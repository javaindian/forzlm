# MARKS-004 Update Package — ChaloSchools AI Secretary

**Built:** 2026-09-19 · **Sequence position:** next patch after `clm_deploy` · **Risk tier:** semantic-rule only (no model, no schema, no frontend)

This package closes the production bug where **"top 5 students in latest exam"** executed an SQL query with **no exam-instance constraint** on marks, producing 5-digit totals (15,000+) — the sum of every exam ever recorded for each student instead of the latest exam round. The fix is a new deterministic semantic rule, **MARKS-004 (rule #60)**, that fires BEFORE execution, forces one corrective regeneration with an exam-instance hint, and fails closed to an honest refusal if the model cannot produce a scoped query. After this patch, a silent 15,000+ total is impossible by construction.

Nothing in this package touches the LLM binary, the dataset, the schema catalog, the frontend, or any gate that currently passes. The only deployed artifact changed is `chalo_chatbot/pipeline/semantic_rules.py` (59 rules → 60 rules). The full 7,973-row false-positive sweep proves the new rule does not perturb any existing behavior.

## Contents

| Path | What it is |
|---|---|
| `patches/marks004_deploy.patch` | **The separate patch file (next after clm_deploy).** Unified diff, 1 file, +132/−1. Applies with `patch -p1` from `/opt/chalo-ai-secretary` or `git apply` anywhere. Fully verified: dry-run, apply, byte-identity, re-apply rejection. |
| `server/patch_marks004_server.py` | Self-verifying, idempotent server patcher (Q50 lineage). Locates the file, backs up, inserts the rule surgically, py_compiles before install, verifies 3 contracts after, **auto-restores on any failure**, optional `--restart`. **Recommended deployment route.** |
| `app/chalo_chatbot/pipeline/semantic_rules.py` | Full post-patch file (60 rules), byte-identical to what the patch produces. Route C: wholesale replacement if you prefer copy-over. |
| `scripts/sweep_marks004.py` | The false-positive sweep harness (7,973 training rows → 0 fires). Re-runnable against any corpus on server or locally. |
| `docs/01_ROOT_CAUSE_ANALYSIS.md` | The three-layer miss that let the bug ship, with schema ground truth. |
| `docs/02_DEPLOYMENT_GUIDE.md` | Three deployment routes, preconditions, expected trace, post-deploy gate re-run. |
| `docs/03_VALIDATION_REPORT.md` | Self-tests, FP sweep, patcher simulation, patch verification matrix — all receipts. |
| `docs/04_ROLLBACK.md` | Restore paths for every route, each under 60 seconds. |
| `docs/05_TECHNICAL_REFERENCE.md` | Rule anatomy: trigger regex, satisfaction markers, canonical fix SQL, orchestrator integration. |

## Quick start (60-second version)

```bash
# 1. upload patch_marks004_server.py to the VPS
scp server/patch_marks004_server.py user@vps:/tmp/

# 2. run it (self-verifying; auto-restores on any failure)
sudo /opt/chalo-ai-secretary/venv/bin/python3 /tmp/patch_marks004_server.py --restart

# 3. prove it
#    ask the chatbot: "top 5 students in latest exam"
#    expect trace:  semantic: REFUSED (MARKS-004) — retrying once with corrective hint
#                   semantic: passed on retry
#    expect totals: ~500-scale (single exam round), never 5 digits
```

Full detail, including the diff-based and file-replacement routes: `docs/02_DEPLOYMENT_GUIDE.md`.

## Scope boundaries (read before mixing with other work)

- **In scope:** `semantic_rules.py` only. One rule added, one docstring line changed, nothing else.
- **Out of scope:** v30 GGUF model, training datasets, `schema_knowledge.py`, `orchestrator.py` (the rule reuses the existing HIGH-severity retry path as-is), `chat.html`, nginx, systemd units. The dynamic prompt router (`schema_router.py`) built earlier remains **built-but-disabled** and is unaffected.
- **Interaction with clm_deploy:** none. `clm_deploy` touched the CLM 2.0 drill-down UI (chat.html 45vh→70vh). This patch touches a different file and layer. Both can be present in any order; this patch assumes only the 59-rule semantic_rules.py baseline that production already runs.
- **Server-side gates to re-run after deploy:** smoke 3,265 · Q50 (expect 115–118 students) · 325-row pending-fees regression. All three were clean against this rule in local proxies; the sweep is the local stand-in where server execution isn't available.

## Related work queued (not in this package)

1. **v31 training rows** — "latest exam" scoping examples so the model gets it right on the first try and the retry latency (~4–8 s on CPU) disappears. Marked proposed, awaiting your confirmation.
2. **Third-party Graphify assessment** — the validation you asked for ("validate this before concluding") is drafted separately from this package so the fix ships unblocked; ask for it and it will be delivered as its own document.
3. **Stage 3 dynamic routing enablement** — the real latency lever; enable via `AI_SECRETARY_PROMPT_PROFILE=dynamic` after a staging golden-50 + smoke pass.

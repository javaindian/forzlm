# 02 — Deployment Guide: marks004 (next patch after clm_deploy)

**Target server layout:** app root `/opt/chalo-ai-secretary/`, app package `chalo_chatbot/`, venv python `/opt/chalo-ai-secretary/venv/bin/python3`, services `chalo-backend.service` (FastAPI pipeline) and `chalo-llm.service` (v30 GGUF, CPU, ctx 8192). The only file this update modifies is `/opt/chalo-ai-secretary/chalo_chatbot/pipeline/semantic_rules.py`, taking it from the 59-rule post-Q50 state to the 60-rule MARKS-004 state.

## 0. Preconditions (check before any route)

Run these five checks; all should pass before you proceed. If any fails, stop and resolve it first — every route below assumes a healthy 59-rule baseline.

```bash
# base file exists and is the 59-rule state (no MARKS-004 yet)
grep -c "def r_"      /opt/chalo-ai-secretary/chalo_chatbot/pipeline/semantic_rules.py   # expect 59
grep -c "MARKS-004"   /opt/chalo-ai-secretary/chalo_chatbot/pipeline/semantic_rules.py   # expect 0

# service healthy
systemctl is-active chalo-backend

# python can compile the current file (rules module imports cleanly)
sudo /opt/chalo-ai-secretary/venv/bin/python3 -m py_compile \
  /opt/chalo-ai-secretary/chalo_chatbot/pipeline/semantic_rules.py && echo BASE-OK
```

If `grep -c "def r_"` returns **60** with `MARKS-004` present, the patch is already applied — the Route A patcher will report `SKIP (idempotent)` and you are done. If the file has been locally modified in ways the baseline doesn't match, prefer Route A or C; Route B's diff will refuse to apply (which is the safe behavior).

## Route A — self-verifying patcher (RECOMMENDED)

This is the same lineage as the Q50 patcher you have already used: locate → idempotent skip → timestamped backup → surgical insertion → compile-gate in a temp file → install → three-contract verification → **automatic restore on any failure**.

```bash
# upload
scp server/patch_marks004_server.py user@YOUR_VPS:/tmp/

# run (add --restart to bounce chalo-backend on success)
sudo /opt/chalo-ai-secretary/venv/bin/python3 /tmp/patch_marks004_server.py --restart
```

What you will see on success, in order: the located file path; `backup -> semantic_rules.py.bak-<YYYYmmdd-HHMMSS>`; three `inserted:` lines (rule block before `def r_subj001(`, registration after the `r_marks001, r_marks002, r_marks003,` line, meta after the `"MARKS-003"` entry); `py_compile OK`; `installed`; `verify: 3/3 contracts OK`; and, with `--restart`, the service bounce. Running it a second time prints `SKIP — already patched` and changes nothing, so accidental double-runs are harmless by design.

The three contracts the patcher verifies after install: (1) the exact live-bug SQL from this incident produces a MARKS-004 HIGH violation; (2) the corrected groupwise-MAX SQL passes clean; (3) the module reports `rule_count() == 60`. If any contract fails, the patcher restores the backup automatically and exits non-zero — you never have to clean up a half-patched file by hand.

## Route B — unified diff (the separate patch file)

`patches/marks004_deploy.patch` is a standard unified diff whose paths are re-rooted to `a/chalo_chatbot/...` / `b/chalo_chatbot/...`, so `-p1` works from any directory that *contains* `chalo_chatbot/`. It carries a readable header comment (git and patch both ignore leading non-diff text).

```bash
scp patches/marks004_deploy.patch user@YOUR_VPS:/tmp/

cd /opt/chalo-ai-secretary
sudo patch -p1 --dry-run < /tmp/marks004_deploy.patch    # preview: expect "OK" lines, no FAILED
sudo patch -p1          < /tmp/marks004_deploy.patch    # apply
# compile gate + restart
sudo /opt/chalo-ai-secretary/venv/bin/python3 -m py_compile \
  chalo_chatbot/pipeline/semantic_rules.py && sudo systemctl restart chalo-backend
```

In a git-managed checkout (e.g. your local `chalo_v97_upd/`), use `git apply --check marks004_deploy.patch && git apply marks004_deploy.patch` from the directory containing `chalo_chatbot/`. Verified behaviors for this exact file: dry-run clean; applied result is byte-identical to the reference 60-rule file; a second `--check` run is rejected (guards against double-apply); `patch -p1 -R` reverses it cleanly (see 04_ROLLBACK.md).

## Route C — full file replacement

Copy the shipped 60-rule file over the production file. Choose this if the server file has drifted from the baseline in ways that make you want a known-good state rather than a surgical change.

```bash
sudo cp app/chalo_chatbot/pipeline/semantic_rules.py \
        /opt/chalo-ai-secretary/chalo_chatbot/pipeline/semantic_rules.py
sudo chown --reference=/opt/chalo-ai-secretary/chalo_chatbot/pipeline/semantic_rules.py.bak-* \
        /opt/chalo-ai-secretary/chalo_chatbot/pipeline/semantic_rules.py 2>/dev/null || true
sudo /opt/chalo-ai-secretary/venv/bin/python3 -m py_compile \
  /opt/chalo-ai-secretary/chalo_chatbot/pipeline/semantic_rules.py
sudo systemctl restart chalo-backend
```

Take a backup first if you use this route (`sudo cp ... semantic_rules.py.bak-preC`), because file replacement has no built-in restore path of its own.

## Post-deploy verification (all routes)

**1. Functional proof — the original bug question.** Ask the chatbot exactly: *"top 5 students in latest exam"*. In the audit trace you must see the rule fire once and the retry succeed:

```
semantic: REFUSED (MARKS-004) — retrying once with corrective hint
semantic: passed on retry
```

The returned totals should be in the normal single-exam scale (~hundreds, not 15,000+). If the model cannot produce a scoped query after the one corrective retry, the pipeline refuses honestly — that refusal is the correct, designed outcome, and the trace will show the MARKS-004 message explaining why.

**2. Regression gates.** Re-run the three standing server gates and compare against their known-good values: smoke suite **3,265**; Q50 TC question **115–118 students** (118 is the reconciled row-granularity variant); **325-row** pending-fees regression. Also confirm at least one everyday marks question that *should* be unbounded ("who is the school topper with aggregate marks?") still answers without a MARKS-004 retry — that is the exemption path.

**3. Service hygiene.** `systemctl is-active chalo-backend`, then tail the journal for one question to confirm no import warnings: `journalctl -u chalo-backend -n 50 --no-pager`.

## Known-good end state

`grep -c "def r_"` → **60** · `grep -c "MARKS-004"` → **7** (definition, meta, docstring, self-tests) · `py_compile` exit 0 · `rule_count()` returns 60 when the module is executed directly · smoke/Q50/325 gates unchanged.

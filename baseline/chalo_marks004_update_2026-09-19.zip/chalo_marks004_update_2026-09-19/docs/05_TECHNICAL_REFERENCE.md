# 05 — Technical Reference: the MARKS-004 rule

Audience: maintainers who will extend, tune, or port the rule. Everything here describes the code actually shipped in `app/chalo_chatbot/pipeline/semantic_rules.py`; nothing is aspirational.

## 1. Position in the pipeline

MARKS-004 is rule #60 in the SEMANTIC stage. The orchestrator invokes each rule as `rule(sql, question, tables) -> list[Violation]`, after GUARDRAIL/VALIDATE/SUBSTITUTE and before BIND/EXECUTE. Its severity is **HIGH**, which routes it into the orchestrator's existing corrective-retry path (`_regen_and_revalidate`): the violated rule's hint text is appended as a corrective instruction, the LLM regenerates once, and the **full** gate chain re-runs on the new SQL — MARKS-004 included, so a bad regen cannot slip through on the retry. If the retry still violates, the pipeline refuses (fail-closed); it never executes a violating query. No orchestrator change was needed or made — the rule is pure data to the existing machinery.

## 2. Trigger conditions (ALL must hold)

| Condition | Implementation | Purpose |
|---|---|---|
| Recency-exam intent | `_MARKS004_RECENCY_RE = r"\b(?:latest|most\s+recent|newest|recent|last)\s+(?:\w+\s+){0,3}exams?\b"` (case-insensitive) | Fires on "latest exam", "most recent exam", "last test" (up to 3 interleaved words), "recent exams" plural, etc. |
| Marks usage | SQL references `\w+.Marks` | The rule governs marks aggregation only; attendance/fee recency questions are out of scope |
| No resolution marker | none of §3's markers present in the SQL | Already-scoped queries pass untouched |
| Not an exemption case | question lacks the school-topper / aggregate-marks exemption phrasing | Those questions *mean* the unbounded aggregate |

All four are conjunctive; the rule is deliberately a scalpel. The exemption check runs before the marker scan so that exempt questions never even reach marker evaluation.

## 3. Resolution markers (any one satisfies the rule)

1. **MAX over a recency column** in a subquery — e.g. `WHERE smm.ID IN (SELECT MAX(ID) ... GROUP BY ClassID, SectionID, ExamTypeID)` or `ExamDate = (SELECT MAX(ExamDate) ...)`.
2. **Windowed recency** — `OVER(... ORDER BY <recency-col> DESC)` (row_number-style latest-instance selection).
3. **Bare `ExamDate`** reference in the marks scope (the OtherExam flow's natural scoping column).
4. **`ExamSettingID`** present *with a tautology guard* (`_MARKS004_TAUTOLOGY_RE`): the marker only counts when the reference can actually constrain the instance — a bare `WHERE smm.ExamSettingID = smm.ExamSettingID`-style self-comparison does not count.
5. **`TOP 1 ... ORDER BY <recency-col> DESC`** shape.

Deliberate non-marker: **`MAX(smd.Marks)`** — the maximum marks *value* is not the latest exam *instance*. This is self-tested (case 6 in the validation report) because it is the most plausible incorrect "fix" a regenerate step could produce.

## 4. The corrective hint (what the retry regenerates against)

The violation's hint carries the canonical repair patterns verbatim, so the retry does not have to rediscover them:

```sql
-- StudentMarkMaster flow (header table: no ExamDate, no SubjectID — one row per
-- (ClassID, SectionID, ExamTypeID) exam round; newest instance = groupwise MAX(ID))
AND smm.ID IN (SELECT MAX(ID) FROM StudentMarkMaster
               WHERE Deleted = 0 AND BranchID IN (...)
               GROUP BY ClassID, SectionID, ExamTypeID)

-- OtherExam flow (this table DOES carry ExamDate)
AND oemm.ExamDate = (SELECT MAX(ExamDate) FROM OtherExamMarkMaster WHERE IsDeleted = 0)
```

The groupwise form (not a global `MAX(ID)`) is mandatory: a global maximum would select the single newest header row *school-wide*, collapsing every cohort except one. The `GROUP BY` cohort key is what makes the constraint per-class, per-section, per-exam-type — which is the actual meaning of "latest exam" in this school's data model.

## 5. Rule metadata and registration

Three insertion points exist in `semantic_rules.py`, mirrored exactly by the three patcher anchors:

1. **Function** `def r_marks004(sql, q, tables):` placed immediately before `def r_subj001(`, alongside its module-level compiled regexes (`_MARKS004_RECENCY_RE`, `_MARKS004_LATEST_RESOLUTION_RE` with the MAX-Marks exclusion logic, `_MARKS004_TAUTOLOGY_RE`).
2. **Registry** — `r_marks004` appended after the `r_marks001, r_marks002, r_marks003,` line so MARKS-004 evaluates after its Marks-family siblings.
3. **Metadata** — `"MARKS-004"` entry in `RULE_META` after the `"MARKS-003"` block: severity HIGH, family Marks, and the hint text of §4. The module docstring's rule count was updated 59→60 with a changelog line; the six self-test tuples ship in the module's self-test table (including the verbatim production-bug SQL as case 1).

## 6. Extension notes for future rules

Three design decisions here are worth copying. **(a) Conjunctive intent+shape triggering** — intent regexes alone over-fire on paraphrase; shape regexes alone miss paraphrase; the AND of both is what produced 0/7,973 false positives. **(b) Whitelist-style resolution markers with an explicit non-marker list** — stating what does *not* count (MAX of the value) is as important as stating what does, because the near-miss is where regenerations go wrong. **(c) Reuse of severity-driven retry** — a new rule should never invent its own remediation channel; emitting a HIGH Violation with a high-quality hint inherits a tested corrective path for free. When v31 training rows land, this rule stays exactly as-is: the training rows reduce how often it fires, and the rule remains the deterministic backstop for when the model regresses.

# 01 — Root Cause Analysis: "Top 5 students in latest exam" returned 15,000+

**Bug class:** silent wrong-aggregation-scope (business semantics) · **Severity:** HIGH — wrong data shown as correct, no error surfaced · **First observed:** production, 2026-09-15 session · **Fixed by:** MARKS-004 (semantic rule #60)

## 1. The live failure, precisely

The owner asked the chatbot *"top 5 students in latest exam"*. The pipeline answered confidently with students whose total marks were 15,000+ — five digits, where a single exam round at this school tops out in the hundreds. The trace that accompanied the answer is the most important diagnostic artifact: `sql_source=llm`, user 116 / branch 1, **all 59 semantic rules green**, TOP-5 pagination applied normally. Nothing in the system objected, because nothing in the system had been told to object.

The generated SQL had the shape:

```sql
SELECT TOP 5 s.Name, SUM(smd.Marks) AS TotalMarks
FROM StudentMarkMaster smd
JOIN Student_Master s ON ...
GROUP BY s.Name
ORDER BY TotalMarks DESC
```

The fatal property is what is **absent**: there is no constraint tying the marks rows to any single exam instance. `StudentMarkMaster` carries one header row per exam round per cohort, so `SUM(smd.Marks)` without an instance filter aggregates **every exam the school has ever recorded** for each student. The ORDER BY/TOP 5 then ranks students largely by *how many exams they have sat* — a silently wrong answer that looks perfectly plausible in a UI.

## 2. Why three independent defenses all missed

A fail-closed pipeline missed this because the miss happened at three layers, each of which would have been sufficient on its own:

**Layer 1 — training corpus.** A grep plus a full JSONL scan of `train_v29 + val_v29 + train_v28 + val_v28` (7,973 rows) found **zero** rows containing a "latest exam" recency modifier on a marks question. Worse than the absence: the corpus *legitimately teaches the unbounded shape*, because those questions are correct business semantics elsewhere — *"show me the school topper with marks"* and *"top 20 students by aggregate marks"* map to exactly this `SUM(smd.Marks)`-with-no-exam-constraint form. From v30's point of view, the generated SQL was textbook-correct: the training data had actively rewarded it in near-identical contexts, and nothing had ever punished the distinction that "latest exam" changes the aggregation scope.

**Layer 2 — fastpath.** The `TopNTemplateLookup` fastpath serves top-N questions as exact-match templates drawn from the dataset. Since no dataset row ever combined a top-N marks request with a recency modifier, no template existed for this question; the fastpath correctly declined and the question fell through to the LLM path. The fastpath behaved exactly as designed — the design gap is that exact-match templates cannot generalize a modifier the dataset has never seen.

**Layer 3 — semantic rules.** The 59-rule chain had no rule enforcing exam-instance scoping. The closest rule, EXAM-007, fires on *term* intent (e.g. "in final term"), which is a different axis — a term constraint does not identify a specific exam round, and a marks query can legitimately reference a term through the exam-type hierarchy. So the live SQL passed every check the chain knew how to perform.

## 3. Schema ground truth (why the fix looks the way it does)

A naive fix would be "add `AND ExamDate = (SELECT MAX(ExamDate) ...)`" — and it would be wrong for the primary table. Verified against `pipeline/schema_catalog.json`:

- **`StudentMarkMaster` has no `SubjectID` and no `ExamDate`.** It is the *per-exam-round header* for the cohort key `(ClassID, SectionID, ExamTypeID)`; one row per round. Subject-level detail lives one level down in `StudentMarkDetails` via `EvalHierID` (the same fact SUBJ-001's canonical note records).
- The **canonical latest-instance constraint is therefore a groupwise MAX(ID)**: for each cohort, the newest header row is `MAX(ID)` within that cohort's group. This is why the standard repair hint the rule injects is `AND smm.ID IN (SELECT MAX(ID) FROM StudentMarkMaster WHERE Deleted = 0 AND BranchID IN (...) GROUP BY ClassID, SectionID, ExamTypeID)`.
- The **`OtherExam` flow is different**: `OtherExamMarkMaster` *does* carry `ExamDate`, so its canonical form is `oemm.ExamDate = (SELECT MAX(ExamDate) FROM OtherExamMarkMaster WHERE IsDeleted = 0)`. The rule accepts either pattern as a valid resolution marker.

## 4. Why the fix lives in the semantic layer and not elsewhere

Three alternatives were considered and rejected. Retraining alone (v31 rows) fixes the model's first attempt but leaves a silent hole whenever the model regresses — and a deterministic guarantee cannot rest on probabilistic weights. A fastpath template fixes exactly one phrasing and re-opens the hole for every paraphrase ("most recent exam", "last test", "newest exam"). A prompt-only instruction is non-deterministic under paraphrase pressure and provides no auditable refusal. A semantic rule is the only layer that sees both the question's *intent* and the SQL's *shape* at the same time, is deterministic, is auditable in the trace, and fails closed through machinery that already exists in the orchestrator (HIGH-severity corrective retry). MARKS-004 was therefore placed at that layer — with v31 training rows queued as the *latency* complement, so that first-try success makes the retry path rare rather than structurally absent.

## 5. Blast radius before and after

| | Before (59 rules) | After (60 rules) |
|---|---|---|
| "top 5 students in latest exam" | 15,000+ totals, shown as correct | one corrective retry with groupwise-MAX hint; ~500-scale totals; refusal if unfixable |
| "school topper with aggregate marks" | unbounded SUM — correct semantics | **unchanged** (explicit exemption; verified in self-tests) |
| every other marks query form | as-is | **unchanged** — 7,973-row sweep produced 0 false positives |
| retry cost when the rule fires | — | one extra LLM call, ~4–8 s on the CPU v30 service |

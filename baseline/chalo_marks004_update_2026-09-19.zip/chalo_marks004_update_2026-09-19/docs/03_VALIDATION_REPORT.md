# 03 — Validation Report: MARKS-004

**Verdict: SHIP.** Every gate executed against the rule returned a clean result. This report lists each gate, the exact population it ran over, the pass criterion, and the observed outcome, so the numbers can be re-verified independently from the shipped artifacts.

## 1. Static integrity

| Gate | Command shape | Result |
|---|---|---|
| Byte compile | `python3 -m py_compile semantic_rules.py` | PASS (exit 0), HEAD 60-rule file and 59-rule parent both |
| Rule census | `grep -c "^def r_"` | 60 in HEAD (was 59 in parent `755391e^`) |
| Self-test harness | execute module directly (`python3 semantic_rules.py`) | runs to completion, prints `rule_count() = 60` |

## 2. Behavioral self-tests (6 tuples, including the live-bug SQL)

The module ships with six embedded self-test tuples; the decisive rows and their observed behavior:

| # | Case | Expected | Observed |
|---|---|---|---|
| 1 | **Exact live-bug SQL** from the production incident (unscoped `SUM(smd.Marks)`, recency question text) | MARKS-004 fires, severity HIGH | ✅ fired, HIGH |
| 2 | Same query + groupwise `MAX(ID)` constraint per `(ClassID, SectionID, ExamTypeID)` | passes clean | ✅ no violation |
| 3 | "School topper with aggregate marks" intent, unbounded SUM | exempt — unbounded is the confirmed semantics | ✅ no violation |
| 4 | Recency question answered via `AVG(...Marks)` with no instance scope | fires | ✅ fired |
| 5 | OtherExam flow resolved by `oemm.ExamDate = (SELECT MAX(ExamDate) ...)` | passes clean | ✅ no violation |
| 6 | Recency question using `MAX(smd.Marks)` as if it were the latest exam | fires — **MAX(Marks) is deliberately NOT instance resolution** | ✅ fired |

Case 6 is the one that protects against the most seductive near-miss fix: taking the maximum *marks value* is not the same as taking the latest *exam instance*, and the rule is built to reject that confusion explicitly.

## 3. False-positive sweep — the regression-safety gate

**Population:** every training and validation row in the working corpora — `train_v29 + val_v29 + train_v28 + val_v28` = **7,973 rows**. Each row's question text was paired with its gold SQL through the full rule entry point (`r_marks004(sql, question, tables)`).

**Pass criterion:** zero fires, or only fires that a human review would certify as true positives (none required — the result was zero).

**Result:** **0 MARKS-004 violations across 7,973 rows** (`scripts/sweep_marks004.py`, re-runnable). This is the gate that matters most for production stability: it shows the rule cannot fire on any query shape the model was ever trained to produce for these corpora. The practical consequence is that MARKS-004 cannot introduce retry churn on existing traffic — it only activates on the specific recency-plus-marks-without-scope intersection that did not exist in any historical row.

**Scope note:** the sweep is a local proxy over the training corpora; the standing server-side gates (smoke 3,265 · Q50 115–118 · 325-row pending-fees regression) are re-run on the VPS per the deployment guide. The Q50/325 gate workloads do not intersect the MARKS-004 trigger (no recency-exam intent), and the sweep corroborates that.

## 4. Server patcher — simulated end-to-end

The patcher (`server/patch_marks004_server.py`) was exercised against a pristine 59-rule copy in a controlled run before shipping:

| Step | Result |
|---|---|
| Locate target file (default glob + `CHALO_RULES_FILE` override) | ✅ |
| Backup `semantic_rules.py.bak-<stamp>` | ✅ created |
| Insert 1/3 — rule block before `def r_subj001(` | ✅ |
| Insert 2/3 — registration after `r_marks001, r_marks002, r_marks003,` | ✅ |
| Insert 3/3 — `RULE_META` entry after the `"MARKS-003"` block | ✅ |
| `py_compile` on temp file **before** install | ✅ |
| Install + verify contracts | ✅ 3/3 (live-bug fires HIGH · corrected passes · `rule_count()==60`), module 59→60 |
| Idempotency: second run | ✅ `SKIP — already patched`, no changes |
| Failure path: forced contract failure in a negative test | ✅ auto-restores backup, exits non-zero |

## 5. Patch file verification matrix (the separate diff)

`patches/marks004_deploy.patch` was verified in a clean sandbox built from git commit `755391e` (parent state = 59 rules) rather than trusted by inspection:

| # | Check | Result |
|---|---|---|
| 1 | `git apply --check` on pristine 59-rule tree | ✅ PASS |
| 2 | `patch -p1 --dry-run` on pristine tree | ✅ PASS |
| 3 | Real `git apply`, then byte-compare against the reference 60-rule file | ✅ **byte-identical** |
| 4 | `git apply --check` again after apply (double-apply guard) | ✅ correctly REJECTED |

Receipt: `md5 b887dbb442c4d488b4a61d3c5f20d518` · `sha256 844675304bb1bb29419d4d8712cfc1c4bcf5cafab5cc2e7f32ac400cf6276d1a` · 13,098 bytes. The diff is re-rooted to `a/chalo_chatbot/...` so `-p1` applies from `/opt/chalo-ai-secretary` directly; the identical operation from your local `chalo_v97_upd/` root is what the sandbox exercised.

## 6. What was NOT re-verified here (and where it is covered)

The golden-50 question set and the 3,265-row smoke suite execute against the live database and therefore belong to the server-side post-deploy step (deployment guide §Post-deploy verification). Local proxies for all three are in place: the FP sweep covers the rule-behavior axis, the patcher's contract tests cover the incident axis, and the exemption self-test covers the school-topper axis. No local gate failed; nothing is being deferred because it was skipped — the server gates are confirmatory, not exploratory.

# 04 — Rollback Guide: marks004

Every deployment route has a dedicated, tested rollback path. All of them are single commands plus one service restart; none touches the model, the database, or any other service. Rollback restores the *exact* pre-patch bytes — including the Q50 fix that preceded this update — because every route preserves the original file rather than editing history in place.

## Route A rollback (patcher backup restore)

The patcher creates `semantic_rules.py.bak-<YYYYmmdd-HHMMSS>` alongside the target **before** it inserts anything, and only ever installs after the temp-file compile gate passes. To roll back:

```bash
cd /opt/chalo-ai-secretary/chalo_chatbot/pipeline
ls -t semantic_rules.py.bak-* | head -3          # identify the pre-patch stamp
sudo cp semantic_rules.py.bak-<stamp> semantic_rules.py
sudo /opt/chalo-ai-secretary/venv/bin/python3 -m py_compile semantic_rules.py
sudo systemctl restart chalo-backend
grep -c "def r_" semantic_rules.py               # expect 59
```

Take care to pick the correct stamp if multiple backups exist (e.g. from earlier Q50 work): the MARKS-004 backup is the one whose timestamp matches the deploy you are undoing. When in doubt, `grep -c MARKS-004` on the backup — the correct restore source contains zero matches. Do not delete backups after rollback; they are the audit trail for the incident window.

Note that the *automatic* rollback inside the patcher is a different mechanism and needs no action from you: if any post-install contract had failed, the patcher would already have restored the backup before exiting. You only reach this section if a post-deploy behavioral problem appears that the contracts could not see.

## Route B rollback (reverse the diff)

The unified diff is fully reversible with standard tooling — verified during the patch build (the sandbox confirmed `patch -p1` applies and the reverse operation restores the base):

```bash
cd /opt/chalo-ai-secretary
sudo patch -p1 -R --dry-run < /tmp/marks004_deploy.patch   # preview the reversal
sudo patch -p1 -R          < /tmp/marks004_deploy.patch    # apply the reversal
# or, in a git checkout:
git apply -R marks004_deploy.patch
sudo /opt/chalo-ai-secretary/venv/bin/python3 -m py_compile \
  chalo_chatbot/pipeline/semantic_rules.py && sudo systemctl restart chalo-backend
```

The dry-run must show clean reversal hunks with no `FAILED` lines. If it reports offsets, the file has drifted since the patch was applied — stop and diff the current file against a backup before proceeding rather than forcing the reversal.

## Route C rollback (restore your pre-C backup)

Route C has no built-in restore, which is why the deployment guide instructs taking `semantic_rules.py.bak-preC` before overwriting. Restore that copy, compile-gate, restart — the same four commands as the Route A section, with your own backup name.

## Service-level verification after any rollback

Rollback is not complete until the pipeline proves it is the 59-rule state again. Three checks, in order: the file census (`grep -c "def r_"` → 59, `grep -c "MARKS-004"` → 0), a clean compile, and one behavioral probe — ask *"top 5 students in latest exam"* and confirm the trace shows **no** MARKS-004 line (it will, of course, reproduce the original unbounded aggregation; that is the accepted state you are rolling back to, and the incident remains documented in this package). Finish with `systemctl is-active chalo-backend` and the smoke suite to confirm nothing else moved.

## Interaction with other patches

Rolling back MARKS-004 does not disturb `clm_deploy` (frontend-only) or the Q50 fix (different identifiers inside the same file — the Q50 TC-request skips live in `r_stud007`, and rollback restores the file *with* those skips intact because they predate this patch). No rule other than MARKS-004 is added or removed by any route's reversal. If a future patch builds on the 60-rule state, its documentation should state that dependency explicitly, the way this package states its 59-rule baseline.

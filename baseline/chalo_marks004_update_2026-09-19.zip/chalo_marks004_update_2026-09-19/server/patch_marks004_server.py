#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
patch_marks004_server.py — MARKS-004 (exam-instance scoping) server patcher.
Production bug 2026-09-15: "top 5 students in latest exam" returned 5-digit
totals (15,000+) because SUM(smd.Marks) spanned every exam ever recorded.

WHAT IT DOES (surgical, idempotent, self-verifying, auto-restoring):
  1. Locates semantic_rules.py (env CHALO_RULES_FILE overrides the search).
  2. Skips cleanly if MARKS-004 is already present.
  3. Backs up to semantic_rules.py.bak-<stamp>  (rollback = restore file).
  4. Inserts, BEFORE `def r_subj001(`:  the MARKS-004 rule block.
     Registers r_marks004 in RULES (after the r_marks001..003 line).
     Adds the RULE_META catalog entry (after the MARKS-003 line).
  5. Verifies with the interpreter that runs this script:
       py_compile OK
       live-bug SQL  -> MARKS-004 HIGH fires
       corrected SQL -> no MARKS-004
       rule_count()  -> 60
  6. ANY verification failure -> backup auto-restored, exit 1 (no half state).

USAGE (on the VPS):
  sudo /opt/chalo-ai-secretary/venv/bin/python3 patch_marks004_server.py
  sudo /opt/chalo-ai-secretary/venv/bin/python3 patch_marks004_server.py --restart   # also restart backend
Then live test: ask the chatbot "top 5 students in latest exam" and check the
pipeline trace for: semantic: REFUSED (MARKS-004) — retrying once ... passed on retry.
"""
import glob
import importlib
import os
import py_compile
import shutil
import sys
import time

RULE_BLOCK = r'''# ============ 2026-09-15: exam-instance scoping (rule 60, production bug) ============
# Live bug: "top 5 students in latest exam" -> SUM(smd.Marks) with no exam
# constraint = totals across EVERY exam (15,000+). Training legitimately teaches
# unbounded aggregates ("school topper"), so MARKS-004 is the recency signal.
_MARKS004_RECENCY_RE = re.compile(
    r"\b(?:latest|most\s+recent|newest|recent|last)\s+(?:\w+\s+){0,3}exams?\b",
    re.IGNORECASE)
_MARKS004_LATEST_RESOLUTION_RE = re.compile(
    r"MAX\s*\(\s*(?:\w+\.)?(?:ID|CreatedOn|Created_Date|CreatedDate|ExamDate|UpdatedOn|Updated_Date|GeneratedDate)\s*\)"
    r"|\bOVER\s*\(\s*ORDER\s+BY[^)]*\b(?:ID|CreatedOn|Created_Date|ExamDate)\b[^)]*DESC"
    r"|\bExamDate\b"
    r"|\bExamSettingID\b"
    r"|\bTOP\s+1\b[^;]*ORDER\s+BY[^;]*\b(?:ID|CreatedOn|Created_Date|ExamDate)\s+DESC",
    re.IGNORECASE)
_MARKS004_TAUTOLOGY_RE = re.compile(
    r"\b\w+\.ExamSettingID\s*=\s*\w+\.ExamSettingID\b", re.IGNORECASE)

def r_marks004(sql, q, tables):
    """MARKS-004 (production bug 2026-09-15): a marks question scoped to the
    LATEST exam must restrict the marks to ONE exam instance. Unbounded marks
    usage spans every exam in the database (live case: 15,000+ totals).
    Exempt: 'school topper' / 'aggregate marks' questions (recency-free by
    design — the unbounded aggregate is the confirmed semantics there)."""
    if not (tables & MARKS_TABLES):
        return None
    ql = (q or "").lower()
    if not _MARKS004_RECENCY_RE.search(ql):
        return None
    if not re.search(r"\b\w+\.Marks\b", sql, re.IGNORECASE):
        return None
    if _MARKS004_LATEST_RESOLUTION_RE.search(sql) and \
            not _MARKS004_TAUTOLOGY_RE.search(sql):
        return None
    return Violation("MARKS-004", "HIGH",
        "Marks question is scoped to the LATEST exam but the query uses marks "
        "with no exam-instance constraint — totals/averages span EVERY exam "
        "ever recorded (live bug: 15,000+ marks instead of one exam's total).",
        "Restrict the marks to the newest exam instance. Standard pattern: "
        "AND smm.ID IN (SELECT MAX(ID) FROM StudentMarkMaster WHERE Deleted = 0 "
        "AND BranchID IN (same authorized-branch subquery as the outer query) "
        "GROUP BY ClassID, SectionID, ExamTypeID) — the groupwise MAX keeps "
        "only the newest exam round per cohort. For the dated OtherExam flow: "
        "AND oemm.ExamDate = (SELECT MAX(ExamDate) FROM OtherExamMarkMaster "
        "WHERE IsDeleted = 0). Never sum/display marks across exam instances "
        "when the question asks for the latest exam.", "Marks")

'''

RULES_ANCHOR = "    r_marks001, r_marks002, r_marks003,"
RULES_INSERT = ("    # ── 2026-09-15: exam-instance scoping (60, production bug) ──\n"
                "    r_marks004,\n")

META_ANCHOR = ('    "MARKS-003": {"title": "Marks total/average without NA/NT/OP exclusion", '
               '"catalog_ref": "User rules 2026-09-08"},')
META_INSERT = ('\n    "MARKS-004": {"title": "Latest-exam marks question not scoped to one exam '
               'instance", "catalog_ref": "Production bug 2026-09-15"},')

DEF_ANCHOR = "def r_subj001("

LIVE_BUG_SQL = (
    "SELECT TOP 5 smd.StudentID, stm.AdmissionNo, SUM(smd.Marks) AS TotalMarks "
    "FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID "
    "INNER JOIN Student_Master stm ON smd.StudentID = stm.ID "
    "WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId) "
    "AND smd.Deleted = 0 AND (smd.Others IS NULL OR smd.Others NOT IN ('NA', 'NT', 'OP')) "
    "AND smm.Deleted = 0 GROUP BY smd.StudentID, stm.AdmissionNo "
    "ORDER BY TotalMarks DESC")
CORRECTED_SQL = LIVE_BUG_SQL.replace(
    "WHERE smd.BranchID IN",
    "WHERE smm.ID IN (SELECT MAX(smm2.ID) FROM StudentMarkMaster smm2 "
    "WHERE smm2.Deleted = 0 GROUP BY smm2.ClassID, smm2.SectionID, smm2.ExamTypeID) "
    "AND smd.BranchID IN")


def find_rules_file():
    env = os.environ.get("CHALO_RULES_FILE")
    if env and os.path.isfile(env):
        return env
    candidates = [
        "/opt/chalo-ai-secretary/chalo_chatbot/pipeline/semantic_rules.py",
        "/opt/chalo-ai-secretary/backend/pipeline/semantic_rules.py",
        "/opt/chalo-ai-secretary/app/pipeline/semantic_rules.py",
    ]
    for c in candidates:
        if os.path.isfile(c):
            return c
    hits = glob.glob("/opt/chalo-ai-secretary/**/pipeline/semantic_rules.py",
                     recursive=True)
    if hits:
        return sorted(hits, key=len)[0]
    hits = glob.glob("/opt/chalo*/**/pipeline/semantic_rules.py", recursive=True)
    if hits:
        return sorted(hits, key=len)[0]
    return None


def verify(path):
    """Import the patched module fresh and assert the three contracts."""
    pipeline_dir = os.path.dirname(os.path.abspath(path))
    sys.path.insert(0, pipeline_dir)
    for m in [k for k in list(sys.modules) if k == "semantic_rules"]:
        del sys.modules[m]
    mod = importlib.import_module("semantic_rules")
    bugs = mod.check_sql(LIVE_BUG_SQL, "top 5 students in latest exam")
    m4_bug = [v for v in bugs if v.rule_id == "MARKS-004"]
    assert m4_bug and m4_bug[0].severity == "HIGH", \
        f"live-bug SQL did not fire MARKS-004 HIGH: {bugs}"
    corr = mod.check_sql(CORRECTED_SQL, "top 5 students in latest exam")
    m4_corr = [v for v in corr if v.rule_id == "MARKS-004"]
    assert not m4_corr, f"corrected SQL still fires MARKS-004: {m4_corr}"
    n = mod.rule_count()
    assert n == 60, f"rule_count() = {n}, expected 60"
    return n


def main():
    restart = "--restart" in sys.argv
    path = find_rules_file()
    if not path:
        print("FAIL: semantic_rules.py not found. Set CHALO_RULES_FILE=/full/path and retry.")
        return 1
    print(f"target : {path}")

    src = open(path, encoding="utf-8").read()
    if "MARKS-004" in src:
        print("SKIP: MARKS-004 already present — nothing to do.")
        return 0

    # pre-state
    sys.path.insert(0, os.path.dirname(os.path.abspath(path)))
    try:
        pre = importlib.import_module("semantic_rules")
        print(f"pre-state: rule_count() = {pre.rule_count()}")
    except Exception as e:
        print(f"WARN: could not import pre-state module ({e}) — continuing")

    # anchors must all exist BEFORE any write
    if DEF_ANCHOR not in src or RULES_ANCHOR not in src or META_ANCHOR not in src:
        missing = [a for a in (DEF_ANCHOR, RULES_ANCHOR, META_ANCHOR) if a not in src]
        print(f"ABORT: anchor(s) not found in server file: {missing}")
        print("       File layout differs from expectation — NO changes written.")
        print("       Fix: sync the repo copy (chalo_chatbot/pipeline/semantic_rules.py) instead.")
        return 1

    stamp = time.strftime("%Y%m%d-%H%M%S")
    backup = f"{path}.bak-{stamp}"
    shutil.copy2(path, backup)
    print(f"backup : {backup}")

    patched = src.replace(DEF_ANCHOR, RULE_BLOCK + DEF_ANCHOR, 1)
    patched = patched.replace(RULES_ANCHOR, RULES_ANCHOR + "\n" + RULES_INSERT, 1)
    patched = patched.replace(META_ANCHOR, META_ANCHOR + META_INSERT, 1)

    tmp = path + ".tmp-marks004"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(patched)
    try:
        py_compile.compile(tmp, doraise=True)
        print("py_compile: OK (patched temp file)")
    except Exception as e:
        os.remove(tmp)
        print(f"FAIL: patched file does not compile — server file untouched. {e}")
        return 1

    os.replace(tmp, path)
    print("write  : patched file installed")

    try:
        n = verify(path)
        print(f"verify : live-bug SQL -> MARKS-004 HIGH fires: OK")
        print(f"verify : corrected SQL -> no MARKS-004: OK")
        print(f"verify : rule_count() = {n} (expected 60): OK")
    except Exception as e:
        shutil.copy2(backup, path)
        print(f"FAIL: post-patch verification failed ({e})")
        print(f"ROLLBACK: backup restored -> {backup}")
        return 1

    print("\nDONE. Now restart the backend to load the new rules:")
    print("  sudo systemctl restart chalo-backend")
    if restart:
        rc = os.system("sudo systemctl restart chalo-backend")
        print(f"systemctl restart chalo-backend -> rc={rc}")
        time.sleep(2)
        os.system("systemctl is-active chalo-backend")
    else:
        print("(or re-run with --restart to do it from here)")
    print("\nLive test: ask 'top 5 students in latest exam' — expect trace lines:")
    print("  semantic: REFUSED (MARKS-004) — retrying once with corrective hint")
    print("  semantic: passed on retry")
    print(f"\nRollback (if ever needed): cp {backup} {path} && sudo systemctl restart chalo-backend")
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""
sweep_marks004.py — false-positive sweep for MARKS-004 over the full
training/validation corpus (train_v29 + val_v29 + train_v28).

Purpose: MARKS-004 triggers a HIGH-severity semantic violation -> one
corrective LLM retry -> refusal. If it fired on SQL the model was TRAINED
to produce, legitimate questions would burn a retry (latency) or refuse.
The training corpus is the best local proxy for production question space
(the Q50 / 325-row gates are server-side).

PASS criterion: 0 MARKS-004 fires across all rows (recency-exam phrasing
never appears in the corpus — verified by grep), OR every fire is a
genuine unbounded-latest-exam bug shape (review list printed).
"""
import json
import sys

sys.path.insert(0, "/home/z/my-project/chalo_v97_upd/chalo_chatbot/pipeline")
import semantic_rules  # noqa: E402

FILES = [
    "/home/z/my-project/chalo_v97_upd/chalo_chatbot/training/train_v29.jsonl",
    "/home/z/my-project/chalo_v97_upd/chalo_chatbot/training/val_v29.jsonl",
    "/home/z/my-project/chalo_v97_upd/chalo_chatbot/training/train_v28.jsonl",
    "/home/z/my-project/chalo_v97_upd/chalo_chatbot/training/val_v28.jsonl",
]

total = 0
fires = []
for path in FILES:
    try:
        with open(path, encoding="utf-8") as f:
            for ln, line in enumerate(f, 1):
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except json.JSONDecodeError:
                    continue
                q = (rec.get("input") or "").strip()
                sql = (rec.get("output") or "").strip()
                if not q or not sql:
                    continue
                total += 1
                vs = semantic_rules.check_sql(sql, q)
                m4 = [v for v in vs if v.rule_id == "MARKS-004"]
                if m4:
                    fires.append((path.split("/")[-1], ln, q[:90], sql[:160]))
    except FileNotFoundError:
        print(f"  (skip, missing: {path})")

print(f"rows checked: {total}")
print(f"MARKS-004 fires: {len(fires)}")
for src, ln, q, s in fires[:20]:
    print(f"\n--- {src}:{ln}\nQ: {q}\nS: {s}")
print("\nVERDICT:", "CLEAN — no false positives" if not fires else "REVIEW NEEDED")

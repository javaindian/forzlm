# V63 Release Notes — 2026-09-10
**Quick-wins (no retrain) + v29 dataset final (Stage B3) + audit package**

This release pairs with `chalo_v63_update_2026-09-09.tar.gz` (10 files) and
`chalo_v29_audit_package_2026-09-09.zip`. All items were approved by the school
owner on 2026-09-09 ("build now AND keep in v29 batch — if one fails, one catches").

---

## 1. Patch 1 — bare-number class questions answer instantly

**Problem:** "How many students are in 8" took >1 minute while "class 10"
phrasings answered in 1–3 seconds. Root cause (code-verified): `ClassTemplateLookup`
recognized only "class N / Nth / N std / std N / grade N / class <word>" — a bare
number after a preposition matched nothing, so the question fell to the LLM path
(20–45 s) with up to 4–5 stacked corrective retries and no total budget.

**Fix (`pipeline/template_lookups.py`):**
- Bare-number class pattern: `(?:in|for|from|of)` + whitespace + class number
  (fixed-width lookbehinds; a bare "8" appearing earlier in the question, e.g.
  "18 students…", deliberately skips the match).
- Filler-tolerant template keys (reuses `dataset_lookup.strip_fillers`), so
  "how many students are there in 8" and "how many students in 8" hit the same key.
- Safety guards: single-SQL collision check (a template ships only if it maps to
  exactly one dataset SQL), first-occurrence replacement guard.

**Result:** "how many students are in 8" is now instant (fastpath). Test matrix
green; shapes genuinely absent from the dataset still go to the LLM by design.

## 2. Patch 2 — Branch_Id → BranchID auto-repair

**Problem:** 11 of the UAT EXECUTE errors shared `SELECT Branch_Id FROM
UserAccountRoleDetails` — the correct column is `BranchID` (`Branch_Id` belongs to
`Branch_Academic_Details`). The v28-era model intermittently writes the wrong one →
"Invalid column" → generic sorry-error, plus one extra slow retry.

**Fix (`pipeline/orchestrator.py`):** `_auto_repair_branch_id` rewrites ONLY the
bare/alias-bound `Branch_Id` on `UserAccountRoleDetails`; `Branch_Academic_Details`
uses are untouched. Applied at all 6 generation points including retries.
0 dataset rows changed (verified SQL was already correct).

## 3. Patch 3 — 90-second total-cycle budget + bigger output cap

**Problem:** the retry stack had no total budget — worst case ~4–5 stacked LLM
calls could run 2–3+ minutes; and `max_tokens=512` truncated some complex SQL
(forcing a refuse + retry).

**Fix:**
- New env `AI_SECRETARY_TOTAL_BUDGET` (default **90 s**, the owner-approved max
  wait). Checked before EVERY retry (guardrail / branch-scoping / semantic /
  local-execute / api-execute). When exhausted, the bot stops retrying and replies
  honestly with suggestion chips instead of failing late. Set `0` to disable (tests).
- `max_tokens` default **512 → 768** (`backend/main.py` ChatRequest `n`). Cuts
  "Output truncated" refusals; normal short answers unaffected.
- Per-call `AI_SECRETARY_LLM_TIMEOUT` stays **45 s** — the budget, not the
  per-call timeout, is what caps the whole cycle.

## 4. Patch 4 — chips: 6 visible, rotating, from a 30-question verified pool

- `ux_config.json`: `suggested_questions_visible = 6` (owner decision).
- Pool expanded 8 → **30** questions; every one verified THREE ways: v28 instant
  (fastpath hit) + 59-rule clean + v29 clean. Module-diverse, deduped, shape-guarded
  (no <12-char fragments, no dangling "same for…", no PII-ish asks).
- `frontend/chat.html` (v12): picks 6 at random per page load; stable across
  re-renders. Every shown chip remains a training-dataset question → instant answer.
- After ANY dataset change, re-verify with `scripts/build_chip_pool.py`.

## 5. Stage B3 — column fitness (the "intelligent columns" rule)

Owner rule: every per-student record carries **admission number + student name +
class + section**; no marks in non-marks questions; no raw IDs where a name exists;
centum-holders LISTS show only admno + name + class + section + subjects.

**What was done (`scripts/build_v29_columns.py`, report in
`training/v29_BUILD_REPORT.md`):**
- 407 per-student list rows detected; **390 edited** (360 train / 30 val) with
  schema-driven join injection; raw ID → name swaps; marks dropped from non-marks
  lists (rank questions keep marks); UNION arms edited per-arm.
- **22 documented residue rows** (`training/b3_residue_list.json`): 14 pre-admission
  applicants (no admission number exists yet) + 8 without a safe class link.
- 3 centum-holder LIST teaching rows added (2 train + 1 val).
- Every edit re-verified through the 59-rule engine; invariants I7–I10 ALL GREEN.
- Backups: `*.preB3`.

## 6. Dataset final numbers

| Split | Rows | Gate |
|---|---|---|
| `training/train_v29.jsonl` | **3,651** | 59-rule checker clean, parens balanced, 0 dup questions |
| `training/val_v29.jsonl` | **320** | same |

Stages applied: A → B1.5 → B1.6 → B1.7 → B2 → B2-mech → B2-struct → B2-stud006 →
marks-rules → AVG-rules → scholastic → STAFF-004 → PII-001 → **B3 column fitness**.
Full before/after log: `training/v29_BUILD_REPORT.md`.

## 7. Files in the deploy bundle (10)

```
backend/main.py                 (budget check, max_tokens 768, PII message, chips wiring)
pipeline/orchestrator.py        (_auto_repair_branch_id, AI_SECRETARY_TOTAL_BUDGET)
pipeline/template_lookups.py    (bare-number + filler-tolerant class templates)
pipeline/dataset_lookup.py      (strip_fillers used by templates — shipped for pairing)
pipeline/semantic_rules.py      (59 rules incl. PII-001 #59, STAFF-004 exemption)
pipeline/schema_knowledge.py    (parent-subjects block, staff on-hold note)
frontend/chat.html              (v12: 6 rotating chips)
frontend/audit.html
ux_config.json                  (visible=6, pool=30, v63 _README note)
```

## 8. Deploy (VPS)

```bash
cd /home/ubuntu && tar xzf chalo_v63_update_2026-09-09.tar.gz
sudo cp backend/main.py /opt/chalo-ai-secretary/chalo_chatbot/backend/
sudo cp pipeline/*.py /opt/chalo-ai-secretary/chalo_chatbot/pipeline/
sudo cp ux_config.json /opt/chalo-ai-secretary/chalo_chatbot/
sudo cp frontend/chat.html frontend/audit.html /var/www/chalo/
sudo chown -R chalo:chalo /opt/chalo-ai-secretary/chalo_chatbot
sudo systemctl restart chalo-backend
```

**⚠ Urgency:** PII-001 (bulk contact block) is in this bundle but NOT live on the
VPS until you deploy — the bulk-contact leak is still reachable on production until
then.

## 9. Rollback

Every replaced file has a `.bak_*` next to it on the VPS (restore + restart).
Dataset rollbacks: `training/*.preB3` (and earlier stage backups) restore the
previous dataset byte-for-byte.

## 10. What is intentionally NOT in this release

- Fastpath rebuild from v29 (Stage E) — happens AFTER your audit + retrain; until
  then the VPS serves the v28-era fastpath.
- KPI delta + follow-up/conversation memory — post-v29 by decision.
- Value-ambiguity chips on not_recognized class/section/subject — v29 candidate.

## 11. Addendum 2026-09-10 — date display rule: dd-mm-yyyy ALWAYS

**School rule:** every date shown to users reads **dd-mm-yyyy**, never yyyy-mm-dd.

**Where the old format came from:** the dataset teaches native date columns (zero
CONVERT display styles), so the ISO look was produced at JSON serialization —
pyodbc `date` objects (local_db mode) and .NET ISO strings (ERP api_wrapper mode).

**The fix (one point, every path):** `backend/main.py` now formats every result
cell at response build (`_fmt_dates_for_display`) — the single place both
`POST /api/chat` and `/api/chat/stream` pass through. Covers fastpath, templates,
LLM, local_db AND api_wrapper. Native dates → `dd-mm-yyyy`; datetimes with a real
time → `dd-mm-yyyy HH:MM:SS`; ISO strings from the ERP API normalized the same
way; midnight times show the plain date.

**Deliberately untouched:** date literals inside SQL (`WHERE PaidDate >=
'2025-06-01'`, GETDATE() math) — internal, execution-verified, never displayed.
Also untouched: admin/feedback diagnostic endpoints (internal tooling).

**Mobile-app note:** date cells in the `rows` payload are now dd-mm-yyyy STRINGS.
If the mobile app parses them as ISO dates, that parsing must switch to
dd-mm-yyyy — flag to the mobile team.

**Tests:** `scripts/test_date_format.py` — 23/23 ALL GREEN; v63 regression suites
re-run green; bundle + audit package rebuilt with the updated main.py.

**Month labels — RESOLVED (owner go 2026-09-10, dataset addendum B4):** the v29
month-bucket trend rows (66 train + 3 val occurrences in 34 rows) now use
`FORMAT(date,'MM-yyyy')` — labels read "06-2025", day-first consistent with this
rule. Backups `train/val_v29.jsonl.preB4`; 59-rule checker re-run after the edit —
classification identical to baseline (3,639+12 train / 319+1 val, zero new
violations); SSMS export regenerated (rev-2 header, 2026-09-10). Month-NAME
buckets (`FORMAT 'MMMM'`, 2 rows) reviewed and left as-is — "June" has no numeric
date order to confuse. The B4 dataset ships in the audit package immediately;
it reaches the VPS with the Stage E fastpath/dataset deploy.

# v98 Release Notes — "Show-Stopper Fixes"
Date: 2026-09-07. Builds directly on v97. Nothing in v97 changes.

## What was wrong (in plain words)

1. **The "top student in 7" bug (Msg 4104).** The model sometimes wrote a
   SQL filter using a nickname (`cm`) it never introduced. Two of our safety
   checkers each thought the OTHER one was checking for that, so the broken
   query went to the school's database and came back as an error the user
   could see. Nobody caught it end to end.
2. **First question after a restart was very slow.** The backend tried to
   "wake up" the AI engine exactly once, at the exact moment the engine was
   still loading (it needs 20-45 seconds). That one attempt failed, and the
   system never tried again — so the first real user waited the full
   30-60 seconds.
3. **One repair lane was missing.** When the school's database rejected a
   query, the backend just showed the error. The local-database mode has had
   an automatic "try to fix it and try again" for a long time; the live
   school-API mode did not.
4. **Mobile app safety net.** A client that sends only the context JSON
   (some mobile builds do) could end up with an empty database name on the
   query, and every question would fail.

## What v98 does about it

- **Fix 1 — the gap is closed.** The alias checker now owns the verdict:
  any nickname that is never defined anywhere in the query is caught
  BEFORE the query is sent. Proven safe: all 4,034 known-good training
  queries still pass with zero new false alarms, and the exact query that
  broke in production is now caught every time.
- **Fix 2 — self-repair.** When a query is caught by the new check, or by
  a business rule, or rejected by the school's database with a SQL-shaped
  error, the backend now asks the model ONCE to fix it, re-checks the fix
  through every safety gate, and only then sends it. If the fix fails any
  gate, the system refuses — exactly as before. Auth or network errors do
  NOT trigger a retry (no wasted time).
- **Fix 3 — warmup retries.** The backend now keeps knocking on the AI
  engine's door every 5 seconds for up to 12 minutes until it answers.
  The first question after a restart is fast again.
- **Fix 4 — one-line insurance** so the database name always falls back to
  the one in the context JSON.

## Safety proof (ran on all 4,034 training + 322 validation queries)

- alias checker: 0 new false alarms (after the fix, 0 flags on all 4,034;
  the intermediate run's 11 flags were false alarms on old-style
  comma-joins — fixed and re-proven)
- branch security gate: 0 new false alarms
- 17 unit tests + 5 end-to-end mock tests: ALL PASS
- full FastAPI app builds; erp_config.json loading unchanged
- Every new behavior has a kill switch:
  `AI_SECRETARY_SEMANTIC_RETRY=0`, `AI_SECRETARY_EXECUTE_RETRY=0`,
  `AI_SECRETARY_WARMUP=0` — set in the systemd environment, restart,
  and v98 behaves exactly like v97.

## v29 dataset prep (for the next retrain — nothing to deploy)

- `training/train_v29.jsonl` (3,656 rows) and `training/val_v29.jsonl`
  (317 rows): trailing semicolons removed from every label (3,851 rows
  fixed); 61 rows dropped that can NEVER execute through the real pipeline
  (DECLARE / multi-statement / write statements).
- `training/v29_CLEANUP_REPORT.md`: the full list of rows that still need
  a human/ERP-team decision — 167 `YEAR(GETDATE())` rows and 373 rows with
  business-rule mismatches. Do NOT auto-fix these; they change query
  meaning and must be verified against the real database.

## How to deploy on the VPS (about 5 minutes)

1. Back up first:
   `sudo cp /opt/chalo-ai-secretary/chalo_chatbot/pipeline/orchestrator.py{,.bak.v97}`
   `sudo cp /opt/chalo-ai-secretary/chalo_chatbot/pipeline/alias_scope_check.py{,.bak.v97}`
   `sudo cp /opt/chalo-ai-secretary/chalo_chatbot/backend/main.py{,.bak.v97}`
2. Copy the 3 changed files from this zip into the same paths
   (overwrite): `pipeline/alias_scope_check.py`, `pipeline/orchestrator.py`,
   `backend/main.py`.
3. Restart: `sudo systemctl restart chalo-backend`
4. Check: `journalctl -u chalo-backend -n 20 --no-pager` — you should see
   normal startup. Ask it "who is the top student in 7 in Term 1?" — even
   if the model writes the bad `cm.` filter again, v98 now catches it,
   repairs it, and answers.
5. Rollback if ever needed: restore the 3 `.bak.v97` files and restart.

## Two users at the same time (VPS-side, no code)

Edit the llama service flags (this is the audit's Part-3 recommendation):

```
sudo systemctl edit chalo-llm --force
```

Paste:

```
[Service]
ExecStart=
ExecStart=/opt/chalo-ai-secretary/llama.cpp/build/bin/llama-server \
  -m /opt/chalo-ai-secretary/chalo_chatbot/models/AISv28-qwen2.5-coder-7b-instruct.Q4_K_M.gguf \
  --host 127.0.0.1 --port 8080 -c 16384 -np 2 -t 6 --cont-batching
```

(Adjust the model path to the real file.) Then:
`sudo systemctl daemon-reload && sudo systemctl restart chalo-llm`

What this means: `-np 2` = two seats at the AI engine so two questions can
be processed at once; `-c 16384` = each seat still gets the full 8,192
memory window it has today; `-t 6` = 6 of the 8 CPU cores (leave 2 for the
rest of the system); `--cont-batching` = serve the two seats smoothly.
Memory check: model ~4.5 GB + KV cache ~1 GB — safe on 16 GB.

Rollback: `sudo systemctl revert chalo-llm && sudo systemctl restart chalo-llm`.

## Answers to your questions

- **Fast path stays ON** — you were right to keep it. Every cached query
  still passes the full safety chain, and with v98 a cached query that
  trips a rule now gets one automatic repair instead of a raw refusal.
  Nothing to change.
- **Key rotation** — agree it is not urgent for the demo; do it before
  going live. It stays the same 2-minute job through erp_config.json.

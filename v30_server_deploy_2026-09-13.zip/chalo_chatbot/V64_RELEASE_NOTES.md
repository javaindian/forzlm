# V64 RELEASE NOTES — Batch A: third-party-audit response (2026-09-10)

Ship the three owner decisions from the audit-response plan as a code-only delta on top
of the deployed-and-clean v63, plus the owner's English-only dataset directive. No model
retrain, no fastpath change, no behavioural regression risk outside the two scoped areas
described below.

> **Rev 9 (2026-09-11, dataset refresh — extremes & tie semantics; MinMark
> confirmed):** `training/train_v29.jsonl` + `training/val_v29.jsonl` refreshed,
> NO code files changed. Owner resolved both items rev 8 left pending:
> (1) MinMark is NOT fixed 35 — it varies per exam (a 100-mark exam may set 35
> or 33; a 20-mark exam converts marks, usually upward to 100) — confirming the
> dataset's existing `smd.Marks < eced.MinMark` design (64 rows, ZERO hardcoded
> 35/33 corpus-wide); (2) "highest and lowest" returns ONLY the two extremes,
> and ties are returned (`TOP 1 WITH TIES`). 10 rows edited (9 train + 1 val):
> train#2325 (highest/lowest collection months) and train#3147 (best/worst
> attendance day) → UNION ALL of two `TOP 1 WITH TIES` branches with an
> `Extreme` label column; train#2486 (highest fee collection AND lowest
> attendance) → ONE best-combined class via `Ranked` CTE rank-sum; train#2042
> (which week had maximum collection) → single `TOP 1 WITH TIES` extreme; six
> per-group `Rn = 1` extremes switched ROW_NUMBER → RANK so rank-1 ties return
> (train#602/#737/#1217/#1976/#3237, val#49). Left alone: train#3471 (per-group
> Top-3 keeps ROW_NUMBER for exactly 3 rows), #1794 streak calc, #258/#845
> ranking phrasings. Every candidate SQL passed ALL FOUR production validators
> before write (59-rule engine, branch gate, alias scope, guardrail); proof:
> 3,939/3,939 clean, branch-gate regression ALL PASS, batch-A 31/31, date-format
> ALL GREEN, alignment sweep zero findings. Bundle: 11 files.

> **Rev 8 (2026-09-11, dataset refresh — third-party sweep reconciled + B3.5):**
> `training/train_v29.jsonl` refreshed, NO code files changed. (a) The
> third-party aggregation/percentage sweep's 4 row fixes were found unapplied
> on disk and re-applied exactly as specified: train#2600 (hostel %) and
> val#226 (salary-vs-collection %) now compute `X * 100.0 / NULLIF(Y, 0)`
> instead of two raw counts; train#1785/#3171 answer "average duration of
> circulars in days" with `AVG(DATEDIFF(DAY, Circular_Date, GETDATE()))` as
> AvgCircularAgeDays instead of a circulars-per-month frequency. (b) B3.5
> Section fitness: 32 per-student GROUP BY lists (B3's classifier treated all
> GROUP BY rows as aggregates) gained AdmissionNo/SectionName via canonical
> `sad.SectionID → SectionMaster` joins + GROUP BY sync — including the
> owner's original "attendance below 75%" case; 189 residue rows documented
> in `training/b35_residue_list.json`. Proof: 3,939/3,939 rows clear the
> tightened 59-rule engine; branch-gate regression (3,927 positives),
> batch-A 31/31, date-format ALL PASS; SSMS export regenerated (rev-5
> header, 0 byte-diffs across 3,939 batches). Bundle: 11 files, md5
> 54b6f9c7107aa8b0a1490b5d9e606b93.

> **Rev 7 (2026-09-10, alignment audit — owner challenge before Stage D):** the
> owner ran "give me all students whose attendance is below 75% with their
> parent contact numbers" and asked where the parent contact numbers were.
> The full investigation found one real rule-engine hole plus 23 dataset rows
> that did not answer their own questions: (1) **PII-001's person-name
> exemption matched ANY `.Name = 'literal'`** — so `SectionMaster.Name = 'B'`
> or an application-status name whitelisted BULK contact lists; tightened to
> person-name columns only (FirstName/LastName/FatherName/…). (2) **21 dataset
> rows** (enquiry/application lists + the absentee-with-contacts row) selected
> `FatherContactNo / MotherContactNo / MobileNo1 / ComMobile / CommunicationEmail`
> in bulk — stripped, per the school's own strict bulk-PII decision of
> 2026-09-09 (contacts for ONE person are still allowed). (3) **37 rows**
> carried contact columns in GROUP BY / ORDER BY without selecting them —
> residue stripped. (4) **3 rows did not answer their own questions**:
> train#123 taught "perfect attendance + scored above 90" with NO attendance
> condition (restored via an absentees NOT-IN subquery); train#900/#2400
> answered "circulars valid for more than 30 days" with an unrelated
> `IsResponseNeeded = 1` filter (replaced with the asked
> `DATEDIFF(DAY, Circular_Date, GETDATE()) > 30`). (5) train#2568/#3128
> promised a "next 7 days" window that no fee table can support (no due-date
> column exists corpus-wide) — questions reworded to the verified semantics
> instead of teaching a silent drop. (6) **The fast-path index pointed at
> `train_v28.jsonl`** — which still contained the original 7-column
> bulk-contact row verbatim, so a fast-path hit served it word-for-word;
> `backend/main.py` now prefers `train_v29.jsonl` (shipped in this bundle,
> growing to **11 files**) with v28 as missing-file fallback. Corpus proof:
> 3,939/3,939 rows clear the TIGHTENED engine; the full Q→SQL alignment sweep
> (numbers/thresholds, entities, PII, residue, count-shapes) reports ZERO
> mismatches; branch-gate/guardrail regression, date-format, repair-budget and
> template suites ALL PASS. Filenames now carry **rev7** (tar) / **rev8**
> (audit package).

> **Deployment status (2026-09-10, same day):** the §7 staged cutover was
> EXECUTED. `AI_SECRETARY_PROMPT_PROFILE=v29` is set in the VPS `backend/.env`
> and the backend restarted — `/api/health` returns `"prompt_profile":"v29"`.
> **Serving now byte-matches the dataset instruction** (2,451 chars, sha
> `528692397793727d`): the serving/training alignment this release staged is in
> effect. For the record: the first flip attempt silently no-op'd because the
> VPS's real `.env` pre-dated v64 and never contained the line, and a
> `sed 's/^VAR=.*/…/'` swap does nothing on a missing line (the code default is
> `expanded`); fixed by delete-then-append + restart. The planned 24–48 h
> `expanded` baseline was **skipped by owner choice** — before/after attribution
> falls back to `audit_trail` rows split at the flip timestamp (earlier rows =
> expanded era, later rows = v29 era). Rollback is unchanged: flip the env back
> + restart. No app code changed in this step; the deploy tar stays rev 6.

> **Rev 6 (2026-09-10, owner renewed the rotation report):** the owner re-reported
> chips not rotating and asked to be taken at their word. Rev 6 supersedes the
> rev-5 "stale tab" diagnosis with a code fix — the real gap: rotation state
> lived ONLY in memory (the planned localStorage persistence was dropped in
> implementation), so every page reload silently reset the window to a fresh
> shuffle. chat.html rev-6: state (order + offset + pool fingerprint) persisted
> under `ux_chip_rotation_v1` and RESTORED on the next visit; changed pools
> reject the stale state; one-time console marker (`[chalo] chip rotation
> ACTIVE — … (chat v64 rev-6)`) + hover counter ("Suggestion set k of 5") make
> the running build visible at a glance. The simulation now also proves the
> reload-restore and pool-change cases. Filenames now carry **rev6**.

> **Rev 5 (2026-09-10, same-day follow-up):** + `frontend/audit.html` (9 files).
> Owner report after deploying rev 4: the audit PAGE showed `sql_source` nowhere,
> while the CSV export had it — because the page only showed it inside expanded
> detail (and only via `pipeline_trace`). audit.html v2.2 now shows a blue
> `src: …` marker on every server-tab row line and an unconditional `sql_source`
> row in the expanded detail (matches the CSV column). Chip rotation itself was
> PROVEN correct (extracted-function simulation, `scripts/test_chip_window_sim.js`):
> the rev-4 "no rotation" report was a stale browser tab — reload the page. The
> owner's live SSMS check confirmed `UserAccountRoleDetails` = {BranchID, ID,
> IsPrimary, RoleID, StaffID, UserID} — **no IsSuperUser** — so the guardrail
> catalog is correct as-is; the regression suite's synthetic shapes were cleaned
> to match the real DB (no corpus/runtime impact). Filenames now carry **rev5**.

## 1. What changed, file by file (9 files)

| # | File | Change |
|---|------|--------|
| 1 | `pipeline/schema_knowledge.py` | New **named `v29` prompt profile** — b64-embedded, byte-identical to the instruction stamped on the v29 dataset rows (2,451 chars, sha256 `528692397793727d`). `VALID_PROFILES = (legacy, expanded, v29)`. **NOT active by default**: env pin stays `expanded` (owner Decision 1, staged cutover). Drift alarm: stored sha must equal the dataset's canonical instruction sha. |
| 2 | `pipeline/value_resolver.py` | **Sections fallback (owner Decision 2):** when a school's Sections vocab is EMPTY (nothing configured in DB), VALIDATE now accepts 1–3 char alphanumeric section literals (`A`, `7a`, `B`) instead of refusing — this was 7/8 of the audit's VALIDATE refusals. When the vocab is NON-empty, strict matching stays: a 'North/South/Blue/Red' school must never silently accept a wrong guess. Other concept types untouched. |
| 3 | `pipeline/guardrail.py` | **Scoping-subquery select-list check (owner review, 2026-09-10)** — closes the #1 live failure class (19 production `Branch_Id` execute errors, 83% of live failures). Every bare column selected by a UARD / Branch_Academic_Details subquery is validated against that table's real columns; refusal hints the real name ("did you mean 'BranchID'?") and feeds retry-with-hint. Zero false positives on the full 3,939-row corpus. See §3. |
| 4 | `backend/security.py` | **`sql_source` promoted to a first-class `audit_trail` column** (was buried inside the `pipeline_trace` JSON). Fresh DBs get it in the CREATE TABLE; pre-existing DBs are migrated lazily via a PRAGMA check + `ALTER TABLE` (safe to re-run). `log_audit()` takes `sql_source=` and falls back to extracting it from `pipeline_trace`. |
| 5 | `backend/main.py` | The chat-path `log_audit` call now passes `sql_source=result.sql_source` — every row written from v64 onward carries the answer's origin (`dataset_exact` / `template` / `llm` / `llm_retry_*`) in its own column, so the staged prompt cutover is cleanly attributable in audit queries. `audit.html` + CSV export already render this column. |
| 6 | `frontend/chat.html` | **Chips rotate after every answer** (owner UX ask) — rev-6 hardened: `pickChips()` builds a shuffled order + sliding window, persisted to localStorage (`ux_chip_rotation_v1`, order + offset + pool fingerprint) so a reload RESTORES the window instead of silently reshuffling; `rotateChips()` — called from the shared post-answer hook `absorbResult()` — advances the window by 6, so the next 6 never overlap the previous 6 (cycle every 5 answers, 30 pool / 6 visible); a changed server pool rejects the stale saved state; console marker + hover "set k of 5" counter self-identify the running build. |
| 7 | `ux_config.json` | 4 pool chips replaced: 1 English phrasing mismatch ("...there in class 10?" → dataset phrasing) + 3 chips that WERE the just-removed Hinglish questions. Pool is now **30/30 exact dataset questions, no duplicates**. |
| 8 | `backend/.env.example` | NEW — documents the 3 behaviour switches: `AI_SECRETARY_TOTAL_BUDGET=90`, `AI_SECRETARY_PROMPT_PROFILE=expanded` (staged-cutover pin), `AI_SECRETARY_FAST_PATHS=0` (protects live traffic until Stage E rebuilds the fastpath from cleaned v29). Copy values into the real `.env`; do not overwrite it with the example. |
| 9 | `frontend/audit.html` (rev 5) | **v2.2 — `sql_source` made visible on the page** (owner report: CSV had it, page hid it). Row lines now show a blue `src: dataset_exact`-style marker; the expanded detail has an unconditional `sql_source` row (first-class DB column; pre-deploy rows show `—`). Filter box already matches `sql_source`. |

## 2. The English-only dataset (owner directive, same day)

`scripts/remove_hinglish_v29.py` scanned the `input` field only (output SQL never touched):
Devanagari block + a curated, unambiguous Hinglish lexicon; every Tier-B candidate was
human-reviewed; `lakh` and `mile` were deliberately kept (Indian-English unit / English
word — false-positive risk).

- **train_v29.jsonl: 3,651 → 3,622** (29 removed) · **val_v29.jsonl: 320 → 317** (3 removed)
- Backups: `training/*.prehinglish` · Removed rows archived: `download/hinglish_removed_rows.jsonl` + `hinglish_removal_summary_10-09-2026.csv`
- The v29 profile sha pins only the 2,451-char instruction — the purge does NOT invalidate it
- `sql_ssms/*.sql` regenerated (rev-3 header) from the cleaned set: 3,939 batches

## 3. The branch-scoping hardening: gate frozen, GUARDRAIL extended (corrected)

**Correction (2026-09-10, after the owner's review):** the original text of this section
claimed a "ground-truth review proved" the existing layers already handle the
wrong-column linkage class. The owner tested that claim directly against the 19 real
production queries that caused the live `Branch_Id` execute errors: **19/19 passed BOTH
the gate and the shipped guardrail, unmodified** — and a corpus-wide mutation test
confirmed it (all 3,927 trained UARD rows mutated to `SELECT Branch_Id FROM
UserAccountRoleDetails`: 3,924/3,927 still passed the guardrail). The justification was
factually wrong and is retracted. The original 5 regression shapes only covered linkages
that are absent or decorative — not the actual bug: **a linkage that is present and
genuinely used as a filter, but whose subquery selects a column that does not exist on
its own table.**

What was done about it (owner option B — the gate file itself stays frozen per task
spec):

- `pipeline/guardrail.py` — NEW scoping-subquery **select-list check**
  (`_scoping_subquery_issues`, wired into `validate_sql()`): every bare column selected
  by a `UserAccountRoleDetails` / `Branch_Academic_Details` subquery is validated against
  THAT table's real columns. This is exactly the hole: the reference is unqualified (the
  alias.column check skips it) and the bare-column check is skipped for multi-table
  queries / unioned with boilerplate columns (`Branch_Id` is REAL on
  `Branch_Academic_Details`, so it passed everywhere). The refusal names the fix
  ("did you mean 'BranchID'?"), which flows into the existing retry-with-hint machinery
  and the audit trail — the diagnostic detail these 19 failures were missing.
- Post-fix proof: mutated corpus **0/3,927** pass; original corpus unchanged (same 4
  pre-existing catalog quirks, zero new false positives — incl. the 220 legitimate
  `Branch_Id`-on-Branch_Academic_Details rows and the 3,927 trained UARD rows);
  multi-real-table production-class shape refused; identical query with real `BranchID`
  passes.
- The regression suite now has the owner-requested **6th case family**: 6
  wrong-column select-list shapes must be REFUSED, the real-column variants must PASS,
  and the standalone check must stay clean across the full corpus (0 hits).

Security note (unchanged and still true): a nonexistent column always fails closed at
SQL execution, so this class never leaked data — it produced user-facing errors (83% of
live failures). The fix is about correctness and diagnosability, and it lives in the
correct layer.

## 4. Verification performed before packaging

- `scripts/verify_batch_a_v64.py` — 31 checks: profile sha + round-trip via `build_system_prompt('v29')`, env default still `expanded`, dataset counts + zero Devanagari + zero Hinglish tokens, 30/30 chips exact-match, fresh-DB + migrated-DB audit round-trips, all call-sites, `py_compile` × 4, `node --check` on chat.html
- `test_branch_gate_regression.py` (extended): gate + repair + **guardrail select-list check** — 3,927 UARD positives, 5 gate hallucination shapes, **6 wrong-column select-list shapes refused / real-column variants pass / 0 corpus false positives**, `test_date_format.py` (23/23), `test_v63_template_in8.py`, `test_v63_repair_budget.py` — ALL GREEN
- Corpus mutation proof: all 3,927 UARD rows mutated to `Branch_Id` → **0 pass** the fixed guardrail (was 3,924 pre-fix); original corpus failure set byte-identical to baseline (4 known catalog quirks)
- Batch B stamping: `stamp_instruction_batch_b.py` — 136/136 stamped (128 train + 8 val), inputs/outputs byte-identical to `.prestamp` backups, idempotent re-run clean

## 5. Deploy (VPS)

```bash
tar -xzf chalo_v64_update_2026-09-10_rev5.tar.gz -C /tmp/v64
cp /tmp/v64/backend/main.py           /path/to/chalo_chatbot/backend/
cp /tmp/v64/backend/security.py       /path/to/chalo_chatbot/backend/
cp /tmp/v64/backend/.env.example      /path/to/chalo_chatbot/backend/   # reference only
cp /tmp/v64/pipeline/schema_knowledge.py /path/to/chalo_chatbot/pipeline/
cp /tmp/v64/pipeline/value_resolver.py   /path/to/chalo_chatbot/pipeline/
cp /tmp/v64/pipeline/guardrail.py        /path/to/chalo_chatbot/pipeline/
cp /tmp/v64/ux_config.json            /path/to/chalo_chatbot/
cp /tmp/v64/frontend/chat.html        /var/www/chalo/
cp /tmp/v64/frontend/audit.html       /var/www/chalo/   # rev 5
chown -R www-data:www-data /path/to/chalo_chatbot /var/www/chalo
# restart the backend service (systemd/supervisor as configured)
```

The `audit_trail` migration runs automatically on the first audit write after restart
(plain SQLite `ALTER TABLE`, no manual step). Serving behaviour is UNCHANGED until the
env-flip in §7.

## 6. Rollback

Restore the 9 files from the v63 state and restart. The `sql_source` column is additive
and harmless to older code (extra column ignored; INSERTs from v63 don't reference it —
actually v63's INSERT lists its columns explicitly, so it is fully compatible both ways).

## 7. Staged prompt cutover (owner Decision 1) — runbook for LATER

1. **Now → +24–48 h:** serve `expanded` exactly as today. This is the baseline.
2. **Cutover:** set `AI_SECRETARY_PROMPT_PROFILE=v29` in the backend environment, restart. Zero code change.
3. **Attribution:** `SELECT sql_source, outcome, COUNT(*) FROM audit_trail GROUP BY 1,2` before/after the flip — the profile change is visible as a clean point-in-time event, not diffed into a code deploy.
4. **Rollback:** flip back to `expanded` (or `legacy`) + restart. Nothing else to revert.

## 8. Not in this release (by design)

- Stage E fastpath rebuild from cleaned v29 (then `AI_SECRETARY_FAST_PATHS=1`) — stays 0
- Kaggle retrain on 3,622/317 (Batch C; after Stage D third-party audit)
- FeeTerms empty-vocab fallback: deliberately NOT added — the audit flagged only Sections;
  scope stays as approved
- Self-learning fastpath go/no-go (owner decision pending, post-v29)

# ChaloSchools AI Secretary — Complete Project Record
## From "I have a school ERP" to End-to-End Verified

---

## 1. The Beginning

The project started with: *"I have a school ERP. I am building a chatbot for the management. We have administration, admissions, general enquiries, fees, examinations, inventory, staff, student, circulars, home works, communication, payroll, transport, parent feedback modules. I have db schema and stored procedures that we use. Nothing else..."*

## 2. What the User Brought

- School ERP: 15 modules, 475 tables, 8,685 columns, 1,095 stored procedures
- Training dataset: JSONL format, syntactically correct but semantically unverified
- Model: Qwen 2.5 Coder 7B Instruct (to be fine-tuned)
- Pipeline: already built (initial version)
- LLM runtime: llama.cpp on Windows

## 3. The Initial Problems

- Coverage gaps, hallucinations, latency
- Semantic correctness (SQL syntactically valid but wrong)
- RBAC not verified
- Fee term vs exam term confusion
- "Like this so many problems are there"

## 4. Phase 1: Audit & Blindspot Discovery

- Schema deep dive: 475 tables, 15 modules documented
- SP mining: 1,095 SPs extracted and categorized
- Training dataset audit: found HIGH-severity violations
- 7 schema-level gotchas identified (BusFeeStrucure misspelling, ExamTermMaster column names, etc.)
- Artifacts: DATA_DICTIONARY.md (526 KB), semantic_validation/, BLINDSPOT_AUDIT.md, GUIDELINES.md

## 5. Phase 2: The 32 Semantic Rules

32 rules in `pipeline/semantic_rules.py` checking every SQL before execution:
- FEE (11): wrong formulas, missing filters, wrong date windows
- EXAM (6): wrong joins, wrong columns
- STUDENT (4): nonexistent columns, missing AcademicYearID
- STAFF (2), ADMISSION (2), DEPRECATED (2), SECURITY/RBAC (4), TRANSPORT (1), STRUCTURE (2)

## 6. Phase 3: Pipeline Hardening

9 stages: CONTEXT → INJECT → EXTRACT → GENERATE → GUARDRAIL → VALIDATE → SEMANTIC → BIND → EXECUTE
- Branch scoping gate, alias scope check, prompt injection defense
- Input sanitization, generic prod errors, LLM timeout, rate limiting, truncation guard
- Vocab engine: synonyms.json (9 concept types, two-layer design)

## 7. Phase 4: Model Training (v27)

- Kaggle fine-tune (~4h on T4 x2) → Colab GGUF export (~30min)
- Q4_K_M quantization, 2560 token context (set for training, not inference)
- Known limitations: ignores named sections, sometimes picks wrong table, label noise

## 8. Phase 5: Windows Local Testing & Packaging

- 5 batch files created + hardened (5 rounds: ASCII, parens, redirects, !)
- Folder reorganization (frontend/, scripts/, docs/)
- bun → npm, .env.example + requirements.txt created
- Draw.io diagrams (4) + HTML viewers
- User's paths pre-filled in start_llm.bat

## 9. Phase 6: End-to-End Bug Fixes (5 bugs + TOP-N)

1. Bind stage rejects unused security params → silently drop
2. School's API error hidden → surface in message field
3. chat.html missing 3 fields → added api_wrapper_url, target_database, model_url
4. School's API fails on repeated @placeholders → use_inline_params=True
5. .env not auto-loaded → python-dotenv
6. TOP-N pagination (duplicate rows) → skip pagination for TOP queries

**Result:** "how many students in 10 a?" → StudentCount = 32

## 10. Phase 7: Option 1.5 + Multi-Tenancy + UI

- Option 1.5: question_extractor.py (pre-LLM entity extraction, ~5ms)
- 1brainy patches added then REVERTED (user: "no workarounds henceforth")
- Audit trail: Reset + Export XLSX + multi-tenancy (target_database column)
- Branch dropdown (multi-branch UI support, "All my branches" option)

## 11. Phase 8: Codebase Analysis Toolkit

- 3 extraction scripts (models, LINQ, constants) + LLM analyzer + test (46 checks)
- Tested against 7,440 C# files: 3,736 models, 2,534 relationships, 29,309 columns
- PRIMITIVE_TYPES fix (long/string/int not treated as navigation properties)
- Intelligent summarization for large codebases
- Honest finding: raw extracts > LLM analysis for 7B model

## 12. Architectural Decisions

1. **Option 1.5 over agents** — agents too slow on CPU, need cloud (privacy)
2. **No Graphiti** — school data is already structured, not unstructured
3. **Shared schema multi-tenancy** — all tenants use V3_CHALO, one model serves all
4. **use_inline_params=True** — workaround for school's API bug
5. **No workarounds for named sections** — fix the API (Option B)
6. **Fast paths OFF** — training label noise, clean dataset first
7. **Keep 7B, don't switch to 3B** — 3B lacks reasoning capacity for complex queries
8. **CTX_SIZE 2560 is training constraint** — can safely increase to 4096 for inference
9. **System prompt expansion** — the #1 accuracy fix available without retrain

## 13. Dev Team Asks

1. Fix ExecuteQuery API (repeated @placeholders)
2. Fix GetUserContext API (Sections: [])
3. SQL Profiler trace (optional)

## 14. Pending Features

1. Disclaimer in chat.html ("AI can make mistakes...")
2. LLM model selector dropdown (CLM 1.0 current, 2.0/3.0 disabled)
3. Show thinking process (configurable show/hide)
4. Standard reply for unanswerable questions (configurable)
5. System prompt expansion (waiting for codebase extracts)
6. CTX_SIZE increase to 4096 (inference only)
7. v28 model retrain (section-scoped examples, cleaned labels)
8. GPU acceleration (--n-gpu-layers 99)
9. Fast paths enablement (clean dataset first)

## 15. Key Metrics

| Metric | Value |
|--------|-------|
| Database tables | 475 |
| Semantic rules | 32 |
| Pipeline stages | 9 |
| API endpoints | 9 |
| C# files scanned | 7,440 |
| Entity models found | 3,736 |
| End-to-end result | StudentCount = 32 |
| Final zip size | 2.3 MB |

## 16. v97 (2026-09-07) — ERP settings consolidated into ONE file

**Trigger:** recurring question "what do I edit when the ERP team changes
the GetUserContext/ExecuteQuery URL or key?" — the v96 hardening had left
these values hardcoded in four different places (config.yaml was already
gone). v97 keeps the hardening but restores a single point of change.

**New files:**
- `erp_config.json` (project root) — the ONE file: `get_user_context_url`,
  `execute_query_url`, `tenant_api_keys` (per-school map), `use_inline_params`.
  Holds the real key — keep it `chalo:chalo` mode `600` on the VPS.
- `erp_config.py` (project root) — loader. Resolution order for every
  setting: erp_config.json → environment variable → built-in fallback.
  A corrupt JSON raises loudly instead of silently using stale values.
- `docs/ERP_CONFIG_GUIDE.md` — the change runbook (all cases: rotate key,
  change URL, add V3_GG, flip inline-params; verify steps; error table).
- `V97_RELEASE_NOTES.md` — release summary + VPS deploy steps.

**Changed files:**
- `pipeline/user_context_api.py` — URL/key resolution now asks erp_config
  first; the hardcoded key was REMOVED from `TENANT_API_KEY_MAP` (empty
  fallback map kept for old deploys).
- `backend/security.py` — `_load_tenant_keys()` reads erp_config first,
  then `AI_SECRETARY_TENANT_KEYS`; the hardcoded default key was REMOVED.
- `backend/main.py` — ExecuteQuery URL comes from erp_config (the chat-UI
  value is only a legacy fallback); `use_inline_params` switch read from
  erp_config instead of hardcoded `True`; both error messages now point
  to erp_config.json.
- `frontend/chat.html` — URL field default emptied (server decides).
- Docs: README, STRUCTURE + 13 docs/*.md got a v97 callout;
  `backend/.env.example` notes the env vars are fallbacks now.

**Verification:** all four Python files compile; smoke test passed —
erp_config getters, security key lookup via erp_config, user_context_api
`_ERP` wiring, corrupt-JSON loud failure, and a full FastAPI app build.

**Deploy:** copy 6 files to the VPS (see V97_RELEASE_NOTES.md), chmod 600
erp_config.json, `sudo systemctl restart chalo-backend`, ask one question.

**Rollback:** the .bak files created during deploy restore v96 behaviour
byte-for-byte; or delete erp_config.json — built-in fallbacks take over.

---

## 17. 2026-09-09 / 2026-09-10 — v63 quick-wins, Stage B3, v29 dataset final, audit package

**Trigger:** the owner's UAT audit + five considerations (intent understanding,
similar-question handling, "in 8" vs "class 10" fastpath gap, total-cycle time
limit, chip rotation), then column-fitness rules and the third-party audit request.

**Engine / code (no retrain needed):**
- `pipeline/template_lookups.py` — bare-number class pattern (`in|for|from|of` + N)
  + filler-tolerant template keys + single-SQL collision guard. "How many students
  are in 8" now answers in 1–3 s instead of >1 min (root cause: the phrase matched
  no template pattern → fell to the LLM with up to 4–5 stacked corrective retries).
- `pipeline/orchestrator.py` — `_auto_repair_branch_id` fixes the model's
  `Branch_Id` → `BranchID` on UserAccountRoleDetails at all 6 generation points
  (11 of the UAT EXECUTE errors were exactly this typo); `AI_SECRETARY_TOTAL_BUDGET`
  (default 90 s, owner-approved) checked before every retry — when exhausted the bot
  replies honestly with chips instead of failing late.
- `backend/main.py` — `max_tokens` 512 → 768 (512 truncated complex SQL → refuse);
  per-call `AI_SECRETARY_LLM_TIMEOUT` stays 45 s (the budget caps the cycle).
- `ux_config.json` + `frontend/chat.html` v12 — `suggested_questions_visible = 6`,
  pool 8 → 30 (each verified: v28 fastpath instant + 59-rule clean + v29 clean),
  6 rotate at random per page load.

**Dataset — Stage B3 column fitness (owner rules: per-student records always carry
admission number + class + section; no marks in non-marks questions; no raw IDs
where a name exists; centum-holders LIST = admno + name + class + section +
subjects, no marks):**
- 407 per-student lists detected; 390 edited (360 train / 30 val) with schema-driven
  join injection; raw-ID → name swaps; UNION arms edited per-arm.
- 22 documented residue exceptions (14 pre-admission applicants, 8 no safe class
  link) in `training/b3_residue_list.json`; 3 centum-holder LIST teaching rows added.
- Every edit re-verified through the 59-rule engine; invariants I7–I10 ALL GREEN;
  backups `*.preB3`.

**Final v29 numbers:** 3,651 train / 320 val — checker-clean at 59 rules,
parens balanced, 0 duplicate questions.

**Deliverables:** `chalo_v63_update_2026-09-09.tar.gz` (10-file VPS bundle) and
`chalo_v29_audit_package_2026-09-09.zip` (app with masked secrets + rules +
dataset + `sql_ssms/` SSMS batches + memory: `V29_MEMORY.md`, `DECISIONS.md`,
`SEMANTIC_RULES_59.md`, `README_AUDIT.md`) — the owner audits with a third party
BEFORE the Kaggle retrain.

**Docs refreshed 2026-09-10:** README, STRUCTURE, PROJECT_STATUS,
SESSION_HANDOFF, training/README, API_CONTRACT, HOW_IT_WORKS, GUIDELINES, PRD,
OCI_DEPLOYMENT — stale rule counts, dataset numbers, token/timeout facts corrected;
`V63_RELEASE_NOTES.md` added.

**Deploy:** 10-file bundle (see V63_RELEASE_NOTES.md §8) — ⚠ until deployed,
PII-001 (bulk contact block) is NOT live on the VPS.

**Still open:** owner deploy + third-party audit (Stage D) → Stage E (prompt
freeze, fastpath rebuild from v29, 15-question acceptance) → Kaggle retrain →
post-v29 (KPI delta, follow-up memory, self-learning fastpath decision).

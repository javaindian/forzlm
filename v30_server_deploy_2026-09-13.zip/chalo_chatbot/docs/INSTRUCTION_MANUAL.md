# ChaloSchools AI Secretary — Instruction Manual

**Version:** 1.1.3
**Last updated:** 2026-09-03
**Audience:** three teams — Infra, Dev, Admin. Each section is self-contained.

---

# Table of Contents

1. [Infra Team Instructions](#part-1--infra-team-instructions)
2. [Dev Team Instructions](#part-2--dev-team-instructions)
3. [Admin Instructions](#part-3--admin-instructions)

---

# Part 1 — Infra Team Instructions

**Your role:** deploy and maintain the OCI infrastructure, nginx, WAF, and secrets. You don't touch the application code.

## 1.1 What you're deploying

Three services on OCI (same region as the ChaloSchools DB):

| Service | What | Where | Port |
|---|---|---|---|
| nginx | TLS termination, rate limiting, security headers, WAF integration | Public subnet | 443 (HTTPS) |
| FastAPI backend | The AI Secretary API service | Same instance (or adjacent) | 8000 (localhost) |
| llama.cpp | The LLM (Qwen 2.5 Coder 7B) | Private subnet (or same instance for cheapest) | 8080 (private) |

The mobile app hits nginx (443). nginx proxies to the backend (8000). The backend calls the LLM (8080) + the school's ExecuteQuery API.

## 1.2 What to do — step by step

### Step 1: Create the VCN + subnets

1. OCI Console → Networking → Virtual Cloud Networks → Create VCN.
   - Name: `ai-secretary-vcn`
   - CIDR: `10.0.0.0/16`
   - Create two subnets:
     - `public-subnet` (10.0.1.0/24) — with an Internet Gateway.
     - `private-subnet` (10.0.2.0/24) — with a NAT Gateway (for outbound updates), NO Internet Gateway.

### Step 2: Configure security lists

**Public subnet security list:**
- Ingress: TCP 443 from 0.0.0.0/0 (mobile app HTTPS)
- Ingress: TCP 22 from your office IP (SSH admin)
- Egress: TCP 8080 to 10.0.2.0/24 (→ the LLM)
- Egress: TCP 443 to 0.0.0.0/0 (→ ExecuteQuery API or the DB)

**Private subnet security list:**
- Ingress: TCP 8080 from 10.0.1.0/24 (← the API instance only)
- Ingress: TCP 22 from your office IP
- Egress: TCP 443 to 0.0.0.0/0 (OS updates)

### Step 3: Launch the compute instance

1. OCI Console → Compute → Instances → Create Instance.
   - Name: `ai-secretary-api`
   - Shape: **VM.Standard.E4.Flex** (AMD EPYC, AVX2)
   - OCPUs: 8
   - Memory: 24 GB
   - Image: Oracle Linux 9 (or Ubuntu 22.04)
   - Subnet: `public-subnet`
   - SSH key: your public key
2. (Optional, for two-instance setup) Launch a second instance `ai-secretary-llm` in the `private-subnet` with the same shape.

### Step 4: Store secrets in OCI Vault

> **v97 update (2026-09-07):** All ERP connection settings — GetUserContext URL, ExecuteQuery URL, per-school API keys, and the use_inline_params switch — now live in ONE file: `erp_config.json` at the project root. Edit it and restart the backend; no code changes. Full runbook: `docs/ERP_CONFIG_GUIDE.md`. The rest of this section describes the pre-v97 method and is kept for history.
> For current steps, follow `docs/ERP_CONFIG_GUIDE.md` instead.

1. OCI Console → Security → Vaults → Create Vault.
   - Name: `ai-secretary-vault`
   - Create a master encryption key.
2. Create these secrets:
   | Secret name | Value | Used for |
   |---|---|---|
   | `auth-tokens` | `user-token-abc123,...` (comma-separated) | Mobile app auth |
   | `admin-tokens` | `admin-token-xyz789,...` | Admin config UI auth |
   | `tenant-keys` | `V3_TestDatabase:<real-key-see-erp_config.json>,V3_GG:...` | ExecuteQuery API keys per tenant |
   | `db-password` | (if using local_db mode) | DB connection |
3. Create a cloud-init script that fetches these secrets at boot and writes them to `/etc/ai-secretary/env` (environment file for the systemd service).

### Step 5: Install nginx + configure TLS

```bash
sudo dnf install nginx
sudo systemctl enable nginx

# Get a TLS cert (use OCI Certificates or Let's Encrypt with certbot)
sudo certbot certonly --nginx -d chatbot.chaloschools.in
```

Copy the nginx config from `docs/OCI_DEPLOYMENT.md` §6 to `/etc/nginx/conf.d/ai-secretary.conf`. Edit the `server_name` and certificate paths. Test: `sudo nginx -t`. Start: `sudo systemctl start nginx`.

### Step 6: Deploy the backend

```bash
# Clone the repo
cd /opt
git clone <your-repo-url> ai-secretary
cd ai-secretary/chalo_chatbot/backend

# Install dependencies
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Create the systemd service
sudo tee /etc/systemd/system/ai-secretary.service << 'EOF'
[Unit]
Description=ChaloSchools AI Secretary API
After=network.target

[Service]
Type=simple
User=ai-secretary
WorkingDirectory=/opt/ai-secretary/chalo_chatbot/backend
EnvironmentFile=/etc/ai-secretary/env
ExecStart=/opt/ai-secretary/chalo_chatbot/backend/venv/bin/uvicorn main:app --host 127.0.0.1 --port 8000
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable ai-secretary
sudo systemctl start ai-secretary
```

### Step 7: Deploy the LLM (llama.cpp)

```bash
# On the LLM instance (or the same instance for single-instance setup)
cd /opt
git clone https://github.com/ggerganov/llama.cpp
cd llama.cpp
make  # or cmake

# Download the GGUF model (your trained model)
# Place it at /opt/llama.cpp/models/qwen25coder_chaloschools_v27.gguf

# Create the systemd service
sudo tee /etc/systemd/system/llama-cpp.service << 'EOF'
[Unit]
Description=llama.cpp LLM Server
After=network.target

[Service]
Type=simple
ExecStart=/opt/llama.cpp/llama-server -m /opt/llama.cpp/models/qwen25coder_chaloschools_v27.gguf --host 127.0.0.1 --port 8080 --ctx-size 2560
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl enable llama-cpp
sudo systemctl start llama-cpp
```

### Step 8: Configure the WAF

1. OCI Console → WAF → Create WAF Policy.
2. Attach to the load balancer in front of the API instance.
3. Enable the OWASP preconfigured ruleset (Top 10 protections).
4. Enable rate limiting: 100 requests/minute per IP.
5. Enable threat intelligence feeds.

### Step 9: Verify

```bash
# From outside OCI:
curl https://chatbot.chaloschools.in/api/health
# Expected: {"status":"ok","pipeline_loaded":true,"rules_count":32,"version":"1.1.0"}

# Check security headers:
curl -I https://chatbot.chaloschools.in/api/health
# Expected: HSTS, X-Content-Type-Options, X-Frame-Options, CSP headers present.
```

## 1.3 What NOT to do

- **Do NOT deploy the Next.js dev UI to production.** It's a local testing tool (`src/app/LOCAL_TEST_UI_README.md`). Deploy only the FastAPI backend.
- **Do NOT expose the LLM (port 8080) to the public internet.** It should be reachable only from the backend (private subnet or localhost).
- **Do NOT store secrets in `.env` files on the PRODUCTION server.** Use OCI Vault. The `.env` file is for LOCAL DEV on your laptop ONLY — never deploy it to the server.
- **Do NOT use `*` for CORS origins in production.** Set `AI_SECRETARY_CORS_ORIGINS` to the explicit allowed origins (or leave empty for native mobile apps — they don't need CORS).
- **Do NOT skip the WAF.** It's defense-in-depth; the backend's parameterized binding is the primary defense, but the WAF catches the common patterns.
- **Do NOT use the default auth tokens (`dev-token-please-change-in-prod`).** Generate long random strings and store them in Vault.
- **Do NOT run the backend as root.** Create a dedicated `ai-secretary` user.

## 1.4 Troubleshooting

| Symptom | Check | Fix |
|---|---|---|
| `curl /api/health` returns nothing | Is nginx running? Is the backend running? | `sudo systemctl status nginx` → `sudo systemctl status ai-secretary` |
| `pipeline_loaded: false` | A Python import failed | `journalctl -u ai-secretary -n 50` → look for the ImportError |
| `rules_count: 0` | The semantic rules module didn't load | Same — check the journal |
| LLM returns "Connection refused" | Is llama.cpp running? | `sudo systemctl status llama-cpp` → check if the GGUF exists |
| 502 Bad Gateway | nginx can't reach the backend (port 8000) | Is the backend running? `curl http://127.0.0.1:8000/api/health` from the instance |
| 429 Too Many Requests | Rate limit hit | Wait 60s; or increase `AI_SECRETARY_RATE_LIMIT_IP` if legitimate traffic |
| TLS cert expired | Let's Encrypt cert is 90 days | `sudo certbot renew` → `sudo systemctl reload nginx` |
| High CPU (sustained) | The LLM is under load | Check concurrent connections; consider adding a second LLM instance |
| Disk full | The audit_trail.db or logs grew | `du -sh /opt/ai-secretary/chalo_chatbot/backend/audit_trail.db` → vacuum or archive |

## 1.5 Maintenance

### Daily (automated)
- **Log rotation:** nginx logs + the backend journal rotate automatically (systemd's journald).
- **Health monitoring:** set up an OCI alarm that pings `/api/health` every minute. Alert if non-200 or `status: "degraded"`.

### Weekly
- **Audit trail backup:** `sqlite3 audit_trail.db ".backup '/backup/audit_trail_$(date +%Y%m%d).db'"` → copy to OCI Object Storage.
- **Log review:** `journalctl -u ai-secretary --since "1 week ago" | grep ERROR` → review any errors.

### Monthly
- **Dependency CVE scan:** `pip-audit` on the backend's venv. If any CVEs, update `requirements.txt` and re-deploy.
- **nginx config review:** check for config drift (did someone edit the config without documenting it?).
- **Vault key rotation:** rotate the auth tokens + admin tokens + tenant API keys. Update the Vault secrets; restart the backend.

### On each model update (v28, v29, etc.)
1. Upload the new GGUF to the LLM instance.
2. Update the systemd service to point to the new GGUF path.
3. `sudo systemctl restart llama-cpp`.
4. No backend change needed — the backend doesn't care which model the LLM serves.

### On each backend update (code change)
1. `cd /opt/ai-secretary && git pull`
2. `source venv/bin/activate && pip install -r requirements.txt`
3. `pip-audit` (verify no new CVEs)
4. `sudo systemctl restart ai-secretary`
5. `curl https://chatbot.chaloschools.in/api/health` → verify `status: "ok"`

---

# Part 2 — Dev Team Instructions

**Your role:** develop, test, and deploy the application code (the backend, the pipeline, the semantic engine, the vocab engine, the training data). You don't touch OCI infrastructure.

## 2.1 What you're developing

The codebase has three layers:

```
chalo_chatbot/
├── backend/          ← the API service (FastAPI + VAPT hardening)
│   ├── main.py       ← the API endpoints + rate limiting + auth
│   ├── security.py   ← V4/V5/V7/V9/V10/V11 fixes
│   └── audit_trail.db ← the audit log
├── pipeline/         ← the inference pipeline (17 modules, ~6,000 LOC)
│   ├── orchestrator.py     ← the conductor (11 stages)
│   ├── semantic_rules.py   ← the 32-rule semantic engine
│   ├── context.py          ← @AcademicYearID injection (D1.3)
│   ├── value_resolver.py   ← validate-and-substitute (F6)
│   ├── guardrail.py        ← schema existence + sensitive blocklist
│   ├── llm_client.py       ← TruncationError guard (D1.8)
│   ├── parameter_binder.py ← parameterized binding
│   ├── api_executor.py     ← the ExecuteQuery API path
│   └── ... (see docs/HOW_IT_WORKS.md for every file)
├── vocab/            ← the vocab engine
│   ├── inject.py     ← STOPGAP + FULL modes
│   └── synonyms.json ← 9 concept types, hand-curated
├── evaluation/       ← the accuracy harness
│   ├── golden_questions.json ← 50 questions (20 novel)
│   ├── scoring.py    ← 4-axis scoring
│   └── evaluate.py   ← the runner
├── semantic_validation/ ← the training-data gate
│   ├── prepare_data.py    ← gated (refuses if HIGH > 0)
│   ├── semantic_rules.py  ← synced with pipeline/
│   └── validate_dataset.py
└── docs/             ← 16 documentation files
```

## 2.2 What to do — daily workflow

### Easiest way to run on Windows (one click)

If you're on Windows, **double-click `START_HERE.bat` in the project root**. It:
1. Opens a window and starts the LLM (port 8080).
2. Opens a second window and starts the backend (port 8000) — auto-creates `.venv`, installs `backend\requirements.txt`.
3. Opens your browser at `frontend/chat.html` (with a backend health check first).

You don't need to manually run any of the commands below — `START_HERE.bat` does them for you. The commands below are for **Mac/Linux** or for **manual control** on Windows.

### Setting up the dev environment (Mac/Linux, or manual on Windows)

```bash
# Clone the repo
git clone <repo-url> ai-secretary
cd ai-secretary/chalo_chatbot

# Create a virtual env
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r backend/requirements.txt  # fastapi, uvicorn, pydantic, python-dotenv, requests, pyodbc

# === LOCAL DEV ONLY — do NOT do this on the production server ===
# Copy the env template (for your laptop's local testing)
cp backend/.env.example backend/.env
# Edit .env: set AI_SECRETARY_AUTH_TOKENS + AI_SECRETARY_ADMIN_TOKENS to dev values
# (For PRODUCTION, use OCI Vault instead — never create a .env on the server)
# (NOTE: backend/main.py now auto-loads backend/.env via python-dotenv on startup,
#  so you don't need to source the env file before starting uvicorn.)

# Start the backend (for local testing)
cd backend
uvicorn main:app --host 0.0.0.0 --port 8000 --reload

# In another terminal, start the Next.js dev UI (for local testing)
cd frontend/nextjs-ui
npm install     # one-time
npm run dev
# → open http://localhost:3000
```

### Running the semantic validation (before any training data change)

```bash
cd semantic_validation
python3 validate_dataset.py
# → output/report.html (interactive triage report)
# → output/violations.csv (per-example)
# → output/summary.md (aggregate)
```

### Running the accuracy harness (before any model change)

```bash
cd evaluation
python3 evaluate.py --model-url http://localhost:8080/v1/chat/completions \
    --context-json sample_context.json --branch 1
# → output/scores.csv + output/summary.md
```

### Running the security self-test

```bash
cd backend
python3 security.py
# → tests V4 (tenant keys), V5 (audit logging), V7 (prompt injection), V9 (input sanitization), V10 (error surface)
```

### Running the semantic engine self-test

```bash
cd pipeline
python3 semantic_rules.py
# → tests 13 cases (known-wrong + known-correct SQL)
```

## 2.3 What to do — when adding a new semantic rule

1. Open `pipeline/semantic_rules.py`.
2. Write a function `r_yourrule(sql, q, tables) -> Optional[Violation]`. Return `None` if the rule doesn't apply; return a `Violation` with `suggested_fix` if it fires.
3. Add the function to the `RULES` list at the bottom of the file.
4. Add metadata to `RULE_META` (`rule_id` → `{title, catalog_ref}`).
5. Add a self-test case to the `if __name__ == "__main__"` block.
6. Run `python3 semantic_rules.py` → verify the self-test passes.
7. Sync the file to `semantic_validation/semantic_rules.py`.
8. Run `python3 validate_dataset.py` → verify the new rule fires on the expected examples (and doesn't over-fire).
9. Update `docs/PRODUCTION_TRACE_OBSERVATIONS.md` if the rule came from a production trace.

**Example rule (the simplest one):**
```python
def r_fee014(sql, q, tables):
    if "FeesInformationStudentDetail" not in tables: return None
    if "bus fee" not in q.lower(): return None
    if not _has(sql, r"IsBusFee\s*=\s*1"):
        return Violation("FEE-014", "HIGH",
            "Bus-fee query omits IsBusFee = 1 filter.",
            "Add AND f.IsBusFee = 1 to restrict to bus-fee rows only.", "Fees")
    return None
```

## 2.4 What to do — when updating the training data (v28 retrain)

1. **Clean the existing labels:** run `python3 semantic_validation/validate_dataset.py` → triage the flagged examples in `output/report.html` → fix the SQL for each real bug → re-run until flag rate < 5%.
2. **Add new training examples:** for the coverage gaps (bonafide, pre-admission, report cards, exam mark entry, rank generation, fee head vs group, messages, not-entered patterns, compare patterns — per `docs/PRODUCTION_TRACE_OBSERVATIONS.md` §6).
3. **Update `prepare_data.py`'s `FROZEN_SYSTEM_PROMPT`** if the instruction is changing (per `docs/INSTRUCTION_IMPROVEMENT.md`). For FULL vocab mode, prepend the vocab block.
4. **Run `prepare_data.py`:** it validates every example, refuses if HIGH > 0, then splits into train/val.
5. **Train:** use the §F parameters (r=16, dropout 0.05, lr 1e-4, warmup 35, MAX_SEQ_LENGTH 2560, epochs 2). See the training notebook.
6. **Export:** q5_k_m quantization (avoid double-4-bit). See the export notebook.
7. **Evaluate:** run the accuracy harness. v28 must beat v27 on all 4 axes.
8. **Deploy:** upload the GGUF to the LLM instance; restart llama-cpp. Flip `inject_vocab: true` in config if using FULL mode.

## 2.5 What NOT to do

- **Do NOT change the frozen system prompt at runtime without retraining.** The v27 model derails on prompt changes (confirmed twice). Any prompt change requires a retrain.
- **Do NOT enable `fast_paths` in production until the 480 flagged examples are cleaned.** Fast-paths replay training SQL verbatim; 12.4% is buggy.
- **Do NOT enable `inject_vocab` without the v28 retrain.** The v27 model can't handle a vocab block (derails).
- **Do NOT ship a model without running the accuracy harness.** `eval_loss` measures next-token prediction, not semantic correctness. The 50 golden questions are the gate.
- **Do NOT add a dependency without running `pip-audit`.** Check for CVEs first; pin the version in `requirements.txt`.
- **Do NOT concatenate user input into SQL.** All values go through parameterized binding (`sp_executesql` or the inline-escaped fallback). Never `f"WHERE x = '{user_input}'"`.
- **Do NOT skip the semantic engine in the pipeline.** `semantic_rules_enabled=True` must always be on in production. It's the defense against semantic bugs.
- **Do NOT log the Context JSON to the audit trail.** It contains user identity + branch permissions. Log only user_id + branch_id, not the full Context JSON.
- **Do NOT commit secrets to the repo.** Auth tokens, API keys, DB passwords go in `.env` (LOCAL DEV on your laptop) or OCI Vault (PRODUCTION on the server), never in code or committed to git.

## 2.6 Troubleshooting

| Symptom | Check | Fix |
|---|---|---|
| Backend won't start | Import error | `python3 -c "from main import app"` → look for the ImportError |
| `pipeline_loaded: false` | A pipeline module didn't import | Check `sys.path` includes `pipeline/` and `vocab/` |
| LLM returns empty/garbled | Wrong model URL or model not loaded | `curl http://localhost:8080/v1/models` → verify the model is served |
| Semantic engine doesn't fire | `semantic_rules_enabled` is False | Check the orchestrator's constructor; must be True in prod |
| Validate-and-substitute doesn't rewrite | Synonym store didn't load | Check `vocab/synonyms.json` exists; check the SynonymStore path |
| Guardrail passes everything | Schema catalog didn't load | Check `schema_catalog.json` path; the guardrail loads from CWD |
| `prepare_data.py` gate fails | HIGH violations > 0 | Run `validate_dataset.py` → fix the flagged examples → re-run |
| Accuracy harness shows regression | The model changed something | Compare v27 vs v28 on the same 50 golden Qs; check which questions regressed |
| Prompt injection not caught | The sanitizer pattern is missing | Add the pattern to `INJECTION_PATTERNS` in `security.py` |

## 2.7 Maintenance

### On each code commit
1. Run `python3 backend/security.py` → verify V4/V5/V7/V9/V10 pass.
2. Run `python3 pipeline/semantic_rules.py` → verify all self-tests pass.
3. Run `npm run lint` (if you changed the Next.js UI) → verify ESLint clean.
4. Run `pip-audit` → verify no new CVEs.
5. Document the change in the relevant doc (`PROJECT_STATUS.md`, `SESSION_HANDOFF.md`, or the specific doc for the area).

### On each model version (v28, v29, etc.)
1. Run the accuracy harness (50 golden Qs) → record the scores.
2. Compare against the previous version → no regressions.
3. Update `PROJECT_STATUS.md` with the new version + scores.
4. Update the golden questions if new failure modes are discovered.

### On each semantic rule addition
1. Add the rule (per §2.3).
2. Re-run `validate_dataset.py` → verify the flag count.
3. Update `docs/VAPT_READINESS.md` if the rule affects security.
4. Update `docs/PRODUCTION_TRACE_OBSERVATIONS.md` if the rule came from a production trace.

## 2.8 Pending UI/UX features (added 2026-09-03 — DOC-UPDATE-5)

These 4 items were requested by the project owner on 2026-09-03 and are **not yet implemented**. They're listed here so the dev team picks them up in the next sprint. Full descriptions are in `docs/PROJECT_STATUS.md` §4.6 and `docs/SESSION_HANDOFF.md` (2026-09-03 update).

| # | Item | Where | Effort |
|---|---|---|---|
| 1 | **AI disclaimer in `chat.html`** — a subtle footer note: *"AI can make mistakes. Please verify important information."* | `frontend/chat.html` (HTML/CSS only) | Small |
| 2 | **LLM model selector dropdown** — three options: **Chalo Language Model 1.0** (current, selected by default), **CLM 2.0** (disabled — coming soon), **CLM 3.0** (disabled — coming soon). Maps to a different GGUF path in `scripts/start_llm.bat` or a different `model_url` in the request body. | `frontend/chat.html` → Settings panel | Medium |
| 3 | **Configurable "show thinking process" toggle** — show pipeline stages progressively ("Understanding your question...", "Generating SQL...", "Validating against 32 rules...", "Querying the database..."). Toggle in Settings; default OFF. Needs backend SSE/streaming (today the trace is returned only at the end). | `frontend/chat.html` + `backend/main.py` (StreamingResponse) + `pipeline/orchestrator.py` (yield stage events) | Medium-large |
| 4 | **Standard reply for unanswerable questions (configurable)** — when `outcome ∈ {REFUSED, ERROR, NEEDS_DISAMBIGUATION}`, show a single admin-configurable message in the user-facing `message` field. Default: *"I'm sorry, I couldn't answer that question. Please try rephrasing it, or ask a different question."* Configurable via `AI_SECRETARY_FALLBACK_MESSAGE` env var in `backend/.env` or a new key in `backend/feature_overrides.json`. The raw `detail` + `semantic_violations` stay in the response body for debugging. | `backend/main.py` + `backend/.env` (or `feature_overrides.json`) | Small-medium |

**Suggested order:** 1 → 2 → 4 → 3 (smallest to largest). Items 1 and 2 are pure frontend. Item 4 is small backend. Item 3 is the largest because it requires streaming stage events from the orchestrator through the backend to the frontend.

## 2.9 Pending accuracy improvements (added 2026-09-03 — DOC-UPDATE-5)

Two non-code, non-retrain accuracy improvements were identified on 2026-09-03:

1. **System prompt expansion** — the current system prompt is one paragraph (~80 tokens). The plan is to expand it to ~2 pages (~1,000-1,500 tokens) covering the 7 schema gotchas, top 5 business formulas, top 10 mandatory filters, key JOIN patterns, and critical enum values. This is the **#1 accuracy lever without retraining or dev-team help**. Status: PENDING — waiting for the user to paste 4 small extracts (top filters, enums, hub tables, raw SQL) from the codebase-analysis toolkit output so the prompt can be built from real data. See `docs/INSTRUCTION_IMPROVEMENT.md` for the v28 retrain variant.

2. **CTX_SIZE bump** — the `CTX_SIZE=2560` in `scripts/start_llm.bat` is a TRAINING constraint (Claude set it to prevent silent truncation of training sequences — the longest example was ~1,750 tokens). At INFERENCE time, the context window is independent; Qwen 2.5 Coder 7B's base model natively supports 32K tokens. **Decision:** bump inference `--ctx-size` from 2560 → **4096** (not 8192 — that might degrade attention on CPU). This unlocks the 2-page system prompt above. Going 2560 → 4096 adds ~3-4 seconds of latency (acceptable: 15-35s → 18-39s on CPU). The `--ctx-size 2560` lines in the systemd `ExecStart` examples in §1.2 Step 7 (and in `docs/COMPLETE_GUIDE.md` §2.2) should also be updated to 4096 when this change goes in. **The two changes (prompt expansion + CTX_SIZE bump) go together.**

---

# Part 3 — Admin Instructions

**Your role:** manage the chatbot's configuration (feature flags, auth tokens, monitoring). You don't touch code or infrastructure.

## 3.1 What you manage

| What | How | How often |
|---|---|---|
| **Feature flags** (24 toggles) | `PUT /api/admin/features` | When you want to enable/disable a feature |
| **Auth tokens** | Ask the infra team to rotate in OCI Vault | Monthly, or after a security incident |
| **Tenant API keys** | Ask the infra team to add in OCI Vault | When a new school/tenant onboards |
| **Monitoring** | Check `/api/health` + the audit trail | Daily (or set up an alert) |
| **The model version** | Ask the dev team to deploy a new GGUF | When v28 (or later) is ready |

## 3.2 What to do — managing feature flags

The chatbot has 24 feature flags (the brainstorm ideas + future features). All are **OFF by default**. You flip them on/off via the admin API.

### To view the current flags

```bash
curl -H "Authorization: Bearer <admin-token>" \
     https://chatbot.chaloschools.in/api/admin/features
```

**Response:**
```json
{
  "flags": {
    "auto_chart": false,
    "insight_cards": false,
    "feedback_loop": true,
    ...
  },
  "descriptions": {
    "auto_chart": "Auto-chart result tables (mobile-app rendering)",
    ...
  }
}
```

### To enable a feature

```bash
curl -X PUT -H "Authorization: Bearer <admin-token>" \
     -H "Content-Type: application/json" \
     -d '{"flags": {"auto_chart": true}}' \
     https://chatbot.chaloschools.in/api/admin/features
```

### To disable a feature

```bash
curl -X PUT -H "Authorization: Bearer <admin-token>" \
     -H "Content-Type: application/json" \
     -d '{"flags": {"auto_chart": false}}' \
     https://chatbot.chaloschools.in/api/admin/features
```

### The 24 flags (what each does)

| Flag | Description | Implemented? |
|---|---|---|
| `auto_chart` | Auto-chart result tables | v1.1 (mobile-app) |
| `insight_cards` | 1-3 auto-generated insight cards | v1.2 (second LLM call) |
| `trend_comparison` | This-year-vs-last-year auto-add | v1.1 |
| `drill_down` | Tappable rows → follow-ups | v1.1 |
| `morning_briefing` | Scheduled 6am insights + push | v1.3 (scheduler + push) |
| `anomaly_alerts` | Nightly anomaly detection + push | v1.3 |
| `you_might_also_ask` | 3 follow-up suggestions | v1.1 (rule-based) |
| `hinglish_tamil` | Bilingual mode | v28 retrain |
| `school_jargon` | Jargon glossary in the prompt | v28 |
| `voice_input` | STT integration | v1.2 (mobile-app) |
| `why_this_answer` | "Why this answer?" expandable | v1.1 |
| `capability_card` | "What I can/can't answer" page | v1.0 (static) |
| `share_qa` | Deep-link sharing | v1.2 |
| `pin_questions` | Pin frequent questions | v1.1 |
| `schedule_questions` | Scheduled queries + push | v1.3 |
| `feedback_loop` | Thumbs up/down on every answer | v1.1 (logging ready; UI pending) |
| `question_clustering` | Weekly clustering report | v1.3 |
| `active_learning` | Chatbot asks admin for help | v2.0 |
| `multi_school_benchmark` | Cross-branch comparison | v1.1 (super-user) |
| `parent_mode` | Parent-facing | v2.0 (parent RBAC) |
| `teacher_mode` | Teacher-facing | v1.2 (class-teacher RBAC) |
| `confidence_score` | Green/amber dot on every answer | v1.1 |
| `source_sp` | Show the SP the query is based on | v1.2 |
| `audit_trail` | Show audit trail in admin UI | v1.1 (table is always logged) |

**Important:** flipping a flag on does NOT immediately add the feature. The flag is a **governance layer** — it tells the backend "this feature is allowed." The feature's code must be implemented (by the dev team) for the flag to have an effect. Flags marked "v1.1+" are not yet implemented; flipping them on today does nothing (the backend ignores unimplemented flags).

### What to do when a feature is implemented (by the dev team)

1. The dev team tells you: "feature X is ready; flip the flag on."
2. You call `PUT /api/admin/features` with `{"flags": {"X": true}}`.
3. The change takes effect immediately (no restart needed).
4. The mobile app receives `features_enabled: ["X"]` in the next `/api/chat` response and renders the feature.

## 3.3 What to do — monitoring

### Daily health check

```bash
curl https://chatbot.chaloschools.in/api/health
# Expected: {"status":"ok","pipeline_loaded":true,"rules_count":32,"version":"1.1.0"}
```

If `status: "degraded"` or the response is empty → contact the infra team.

### Reviewing the audit trail

The audit trail logs every chatbot question + outcome. To review recent activity:

```bash
# On the server (ask the infra team for access, or set up a simple admin endpoint)
sqlite3 /opt/ai-secretary/chalo_chatbot/backend/audit_trail.db \
  "SELECT timestamp, user_id, question, outcome, latency_ms FROM audit_trail ORDER BY id DESC LIMIT 20;"
```

Or, **easier:** open `frontend/audit.html` in a browser, paste your admin token, and click Load — see the audit trail as a paginated table with dashboard stats (total / answered / refused / error counts + avg latency + last-7-days count + refused-by-stage breakdown).

What to look for:
- **High `ERROR` rate:** if many queries are ERROR, the LLM or the DB may be down.
- **High `REFUSED` rate:** if many queries are REFUSED, check the `semantic_violations` — a new rule may be over-firing.
- **Prompt injection attempts:** `outcome = 'REFUSED'` and `stage = 'security'` → someone tried to inject.
- **Unusual question patterns:** a spike in fee queries may indicate a new fee-collection cycle; a spike in attendance queries may indicate a reporting deadline.

### Exporting the audit trail to Excel (XLSX)

In `frontend/audit.html`, click the green **Export XLSX** button (top of the page). It:

1. Fetches ALL rows (respecting the current outcome filter, up to 100,000 rows).
2. Downloads them as an Excel `.xlsx` file via SheetJS (loaded from the CDN).
3. **Falls back to CSV** if you're offline (SheetJS not loaded) — the CSV still opens in Excel.
4. Filename includes the date + row count (e.g. `audit_trail_2026-08-31_482rows.xlsx`).

This is the easiest way to share a month's worth of audit data with the dev team (for v28 training-data triage) or with the compliance team.

### Resetting (clearing) the audit trail

In `frontend/audit.html`, click the red **Reset** button (top of the page). It:

1. Shows a confirmation dialog telling you how many rows will be deleted + reminding you to "Export XLSX first if you want a copy."
2. If you confirm, calls the new `DELETE /api/audit` endpoint (admin-only).
3. Returns `{"status":"ok","message":"Audit trail cleared. 0 row(s) remaining."}`.

This is useful for resetting the audit trail after a long testing session (so the next batch of user questions starts from a clean slate) or for clearing out stale data from a previous model version. **Cannot be undone — export first if you want a copy.**

### Setting up an alert (via the infra team)

Ask the infra team to set up an OCI alarm that:
- Pings `/api/health` every minute. Alert if non-200.
- Alerts if the `ERROR` rate in the audit trail exceeds 20% in any 10-minute window.
- Alerts if any `REFUSED` at `stage = 'security'` (prompt injection) occurs.

## 3.4 What to do — when a new school/tenant onboards

1. The dev team adds the tenant's `DBPrefix` + API key to `TENANT_API_KEYS` (via OCI Vault env var: `AI_SECRETARY_TENANT_KEYS`).
2. The infra team restarts the backend (to load the new env var).
3. The new school's users log into the mobile app → the mobile app fetches their Context JSON from `GetUserContext` → sends it to the chatbot → the chatbot scopes to their branch.
4. No admin action needed (the tenant key is server-side; the mobile app never sees it).

## 3.5 What to do — when a model update is ready

1. The dev team says: "v28 is trained + evaluated + ready."
2. The infra team uploads the new GGUF to the LLM instance + restarts llama.cpp.
3. You verify: `curl https://chatbot.chaloschools.in/api/health` → still `status: "ok"`.
4. (If using FULL vocab mode) You flip `inject_vocab: true` via the admin API — no, this is a backend config, not a feature flag. Ask the dev team to update the config.
5. Test a few questions via the mobile app → verify the answers are correct.

## 3.6 What NOT to do

- **Do NOT share the admin token.** It controls the feature flags. If it leaks, an attacker can disable security features or enable unimplemented features.
- **Do NOT flip on features marked "v1.1+" or "v2.0".** They're not implemented yet. Flipping them on does nothing today, but it may cause confusion ("I turned on auto_chart but nothing happened").
- **Do NOT flip on `hinglish_tamil` until the v28 retrain is done.** This flag changes the prompt; the v27 model will derail.
- **Do NOT delete the audit_trail.db.** It's the compliance record + the debugging log. Back it up, don't delete it.
- **Do NOT try to edit the code or the nginx config yourself.** That's the dev team / infra team's job. You manage the flags + the monitoring.
- **Do NOT use the user auth token for admin operations.** The admin token is separate (`AI_SECRETARY_ADMIN_TOKENS`). The user token can't access `/api/admin/features`.

## 3.7 Troubleshooting

| Symptom | What to check | Who to contact |
|---|---|---|
| The chatbot doesn't answer at all | `/api/health` — is the status "ok"? | Infra team (LLM or backend down) |
| The chatbot answers but the SQL is wrong | The audit trail — check the `outcome` + `semantic_violations` | Dev team (semantic rule or training gap) |
| The chatbot refuses everything | The audit trail — check if a new rule is over-firing | Dev team (rule tuning) |
| A feature flag doesn't take effect | Is the feature implemented? (check the table in §3.2) | Dev team (if it should be implemented) |
| `401 Unauthorized` on the admin API | Is the admin token correct? Was it rotated? | Infra team (check OCI Vault) |
| `403 Forbidden` on the admin API | You're using a user token, not an admin token | Use the admin token |
| Prompt injection alert | The audit trail — check `stage = 'security'` | No action needed (the system caught it); log the attempt |

## 3.8 Maintenance

### Monthly
- **Rotate the admin token.** Ask the infra team to update `AI_SECRETARY_ADMIN_TOKENS` in OCI Vault + restart the backend.
- **Review the audit trail.** Export the last month's logs; look for patterns (most-asked questions, most-refused questions, injection attempts).
- **Review the feature flags.** Are all enabled features still wanted? Disable any that aren't pulling their weight.

### Quarterly
- **Review the accuracy harness scores.** Ask the dev team to re-run the 50 golden Qs against the current model. If scores dropped, the model may need a retrain.
- **Review the dev team asks** (`docs/DEV_TEAM_ASKS.md`). Are any resolved? Any new ones?

---

# Appendix — Quick Reference

## A. The three services + ports

| Service | Port | What | Who manages |
|---|---|---|---|
| nginx | 443 (HTTPS) | TLS, rate limit, headers, WAF | Infra |
| FastAPI backend | 8000 (localhost) | The API service | Dev |
| llama.cpp | 8080 (private) | The LLM | Infra (deploys) / Dev (model) |

## B. The API endpoints

| Endpoint | Method | Auth | Purpose |
|---|---|---|---|
| `/api/health` | GET | None | Health check (public) |
| `/api/chat` | POST | User token | Run a question through the pipeline |
| `/api/branches` | POST | User token | List branches (for the picker) |
| `/api/validate` | POST | User token | Validate a SQL query (debug) |
| `/api/admin/features` | GET | Admin token | View feature flags |
| `/api/admin/features` | PUT | Admin token | Update feature flags |
| `/api/audit` | GET | Admin token | Fetch audit-trail rows (paginated, optional `outcome` filter) |
| `/api/audit/stats` | GET | Admin token | Aggregate audit stats (counts, avg latency, refused-by-stage) |
| `/api/audit` | DELETE | Admin token | Clear ALL audit-trail rows (used by the audit.html **Reset** button; cannot be undone) |

**Total: 9 endpoints (4 user + 5 admin/audit).**

## C. The env vars (set by the infra team in OCI Vault)

| Var | Purpose | Set by |
|---|---|---|
| `AI_SECRETARY_AUTH_TOKENS` | User auth tokens (comma-separated) | Infra |
| `AI_SECRETARY_ADMIN_TOKENS` | Admin auth tokens | Infra |
| `AI_SECRETARY_TENANT_KEYS` | `DBPrefix:apikey` pairs | Infra (from dev team) |
| `AI_SECRETARY_CORS_ORIGINS` | Allowed CORS origins | Infra |
| `AI_SECRETARY_DEBUG` | `true` for debug mode (shows real errors); `false` for prod | Infra |
| `AI_SECRETARY_LLM_TIMEOUT` | LLM timeout in seconds (default 45) | Infra |
| `AI_SECRETARY_RATE_LIMIT_IP` | Per-IP rate limit (default 100/min) | Infra |
| `AI_SECRETARY_RATE_LIMIT_TOKEN` | Per-token rate limit (default 20/min) | Infra |
| `AI_SECRETARY_AUDIT_DB` | Path to the audit DB | Infra |
| `AI_SECRETARY_FEATURE_OVERRIDES` | Path to the feature overrides file | Infra |

## D. The documentation map (read in this order)

| When you're... | Read this |
|---|---|
| New to the project | `docs/HOW_IT_WORKS.md` |
| The mobile-app team | `docs/API_CONTRACT.md` |
| The infra team | `docs/OCI_DEPLOYMENT.md` + this doc (Part 1) |
| The dev team | `docs/HOW_IT_WORKS.md` + this doc (Part 2) |
| The admin | this doc (Part 3) + `docs/ADMIN_CONFIG_UI.md` |
| Preparing for VAPT | `docs/VAPT_READINESS.md` |
| Investigating a failure | `docs/PRODUCTION_TRACE_OBSERVATIONS.md` + the audit trail |
| Planning the v28 retrain | `docs/INSTRUCTION_IMPROVEMENT.md` + `docs/PRODUCTION_TRACE_OBSERVATIONS.md` |
| Want to know what's improved | `docs/IMPROVEMENTS_VS_AISEC.md` |
| Want the full picture | `docs/GUIDELINES.md` (the single source of truth, 735 lines) |

# ERP Config Guide (v97) — the ONLY file you ever touch

**File:** `erp_config.json` (project root, next to `erp_config.py`)
**Golden rule:** edit it → `sudo systemctl restart chalo-backend` → done.
No code edits. No chat-UI edits. Nothing else.

---

## 1. What is inside the file

| Field | Meaning | Change when... |
|---|---|---|
| `get_user_context_url` | GetUserContext endpoint (who you are, school, role) | ERP team moves the GetUserContext endpoint |
| `execute_query_url` | ExecuteQuery endpoint (runs the SQL) | ERP team moves the ExecuteQuery endpoint |
| `tenant_api_keys` | One API key per school database, e.g. `"V3_TestDatabase": "..."` | ERP team rotates a key, or you add a new school (V3_GG) |
| `use_inline_params` | `true` = values are inlined into the SQL text (current workaround for the ERP's repeated-`@placeholder` bug) | ONLY when the ERP team confirms the placeholder bug is fixed → set `false` |

Lines starting with `_` (like `_README`) are comments. The app ignores them.
Never print, email, or commit the key values. On the VPS the file must stay
`chalo:chalo`, mode `600`.

---

## 2. Change recipe (all cases)

```bash
# On the VPS
cd /opt/chalo-ai-secretary/chalo_chatbot
sudo cp erp_config.json erp_config.json.bak.$(date +%Y%m%d-%H%M%S)
sudo nano erp_config.json          # make the change
sudo systemctl restart chalo-backend
```

Then verify — ask ONE question in the chat UI:

```bash
sudo journalctl -u chalo-backend -n 30 --no-pager
```

You want: no stack trace, and the question returns rows as before.

### Case A — key rotated (most common)
Edit the value inside `tenant_api_keys` for that database. Restart. Done.

### Case B — URL changed
Edit `get_user_context_url` and/or `execute_query_url`. Restart. Done.

### Case C — new school / new database
Get the key from the ERP team (they use
`SELECT AISecretaryApiKey FROM chalov3common.dbo.SchoolMaster` for the
school's row). Add a new line inside `tenant_api_keys`:
`"V3_GG": "<paste key>"`. Restart. Done.

### Case D — ERP fixed the @placeholder bug
Set `"use_inline_params": false`. Restart. Then test carefully (see §5).
If anything fails, set it back to `true` and restart — zero harm done.

---

## 3. How the app reads it (priority order)

For every setting, first non-empty wins:

1. `erp_config.json` ← you edit here
2. Environment variable (`USER_CONTEXT_API_URL`, `EXECUTE_QUERY_API_URL`,
   `ERP_USE_INLINE_PARAMS`, `AI_SECRETARY_TENANT_KEYS`) ← testing escape hatch only
3. Built-in fallback URLs (the old v96 values) — so even with the file
   missing, the app boots; but with no key set, queries fail with a clear
   error telling you to fix `erp_config.json`.

A corrupt `erp_config.json` (bad JSON) makes the backend refuse to start
quietly — it raises a clear error naming the file. Fix the JSON, restart.

If both the json and an env var define the SAME database key, the json wins.

---

## 4. Error messages you may see (and what they mean)

| Message in journal / UI | Cause | Fix |
|---|---|---|
| `No tenant API key found for 'X'` | database not in `tenant_api_keys` | add it (Case C) |
| `erp_config.json ... is not valid JSON` | typo, missing comma/quote | fix JSON, restart |
| ERP replies `Invalid API key for the specified tenant` | rotated/wrong key | Case A |
| `Mode is 'api_wrapper' but no ExecuteQuery URL` | both json and request empty | set `execute_query_url` (Case B) |

## 5. Verifying a `use_inline_params` flip (Case D)

1. Restart with `false`, ask one simple question ("how many students in class 10?").
2. Then ask one that hits branch scoping (any question as a logged-in user).
3. Both return rows → keep `false`. Any SQL error from the ERP → back to `true`, restart.

## 6. Windows laptop

Nothing special: `erp_config.json` ships in the project root and
`erp_config.py` finds it relative to itself, whatever the working directory
is. Edit the file, restart the backend window, refresh the browser.

---

*v97 (2026-09-07): replaced the v96 arrangement where the key was hardcoded
in `backend/security.py` (L39) and `pipeline/user_context_api.py` (L102),
the GetUserContext URL in `user_context_api.py` (L77), and the
use_inline_params switch in `backend/main.py` (L378). Those code places are
now empty fallbacks. config.yaml was already gone since the v96 hardening.*

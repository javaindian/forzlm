# ChaloSchools AI Secretary — Session Handoff

**Session:** web-84e3a3b5-2d4c-4178-b2c9-938f5a3091e9
**Date:** 2026-08-27
**From:** Z.ai Code (the AI assistant)
**To:** the next session / the next developer / the project owner

This file captures everything needed to resume work on the ChaloSchools AI Secretary project. Read this first.

---

## 0. Handoff update — 2026-09-10 (current state; everything below is history)

**Where the project actually is today:**

1. **v29 dataset generation is DONE.** 3,622 train / 317 val (English-only: the
   2026-09-10 Batch A purge removed 32 Hinglish/Hindi questions; originals in
   `training/*.prehinglish`), checker-clean at the
   **59-rule** engine (rule history: 32 → 54 on 2026-09-04 → 58 → 59 on 2026-09-09).
   Every build stage and edit is logged in `training/v29_BUILD_REPORT.md`. Stage B3
   "column fitness" landed last: 390 per-student lists edited to always carry
   AdmissionNo + StudentName + Class + Section, raw-ID exposure removed, marks dropped
   from non-marks lists, 3 centum-holder LIST teaching rows added, 22 documented residue
   exceptions (`training/b3_residue_list.json`).
2. **Quick-win batch built (no retrain needed)** — see `V63_RELEASE_NOTES.md`:
   bare-number class templates ("how many students are in 8" now instant),
   Branch_Id→BranchID auto-repair, `AI_SECRETARY_TOTAL_BUDGET` = 90 s total-cycle
   budget (owner-approved max wait), `max_tokens` 512→768, chips visible = 6 rotating
   from a 30-question fastpath-verified pool.
3. **Deliverables waiting for the owner:** `chalo_v64_update_2026-09-10_rev5.tar.gz`
   (9-file VPS deploy bundle: v63 delta + audit.html v2.2, rev 5 = 2026-09-10 same-day
   follow-up) and `chalo_v29_audit_package_2026-09-10_rev5.zip`
   (app + rules + English-only dataset + SSMS SQL + memory) for the owner's THIRD-PARTY
   audit. (v63 deployed clean 2026-09-10 — PII-001 closed; rev-4 v64 deployed 2026-09-10;
   rev-5 adds audit.html sql_source visibility — owner deploys 1 extra file.)
4. **v64 (Batch A, 2026-09-10) — audit response shipped:** `v29` prompt profile in code
   (byte-identical to the dataset instruction, sha 528692397793727d) with serving STAYING
   on `expanded` — cutover is a later env-flip + restart after a 24–48 h baseline;
   Sections fallback only when the vocab is empty; `sql_source` as a real `audit_trail`
   column; chips rotate after every answer. **Owner-review corrections (same day):**
   the guardrail now REFUSES scoping subqueries that select a wrong column
   (`Branch_Id` on UserAccountRoleDetails — the class behind 19 live execute errors;
   0 false positives on the 3,939-row corpus), and **all 136 rows that were missing the
   `instruction` field are stamped** (P0-A closed; dataset Kaggle-ready). Gate file
   itself stays frozen per task spec. See `V64_RELEASE_NOTES.md` §3.
5. **Next steps in order:** owner deploys v64 bundle → 24–48 h baseline under
   `expanded` → env-flip to `v29` + restart (zero-code change) → third-party audit
   (Stage D: SSMS execution of `sql_ssms/*.sql` + dataset review) → Stage E (rebuild
   fastpath from cleaned v29, 15-question acceptance + phrasing variants, then
   `AI_SECRETARY_FAST_PATHS=1`) → Kaggle retrain (~6–8 h) → post-v29 items (KPI delta,
   follow-up memory, self-learning fastpath go/no-go).
6. **Decisions log:** every owner decision to date is in the audit package's
   `memory/DECISIONS.md` (ParentName = parent person name — do not touch; 90 s max
   wait; 6 chips; build-both-tracks redundancy; centum list = admno + name + class +
   section + subjects, no marks; per-student records always carry admno/class/section).

Everything from here down describes the 2026-08-27 → 2026-09-07 sessions and is kept
as history.

---

## 1. What this session accomplished

### Audit phase (rounds 1-5)
- Read every file in `aisec.zip`'s `app_layer/` (~4,600 LOC, 20 Python files) before the upload folder was cleared.
- Produced a 5-round blindspot audit (`BLINDSPOT_AUDIT.md`, ~800 lines) covering: pipeline architecture, RBAC, hallucination vectors, latency, coverage, training-data quality, and the section-concept problem.
- Proved the fee/exam-term bug's root cause directly in the schema (round-1), then from the training data (round-3: 0 JOIN bugs, it's a missing-pattern failure), then from a live trace (round-4).
- Diagnosed three confirmed failing examples: "fee outstanding of current term" (inference-time generalization gap), "who is the principal" (training-coverage gap + hallucinated `Principal_ID`), "who teaches maths in 8A" (branch uses ability-stream sections, not A/B/C).
- Mined 78 semantic rules from the 1,095 stored procedures (`semantic_rules_catalog.md`).
- Audited the training parameters (round 4): `MAX_SEQ_LENGTH = 2560` is safe for v27 + Option A (real tokenizer confirmed), LoRA overfitting direction is inconsistent, `eval_loss` is necessary but insufficient.

### Build phase (Batch 1 + Batch 2 + mobile-app split)
- **Batch 1:** the 32-rule semantic engine (`semantic_rules.py`), the vocab engine (`vocab/inject.py` + `synonyms.json`), the accuracy harness (`evaluation/`), the pipeline reconstruction (`pipeline/` — 17 files, 6,137 LOC, with 8 fixes: F6 validate-substitute, D1.3 @AcademicYearID, D1.5 retry re-check, D1.8 truncation guard, D1.9 fast-path gating, D1.11 connection pool, D1.2/D1.6 sensitive blocklist, D1.13 FEE_TERM).
- **Batch 2:** the FastAPI backend (`backend/main.py`, mobile-app-facing, Bearer auth, OpenAPI spec), the Claude.ai-style Next.js chat UI (`src/app/page.tsx`, 875 LOC, ESLint clean), the API contract (`docs/API_CONTRACT.md`).
- **Mobile-app split:** separated the production backend (mobile-app-facing) from the local-test web UI (dev only). Added Bearer auth to all endpoints except `/api/health`. Marked the Next.js UI as dev-only in `src/app/LOCAL_TEST_UI_README.md`.

### Documentation
- 10 markdown files totaling ~3,500 lines: `HOW_IT_WORKS.md`, `API_CONTRACT.md`, `IMPROVEMENTS_VS_AISEC.md`, `PRD.md`, `PROJECT_STATUS.md`, `SESSION_HANDOFF.md` (this file), plus the pre-existing `GUIDELINES.md`, `BLINDSPOT_AUDIT.md`, `schema_audit_report.md`, `semantic_rules_catalog.md`, `semantic_validation/README.md`.

---

## 2. The current state of the workspace

> **v97 update (2026-09-07):** All ERP connection settings — GetUserContext URL, ExecuteQuery URL, per-school API keys, and the use_inline_params switch — now live in ONE file: `erp_config.json` at the project root. Edit it and restart the backend; no code changes. Full runbook: `docs/ERP_CONFIG_GUIDE.md`. The rest of this section describes the pre-v97 method and is kept for history.

```
/home/z/my-project/
├── chalo_chatbot/                    ← the package
│   ├── README.md                     ← top-level (start here)
│   ├── backend/
│   │   ├── main.py                   ← FastAPI, 4 endpoints, Bearer auth (port 8000)
│   │   └── .env.example
│   ├── pipeline/                     ← 17 files, ~6,000 LOC
│   │   ├── orchestrator.py           ← 715 LOC, the conductor
│   │   ├── semantic_rules.py          ← 636 LOC, 32 rules
│   │   ├── context.py                ← @AcademicYearID injection (D1.3)
│   │   ├── value_resolver.py          ← validate-and-substitute (F6)
│   │   ├── guardrail.py               ← schema + sensitive blocklist (D1.2/D1.6)
│   │   ├── llm_client.py             ← TruncationError guard (D1.8)
│   │   ├── parameter_binder.py        ← substitute_validated_values()
│   │   ├── local_executor.py          ← connection pool (D1.11)
│   │   ├── api_executor.py            ← production execution path
│   │   ├── user_context_api.py        ← GetUserContext + fallbacks
│   │   ├── branch_scoping_gate.py     ← retry re-check (D1.5)
│   │   ├── dataset_lookup.py          ← fast-path (gated, D1.9)
│   │   ├── template_lookups.py        ← fast-paths (gated)
│   │   ├── entity_extractor.py        ← + FEE_TERM + experimental designation
│   │   ├── context_vocab.py           ← + FEE_TERM concept
│   │   ├── concept_store.py           ← legacy compat
│   │   └── alias_scope_check.py
│   ├── vocab/
│   │   ├── inject.py                  ← STOPGAP + FULL modes
│   │   └── synonyms.json              ← 9 concept types
│   ├── evaluation/
│   │   ├── golden_questions.json      ← 50 Qs (20 novel)
│   │   ├── scoring.py                 ← 4-axis scoring
│   │   ├── evaluate.py                ← the runner
│   │   └── sample_context.json
│   ├── semantic_validation/
│   │   ├── semantic_rules.py          ← synced with pipeline/
│   │   ├── validate_dataset.py
│   │   ├── prepare_data.py            ← the gate
│   │   ├── rules_catalog.json         ← 78-rule catalog
│   │   ├── semantic_rules_catalog.md
│   │   └── reference_inputs/          ← bundled v27 + schema + SPs
│   ├── docs/
│   │   ├── PRD.md
│   │   ├── PROJECT_STATUS.md
│   │   ├── SESSION_HANDOFF.md         ← (this file)
│   │   ├── HOW_IT_WORKS.md
│   │   ├── API_CONTRACT.md
│   │   └── IMPROVEMENTS_VS_AISEC.md
│   └── config/                       ← (Batch 3 — pending)
├── src/app/                          ← the local-test Next.js UI (dev only)
│   ├── page.tsx                      ← 875 LOC, Claude.ai-style
│   ├── layout.tsx
│   ├── globals.css                   ← warm Claude palette
│   └── LOCAL_TEST_UI_README.md       ← "DEV ONLY"
├── GUIDELINES.md                     ← single source of truth (735 lines)
├── BLINDSPOT_AUDIT.md                 ← findings history (~800 lines)
├── schema_audit_report.md            ← schema/SP evidence (~90 KB)
├── worklog.md                        ← the agent worklog
└── (various one-off audit scripts, superseded by the package)
```

---

## 3. How to resume work

### If you're continuing the build (Batch 3)
1. Read `chalo_chatbot/README.md` (the package README) — it's the entry point.
2. Read `docs/PROJECT_STATUS.md` §4 "What's pending" — Batch 3 is: `config/config.yaml.example`, `docs/ARCHITECTURE.md`, the final zip.
3. The backend is at `chalo_chatbot/backend/main.py`; the pipeline at `chalo_chatbot/pipeline/`; the docs at `chalo_chatbot/docs/`.
4. To verify the backend works: `cd chalo_chatbot/backend && python3 -m uvicorn main:app --port 8000 && curl http://localhost:8000/api/health`.

### If you're picking up the audit
1. Read `BLINDSPOT_AUDIT.md` (the 5-round findings, ~800 lines) for the full root-cause analysis.
2. Read `GUIDELINES.md` (the single source of truth, 735 lines) for every problem + impact + mitigation.
3. The schema evidence is in `schema_audit_report.md`; the SP catalog is in `semantic_validation/semantic_rules_catalog.md`.

### If you're the mobile-app team
1. Read `chalo_chatbot/docs/API_CONTRACT.md` — it's self-contained (270 lines). It has the auth model, every endpoint, request/response shapes, UX flow, latency expectations, pagination, rate limiting, and security notes.
2. The OpenAPI spec is at `http://<host>:8000/openapi.json` when the backend is running — use `openapi-generator` to produce Swift/Kotlin clients.

### If you're doing the v28 retrain
1. Read `GUIDELINES.md` §F (training-parameters audit) and §D3 (the v28 retrain plan).
2. Read `semantic_validation/prepare_data.py` — it's the gated prepare_data (refuses if HIGH violations > 0, adds the `instruction` field).
3. The §F parameter changes: r=16/32, dropout 0.05-0.1, lr 1e-4, warmup 35-50, MAX_SEQ_LENGTH 2560 (confirmed-safe), q5_k_m or q8_0 quant.
4. The 50 new training examples are in the round-3 work (documented in `BLINDSPOT_AUDIT.md` §24); the `generate_new_examples.py` script is at `/home/z/my-project/generate_new_examples.py` (if it survived).

---

## 4. Decisions made and their rationale

| Decision | When | Rationale | Where recorded |
|---|---|---|---|
| **Option A (retrain vocab-aware)** for the section concept | Round 4 | The structurally correct fix for ability-stream branches + subject casing. | `BLINDSPOT_AUDIT.md` §30 |
| **32 rules** (29 base + 3 from the "passed maths in term 1" trace) | Batch 1 | EXAM-006 (MinMark hallucination), EXAM-007 (exam-term filter), STUD-006 (Subject/BranchID cartesian join — caught 25 real bugs in v27). | `semantic_rules.py` + `worklog.md` |
| **Bearer auth on the backend** | Batch 2 (mobile-app split) | Mobile apps need auth; the original Streamlit app had none. Constant-time comparison. | `backend/main.py` + `docs/API_CONTRACT.md` |
| **Local-test UI marked dev-only** | Mobile-app split | The production frontend is the mobile app; the Next.js UI is for dev only. | `src/app/LOCAL_TEST_UI_README.md` |
| **FastAPI (not Streamlit) for the backend** | Batch 2 | The original was Streamlit (single-file, less rich). The mobile app needs a real API. | `backend/main.py` |
| **STOPGAP mode default (inject_vocab=False)** | Batch 1 | The v27 model was trained without a vocab block; appending one derails it. FULL mode needs the v28 retrain. | `orchestrator.py` + `vocab/inject.py` |
| **Fast-paths disabled by default (D1.9)** | Batch 1 | 12.4% of v27 labels are buggy; fast-paths replay them verbatim. Re-enable after the labels are cleaned. | `orchestrator.py` |
| **The frozen system prompt is version-controlled in prepare_data.py** | Batch 1 | The model is brittle to prompt changes; the prompt must match training verbatim. | `prepare_data.py` `FROZEN_SYSTEM_PROMPT` |

---

## 5. Open questions for the project owner (unresolved)

These are the questions I asked but didn't get a definitive answer on. They block specific pieces of work.

| # | Question | Blocks | Asked in |
|---|---|---|---|
| **Q11** | Is there school-routing code (parses `username@shortschoolname` → DB target)? Where does it live? | Multi-tenant deployment. | Round 5 (the full-package discussion) |
| **Q12** | Where is `config.yaml`'s `allowed_tables` / `blocked_columns` / `max_joins` enforced? | Security hardening. If not enforced, the chatbot can query any of the 475 tables. | Round 5 |
| **Q16** | Training notebooks: (a) updated, (b) documented diff, or (c) untouched? | The v28 retrain delivery. | Round 5 |
| **Q-RBAC** | Is class-teacher row-level RBAC a requirement, or is branch-level sufficient? | D5 implementation. | Round 5 |
| **Q-SectionSource** | Is `SectionMaster` the right table for ability-stream branches (BRAINY/EXPERT), or do sections live in `ClassSectionMasterMapping`? | The vocab engine + the Option A retrain. | Round 4 (§26c) |

---

## 6. The 3 services and their ports

| Service | Port | What | How to start |
|---|---|---|---|
| **llama.cpp LLM** | 8080 | The fine-tuned Qwen 2.5 Coder 7B model | `./llama-server -m your_model.gguf --port 8080` (run separately — the user's responsibility) |
| **AI Secretary API** | 8000 | The FastAPI backend (production) | `cd chalo_chatbot/backend && python3 -m uvicorn main:app --port 8000` |
| **Next.js dev UI** | 3000 | The local-test web UI (dev only — NOT production) | `cd /home/z/my-project && npm run dev` |

The mobile app (production) talks to the AI Secretary API (8000), which talks to the LLM (8080) and the school's ExecuteQuery API.

---

## 7. The 5-minute smoke test (verify everything works)

```bash
# 1. Start the backend
cd /home/z/my-project/chalo_chatbot/backend
cp .env.example .env  # if not already
python3 -m uvicorn main:app --host 0.0.0.0 --port 8000

# 2. Health (no auth)
curl http://localhost:8000/api/health
# → {"status":"ok","pipeline_loaded":true,"rules_count":32}

# 3. Chat without auth (should 401)
curl -X POST http://localhost:8000/api/chat -H "Content-Type: application/json" -d '{"question":"test","context_json":{},"mode":"dry_run"}'
# → {"detail":"Missing Authorization header..."}

# 4. Chat with auth (pipeline runs; ERROR if no LLM)
curl -X POST http://localhost:8000/api/chat \
  -H "Authorization: Bearer dev-token-please-change-in-prod" \
  -H "Content-Type: application/json" \
  -d '{"question":"who is the principal","context_json":{"UserMasterDetails":{"Id":116,"UserName":"abav","IsSuperUser":false,"UserBranchDetails":[{"ID":1,"Name":"CHALO","IsPrimary":true,"AcademicYears":[{"Id":6,"Name":"2026-2027","IsCurrentYear":true}],"Subjects":["MATHS"]}]}},"mode":"dry_run","branch_id":1}'
# → outcome: ERROR (LLM unreachable — expected) with the full trace

# 5. Semantic engine
curl -X POST http://localhost:8000/api/validate \
  -H "Authorization: Bearer dev-token-please-change-in-prod" \
  -H "Content-Type: application/json" \
  -d '{"sql":"SELECT Password FROM UserAccountMaster","question":"show passwords"}'
# → {"violation_count":1,"high_count":1}
```

If all 5 pass, the backend is healthy. To test the full pipeline, start your llama.cpp at port 8080 and re-run step 4 — expect `outcome: ANSWER` with `sql` populated.

---

## 8. What NOT to do

- **Do NOT enable `inject_vocab` in production until the v28 retrain is done.** The v27 model derails if you append a vocab block (confirmed twice in code comments).
- **Do NOT enable fast-paths in production until the 480 flagged v27 examples are cleaned.** They replay buggy SQL verbatim.
- **Do NOT change the frozen system prompt without a retrain.** The model is brittle to prompt changes.
- **Do NOT deploy the Next.js UI to production.** It's a dev tool (localStorage conversations, no real auth, single-page). The production frontend is the mobile app.
- **Do NOT train on v27 labels without running `prepare_data.py`'s gate.** 12.4% are semantically buggy; the gate refuses if HIGH > 0.
- **Do NOT trust `eval_loss` alone for model selection.** It measures next-token prediction, not semantic correctness. Run the accuracy harness (50 golden Qs).
- **Do NOT diff my reconstructed pipeline files blindly.** I reconstructed from my conversation context; there may be small drift from your real files. Diff `orchestrator.py`, `value_resolver.py`, `parameter_binder.py`, `guardrail.py` against your real `aisec.zip` files first.

---

## 9. The worklog

The agent worklog is at `/home/z/my-project/worklog.md`. It has the records from the subagents I launched:
- `schema-deep-dive` (Task 7) — mined the schema/SP docs.
- `sp-miner` (Task SP-MINE) — mined 78 rules from the 1,095 SPs.
- `rules-engine-extend` (Task BATCH1-RULES) — extended the engine from 29 to 32 rules.
- `pipeline-reconstruct` (Task BATCH1-PIPELINE) — reconstructed the 17-file pipeline.

Read it for the detailed step-by-step of how the subagents worked.

---

## 10. Contact / next steps

The next session should:
1. Read this file + `PROJECT_STATUS.md` + `chalo_chatbot/README.md`.
2. Check the open questions (§5) — resolve them with the project owner.
3. Proceed to Batch 3 (config + zip) OR the v28 retrain path (if Q16 is answered) OR the class-teacher RBAC (if Q-RBAC is answered).
4. Run the 5-minute smoke test (§7) to confirm the backend is healthy.

The project is in a **good state** — the backend is feature-complete, the docs are comprehensive, the audit findings are all addressed. The remaining work is mostly the project owner's decisions (Q11, Q12, Q16, Q-RBAC, Q-SectionSource) and the ops/deployment + mobile-app integration.

---

## Update 2026-08-27 — Q11/Q12/Q16 resolved; new design questions raised

### Resolved (no longer blocking)

**Q11 (school routing):** the school-routing layer already exists in the school's auth system (`GetUserContext` validates `username@shortschoolname` → `school_id` → `DBPrefix` + roles). The backend receives the already-validated Context JSON; no separate routing layer needed. No code change.

**Q16 (training notebooks):** (a) updated notebooks + (b) documented diff. Will deliver in Batch 3: `finetune_TRAIN.ipynb` with `r=16, dropout=0.05, lr=1e-4, warmup_steps=35, MAX_SEQ_LENGTH=2560, epochs=2`; `finetune_EXPORT.ipynb` with `q5_k_m` quant + auto-read `MODEL_VERSION`.

### Resolved but raised a deeper question

**Q12 (role/screen/table RBAC):** the school's RBAC is **screen-level**, not table-level. Every user has a role; every role grants access to screens (modules); each screen touches multiple tables (e.g. the attendance screen joins to fee-due details). The `config.yaml` `allowed_tables` whitelist (16 tables) is NOT the right enforcement — a user's role grants them screens, and screens map to many tables.

**New open question: Q-RBAC-Screen** — should the chatbot enforce role→screen→table RBAC?
- **Path A (stopgap):** a manual role→allowed-tables map in config. Simple, brittle.
- **Path B (proper):** integrate with `Role_Privilege_Details` + `Screen_Privilege_Details` — resolve the user's screens → each screen's tables → allow only those. Requires a screen→table mapping the school must provide.
- **Recommendation:** ship v1.0 with branch-level + sensitive blocking (current); implement screen-level RBAC as v1.1.
- **Status:** not blocking v1.0 launch; added to PRD §10.

### New open question: Q-ContextAPI

A real `GetUserContext` response was provided. It confirms the design (per-branch vocab varies — this branch has lettered sections A/B/C/D/E and mixed-case subjects "Maths"/"English", unlike branch 1 which had ability-stream sections and uppercase "MATHS"). But it also confirms two API gaps:
- **Sections** is returned by this branch's API (the sample I had didn't have it). So the API is inconsistent — some branches return Sections, some don't. The `_merge_local_sections` fallback handles the gap.
- **FeeTerms** is NOT returned (confirmed — neither branch's API returns it). The fallback queries `TermMaster`.
- **IsMgmtAppEnabled, ShortName, StaffName** are absent in this response. The backend tolerates missing optional fields.

**New open question: Q-ContextAPI** — ask the dev team to:
1. Standardize the `GetUserContext` response (always return Sections + FeeTerms for every branch).
2. Add the missing optional fields (`IsMgmtAppEnabled`, `ShortName`, `StaffName`) consistently.
3. Document the contract (the current response is ad-hoc per branch).

### Real Context JSON observations (for the v28 retrain)

The real Context JSON reveals the synonym store needs refinement:
- **FeeHeads are granular and year-suffixed:** "Bus Fee I", "Bus Fee II", "Arrear Fee (22-23)", "TuitionFee 24-25". The model trained on "Tuition Fees" won't match "Tuition Fee" or "TuitionFee 24-25" without synonyms.
- **ExamTerms are detailed:** "SUMMATIVE ASSESSMENT I", "MIDTERM-I", "JAN SAT1", "UNIT EXAM". The model trained on "Term I" won't match "SUMMATIVE ASSESSMENT I" without synonyms.
- **Action for v1.1:** expand the synonym store with branch-specific FeeHead + ExamTerm synonyms. Or (better) make the synonym store learn from the Context JSON's real values (per-branch synonym induction — a v2.0 enhancement).

### Decisions recorded

| Decision | Rationale |
|---|---|
| Ship v1.0 with branch-level + sensitive-blocking RBAC | The screen-level RBAC (Path B) requires a screen→table mapping the school hasn't provided; it's a v1.1 hardening. |
| Use the real Context JSON shape for `evaluation/sample_context.json` | More realistic testing than the fabricated sample. |
| Deliver updated training notebooks in Batch 3 (Q16 = a+b) | Per the project owner's decision. |
| Document the Context API contract gaps as Q-ContextAPI | The dev team needs to standardize the response. |

### New docs written (this session)

The project owner asked three follow-up questions + a brainstorm. All four are now written:
1. `docs/VOCAB_EXPLAINED.md` — what "vocab" means, in plain language (the two modes, the synonym store, why the original was insufficient).
2. `docs/INSTRUCTION_IMPROVEMENT.md` — analysis of the frozen system prompt's 7 gaps + the proposed improved instruction for v28 (with the constraint that it can't change at runtime without a retrain).
3. `docs/CONVERSATIONAL_HANDLING.md` — the casual to-and-fro UX design (client-side rule-based resolver, 10 rewrite patterns, disambiguation + refusal UX, phasing plan).
4. `docs/BRAINSTORM.md` — 23 out-of-the-box ideas across 8 themes (auto-charts, morning briefing, suggestions, feedback loop, multi-school benchmarking, parent mode, voice input, active learning). Top 5 picks: auto-chart, morning briefing, suggestions, feedback loop, multi-school benchmarking.

All 4 are in `chalo_chatbot/docs/`. The PRD §10 (open questions) is updated with Q11/Q12/Q16 resolutions + the new Q-RBAC-Screen and Q-ContextAPI questions.

### Dev team asks doc written

`docs/DEV_TEAM_ASKS.md` (priority 1/2/3, 9 asks, summary table). This is the single list to hand to the dev team — what we need, why, the impact if not done, and the effort. Minimum to ship v1.0: asks 1.1 + 1.2. Minimum for the v28 retrain: 1.1 + 2.1 + 2.2 + 2.3. The cheapest high-value ask: 2.3 (10-20 failing examples, 1-2 hours of dev time).


---

## Update 2026-08-27 (later still) — VAPT + admin config + deployment context

### Two new principles (from the project owner)

1. **The 23 brainstorm ideas are admin-only feature toggles.** The project owner (the admin) wants a config UI to flip each idea on/off — not per-user, not per-school necessarily, but admin-controlled. The mobile app reads the enabled features from the backend; the backend enforces them. Default: all off. The admin flips on the ones they want. (See `docs/ADMIN_CONFIG_UI.md` — to be written.)

2. **Documentation is maintained at every stage.** The project owner values documentation. Every change — code, config, deployment, VAPT fix — gets its doc update. No orphan code. (This is the standing principle; this update formalizes it.)

### Deployment context clarified

- **The DB is in Oracle Cloud (OCI).** Not on-prem. The LLM should be in the **same OCI region** as the DB, ideally the same VCN, for 1ms RTT on the execute round-trips.
- **Recommended shape:** `VM.Standard.E4.Flex` with 8 OCPUs + 24GB RAM (~$60-80/month). Handles 20-25 onboarded users, 1-3 concurrent. Skip the GPU (school staff don't need sub-second latency).
- **Deployment topology:** FastAPI backend in a public subnet (behind a TLS-terminating LB); llama.cpp in a private subnet (only the backend can reach it); the DB in the same VCN. See `docs/OCI_DEPLOYMENT.md` — to be written.

### VAPT-readiness work started

The project owner said: "Make sure there are no bugs and the whole app passes VAPT test — This is more important."

Honest assessment: the app is **structurally safe** (SQLi impossible via parameterized binding; SELECT-only; sensitive-table blocked; branch-scoped; 32-rule semantic engine) but **not production-hardened** (15 gaps a VAPT pen-tester will find). The 15 gaps are in `docs/VAPT_READINESS.md` — to be written. None require a redesign; they're additions (rate limiting, audit logging, input sanitization, prompt-injection defense, ops config). ~5-7 days of work.

### The VAPT work in progress

Implementing the code-side fixes:
- **V4** — move the ExecuteQuery API key server-side (the backend looks up the key from the user's DBPrefix; the mobile app never sees it). Also unblocks multi-tenant rollout (ask 2.2).
- **V5** — audit logging (a SQLite table + a logging hook). Compliance + debugging + the feedback loop.
- **V7** — prompt-injection defense (question sanitizer + system-prompt reinforcement).
- **V9** — input sanitization (strip control chars, reject null bytes, normalize Unicode).
- **V10** — generic prod error (don't leak SQL Server errors to the mobile app; log server-side).
- **V8** — dependency CVE scan (`pip-audit`) + pin versions.

The ops-side fixes (V1 rate limiting, V2 TLS, V3 CORS, V6 secrets in OCI Vault, V11 LLM timeout, V12 body size, V14 security headers, V15 WAF) are in the nginx config + the OCI deployment doc — the ops team applies them.

### Admin config UI design (to be built)

- **Backend endpoints:** `GET /api/admin/features` (returns the current feature flags + their allowed roles); `PUT /api/admin/features` (admin updates the flags). Both require the admin Bearer token (a separate admin token in `AI_SECRETARY_AUTH_TOKENS`, or a role check).
- **Config shape:** the `features` block in `config.yaml` (23 flags, all default off). The backend reads it at startup; the admin endpoint writes to it (or to an overrides file).
- **Mobile-app admin UI:** a "Features" screen in the admin settings — a toggle per flag. The mobile app calls `GET /api/admin/features` to load, `PUT /api/admin/features` to save. Per-role control: each feature has an `allowed_roles` list; the backend checks the user's role before enabling a feature for that request.
- **Per-feature implementation:** flipping a flag on doesn't build the feature; it tells the backend "this feature is allowed." The feature's code lands in v1.1+ (each feature is an incremental addition). The flag is the **governance layer**, not the implementation.

### Docs to be written/maintained this session

- `docs/VAPT_READINESS.md` — the 15 gaps + fixes + pre-VAPT checklist.
- `docs/OCI_DEPLOYMENT.md` — the OCI shape + VCN topology + secrets in Vault + nginx config.
- `docs/ADMIN_CONFIG_UI.md` — the admin-only feature config UI design.
- `docs/HARDWARE_AND_DEPLOYMENT.md` — the hardware recs (already discussed inline; now captured).
- Updates to `PROJECT_STATUS.md`, `SESSION_HANDOFF.md`, `PRD.md`, `README.md` to reflect the VAPT + admin-config work.

---

## Update 2026-08-27 (final) — VAPT hardening + admin config UI delivered

### What was done

**VAPT code-side fixes (all implemented + verified):**
- `backend/security.py` (new) — V4 (server-side API key), V5 (audit logging), V7 (prompt-injection defense), V9 (input sanitization), V10 (generic prod error), V11 (LLM timeout).
- `backend/main.py` (rewritten) — wires in all the VAPT fixes + the admin config UI endpoints + rate limiting (V1). Bumped to v1.1.0.
- Verified end-to-end: 401 without auth, 400 on prompt injection, 400 on null bytes, admin 403/200, audit trail logging, features_enabled in chat response.

**Ops-side fixes (documented; ops team applies):**
- `docs/OCI_DEPLOYMENT.md` (new) — the OCI shape (VM.Standard.E4.Flex, 8 OCPU, 24GB), VCN topology (public API subnet + private LLM subnet), secrets in OCI Vault, nginx config (TLS, HSTS, security headers, body size, rate limiting), WAF. The ops team applies this in ~1 day.

**Admin config UI (built + tested):**
- `GET /api/admin/features` + `PUT /api/admin/features` — admin-only endpoints (separate admin token). 24 feature flags, all OFF by default, persisted to `feature_overrides.json`.
- Every `/api/chat` response includes `features_enabled` — the list of flags currently on.
- `docs/ADMIN_CONFIG_UI.md` (new) — the full design + the mobile-app admin UI spec.

**New docs:**
- `docs/VAPT_READINESS.md` — the 15 gaps + fixes + the pre-VAPT checklist.
- `docs/OCI_DEPLOYMENT.md` — the OCI deployment guide.
- `docs/ADMIN_CONFIG_UI.md` — the admin config UI design.
- `docs/HARDWARE_AND_DEPLOYMENT.md` — the lean hardware recs (~$60-80/month for 20-25 users).

### The two principles (locked in)

1. **Admin-only feature config UI** — the 23 brainstorm ideas + future features are admin-controlled flags. `GET/PUT /api/admin/features`. The mobile app reads `features_enabled` from the chat response. All OFF by default. The flag is governance; the implementation is v1.1+.
2. **Documentation maintained at every stage** — every change (code, config, deployment, VAPT fix) gets its doc update. This is now the standing principle for the project.

### The pre-VAPT checklist

Before engaging the pen-tester, run through `docs/VAPT_READINESS.md` §3:
- Code-side: V1, V4, V5, V7, V8, V9, V10, V11 (all verified except V8 pip-audit — run before deploy).
- Ops-side: V2, V3, V6, V12, V14, V15 (the ops team applies the nginx config + OCI settings).
- Pen-tester-facing: SQLi, write verbs, sensitive columns, cross-branch, prompt injection, DoS, auth, large payload, LLM timeout.

### What the next session should do

1. **V8** — run `pip-audit` on the backend's dependencies; pin to non-vulnerable versions. ~1 hour.
2. **The ops team** — apply `docs/OCI_DEPLOYMENT.md` (the nginx config + OCI Vault + WAF). ~1 day.
3. **Run the pre-VAPT checklist** — verify every item. ~2 hours.
4. **Engage the VAPT pen-tester** — the app should pass on the first round (or only flag the ops-side items not yet applied).
5. **Then** — the v28 retrain path (the 12 new semantic rules + the hint map + ~60-100 training examples, per `docs/PRODUCTION_TRACE_OBSERVATIONS.md`).

### Files updated this session

- `backend/main.py` (rewritten — VAPT-hardened + admin config UI, v1.1.0)
- `backend/security.py` (new — the VAPT code-side fixes)
- `backend/audit_trail.db` (new — the audit log)
- `backend/feature_overrides.json` (new — the admin's flag overrides)
- `docs/VAPT_READINESS.md` (new)
- `docs/OCI_DEPLOYMENT.md` (new)
- `docs/ADMIN_CONFIG_UI.md` (new)
- `docs/HARDWARE_AND_DEPLOYMENT.md` (new)
- `docs/PROJECT_STATUS.md` (updated)
- `docs/SESSION_HANDOFF.md` (updated — this section)

### Instruction manual written

`docs/INSTRUCTION_MANUAL.md` (655 lines, + PDF) — a single document with three self-contained sections:
- **Part 1 — Infra Team:** step-by-step OCI deployment (VCN, subnets, security lists, compute, Vault, nginx, WAF, llama.cpp), what NOT to do, troubleshooting, maintenance.
- **Part 2 — Dev Team:** dev environment setup, daily workflow, how to add a semantic rule, how to update training data (v28 retrain path), what NOT to do, troubleshooting, maintenance.
- **Part 3 — Admin:** managing feature flags (the admin API), monitoring (health + audit trail), tenant onboarding, model updates, what NOT to do, troubleshooting, maintenance.

The PDF version is at `docs/INSTRUCTION_MANUAL.pdf` (93KB, generated via pandoc + weasyprint). The markdown is the source of truth; the PDF is for distribution.

### Total docs in chalo_chatbot/docs/

16 docs, ~3,800 lines:
ADMIN_CONFIG_UI.md, API_CONTRACT.md, BRAINSTORM.md, CONVERSATIONAL_HANDLING.md,
DEV_TEAM_ASKS.md, HARDWARE_AND_DEPLOYMENT.md, HOW_IT_WORKS.md, IMPROVEMENTS_VS_AISEC.md,
INSTRUCTION_IMPROVEMENT.md, OCI_DEPLOYMENT.md, PRD.md, PRODUCTION_TRACE_OBSERVATIONS.md,
PROJECT_STATUS.md, SESSION_HANDOFF.md, VAPT_READINESS.md, VOCAB_EXPLAINED.md.

---

## Update 2026-08-30 — v27 trained + 50-question benchmark + all docs updated

### v27 model status

v27 was trained (6 hours on Kaggle) and benchmarked with the 50-question script locally (api_wrapper mode, user 116, branch 1). This is the **first real v27 baseline** — all previous production traces (batches 1-2, 43 traces) were from the v25 model.

### The v27 benchmark numbers

- **50 questions:** 18 correct (36%), 5 semantic mismatches (10%), 16 refused by guardrail (32%), 6 execute errors (12%), 3 section refusals (6%), 1 branch-scoping refusal (2%).
- **v25 vs v27 (first 10, head-to-head):** semantic mismatch rate dropped from 50% to 12.5%. Bus fee outstanding (Q6) went from NULL to 117,800. The 'Reg' enum hallucination is gone. Total demand numbers are more accurate.
- **Strongest module:** Fees (80% answer rate — the Structure_Type removal fix works).
- **Weakest module:** Staff (17% — principal, turnover all fail on hallucinated columns).

### The 5 semantic mismatches (v28 targets)

1. Q1: hardcoded `Term_Name IN ('Term 1','Term 2')` instead of TermMaster date window → NULL
2. Q22: cartesian subject join (`s.BranchID = smd.BranchID`) → all subjects = 46.11
3. Q25: same cartesian join → 1039 rows instead of 5
4. Q24: queried marks instead of report-card-status table → wrong data
5. Q48: counted StudentAcademicDetail instead of SMSAuditTrail → student count, not notifications

### The 12 guardrail failures (all coverage gaps — the model guesses because it has no training examples)

Q7 (FeesType_Name), Q8 (Fees_Head_Name), Q19 (smd.SubjectID), Q20 (smm.Term_Name), Q26 (StaffDesignationMaster.StaffID + DesignationName), Q31 (EmployeeMaster.IsTCIssued + IsNewJoiner), Q39 (Route_MasterStudentMapping), Q43 (FeesCollection.IsCreditNote), Q44 (InventoryItem_Master.MinStockLevel), Q45 (SupplierMaster table), Q47 (SMSLog table), Q49 (FeedbackParentStudent table).

### The 6 execute: api FAILED cases

- 2 confirmed CTE + ExecuteQuery API bug (Q32, Q36 — the CTE-form scoping works structurally but the API can't handle repeated @UserId placeholders in a CTE + subquery)
- 1 schema drift (Q30 EmployeeMaster — in the catalog but not in the live DB)
- 3 other DB errors (Q21 multi-join, Q23 ProgressCardDataRetrieval, + the schema drift)

### The v28 training data plan (~130-220 new examples)

| Category | Count | Source |
|---|---|---|
| "Current term" via TermMaster date window | 10-15 | Batch 4 Q1 |
| Subject join via EvalHierID (not BranchID) | 10-15 | Batch 4 Q22, Q25 + Batch 1 STUD-006 |
| Fee head name JOIN (Fees_Head_ID → Fees_Master) | 5-10 | Batch 4 Q8 |
| "Who is the principal" → BranchMaster.Principal | 5-10 | Batch 4 Q26 |
| Report card status (correct table) | 5-10 | Batch 4 Q24 (needs ask 3.5) |
| Notifications/SMS → SMSAuditTrail | 5-10 | Batch 4 Q47, Q48 |
| Feedback → FeedbackTicket | 5-10 | Batch 4 Q49 |
| EmployeeMaster → Staff_Master | 5-10 | Batch 4 Q30, Q31 |
| Supplier/Inventory/CreditNote correct tables | 10-15 | Batch 4 Q43, Q44, Q45 (needs ask 3.5) |
| CTE-form scoping rewrites | 50-100 | §22 recommendation (needs ask 2.1 — API bug fix) |
| Compare + "not entered" patterns | 20-30 | Batches 1-2 |
| Bus fee by route + DECLARE → single SELECT | 5-10 | Batch 4 Q33, Q39 |

### The immediate next steps

1. **Dev team provides the correct table/column names for 6 concepts** (ask 3.5: bonafide, report cards, credit notes, suppliers, inventory low-stock, SMS log). Without these, the v28 training examples for those concepts can't be written correctly.
2. **Dev team fixes or confirms the ExecuteQuery CTE bug** (ask 2.1). If the bug is fixed, the v28 training data can use CTE-form scoping (cuts query length 30-50% + avoids the repeated-placeholder failure). If not fixed, v28 must stay with inline scoping.
3. **I draft the ~130-220 new training examples** + the improved instruction (§INSTRUCTION_IMPROVEMENT.md). These use the correct tables from step 1 + the CTE-or-inline decision from step 2.
4. **You retrain v28** on Kaggle (same notebooks, updated dataset, updated parameters: r=16, dropout=0.05, lr=1e-4, warmup=35, q5_k_m).
5. **You run the 50 questions again** with v28 → compare v25 (50% mismatch) → v27 (18% mismatch) → v28 (target: <5% mismatch).

### The doc inventory (as of this update)

- 20 markdown docs + 2 PDFs in `chalo_chatbot/docs/` (~5,500 lines)
- `PRODUCTION_TRACE_OBSERVATIONS.md` (838 lines — the full 4-batch analysis with v25 vs v27 comparison)
- `DATA_DICTIONARY.xlsx` (362KB — the living data dictionary, 475 tables, 8,685 columns)
- `PROJECT_STATUS.md` (this file)
- `SESSION_HANDOFF.md` (this file)
- The v27 training + export notebooks in `chalo_chatbot/training/`

### The bottom line

v27 is the new baseline. The path to v28 is clear: ~130-220 new training examples (waiting on 6 dev-team confirmations + 1 API bug fix), the improved instruction, the §F parameters. The 50-question benchmark is the gate: v28 must beat v27 (18% mismatch → <5%).

---

## Update 2026-08-30 — Windows local testing guide + batch files

The project owner is running the app on a Windows laptop for local testing (before OCI deployment). Created:

| File | What |
|---|---|
| `docs/WINDOWS_LOCAL_TESTING.md` | Separate Windows-only guide (for the owner's personal use, not mixed with the OCI/Linux docs) |
| `scripts/start_llm.bat` | Batch file to start llama.cpp on Windows |
| `scripts/start_backend.bat` | Batch file to start the FastAPI backend on Windows |
| `scripts/run_50.bat` | Batch file to run the 50-question benchmark on Windows |
| `frontend/chat.html` | Standalone HTML chat UI (open in browser, no build) |
| `frontend/audit.html` | Standalone HTML audit-trail viewer |
| `frontend/start_chat.bat` | Windows launcher for chat.html |
| `frontend/nextjs-ui/` | Full Next.js React UI source (optional, requires `npm install`) |

The Windows guide is kept separate from the OCI deployment guide (per the owner's request). The OCI docs (Linux, nginx, Vault, systemd) are for production deployment later. The Windows docs are for local testing now.

The batch files have editable paths at the top (`D:\aisec-zv27\`, `D:\llama.cpp\`, `D:\models\`) — the owner changes them to match his actual folder locations.

---

## Update 2026-08-31 — End-to-end verified on Windows + 5 backend bug fixes + audit export/reset + batch file hardening

### The headline: the system is now verified end-to-end

The user successfully ran the full pipeline on a Windows laptop against the school's real `V3_TestDatabase`. The query **"how many students are there in 10 a?"** returned the real answer **`StudentCount = 32`**. The full pipeline trace shows all 6 stages passing: `generate → branch_scoping → validate → semantic (32 rules) → bind → execute`. This is the **first end-to-end verification** — every prior run was either dry_run or against a sandboxed/stubbed LLM. The chat UI (`frontend/chat.html`), the backend (`backend/main.py`), the LLM (`D:\llama-b6691\llama-server.exe` + `D:\ggufs\AISv27-qwen2.5-coder-7b-instruct.Q4_K_M.gguf`), and the school's ExecuteQuery API all talked to each other.

### The 5 backend bug fixes (the changes that made it actually work)

These were discovered while running the system on Windows. Each was a real blocker — the system did not work end-to-end without them.

| # | File | Bug (the symptom) | Fix (what changed) |
|---|---|---|---|
| 1 | `pipeline/parameter_binder.py` | The bind stage raised `UnboundParameterError` whenever the model didn't use `@AcademicYearID` or `@SelectedBranchId` (common — the model often scopes by `GETDATE()` instead). The chat UI just said "could not be safely bound" with no clue why. | Unused `SECURITY_PLACEHOLDERS` (`@AcademicYearID`, `@SelectedBranchId`) are now **silently dropped** instead of raising. The model is allowed to scope by `GETDATE()` instead of `@AcademicYearID`. |
| 2 | `pipeline/orchestrator.py` | The school's ExecuteQuery API error message was hidden in the `detail` field (only visible with `DEBUG=true`), so the chat UI just said "ExecuteQuery API failed" with no clue why. | The school's API error message is now **surfaced in the `message` field** (shown in the chat UI), not just the `detail` field. Users now see the real API error inline. |
| 3 | `backend/main.py` | `mode=api_wrapper` with an empty `api_wrapper_url` or `target_database` was silently passed to urllib → `unknown url type: ''` (a urllib-level error with no actionable info). | **Early validation.** If `mode=api_wrapper` but `api_wrapper_url` or `target_database` is empty, fail fast with a clear **400 error** telling the user to set the field in the chat UI Settings. |
| 4 | `backend/main.py` | The school's ExecuteQuery API has a **confirmed bug** where it fails on repeated `@-placeholders` in nested subqueries (e.g. `@UserId` referenced twice in a CTE + a subquery). With `use_inline_params=False`, every bound request hit this bug. | `use_inline_params=True` is now **hardcoded** (matches the old `config.yaml`). Inline params substitutes `@UserId=116` and `@SelectedBranchId=1` directly into the SQL text (safely escaped by `_sql_literal()`), avoiding the repeated-placeholder bug entirely. |
| 5 | `backend/main.py` | The user had to set every env var (`AI_SECRETARY_AUTH_TOKENS`, etc.) in the shell before starting uvicorn — easy to forget on Windows. | Added a `try/except` block at the top that **auto-loads `backend/.env`** via python-dotenv (graceful fallback if dotenv isn't installed or `.env` is missing). |

### Audit trail — Export XLSX + Reset (the new admin feature)

Two new admin-facing features in `frontend/audit.html`:

1. **Export XLSX (green button):** fetches ALL audit rows (respecting the current outcome filter, up to 100,000) and downloads them as an Excel `.xlsx` file via SheetJS (loaded from the CDN). **Falls back to CSV** if offline (SheetJS not loaded). Filename includes the date + row count (e.g. `audit_trail_2026-08-31_482rows.xlsx`).

2. **Reset (red button):** clears the entire audit trail. Shows a confirmation dialog with the row count + a reminder to "Export XLSX first if you want a copy." Calls the new `DELETE /api/audit` endpoint (admin-only). Cannot be undone.

**New backend endpoint: `DELETE /api/audit`** — admin-only, deletes ALL rows from the `audit_trail` SQLite table. The endpoint count went from 8 → 9 (4 user + 5 admin/audit).

### The batch file hardening (CHANGE 1)

All 5 batch files were rewritten to be **bulletproof on Windows**:

- `goto`-based control flow (not nested `if` blocks) — Windows `cmd.exe` parses nested `if` blocks weirdly, especially with delayed expansion.
- **Pure ASCII** (no Unicode box-drawing chars) — `cmd.exe` displays Unicode as garbage on some code pages.
- **Self-bootstrapping** — auto-create `.venv`, `pip install -r backend\requirements.txt`, fall back to a sample `context.json` if the user's is missing.
- **Find Python via `python --version`** (not `where`) — `where` doesn't always find Python on Windows even when it's on PATH.
- Friendly file-missing errors with download URLs (e.g. `start_llm.bat` tells you to download llama.cpp from the releases page if `llama-server.exe` is missing).
- The user's real paths are pre-filled in `start_llm.bat`: `D:\llama-b6691\llama-server.exe` and `D:\ggufs\AISv27-qwen2.5-coder-7b-instruct.Q4_K_M.gguf`.

**`START_HERE.bat`** (NEW, in project root) is the one-click starter that opens all 3 services (LLM, backend, browser) in 3 windows with step-by-step instructions. This is now the recommended way to start the system on Windows.

### What's NOT fixed (carried forward to v28)

- **The LLM quality gap on "section A":** the end-to-end test query ("how many students are there in 10 a?") returned the count for ALL of class 10 (32 students), not section A specifically. The v27 model wasn't trained on enough class+section examples — it ignores "section A" in the question. This is a **model-quality issue, not a pipeline bug** — the pipeline correctly bound, scoped, and executed the SQL the model produced; the model just produced the wrong SQL. **Needs the v28 retrain** with more class+section training examples (~10-15 new examples in the v28 training plan).
- **The v28 retrain** is still pending (waiting on dev-team asks 1.1, 2.1, 3.5).
- **Screen-level RBAC (Path B)** is still designed-not-implemented (v1.1).
- **VAPT ops-side (nginx, Vault, WAF)** is still documented-not-applied (pre-VAPT).
- **pip-audit (V8)** is still not run (pre-deploy).

### Files changed this session (2026-08-31)

- **Backend:** `backend/main.py` (fixes 3, 4, 5 + the new `DELETE /api/audit` endpoint), `pipeline/parameter_binder.py` (fix 1), `pipeline/orchestrator.py` (fix 2).
- **Frontend:** `frontend/chat.html` (added Settings inputs for `api_wrapper_url`, `target_database`, `model_url`), `frontend/audit.html` (Export XLSX + Reset buttons), `frontend/nextjs-ui/src/app/page.tsx` (the BLOCKER fix — was calling a non-existent `/api/chat?XTransformPort=8000` route with no auth; now calls `${settings.backendUrl}/api/chat` directly with `Authorization: Bearer ${settings.authToken}`).
- **Batch files:** `START_HERE.bat` (NEW), `scripts/start_backend.bat`, `scripts/start_llm.bat`, `scripts/run_50.bat`, `frontend/start_chat.bat` — all 5 rewritten (goto-based, pure ASCII, self-bootstrapping).
- **Bundled INTO `chalo_chatbot/`:** `run_50_questions.py`, `context.json`, `docs/GUIDELINES.md`, `docs/BLINDSPOT_AUDIT.md`, `semantic_validation/` (entire folder), `pipeline/schema_catalog.json`, `training/README.md`, `backend/.env.example` (now with the user's real `AI_SECRETARY_TENANT_KEYS` pre-filled), `backend/requirements.txt` (NEW).
- **`bun` → `npm`:** all `bun install` / `bun run dev` references changed to `npm install` / `npm run dev`. The Next.js `package.json` `start` script changed from `bun` to `node`; `bun-types` removed; `@types/node` added.
- **All 11 docs updated** to reflect the above (README.md, STRUCTURE.md, PROJECT_STATUS.md, SESSION_HANDOFF.md, INSTRUCTION_MANUAL.md, COMPLETE_GUIDE.md, HOW_IT_WORKS.md, API_CONTRACT.md, ADMIN_CONFIG_UI.md, frontend/README.md, WINDOWS_LOCAL_TESTING.md).

### The bottom line

The system is now **end-to-end verified on Windows**. The path to v28 is unchanged (the LLM quality gap on "section A" is the same model-quality issue that drove the v28 plan from the start). The pipeline, the backend, the chat UI, the LLM, and the school's ExecuteQuery API all talk to each other correctly. The remaining work is the v28 retrain (model quality) + the ops-side VAPT (deployment hardening) + the mobile-app integration.

---

## Update 2026-09-03 — 4 new pending UI/UX items + CTX_SIZE clarification + system prompt expansion plan + 3B vs 7B decision + persona skill + SESSION_RECORD

**Task ID:** DOC-UPDATE-5 (documentation-only update — no code changed).

### The 4 new pending UI/UX items (the most important thing in this update)

The project owner requested 4 new features be added to the pending list. **None are implemented yet** — they're queued for the next developer / next session. Clear descriptions for the next developer:

1. **AI disclaimer in `chat.html`**
   - **Where:** `frontend/chat.html` — a subtle footer note below the input box (not a modal, not a banner).
   - **What:** Suggested wording — *"AI can make mistakes. Please verify important information."* (or similar). The point is to set user expectations without alarming them.
   - **Effort:** small — pure HTML/CSS, no backend change.

2. **LLM model selector dropdown in `chat.html`**
   - **Where:** `frontend/chat.html` → Settings panel (alongside the existing Backend URL / Auth token / Branch ID / Mode inputs).
   - **What:** three options:
     - **Chalo Language Model 1.0** — enabled, selected by default (this is the current v27 GGUF)
     - **Chalo Language Model 2.0** — DISABLED (greyed out, "coming soon" — this will be v28 once trained)
     - **Chalo Language Model 3.0** — DISABLED (greyed out, "coming soon" — this will be v29 once trained)
   - **Future-proofing:** when v28 (CLM 2.0) and v29 (CLM 3.0) are trained, users can switch between them. The selection maps to:
     - a different GGUF file path in `scripts/start_llm.bat` (the script reads an env var or arg to pick the file), **OR**
     - a different `model_url` in the request body to `/api/chat` (if the school runs multiple `llama-server` instances on different ports — e.g. 8080 for v27, 8081 for v28).
   - **Effort:** medium — frontend dropdown + a small backend wiring (the `model_url` field already exists in the request body; we just need to expose it in the UI and add the disabled-state styling). Decide which routing strategy (single-`llama-server`-with-config vs. multi-`llama-server`-per-port) before implementing.

3. **Configurable "show thinking process" toggle (show/hide)**
   - **Where:** `frontend/chat.html` → Settings panel (a new toggle, default OFF).
   - **What:** because there's 15-35s latency on CPU, show the pipeline stages as they happen:
     - "Understanding your question..."
     - "Generating SQL..."
     - "Validating against 32 rules..."
     - "Querying the database..."
   - When enabled, the chat UI shows progressive status updates while the backend processes the question. When disabled (default), just show the loading dots (current behavior).
   - **Backend change needed:** today the pipeline returns the `trace` array only at the END (in the final response). To show stages progressively, the backend needs to emit stage events — either via Server-Sent Events (SSE) on `/api/chat`, or via a separate `/api/chat/<id>/status` polling endpoint, or via WebSocket. The simplest path is SSE: stream `{"stage":"generate","status":"running"}` events as each stage starts/finishes, then send the final result. **This is a non-trivial change** — touches `backend/main.py` (StreamingResponse) + `pipeline/orchestrator.py` (yield stage events instead of accumulating them) + `frontend/chat.html` (EventSource listener).
   - **Effort:** medium-large — the orchestrator already has the stage list; the work is plumbing it through as a stream instead of a final array.

4. **Standard reply for unanswerable questions (configurable)**
   - **Where:** backend config + `frontend/chat.html`.
   - **What:** when the system can't answer a question (`outcome ∈ {REFUSED, ERROR, NEEDS_DISAMBIGUATION}`), show a single standard configurable reply instead of the raw error in the user-facing `message` field. Suggested default: *"I'm sorry, I couldn't answer that question. Please try rephrasing it, or ask a different question."*
   - **Configuration:** either `AI_SECRETARY_FALLBACK_MESSAGE` env var in `backend/.env`, OR a new key in `backend/feature_overrides.json` (e.g. `fallback_message`). The env var is simpler; the JSON key is more admin-friendly (changeable via the admin API without a restart). Recommend the env var with a JSON override on top.
   - **Important:** the raw `detail` + `semantic_violations` STAY in the response body for debugging — only the user-facing `message` is replaced. The mobile app already shows `message` (not `detail`), so this is backward-compatible.
   - **Special case:** for `NEEDS_DISAMBIGUATION`, the `disambiguation.candidates` array must still come through unchanged (the user needs to pick a candidate) — only the text shown above the candidates changes.
   - **Effort:** small-medium — backend reads the config; replaces `message` when outcome is not `ANSWER`; frontend already renders `message`.

**For the next developer:** items 1 and 2 are pure frontend work in `frontend/chat.html`. Item 3 is the largest (touches backend + orchestrator + frontend). Item 4 is small backend + minimal frontend. A sensible order: 1 → 2 → 4 → 3.

### CTX_SIZE — training constraint ≠ inference constraint (important architectural decision)

`scripts/start_llm.bat` sets `CTX_SIZE=2560` with the comment *"Context size (must match training: 2560). Don't change unless you know why."* That comment is **misleading** and was clarified on 2026-09-03:

- **2560 came from TRAINING.** The previous AI assistant (Claude) chose `MAX_SEQ_LENGTH=2560` during fine-tuning to prevent silent truncation of training sequences (longest training example was ~1,750 tokens; 2,560 gave margin). This is a TRAINING constraint — it sets the max sequence length the LoRA adapters were exposed to during fine-tuning.
- **Inference is independent.** At inference time (in `llama-server`), the context window is set by `--ctx-size` and is decoupled from the training sequence length. Qwen 2.5 Coder 7B's base model natively supports **32K tokens** of context. Fine-tuning with LoRA (1.05% of params) teaches patterns, not context length — the model's attention mechanism doesn't break at longer lengths just because the LoRA was trained at 2,560.

**Decision:** the inference `--ctx-size` can safely be **increased to 4096** (not 8192 — that might degrade attention quality on CPU). This allows a 2-page system prompt (~1,000-1,500 tokens) instead of the current 1-paragraph prompt (~80 tokens). Going from 2560 → 4096 adds ~3-4 seconds of latency (acceptable: 15-35s → 18-39s on CPU).

**Action (PENDING — not yet applied):** bump `CTX_SIZE` in `scripts/start_llm.bat` from 2560 to 4096, update the comment to explain the distinction, and update the systemd `ExecStart` lines in `docs/INSTRUCTION_MANUAL.md` and `docs/COMPLETE_GUIDE.md` (currently both hardcode `--ctx-size 2560`). **This should happen alongside the system prompt expansion** (next item) — the two changes go together.

### System prompt expansion plan (the #1 accuracy lever without retraining or dev-team help)

**The current prompt** is one paragraph (~80 tokens), frozen in `prepare_data.py`'s `FROZEN_SYSTEM_PROMPT` and `demo_runner._read_base_prompt`:

> "You are a T-SQL expert for the ChaloSchools (V3_CHALO) school management database. Convert the following natural language question into a single, executable T-SQL query. Use @UserId (bound as a query parameter at runtime from the logged-in user's session) to scope results to the branches that user has access to via UserAccountRoleDetails."

**The plan:** expand it to ~2 pages (~1,000-1,500 tokens) covering:

- **The 7 known schema gotchas** — `BusFeeStrucure` misspelling (no 't' in "Structure"), `ExamTermMaster` column names, `Receipt_Amt` not `Amt`, etc.
- **The top 5 business formulas** — fee outstanding = `Amount - Concession_Amt - Paid_Amt - Lien_Amount`; current term = `TermMaster WHERE GETDATE() BETWEEN StartDate AND EndDate`; etc.
- **The top 10 mandatory filters** — `IsActive=1`, `IsTCIssued=0`, `ChequeStatus_ID NOT IN (3,4)`, `BranchID = @SelectedBranchId`, etc.
- **The key JOIN patterns** — student → `ClassMaster` + `SectionMaster`; fees → `FeesInformationStudentDetail`; etc.
- **The critical enum values** — `ChequeStatus` (3=Bounced, 4=Cancelled); etc.

**Constraint:** changing the system prompt at INFERENCE time is fine (the LoRA layers adapt). Changing it at TRAINING time requires regenerating the JSONL with the new prompt prepended (per `docs/INSTRUCTION_IMPROVEMENT.md`). So the expansion can be tested at inference first, then baked into v28.

**Status:** PENDING — waiting for the user to paste 4 small extracts (top filters, enums, hub tables, raw SQL) from the codebase-analysis toolkit output so the prompt can be built from REAL data, not from the assistant's memory. The extracts will be folded into the prompt and tested against the 50 golden questions.

**Latency impact:** the 2-page prompt adds ~1,000-1,500 input tokens. On CPU (Qwen 2.5 Coder 7B, Q4_K_M), prefill is ~50-100 tok/s — so the added prompt adds ~10-30 seconds of latency. **This is the reason to bump `CTX_SIZE` to 4096** (above). The two changes go together.

### 3B vs 7B model decision — keep the 7B, get a GPU if latency is the problem

The project owner asked whether fine-tuning a 3B model would bring it to par with the 7B after training. The answer is **NO**:

- **For simple queries** (single-table, basic WHERE): 3B gets close (~90-95% of 7B accuracy) — fine-tuning taught it the patterns.
- **For complex queries** (multi-JOIN, comparisons, ambiguity): 3B falls behind (~50-65% of 7B accuracy) — the 3B lacks the reasoning capacity.

**The principle:** fine-tuning adds KNOWLEDGE (your schema, your patterns). It does NOT add REASONING capacity. The gap on complex queries is reasoning, not knowledge. Qwen 2.5 Coder benchmarks confirm: 7B scores 17-22 points higher than 3B on coding benchmarks (HumanEval, MBPP, MultiPL-E).

**Decision:** **keep the 7B model.** If latency is the problem, the right fix is a GPU — a $200 used RTX 3060 (12GB VRAM) makes the 7B run in 1-3 seconds with `--n-gpu-layers 99`. Don't shrink the brain to make it faster.

### chalo-chatbot-persona skill created

A new skill file was created at `chalo-chatbot-persona/SKILL.md` (also copied to `chalo_chatbot/skills/chalo-chatbot-persona/SKILL.md` for in-project access). It captures the project owner's persona, project context, preferences, and the key files for future conversations. The skill auto-triggers when the user mentions ChaloSchools, the chatbot, the pipeline, etc., so the assistant doesn't have to relearn the project state from scratch each session.

> **Note (2026-09-03):** the persona skill is referenced here for documentation purposes; the actual `chalo_chatbot/skills/` folder may or may not be present in the downloaded package depending on when you unpacked it. The canonical copy lives at `chalo-chatbot-persona/SKILL.md` outside the package.

### SESSION_RECORD.md created

A complete project record (~526 lines, ~27 KB) was created at `SESSION_RECORD.md` in the project root. It covers the full journey from "I have a school ERP" to end-to-end verified, with 16 sections including: the beginning, what the user brought, the initial problems, all 8 phases of work, architectural decisions, dev team asks, and key metrics. Read this for the complete narrative history (`PROJECT_STATUS.md` is the snapshot; `SESSION_RECORD.md` is the story).

> **Note (2026-09-03):** `SESSION_RECORD.md` is referenced here for documentation purposes; verify it exists in your downloaded package. If it's missing, ask the project owner for the latest copy.

### What's NOT changed (carried forward)

- The system is still **end-to-end verified on Windows** (2026-08-31) — no code changes since.
- The endpoint count is still **9** (4 user + 5 admin/audit) — no API surface changes.
- The v28 retrain is still pending (waiting on dev-team asks 1.1, 2.1, 3.5).
- Screen-level RBAC (Path B) is still designed-not-implemented (v1.1).
- VAPT ops-side (nginx, Vault, WAF) is still documented-not-applied (pre-VAPT).
- pip-audit (V8) is still not run (pre-deploy).
- The LLM quality gap on "section A" is still a model-quality issue (needs v28 retrain).

### Files changed this session (2026-09-03 — DOC-UPDATE-5)

Documentation-only update — no code changed. The 10 docs updated: `README.md`, `STRUCTURE.md`, `docs/PROJECT_STATUS.md`, `docs/SESSION_HANDOFF.md` (this file), `docs/INSTRUCTION_MANUAL.md`, `docs/COMPLETE_GUIDE.md`, `docs/HOW_IT_WORKS.md`, `docs/API_CONTRACT.md`, `frontend/README.md`, and (where present) `SESSION_RECORD.md`. The worklog at `/home/z/my-project/worklog.md` got a new `DOC-UPDATE-5` entry appended.

### The bottom line

The system remains end-to-end verified. The path to higher accuracy is now clearer: (1) the system prompt expansion (waiting for the user's extracts) is the #1 lever, (2) bumping `CTX_SIZE` 2560 → 4096 unlocks the longer prompt at the cost of ~3-4s latency, (3) the v28 retrain remains the medium-term plan, (4) the 4 new UI/UX items are quality-of-life improvements for the chat UI. The 7B model stays — a GPU is the right fix for latency, not a smaller brain.

---

## Update 2026-09-04 — ERP CODEBASE ANALYSIS INCORPORATED (rules 33-54 + expanded prompt + hint map + v28 dataset)

**This is the session where the codebase-analysis extracts were folded into the chatbot and the LLM training data.** The extracts existed since 2026-09-03 (the `codebase_analysis/` folder: 117 JOIN signatures, 352 mandatory-filter patterns from 11,148 WHERE clauses, 39 business formulas, 168 query templates, 1,399-table data dictionary). Nothing from them had reached the pipeline yet. Now it has.

### What changed (7 files, all code-verified)

1. **`pipeline/semantic_rules.py` — 32 → 54 rules.** 22 new rules:
   - **12 trace-derived** (PRODUCTION_TRACE_OBSERVATIONS §7): STAFF-004 (EmployeeMaster payroll-twin trap), FEEDBACK-001 (FeedbackTicket), FEE-023/024/025 (lumpsum-on-wrong-table, fee-group-vs-fee-head, numeric-ID-without-name), COMM-001 (SMSAuditTrail vs GeneralCallRegister), ATT-001 (not-marked = NOT EXISTS), COMPARE-001 (labelled rows), CLASSNAME-001 (ClassMaster.Name), BONAFIDE-001 / PREADM-001 / REPORTCARD-001 (hallucinated columns).
   - **10 from the mandatory-filters reference** (the ERP's own LINQ usage): SOFTDEL-101/102 (always-filtered tables), STUD-007 (TC filter on counts), STAFF-005 (StaffStatus_ID=1 for salary/attendance), FEE-026 (zero-payment rows), LEAVE-001 (leave approval status), VIS-001 / HIER-001 / PC-001 (visibility/root/sub-subject), STAFF-006 (IsClassTeacher=1).
   - Plus **HINT_MAP + lookup_hints()**: 13 hallucination-trap → correct-approach mappings.
   - Severity policy: HIGH = refuse (≈100% evidence or confirmed hallucination); MEDIUM = warn only. Self-tests extended; all pass.
   - **Measured on the v27 dataset:** the 22 new rules flag 88 examples (2.3%) — checked one-by-one, all genuine buggy labels (missing TC filter, numeric-ID answers, payroll-twin misuse), zero false positives after two evidence-driven refinements (bank queries legitimately use EmployeeMaster; money questions skip the TC filter).
2. **`pipeline/schema_knowledge.py` (NEW)** — the expanded system prompt, built from the REAL extracts: two-term concepts, the core student/fee/teacher join chains, mandatory filters, enums, hallucination traps, formulas. **The frozen v27 text still leads byte-for-byte** (least-derailing design, same append pattern as vocab injection); the ~1,200-token knowledge block follows. Profile via `AI_SECRETARY_PROMPT_PROFILE` (default `expanded`; `legacy` = one-line rollback in `backend/.env`).
3. **`backend/main.py`** — wired to `build_system_prompt()`; version **1.2.0**; `/api/health` now reports `prompt_profile` + 54 rules.
4. **`pipeline/orchestrator.py`** — the guardrail retry now includes **HINT MAP hints** ("The correct approach for the issues above: …"), so the model gets the right path instead of re-hallucinating (trace §8's fix).
5. **`scripts/start_llm.bat`** — `CTX_SIZE` **2560 → 4096** (the documented pairing with the expanded prompt; rollback instructions in the file). ~3-4s extra prefill on CPU.
6. **`training/prepare_data_v28.py` (NEW)** + **`semantic_validation/reference_inputs/training_dataset_v28_additions.jsonl` (NEW, 182 examples)** — the v28 training data, drafted from the ERP's own query templates and the documented blindspot categories (section-filtered counts, current-term date windows, principal, class teachers, SMSAuditTrail, FeedbackTicket, not-marked NOT EXISTS, compare-X-vs-Y, TC lists, cheques, leaves, bus fee, refusals…). **Gate: 0 violations on all 182** (54-rule engine + 475-table catalog column check). 9 examples are corrected replacements for known-buggy v27 labels.
7. **`semantic_validation/semantic_rules.py`** — synced to the 54-rule engine (the training gate now validates against the SAME rules the runtime uses — one engine, two entry points).

### The v28 dataset (built + gated, ready for Kaggle)

`python training/prepare_data_v28.py` produced:
- **4,034 unique examples** (3,867 v27 + 182 additions − 15 replaced duplicates) → `train_v28.jsonl` (3,712) + `val_v28.jsonl` (322) + `training/DATASET_VERSION_V28.txt`
- Every example carries the **improved v28 instruction** (INSTRUCTION_IMPROVEMENT.md §4 refined with the findings; ~430 tokens — fits MAX_SEQ_LENGTH 2560)
- Additions gate: **0 violations** (hard requirement, passed). v27 base: 429 flagged (the known buggy-label set — cleanup still tracked separately).
- Retrain params (per §F): r=16, dropout=0.05, lr=1e-4, warmup=35, epochs=2, MAX_SEQ_LENGTH=2560, quant q5_k_m/q8_0.

### Catalog corrections found while building (dev-team relevant)

- **`StudentAcademicDetail` has NO `BranchID`** (catalog + DDL agree) — branch scope flows through the `AcademicYearID → Branch_Academic_Details.Branch_Id` subquery. The codebase-analysis template T-001's `sad.BranchID` would fail at runtime; the additions scope via the year subquery instead.
- **`Student_Master` has NO delete column** (only Deleted_By/Deleted_Date) — student activeness is the TC filter, full stop. The `sm.Deleted = 0` in template T-005 was a trap; it is now explicitly called out in the knowledge block.
- **`FeesCollection`'s receipt date is `Bill_Date`** (no `Receipt_Date` column).
- `LeaveApplicationEntries`, `ProgressCardMarksDetails`, `SubjectWiseHierarchyList` are NOT in the 475-table runtime catalog (rules reference them for dataset-quality checks; the guardrail refuses them at runtime anyway).

### What to do next (priority order)

1. **Test locally on Windows** (the expanded prompt is the #1 accuracy lever but MUST be benchmarked): start LLM + backend, run the 50 golden questions via `evaluation/evaluate.py`, compare v27-baseline (18/50) vs expanded-prompt. If accuracy drops, set `AI_SECRETARY_PROMPT_PROFILE=legacy` in `backend\.env` (one line — documented rollback) and re-run to confirm.
2. **Retrain v28 on Kaggle**: upload `training/train_v28.jsonl` + `val_v28.jsonl`, run the TRAIN notebook with the §F params, export GGUF via the Colab notebook, name it per convention. Target: <5% semantic mismatch (v25 50% → v27 18% → v28).
3. After v28 lands: point `MODEL_PATH` at the new GGUF, re-run the 50 questions, and switch `schema_knowledge.py`'s frozen lead text to the v28 instruction (one constant — the file documents this).
4. The 4 UI/UX items (order 1 → 2 → 4 → 3) and dev-team asks 1.1 / 2.1 / 3.5 remain pending as before.

### Files changed this session (2026-09-04 — CODE-UPDATE-6)

Code: `pipeline/semantic_rules.py`, `pipeline/schema_knowledge.py` (new), `pipeline/orchestrator.py`, `backend/main.py`, `scripts/start_llm.bat`, `semantic_validation/semantic_rules.py` (synced copy), `training/prepare_data_v28.py` (new), `semantic_validation/reference_inputs/training_dataset_v28_additions.jsonl` (new). Generated: `training/train_v28.jsonl`, `training/val_v28.jsonl`, `training/DATASET_VERSION_V28.txt`, `semantic_validation/reference_inputs/training_dataset_final_v28.jsonl`, validation reports under `semantic_validation/validation_reports/v28/`. Docs: `docs/SESSION_HANDOFF.md` (this update), `docs/PROJECT_STATUS.md`, `README.md`, and the worklog.

### The bottom line

The ERP's tribal knowledge — the joins, filters, and formulas its own code uses — is now IN the system three ways: **54 semantic rules** (validated, zero false positives measured), **the expanded system prompt** (profile-switchable, one-line rollback), and **182 gated v28 training examples** (0 violations). The v28 retrain is unblocked and the dataset is ready. The two changes that "go together" (prompt + CTX 4096) are in. Benchmark on Windows, then retrain.

---

## Update 2026-09-04 (later) — SSMS test kit for the v28 dataset (CODE-UPDATE-7)

The owner tests the dataset against the local DB before any training run. New folder **`sql_tests/`** turns all 4,034 v28 question→SQL pairs into runnable T-SQL so SSMS is the pre-training error gate.

### What was generated (11 files, all pure ASCII, CRLF, deterministic script `D:\aisecretary-z\chalo_chatbot\...` mirror)

- `v28_smoke_first50.sql` — 50 sampled queries (25 classic v27 + 25 new v28 material) for a first quick look with result grids ON.
- `v28_part_01.sql` … `v28_part_09.sql` — the full 4,034 queries, 500 per file (part 9 = last 34). Query text is embedded **byte-identical** to the dataset (verified with random fidelity checks) — any error found here is an error the trained model would produce.
- `v28_run_all.sql` — one-shot runner for all 9 parts (Query → SQLCMD Mode, then F5).
- `README.txt` — plain-English usage + how to read failures.

### How it works (design decisions worth remembering)

- Each query runs in its own GO batch inside TRY/CATCH; failures land in `#ai_errors` (qid, question, error, ms) AND are printed in the Messages tab, so results can be discarded (Query Options → Results → Grid → "Discard results after execution") without losing the error list. Timing per query is captured; run_all prints the 20 slowest.
- `@UserId` / `@SelectedBranchId` are re-declared in every batch (variables don't survive GO) with default `@UserId INT = 1` — the owner changes it once via Find & Replace. `@SelectedBranchId NULL` = all authorized branches.
- Scan results folded into the kit: `@AcademicYearID` is **never used** in the dataset (so not declared); `@StatusLost/@StatusConverted/@StatusNew/@StatusInProgress` appear in ~25 enquiry queries but are **self-declared inside those queries** — no harness support needed. No non-ASCII, no stray GO lines; 2,871 of 4,034 SQL texts are unique (repeats = different questions mapping to the same SQL; all kept so counts match the dataset exactly).
- Q-numbers = line numbers in `training_dataset_final_v28.jsonl` (Q64 is the in-place replaced v27 row; the 166 appended additions form the tail).
- SSMS runs repeated `@variables` natively — the school ExecuteQuery API's repeated-placeholder limitation does not apply to local testing.

### Verification performed

Q1..Q4034 complete and ordered across parts; BEGIN TRY/CATCH balanced in every file; ASCII + CRLF clean; 20-row random dataset-fidelity check = 0 mismatches; apostrophe questions correctly escaped (`''`); multi-statement @Status queries and refusal (`AS Message`) queries embedded intact.

### Files changed (CODE-UPDATE-7)

New: `sql_tests/` (README.txt, v28_smoke_first50.sql, v28_part_01..09.sql, v28_run_all.sql). No code changes anywhere — the chatbot/pipeline are untouched. Docs: this file, `docs/PROJECT_STATUS.md`, worklog. Generator kept at `/home/z/tmp_scripts/gen_ssms.py` (re-runnable if the dataset changes).

### The bottom line

Before spending Kaggle GPU hours: open `sql_tests\README.txt`, set `@UserId` via Find & Replace, run the smoke file, then run all 9 parts. Any Q-number that fails is a label bug to fix in the dataset — the Q-number is its line in `training_dataset_final_v28.jsonl`.

---

## Update 2026-09-04 (evening) — smoke-test findings: 39 syntax-broken v28 labels fixed + syntax gate added (CODE-UPDATE-8)

The owner ran `sql_tests\v28_smoke_first50.sql` on the local DB (the exact workflow the kit was built for) and reported red syntax errors — while the harness printed "SMOKE done: 50 queries, 0 failed". Both facts were diagnostic:

### Finding 1 — 39 broken labels, ALL in the v28 additions (the v27 base is clean)

Parsed all 4,034 outputs with sqlglot (T-SQL dialect): **39 failures, all in the 182 additions; the 3,867 v27 base labels parse 100% clean.** Two bug families, both from the additions generator's template junctions:
- 36 × missing `AND` between two WHERE predicates (e.g. `stf.StaffStatus_ID = 1 sam.AcademicYearID IN (...)`) — categories: class teachers, subject teachers, staff types, attendance-not-marked, marks.
- 3 × double `WHERE` (a shared fee filter fragment started with `WHERE` and was appended after a category WHERE) — fee-collection month/mode/online.

The 54-rule engine could not catch these: it checks filter *presence*, not predicate junctions. Fixed at the SOURCE (the generator's six junction sites), regenerated the additions file — diff confirms exactly the 39 broken outputs changed, nothing else (same 182 questions, same order, same category counts).

### Finding 2 — the harness blindspot ("0 failed" despite red errors)

TRY/CATCH cannot catch compile-time errors: the whole batch fails to compile before TRY ever runs. Since the kit exists to catch invalid columns/tables against the real DB (which are also compile-time errors), this had to be fixed: every query now runs via `EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT', @UserId, @SelectedBranchId` inside TRY/CATCH — the inner batch compiles at EXEC time, so syntax/invalid-column/invalid-object errors become catchable runtime errors, recorded in `#ai_errors` and counted in the summary. (Dynamic SQL cannot see outer variables — hence the parameter passing; the self-declaring `@Status…` queries still work unchanged inside the wrapper.) The kit also pre-parses the whole dataset with sqlglot before generating any file.

### The permanent gates (so this class of bug cannot recur)

- `training/prepare_data_v28.py` now has **HARD GATE #2**: additions must parse as T-SQL with ZERO failures (exit 1 otherwise; requires `pip install sqlglot`); the frozen v27 base is parse-reported non-blocking (currently 0 failures). DATASET_VERSION_V28.txt records PARSE_GATE / ADDITIONS_PARSE_FAILURES / BASE_PARSE_FAILURES / the SYNTAX_FIX note.
- The additions generator (`/tmp/gen_v28.py`, mirrored at `z user scratch` `tmp_scripts/gen_v28.py`) gained the same sqlglot gate in its self-check.

### Rebuilt artifacts (all re-verified)

- `training_dataset_v28_additions.jsonl` — 182 examples, 39 labels repaired, 0 rule violations, 0 parse failures.
- `training_dataset_final_v28.jsonl` / `train_v28.jsonl` (3,712) / `val_v28.jsonl` (322) — rebuilt via the gated pipeline; instruction on every row (1 unique text), 0 parse failures; counts unchanged (4,034 total, 15 replacements).
- `sql_tests\` — regenerated with the sp_executesql harness + updated README.txt; Q1..Q4034 complete/ordered, TRY/CATCH + sp_executesql balanced, CRLF/ASCII clean, 40-row random fidelity check vs dataset = 0 mismatches; all six previously-broken smoke queries verified fixed in-file.

### Files changed (CODE-UPDATE-8)

Data: `semantic_validation/reference_inputs/training_dataset_v28_additions.jsonl` (39 labels repaired), regenerated `training_dataset_final_v28.jsonl`, `training/train_v28.jsonl`, `training/val_v28.jsonl`, `training/DATASET_VERSION_V28.txt`. Code: `training/prepare_data_v28.py` (parse gate), generator script (junction fixes + parse gate). Kit: all 12 `sql_tests\` files regenerated. Docs: this file, `docs/PROJECT_STATUS.md`, worklog.

### The bottom line

The owner's local-DB test caught what three validation layers missed — pattern rules validate *what* a query says, not whether it *runs*. That gap is now closed: the dataset builder hard-gates on real T-SQL parsing, and the SSMS harness counts every error a real execution would raise. Re-run the smoke file: expect "SMOKE done: 50 queries, 0 failed" to now be trustworthy, and the full 9-part run to surface only genuine schema mismatches (if any).

---

## Update 2026-09-04 (night) — smoke test PASSED; run-all SQLCMD-mode fix (CODE-UPDATE-9)

**Owner's local test results:** smoke file = **0 errors, 50/50 clean** — the 39 repaired labels run correctly on the real DB. The full run attempt failed with `Msg 102 Incorrect syntax near ':'` at line 20 — that line is the first `:r v28_part_01.sql` include: SSMS was not in SQLCMD Mode, so nothing executed (no queries ran, no partial results). Not a data problem.

Fixes (usability root-cause, data untouched):
- **NEW `sql_tests\v28_run_all_single_file.sql`** — all 4,034 queries inline in ONE self-contained 6.8 MB script. No SQLCMD mode, no includes: set `@UserId` (Find & Replace in THIS file), press F5. Same sp_executesql harness, 9 per-part summaries + grand total in Messages.
- `v28_run_all.sql` kept for the modular route, now with a loud banner directly above the first `:r` line mapping the exact `Incorrect syntax near ':'` error to the fix (Query → SQLCMD Mode), and pointing to the single-file alternative.
- README.txt rewritten FILES/RUN ORDER sections.

Verification: single file Q1..Q4034 ordered; 4,034 TRY/CATCH + sp_executesql wrappers; one #ai_errors creation; 9 part summaries + 1 grand total; no `:r` commands; ASCII/CRLF clean. **Exhaustive fidelity: 4,034/4,034 extracted @sql literals match the dataset exactly** after quote-unescaping and CRLF→LF normalization (the only differences are T-SQL string escaping `''` and Windows line breaks inside string literals — SQL Server treats both as insignificant whitespace; 253 queries are multi-line). SQLCMD runner: 9 includes, banner at lines 20–27 above the first `:r` (line 28), grand total present.

Files changed: `sql_tests\` regenerated (13 files — README, smoke, 9 parts, 2 runners). Docs: this file, PROJECT_STATUS, worklog. Dataset/training files untouched.

### Next

Owner: run `v28_run_all_single_file.sql` (set `@UserId` first). Grand total line = `ALL DONE: 4034 queries executed. TOTAL FAILURES: N`. Any N > 0 = genuine schema mismatches (Q-numbers map to dataset lines) → fix before Kaggle.

---

## Update 2026-09-04 (afternoon) — OCI Ubuntu quickstart + the 4 UI/UX items implemented (CODE-UPDATE-10)

The owner asked: "I'm going to host the app in Oracle Cloud in Ubuntu — which file do I follow? Where do the files go, commands etc. — and has chat.html been updated? Anything pending in the to-do?" Answer: chat.html had NOT been touched (still "v1.1.0 · 32 rules" while the backend was 1.2.0/54 rules), the 4 UI/UX items from 2026-09-03 were all pending, and there was no Ubuntu-specific install guide. All three gaps closed:

**1. NEW `docs/OCI_UBUNTU_QUICKSTART.md`** — the command-by-command Ubuntu companion to `docs/OCI_DEPLOYMENT.md` (which stays the master for topology/Vault/WAF). Implements the single-instance topology (master guide §5.2):
- Files: `/opt/chalo-ai-secretary/` (chalo_chatbot package, llama.cpp, `models/` for the GGUF, venv), `/var/www/chalo/` (chat.html + audit.html via nginx), `chalo-llm.service` + `chalo-backend.service` systemd units.
- Commands: instance launch (E4.Flex 8 OCPU/24GB, Ubuntu 24.04 for Python 3.12; deadsnakes note for 22.04), OCI security list + **the Ubuntu iptables REJECT gotcha** (OCI Ubuntu images block web ports at the OS layer even when the security list allows them — the #1 first-day failure), Windows scp/rsync upload, venv + requirements (pyodbc optional), llama.cpp prebuilt binary, both systemd units (LLM: `--ctx-size 4096 --threads 8`, MemoryMax 16G; backend: uvicorn on 127.0.0.1:8000), nginx site proxying `/api/` + serving the static chat UI, certbot TLS, curl verification chain, day-2 cheat sheet, troubleshooting table.
- Hosting notes baked in: chat.html Backend URL = EMPTY (same-origin via nginx); LLM URL stays `http://localhost:8080/...` (the backend calls it server-side); the Windows .bat launchers are replaced by the systemd units.

**2. `frontend/chat.html` updated (the first update since 2026-08-31):**
- Footer "v1.1.0 · 32 rules" → **"v1.3.0 · 54 rules"**; both empty-state texts 32 → 54 rules (stale since CODE-UPDATE-6).
- Item 1 — AI disclaimer below the composer: "AI can make mistakes. Please verify important information."
- Item 2 — LLM Model selector in Settings: CLM 1.0 (enabled, default) / CLM 2.0 / CLM 3.0 (disabled, "coming soon"); maps to the existing `model_url` request field; enable + remap when the v28/v29 GGUFs exist.
- Item 3 — "Show thinking process" toggle (default off): progressive stage text under the loading dots while a query runs (timed stages; true SSE stage streaming remains a future backend enhancement — needs `StreamingResponse` in main.py + orchestrator yielding events). Timer cleared on both success and error paths.
- Settings now actually persist to localStorage (frontend/README claimed this since 2026-08-31 but it was never wired up — now real, incl. the new controls).

**3. `backend/main.py` v1.3.0 — item 4 (standard reply for unanswerable questions):**
- outcome ∈ {REFUSED, ERROR, NEEDS_DISAMBIGUATION} → user-facing `message` becomes the standard reply; the original message moves into `detail`; `semantic_violations` + `disambiguation` untouched; response gains `fallback_used`.
- Config priority: `AI_SECRETARY_FALLBACK_MESSAGE` env var > `"fallback_message"` key in `feature_overrides.json` > built-in default ("I'm sorry, I couldn't answer that question. Please try rephrasing it, or ask a different question."). Empty env var disables.
- `/api/health` now reports `fallback_message_active`; `_save_feature_overrides` fixed to preserve non-flag keys (admin PUTs previously would have dropped `fallback_message`).
- Documented in `backend/.env.example` + `backend/.env` (commented out → default active).

**Verification:** main.py py_compile clean + 8-point runtime test (import/version, default, env priority, empty-disables, the replacement branch, health = 54 rules/expanded profile, non-flag key preservation) — all pass. chat.html browser-verified: zero console errors, all new elements present, settings persist across reload, thinking stages render in-flight + clean up on error, mobile 390px fine.

Files changed: `frontend/chat.html`, `backend/main.py`, `backend/.env.example`, `backend/.env`, NEW `docs/OCI_UBUNTU_QUICKSTART.md`, `docs/PROJECT_STATUS.md`, `docs/SESSION_HANDOFF.md` (this section), `frontend/README.md`, worklog. Pipeline/training/dataset untouched.

### Next

Owner: follow `docs/OCI_UBUNTU_QUICKSTART.md` step by step for the OCI Ubuntu host. Still open from earlier updates: run `v28_run_all_single_file.sql` on the local DB (TOTAL FAILURES = genuine schema mismatches to fix before Kaggle), the Windows 50-golden-question benchmark of the expanded prompt, and the v28 retrain. Optional future: SSE stage streaming (item 3's true event mode).

---

## CODE-UPDATE-11 (2026-09-04, late) — v28 training kit + packaging fix; SQL full-run milestone

**Milestone:** the owner ran the full `v28_run_all_single_file.sql` on the local DB — **4,034/4,034 queries, 0 failures**. The v28 labels are now execution-verified on the real schema. That closes the last pre-training gate.

**The blocker I found when asked "do I go to training straight?":** both notebooks still pointed at v27 (dataset slug, `train_v27.jsonl`, 3,867-example counts). The dataset on disk is v28. Training from the downloaded zip would have died at the first path assert.

- NEW `training/finetune_qwen25coder_TRAIN_KAGGLE_v28.ipynb` — slug `chaloschools-sql-dataset-v28`, `train_v28.jsonl`/`val_v28.jsonl`, v28 change-notes header (182 additions / 15 replaced / 39 repaired / 3,712+322), Kaggle steps updated, **`MAX_SEQ_LENGTH` 2560 → 3072** (v28's longest example is 9,111 chars ≈ ~2,700 tokens + template; at 2560 the longest examples would be silently truncated — teaching broken SQL; 3072 is safe, Qwen2.5 handles 32k natively), time estimate ~1–1.5 h on 1× T4.
- NEW `training/finetune_qwen25coder_GGUF_EXPORT_COLAB_v28.ipynb` — `MODEL_VERSION = "v28"`, points at the v28 train notebook, reload `MAX_SEQ_LENGTH` also 3072 (must match training config).
- All other hyperparameters unchanged (r=32, α=32, lr=2e-4, 2 epochs, eff. batch 8, adamw_8bit, Q4_K_M) — data-only update discipline maintained. v27 notebooks kept as reference.
- `training/README.md` rewritten: Kaggle prerequisites (phone-verified account for GPU, ~30 h/week free quota, optional HF token), dataset upload steps, baseline-first recommendation. `STRUCTURE.md` training section matches.

**Packaging bug fixed:** the 2026-09-04 zip was 13 MB / 2,187 entries — 1,959 were `.venv` junk. Cause: `package.sh` assembled an **unquoted** `$EXCLUDE_ARGS` string; the shell glob-expanded `*/.venv/*` against the workspace into literal paths, so zip never applied the excludes. Fix: one `-x` flag with every pattern a separately quoted argument + two post-build gates (junk gate: 0 leaked entries or exit 1; must-ship gate: 13 key files or exit 1). Rebuilt: **4.4 MB / 230 files**, gates green, `.env.example` ships, `.env`/`audit_trail.db` excluded. `package.bat` was already correct (robocopy /XD).

**Dashboard:** download banner added at the top of the review page (zip also served from `public/chalo_chatbot.zip` → works even when workspace download fails — the owner's reported issue, fix explicitly deferred by the owner). Snapshot → v1.3.0; next-steps refreshed (SQL gate DONE; stale "4 UI/UX items pending" removed — they shipped in CODE-UPDATE-10).

**Owner's training path (unblocked):** re-download the zip (the old copy's notebooks point at v27) → upload `training/train_v28.jsonl` + `val_v28.jsonl` to Kaggle as `chaloschools-sql-dataset-v28` → import the v28 train notebook → Accelerator GPU T4 ×2 (notebook uses 1), Internet On → run all (~1–1.5 h) → download `qwen25coder_chaloschools_lora/` from Output → Colab v28 export notebook → Q4_K_M GGUF → point `scripts/start_llm.bat` at it → re-run the 50 golden questions (capture the v27 baseline FIRST for a before/after).

**Verification:** both notebooks JSON-valid + parsed-source checks (v28 paths/counts/version, 3072 in both, hyperparams identical to v27, zero active v27 refs); `package.sh` rebuild gates 0-leak / 13-of-13; zip served HTTP 200 (4,511,354 bytes); dashboard browser-verified (banner, v1.3.0 badge, updated next-steps, zero console errors, mobile footer intact).

Files changed: NEW ×2 (v28 notebooks), `package.sh`, `training/README.md`, `STRUCTURE.md`, `docs/PROJECT_STATUS.md`, `docs/SESSION_HANDOFF.md` (this section), `public/status_snapshot.json`, `src/app/page.tsx`, `public/chalo_chatbot.zip`. Dataset/pipeline/backend untouched.

---

## CODE-UPDATE-12 (2026-09-04, later) — v28 train notebook: OUTPUT_ROOT restored (Kaggle NameError fix)

**What happened:** the owner's first Kaggle run of `finetune_qwen25coder_TRAIN_KAGGLE_v28.ipynb` failed at the SFTConfig cell with `NameError: OUTPUT_ROOT not defined`. Root cause: when I built the v28 notebook by rewriting the paths cell (cell 8), I had only inspected the original v27 cell's first 900 characters — the `OUTPUT_ROOT = "/kaggle/working"` assignment (plus its "Save Version" comment) sits AFTER the asserts and was silently dropped by my full-cell replacement.

**"What else missed?" — answered by audit, not by guess:**
- Defined-name diff (assignments/imports/defs/for-targets across every cell): v27 defines 54 names in TRAIN, 29 in EXPORT → the fixed v28 defines exactly the same sets; the ONLY missing name was `OUTPUT_ROOT`.
- Cell-by-cell source diff v27→v28: TRAIN changed cells 0 (header), 8 (paths — the regression), 10 (`MAX_SEQ_LENGTH` 2560→3072), 22 (time-estimate comment); EXPORT changed cells 0, 6 (`MODEL_VERSION`), 12 (`MAX_SEQ_LENGTH`). Nothing else touched.
- Undefined-name scan (simulated cell-order execution, IPython magics stripped): the fixed TRAIN v28 and the v27 original show identical profiles (the scanner's single remaining flag, `examples`, is a function parameter in both — a scanner artifact, not a bug); EXPORT v28 fully clean.
- The audit script lives at `/home/z/tmp_scripts/audit_v28_notebooks.py` (rerun it after any future notebook edit).

**The fix:** `OUTPUT_ROOT = "/kaggle/working"` + its comment restored verbatim at the end of the v28 paths cell (cell 8). Zip rebuilt (junk gate 0 / must-ship 13/13, 4.4 MB), re-copied to `public/chalo_chatbot.zip`, and the notebook inside the served zip re-extracted and re-verified.

**Owner's unblock options (both work):**
1. Quick, in Kaggle, no re-download: append `OUTPUT_ROOT = "/kaggle/working"` to the end of the paths cell (or add a new cell after it) → Run All. Nothing before the failed cell needs changing; the error hit before training started, so nothing is lost.
2. Clean: re-download the zip from the dashboard banner (banner text updated to explain the bug + the one-line fix; snapshot bumped to v1.3.1).

**Lesson recorded:** never replace a notebook cell from a truncated inspection — always read the full cell source; and diff every name defined before/after any notebook edit (the audit script automates this).

Files changed: `training/finetune_qwen25coder_TRAIN_KAGGLE_v28.ipynb` (cell 8 fix), `public/chalo_chatbot.zip` + `public/status_snapshot.json` (v1.3.1), `src/app/page.tsx` (banner text), `docs/SESSION_HANDOFF.md` + `docs/PROJECT_STATUS.md` (this update), worklog. Export notebook, dataset, pipeline, backend: untouched.

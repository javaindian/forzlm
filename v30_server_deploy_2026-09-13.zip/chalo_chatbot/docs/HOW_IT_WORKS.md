# How the ChaloSchools AI Secretary Works — A Plain-Language Guide

This document explains the whole system end-to-end: what it does, how a question flows through it, what each file contributes, what to check, and how to diagnose problems. No prior context assumed.

---

## 1. The big picture (one paragraph)

**The production deployment is a mobile app** — the chatbot is a menu item in the school's mobile app. The mobile app calls the backend API service described in this document. A local-test Next.js web UI (Claude.ai-style) exists for development only and is NOT part of production.

A school staff member types a question in a chat box ("What is the fee outstanding for the current term?"). A small language model (Qwen 2.5 Coder 7B, fine-tuned by you, running on the same machine via llama.cpp) reads the question and writes a SQL query. Before that query touches the school's database, it passes through a gauntlet of checks — does it only read (never write)? does it reference real tables and columns? does it scope results to the branches the logged-in user is allowed to see? are the school's real names for classes/subjects/sections spelled correctly? does it follow the business rules mined from the school's 1,095 stored procedures? If anything fails, the system refuses with a specific, actionable reason instead of running a wrong query. If everything passes, the query runs and the answer comes back as a table.

The chat interface (a Claude.ai-style web page) shows the answer plus the generated SQL, the pipeline trace, any warnings, and the result rows — so the user (and you, the maintainer) can always see exactly what happened.

---

## 2. The cast of characters (the layers, bottom to top)

Imagine the system as five layers stacked on top of each other. Each layer has one job and trusts the layer below.

```
┌─────────────────────────────────────────────────┐
│  5. Mobile App (production)                     │  ← what the user sees (prod)
│  5. Local-test Web UI (Next.js, dev only)        │  ← dev tool, NOT production
├─────────────────────────────────────────────────┤
│  4. Backend API (FastAPI, port 8000)            │  ← the bridge (mobile-app-facing)
├─────────────────────────────────────────────────┤
│  3. The Pipeline (orchestrator + 15 modules)    │  ← the brain
│  2. The Vocab Engine (synonyms + injection)      │  ← the translator
│  1. The LLM (llama.cpp, port 8080)               │  ← the SQL writer
└─────────────────────────────────────────────────┘
```

**Layer 1 — The LLM.** A fine-tuned Qwen 2.5 Coder 7B model served by llama.cpp at `http://localhost:8080/v1/chat/completions`. You run this separately. It reads a question + a system prompt and writes T-SQL. It's the only "AI" part; everything else is deterministic Python.

**Layer 2 — The Vocab Engine.** The model was trained on one school's data, but each branch has different real names (one branch stores "MATHS", another "Mathematics"; one branch's sections are A/B/C, another's are BRAINY/EXPERT/FOUNDATION). The vocab engine bridges this gap two ways: (a) it can inject the branch's real vocabulary into the prompt before the model writes the SQL (the "FULL mode" — needs a retrain), or (b) it can translate the model's literal to the branch's real literal after the model writes the SQL (the "STOPGAP mode" — works today).

**Layer 3 — The Pipeline.** The conductor. It takes the question through ~10 stages in order, each checking one thing. If any stage fails, the pipeline stops and returns a structured refusal with the reason. If all pass, it executes the query and returns rows. This is where ~6,000 lines of code live.

**Layer 4 — The Backend API.** A small FastAPI server that wraps the pipeline behind HTTP. It receives the user's question + the user's Context JSON (who they are, which branches they can see), calls the pipeline, returns the full result (SQL, rows, violations, trace) as JSON. **The mobile app calls this** (production). The local-test web UI also calls this (dev only). Requires a Bearer auth token. See `docs/API_CONTRACT.md` for the full integration guide.

**Layer 5 — The Frontend.** In production: the **mobile app** (built by your mobile-app team per `docs/API_CONTRACT.md`). In dev: the **local-test web UI** (a Claude.ai-style Next.js page at `src/app/page.tsx` that shows the conversation, sends questions to the backend, renders results richly — SQL code block, result table, violation list, trace). The local-test UI persists conversations to localStorage and is NOT deployed to production.

---

## 3. The journey of one question

Follow a single question — "What is the fee outstanding for the current term?" — through the system. User is logged in as user 116, branch 1 (CHALO INTERNATIONAL SCHOOL).

**Step 1 — The user types and hits Enter.** The chat UI's composer sends the question to the backend at `/api/chat?XTransformPort=8000` along with the user's Context JSON (which branches they can see, what the current academic year is, the branch's real Classes/Sections/Subjects/etc.).

**Step 2 — The backend builds the UserContext.** The `context.py` module parses the Context JSON into a `UserContext` object: user_id=116, is_super_user=False, authorized_branches=[1], selected_branch_id=1. It also resolves the current academic year (the one with `IsCurrentYear=true`) and prepares to inject it as `@AcademicYearID` (a trusted parameter the model doesn't have to guess).

**Step 3 — The pipeline starts.** `orchestrator.py` runs the question through these stages in order:

| # | Stage | What it checks | What happens on failure |
|---|---|---|---|
| 1 | CONTEXT | Is a branch selected? | "Please choose a branch first." |
| 2 | INJECT | Should we inject the branch's vocab? (config: `inject_vocab`) | If ON, the vocab block is appended to the prompt. If OFF, skip. |
| 3 | GENERATE | Call the LLM. Did it produce SQL? Did it get truncated? | If empty or truncated, REFUSED. |
| 4 | GUARDRAIL | Do all tables and columns exist in the schema catalog? Are sensitive tables/columns blocked? | One retry, then REFUSED. |
| 5 | ALIAS_SCOPE | Does any subquery reference an alias defined in a different subquery? (Msg 4104) | REFUSED. |
| 6 | BRANCH_SCOPING | Does the SQL genuinely scope results to the logged-in user's branches via `UserAccountRoleDetails WHERE UserID=@UserId`? | REFUSED. |
| 7 | VALIDATE | For each master-data literal the model wrote (class name, subject, section, etc.) — is it a real value for this branch? | If 0 or 2+ matches, NEEDS_DISAMBIGUATION (asks the user). |
| 8 | SUBSTITUT | If the model wrote "maths" but the branch stores "MATHS", rewrite the SQL literal. | (Silent — improves the SQL.) |
| 9 | SEMANTIC | Run the 59-rule semantic engine. Does the query follow the business rules? | REFUSED with the specific rule + suggested fix. |
| 10 | BIND | Bind `@UserId`, `@SelectedBranchId`, `@AcademicYearID` as real parameters. Check parity (every placeholder has a value, no extras). **Unused SECURITY placeholders (e.g. `@AcademicYearID` if the model scopes by `GETDATE()` instead) are silently dropped — not an error.** | REFUSED (only if a non-SECURITY placeholder is unbound). |
| 11 | EXECUTE | Run the query (dry_run / local_db / api_wrapper). **In `api_wrapper` mode, the school's ExecuteQuery API error message is surfaced in the `message` field (shown in the chat UI), not just `detail`.** | Returns rows, or an execution error with the school's real error message inline. |

**Step 4 — The result comes back.** The orchestrator returns a `PipelineResult` with: outcome (ANSWER/REFUSED/etc.), the SQL, the rows, the trace (the list of stages that ran), any violations. The backend adds the semantic-rules violations and the latency, and returns it all as JSON.

**Step 5 — The UI renders it.** The chat UI shows: an outcome badge (green "Answered" or red "Refused"), the generated SQL in a copyable code block, the result rows in a table (if any), any semantic violations with their suggested fixes, and a collapsible pipeline trace. The user sees exactly what happened and why.

---

## 4. Each file's contribution (what to look at when something breaks)

### The Pipeline (`chalo_chatbot/pipeline/`)

| File | Job | When to suspect it |
|---|---|---|
| `orchestrator.py` | The conductor — runs the 11 stages in order. | If the trace shows a stage failed, look here to see which stage and why. |
| `context.py` | Parses the Context JSON into a `UserContext`; resolves `@AcademicYearID`. | "Please choose a branch first" or wrong academic year. |
| `context_vocab.py` | Parses the per-branch vocab (Classes/Sections/Subjects/etc.) from the Context JSON. | Vocab injection looks wrong or FEE_TERM is missing. |
| `llm_client.py` | Talks to llama.cpp; cleans the output (strips markdown); detects truncation. | "LLM generation failed" or truncated SQL. |
| `guardrail.py` | Schema existence + sensitive-table/column blocklist. | "Table X does not exist" or "Sensitive column selected". |
| `alias_scope_check.py` | Catches Msg 4104 (alias used outside its subquery). | "alias_out_of_scope" refusals. |
| `branch_scoping_gate.py` | Verifies the `@UserId` branch-scoping subquery is present and used. | "could not be confirmed as properly scoped". |
| `semantic_rules.py` | **The 59-rule semantic engine** (32 → 54 → 58 → 59 as of 2026-09-09). Catches wrong term-master joins, missing Lien_Amount, missing Structure_Type, deprecated tables, sensitive columns, bulk PII contact exposure (PII-001), RBAC bypasses, etc. | Any REFUSED with a rule_id like FEE-006, STUD-006, PII-001, RBAC-SALARY. |
| `entity_extractor.py` | Pulls master-data literals (`sub.Name = 'maths'` → {concept_type: SUBJECT, value: 'maths'}) from the SQL so VALIDATE can check them. | A value the model wrote isn't being validated (extractor missed it). |
| `value_resolver.py` | The VALIDATE stage. Checks each extracted value against the branch's real vocab. **With the F6 fix: also returns the real literal to substitute back.** | "I don't recognize 'X' as a section at your branch." or a query that should work returns empty rows (substitution didn't happen). |
| `parameter_binder.py` | Binds `@UserId`/`@SelectedBranchId`/`@AcademicYearID` as real sp_executesql parameters; checks parity. Also has `substitute_validated_values()` (the F6 fix). **Unused SECURITY placeholders (`@AcademicYearID`, `@SelectedBranchId`) are silently dropped — not an error** (the model often scopes by `GETDATE()` instead). | "UnboundParameterError" (only for non-SECURITY placeholders now) or "UnsafeQueryError". |
| `local_executor.py` | Runs the query on a local MS SQL Server via pyodbc + sp_executesql. Has a connection pool. | "Connection failed" or query execution timeouts. |
| `api_executor.py` | Runs the query via the ExecuteQuery ASMX API (your production path). Double-JSON-encodes the request. | "ExecuteQuery API failed" or wrong tenant key. |
| `user_context_api.py` | Calls the real `GetUserContext` API to fetch the Context JSON live. Has Sections + FeeTerms fallbacks. | "GetUserContext API call failed" or stale branch vocab. |
| `concept_store.py` | Legacy SQLite synonym store (kept for compat; the new vocab engine supersedes it). | Unlikely — only used if the new vocab engine isn't wired. |
| `dataset_lookup.py` | Fast-path: if the exact question is in the training set, reuse its SQL (no LLM call). **Config-gated, default OFF** (D1.9 — until labels are cleaned). | If you see "dataset_exact" as the sql_source and the answer is wrong — the cached SQL has a bug. |
| `template_lookups.py` | Fast-paths: generalize "Class 7" → "Class 9" etc. Also config-gated. | Same — only if fast-paths are enabled. |

### The Vocab Engine (`chalo_chatbot/vocab/`)

| File | Job | When to suspect it |
|---|---|---|
| `synonyms.json` | Maps user phrasings to canonical concept keys. "maths"/"Mathematics"/"math" → SUBJ_MATHS. 9 concept types (CLASS, SECTION, SUBJECT, ENQUIRY_STATUS, FEE_HEAD, EXAM_TERM, FEE_TERM, DESIGNATION, ROLE). | A common phrasing isn't resolving (add it here). |
| `inject.py` | The vocab engine itself. Two modes: STOPGAP (validate-and-substitute after generation) and FULL (inject vocab before generation). | Substitution not happening, or injection prompt looks wrong. |

### The Backend (`chalo_chatbot/backend/`)

| File | Job | When to suspect it |
|---|---|---|
| `main.py` | FastAPI server. 4 endpoints: `/api/chat`, `/api/health`, `/api/validate`, `/api/branches`. | CORS errors, 500s, the frontend can't reach the backend. |

### The Frontend (`src/app/page.tsx` + `globals.css`)

| File | Job | When to suspect it |
|---|---|---|
| `page.tsx` | The full chat UI (sidebar, chat area, composer, result panel, settings drawer). | Visual issues, a result isn't rendering, state not persisting. |
| `globals.css` | The Claude.ai warm theme. | Colors look wrong. |
| `layout.tsx` | The page shell + metadata. | Title is wrong. |

---

## 5. The variables to keep on check (the knobs that matter)

> **v97 update (2026-09-07):** All ERP connection settings — GetUserContext URL, ExecuteQuery URL, per-school API keys, and the use_inline_params switch — now live in ONE file: `erp_config.json` at the project root. Edit it and restart the backend; no code changes. Full runbook: `docs/ERP_CONFIG_GUIDE.md`. The rest of this section describes the pre-v97 method and is kept for history.
> For current steps, follow `docs/ERP_CONFIG_GUIDE.md` instead.

These are the settings that change behavior. Track them in `config.yaml` (production) or the Settings drawer (dev).

### Critical (affect correctness)

| Variable | Where | What it does | Safe value |
|---|---|---|---|
| `inject_vocab` | config / Settings drawer | OFF = STOPGAP mode (works with v27). ON = FULL mode (needs v28 retrain). | **OFF** for v27; **ON** only after retraining v28 |
| `fast_paths_enabled` | config / orchestrator | OFF = always call the LLM. ON = use cached training SQL for exact matches. | **OFF** until the 480 flagged training examples are cleaned (D1.9) |
| `mode` | config / Settings drawer | `dry_run` (no execution), `local_db` (MS SQL direct), `api_wrapper` (ExecuteQuery API). | `dry_run` for testing; `api_wrapper` for production |
| `temperature` | config | 0 = deterministic (same question → same SQL). Higher = more creative but less reliable. | **0** (your config already has this — good) |
| `use_inline_params` | config | `true` = inline values as literals (works around the ExecuteQuery API bug). `false` = use sp_executesql parameters. | **Hardcoded `true` in `backend/main.py`** (the school's ExecuteQuery API has a confirmed bug where repeated `@-placeholders` in nested subqueries fail). Will switch to `false` once the dev team fixes the API. |
| `max_auto_pages` | config | How many pages to auto-fetch (each is a sequential HTTP call). | **5** (your config) — raising it increases latency |
| `branch_id` | Settings drawer | Which branch the user is scoped to. NULL = all authorized branches. | Set per user; NULL only for super-users who want cross-branch aggregates |

### Important (affect quality / RBAC)

| Variable | Where | What it does | Watch for |
|---|---|---|---|
| `dataset_lookup_path` | config | Which training dataset the fast-paths cache against. | Your config says `v25` but your real dataset is `v27` — **this is stale; the fast-path may be looking for a file that doesn't exist**. Update to v27 or disable fast-paths. |
| `allowed_tables` (in config.yaml `safety`) | config | A 16-table whitelist. | Where is this enforced? (Open question Q12 — I didn't find it in the code I read. If it's not enforced, the chatbot can query any of the 475 tables.) |
| `blocked_columns` (in config.yaml `safety`) | config | Password, Token, AadhaarNo, PAN, BankAccountNo, etc. | Same — where is this enforced? The semantic_rules.py catches them at the SEMANTIC stage, but defense-in-depth would enforce at the GUARDRAIL stage too. |
| `max_joins` (in config.yaml `safety`) | config | Limit of 8 joins per query. | Where enforced? If nowhere, complex queries can run unboundedly. |
| The frozen system prompt | `demo_runner._read_base_prompt` / `prepare_data.py FROZEN_SYSTEM_PROMPT` | The exact instruction the model was trained on. Any change derails it. | Must match training verbatim. For the v28 retrain, change it in `prepare_data.py` AND regenerate the dataset. |

### Operational (affect latency / stability)

| Variable | Where | What it does | Watch for |
|---|---|---|---|
| `model_url` | config / Settings drawer | The llama.cpp endpoint. | If the LLM is unreachable, you'll see "LLM generation failed: Connection refused". |
| `max_tokens` | config | 768 (the LLM's output cap; raised from 512 on 2026-09-10 — v63 — because 512 truncated some complex SQL). | The pipeline still catches truncation (D1.8) and refuses; normal short answers are unaffected by the higher cap. The whole retry cycle is additionally capped by `AI_SECRETARY_TOTAL_BUDGET` (90 s). |
| `CTX_SIZE` (`--ctx-size`) | `scripts/start_llm.bat` | The llama-server context window. Currently 2560. | **Training-vs-inference distinction (clarified 2026-09-03):** the `2560` came from TRAINING (`MAX_SEQ_LENGTH=2560` — Claude set it to prevent silent truncation; longest training example was ~1,750 tokens). At INFERENCE time the context window is independent — Qwen 2.5 Coder 7B natively supports 32K. **Decision (PENDING):** bump inference `--ctx-size` to 4096 (not 8192 — that might degrade attention on CPU) to unlock a longer system prompt (see §11). Adds ~3-4s latency (acceptable: 15-35s → 18-39s on CPU). |
| `connection_pool_size` | config | 5 (for local_db mode). | If you see "Connection failed" repeatedly, the pool may be exhausted. |
| `TENANT_API_KEY_MAP` | `user_context_api.py` | Maps `TargetDatabase` → API key. Only `V3_TestDatabase` is populated. | For other tenants (e.g. `V3_GG`), you'll see "Invalid API key for the specified tenant." |

---

## 6. How to health-check the system (start here when something's wrong)

When a user reports "the chatbot isn't working," run these checks in order. Each takes <10 seconds and isolates a layer.

### Check 1 — Is the LLM up? (Layer 1)
```bash
curl -s http://localhost:8080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"messages":[{"role":"user","content":"SELECT 1"}],"max_tokens":20}' | head -c 200
```
- **Expected:** a JSON response with `choices[0].message.content`.
- **If it fails:** the llama.cpp server isn't running. Start it: `./llama-server -m your_model.gguf --port 8080`. This is the most common cause of "the chatbot doesn't answer."

### Check 2 — Is the backend up? (Layer 4)
```bash
curl -s http://localhost:8000/api/health
```
- **Expected:** `{"status":"ok","pipeline_loaded":true,"rules_count":32}`.
- **If `pipeline_loaded: false`:** a Python import failed. Check the backend log (`/tmp/backend.log` or your systemd journal).
- **If connection refused:** the FastAPI server isn't running. Start it: `cd chalo_chatbot/backend && python3 -m uvicorn main:app --port 8000`.

### Check 3 — Is the frontend up? (Layer 5)
```bash
curl -s -o /dev/null -w "HTTP %{http_code}\n" http://localhost:3000
```
- **Expected:** `HTTP 200`.
- **If 500:** a TypeScript/compile error. Check `dev.log`.
- **If connection refused:** the Next.js dev server isn't running. `cd /home/z/my-project && npm run dev`.

### Check 4 — Does the full pipeline run end-to-end? (Layers 1-4 together)
```bash
curl -s -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"question":"how many students are in class 10","context_json":<paste a real Context JSON>,"mode":"dry_run","branch_id":1}' | python3 -m json.tool
```
- **Expected outcome:** `ANSWER` with `sql` populated (dry_run doesn't execute, so no rows, but the SQL should be there).
- **If `outcome: ERROR` with "LLM generation failed":** go back to Check 1.
- **If `outcome: REFUSED` at `stage: GUARDRAIL`:** the model hallucinated a table/column. Look at the `detail` field — it names the bad column.
- **If `outcome: REFUSED` at `stage: BRANCH_SCOPING`:** the model forgot the `@UserId` scoping subquery. This is a model-quality issue (the v27 model sometimes drops it under phrasing pressure).
- **If `outcome: REFUSED` at `stage: SEMANTIC`:** a semantic rule fired. Look at `semantic_violations` — each has a `rule_id` (e.g. `FEE-006`), a `message`, and a `suggested_fix`. The fix tells you what the SQL should say.

### Check 5 — Is the semantic engine itself healthy?
```bash
curl -s -X POST http://localhost:8000/api/validate \
  -H "Content-Type: application/json" \
  -d '{"sql":"SELECT Password FROM UserAccountMaster","question":"show passwords"}'
```
- **Expected:** `{"violation_count":1,"high_count":1}` with a `SENSITIVE-COL` violation.
- **If 0 violations:** the semantic engine isn't loaded. Check Check 2.

### Check 6 — Is the Context JSON valid?
```bash
curl -s -X POST http://localhost:8000/api/branches \
  -H "Content-Type: application/json" \
  -d '<paste your Context JSON>'
```
- **Expected:** a list of branches the user can see.
- **If it errors:** the Context JSON is malformed or missing `UserMasterDetails`. Fix the auth flow that produces it.

### Check 7 — Is the ExecuteQuery API reachable? (production only)
Run a trivial query in `api_wrapper` mode:
```bash
curl -s -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"question":"SELECT 1 as test","context_json":<...>,"mode":"api_wrapper","branch_id":1}' | python3 -m json.tool
```
- **If `outcome: ERROR` with "ExecuteQuery API failed":** the API is down, the api_key is wrong, or the target_database is wrong. Check `TENANT_API_KEY_MAP` in `user_context_api.py`.

---

## 7. What can go wrong and where to look (the troubleshooting matrix)

| Symptom | First place to look | Second place |
|---|---|---|
| "The chatbot doesn't answer at all" | Check 1 (LLM up?) | Check 2 (backend up?) |
| "It answers but the SQL is wrong" | The `semantic_violations` in the result — they name the bug | The `trace` — which stage produced the SQL |
| "It refuses with 'A' not recognized as a section" | The branch's real Sections in the Context JSON — your branch may use ability-stream names (BRAINY/EXPERT), not A/B/C | The validate-and-substitute path (vocab engine) — it should have asked for clarification, not refused |
| "It refuses with 'Principal_ID does not exist'" | The model hallucinated a column — the guardrail caught it (good). Real column is `BranchMaster.Principal` | Training coverage — add "who is the principal" examples (round-2 §27) |
| "Fee outstanding mixes up fee term and exam term" | The model joined `ExamTermMaster` instead of `TermMaster` — the SEMANTIC stage (FEE-006) should catch it | Training coverage — add current-term-fee examples (round-1 §1) |
| "The query returns zero rows when it shouldn't" | The validate-and-substitute path (F6) — did it rewrite the literal? Check the trace for `substit: rewrote N literal(s)` | The branch's real vocab in the Context JSON — the model's literal may not be a synonym |
| "Latency is 30+ seconds" | The LLM is on CPU and the query is long — switch to CTE-form scoping (D1.7) to cut length 30-50% | The `max_auto_pages` — sequential pagination; lower it |
| "Super-user sees zero branches" | The branch-scoping subquery is missing the `UNION SELECT ID FROM BranchMaster WHERE EXISTS (... IsSuperUser=1)` half | RBAC-001 semantic rule should fire — check `semantic_violations` |
| "Cross-branch data leak" | The query has no `@UserId` scoping — the BRANCH_SCOPING stage should have refused | If it didn't refuse, the gate's regex missed a pattern — check `branch_scoping_gate.py` |
| "Sensitive data exposed (passwords, Aadhaar)" | The SEMANTIC stage (SENSITIVE-COL) should have refused | If not, the column isn't in `SENSITIVE_COLUMN_OWNERS` in `semantic_rules.py` — add it |
| "Fast-path served a wrong answer" | The cached training SQL has a bug — disable fast-paths (`fast_paths_enabled: false`) | Clean the flagged examples (D6 triage) then re-enable |

---

## 8. The relationship between the components (a mental model)

Think of it as a **courtroom**:

- The **LLM** is the defendant — it produces a statement (the SQL) that may or may not be true.
- The **Guardrail** is the bailiff — checks the defendant isn't carrying contraband (nonexistent tables, sensitive columns).
- The **Alias-scope check** is the grammarian — catches structural errors (an alias used outside its scope).
- The **Branch-scoping gate** is the border guard — checks the defendant is only accessing territory they're authorized for (their branches).
- The **Value resolver** is the translator — checks the defendant's words ("maths") match the local dialect ("MATHS") and rewrites them if needed.
- The **Semantic rules engine** is the judge — checks the statement follows the law (the 32 business rules mined from the SPs). Each violation comes with a suggested sentence correction.
- The **Binder** is the court clerk — makes sure every name on the docket has a person attached (every `@placeholder` has a value).
- The **Executor** is the bailiff again — carries out the (now-vetted) order.

If any of them object, the case is dismissed with a written reason (the REFUSED outcome). The user sees the reason and can rephrase.

---

## 9. The single most important thing to understand

**The system is designed to fail closed.** A refusal is not a bug — it's the system working. Every refusal comes with a specific reason (the rule_id, the message, the suggested fix) that tells you exactly what to change. When a user reports "it refused my question," the first step is to look at the `semantic_violations` and the `trace` in the result — they tell you which stage refused and why.

The wrong mental model is "the chatbot should answer everything." The right mental model is "the chatbot should answer everything it can answer correctly, and refuse clearly when it can't." A confident wrong answer is far worse than a clear refusal.

---

## 10. Where to learn more

- `docs/GUIDELINES.md` — the single source of truth for all problems, mitigations, and decisions (735 lines).
- `docs/BLINDSPOT_AUDIT.md` — the round-by-round findings history with root-cause proofs.
- `semantic_validation/README.md` — how to use the semantic validation suite (the training-data gate).
- `semantic_validation/semantic_rules_catalog.md` — the full 78-rule catalog with SP evidence.
- `docs/ARCHITECTURE.md` — (Batch 3, pending) the formal architecture diagram + data flow.
- `SESSION_RECORD.md` (added 2026-09-03) — the complete project narrative (~526 lines, 16 sections). Read this for the full story; this doc is the technical entry point.

This document is the entry point. Read it first; drill into the others when you need depth on a specific area.

---

## 11. Planned improvements (added 2026-09-03 — DOC-UPDATE-5)

This section captures the improvements identified on 2026-09-03 that are **not yet implemented**. They are tracked across `docs/PROJECT_STATUS.md` §4.6, `docs/SESSION_HANDOFF.md` (2026-09-03 update), `docs/INSTRUCTION_MANUAL.md` §2.8-2.9, `docs/COMPLETE_GUIDE.md` §4.7-4.8, and `README.md` "Planned features / Roadmap".

### 11.1 The 4 new UI/UX items (pending — none implemented)

1. **AI disclaimer in `chat.html`** — a subtle footer note: *"AI can make mistakes. Please verify important information."* Pure HTML/CSS work in `frontend/chat.html`.
2. **LLM model selector dropdown** in `chat.html` → Settings — three options: **Chalo Language Model 1.0** (current, selected by default), **CLM 2.0** (disabled — coming soon), **CLM 3.0** (disabled — coming soon). Maps to a different GGUF path in `scripts/start_llm.bat` or a different `model_url` in the request body.
3. **Configurable "show thinking process" toggle** — show pipeline stages progressively ("Understanding your question...", "Generating SQL...", "Validating against 59 rules...", "Querying the database..."). Toggle in Settings (default OFF). Needs backend streaming (SSE) — today the trace is returned only at the end. Touches `backend/main.py` + `pipeline/orchestrator.py` + `frontend/chat.html`.
4. **Standard reply for unanswerable questions (configurable)** — when `outcome ∈ {REFUSED, ERROR, NEEDS_DISAMBIGUATION}`, show a single admin-configurable message in the user-facing `message` field. Default: *"I'm sorry, I couldn't answer that question. Please try rephrasing it, or ask a different question."* Configurable via `AI_SECRETARY_FALLBACK_MESSAGE` env var in `backend/.env` or a new key in `backend/feature_overrides.json`. The raw `detail` + `semantic_violations` stay in the response body for debugging.

### 11.2 System prompt expansion (the #1 accuracy lever without retraining)

The current system prompt is one paragraph (~80 tokens). The plan is to expand it to ~2 pages (~1,000-1,500 tokens) covering: the 7 known schema gotchas (`BusFeeStrucure` misspelling, `ExamTermMaster` column names, `Receipt_Amt` not `Amt`, etc.); the top 5 business formulas (fee outstanding = `Amount - Concession_Amt - Paid_Amt - Lien_Amount`, etc.); the top 10 mandatory filters (`IsActive=1`, `IsTCIssued=0`, `ChequeStatus_ID NOT IN (3,4)`, etc.); the key JOIN patterns (student → `ClassMaster` + `SectionMaster`; fees → `FeesInformationStudentDetail`); and the critical enum values (`ChequeStatus`: 3=Bounced, 4=Cancelled). **Status:** PENDING — waiting for the user to paste 4 small extracts (top filters, enums, hub tables, raw SQL) from the codebase-analysis toolkit output. **Constraint:** changing the prompt at inference is fine (LoRA adapts); changing it at training time requires regenerating the JSONL (per `docs/INSTRUCTION_IMPROVEMENT.md`). Test at inference first, then bake into v28.

### 11.3 CTX_SIZE bump (2560 → 4096)

Goes together with §11.2 above — see the `CTX_SIZE` row in the variables table in §5. The `CTX_SIZE=2560` in `scripts/start_llm.bat` is a TRAINING constraint, not an INFERENCE constraint. At inference, Qwen 2.5 Coder 7B natively supports 32K context. Bumping to 4096 unlocks the 2-page system prompt above. Adds ~3-4s latency (acceptable: 15-35s → 18-39s on CPU). The `--ctx-size 2560` lines in the systemd `ExecStart` examples in `docs/INSTRUCTION_MANUAL.md` §1.2 Step 7 and `docs/COMPLETE_GUIDE.md` §2.2 Step 6 should also be updated when this goes in.

### 11.4 3B vs 7B decision — keep the 7B, get a GPU if latency is the problem

The project owner asked whether fine-tuning a 3B model would bring it to par with the 7B after training. The answer is **NO**:

- **For simple queries** (single-table, basic WHERE): 3B gets close (~90-95% of 7B accuracy) — fine-tuning taught it the patterns.
- **For complex queries** (multi-JOIN, comparisons, ambiguity): 3B falls behind (~50-65% of 7B accuracy) — the 3B lacks the reasoning capacity.

**The principle:** fine-tuning adds KNOWLEDGE (your schema, your patterns). It does NOT add REASONING capacity. The gap on complex queries is reasoning, not knowledge. Qwen 2.5 Coder benchmarks confirm: 7B scores 17-22 points higher than 3B on coding benchmarks (HumanEval, MBPP, MultiPL-E).

**Decision:** **keep the 7B model.** If latency is the problem, the right fix is a GPU — a $200 used RTX 3060 (12GB VRAM) makes the 7B run in 1-3 seconds with `--n-gpu-layers 99`. Don't shrink the brain to make it faster.

# ChaloSchools AI Secretary — Project Status

**As of:** 2026-09-10
**Version:** 1.4.0 (2026-09-10: v63 quick-wins — bare-number class templates, Branch_Id auto-repair, 90 s total-cycle budget, max_tokens 768, 6 rotating chips from a 30-question verified pool; v29 dataset FINAL 3,651/320 at 59 rules incl. Stage B3 column fitness; audit package built. 2026-09-07: v97 erp_config.json. 2026-09-04: codebase analysis — 54 rules, expanded prompt; end-to-end verified 2026-08-31)

---

## 1. Executive summary

> **v63/v29 update (2026-09-10) — read this first:**
> - **v29 dataset generation is DONE**: 3,651 train / 320 val, checker-clean at **59 rules** (32 → 54 on 09-04 → 58 → 59 on 09-09), incl. Stage B3 column fitness (390 per-student lists now carry AdmissionNo + StudentName + Class + Section; centum-holder LIST rows; 22 documented residue exceptions). Full log: `training/v29_BUILD_REPORT.md`.
> - **Four no-retrain patches shipped in code** (see `V63_RELEASE_NOTES.md`): bare-number class fastpath ("how many students are in 8" no longer takes >1 min), Branch_Id→BranchID auto-repair, `AI_SECRETARY_TOTAL_BUDGET` = 90 s (owner-approved max wait; bot stops retrying and answers honestly with chips), `max_tokens` 512→768.
> - **UX**: 6 chips visible (rotate per refresh) from a 30-question verified pool. **Date display rule (09-10 addendum): every date users see is dd-mm-yyyy** — enforced at one backend serialization point (see `V63_RELEASE_NOTES.md` §11).
> - **Deploy pending on the owner**: the v63 bundle (10 files) — until deployed, **PII-001 (bulk contact block) is NOT live on the VPS** and the leak is still reachable.
> - **Next gates**: owner's third-party audit (Stage D) → Stage E (prompt freeze + fastpath rebuild from v29 + 15-question acceptance) → Kaggle retrain (~6–8 h).
> - The rest of this document describes earlier states (v1.3.0 era and before) and is kept for history.

> **v97 update (2026-09-07):** All ERP connection settings — GetUserContext URL, ExecuteQuery URL, per-school API keys, and the use_inline_params switch — now live in ONE file: `erp_config.json` at the project root. Edit it and restart the backend; no code changes. Full runbook: `docs/ERP_CONFIG_GUIDE.md`. The rest of this section describes the pre-v97 method and is kept for history.

The ChaloSchools AI Secretary chatbot backend is **feature-complete for v1.0** and **now verified end-to-end on Windows** (2026-08-31). The pipeline (17 files, ~6,000 LOC), the 32-rule semantic engine, the vocab engine (9 concept types), the accuracy harness (50 golden questions), the training-data gate, the FastAPI backend (mobile-app-facing, with Bearer auth + OpenAPI spec, **9 endpoints: 4 user + 5 admin/audit**), and 6 documentation files are all delivered and verified.

**What's pending:** the v28 retrain (your decision on Q16), class-teacher row-level RBAC (your decision on Q-RBAC), production hardening to the full OCI topology (Vault/WAF/LB — the systemd/nginx Ubuntu path is now documented, see `docs/OCI_UBUNTU_QUICKSTART.md`), the mobile-app integration (your mobile-app team's work, per `API_CONTRACT.md`). **The 4 UI/UX items added 2026-09-03 are now IMPLEMENTED** (see §4.6 and the 2026-09-04 CODE-UPDATE-10 update below).

**Known limitation:** the v27 model was trained without a vocab block, so the system runs in STOPGAP mode (validate-and-substitute) by default. The FULL mode (vocab injection) requires the v28 retrain.

---

## 2. What's done (verified)

### Batch 1 — the working core (7,227 LOC, 23 files)

| Component | Files | LOC | Status |
|---|---|---|---|
| **Pipeline** (17 modules) | `pipeline/*.py` | 6,137 | ✅ All import clean; end-to-end verified |
| **Vocab engine** | `vocab/inject.py` + `synonyms.json` | 513 | ✅ Self-test passes; 9 concept types |
| **Accuracy harness** | `evaluation/*` | 577 | ✅ 50 golden Qs; 4-axis scoring; runner works |
| **Semantic validation** | `semantic_validation/*` | ~5,000 | ✅ 32 rules; v27 validation runs (548 flagged) |

**Key verifications:**
- ✅ All 17 pipeline modules import cleanly.
- ✅ 32-rule semantic engine: self-test passes; v27 run flags 548 examples (13.5%) with 741 violations (688 HIGH).
- ✅ Vocab engine: `maths`/`Maths`/`Mathematics`/`math` all resolve to `MATHS`; FULL-mode injection prompt lists all 7 concept types.
- ✅ End-to-end F6 fix: `validate: 'maths' → 'MATHS' (synonym_exact)` + `substit: rewrote 1 literal(s)` — the SQL literal is rewritten before the semantic check.
- ✅ Accuracy harness scoring: correct SQL → 3/3, wrong SQL (ExamTermMaster join) → 1/3 with 8 violations, sensitive refusal → 3/3.

### Batch 2 — the chatbot app + mobile-app split

| Component | Files | Status |
|---|---|---|
| **FastAPI backend** (mobile-app-facing) | `backend/main.py` | ✅ 9 endpoints (4 user + 5 admin/audit), Bearer auth, OpenAPI spec auto-generated |
| **Local-test Next.js UI** (Claude.ai-style) | `src/app/page.tsx` (875 LOC) | ✅ Renders, ESLint clean, sends Bearer token |
| **API contract** (for mobile-app team) | `docs/API_CONTRACT.md` (270 lines) | ✅ Complete |
| **Backend config** | `backend/.env.example` | ✅ Auth tokens, CORS, LLM URL, DB vars |

**Key verifications:**
- ✅ Backend health: `{"status":"ok","pipeline_loaded":true,"rules_count":32}`
- ✅ Chat without auth → 401 with clear message.
- ✅ Chat with auth → pipeline runs (ERROR on no LLM — expected).
- ✅ OpenAPI spec at `/openapi.json` + interactive docs at `/docs`.
- ✅ Frontend lint clean; renders the sidebar, header, empty state, 6 suggested questions, composer.

### Documentation (20 files in `docs/`)

**New:** `DATA_DICTIONARY.md` (25,915 lines, 526KB) — the living data dictionary for all 475 tables + 8,685 columns. 25 confirmed (5.3%), 13 partial (2.7%), 432 pending (90.9%), 5 deprecated. Status-tagged per table + per column for trackability. The dev team fills in the PENDING items over time.

**New:** `INSTRUCTION_MANUAL.md` (+ `.pdf`) — the consolidated instruction doc for Infra, Dev, and Admin teams (655 lines). Covers what to do, how to do, what NOT to do, troubleshooting, and maintenance for each team.

| Doc | Lines | Audience |
|---|---|---|
| `HOW_IT_WORKS.md` | 285 | Maintainers (plain-language guide) |
| `API_CONTRACT.md` | 270 | Mobile-app team |
| `IMPROVEMENTS_VS_AISEC.md` | 132 | Reviewers (what I changed vs. the original) |
| `PRD.md` | 220 | Project owner, stakeholders |
| `PROJECT_STATUS.md` | this file | Everyone |
| `SESSION_HANDOFF.md` | (below) | The next session / the next developer |

Plus the pre-existing:
- `docs/GUIDELINES.md` (735 lines) — single source of truth
- `docs/BLINDSPOT_AUDIT.md` (~800 lines) — findings history
- `semantic_validation/README.md` (~170 lines) — how to validate the training data
- `semantic_validation/semantic_rules_catalog.md` (~570 lines) — the 78-rule catalog

---

## 3. Metrics

### Code
- **Total Python LOC:** ~12,000 (pipeline 6,137 + vocab 513 + evaluation 577 + semantic_validation ~5,000 + backend 250)
- **Total TypeScript LOC:** ~875 (the local-test UI)
- **Total docs:** ~3,500 lines across 10 markdown files
- **Total files:** ~50 (Python + TypeScript + JSON + MD + config)

### Quality
- **Python imports:** 17/17 modules import cleanly.
- **ESLint:** clean (no errors).
- **Semantic engine self-test:** 13/13 cases pass.
- **v27 training-data audit:** 548 flagged (13.5%), 741 violations, 688 HIGH.
- **End-to-end F6 fix:** verified (validate-and-substitute rewrites the literal).

### Test coverage
- **Unit:** semantic engine self-test (13 cases), vocab engine self-test (6 cases), scoring self-test (3 cases).
- **Integration:** end-to-end pipeline with a stub LLM (the F6 fix trace).
- **Dataset:** the 32-rule engine against all 3,867 v27 examples.
- **API:** health, chat-with-auth, chat-without-auth, OpenAPI spec.
- **UI:** agent-browser snapshot confirms structure (sidebar, header, empty state, composer).

### What's NOT tested (needs your environment)
- The full pipeline with a real LLM (llama.cpp at port 8080) — needs your machine.
- The `api_wrapper` mode against the real ExecuteQuery endpoint — needs your school's API.
- The `local_db` mode against a real MS SQL Server — needs your DB.
- The mobile-app integration — needs your mobile-app team's build.

---

## 4. What's pending

### Batch 3 (the final delivery — config + zip)
- [ ] `chalo_chatbot/config/config.yaml.example` — the production config template
- [ ] `chalo_chatbot/docs/ARCHITECTURE.md` — the formal architecture diagram
- [ ] The final zip of `chalo_chatbot/`

### Dev team asks (see `docs/DEV_TEAM_ASKS.md`)

9 asks, 3 priorities. **P1 (blocking v1.0):** 1.1 standardize GetUserContext (add Sections + FeeTerms), 1.2 confirm SectionMaster source. **P2 (for v28):** 2.1 ExecuteQuery bug status, 2.2 per-tenant API keys, 2.3 10-20 failing examples. **P3 (nice-to-have):** 3.1 audit trail, 3.2 context fetch simplification, 3.3 Branch_Academic_Details confirmation. The cheapest high-value ask: 2.3.

### Pending your decisions
| # | Decision | What's blocked |
|---|---|---|
| Q11 | School-routing code (parses `username@shortschoolname` → DB target) | Multi-tenant deployment |
| Q12 | Where `allowed_tables`/`blocked_columns`/`max_joins` are enforced | Security hardening |
| Q16 | Training notebooks: (a) updated, (b) documented diff, (c) untouched | The v28 retrain delivery |
| Q-RBAC | Is class-teacher row-level RBAC a requirement? | D5 implementation |
| Q-SectionSource | Is `SectionMaster` the right table for ability-stream branches? | The vocab engine + Option A retrain |

### Pending the v28 retrain (after Q16 decision)
- [ ] Regenerate the JSONL with the vocab block prepended (per branch)
- [ ] Run `prepare_data.py` gate (must pass with 0 HIGH violations)
- [ ] Fine-tune with the §F parameter changes (r=16/32, dropout 0.05-0.1, lr 1e-4, warmup 35-50, MAX_SEQ_LENGTH 2560 confirmed-safe)
- [ ] Export with q5_k_m or q8_0 (avoid double-4-bit)
- [ ] Run the accuracy harness (50 golden Qs) — must meet the §7 targets
- [ ] Flip `inject_vocab` to ON in config

### Pending the mobile-app team (per `API_CONTRACT.md`)
- [ ] Implement the 4-endpoint client (health, chat, branches, validate)
- [ ] Bearer auth integration (token from school's auth system)
- [ ] Branch picker UX (when user has 2+ branches)
- [ ] Disambiguation UX (when backend returns `NEEDS_DISAMBIGUATION`)
- [ ] Result rendering (table for ANSWER, message for REFUSED, candidates for DISAMBIGUATION)
- [ ] Latency UX (loading indicator; "taking longer than usual" at 15s)
- [ ] Pagination (Load more / infinite scroll)

### Pending ops (after Batch 3)
- [ ] Docker / systemd / nginx deployment config
- [ ] Rate limiting (per-user 20/min, per-IP 100/min)
- [ ] Audit logging (the `audit_trail.db` pattern from the original Streamlit app)
- [ ] Monitoring (the `/api/health` endpoint + alerting)
- [ ] Pen-test (sensitive tables, cross-branch leak, SQL injection, prompt injection)

### UI/UX features (added 2026-09-03 — DOC-UPDATE-5; IMPLEMENTED 2026-09-04, see bottom of this file)

These 4 items were requested by the project owner on 2026-09-03. The table preserves the original spec; the implementation status is in the line below and the CODE-UPDATE-10 section at the bottom of this file.

| # | Item | Where it lives | Notes |
|---|---|---|---|
| 1 | **AI disclaimer in `chat.html`** | `frontend/chat.html` (subtle footer note below the input box) | Suggested wording: *"AI can make mistakes. Please verify important information."* Should be subtle — not a modal. |
| 2 | **LLM model selector dropdown** | `frontend/chat.html` → Settings panel | Three options: **Chalo Language Model 1.0** (current — enabled/selected by default), **Chalo Language Model 2.0** (disabled — coming soon), **Chalo Language Model 3.0** (disabled — coming soon). Future-proofing: when v28 (CLM 2.0) and v29 (CLM 3.0) are trained, users can switch. The selection maps to a different GGUF file path in `scripts/start_llm.bat` (or a different `model_url` in the request body to `/api/chat`). |
| 3 | **Configurable "show thinking process" toggle** | `frontend/chat.html` → Settings panel (show/hide toggle) | Because there's 15-35s latency on CPU, show the pipeline stages as they happen ("Understanding your question...", "Generating SQL...", "Validating against 32 rules...", "Querying the database..."). When enabled: progressive status updates. When disabled (default): just the loading dots (current behavior). Needs a small backend change to emit stage events (today the trace is returned only at the end). |
| 4 | **Standard reply for unanswerable questions (configurable)** | Backend config (env var `AI_SECRETARY_FALLBACK_MESSAGE` in `backend/.env`, or a new key in `backend/feature_overrides.json`) | When the system can't answer (`REFUSED`, `ERROR`, or `NEEDS_DISAMBIGUATION`), show a single standard configurable reply instead of the raw error. Suggested default: *"I'm sorry, I couldn't answer that question. Please try rephrasing it, or ask a different question."* The raw `detail` + `semantic_violations` stay in the response body for debugging; only the user-facing `message` is replaced. |

**Status:** ✅ **ALL 4 IMPLEMENTED (2026-09-04, CODE-UPDATE-10)** — see the update section at the bottom of this file for exactly how each one shipped. The only deferred piece: true per-stage SSE streaming for item 3 (the frontend toggle ships now with timed stage text; the backend change is a future enhancement).

---

## 5. Known issues

| Issue | Severity | Workaround |
|---|---|---|
| The dev server in this sandbox dies after 2-3 requests (process persistence issue) | Low (sandbox-only) | On your machine, `npm run dev` is stable. The page compiles HTTP 200 and renders correctly. |
| `config.yaml`'s `dataset_lookup_path` is `v25` (stale; your real dataset is v27) | Medium | Update to v27, or keep fast-paths disabled (default). |
| The `allowed_tables` whitelist isn't enforced (open Q12) | Medium | The semantic engine catches sensitive tables/columns; the 16-table whitelist itself isn't enforced anywhere I found. |
| The super-user `UNION` in branch scoping isn't always present in v27 training SQL | Medium | The `RBAC-001` semantic rule catches it; the v28 retrain should standardize on the full pattern. |
| The next dev server in this sandbox can't be reached by agent-browser (network namespace isolation) | Low (sandbox-only) | curl confirms HTTP 200; the page renders. Visual verification on your machine. |
| ~~Bind stage raises `UnboundParameterError` for unused `@AcademicYearID` / `@SelectedBranchId`~~ | ~~High~~ | **FIXED (2026-08-31).** `parameter_binder.py` now silently drops unused SECURITY placeholders instead of raising. The model is allowed to scope by `GETDATE()` instead of `@AcademicYearID`. |
| ~~`api_wrapper` mode silently passed empty `api_wrapper_url` to urllib → `unknown url type: ''`~~ | ~~High~~ | **FIXED (2026-08-31).** `backend/main.py` now validates `api_wrapper_url` + `target_database` early and returns a clear 400 if either is empty. |
| ~~The LLM ignores "section A" in "class 10 section A" (returns count for all sections)~~ | Medium (model quality) | **NOT FIXED — needs v28 retrain.** The v27 model wasn't trained on enough class+section examples. The end-to-end test query ("how many students are there in 10 a?") returned the count for ALL of class 10, not section A. |

---

## 6. What needs to happen next (priority order)

1. **You decide Q16** (training notebooks) → I deliver the v28 retrain path (Batch 3 + the updated notebooks if (a)).
2. **You decide Q-RBAC** (class-teacher row-level RBAC) → I implement D5 if yes.
3. **You retrain v28** (your team) → the `prepare_data.py` gate ensures clean labels; the §F params are documented.
4. **You run the accuracy harness** (`evaluation/evaluate.py`) → measures v27 vs v28; must meet §7 targets.
5. **Your mobile-app team reads `API_CONTRACT.md`** → builds the mobile client.
6. **You deploy** (Batch 3 + ops) → Docker/systemd/nginx + rate limiting + monitoring.
7. **You pen-test** → sensitive tables, cross-branch leak, SQL injection, prompt injection.

---

## 7. File map (where everything is)

```
/home/z/my-project/
├── chalo_chatbot/                    ← the package (production backend + dev UI + docs)
│   ├── README.md                     ← start here
│   ├── backend/                      ← the production API service
│   │   ├── main.py                    ← FastAPI, 9 endpoints (4 user + 5 admin/audit), Bearer auth
│   │   └── .env.example
│   ├── pipeline/                      ← 17 modules, ~6,000 LOC
│   ├── vocab/                        ← the vocab engine
│   ├── evaluation/                   ← the accuracy harness
│   ├── semantic_validation/          ← the training-data gate
│   ├── docs/                         ← 6 docs (PRD, status, handoff, etc.)
│   └── config/                       ← (Batch 3 — pending)
├── src/app/                          ← the local-test Next.js UI (dev only)
│   ├── page.tsx                      ← the Claude.ai-style chat UI
│   ├── layout.tsx, globals.css
│   └── LOCAL_TEST_UI_README.md       ← "DEV ONLY" marker
└ GUIDELINES.md, BLINDSPOT_AUDIT.md, schema_audit_report.md ← (the audit history, in the root)
```

---

## 8. How to verify it works (the 5-minute smoke test)

```bash
# 1. Start the backend
cd /home/z/my-project/chalo_chatbot/backend
cp .env.example .env
python3 -m uvicorn main:app --host 0.0.0.0 --port 8000

# 2. Health check (no auth)
curl http://localhost:8000/api/health
# → {"status":"ok","pipeline_loaded":true,"rules_count":54,"prompt_profile":"expanded"}

# 3. Chat without auth (should 401)
curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"question":"test","context_json":{},"mode":"dry_run"}'
# → {"detail":"Missing Authorization header..."}

# 4. Chat with auth (pipeline runs; ERROR if no LLM)
curl -X POST http://localhost:8000/api/chat \
  -H "Authorization: Bearer dev-token-please-change-in-prod" \
  -H "Content-Type: application/json" \
  -d '{"question":"who is the principal","context_json":{"UserMasterDetails":{"Id":116,"UserName":"abav","IsSuperUser":false,"UserBranchDetails":[{"ID":1,"Name":"CHALO","IsPrimary":true,"AcademicYears":[{"Id":6,"Name":"2026-2027","IsCurrentYear":true}],"Subjects":["MATHS"]}]}},"mode":"dry_run","branch_id":1}'
# → outcome: ERROR (LLM unreachable — expected)

# 5. Semantic engine
curl -X POST http://localhost:8000/api/validate \
  -H "Authorization: Bearer dev-token-please-change-in-prod" \
  -H "Content-Type: application/json" \
  -d '{"sql":"SELECT Password FROM UserAccountMaster","question":"show passwords"}'
# → {"violation_count":1,"high_count":1}
```

If all 5 pass, the backend is healthy. To test the full pipeline, start your llama.cpp server at port 8080 and re-run step 4 — expect `outcome: ANSWER` with `sql` populated.

---

## Update 2026-08-27 — Q11/Q12/Q16 answered

The project owner resolved three open questions. Status updated.

### Q11 — School routing: RESOLVED
**Answer:** `@shortschoolname` is validated with `school_id`. The username is validated with `useraccountdetails` and their roles. Both come from the Context JSON.

**What this means:** the school-routing layer already exists in the school's auth system (the `GetUserContext` API validates `username@shortschoolname` → `school_id` → `DBPrefix` + the user's roles). The backend does NOT need to build a separate routing layer — it receives the already-validated Context JSON from the mobile app (which got it from `GetUserContext`).

**Action taken:** no code change needed. The backend's `context.py` already parses `DBPrefix` from the Context JSON. The `school_mappings` block in `config.yaml` is for the auth layer (out of scope for this backend). Documented in `docs/API_CONTRACT.md` §5 (Context JSON shape).

### Q12 — Role/screen/table RBAC: RESOLVED (context only)
**Answer:** every user is assigned a role; every role is assigned access screens in modules (that's their boundary in practice). Each screen may link to many tables (e.g. the attendance screen has fee-due details).

**What this means:** the school's RBAC is **screen-level**, not table-level. The `allowed_tables` whitelist in `config.yaml` (16 tables) is NOT the right enforcement layer — a user's role grants them access to *screens*, and each screen touches multiple tables. The chatbot's RBAC challenge: a user with access to the "Attendance" screen can legitimately query attendance tables (which may join to fee-due details), but a user without the "Fees" screen should NOT be able to query fee tables directly.

**Action taken:** this is a **deeper RBAC problem than I designed for**. The current backend enforces branch-level scoping (via `UserAccountRoleDetails`) + sensitive-table blocking (via the semantic engine). It does NOT enforce role→screen→table access. Two paths forward (documented in PRD §10 as a new open question Q-RBAC-Screen):
- **Path A (narrow):** maintain a role→allowed-tables map in config (manual, brittle, but simple). The chatbot checks the user's role (from Context JSON) against the map before executing.
- **Path B (proper):** integrate with the school's existing `Role_Privilege_Details` + `Screen_Privilege_Details` tables — resolve the user's screens, then resolve each screen's tables, then allow only those. This is the structurally correct fix but requires a screen→table mapping the school must provide.

**Recommendation:** Path B for production; Path A as a stopgap. Marked as a v1.1 milestone (not blocking v1.0 launch).

### Q16 — Training notebooks: RESOLVED (a + b)
**Answer:** (a) updated notebooks + (b) documented diff.

**What this means:** I deliver updated `finetune_TRAIN.ipynb` and `finetune_EXPORT.ipynb` with the §F parameter changes baked in, AND a documented diff in `training/README.md` so you can review each change.

**Action taken:** will be delivered in Batch 3 (the v28 retrain path). The notebooks get: `MAX_SEQ_LENGTH=2560` (confirmed-safe), `r=16` (reduced from 32 — less overfitting on noisy labels), `lora_dropout=0.05` (regularization), `learning_rate=1e-4` (conservative), `warmup_steps=35` (3% of ~1150 steps), `num_train_epochs=2` (with per-epoch eval_loss monitoring), `quantization_method="q5_k_m"` (avoid double-4-bit), `MODEL_VERSION` auto-read from the adapter dir (fixes the stale v23 placeholder). The `prepare_data.py` already delivered (gated, instruction-field, vocab-aware option).

### New open question: Q-RBAC-Screen
**Q:** Should the chatbot enforce role→screen→table RBAC (Path B above), or is branch-level + sensitive-table blocking sufficient for v1.0?
**Blocks:** v1.1 RBAC hardening (not v1.0 launch).
**Recommendation:** ship v1.0 with branch-level + sensitive blocking; implement screen-level RBAC as v1.1.

### Real Context JSON received
The project owner provided a real `GetUserContext` response (a different school — "Golden Gates Matriculation Higher Secondary School", branch ID 2). Key observations vs. the sample I'd been using:
- **Sections are lettered: A/B/C/D/E** (this branch DOES use traditional sections — unlike branch 1 which uses ability streams). Confirms the §26 finding: section naming varies per branch. The vocab engine + the validate-and-substitute path handle this correctly.
- **Subjects are mixed-case: "Maths", "English", "Physics"** (not uppercase "MATHS"). Confirms the F5 finding: subject casing varies per branch. The synonym store handles "maths" → "Maths" (via the SUBJECT synonyms).
- **FeeHeads are granular: "Bus Fee I", "Bus Fee II", "Arrear Fee (22-23)", "TuitionFee 24-25"** (year-suffixed heads for arrears/period fees). The model needs to match these exactly — the synonym store may need branch-specific FeeHead synonyms (this is a v1.1 refinement).
- **ExamTerms are detailed: "SUMMATIVE ASSESSMENT I", "MIDTERM-I", "JAN SAT1", "UNIT EXAM"** (not just "Term I/II/EoY"). The model trained on "Term I" may not match "SUMMATIVE ASSESSMENT I" — the synonym store needs ExamTerm synonyms too.
- **NO `FeeTerms` key** (confirmed — the API doesn't return it). The fallback queries `TermMaster`.
- **NO `IsMgmtAppEnabled`, `ShortName`, `StaffName`** in this response (the sample had them). The backend tolerates missing optional fields.

**Action taken:** the real Context JSON confirms the vocab engine's design is correct (per-branch vocab varies; the engine bridges it). Updated `evaluation/sample_context.json` to use this real shape for more realistic testing. Documented the Context JSON contract gap (Sections + FeeTerms missing from the API) in PRD §9 (assumptions) and §10 (Q-ContextAPI — new open question: ask the dev team to add Sections + FeeTerms to the GetUserContext response).


---

## Update 2026-08-27 (final) — VAPT hardening + admin config UI complete

### VAPT code-side fixes (all implemented + verified)

| # | Fix | Status |
|---|---|---|
| V1 | Rate limiting (per-IP 100/min, per-token 20/min) | ✅ Wired in `main.py` (`check_rate_limit` dependency) |
| V4 | API key server-side (backend looks up from DBPrefix via `TENANT_API_KEYS`) | ✅ `security.py` `get_tenant_api_key()`; `ChatRequest` no longer has `api_key` field |
| V5 | Audit logging (SQLite `audit_trail` table; every `/api/chat` logged) | ✅ `security.py` `log_audit()`; 3+ rows verified |
| V7 | Prompt-injection defense (sanitizer + system-prompt reinforcement) | ✅ `security.py` `detect_prompt_injection()` + `reinforce_prompt()`; "ignore previous instructions" → 400 |
| V8 | Dependency CVE scan (pip-audit) | Pending (run before deploy) |
| V9 | Input sanitization (control chars, null bytes, Unicode NFKC) | ✅ `security.py` `sanitize_question()`; null byte → 400 |
| V10 | Generic prod error (no SQL Server error leak) | ✅ `security.py` `safe_error_message()`; production mode returns generic |
| V11 | LLM timeout (45s default) | ✅ `security.py` `LLM_TIMEOUT_SECONDS`; passed to `LlamaCppClient` |
| V13 | Dev UI not deployed | ✅ Documented (`src/app/LOCAL_TEST_UI_README.md`); the deployment doc is explicit |

### Ops-side fixes (docs provided; the ops team applies)

| # | Fix | Where documented |
|---|---|---|
| V2 | HTTPS enforcement + HSTS | `docs/OCI_DEPLOYMENT.md` §6 (nginx config) |
| V3 | CORS locked to explicit origins | `.env.example` + `docs/OCI_DEPLOYMENT.md` |
| V6 | Secrets in OCI Vault (not plaintext .env) | `docs/OCI_DEPLOYMENT.md` §4 |
| V12 | Request body size limit (1MB) | `docs/OCI_DEPLOYMENT.md` §6 (nginx `client_max_body_size`) |
| V14 | Security headers (HSTS, X-Content-Type-Options, X-Frame-Options, CSP) | `docs/OCI_DEPLOYMENT.md` §6 (nginx config) |
| V15 | WAF (OCI WAF) | `docs/OCI_DEPLOYMENT.md` §7 |

### Admin config UI (built + tested)

- `GET /api/admin/features` — returns 24 feature flags + descriptions. Admin-only (separate admin token).
- `PUT /api/admin/features` — updates flags; persists to `feature_overrides.json`. Admin-only.
- Every `/api/chat` response includes `features_enabled` (the list of flags currently on).
- The flags are **all OFF by default**; the admin flips them on.
- The flag is a **governance layer**, not an implementation. Flipping a flag on tells the backend "this feature is allowed"; the feature's code lands in v1.1+.
- See `docs/ADMIN_CONFIG_UI.md` for the full design.

### New files

- `backend/security.py` — the VAPT code-side fixes (V4, V5, V7, V9, V10, V11).
- `backend/audit_trail.db` — the audit log (SQLite, 3+ rows after testing).
- `backend/feature_overrides.json` — the admin's feature-flag overrides (persists across restarts).
- `docs/VAPT_READINESS.md` — the 15 gaps + fixes + pre-VAPT checklist.
- `docs/OCI_DEPLOYMENT.md` — the OCI shape + VCN topology + secrets in Vault + nginx config + WAF.
- `docs/ADMIN_CONFIG_UI.md` — the admin-only feature config UI design.
- `docs/HARDWARE_AND_DEPLOYMENT.md` — the lean hardware recs (8 OCPU / 24GB / ~$60-80/month).

### Backend version

Bumped from 1.0.0 to **1.1.0** (VAPT-hardened + admin config UI). The `/api/health` endpoint returns `version: "1.1.0"`.

### What's still pending

- **V8** (pip-audit) — run before deploy. ~1 hour.
- **The ops-side fixes** (V2, V3, V6, V12, V14, V15) — the ops team applies the nginx config + OCI settings from `docs/OCI_DEPLOYMENT.md`.
- **The mobile-app admin UI** — the "Features" screen (per `docs/ADMIN_CONFIG_UI.md` §3). The mobile-app team's work.
- **The feature implementations** — each flag is governance; the actual feature code lands in v1.1+.
- **The pre-VAPT checklist** (`docs/VAPT_READINESS.md` §3) — run through it before engaging the pen-tester.

### The bottom line

The backend is now **VAPT-ready on the code side**. The ops side (nginx + Vault + WAF) is documented in `docs/OCI_DEPLOYMENT.md` and takes ~1 day of ops work. After the ops team applies it + you run the pre-VAPT checklist, the app should pass a VAPT test on the first round.

---

## Update 2026-08-30 — v27 trained + 50-question benchmark completed

### v27 model trained and benchmarked

The v27 model was trained (6 hours on Kaggle) and the 50-question benchmark was run locally (api_wrapper mode, user 116, branch 1). This is the **first real v27 baseline** — all previous production traces were from the v25 model.

### v27 benchmark results (50 questions)

| Outcome | Count | % |
|---|---|---|
| Correct answers | 18/50 | 36% |
| Semantic mismatches (wrong but returned data) | 5/50 | 10% |
| Refused (guardrail caught hallucinations) | 16/50 | 32% |
| Execute errors (CTE bug + schema drift) | 6/50 | 12% |
| Section refusals (ability-stream branch) | 3/50 | 6% |
| Branch-scoping refused (DECLARE statement) | 1/50 | 2% |

### v25 vs v27 comparison (first 10 questions, head-to-head)

| Metric | v25 | v27 | Change |
|---|---|---|---|
| Semantic mismatch rate | 50% (4/8) | 12.5% (1/8) | **-37.5pp** |
| Bus fee outstanding (Q6) | NULL | 117,800 | **FIXED** |
| Structure_Type removal | Not done | Done | **v27 fix works** |
| 'Reg' enum hallucination (Q2) | Present | Gone | **FIXED** |
| Total demand (Q10) | 18.0M | 18.2M | **More accurate** |

### v27 module performance (answer rate)

| Module | Answer rate | Assessment |
|---|---|---|
| Fees | 80% | Strongest — the v27 Structure_Type fix works |
| Students | 75% | Strong |
| Transport | 75% | Strong |
| Payroll | 67% | Good |
| Communication | 50% | Medium |
| Admissions | 40% | Weak (CTE failures) |
| Exams | 43% | Weak (SubjectID/Term_Name hallucinations) |
| Inventory | 33% | Weak (thin training + hallucinated tables) |
| Staff | 17% | Weakest (principal, turnover all fail) |

### The 5 semantic mismatches (v28 priority targets)

1. **Q1:** hardcoded `Term_Name IN ('Term 1','Term 2')` instead of TermMaster date window → NULL
2. **Q22:** cartesian subject join (`s.BranchID = smd.BranchID`) → all subjects show 46.11
3. **Q25:** same cartesian join → 1039 rows instead of 5
4. **Q24:** queried marks instead of report-card-status table → 580 rows of wrong data
5. **Q48:** counted StudentAcademicDetail instead of SMSAuditTrail → 923 (student count, not notifications)

### The 12 guardrail failures (hallucinated tables/columns — coverage gaps)

Q7 (FeesType_Name), Q8 (Fees_Head_Name), Q19 (smd.SubjectID), Q20 (smm.Term_Name), Q26 (StaffDesignationMaster columns), Q31 (EmployeeMaster columns), Q39 (Route_MasterStudentMapping), Q43 (IsCreditNote), Q44 (MinStockLevel), Q45 (SupplierMaster), Q47 (SMSLog), Q49 (FeedbackParentStudent)

### The 6 execute: api FAILED cases

- 2 confirmed CTE + ExecuteQuery API bug (Q32, Q36)
- 1 schema drift — EmployeeMaster may not exist in the live DB (Q30)
- 3 other DB errors (Q21, Q23, + the schema drift)

### v28 training data needs (consolidated from all 4 batches)

~130-220 new training examples:
- "Current term" via TermMaster date window (10-15)
- Subject join via EvalHierID (10-15)
- Fee head name JOIN (5-10)
- "Who is the principal" → BranchMaster.Principal (5-10)
- Report card status (5-10)
- Notifications/SMS → SMSAuditTrail (5-10)
- Feedback → FeedbackTicket (5-10)
- EmployeeMaster → Staff_Master (5-10)
- Supplier/Inventory/CreditNote correct tables (10-15)
- CTE-form scoping rewrites (50-100)
- Compare + "not entered" patterns (20-30)

### What's now in place

| Item | Status |
|---|---|
| v27 model trained + exported | Done |
| v27 50-question baseline | Done (18 correct, 5 mismatch, 16 refused, 6 error) |
| v25 50-question baseline (first 10) | Done (for comparison) |
| Semantic rules engine (32 rules) | Done + FEE-005 refined |
| Pipeline (17 modules, 11 stages) | Done |
| Backend (FastAPI, VAPT-hardened) | Done |
| Admin config UI (24 feature flags) | Done |
| Data dictionary (475 tables, Excel) | Done |
| Schema change playbook | Done |
| Training notebooks (v27-ready) | Done |
| Complete guide (MD + PDF) | Done |
| Dev team asks (9 asks) | Done |
| All documentation (~20 docs, ~5,500 lines) | Done |

### What's pending

| Item | Status | Blocks |
|---|---|---|
| Dev team asks 3.5 (correct tables for 6 concepts) | Sent | v28 training data for bonafide, report cards, credit notes, suppliers, inventory, SMS |
| Dev team ask 2.1 (ExecuteQuery CTE bug fix) | Sent | v28 CTE-form scoping (50-100 examples) |
| Dev team ask 1.1 (standardize GetUserContext) | Sent | v28 FULL vocab mode |
| v28 training data (~130-220 examples) | Not started | Waiting on asks 3.5 + 2.1 |
| v28 retrain | Not started | Waiting on training data |
| Screen-level RBAC (Path B) | Designed, not implemented | v1.1 |
| VAPT ops-side (nginx, Vault, WAF) | Documented, not applied | Pre-VAPT |
| pip-audit (V8) | Not run | Pre-deploy |

---

## Update 2026-08-31 — End-to-end verified on Windows + 5 backend bug fixes + audit export/reset

### The headline: the system works end-to-end on Windows

The user successfully ran the full pipeline on a Windows laptop against the school's real `V3_TestDatabase`. The query **"how many students are there in 10 a?"** returned the real answer **`StudentCount = 32`**. The full pipeline trace shows all 6 stages passing: `generate → branch_scoping → validate → semantic (32 rules) → bind → execute`. This is the **first end-to-end verification** — every prior run was either dry_run or against a sandboxed/stubbed LLM. The chat UI (`frontend/chat.html`), the backend (`backend/main.py`), the LLM (`D:\llama-b6691\llama-server.exe` + `D:\ggufs\AISv27-qwen2.5-coder-7b-instruct.Q4_K_M.gguf`), and the school's ExecuteQuery API all talked to each other.

### The 5 backend pipeline bug fixes (the changes that made it actually work)

These were discovered while running the system on Windows. Each was a real blocker.

| # | File | Bug (the symptom) | Fix (what changed) |
|---|---|---|---|
| 1 | `pipeline/parameter_binder.py` | The bind stage raised `UnboundParameterError` whenever the model didn't use `@AcademicYearID` or `@SelectedBranchId` (common — the model often scopes by `GETDATE()` instead). | Unused `SECURITY_PLACEHOLDERS` (`@AcademicYearID`, `@SelectedBranchId`) are now **silently dropped** instead of raising. The model is allowed to scope by `GETDATE()` instead of `@AcademicYearID`. |
| 2 | `pipeline/orchestrator.py` | The school's ExecuteQuery API error message was hidden in the `detail` field (only visible with `DEBUG=true`), so the chat UI just said "ExecuteQuery API failed" with no clue why. | The school's API error message is now **surfaced in the `message` field** (shown in the chat UI), not just the `detail` field. Users now see the real API error inline. |
| 3 | `backend/main.py` | `mode=api_wrapper` with an empty `api_wrapper_url` or `target_database` was silently passed to urllib → `unknown url type: ''` (a urllib-level error with no actionable info). | **Early validation.** If `mode=api_wrapper` but `api_wrapper_url` or `target_database` is empty, fail fast with a clear **400 error** telling the user to set the field in the chat UI Settings. |
| 4 | `backend/main.py` | The school's ExecuteQuery API has a **confirmed bug** where it fails on repeated `@-placeholders` in nested subqueries (e.g. `@UserId` referenced twice in a CTE + a subquery). With `use_inline_params=False`, every bound request hit this bug. | `use_inline_params=True` is now **hardcoded** (matches the old `config.yaml`). Inline params substitutes `@UserId=116` and `@SelectedBranchId=1` directly into the SQL text (safely escaped by `_sql_literal()`), avoiding the repeated-placeholder bug entirely. |
| 5 | `backend/main.py` | The user had to set every env var (`AI_SECRETARY_AUTH_TOKENS`, etc.) in the shell before starting uvicorn — easy to forget on Windows. | Added a `try/except` block at the top that **auto-loads `backend/.env`** via python-dotenv (graceful fallback if dotenv isn't installed or `.env` is missing). |

### The audit trail — Export XLSX + Reset (the new admin feature)

Two new admin-facing features were added to `frontend/audit.html`:

1. **Export XLSX (green button):** fetches ALL audit rows (respecting the current outcome filter, up to 100,000) and downloads them as an Excel `.xlsx` file via SheetJS (loaded from the CDN). **Falls back to CSV** if offline (SheetJS not loaded). Filename includes the date + row count (e.g. `audit_trail_2026-08-31_482rows.xlsx`).

2. **Reset (red button):** clears the entire audit trail. Shows a confirmation dialog with the row count + a reminder to "Export XLSX first if you want a copy." Calls the new `DELETE /api/audit` endpoint (admin-only). Cannot be undone.

### New backend endpoint: `DELETE /api/audit`

- **Method:** `DELETE`
- **Path:** `/api/audit`
- **Auth:** admin Bearer token (separate from user token)
- **Body:** none
- **Response:** `{"status": "ok", "message": "Audit trail cleared. 0 row(s) remaining.", "remaining": 0}`
- **Effect:** deletes ALL rows from the `audit_trail` SQLite table. The audit table itself is preserved (just emptied).

### Endpoint count updated: 8 → 9

The backend now has **9 endpoints** (was 8):

- **4 user endpoints:** `GET /api/health`, `POST /api/chat`, `POST /api/branches`, `POST /api/validate`
- **5 admin/audit endpoints:** `GET /api/admin/features`, `PUT /api/admin/features`, `GET /api/audit`, `GET /api/audit/stats`, `DELETE /api/audit`

### Batch file hardening (the Windows bootstrap changes)

All 5 batch files were rewritten to be **bulletproof on Windows**:

- `goto`-based control flow (not nested `if` blocks) — Windows `cmd.exe` parses nested `if` blocks weirdly.
- **Pure ASCII** (no Unicode box-drawing chars) — `cmd.exe` displays Unicode as garbage on some code pages.
- **Self-bootstrapping** — auto-create `.venv`, `pip install -r backend\requirements.txt`, fall back to a sample `context.json` if the user's is missing.
- Friendly file-missing errors with download URLs (e.g. start_llm.bat tells you to download llama.cpp from the releases page if `llama-server.exe` is missing).
- The user's real paths are pre-filled in `start_llm.bat`: `D:\llama-b6691\llama-server.exe` and `D:\ggufs\AISv27-qwen2.5-coder-7b-instruct.Q4_K_M.gguf`.

`START_HERE.bat` (NEW, in project root) is the one-click starter that opens all 3 services (LLM, backend, browser) in 3 windows with step-by-step instructions.

### What's still NOT fixed (carried forward)

- **The LLM quality gap on "section A":** the end-to-end test query ("how many students are there in 10 a?") returned the count for ALL of class 10 (32), not section A specifically. The v27 model wasn't trained on enough class+section examples — it ignores "section A". This is a model-quality issue, **needs the v28 retrain** with more class+section training examples.
- **The v28 retrain** is still pending (waiting on dev-team asks 1.1, 2.1, 3.5).
- **Screen-level RBAC (Path B)** is still designed-not-implemented (v1.1).
- **VAPT ops-side (nginx, Vault, WAF)** is still documented-not-applied (pre-VAPT).
- **pip-audit (V8)** is still not run (pre-deploy).

### Files changed this session (2026-08-31)

- `backend/main.py` — fixes 3, 4, 5 above + the new `DELETE /api/audit` endpoint.
- `pipeline/parameter_binder.py` — fix 1 (silent drop of unused SECURITY placeholders).
- `pipeline/orchestrator.py` — fix 2 (surface ExecuteQuery API error in `message`).
- `frontend/chat.html` — added Settings inputs for `api_wrapper_url`, `target_database`, `model_url` (sent in the request body).
- `frontend/audit.html` — added Export XLSX + Reset buttons (SheetJS via CDN, CSV fallback).
- `frontend/nextjs-ui/src/app/page.tsx` — fixed the BLOCKER: now calls `${settings.backendUrl}/api/chat` directly with `Authorization: Bearer ${settings.authToken}` (was calling a non-existent `/api/chat?XTransformPort=8000`). Added `backendUrl` + `authToken` to AppSettings + Settings UI. Removed the dead `api_key` body field.
- `START_HERE.bat` (NEW), `scripts/start_backend.bat`, `scripts/start_llm.bat`, `scripts/run_50.bat`, `frontend/start_chat.bat` — all 5 batch files rewritten (goto-based, pure ASCII, self-bootstrapping).
- `run_50_questions.py`, `context.json`, `docs/GUIDELINES.md`, `docs/BLINDSPOT_AUDIT.md`, `semantic_validation/`, `pipeline/schema_catalog.json`, `training/README.md`, `backend/.env.example`, `backend/requirements.txt` — all bundled INTO `chalo_chatbot/` (previously outside / referenced as if included).
- All `bun` / `bun install` / `bun run dev` references changed to `npm` / `npm install` / `npm run dev`. The Next.js `package.json` `start` script changed from `bun` to `node`; `bun-types` removed; `@types/node` added.
- All 11 docs updated to reflect the above (README.md, STRUCTURE.md, PROJECT_STATUS.md, SESSION_HANDOFF.md, INSTRUCTION_MANUAL.md, COMPLETE_GUIDE.md, HOW_IT_WORKS.md, API_CONTRACT.md, ADMIN_CONFIG_UI.md, frontend/README.md, WINDOWS_LOCAL_TESTING.md).

---

## Update 2026-09-03 — 4 new pending UI/UX items + CTX_SIZE clarification + system prompt expansion plan + 3B vs 7B decision + persona skill + SESSION_RECORD

### The 4 new pending UI/UX items

The project owner requested 4 new features be added to the pending list (none are implemented yet — see §4.6 "Pending UI/UX features" above for the full descriptions):

1. **AI disclaimer in `chat.html`** — a subtle footer note: *"AI can make mistakes. Please verify important information."*
2. **LLM model selector dropdown** in `chat.html` → Settings — three options: **Chalo Language Model 1.0** (current, enabled by default), **CLM 2.0** (disabled — coming soon), **CLM 3.0** (disabled — coming soon). Maps to a different GGUF path in `start_llm.bat` or a different `model_url` in the request body.
3. **Configurable "show thinking process" toggle** — show the pipeline stages progressively ("Understanding your question...", "Generating SQL...", "Validating against 32 rules...", "Querying the database..."). Toggle in Settings. When off (default): just the loading dots (current behavior).
4. **Standard reply for unanswerable questions (configurable)** — when `outcome ∈ {REFUSED, ERROR, NEEDS_DISAMBIGUATION}`, show a single admin-configurable message instead of the raw error. Configurable via env var `AI_SECRETARY_FALLBACK_MESSAGE` or in `feature_overrides.json`. Raw `detail` + `semantic_violations` stay in the response body for debugging.

### CTX_SIZE clarification — training constraint ≠ inference constraint

**The setup:** `scripts/start_llm.bat` sets `CTX_SIZE=2560`, with the comment *"Context size (must match training: 2560). Don't change unless you know why."* That comment is misleading — it conflates two independent things.

**Where 2560 came from:** the previous AI assistant (Claude) chose `MAX_SEQ_LENGTH=2560` during model TRAINING to prevent silent truncation of training sequences (the longest training example was ~1,750 tokens, so 2,560 gave margin). This is a TRAINING constraint — it sets the max sequence length the LoRA adapters were exposed to during fine-tuning.

**Why this doesn't constrain inference:** at INFERENCE time (running in `llama-server`), the context window is independent. Qwen 2.5 Coder 7B's base model natively supports **32K tokens** of context. Fine-tuning with LoRA (1.05% of params) teaches patterns, not context length — the model's attention mechanism doesn't break at longer lengths just because the LoRA was trained at 2,560.

**The decision:** the inference `--ctx-size` can safely be **increased to 4096** (not 8192 — that might degrade attention quality on CPU). This allows a 2-page system prompt (~1,000-1,500 tokens) instead of the current 1-paragraph prompt (~80 tokens). Going from 2560 → 4096 adds ~3-4 seconds of latency (acceptable: 15-35s → 18-39s on CPU).

**Action (PENDING, not yet applied):** bump `CTX_SIZE` in `scripts/start_llm.bat` from 2560 to 4096, and update the systemd/`ExecStart` lines in `docs/INSTRUCTION_MANUAL.md` and `docs/COMPLETE_GUIDE.md` accordingly. This should happen alongside the system prompt expansion (next item) — they go together.

### System prompt expansion plan (the #1 accuracy improvement without retraining)

**The current prompt** (one paragraph, ~80 tokens, frozen in `prepare_data.py`'s `FROZEN_SYSTEM_PROMPT` and `demo_runner._read_base_prompt`):

> "You are a T-SQL expert for the ChaloSchools (V3_CHALO) school management database. Convert the following natural language question into a single, executable T-SQL query. Use @UserId (bound as a query parameter at runtime from the logged-in user's session) to scope results to the branches that user has access to via UserAccountRoleDetails."

**The problem:** this is the single biggest accuracy lever available without retraining or dev-team help. The model has to guess schema gotchas, business formulas, mandatory filters, JOIN patterns, and enum values from its training data alone — which is exactly what produced the 5 semantic mismatches in the v27 benchmark.

**The plan:** expand the system prompt to ~2 pages (~1,000-1,500 tokens) covering:

- **The 7 known schema gotchas:** `BusFeeStrucure` misspelling (no 't' in "Structure"), `ExamTermMaster` column names, `Receipt_Amt` not `Amt`, etc.
- **The top 5 business formulas:** e.g. fee outstanding = `Amount - Concession_Amt - Paid_Amt - Lien_Amount`; current term = `TermMaster WHERE GETDATE() BETWEEN StartDate AND EndDate`; etc.
- **The top 10 mandatory filters:** `IsActive=1`, `IsTCIssued=0`, `ChequeStatus_ID NOT IN (3,4)`, `BranchID = @SelectedBranchId`, etc.
- **The key JOIN patterns:** student → `ClassMaster` + `SectionMaster`; fees → `FeesInformationStudentDetail`; etc.
- **The critical enum values:** `ChequeStatus` (3=Bounced, 4=Cancelled); etc.

**Important constraint:** changing the system prompt at inference time is fine (the LoRA layers adapt). Changing it at TRAINING time requires regenerating the JSONL with the new prompt prepended (per `docs/INSTRUCTION_IMPROVEMENT.md`). So the expansion can be tested at inference first, then baked into v28.

**Status:** PENDING — waiting for the user to paste 4 small extracts (top filters, enums, hub tables, raw SQL) from the codebase-analysis toolkit output so the prompt can be built from REAL data, not from the assistant's memory. The extracts will be folded into the prompt and tested against the 50 golden questions.

**Latency impact:** the 2-page prompt adds ~1,000-1,500 input tokens. On CPU (Qwen 2.5 Coder 7B, Q4_K_M), prefill is ~50-100 tok/s — so the added prompt adds ~10-30 seconds of latency. **This is the reason to bump `CTX_SIZE` to 4096** (above). The two changes go together.

### 3B vs 7B decision — keep the 7B, get a GPU if latency is the problem

The project owner asked whether fine-tuning a 3B model would bring it to par with the 7B after training. The answer is **NO**:

- **For simple queries** (single-table, basic WHERE): 3B gets close (~90-95% of 7B accuracy) — fine-tuning taught it the patterns.
- **For complex queries** (multi-JOIN, comparisons, ambiguity): 3B falls behind (~50-65% of 7B accuracy) — the 3B lacks the reasoning capacity.

**The principle:** fine-tuning adds KNOWLEDGE (your schema, your patterns). It does NOT add REASONING capacity. The gap on complex queries is reasoning, not knowledge. Qwen 2.5 Coder benchmarks confirm: 7B scores 17-22 points higher than 3B on coding benchmarks (HumanEval, MBPP, MultiPL-E).

**Decision:** **keep the 7B model.** If latency is the problem, the right fix is a GPU — a $200 used RTX 3060 (12GB VRAM) makes the 7B run in 1-3 seconds with `--n-gpu-layers 99`. Don't shrink the brain to make it faster.

### chalo-chatbot-persona skill created

A new skill file was created at `chalo-chatbot-persona/SKILL.md` (also copied to `chalo_chatbot/skills/chalo-chatbot-persona/SKILL.md` for in-project access). It captures the project owner's persona, project context, preferences, and the key files for future conversations. The skill auto-triggers when the user mentions ChaloSchools, the chatbot, the pipeline, etc., so the assistant doesn't have to relearn the project state from scratch each session.

> **Note (2026-09-03):** the persona skill is referenced here for documentation purposes; the actual `chalo_chatbot/skills/` folder may or may not be present in the downloaded package depending on when you unpacked it. The canonical copy lives at `chalo-chatbot-persona/SKILL.md` outside the package.

### SESSION_RECORD.md created

A complete project record (~526 lines, ~27 KB) was created at `SESSION_RECORD.md` in the project root. It covers the full journey from "I have a school ERP" to end-to-end verified, with 16 sections including: the beginning, what the user brought, the initial problems, all 8 phases of work, architectural decisions, dev team asks, and key metrics. Read this for the complete narrative history (this `PROJECT_STATUS.md` is the snapshot; `SESSION_RECORD.md` is the story).

> **Note (2026-09-03):** `SESSION_RECORD.md` is referenced here for documentation purposes; verify it exists in your downloaded package. If it's missing, ask the project owner for the latest copy.

### Files changed this session (2026-09-03 — DOC-UPDATE-5)

This was a **documentation-only update**. No code changed. The 10 docs updated are: `README.md`, `STRUCTURE.md`, `docs/PROJECT_STATUS.md` (this file), `docs/SESSION_HANDOFF.md`, `docs/INSTRUCTION_MANUAL.md`, `docs/COMPLETE_GUIDE.md`, `docs/HOW_IT_WORKS.md`, `docs/API_CONTRACT.md`, `frontend/README.md`, and (where present) `SESSION_RECORD.md`. The worklog at `/home/z/my-project/worklog.md` got a new `DOC-UPDATE-5` entry appended.

### The bottom line

The system remains **end-to-end verified on Windows** (2026-08-31). The path to higher accuracy is now clearer: (1) the system prompt expansion (waiting for the user's extracts) is the #1 lever, (2) bumping `CTX_SIZE` 2560 → 4096 unlocks the longer prompt at the cost of ~3-4s latency, (3) the v28 retrain remains the medium-term plan, (4) the 4 new UI/UX items are quality-of-life improvements for the chat UI. The 7B model stays — a GPU is the right fix for latency, not a smaller brain.

---

## Update 2026-09-04 — ERP codebase analysis incorporated: 54 rules, expanded prompt, v28 dataset ready

**Version 1.2.0.** The extracts from the ERP source-code analysis (JOIN patterns, mandatory filters, business formulas, query templates) are now incorporated into the chatbot AND the LLM training data. This was the documented "#1 accuracy lever" plan from 2026-09-03, now executed.

### The numbers

| What | Before | After |
|---|---|---|
| Semantic rules | 32 | **54** (12 trace-derived + 10 from the ERP's mandatory filters) |
| System prompt | 1 paragraph (~85 tokens) | **+ ~1,200-token ERP knowledge block** (frozen text still leads; profile-switchable) |
| Retry prompts | "that column doesn't exist, try again" | **+ HINT MAP** (13 hallucination-trap → correct-approach hints) |
| CTX_SIZE | 2560 | **4096** (pairs with the expanded prompt) |
| Training data | v27 only (3,867) | **v28 ready: 4,034** (3,867 + 182 gated additions, 15 buggy labels replaced) |
| New-rule false positives on v27 data | — | **measured: 88 flags (2.3%), all genuine label bugs** |
| Backend | 1.1.0 | 1.2.0 (health reports prompt_profile + rule count) |

### What was verified this session

- All 54 rules pass self-tests (22 new rules each fire on bad SQL, pass on corrected SQL).
- The 182 v28 additions pass the 54-rule engine + the 475-table catalog column check with **0 violations** (independently re-verified).
- `training/prepare_data_v28.py` runs end-to-end: additions gate PASSED, merged dataset written, 92/8 split produced.
- All modified Python files compile; `python3 pipeline/semantic_rules.py` and `python3 pipeline/schema_knowledge.py` self-checks pass.

### Catalog corrections discovered (dev team should know)

1. `StudentAcademicDetail` has **no BranchID** column — branch scope must flow through the AcademicYearID → Branch_Academic_Details subquery (the T-001 template's `sad.BranchID` would fail).
2. `Student_Master` has **no delete column** — activeness is the TC filter only.
3. `FeesCollection`'s receipt date is **Bill_Date** (no Receipt_Date).
4. `LeaveApplicationEntries`, `ProgressCardMarksDetails`, `SubjectWiseHierarchyList` are not in the runtime catalog (guardrail refuses them; rules keep them for dataset-quality checks).

### What's pending now (unchanged unless noted)

- **Benchmark the expanded prompt on Windows** (50 golden questions, v27 model) — then retrain v28 on Kaggle (dataset ready: `training/train_v28.jsonl` + `val_v28.jsonl`, params in DATASET_VERSION_V28.txt).
- Dev-team asks 1.1 (ExecuteQuery repeated-@placeholder bug), 2.1 (GetUserContext Sections:[]), 3.5 (6 concept table names) — still pending.
- 4 UI/UX items (order 1 → 2 → 4 → 3), screen-level RBAC Path B, VAPT ops-side, pip-audit — unchanged.
- v27 buggy-label cleanup (429 flagged by the 54-rule engine) — tracked; 15 worst ones already replaced by corrected labels in v28.

### Files changed this session (2026-09-04 — CODE-UPDATE-6)

Code (8): `pipeline/semantic_rules.py`, `pipeline/schema_knowledge.py` (new), `pipeline/orchestrator.py`, `backend/main.py`, `scripts/start_llm.bat`, `semantic_validation/semantic_rules.py` (sync), `training/prepare_data_v28.py` (new), `semantic_validation/reference_inputs/training_dataset_v28_additions.jsonl` (new). Generated (4): `training/train_v28.jsonl`, `training/val_v28.jsonl`, `training/DATASET_VERSION_V28.txt`, `semantic_validation/reference_inputs/training_dataset_final_v28.jsonl`. Docs: this file, `docs/SESSION_HANDOFF.md`, `README.md`, worklog.

### The bottom line

The chatbot now knows what the ERP's own code knows. 54 validated rules catch the blindspots at runtime; the expanded prompt (with a one-line rollback) feeds the model the real joins, filters, and enums; the v28 training set (4,034 examples, additions 100% clean) is ready for Kaggle. Next: benchmark the prompt on Windows, retrain, re-run the 50 questions. v25 50% mismatch → v27 18% → v28 target <5%.

---

## Update 2026-09-04 (later) — SSMS local-test kit for the v28 dataset (CODE-UPDATE-7)

**Pre-training gate added:** every one of the 4,034 v28 question→SQL pairs is now runnable T-SQL in **`sql_tests\`** (9 part files of 500, a 50-query smoke file, a run-all SQLCMD runner, and a README). The SQL text is byte-identical to the dataset, so any error SSMS reports = an error the trained model would produce. Failures are collected per query (TRY/CATCH → `#ai_errors` with qid, question, error, ms) and printed in the Messages tab even when result grids are discarded; Q-number = line number in `training_dataset_final_v28.jsonl`.

- One setting to change before running: Find & Replace `@UserId INT = 1` → your local user id. `@SelectedBranchId NULL` = all authorized branches.
- Dataset scans folded in: `@AcademicYearID` never used (not declared); the four `@Status…` variables in enquiry queries declare themselves; 2,871/4,034 SQL texts unique; 17 refusal queries return messages by design.
- No code changed — chatbot/pipeline untouched. New files only + docs (this file, SESSION_HANDOFF, worklog).

**Next:** run the smoke file, then all parts on the local DB; fix any failing Q-numbers in the dataset before uploading `train_v28.jsonl` / `val_v28.jsonl` to Kaggle.

---

## Update 2026-09-04 (evening) — SSMS smoke test caught 39 broken v28 labels; fixed + syntax gate added (CODE-UPDATE-8)

The owner ran the smoke file locally and reported syntax errors with a misleading "0 failed" summary. Root-cause analysis: (1) **39 of the 182 v28 addition labels were syntactically broken** (36 missing AND, 3 double WHERE — generator template junction bugs; pattern rules can't see predicate junctions; the 3,867 v27 base labels parse 100% clean); (2) **TRY/CATCH cannot catch compile-time errors** (the batch dies before TRY runs), so the harness under-counted exactly the error class it exists to catch.

Fixes (root cause, no workarounds):
- Generator's six junction sites fixed; additions regenerated (diff: exactly the 39 broken outputs changed). 54-rule gate: 0 violations. New **sqlglot T-SQL parse gate**: 0 failures on additions AND on the whole 4,034.
- `training/prepare_data_v28.py`: added HARD GATE #2 — additions must parse with 0 failures (`pip install sqlglot` required); base parse-reported (currently 0). DATASET_VERSION_V28.txt records the gate + the fix note.
- `sql_tests\` regenerated with the **sp_executesql wrapper** per query: syntax / unknown-column / unknown-table errors are now caught and counted (compile-time errors become runtime errors at EXEC time). Kit README updated; dataset pre-parsed before file generation.
- Rebuilt + re-verified: additions (182), combined (4,034), train (3,712) / val (322), all parse-clean, instruction uniform; kit Q1..Q4034 ordered, fidelity 0 mismatches, all six broken smoke queries verified fixed in-file.

**Next:** re-run `v28_smoke_first50.sql` (the same 50 queries incl. the previously failing ones), then the 9 parts — "N failed" is now the true count. Any remaining failure = genuine schema mismatch to fix in the dataset before Kaggle.

---

## Update 2026-09-04 (night) — smoke test clean; run-all needed no-SQLCMD option (CODE-UPDATE-9)

Owner's smoke run: **0 errors, 50/50** — the repaired dataset executes on the local DB. The full-run attempt failed only because `v28_run_all.sql` requires SSMS SQLCMD Mode (its `:r` include lines are not T-SQL); nothing executed.

- **New `sql_tests\v28_run_all_single_file.sql`** (6.8 MB): all 4,034 queries inline, no modes, just F5 after setting `@UserId`. Same error-capturing harness; 9 part summaries + grand total.
- `v28_run_all.sql` now carries a banner directly above the first `:r` that names the exact error and its fix, plus the single-file alternative.
- Verified: 4,034/4,034 literals byte-exact (modulo `''` escaping + CRLF, both whitespace-insignificant to SQL Server); banner/includes/grand-total structure confirmed.

Dataset and training files unchanged. **Next:** full run via the single file; report `TOTAL FAILURES` — anything above 0 is a genuine schema mismatch to fix in the dataset before training.

---

## Update 2026-09-04 (afternoon) — OCI Ubuntu quickstart + the 4 UI/UX items implemented (CODE-UPDATE-10)

**Version 1.3.0.** Two deliverables in one pass: the deployment guide the owner asked for (hosting on OCI Ubuntu), and the 4 pending UI/UX items from §4.6.

### 1. OCI Ubuntu deployment — `docs/OCI_UBUNTU_QUICKSTART.md` (NEW)

The owner is moving to Oracle Cloud on Ubuntu. The master guide (`docs/OCI_DEPLOYMENT.md`) is topology-oriented (VCN, Vault, WAF, LB); the new quickstart is the **command-by-command Ubuntu companion** implementing the single-instance topology (§5.2 of the master guide):

- **Where the files go:** `/opt/chalo-ai-secretary/` (package, llama.cpp, `models/` GGUF, venv), `/var/www/chalo/` (chat.html + audit.html served by nginx), systemd units `chalo-llm.service` + `chalo-backend.service`, nginx site `/etc/nginx/sites-available/chalo`.
- **The commands:** instance launch (E4.Flex 8 OCPU/24GB, Ubuntu 24.04), the **OCI security list AND the Ubuntu iptables REJECT gotcha** (the #1 "why won't my page load" cause on OCI Ubuntu images), scp upload from Windows (incl. rsync-resume tip for the 4.5 GB GGUF), venv + requirements (pyodbc optional for api_wrapper mode), llama.cpp prebuilt binary, both systemd units (`--ctx-size 4096 --threads 8`, `MemoryMax=16G`, backend on 127.0.0.1:8000), nginx reverse-proxy `/api/` → backend + static chat UI, certbot TLS, the curl verification chain, day-2 cheat sheet (logs, restarts, model swap, app updates, audit backup), and a troubleshooting table.
- Also documented: on the hosted deployment, chat.html's Backend URL stays EMPTY (same-origin through nginx) and the LLM URL stays `http://localhost:8080/...` (the **backend** calls it server-side; the browser never talks to 8080).

### 2. The 4 UI/UX items — all implemented

| # | Item | What shipped |
|---|---|---|
| 1 | AI disclaimer | Subtle muted note below the chat input: *"AI can make mistakes. Please verify important information."* |
| 2 | LLM model selector | Settings → "LLM Model": CLM 1.0 (enabled, default), CLM 2.0 + CLM 3.0 (disabled, "coming soon"). Maps to the existing `model_url` request field; enable + remap when v28/v29 GGUFs land. |
| 3 | Show thinking process | Settings toggle (default off). When on: progressive stage text under the loading dots — "Understanding your question..." → "Generating SQL..." → "Validating against 54 rules..." → "Querying the database..." (timed; true SSE stage streaming remains a future backend enhancement). Timer cleaned up on both success and error paths. |
| 4 | Standard reply (backend) | `backend/main.py` v1.3.0: outcome ∈ {REFUSED, ERROR, NEEDS_DISAMBIGUATION} → user-facing `message` becomes the standard reply; the original message moves into `detail`; `semantic_violations` untouched; new `fallback_used` boolean in the response. Config priority: `AI_SECRETARY_FALLBACK_MESSAGE` env var > `"fallback_message"` key in `feature_overrides.json` > built-in default; empty env var disables. `/api/health` now reports `fallback_message_active`. `_save_feature_overrides` was also fixed to preserve non-flag keys (admin PUTs no longer drop `fallback_message`). |

Also shipped: chat.html footer "v1.1.0 · 32 rules" → **"v1.3.0 · 54 rules"** (was stale since CODE-UPDATE-6), all UI text 32 → 54 rules, and **settings persistence to localStorage** (previously claimed by frontend/README.md but never wired up — now real).

### Verification

- `backend/main.py` py_compile clean; 8-point runtime test passed: import OK (v1.3.0), fallback default, env-var priority, empty-disables, the exact replacement branch (message swapped + original preserved in detail), `/api/health` (54 rules, prompt_profile expanded, fallback_message_active true), `_save_feature_overrides` preserving non-flag keys.
- `chat.html` verified in a real browser: page loads with zero console errors; version footer, disclaimer, model dropdown (1 enabled / 2 disabled), thinking toggle (default off) all present; settings persist across reload; thinking stages render during an in-flight request and clean up on both success and error; mobile 390px layout intact.

### Files changed (CODE-UPDATE-10)

Code (2): `frontend/chat.html`, `backend/main.py`. Config (3): `backend/.env.example`, `backend/.env` (documented the new var, commented out), `backend/feature_overrides.json` (unchanged behavior — the key is optional). Docs (5): `docs/OCI_UBUNTU_QUICKSTART.md` (NEW), `docs/PROJECT_STATUS.md` (this file), `docs/SESSION_HANDOFF.md`, `frontend/README.md`, worklog. No pipeline/training/dataset files touched.

### The bottom line

The owner can now host on OCI Ubuntu by following `docs/OCI_UBUNTU_QUICKSTART.md` top to bottom, and the chat UI the users see is current: v1.3.0 · 54 rules, disclaimer, model selector, thinking toggle, standard replies — with nothing left pending from the 2026-09-03 UI/UX list except the optional SSE streaming upgrade.

---

## Update 2026-09-04 (late) — SQL full-run clean; v28 training kit shipped (CODE-UPDATE-11)

**The milestone:** the owner ran the ENTIRE `v28_run_all_single_file.sql` kit on the local DB — **all 4,034 queries executed with 0 failures**. That was the last pre-training gate: the v28 labels are now parse-gated (sqlglot), rule-gated (54 semantic rules), and **execution-verified on the real schema**.

**What this update ships** (the owner asked "do I go to training straight? any prerequisites?" — the honest answer was *not quite*):

### 1. v28 training + export notebooks (the actual blocker)

Both notebooks still pointed at v27 (`/kaggle/input/chaloschools-sql-dataset-v27`, `train_v27.jsonl`, "3,867 examples") while the validated dataset on disk is v28. Training straight from the zip would have failed at the very first `assert os.path.exists(TRAIN_PATH)`.

- **NEW `training/finetune_qwen25coder_TRAIN_KAGGLE_v28.ipynb`** (v27 kept as reference): dataset slug `chaloschools-sql-dataset-v28`, `train_v28.jsonl`/`val_v28.jsonl`, header documents the v28 changes (182 additions, 15 replaced, 39 repaired, 4,034 = 3,712 train / 322 val, execution-verified 2026-09-04), Kaggle how-to steps updated.
- **`MAX_SEQ_LENGTH raised 2560 → 3072`** (the one hyperparameter change): v28's longest example is 9,111 chars ≈ up to ~2,700 tokens with the chat template; at 2560 the longest examples would be **silently truncated — teaching the model broken SQL**. 3072 restores headroom (Qwen2.5 supports 32k natively; T4 16GB handles it). Time estimate updated (~1–1.5 h on 1× T4 for 3,712 examples).
- **NEW `training/finetune_qwen25coder_GGUF_EXPORT_COLAB_v28.ipynb`**: `MODEL_VERSION = "v28"`, references the v28 training notebook, and its model-reload `MAX_SEQ_LENGTH` also raised to 3072 ("must match training config").
- Hyperparameters otherwise unchanged from v27 (r=32, α=32, dropout 0, lr 2e-4, 2 epochs, effective batch 8, adamw_8bit, Q4_K_M export) — data-only update, same discipline as every prior version bump.
- `training/README.md` rewritten: files table (train/val v28 first), the pipeline diagram, **the Kaggle prerequisites** (phone-verified account, ~30 h/week free GPU quota, optional HF token), step-by-step dataset upload (`+ Add Input` → slug `chaloschools-sql-dataset-v28`), and a "run the 50-question baseline FIRST" recommendation. `STRUCTURE.md` training section updated to match.

### 2. package.sh bug fixed (the zip carried hidden junk)

The 2026-09-04 zip the owner downloaded was **13 MB with 2,187 entries — 1,959 of them `.venv/` junk** (harmless but sloppy). Root cause: `package.sh` built one unquoted `$EXCLUDE_ARGS` string, so the shell **glob-expanded `*/.venv/*` against the workspace** into literal paths before `zip` ever saw the patterns (the excludes silently became no-ops). Fixed: every pattern is now a separately **quoted** argument on one `-x` flag, plus two hard post-build gates — a **junk gate** (listing must contain 0 `.venv/node_modules/__pycache__/.pyc/.next/.env/.git/audit_trail.db` entries; exit 1 otherwise) and a **must-ship gate** (13 key files must be present: chat.html, backend, pipeline, the v28 training kit, sql_tests, the OCI quickstart). Rebuilt zip: **4.4 MB, 230 clean files, both gates green**. (`package.bat` was already correct — robocopy `/XD` handles excludes natively.)

### 3. Review dashboard (the `/` page)

New download banner at the top: "v28 training kit is ready — the chatbot zip was rebuilt (4.4 MB, clean)" with a **Download chalo_chatbot.zip** button (the zip also lives at `public/chalo_chatbot.zip` so the download works even when workspace-file download fails — the owner's reported issue, fix deferred). Snapshot bumped to v1.3.0; next-steps list refreshed (SQL gate marked DONE, the Kaggle v28 steps with concrete slug/notebook names, the baseline-before-retrain recommendation, remaining dev-team/VAPT/OCI items). The old list still claimed the 4 UI/UX items were pending — stale since CODE-UPDATE-10; fixed.

### Verification

- Both v28 notebooks: JSON-valid, 31/21 cells, parsed-source checks pass (v28 paths/counts/`MODEL_VERSION`, `MAX_SEQ_LENGTH = 3072` in both, hyperparameters byte-identical to v27, **zero active v27 references** — only deliberate historical mentions in the change-notes).
- `package.sh` rebuild: junk gate 0 leaks; must-ship gate 13/13; `curl` on the served zip → HTTP 200, 4,511,354 bytes; only `.env.example` ships (no `.env`, no `audit_trail.db`).
- Dashboard browser-verified: banner + download link render, version badge v1.3.0, next-steps show the Kaggle v28 steps, zero console/page errors, mobile 390px footer-at-bottom intact, download button 324 px wide (touch-safe).

### Files changed (CODE-UPDATE-11)

New (2): `training/finetune_qwen25coder_TRAIN_KAGGLE_v28.ipynb`, `training/finetune_qwen25coder_GGUF_EXPORT_COLAB_v28.ipynb`. Code (1): `package.sh` (quoting fix + two gates). Docs (4): `training/README.md`, `STRUCTURE.md`, `docs/PROJECT_STATUS.md` (this file), `docs/SESSION_HANDOFF.md`. Dashboard (3): `public/status_snapshot.json`, `src/app/page.tsx` (download banner), `public/chalo_chatbot.zip` (rebuilt clean). Dataset/pipeline/backend: untouched.

### The bottom line

The owner's path to the v28 retrain is now unblocked end-to-end: re-download the zip (the earlier copy has the v27-pointing notebooks), upload `train_v28.jsonl` + `val_v28.jsonl` to Kaggle as `chaloschools-sql-dataset-v28`, import the v28 notebook, T4 ×1, ~1–1.5 h, then Colab GGUF export, point `start_llm.bat` at the new file, re-run the 50 golden questions. Recommended before that: capture the v27 baseline score. Nothing else is pending on the chatbot side.

---

## Update 2026-09-04 (later still) — Kaggle NameError fixed; full audit: nothing else missed (CODE-UPDATE-12)

The owner's first v28 Kaggle run failed with `NameError: OUTPUT_ROOT`. Cause: my v28 notebook conversion replaced the paths cell based on a truncated (900-char) view of the original — the `OUTPUT_ROOT = "/kaggle/working"` line after the asserts was dropped. Fixed by restoring the line verbatim; the notebook inside the rebuilt zip is re-verified.

**Audit answering "what else missed?" (proof, not spot-checks):** defined-name diff across every cell — TRAIN v27 54 names / v28 now 54, missing: none (the one regression was OUTPUT_ROOT); EXPORT 29/29, missing: none. Cell-by-cell diff — only the 4 + 3 intentional v28 edits (headers, paths, `MAX_SEQ_LENGTH` 3072, `MODEL_VERSION`, time comment) plus the now-fixed cell 8. Undefined-name scan on the fixed notebook — profile identical to the v27 original that trained successfully. Audit script kept at `/home/z/tmp_scripts/audit_v28_notebooks.py`.

**Owner unblock (pick either):** (a) in Kaggle, append `OUTPUT_ROOT = "/kaggle/working"` to the paths cell and Run All — the failure happened before training started, nothing lost; (b) re-download the fixed zip (4.4 MB, gates green) from the dashboard banner. Banner + snapshot (v1.3.1) updated to say exactly this.

Process lesson codified: full-cell reads before replacements; name-level diff after every notebook edit.

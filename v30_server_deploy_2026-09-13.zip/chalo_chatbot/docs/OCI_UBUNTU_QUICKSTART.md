# OCI Ubuntu Quickstart — ChaloSchools AI Secretary

**For:** the project owner hosting the AI Secretary on an Oracle Cloud (OCI) Ubuntu instance.
**What this is:** the **command-by-command Ubuntu companion** to `docs/OCI_DEPLOYMENT.md` (the master guide — topology, VCN/subnets, OCI Vault, WAF, and the VAPT production checklist live there).
**What it implements:** the **single-instance topology** from `OCI_DEPLOYMENT.md` §5.2 — nginx + FastAPI backend + llama.cpp LLM, all on ONE instance. That's the recommended starting point (first 5–10 clients, ~$60–80/month on an 8-OCPU E4.Flex). When you outgrow it or before the VAPT test, split into the two-instance topology per the master guide.

> Read this top to bottom once, then execute the steps in order. Every command is copy-pasteable. Placeholders you must replace: `<PUBLIC-IP>`, your SSH key path, and the domain name (or use the raw IP while testing).

---

## 0. What you need before starting

| Item | Notes |
|---|---|
| OCI account with the ability to launch instances | Always-Free / Pay-As-You-Go both work |
| An SSH key pair | `ssh-keygen -t ed25519 -f ~/.ssh/oci_key` on Linux/macOS, or PuTTYgen on Windows. You'll paste the **public** key when launching the instance. |
| The `chalo_chatbot/` package | the same folder you've been testing on Windows |
| The trained GGUF model file | `AISv27-qwen2.5-coder-7b-instruct.Q4_K_M.gguf` (~4.5 GB) — on your Windows machine at `D:\ggufs\` |
| (optional, for TLS) a domain name | e.g. `chatbot.chaloschools.in` with an A record → `<PUBLIC-IP>` |

---

## 1. Launch the instance (OCI console)

**Compute → Instances → Create instance.**

| Setting | Value | Why |
|---|---|---|
| Name | `chalo-ai-secretary` | — |
| Image | **Ubuntu 24.04** (Canonical, platform image) | Python 3.12 built in (backend needs 3.11+). Ubuntu 22.04 also works but ships Python 3.10 — see the note at the end of this section. |
| Shape | `VM.Standard.E4.Flex`, **8 OCPU / 24 GB RAM** | The GGUF (4.5 GB) + KV cache + backend + OS + headroom. 8 OCPUs = the minimum for tolerable 15–35 s query latency on CPU. |
| Boot volume | 50 GB | GGUF(s) + package + logs |
| Networking | Create/choose a VCN + **public subnet** | Leave "Assign a public IPv4 address" on. |
| SSH keys | Paste your public key | You need this to log in. |

Then click **Create**. When it's running, note the **Public IP**.

> **Ubuntu 22.04 instead?** Its default `python3` is 3.10, but the backend needs 3.11+:
> ```bash
> sudo add-apt-repository ppa:deadsnakes/ppa -y
> sudo apt update && sudo apt install -y python3.11 python3.11-venv
> # then use python3.11 everywhere this doc says python3
> ```
> Ubuntu 24.04 needs none of this — prefer it.

---

## 2. Open the ports — TWO places (the classic OCI gotcha)

### 2.1 The OCI Security List (console)

**Networking → Virtual Cloud Networks → your VCN → Security Lists → Default Security List** → **Add Ingress Rules**:

| Source | Protocol | Dest Port | Purpose |
|---|---|---|---|
| 0.0.0.0/0 | TCP | 80 | HTTP (will redirect to HTTPS) |
| 0.0.0.0/0 | TCP | 443 | HTTPS — the chat UI + API |

(SSH on 22 from anywhere is usually already in the default list. In production, tighten 22 to your office IP per `OCI_DEPLOYMENT.md` §3.2.)

### 2.2 The instance's own iptables (Ubuntu images ship with a blocking REJECT rule!)

**Even with the security list open, nothing will load** until you clear this. Log in first (see §3), then:

```bash
# See the rules — you'll find a "REJECT all" rule near the bottom of INPUT
sudo iptables -L INPUT --line-numbers

# Allow web traffic (INSERT puts ACCEPT above the REJECT rule)
sudo iptables -I INPUT -p tcp --dport 80 -j ACCEPT
sudo iptables -I INPUT -p tcp --dport 443 -j ACCEPT

# Persist across reboots
sudo apt update && sudo apt install -y iptables-persistent   # answer "Yes" to save current rules
# (or: sudo netfilter-persistent save)
```

Ports **8080 (LLM) and 8000 (backend) never open publicly** — both bind to `127.0.0.1` only. nginx is the single public door.

---

## 3. First login + base packages

```bash
ssh -i ~/.ssh/oci_key ubuntu@<PUBLIC-IP>
# Windows PowerShell: ssh -i $env:USERPROFILE\.ssh\oci_key.pem ubuntu@<PUBLIC-IP>
```

Then on the server:

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y unzip python3 python3-venv python3-pip nginx

# A dedicated service user that owns the app files (no login shell)
sudo useradd -r -m -d /opt/chalo-ai-secretary -s /usr/sbin/nologin chalo

# Optional but recommended: 8 GB swap as an OOM safety net
sudo fallocate -l 8G /swapfile && sudo chmod 600 /swapfile
sudo mkswap /swapfile && sudo swapon /swapfile
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab

python3 --version   # must be 3.11 or newer (Ubuntu 24.04 → 3.12)
```

---

## 4. Where the files go + how to get them there

Target layout:

```
/opt/chalo-ai-secretary/            ← home of the "chalo" user
├── chalo_chatbot/                  ← the package (from Windows)
│   ├── backend/                    ← main.py, security.py, requirements.txt, .env
│   ├── pipeline/                   ← 17 modules + schema_catalog.json
│   ├── vocab/                      ← synonyms.json + inject.py
│   └── frontend/                   ← chat.html + audit.html (copied to /var/www in step 9)
├── llama.cpp/
│   └── build/bin/llama-server      ← the LLM runtime (step 7)
├── models/
│   └── AISv27-qwen2.5-coder-7b-instruct.Q4_K_M.gguf   ← the 4.5 GB "brain"
└── venv/                           ← the Python virtualenv (step 5)

/var/www/chalo/                     ← chat.html + audit.html served by nginx
/etc/nginx/sites-available/chalo    ← the nginx site
/etc/systemd/system/chalo-llm.service        ← LLM service
/etc/systemd/system/chalo-backend.service    ← backend service
```

### 4.1 Upload from your Windows machine (PowerShell)

```powershell
# 1. zip the package (from the folder that CONTAINS chalo_chatbot)
Compress-Archive -Path .\chalo_chatbot -DestinationPath .\chalo_chatbot.zip -Force

# 2. upload the package + the GGUF (the ~4.5 GB upload is the slow part; let it run)
scp -i $env:USERPROFILE\.ssh\oci_key.pem .\chalo_chatbot.zip ubuntu@<PUBLIC-IP>:/tmp/
scp -i $env:USERPROFILE\.ssh\oci_key.pem "D:\ggufs\AISv27-qwen2.5-coder-7b-instruct.Q4_K_M.gguf" ubuntu@<PUBLIC-IP>:/tmp/
```

> Large file tip: if the upload keeps dying, use rsync over SSH from WSL/Git-Bash:
> `rsync -avzP -e "ssh -i ~/.ssh/oci_key" /mnt/d/ggufs/AISv27-qwen2.5-coder-7b-instruct.Q4_K_M.gguf ubuntu@<PUBLIC-IP>:/tmp/` (resumes where it stopped).

### 4.2 Unpack into place (back on the server)

```bash
sudo mkdir -p /opt/chalo-ai-secretary/models
sudo unzip /tmp/chalo_chatbot.zip -d /opt/chalo-ai-secretary/
sudo mv /tmp/AISv27-qwen2.5-coder-7b-instruct.Q4_K_M.gguf /opt/chalo-ai-secretary/models/
sudo chown -R chalo:chalo /opt/chalo-ai-secretary
rm /tmp/chalo_chatbot.zip
ls -la /opt/chalo-ai-secretary/chalo_chatbot/backend/main.py        # sanity check
ls -la /opt/chalo-ai-secretary/models/*.gguf                        # sanity check
```

---

## 5. Python virtualenv + backend dependencies

```bash
sudo python3 -m venv /opt/chalo-ai-secretary/venv
sudo /opt/chalo-ai-secretary/venv/bin/pip install --upgrade pip
sudo /opt/chalo-ai-secretary/venv/bin/pip install -r /opt/chalo-ai-secretary/chalo_chatbot/backend/requirements.txt
```

> **pyodbc note:** `requirements.txt` includes `pyodbc` (used only by the optional `local_db` mode). On Ubuntu it compiles against unixODBC — if the install fails, either `sudo apt install -y unixodbc-dev` and retry, or install everything else and skip it: `grep -v pyodbc requirements.txt | sudo /opt/chalo-ai-secretary/venv/bin/pip install -r /dev/stdin`. **Production uses `api_wrapper` mode** (the school's ExecuteQuery HTTPS API), which needs no ODBC driver.

---

## 6. Backend configuration (`backend/.env`)

> **v97 update (2026-09-07):** All ERP connection settings — GetUserContext URL, ExecuteQuery URL, per-school API keys, and the use_inline_params switch — now live in ONE file: `erp_config.json` at the project root. Edit it and restart the backend; no code changes. Full runbook: `docs/ERP_CONFIG_GUIDE.md`. The rest of this section describes the pre-v97 method and is kept for history.
> For current steps, follow `docs/ERP_CONFIG_GUIDE.md` instead.

The backend auto-loads `backend/.env` on startup (python-dotenv). The file is already in the package with your `V3_TestDatabase` tenant key. Edit the production values:

```bash
sudo -u chalo nano /opt/chalo-ai-secretary/chalo_chatbot/backend/.env
```

Set at minimum:

```ini
AI_SECRETARY_AUTH_TOKENS=<a-long-random-token-you-choose>       # what users type in chat.html Settings
AI_SECRETARY_ADMIN_TOKENS=<a-different-long-random-token>       # for audit.html / admin APIs
AI_SECRETARY_CORS_ORIGINS=https://chatbot.chaloschools.in       # not needed when same-origin via nginx, but harmless
AI_SECRETARY_DEBUG=false

# UI/UX item 4 (v1.3.0): the standard reply for unanswerable questions.
# Priority: this env var > "fallback_message" in feature_overrides.json > built-in default.
# Leave commented to use the default; set to empty string to disable.
# AI_SECRETARY_FALLBACK_MESSAGE=I'm sorry, I couldn't answer that question. Please try rephrasing it, or ask a different question.
```

(For full production hardening — Vault instead of .env, rate limits, LLM timeout — see `OCI_DEPLOYMENT.md` §4.)

---

## 7. llama.cpp + the GGUF

Download the prebuilt Linux binary (no compiler needed):

```bash
cd /tmp
# Get the LATEST tag from https://github.com/ggerganov/llama.cpp/releases
# (asset names look like llama-bXXXX-bin-ubuntu-avx2-x64.zip — pick ubuntu-avx2-x64)
wget https://github.com/ggerganov/llama.cpp/releases/download/b6318/llama-b6318-bin-ubuntu-avx2-x64.zip
sudo mkdir -p /opt/chalo-ai-secretary/llama.cpp
sudo unzip llama-b6318-bin-ubuntu-avx2-x64.zip -d /opt/chalo-ai-secretary/llama.cpp/
sudo chown -R chalo:chalo /opt/chalo-ai-secretary/llama.cpp
/opt/chalo-ai-secretary/llama.cpp/build/bin/llama-server --version   # sanity check
```

> **If the release zip layout ever differs**, find the binary: `sudo find /opt/chalo-ai-secretary/llama.cpp -name llama-server -type f` and adjust the path in the systemd unit below.
>
> **Building from source instead** (if you want AVX512 on EPYC): `sudo apt install -y build-essential cmake git` → `git clone https://github.com/ggerganov/llama.cpp /tmp/llama.cpp && cd /tmp/llama.cpp && cmake -B build -DGGML_NATIVE=ON && cmake --build build --target llama-server -j8` → binary at `/tmp/llama.cpp/build/bin/llama-server`; move it into `/opt/chalo-ai-secretary/llama.cpp/build/bin/`.

`--ctx-size 4096` is intentional — it pairs with the expanded system prompt (see `scripts/start_llm.bat` and `docs/SESSION_HANDOFF.md`, 2026-09-04). The Windows `.bat` launchers are replaced on Ubuntu by the systemd units below.

---

## 8. systemd services (replaces start_llm.bat / start_backend.bat)

### 8.1 The LLM service — `/etc/systemd/system/chalo-llm.service`

```ini
[Unit]
Description=ChaloSchools AI Secretary - llama.cpp LLM server (CLM 1.0)
After=network.target

[Service]
Type=simple
User=chalo
ExecStart=/opt/chalo-ai-secretary/llama.cpp/build/bin/llama-server -m /opt/chalo-ai-secretary/models/AISv27-qwen2.5-coder-7b-instruct.Q4_K_M.gguf --host 127.0.0.1 --port 8080 --ctx-size 4096 --threads 8
Restart=always
RestartSec=5
# 7B Q4_K_M (~4.5 GB weights + KV cache) fits easily in 24 GB; the cap is an OOM guard
MemoryMax=16G

[Install]
WantedBy=multi-user.target
```

### 8.2 The backend service — `/etc/systemd/system/chalo-backend.service`

```ini
[Unit]
Description=ChaloSchools AI Secretary - FastAPI backend (v1.3.0)
After=network.target chalo-llm.service
Wants=chalo-llm.service

[Service]
Type=simple
User=chalo
WorkingDirectory=/opt/chalo-ai-secretary/chalo_chatbot/backend
ExecStart=/opt/chalo-ai-secretary/venv/bin/uvicorn main:app --host 127.0.0.1 --port 8000
Restart=always
RestartSec=5
# backend/.env is auto-loaded by the app itself (python-dotenv)

[Install]
WantedBy=multi-user.target
```

### 8.3 Start both + verify

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now chalo-llm chalo-backend

# The LLM takes ~30-60s to mmap the 4.5 GB model. Watch it:
sudo journalctl -u chalo-llm -f          # wait for "server is listening on 127.0.0.1:8080"  (Ctrl+C to exit)

curl http://127.0.0.1:8080/health        # {"status":"ok"}  → LLM alive
curl http://127.0.0.1:8000/api/health    # {"status":"ok","rules_count":54,"version":"1.3.0",...}  → backend alive
```

---

## 9. nginx — serve chat.html + proxy /api/

```bash
# The static chat UI (the production frontend is the mobile app; chat.html is the web UI)
sudo mkdir -p /var/www/chalo
sudo cp /opt/chalo-ai-secretary/chalo_chatbot/frontend/chat.html /var/www/chalo/
sudo cp /opt/chalo-ai-secretary/chalo_chatbot/frontend/audit.html /var/www/chalo/

sudo tee /etc/nginx/sites-available/chalo >/dev/null <<'EOF'
server {
    listen 80;
    # use the domain if you have one; the raw IP works while testing
    server_name chatbot.chaloschools.in;

    root /var/www/chalo;
    index chat.html;

    # The backend API — everything under /api/ goes to FastAPI on localhost
    location /api/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_read_timeout 120s;   # LLM latency is 15-35s; give headroom
    }

    # The static chat UI
    location / {
        try_files $uri $uri/ =404;
    }
}
EOF

sudo ln -sf /etc/nginx/sites-available/chalo /etc/nginx/sites-enabled/chalo
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx

# Through nginx now:
curl http://localhost/api/health
```

Open `http://<PUBLIC-IP>/` in your browser → the chat UI loads.

**chat.html Settings for the hosted deployment:**

| Setting | Value |
|---|---|
| Backend URL | **leave empty** (same origin — nginx serves both the page and `/api/`) — or `https://chatbot.chaloschools.in` |
| Auth Token | the `AI_SECRETARY_AUTH_TOKENS` value from `backend/.env` |
| LLM Model | Chalo Language Model 1.0 (2.0/3.0 unlock when the v28/v29 GGUFs are deployed) |
| LLM URL | keep `http://localhost:8080/v1/chat/completions` — **the backend** (server-side) calls it; the browser never talks to port 8080 |
| Mode | `api_wrapper` + Target Database `V3_TestDatabase` + the ExecuteQuery URL (defaults are pre-filled) for real execution; `dry_run` to preview SQL |
| Context JSON | load your exported context file from your own machine (file input, stays client-side) |

Settings persist in the browser's localStorage.

---

## 10. TLS (Let's Encrypt) — when the DNS record exists

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d chatbot.chaloschools.in
# certbot rewrites the site file: 80 → 301 https, adds the 443 server + auto-renewal timer
sudo systemctl list-timers | grep certbot    # renewal is automatic
```

Then harden nginx to the full production config from **`OCI_DEPLOYMENT.md` §6** (HSTS, security headers, rate limits, 1 MB body cap) and add the OCI WAF (§7) before the VAPT test.

---

## 11. End-to-end verification

```bash
# 1. LLM                      → {"status":"ok"}
curl http://127.0.0.1:8080/health

# 2. Backend                  → {"status":"ok","pipeline_loaded":true,"rules_count":54,"version":"1.3.0",...}
curl http://127.0.0.1:8000/api/health

# 3. Through nginx            → same JSON as #2
curl http://localhost/api/health

# 4. From your own machine    → same JSON as #2
curl http://<PUBLIC-IP>/api/health
```

Then in the browser: open `http://<PUBLIC-IP>/` (or the domain), load the Context JSON in ⚙ Settings, set the auth token, ask a question, and watch the SQL + trace + answer come back. `audit.html` (sidebar → Audit Trail) shows the audit rows after the first questions.

---

## 12. Day-2 operations (the cheat sheet)

| Task | Command |
|---|---|
| Backend logs | `sudo journalctl -u chalo-backend -f` |
| LLM logs | `sudo journalctl -u chalo-llm -f` |
| Restart backend | `sudo systemctl restart chalo-backend` |
| Restart LLM | `sudo systemctl restart chalo-llm` |
| Swap in a new model (after v28 training) | upload the new GGUF into `/opt/chalo-ai-secretary/models/`, edit the `-m` path in `chalo-llm.service` (or name the new file the same), `sudo systemctl daemon-reload && sudo systemctl restart chalo-llm` — no backend change needed |
| Update the app | upload the new zip → `sudo unzip -o /tmp/chalo_chatbot.zip -d /opt/chalo-ai-secretary/` → `sudo chown -R chalo:chalo /opt/chalo-ai-secretary` → `sudo systemctl restart chalo-backend` |
| Update chat.html | `sudo cp /opt/chalo-ai-secretary/chalo_chatbot/frontend/chat.html /var/www/chalo/` |
| Back up the audit trail | `sudo cp /opt/chalo-ai-secretary/chalo_chatbot/backend/audit_trail.db ~/audit_backup_$(date +%F).db` (weekly) |
| Update the schema catalog | copy the new `schema_catalog.json` into `.../pipeline/` → restart backend |
| Health alarm | point an OCI alarm (or any uptime monitor) at `https://chatbot.chaloschools.in/api/health` — alert if non-200 or `"status" != "ok"` |

---

## 13. Troubleshooting

| Symptom | Cause → Fix |
|---|---|
| Page won't load from the internet, but `curl http://localhost/api/health` on the server works | The Ubuntu **iptables REJECT rule** (§2.2) — run the two `iptables -I INPUT` commands + persist. Also re-check the Security List (§2.1). |
| `401 Unauthorized` in the chat UI | The Auth Token in ⚙ Settings doesn't match `AI_SECRETARY_AUTH_TOKENS` in `backend/.env`. |
| Typing dots spin forever, backend log shows LLM timeouts | `sudo journalctl -u chalo-llm` — the model may still be loading (wait for "server is listening"), or check RAM: `free -h`. If OOM-killed, lower `MemoryMax` is NOT the fix — check the GGUF quant size (Q4_K_M ≈ 4.5 GB). |
| `Mode is 'api_wrapper' but no target_database set` | Fill Target Database + ExecuteQuery URL in ⚙ Settings (defaults are pre-filled for V3_TestDatabase). |
| `No tenant API key found for 'V3_TestDatabase'` | `AI_SECRETARY_TENANT_KEYS` missing from `backend/.env` (it's pre-filled in the package — check it survived the upload). |
| Slow answers (30 s+) | Expected on CPU. Options: more OCPUs, or a GPU instance shape later; keep the 7B (see PROJECT_STATUS 2026-09-03: don't shrink the brain). |
| Backend starts then dies repeatedly | `sudo journalctl -u chalo-backend -n 50` — usually Python version (< 3.11) or a broken venv; rebuild the venv (§5). |

---

## 14. What this quickstart deliberately does NOT cover

- **Two-instance topology, VCN design, OCI Vault for secrets, WAF, LB** → `docs/OCI_DEPLOYMENT.md` (do these before the VAPT test).
- **The v28 retrain / GGUF export** → `training/` + `docs/SESSION_HANDOFF.md`.
- **The mobile-app client** → `docs/API_CONTRACT.md` (your mobile team's work; the backend here is what it talks to).
- **Docker** — the project's ops plan lists Docker as optional; systemd (this doc) is the supported path on Ubuntu.

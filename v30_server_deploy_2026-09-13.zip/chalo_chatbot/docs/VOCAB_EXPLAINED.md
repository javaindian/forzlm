# What Is "Vocab"? — A Plain-Language Explainer

The word "vocab" comes up a lot in this project. This doc explains what it is, why it matters, and how the system handles it — with no jargon.

---

## 1. The problem vocab solves

The model (Qwen 2.5 Coder 7B, fine-tuned by you) was trained on one school's data. But ChaloSchools is multi-tenant — different branches of the same school have different real names for the same things:

| Thing | Branch 1 (CHALO INTERNATIONAL) | Branch 2 (Golden Gates Matriculation) |
|---|---|---|
| Subjects | "MATHS" (uppercase) | "Maths" (title case) |
| Sections | "BRAINY", "EXPERT", "FOUNDATION" (ability streams) | "A", "B", "C", "D", "E" (lettered) |
| Fee heads | "Admission Fee", "Tuition Fees", "Transport Fee" | "Admission Fee", "Tuition Fee", "Bus Fee I", "Bus Fee II", "Arrear Fee (22-23)" |
| Exam terms | "Term I", "Term II", "EoY" | "SUMMATIVE ASSESSMENT I", "MIDTERM-I", "JAN SAT1", "UNIT EXAM" |

The model learned one set of names during training. At runtime, it writes SQL using the names it learned. But the user's branch may store different names. So the model writes `WHERE sub.Name = 'MATHS'` and the branch's database has `'Maths'` — the query returns zero rows. The user sees an empty answer and thinks the chatbot is broken.

**This is the "vocab" problem: the model's vocabulary doesn't match the branch's real vocabulary.**

---

## 2. What "vocab" means in this project

> **v97 update (2026-09-07):** All ERP connection settings — GetUserContext URL, ExecuteQuery URL, per-school API keys, and the use_inline_params switch — now live in ONE file: `erp_config.json` at the project root. Edit it and restart the backend; no code changes. Full runbook: `docs/ERP_CONFIG_GUIDE.md`. The rest of this section describes the pre-v97 method and is kept for history.

"Vocab" is short for **the branch's real master-data vocabulary** — the actual names the branch's database stores for classes, sections, subjects, fee heads, exam terms, fee terms, enquiry statuses, designations, and roles.

The vocab comes from the **Context JSON** — the document the school's `GetUserContext` API returns when a user logs in. It looks like this (simplified):

```json
{
  "UserMasterDetails": {
    "Id": 116,
    "UserName": "abav",
    "UserBranchDetails": [
      {
        "ID": 2,
        "Name": "Golden Gates Matriculation Higher Secondary School",
        "Classes": [{"Name": "LKG", "DisplayOrder": 1}, ...],
        "Sections": ["A", "B", "C", "D", "E"],
        "Subjects": ["Maths", "English", "Physics", ...],
        "FeeHeads": ["Admission Fee", "Tuition Fee", "Bus Fee I", ...],
        "ExamTerms": ["SUMMATIVE ASSESSMENT I", "MIDTERM-I", ...]
      }
    ]
  }
}
```

Each branch's real names are right there. The chatbot's job is to make sure the SQL it generates uses **the names from the user's branch**, not the names the model memorized during training.

---

## 3. The two ways the system handles vocab

There are two modes, and the project owner chose **Option A** (the retrain path) as the long-term fix. But the system supports both, switchable by config.

### Mode 1 — STOPGAP (works today, with the v27 model)

The model is NOT told the branch's real names. It writes SQL using whatever it memorized during training. Then, AFTER the SQL is generated, the system checks each name the model used against the branch's real vocab:

1. The model writes `WHERE sub.Name = 'MATHS'`.
2. The system extracts the literal `'MATHS'` (the `entity_extractor` does this).
3. The system checks: is `'MATHS'` a real subject at this branch? The branch's Subjects are `["Maths", "English", "Physics", ...]`. No — the branch stores `'Maths'` (title case), not `'MATHS'`.
4. The system checks the **synonym store** (`vocab/synonyms.json`): is `'MATHS'` a known synonym for `'Maths'`? Yes — both map to the canonical concept key `SUBJ_MATHS`.
5. The system **rewrites the SQL**: `WHERE sub.Name = 'Maths'`. (This is the F6 fix — validate-and-substitute.)
6. The rewritten SQL is checked by the semantic engine, then executed against the branch's database.

**Analogy:** imagine a tourist who only speaks one dialect. They order "soda" at a restaurant. The waiter checks the menu, sees the local term is "pop", and silently translates the order to "pop" before sending it to the kitchen. The tourist gets what they wanted; the kitchen gets an order it understands.

**Pros:** works with the current v27 model (no retrain needed).
**Cons:** only works for names the synonym store knows about. A name the store doesn't recognize → the system asks the user to clarify (disambiguation).

### Mode 2 — FULL (needs the v28 retrain)

The model IS told the branch's real names, BEFORE it writes the SQL. The system prepends a "vocab block" to the system prompt:

```
You are a T-SQL expert for the ChaloSchools database...

This branch's real master-data values (use these EXACT names, do not invent):
- Classes: LKG, UKG, I, II, III, IV, V, VI, VII, VIII, IX, X, XI, XII
- Sections: A, B, C, D, E
- Subjects: Maths, English, Physics, Chemistry, ...
- Fee heads: Admission Fee, Tuition Fee, Bus Fee I, Bus Fee II, ...
- Exam terms: SUMMATIVE ASSESSMENT I, MIDTERM-I, ...
- Fee terms: Term 1, Term 2, Term 3
```

The model reads this, writes SQL using the branch's real names directly. No post-generation rewriting needed.

**Analogy:** instead of the tourist learning one dialect and the waiter translating, the tourist is handed a phrasebook with the local dialect's exact words before they order. They order in the local dialect directly.

**Pros:** the model writes the correct literal the first time; no synonym-store dependency; the model can also use the real names to reason about the question (e.g. it sees the sections are A/B/C/D/E and knows "8A" means Class 8 + Section A).
**Cons:** requires retraining the model with the vocab block in every training example's prompt (the v28 retrain). The v27 model was trained without it; appending it at runtime "derails" the model (it loops, drops the `@UserId` scoping — confirmed twice).

---

## 4. The synonym store (the bridge)

`vocab/synonyms.json` is the bridge for STOPGAP mode. It maps every way a user (or the model) might phrase a concept to a canonical key. Example for SUBJECT:

```json
{
  "SUBJECT": {
    "SUBJ_MATHS": ["Maths", "maths", "MATHS", "Mathematics", "mathematics", "Math", "math"],
    "SUBJ_ENGLISH": ["English", "ENGLISH", "english", "Eng", "ENG"],
    "SUBJ_PHYSICS": ["Physics", "PHYSICS", "physics", "Phy", "PHY"],
    ...
  }
}
```

When the system sees `'MATHS'` in the SQL and the branch stores `'Maths'`, it:
1. Looks up `'MATHS'` in the SUBJECT synonyms → finds the canonical key `SUBJ_MATHS`.
2. Checks all the synonyms for `SUBJ_MATHS` against the branch's real Subjects list.
3. Finds `'Maths'` is a real subject at this branch → rewrites the SQL literal.

The synonym store covers 9 concept types: CLASS, SECTION, SUBJECT, ENQUIRY_STATUS, FEE_HEAD, EXAM_TERM, FEE_TERM, DESIGNATION, ROLE. It's hand-curated from the v27 training data + the real Context JSON shapes.

---

## 5. Why the original `concept_store.db` was insufficient

The original `aisec.zip` shipped a SQLite database called `concept_store.db` with 86 synonyms — all for CLASS (GRADE_1 → "Class 1", "1st", "Grade 1", "I", etc.). Zero synonyms for the other 6 concept types that existed (SECTION, SUBJECT, ENQUIRY_STATUS, FEE_HEAD, EXAM_TERM). No FEE_TERM concept type at all.

So in the original system:
- "maths" → "MATHS" had no path. The system checked `'maths'` against the branch's `["MATHS", "ENGLISH", ...]` (case-sensitive), got no match, and returned "I don't recognize 'maths' as a subject." The user saw a refusal for a simple question.
- "Term 1" (fee term) vs "Term I" (exam term) had no disambiguation — there was no FEE_TERM concept type, so the system couldn't tell them apart.

**The vocab engine I built fixes this:** 9 concept types (including the new FEE_TERM), hand-curated synonyms for each, the validate-and-substitute path that rewrites the SQL literal, and the FULL-mode injection prompt for the v28 retrain.

---

## 6. The vocab engine's two jobs (summary)

1. **Translation (STOPGAP mode):** after the model writes SQL, translate the model's literals to the branch's real literals via the synonym store. Rewrite the SQL. (Works today.)
2. **Injection (FULL mode):** before the model writes SQL, tell it the branch's real literals so it writes them directly. (Needs the v28 retrain.)

Both modes share the same Context JSON source (the branch's real vocab) and the same synonym store. Switching is config-driven (`inject_vocab: false` for STOPGAP, `true` for FULL).

---

## 7. Where vocab shows up in the user experience

- **When it works (STOPGAP, synonym known):** the user asks "who teaches maths in 8A?" → the model writes `sub.Name = 'maths'` → the system rewrites it to `'Maths'` → the query runs → the user sees the teacher's name. The translation is invisible.

- **When it works (FULL mode, after retrain):** the model writes `sub.Name = 'Maths'` directly → no rewriting needed → the query runs → the user sees the teacher's name.

- **When it fails closed (STOPGAP, synonym unknown):** the user asks "who teaches geography in 8A?" → the model writes `sub.Name = 'geography'` → the system checks the branch's Subjects → "Geography" isn't in the list (the branch doesn't teach Geography) → the system asks "Which subject did you mean? Here are your branch's subjects: Maths, English, Physics, ..." The user picks one or rephrases.

- **When the branch uses different sections (the §26 finding):** the user asks "who teaches maths in 8A?" at branch 1 (which uses ability streams) → the model writes `secm.Name = 'A'` → the system checks the branch's Sections → "A" isn't there (the branch has BRAINY/EXPERT/FOUNDATION) → the system asks "Which section did you mean? Here are your branch's sections: BRAINY, EXPERT, FOUNDATION, INTELLIGENT, TALENTED." In FULL mode (after retrain), the model would write `secm.Name = 'TALENTED'` directly if the user said "8 TALENTED".

---

## 8. What the project owner's decision means

**Option A (retrain vocab-aware):** the long-term fix. The v28 retrain will have the vocab block in every training example's system prompt. After retraining, the model writes the branch's real names directly. The synonym store becomes a fallback, not the primary path.

**Until the retrain:** the system runs in STOPGAP mode (`inject_vocab: false`). The synonym store + validate-and-substitute handle the translation. Most common cases work (maths/Maths/MATHS/Mathematics all resolve). Edge cases (a branch-specific FeeHead like "TuitionFee 24-25" that the synonym store doesn't know) will ask for clarification.

**The v1.1 refinement:** expand the synonym store with the real FeeHead and ExamTerm names from the Golden Gates Context JSON (e.g. "Tuition Fees" → "Tuition Fee", "TuitionFee 24-25"; "Term I" → "SUMMATIVE ASSESSMENT I", "MIDTERM-I"). Or (better, v2.0): make the synonym store learn from the Context JSON's real values per-branch (synonym induction).

---

## 9. The bottom line

"Vocab" = the branch's real names for things. The model memorized one set of names during training; the branch may use different names. The vocab engine's job is to bridge that gap — either by translating the model's SQL after generation (STOPGAP, today) or by telling the model the real names before generation (FULL, after v28 retrain). Without it, the model writes SQL that doesn't match the branch's database and returns empty answers as confident results.

The original system had a CLASS-only synonym store. The new system has 9 concept types + the FEE_TERM the original was missing + the validate-and-substitute path the original didn't have. That's the difference between "I don't recognize 'maths'" and "Here's the maths teacher for 8A."

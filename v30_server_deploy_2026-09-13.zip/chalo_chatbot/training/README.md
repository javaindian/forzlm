# Training — Model Fine-Tuning

This folder contains everything you need to fine-tune the Qwen 2.5 Coder 7B model that powers the AI Secretary.

> **Current version: v29** (2026-09-10) — **3,651 train / 320 val**, checker-clean at **59 rules**.
> Build stages A → B1.5 → B1.6 → B1.7 → B2 → B2-mech → B2-struct → B2-stud006 → marks-rules →
> AVG-rules → scholastic → STAFF-004 → PII-001 → **B3 column fitness** (every per-student list now
> carries AdmissionNo + StudentName + Class + Section; centum-holder LIST rows added; raw-ID
> exposure removed) + **B4 month labels** (monthly trend buckets `FORMAT 'MM-yyyy'` —
> "06-2025", day-first; owner go 2026-09-10). Every before/after edit is logged in
> `v29_BUILD_REPORT.md`.
>
> **Status:** awaiting the owner's third-party audit (Stage D) → then Stage E (prompt freeze,
> fastpath rebuild, 15-question acceptance) → then the Kaggle retrain. Use the **v29** files below.
> The v28 (4,034 pairs, execution-verified 2026-09-04) and v27 files are kept as previous-version
> references.

## Files (v29 — current)

| File | What it is |
|------|------------|
| `train_v29.jsonl` | ★ **The v29 training split — 3,651 examples** (third-party audit, then Kaggle) |
| `val_v29.jsonl` | ★ **The v29 validation split — 320 examples** |
| `v29_BUILD_REPORT.md` | ★ Full build log: every stage, every before→after edit, residue lists |
| `b3_residue_list.json` | The 22 student lists intentionally lacking class/section (14 pre-admission applicants + 8 no safe class link) |
| `finetune_qwen25coder_TRAIN_KAGGLE_v29.ipynb` | ★ **Kaggle notebook — Stage 1: fine-tune Qwen 2.5 Coder 7B on v29** (v29 paths) |
| `train_v29.jsonl.preB4` + 8 more `.pre*` backups | Byte-for-byte rollback points for every rewrite stage (preB4 = before the B4 month-label change) |

**Audit/SSMS export** (in the audit package, not this folder): `sql_ssms/v29_train_ssms.sql`,
`sql_ssms/v29_val_ssms.sql` + `manifest.csv` — every dataset row as SSMS-runnable batches for
local execution against the ERP database copy (Stage D).

## Files (v28 — previous version reference)

| File | What it is |
|------|------------|
| `train_v28.jsonl` | The v28 training split — 3,712 examples (3,712 + 322 = 4,034 total) |
| `val_v28.jsonl` | The v28 validation split — 322 examples |
| `DATASET_VERSION_V28.txt` | Provenance card: sources, counts, gates, seed, instruction length |
| `prepare_data_v28.py` | Built the v28 dataset (54-rule semantic gate + sqlglot parse gate — HARD gates) |
| `finetune_qwen25coder_TRAIN_KAGGLE_v28.ipynb` | Kaggle notebook — Stage 1: fine-tune Qwen 2.5 Coder 7B on v28 |
| `finetune_qwen25coder_GGUF_EXPORT_COLAB_v28.ipynb` | Colab notebook — Stage 2: export the v28 adapter to GGUF |
| `finetune_qwen25coder_TRAIN_KAGGLE_v27.ipynb` | (previous) v27 training notebook — reference only |
| `finetune_qwen25coder_GGUF_EXPORT_COLAB_v27.ipynb` | (previous) v27 export notebook — reference only |
| `prepare_data_v27.py` | (previous) simpler v27 splitter, no validation gate |

## The training pipeline (v29 — current)

```
[AUDIT] third-party SSMS audit (Stage D)  →  Stage E (prompt freeze + fastpath rebuild
        + 15-question acceptance)         →  Kaggle v29 notebook (Stage 1)  →  Colab (Stage 2)
                    ↓                                   ↓                            ↓
 sql_ssms/*.sql + train/val_v29.jsonl          LoRA adapter (~300MB)      qwen25coder_*.gguf
 (3,651 + 320 pairs, 59-rule clean)            download from              Q4_K_M, ~4-5 GB →
                                               Kaggle Output tab          VPS scripts/start_llm.bat
```

## The training pipeline (v28 — history)

```
[DONE] prepare_data_v28.py  →  Kaggle v28 notebook (Stage 1)  →  Colab v28 notebook (Stage 2)
        ↓                              ↓                                ↓
 train_v28.jsonl + val_v28.jsonl   LoRA adapter (~300MB)      qwen25coder_chaloschools_v28*.gguf
 (4,034 pairs, 0 gate failures,      download from              Q4_K_M, ~4-5 GB →
  0 execution errors on local DB)    Kaggle Output tab          scripts/start_llm.bat
```

## How to run (the short version)

1. **Prerequisites on Kaggle** (all free):
   - A Kaggle account with **phone verification** (required to enable GPUs)
   - GPU quota: ~30 h/week free — the v28 run needs **~1–1.5 h** on 1× T4
   - (Optional) a Hugging Face token, if you want to push the adapter to the Hub
     instead of downloading it from the Kaggle Output tab

2. **Upload the dataset:**
   - Kaggle → **Datasets → New Dataset**
   - Upload **`train_v29.jsonl`** and **`val_v29.jsonl`** (both from this folder) — AFTER the third-party audit is closed
   - Name it `chaloschools-sql-dataset-v29` (or any slug — then edit `TRAIN_PATH`/`VAL_PATH`
     in the notebook's paths cell to match)

3. **Fine-tune (Stage 1, Kaggle):**
   - Create a new Kaggle Notebook → File → Import `finetune_qwen25coder_TRAIN_KAGGLE_v29.ipynb`
   - Settings (right panel): **Accelerator → GPU T4 x2**, **Internet → On**
   - "+ Add Input" → attach your `chaloschools-sql-dataset-v29` dataset
   - Run all cells. Same hyperparameters as v28 (temperature 0.1, `MAX_SEQ_LENGTH = 3072` —
     the v29 instruction + B3-widened rows fit; the notebook checks the longest example)
   - Download the `qwen25coder_chaloschools_lora/` folder from the Output tab (~300 MB)

4. **Export to GGUF (Stage 2, Colab):**
   - Open `finetune_qwen25coder_GGUF_EXPORT_COLAB_v28.ipynb` in Google Colab (GPU runtime)
     — the export procedure is version-agnostic; point it at your v29 adapter folder
   - Run all cells (uses llama.cpp's `convert_hf_to_gguf.py` + `quantize`)
   - Download the `.gguf` file (Q4_K_M quantization, ~4–5 GB)

5. **Place the GGUF:**
   - Put the `.gguf` file where `scripts/start_llm.bat` expects it
     (default: `D:\models\qwen25coder_chaloschools_v27.gguf` — edit the .bat to point at your v28 file)
   - See `docs/diagrams/04-llm-setup.drawio` for a visual

6. **Verify the retrain:**
   - Stage E: rebuild the fastpath from v29, then run the 15-question acceptance +
     phrasing-variant test (see `V63_RELEASE_NOTES.md` §10 for why this comes first)
   - Re-run the 50 golden questions (`scripts/run_50.bat`) and compare against the
     pre-retrain baseline — target <5% mismatch

## Important notes

- **Recommended before training:** the third-party SSMS audit (Stage D) closes first —
  every batch that errors is a finding (see the audit package `README_AUDIT.md`).
- **The v29 dataset passed every gate:** 59-rule semantic validation (0 violations —
  final sweep), parens balanced, 0 duplicate questions, question-drift checks on every
  rewrite stage, and per-edit checker gating during B3 (see `v29_BUILD_REPORT.md`).
  The v28 baseline beneath it was execution-verified (4,034/4,034 clean, 2026-09-04);
  v29 rows are lineage-tracked from that baseline in the build report.
- **The model needs ~8 GB VRAM** for training (Qwen 2.5 Coder 7B in 4-bit). Kaggle T4 (16 GB)
  is comfortable; the notebook deliberately uses only 1 of the 2 T4s (faster per Unsloth's own
  benchmarks).
- **The GGUF needs ~5 GB RAM** at inference time (Q4_K_M quantization). A modern laptop
  (8 GB+ RAM) is fine for local testing.
- **v29 carries the expanded instruction** (the frozen system prompt with the knowledge
  block incl. parent-subjects + staff on-hold + PII blocks) on every row — the same prompt
  the deployed backend serves.

## See also

- `DATASET_VERSION_V28.txt` — provenance of every number above
- `docs/INSTRUCTION_IMPROVEMENT.md` — how to improve the frozen system prompt
- `../semantic_validation/README.md` — how to validate + clean the training dataset
- `../sql_tests/README.txt` — the SSMS execution kit that validated the labels
- `docs/diagrams/04-llm-setup.drawio` — visual flow of the LLM setup

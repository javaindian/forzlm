# v29 build report (Stage A+B: checker-driven rewrites)

- checker: production semantic_rules.check_sql (54 rules)

## Summary

- fix:FEE-007:injected-date-lookup: 137
- fix:STUD-005:injected-date-lookup: 32
- train_v29.jsonl:clean: 3297
- train_v29.jsonl:fixed: 157
- train_v29.jsonl:manual: 202
- val_v29.jsonl:clean: 288
- val_v29.jsonl:fixed: 12
- val_v29.jsonl:manual: 17

## Manual rows (never guessed — per-row decision)

### train_v29.jsonl (202)
- #57: What is the total demand for tuition fees specifically? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #65: Subject-wise average marks — [HIGH] STUD-006: Subject_Master (alias s) joined on BranchID — cartesian product.
- #74: What is the term-wise fee collection breakdown? — [MEDIUM] FEE-025: Term-wise answer returns Term_ID (a numeric ID) without joining TermMaster.
- #82: I need the top performers in Mathematics — [HIGH] STUD-006: Subject_Master (alias s) joined on BranchID — cartesian product.
- #107: How many students don't use transport? — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #124: Branch-wise total fee demand this year — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #135: Top performers in Mathematics — [HIGH] STUD-006: Subject_Master (alias s) joined on BranchID — cartesian product.
- #140: How many students scoring centum in each subject do we have? — [HIGH] STUD-006: Subject_Master (alias s) joined on BranchID — cartesian product.
- #173: Total students enrolled vs appeared in exams — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #177: How many students were promoted last year? — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #185: Show term-wise outstanding fees. — [MEDIUM] FEE-025: Term-wise answer returns Term_ID (a numeric ID) without joining TermMaster.
- #219: What percentage of total demand is given as concession? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #222: How many students per Class who are active do we have? — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #225: List students who failed in any subject this term — [HIGH] EXAM-007: Marks query about exam-term results has no ExamTypeMaster/ExamTermMaster join. Marks filter by EXAM term via ExamTypeMaster.TermID → ExamTermMaster.ID.
- #256: What's the term-wise fee collection breakdown? — [MEDIUM] FEE-025: Term-wise answer returns Term_ID (a numeric ID) without joining TermMaster.
- #258: What's the total demand for tuition fees specifically? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #297: How many transport students are absent today? — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #303: What's the total demand for Perambur branch? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #317: Let me see leave applications submitted today — [HIGH] LEAVE-001: Leave query omits the leave-status filter — inactive leave entries included.
- #326: Hey, what's the tuition fee outstanding across all classes? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #327: So, what's the bus fee outstanding for students who require transport? — [HIGH] FEE-009: Outstanding query joins StudentAcademicDetail but omits the TC-issued filter.
- #330: So, what's the library fee demand and collection? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #370: Staff leave category wise count — [HIGH] STAFF-004: Staff question uses EmployeeMaster — the payroll twin, not the staff table.
- #398: Students whose section was changed and who have pending fees — [HIGH] FEE-009: Outstanding query joins StudentAcademicDetail but omits the TC-issued filter.
- #416: Hey, what's the total fee demand for Class 5? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #417: What is the month-wise fee head collection pivot? — [HIGH] FEE-024: Fee-HEAD question grouped by fee GROUP (FeesGroup_Name).
- #435: Show me students with more than 3 months fee pending — [HIGH] FEE-004: Outstanding query omits IsIncludedInLumpSum filter (risks double-counting)., [HIGH] FEE-009: Outstanding query joins StudentAcademicDetail but omits the TC-issued filter., [MEDIUM] FEE-022: Academic-fee query omits IsDonation = 0 filter.
- #472: Maths mein kaun top kiya? — [HIGH] STUD-006: Subject_Master (alias s) joined on BranchID — cartesian product.
- #474: Show concession given for each fee type. — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #479: Show students admitted after June 2025 — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #519: Hey, what's the total fee demand for the current academic year? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #523: List all unpaid late fees for Class 10 students. — [HIGH] FEE-009: Outstanding query joins StudentAcademicDetail but omits the TC-issued filter.
- #581: Top 5 students in Hindi subject — [HIGH] STUD-006: Subject_Master (alias s) joined on BranchID — cartesian product.
- #585: Tell me about the subject toppers for Class 10 — [HIGH] STUD-006: Subject_Master (alias s) joined on BranchID — cartesian product.
- #620: What are the students who failed in all subjects? — [HIGH] EXAM-007: Marks query about exam-term results has no ExamTypeMaster/ExamTermMaster join. Marks filter by EXAM term via ExamTypeMaster.TermID → ExamTermMaster.ID.
- #655: Class-wise collected vs pending comparison — [HIGH] FEE-004: Outstanding query omits IsIncludedInLumpSum filter (risks double-counting)., [MEDIUM] FEE-022: Academic-fee query omits IsDonation = 0 filter.
- #672: How many single-day vs multi-day leaves were taken this month? — [HIGH] LEAVE-001: Leave query omits the leave-status filter — inactive leave entries included.
- #691: How many students owe between 10000 and 50000? — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #765: How many new admissions did we get each year? — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #802: Students who failed in Mathematics — [HIGH] EXAM-007: Marks query about exam-term results has no ExamTypeMaster/ExamTermMaster join. Marks filter by EXAM term via ExamTypeMaster.TermID → ExamTermMaster.ID., [HIGH] STUD-006: Subject_Master (alias s) joined on BranchID — cartesian product.
- #850: Bank-wise salary disbursement for last month — [HIGH] STAFF-005: Salary/attendance staff query omits StaffStatus_ID = 1 — resigned staff included.
- #866: What are the most common reasons for leave applications? — [HIGH] LEAVE-001: Leave query omits the leave-status filter — inactive leave entries included.
- #887: What's the total fee collected via cheque that later bounced? — [HIGH] FEE-011: FeesCollection collection query omits ChequeStatus_ID filter.
- #907: Which fee head contributes the most to collection? — [HIGH] FEE-024: Fee-HEAD question grouped by fee GROUP (FeesGroup_Name).
- #944: How many salary structures exist? — [HIGH] STAFF-005: Salary/attendance staff query omits StaffStatus_ID = 1 — resigned staff included.
- #947: Which class has the highest pending fees? — [HIGH] FEE-004: Outstanding query omits IsIncludedInLumpSum filter (risks double-counting)., [HIGH] FEE-009: Outstanding query joins StudentAcademicDetail but omits the TC-issued filter., [MEDIUM] FEE-022: Academic-fee query omits IsDonation = 0 filter.
- #952: Students failing in both Maths and Science — [HIGH] STUD-006: Subject_Master (alias s) joined on BranchID — cartesian product.
- #954: How much did each fee head collect compared to last year? — [HIGH] FEE-024: Fee-HEAD question grouped by fee GROUP (FeesGroup_Name).
- #967: What's the subject-wise fail count? — [HIGH] STUD-006: Subject_Master (alias s) joined on BranchID — cartesian product.
- #969: What is the term-wise fee collection status? — [MEDIUM] FEE-025: Term-wise answer returns Term_ID (a numeric ID) without joining TermMaster.
- #1034: So, what's the total tuition fee outstanding? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #1038: Show me staff count by salary structure — [HIGH] STAFF-005: Salary/attendance staff query omits StaffStatus_ID = 1 — resigned staff included.
- #1064: What's the class-wise student count with average marks? — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #1091: Weakest subject across all classes — [HIGH] STUD-006: Subject_Master (alias s) joined on BranchID — cartesian product.
- #1092: Class-wise count of failed students — [HIGH] EXAM-007: Marks query about exam-term results has no ExamTypeMaster/ExamTermMaster join. Marks filter by EXAM term via ExamTypeMaster.TermID → ExamTermMaster.ID.
- #1106: Show fee demand and collection for Section A of Class 8. — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #1119: Gimme the total outstanding for this year — [HIGH] FEE-004: Outstanding query omits IsIncludedInLumpSum filter (risks double-counting)., [MEDIUM] FEE-022: Academic-fee query omits IsDonation = 0 filter.
- #1180: Staff shift wise distribution — [HIGH] STAFF-004: Staff question uses EmployeeMaster — the payroll twin, not the staff table.
- #1181: How many students got admitted under the regular admission process this year? — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #1190: employee bank account details for salary transfer — [HIGH] STAFF-005: Salary/attendance staff query omits StaffStatus_ID = 1 — resigned staff included.
- #1196: How much was collected in July against the demand? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #1208: Any staff on hold right now? — [HIGH] STAFF-004: Staff question uses EmployeeMaster — the payroll twin, not the staff table.
- #1235: Give me the demand vs collected for the Guduvanchery branch — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #1283: Give me the weakest subject across all classes — [HIGH] STUD-006: Subject_Master (alias s) joined on BranchID — cartesian product.
- #1287: What is the Term 3 demand for Class 10? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #1288: Show month-wise total demand and total collected. — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #1307: What is the total fee demand for this academic year? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #1330: Hey, what's the recovery rate for tuition fees specifically? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #1352: Which class has the highest number of new admissions? — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #1360: Any staff on hold? — [HIGH] STAFF-004: Staff question uses EmployeeMaster — the payroll twin, not the staff table.
- #1430: How much late fee is pending for Class 9 students? — [HIGH] FEE-009: Outstanding query joins StudentAcademicDetail but omits the TC-issued filter.
- #1437: Show the fee name wise demand and collection. — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #1446: How many staff are on hold? — [HIGH] STAFF-004: Staff question uses EmployeeMaster — the payroll twin, not the staff table.
- #1447: Show leave applications submitted today. — [HIGH] LEAVE-001: Leave query omits the leave-status filter — inactive leave entries included.
- #1458: Number of students scoring centum in each subject — [HIGH] STUD-006: Subject_Master (alias s) joined on BranchID — cartesian product.
- #1501: Show the class-wise fee demand and collection. — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #1541: What percentage of fees have been collected so far this year? — [HIGH] FEE-011: FeesCollection collection query omits ChequeStatus_ID filter.
- #1561: How many students failed in each class? — [HIGH] EXAM-007: Marks query about exam-term results has no ExamTypeMaster/ExamTermMaster join. Marks filter by EXAM term via ExamTypeMaster.TermID → ExamTermMaster.ID.
- #1575: What is the recovery rate for tuition fees specifically? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #1583: Staff not on hold — [HIGH] STAFF-004: Staff question uses EmployeeMaster — the payroll twin, not the staff table.
- #1633: Attendance of students in Red house today — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #1655: What is the total fee demand for Class 5? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #1663: List staff members whose salary is on hold — [HIGH] STAFF-005: Salary/attendance staff query omits StaffStatus_ID = 1 — resigned staff included.
- #1681: New admissions in July for Class 1 — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #1684: Compare total demand vs collection per branch — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #1702: Show class-wise pending late fee totals. — [HIGH] FEE-009: Outstanding query joins StudentAcademicDetail but omits the TC-issued filter.
- #1717: I need the fail percentage by subject — [HIGH] STUD-006: Subject_Master (alias s) joined on BranchID — cartesian product.
- #1751: fee outstanding by term — [MEDIUM] FEE-025: Term-wise answer returns Term_ID (a numeric ID) without joining TermMaster.
- #1768: What is the total demand amount for April month? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #1769: What percentage of staff are on hold? — [HIGH] STAFF-004: Staff question uses EmployeeMaster — the payroll twin, not the staff table.
- #1776: Show fee-name-wise demand and collection. — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #1806: Students with pending for more than 3 months — [HIGH] FEE-004: Outstanding query omits IsIncludedInLumpSum filter (risks double-counting)., [HIGH] FEE-009: Outstanding query joins StudentAcademicDetail but omits the TC-issued filter., [MEDIUM] FEE-022: Academic-fee query omits IsDonation = 0 filter.
- #1825: List students who failed in all subjects — [HIGH] EXAM-007: Marks query about exam-term results has no ExamTypeMaster/ExamTermMaster join. Marks filter by EXAM term via ExamTypeMaster.TermID → ExamTermMaster.ID.
- #1839: Which subject has the most failures? — [HIGH] STUD-006: Subject_Master (alias s) joined on BranchID — cartesian product.
- #1872: Year-wise count of students who got promoted — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #1920: What's the class-wise collected vs pending comparison? — [HIGH] FEE-004: Outstanding query omits IsIncludedInLumpSum filter (risks double-counting)., [MEDIUM] FEE-022: Academic-fee query omits IsDonation = 0 filter.
- #1923: transport fee pending for this term — [HIGH] FEE-013: Current-term fee query has no date window on TermMaster.
- #1931: List staff who have not taken any leave this year — [HIGH] LEAVE-001: Leave query omits the leave-status filter — inactive leave entries included.
- #1939: Can you list out all fee heads with their amounts for Class 8? — [MEDIUM] FEE-025: Fee-head answer returns Fees_Head_ID (a numeric ID) without joining Fees_Master.
- #1943: Which students have not cleared their dues? — [HIGH] FEE-004: Outstanding query omits IsIncludedInLumpSum filter (risks double-counting)., [HIGH] FEE-009: Outstanding query joins StudentAcademicDetail but omits the TC-issued filter., [MEDIUM] FEE-022: Academic-fee query omits IsDonation = 0 filter.
- #1944: Let me see term-wise collection — [MEDIUM] FEE-025: Term-wise answer returns Term_ID (a numeric ID) without joining TermMaster.
- #1945: How many new students enrolled this week? — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #1979: What is the total amount collected against the fee demand this year? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #2032: Pull up fee demand and collection for Section A of Class 8 — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #2049: Are new admissions still coming in or have they slowed down? — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #2079: What is the total demand for KG classes (LKG, UKG)? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #2098: List students who have paid nothing and have demand more than 30000. — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #2109: What is the total demand for optional fees? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #2121: New admissions vs existing students - marks comparison — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #2122: What is the total demand for Perambur branch? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #2133: List all fee heads with their amounts for Class 8 — [MEDIUM] FEE-025: Fee-head answer returns Fees_Head_ID (a numeric ID) without joining Fees_Master.
- #2151: What's the Term 3 demand for Class 10? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #2153: how many employees have their salary on hold? — [HIGH] STAFF-005: Salary/attendance staff query omits StaffStatus_ID = 1 — resigned staff included.
- #2177: Classes that have no new admissions this year — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #2274: What's the average outstanding per student in each Class who uses transport? — [HIGH] FEE-009: Outstanding query joins StudentAcademicDetail but omits the TC-issued filter.
- #2287: Pull up term-wise outstanding fees — [MEDIUM] FEE-025: Term-wise answer returns Term_ID (a numeric ID) without joining TermMaster.
- #2292: Which class received the most concession as a percentage of its demand? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #2321: Class-wise fee dues summary — [HIGH] FEE-004: Outstanding query omits IsIncludedInLumpSum filter (risks double-counting)., [HIGH] FEE-009: Outstanding query joins StudentAcademicDetail but omits the TC-issued filter., [MEDIUM] FEE-022: Academic-fee query omits IsDonation = 0 filter.
- #2340: I need to see the top 10 zero-payment students sorted by demand amount — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #2352: So, how many staff have salary structure ID 1? — [HIGH] STAFF-005: Salary/attendance staff query omits StaffStatus_ID = 1 — resigned staff included.
- #2362: Pull up the class-wise fee demand and collection — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #2372: So, what's the total admission fee collected vs demand? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #2376: Give me a list of all unpaid late fees for Class 10 students — [HIGH] FEE-009: Outstanding query joins StudentAcademicDetail but omits the TC-issued filter.
- #2378: What is the average fee demand per student? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #2384: Subject-wise fail count — [HIGH] STUD-006: Subject_Master (alias s) joined on BranchID — cartesian product.
- #2386: What is the total demand of students who have paid nothing? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #2392: Can you show me staff count by salary structure? — [HIGH] STAFF-005: Salary/attendance staff query omits StaffStatus_ID = 1 — resigned staff included.
- #2397: What's the count for of staff on hold? — [HIGH] STAFF-004: Staff question uses EmployeeMaster — the payroll twin, not the staff table.
- #2424: So, what's the month-wise fee head collection pivot? — [HIGH] FEE-024: Fee-HEAD question grouped by fee GROUP (FeesGroup_Name).
- #2439: How many staff have salary structure ID 1? — [HIGH] STAFF-005: Salary/attendance staff query omits StaffStatus_ID = 1 — resigned staff included.
- #2442: How many fee heads does Class 8 have? — [MEDIUM] FEE-025: Fee-head answer returns Fees_Head_ID (a numeric ID) without joining Fees_Master.
- #2452: So, how many students were admitted today? — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #2472: show me the salary structure template for employee ID 5 — [HIGH] RBAC-SALARY: Salary query has no branch scoping.
- #2501: Let me see students with more than 3 months fee pending — [HIGH] FEE-004: Outstanding query omits IsIncludedInLumpSum filter (risks double-counting)., [HIGH] FEE-009: Outstanding query joins StudentAcademicDetail but omits the TC-issued filter., [MEDIUM] FEE-022: Academic-fee query omits IsDonation = 0 filter.
- #2518: How many distinct fee types are configured this year? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #2526: Show the top 10 zero-payment students sorted by demand amount. — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #2528: What are the staff members whose salary is on hold? — [HIGH] STAFF-005: Salary/attendance staff query omits StaffStatus_ID = 1 — resigned staff included.
- #2555: What is the average outstanding per student in each class who uses transport? — [HIGH] FEE-009: Outstanding query joins StudentAcademicDetail but omits the TC-issued filter.
- #2571: What's the month-wise fee head collection pivot? — [HIGH] FEE-024: Fee-HEAD question grouped by fee GROUP (FeesGroup_Name).
- #2586: Subject toppers for Class 10 — [HIGH] STUD-006: Subject_Master (alias s) joined on BranchID — cartesian product.
- #2600: I need to see class-wise pending late fee totals — [HIGH] FEE-009: Outstanding query joins StudentAcademicDetail but omits the TC-issued filter.
- #2601: Show term-wise collection — [MEDIUM] FEE-025: Term-wise answer returns Term_ID (a numeric ID) without joining TermMaster.
- #2616: Fee heads that have never been collected from any student — [MEDIUM] FEE-025: Fee-head answer returns Fees_Head_ID (a numeric ID) without joining Fees_Master.
- #2626: percentage of students in hostel — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #2640: Can you show month-wise total demand and total collected? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #2663: Show leave type-wise distribution for this year — [HIGH] LEAVE-001: Leave query omits the leave-status filter — inactive leave entries included.
- #2674: Top 5 scorers in English — [HIGH] STUD-006: Subject_Master (alias s) joined on BranchID — cartesian product.
- #2692: How many students have zero payment against their demand? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #2708: So, what's the total demand for KG classes (LKG, UKG)? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #2716: What's the staff not on hold? — [HIGH] STAFF-004: Staff question uses EmployeeMaster — the payroll twin, not the staff table.
- #2772: What percentage of the total demand has been collected so far? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #2791: Class-wise student count with average marks — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #2794: Outstanding amount comparison year on year — [HIGH] FEE-004: Outstanding query omits IsIncludedInLumpSum filter (risks double-counting)., [MEDIUM] FEE-022: Academic-fee query omits IsDonation = 0 filter.
- #2809: What is the tuition fee outstanding across all classes? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #2812: Can you show concession given for each fee type? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #2813: Students who failed in more than 3 subjects — [HIGH] EXAM-007: Marks query about exam-term results has no ExamTypeMaster/ExamTermMaster join. Marks filter by EXAM term via ExamTypeMaster.TermID → ExamTermMaster.ID.
- #2816: How much fee is pending? — [HIGH] FEE-004: Outstanding query omits IsIncludedInLumpSum filter (risks double-counting)., [MEDIUM] FEE-022: Academic-fee query omits IsDonation = 0 filter.
- #2859: Show the top 5 classes by total fee demand. — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #2869: Show class-wise tuition fee outstanding. — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #2876: What is the bus fee outstanding for students who require transport? — [HIGH] FEE-009: Outstanding query joins StudentAcademicDetail but omits the TC-issued filter.
- #2885: Fee pending students in Class 5 with parent contact — [HIGH] FEE-004: Outstanding query omits IsIncludedInLumpSum filter (risks double-counting)., [MEDIUM] FEE-022: Academic-fee query omits IsDonation = 0 filter.
- #2898: New admission students who are absent today — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #2963: Subject performance comparison between Term 1 and Term 2 — [HIGH] STUD-006: Subject_Master (alias s2) joined on BranchID — cartesian product.
- #2964: How much tuition fee is outstanding? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #2979: Who topped in Science? — [HIGH] STUD-006: Subject_Master (alias s) joined on BranchID — cartesian product.
- #2991: I need the payment mode wise staff count — [HIGH] STAFF-004: Staff question uses EmployeeMaster — the payroll twin, not the staff table.
- #3001: How many distinct fee types are charged this year? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #3021: What is the total fee demand for the current academic year? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #3023: What's the total demand amount for April month? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #3027: Show staff who have applied for more than 5 days leave at once. — [HIGH] LEAVE-001: Leave query omits the leave-status filter — inactive leave entries included.
- #3040: What is the net demand after concessions for the academic year? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #3057: How many staff have salary on hold? — [HIGH] STAFF-005: Salary/attendance staff query omits StaffStatus_ID = 1 — resigned staff included.
- #3062: Students who failed only in one subject — [HIGH] EXAM-007: Marks query about exam-term results has no ExamTypeMaster/ExamTermMaster join. Marks filter by EXAM term via ExamTypeMaster.TermID → ExamTermMaster.ID.
- #3091: Count of staff on hold — [HIGH] STAFF-004: Staff question uses EmployeeMaster — the payroll twin, not the staff table.
- #3126: Staff on hold who are also absent today — [HIGH] STAFF-004: Staff question uses EmployeeMaster — the payroll twin, not the staff table.
- #3130: How many students got admission in April this year? — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #3139: Can you show class-wise tuition fee outstanding? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #3149: Who's the students who failed in Mathematics? — [HIGH] EXAM-007: Marks query about exam-term results has no ExamTypeMaster/ExamTermMaster join. Marks filter by EXAM term via ExamTypeMaster.TermID → ExamTermMaster.ID., [HIGH] STUD-006: Subject_Master (alias s) joined on BranchID — cartesian product.
- #3159: What is the total demand for primary classes (Class 1 to 5)? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #3171: Fee head-wise collection breakdown for this year — [HIGH] FEE-024: Fee-HEAD question grouped by fee GROUP (FeesGroup_Name).
- #3184: So, what's the average fee demand per student? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #3192: Rank all fee heads by pending amount — [HIGH] FEE-004: Outstanding query omits IsIncludedInLumpSum filter (risks double-counting)., [MEDIUM] FEE-022: Academic-fee query omits IsDonation = 0 filter.
- #3202: Which month had the highest number of leave applications? — [HIGH] LEAVE-001: Leave query omits the leave-status filter — inactive leave entries included.
- #3210: I need the top 5 scorers in English — [HIGH] STUD-006: Subject_Master (alias s) joined on BranchID — cartesian product.
- #3212: Give me the class-wise count of students using transport — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #3284: So, what's the net demand after concessions for the academic year? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #3338: How much money is still due from students? — [HIGH] FEE-004: Outstanding query omits IsIncludedInLumpSum filter (risks double-counting)., [MEDIUM] FEE-022: Academic-fee query omits IsDonation = 0 filter.
- #3349: What is the total admission fee collected vs demand? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #3351: I need to see staff who have applied for more than 5 days leave at once — [HIGH] LEAVE-001: Leave query omits the leave-status filter — inactive leave entries included.
- #3437: Hey, what's the total demand for primary classes (Class 1 to 5)? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #3441: Is anyone's salary currently held? — [HIGH] STAFF-005: Salary/attendance staff query omits StaffStatus_ID = 1 — resigned staff included.
- #3443: Yo, how much is still pending from Class 9? — [HIGH] FEE-004: Outstanding query omits IsIncludedInLumpSum filter (risks double-counting)., [HIGH] FEE-009: Outstanding query joins StudentAcademicDetail but omits the TC-issued filter., [MEDIUM] FEE-022: Academic-fee query omits IsDonation = 0 filter.
- #3444: What's the class-wise count of failed students? — [HIGH] EXAM-007: Marks query about exam-term results has no ExamTypeMaster/ExamTermMaster join. Marks filter by EXAM term via ExamTypeMaster.TermID → ExamTermMaster.ID.
- #3451: Transport fee collection for this term — [HIGH] FEE-013: Current-term fee query has no date window on TermMaster.
- #3522: Which day of the week has the most leave applications? — [HIGH] LEAVE-001: Leave query omits the leave-status filter — inactive leave entries included.
- #3527: Highest scoring student in each subject — [HIGH] STUD-006: Subject_Master (alias s) joined on BranchID — cartesian product.
- #3533: Give me a summary of total payable vs collected vs pending — [HIGH] FEE-004: Outstanding query omits IsIncludedInLumpSum filter (risks double-counting)., [MEDIUM] FEE-022: Academic-fee query omits IsDonation = 0 filter.
- #3545: In which year did we have the highest number of new admissions? — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #3597: Can I see the subject-wise average marks? — [HIGH] STUD-006: Subject_Master (alias s) joined on BranchID — cartesian product.
- #3598: Payment mode wise staff count — [HIGH] STAFF-004: Staff question uses EmployeeMaster — the payroll twin, not the staff table.
- #3604: What is the total tuition fee outstanding? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #3624: Class-wise count of students using transport. — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
### val_v29.jsonl (17)
- #24: Can you list out all unpaid late fees for Class 10 students? — [HIGH] FEE-009: Outstanding query joins StudentAcademicDetail but omits the TC-issued filter.
- #35: Can you show the top 5 classes by total fee demand? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #63: I need the staff leave category wise count — [HIGH] STAFF-004: Staff question uses EmployeeMaster — the payroll twin, not the staff table.
- #72: Fail percentage by subject — [HIGH] STUD-006: Subject_Master (alias s) joined on BranchID — cartesian product.
- #95: What is the total fee collected via cheque that later bounced? — [HIGH] FEE-011: FeesCollection collection query omits ChequeStatus_ID filter.
- #128: So, how many salary structures exist? — [HIGH] STAFF-005: Salary/attendance staff query omits StaffStatus_ID = 1 — resigned staff included.
- #147: So, how many students owe between 10000 and 50000? — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #153: Hey, what's the term-wise fee collection breakdown? — [MEDIUM] FEE-025: Term-wise answer returns Term_ID (a numeric ID) without joining TermMaster.
- #158: How many students were admitted today? — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #195: Outstanding fees by class — [HIGH] FEE-004: Outstanding query omits IsIncludedInLumpSum filter (risks double-counting)., [HIGH] FEE-009: Outstanding query joins StudentAcademicDetail but omits the TC-issued filter., [MEDIUM] FEE-022: Academic-fee query omits IsDonation = 0 filter.
- #239: Can you show term-wise collection? — [MEDIUM] FEE-025: Term-wise answer returns Term_ID (a numeric ID) without joining TermMaster.
- #240: How many students enrolled vs appeared in exams are there? — [HIGH] STUD-007: Student-count query omits the TC-issued filter — students who left are counted.
- #243: What's the term-wise fee collection status? — [MEDIUM] FEE-025: Term-wise answer returns Term_ID (a numeric ID) without joining TermMaster.
- #259: What is the library fee demand and collection? — [HIGH] FEE-005: Academic-fee query omits Structure_Type filter.
- #286: Pull up class-wise pending late fee totals — [HIGH] FEE-009: Outstanding query joins StudentAcademicDetail but omits the TC-issued filter.
- #291: How much is the total dues for this academic year? — [HIGH] FEE-004: Outstanding query omits IsIncludedInLumpSum filter (risks double-counting)., [MEDIUM] FEE-022: Academic-fee query omits IsDonation = 0 filter.
- #308: Pending fees from new admission students — [HIGH] FEE-009: Outstanding query joins StudentAcademicDetail but omits the TC-issued filter.

## Stage B1.5 — scholastic-subject discipline (user rule 2026-09-07)

- study-sheet drift vs v28: NONE

### Counts

- inject:pc.SubjectTypeID: 60
- new:coscholastic-train: 6
- new:coscholastic-val: 2
- train_v29.jsonl:injected: 51
- train_v29.jsonl:marks: 226
- train_v29.jsonl:no-link: 119
- train_v29.jsonl:no-link:generic-smd: 131
- train_v29.jsonl:skip:named-subject: 30
- train_v29.jsonl:skip:pending-B2-manual: 26
- val_v29.jsonl:injected: 9
- val_v29.jsonl:marks: 22
- val_v29.jsonl:no-link: 10
- val_v29.jsonl:no-link:generic-smd: 11
- val_v29.jsonl:skip:named-subject: 1
- val_v29.jsonl:skip:pending-B2-manual: 2

### Manual / no-link rows (never guessed)

NOTE for Stage B2: rows below that are ALSO generic marks rows must receive the scholastic filter when their own B2 fix lands (they were skipped here to avoid stacking edits on rows that still fail the checker). The B2 pass must run this file's inject_type_filter() after each successful B2 fix.
- train_v29.jsonl#64: Did students improve between exams? — no-link:smd-no-subject-join
- train_v29.jsonl#132: Average marks progression across all exams — no-link:smd-no-subject-join
- train_v29.jsonl#202: How're the kids doing in exams overall? — no-link:smd-no-subject-join
- train_v29.jsonl#261: Exam mein koi 100 marks laya? — no-link:smd-no-subject-join
- train_v29.jsonl#351: What's the students with all A+ grades? — no-link:smd-no-subject-join
- train_v29.jsonl#352: Bhai kitne bacche fail hue? — no-link:smd-no-subject-join
- train_v29.jsonl#361: Which exam type has the best performance? — no-link:smd-no-subject-join
- train_v29.jsonl#367: Students with total marks above 450 in Class 10 — no-link:smd-no-subject-join
- train_v29.jsonl#368: What's the class-wise pass percentage? — no-link:smd-no-subject-join
- train_v29.jsonl#436: Top 5 students in Class 10 — no-link:smd-no-subject-join
- train_v29.jsonl#477: Students at risk of failing - below 40 marks average — no-link:smd-no-subject-join
- train_v29.jsonl#508: TC issued students - were they failing? — no-link:smd-no-subject-join
- train_v29.jsonl#511: Class 10 result summary — no-link:smd-no-subject-join
- train_v29.jsonl#547: Term 1 vs Term 2 class-wise comparison — no-link:smd-no-subject-join
- train_v29.jsonl#559: So, what's the overall pass percentage for the school? — no-link:smd-no-subject-join
- train_v29.jsonl#570: Can I see the students scoring below 20 marks? — no-link:smd-no-subject-join
- train_v29.jsonl#608: Term-wise top scorer — no-link:smd-no-subject-join
- train_v29.jsonl#638: Average marks for Class 10 — no-link:smd-no-subject-join
- train_v29.jsonl#670: Term-wise average marks — no-link:smd-no-subject-join
- train_v29.jsonl#722: I need the gender-wise exam performance comparison — no-link:smd-no-subject-join
- train_v29.jsonl#727: Compare Term 1 and Term 2 results — no-link:smd-no-subject-join
- train_v29.jsonl#730: Can I see the students with F grade? — no-link:smd-no-subject-join
- train_v29.jsonl#745: What's the term-wise top scorer? — no-link:smd-no-subject-join
- train_v29.jsonl#811: Class-wise average marks — no-link:smd-no-subject-join
- train_v29.jsonl#822: Class 12 performance comparison between all exam types — no-link:smd-no-subject-join
- train_v29.jsonl#856: Who scored the highest marks overall? — no-link:smd-no-subject-join
- train_v29.jsonl#913: How many students scored above 90? — no-link:smd-no-subject-join
- train_v29.jsonl#916: What is the overall pass percentage for the school? — no-link:smd-no-subject-join
- train_v29.jsonl#939: I need the Class 10 result summary — no-link:smd-no-subject-join
- train_v29.jsonl#1014: Sabse weak class konsi hai? — no-link:smd-no-subject-join
- train_v29.jsonl#1023: Who are the class 10 toppers in term 1? — no-link:smd-no-subject-join
- train_v29.jsonl#1030: Who is the class topper for Class 8? — no-link:smd-no-subject-join
- train_v29.jsonl#1131: Give me the house-wise student performance — no-link:smd-no-subject-join
- train_v29.jsonl#1143: Improvement from unit test to final exam — no-link:smd-no-subject-join
- train_v29.jsonl#1145: Give me the average marks of bottom 25% students — no-link:smd-no-subject-join
- train_v29.jsonl#1156: Give me the pass percentage for Class 12 — no-link:smd-no-subject-join
- train_v29.jsonl#1166: What is the average marks in Maths for class 10 in term 1? — no-link:smd-no-subject-join
- train_v29.jsonl#1168: Students with F grade — no-link:smd-no-subject-join
- train_v29.jsonl#1173: Weakest performing class — no-link:smd-no-subject-join
- train_v29.jsonl#1230: Class-wise toppers — no-link:smd-no-subject-join
- train_v29.jsonl#1259: I need the term-wise fail count — no-link:smd-no-subject-join
- train_v29.jsonl#1267: Class-wise pass percentage — no-link:smd-no-subject-join
- train_v29.jsonl#1274: Rank the classes by average performance — no-link:smd-no-subject-join
- train_v29.jsonl#1319: What's the number of students appearing per exam type? — no-link:smd-no-subject-join
- train_v29.jsonl#1321: How did Class 10 perform in midterm vs final? — no-link:smd-no-subject-join
- train_v29.jsonl#1363: Can you show rank list for Class 9 Section A? — no-link:smd-no-subject-join
- train_v29.jsonl#1398: I need to see class-wise fail count and pass count — no-link:smd-no-subject-join
- train_v29.jsonl#1427: How many students are below average in Class 10? — no-link:smd-no-subject-join
- train_v29.jsonl#1429: Which class has the lowest pass percentage? — no-link:smd-no-subject-join
- train_v29.jsonl#1489: Can you show me the school topper with marks? — no-link:smd-no-subject-join
- train_v29.jsonl#1504: How many students passed Maths in term 1 in class 10? — no-link:smd-no-subject-join
- train_v29.jsonl#1534: Grade distribution of all students — no-link:smd-no-subject-join
- train_v29.jsonl#1539: What's the average marks by exam type? — no-link:smd-no-subject-join
- train_v29.jsonl#1569: Students who scored 100 marks — no-link:smd-no-subject-join
- train_v29.jsonl#1584: Top 20 students by aggregate marks — no-link:smd-no-subject-join
- train_v29.jsonl#1748: Show class-wise fail count and pass count — no-link:smd-no-subject-join
- train_v29.jsonl#1753: Hey, percentage of students below Class average per class — no-link:smd-no-subject-join
- train_v29.jsonl#1754: Tell me about the students who scored 100 marks — no-link:smd-no-subject-join
- train_v29.jsonl#1800: How many students appeared for exams this year? — no-link:smd-no-subject-join
- train_v29.jsonl#1847: House-wise student performance — no-link:smd-no-subject-join
- train_v29.jsonl#1849: Can I see the vIP students performance? — no-link:smd-no-subject-join
- train_v29.jsonl#1878: Students who scored single digits — no-link:smd-no-subject-join
- train_v29.jsonl#1887: Pass ya fail - overall kya scene hai? — no-link:smd-no-subject-join
- train_v29.jsonl#1890: Give me the weakest performing class — no-link:smd-no-subject-join
- train_v29.jsonl#1913: Show me the school topper with marks — no-link:smd-no-subject-join
- train_v29.jsonl#1914: Which class has the highest pass percentage? — no-link:smd-no-subject-join
- train_v29.jsonl#1968: Percentage of students below class average per class — no-link:smd-no-subject-join
- train_v29.jsonl#2031: Kaunse bacche top kiye class 10 mein? — no-link:smd-no-subject-join
- train_v29.jsonl#2114: Term-wise fail count — no-link:smd-no-subject-join
- train_v29.jsonl#2142: Standard deviation of marks class-wise — no-link:smd-no-subject-join
- train_v29.jsonl#2181: What's the deal with exam results? — no-link:smd-no-subject-join
- train_v29.jsonl#2238: How many students scored below 35? — no-link:smd-no-subject-join
- train_v29.jsonl#2241: Hey, how many students got zero marks? — no-link:smd-no-subject-join
- train_v29.jsonl#2300: What's the nEET/JEE students performance summary? — no-link:smd-no-subject-join
- train_v29.jsonl#2344: I need the rank list for Class 12 — no-link:smd-no-subject-join
- train_v29.jsonl#2347: Students scoring between 60 and 80 — no-link:smd-no-subject-join
- train_v29.jsonl#2371: Who are the top 10 scorers in the school? — no-link:smd-no-subject-join
- train_v29.jsonl#2381: Highest marks scored in the school — no-link:smd-no-subject-join
- train_v29.jsonl#2404: Give me the average marks progression across all exams — no-link:smd-no-subject-join
- train_v29.jsonl#2505: Staff children performance in exams — no-link:smd-no-subject-join
- train_v29.jsonl#2535: Students with all A+ grades — no-link:smd-no-subject-join
- train_v29.jsonl#2593: Lowest marks scored in the school — no-link:smd-no-subject-join
- train_v29.jsonl#2644: Can I see the term-wise average marks? — no-link:smd-no-subject-join
- train_v29.jsonl#2687: NEET/JEE students performance summary — no-link:smd-no-subject-join
- train_v29.jsonl#2688: Can I see the class-wise average marks? — no-link:smd-no-subject-join
- train_v29.jsonl#2690: Show rank list for Class 9 section A — no-link:smd-no-subject-join
- train_v29.jsonl#2751: Students with perfect scores in all subjects — no-link:smd-no-subject-join
- train_v29.jsonl#2792: Rank list for Class 12 — no-link:smd-no-subject-join
- train_v29.jsonl#2819: Which class has the most failures? — no-link:smd-no-subject-join
- train_v29.jsonl#2852: Number of students appearing per exam type — no-link:smd-no-subject-join
- train_v29.jsonl#2853: Students who improved from Term 1 to Term 2 — no-link:smd-no-subject-join
- train_v29.jsonl#2854: Can I see the standard deviation of marks class-wise? — no-link:smd-no-subject-join
- train_v29.jsonl#2857: Pass percentage for Class 12 — no-link:smd-no-subject-join
- train_v29.jsonl#2881: Bottom 10 performers in the school — no-link:smd-no-subject-join
- train_v29.jsonl#2927: Average marks by exam type — no-link:smd-no-subject-join
- train_v29.jsonl#2969: Top 10 most consistent performers across exams — no-link:smd-no-subject-join
- train_v29.jsonl#3000: Students who declined from Term 1 to Term 2 — no-link:smd-no-subject-join
- train_v29.jsonl#3004: Class 12 students failing in more than 2 subjects — no-link:smd-no-subject-join
- train_v29.jsonl#3055: Students scoring below 20 marks — no-link:smd-no-subject-join
- train_v29.jsonl#3083: Highest marks in Science for class 9 in term 2 — no-link:smd-no-subject-join
- train_v29.jsonl#3096: Which term had better results? — no-link:smd-no-subject-join
- train_v29.jsonl#3115: How many students need remedial classes based on marks below 35? — no-link:smd-no-subject-join
- train_v29.jsonl#3134: Topper kaun hai school ka? — no-link:smd-no-subject-join
- train_v29.jsonl#3196: Section-wise average marks for Class 10 — no-link:smd-no-subject-join
- train_v29.jsonl#3197: Gender-wise exam performance comparison — no-link:smd-no-subject-join
- train_v29.jsonl#3272: Who's the class-wise toppers? — no-link:smd-no-subject-join
- train_v29.jsonl#3287: How many students got A+ grade? — no-link:smd-no-subject-join
- train_v29.jsonl#3289: Sections with highest fail rates — no-link:smd-no-subject-join
- train_v29.jsonl#3291: What's the exam-wise pass percentage? — no-link:smd-no-subject-join
- train_v29.jsonl#3319: What's the grade distribution of all students? — no-link:smd-no-subject-join
- train_v29.jsonl#3391: Pass percentage comparison across exam types — no-link:smd-no-subject-join
- train_v29.jsonl#3401: What's the average marks for Class 10? — no-link:smd-no-subject-join
- train_v29.jsonl#3420: How do hostel students perform vs day scholars? — no-link:smd-no-subject-join
- train_v29.jsonl#3459: What's the median score for the school? — no-link:smd-no-subject-join
- train_v29.jsonl#3475: Students with high marks who also require transport — no-link:smd-no-subject-join
- train_v29.jsonl#3497: Students scoring above 95 in any subject — no-link:smd-no-subject-join
- train_v29.jsonl#3503: Subject wise average marks for class 8 in term 1 — no-link:smd-no-subject-join
- train_v29.jsonl#3510: Top 3 students in each class — no-link:smd-no-subject-join
- train_v29.jsonl#3627: Hey, how many students are below average in Class 10? — no-link:smd-no-subject-join
- val_v29.jsonl#32: Full school report card summary do — no-link:smd-no-subject-join
- val_v29.jsonl#104: Term 1 better tha ya Term 2? — no-link:smd-no-subject-join
- val_v29.jsonl#109: Average marks of bottom 25% students — no-link:smd-no-subject-join
- val_v29.jsonl#114: Tell me about the students who scored single digits — no-link:smd-no-subject-join
- val_v29.jsonl#116: Exam-wise pass percentage — no-link:smd-no-subject-join
- val_v29.jsonl#138: List students who failed in Science in term 2 in class 9 — no-link:smd-no-subject-join
- val_v29.jsonl#178: How many students got zero marks? — no-link:smd-no-subject-join
- val_v29.jsonl#218: VIP students performance — no-link:smd-no-subject-join
- val_v29.jsonl#277: Students who require food and their academic performance — no-link:smd-no-subject-join
- val_v29.jsonl#298: Exam type with highest failure rate — no-link:smd-no-subject-join

### New co-scholastic teaching rows (Grade output on smd clones)

- [train] Who's the Art topper in Class 8?
- [train] Who's the Music topper in Class 8?
- [train] Who's the Physical Education topper in Class 8?
- [train] Who's the Dance topper in Class 8?
- [train] Lowest marks in Art for Class 10
- [train] Lowest marks in Music for Class 10
- [val] Who's the Work Education topper in Class 8?
- [val] Lowest marks in Dance for Class 10

### Deferred by design (dev confirmations needed)

- Output format 'scored/max (pct vs 100)': pc.MaxMarks semantics are TBC (ProgressCardDataRetrieval all-68-cols pending); smd path needs EvalHierID -> ExamConfigurationEvaluationDetails.MaxMark (nullable, PARTIAL FK). Stage D live-run proves semantics, then a micro-pass adds the columns; rendering '72/80 (90%)' lands in the Stage E answer layer.
- generic smd rows with no subject join: the marks->subject FK chain is not recoverable from the codebase analysis (no stored procs, no raw SQL touches StudentMarkDetails). Dev question: confirm StudentMarkMaster.ExamSettingID -> StudentMarkEntrySettings.ID -> StudentMarkEntrySettings.SubjectID.

## Stage B1.6 — marks display + Others discipline (user rules 2026-09-07)

R1 pc.MaxMarks display column; R2 AB=fail (question-scoped);
R3 NA/NT/OP excluded from SUM(Marks) totals ('NA', 'NT', 'OP') — rankings untouched (user correction).

### Counts

- edit:R1:maxmarks-display: 22
- edit:R1:maxmarks-display+R2:ab-fail: 1
- edit:R2:ab-fail: 33
- edit:R3:totals-exclude-nantop: 26
- train_v29.jsonl:edited: 75
- val_v29.jsonl:edited: 7

### Manual rows (never guessed)

- train_v29.jsonl#477: Students at risk of failing - below 40 marks average — R2:failpass-shape-unhandled

### Notes

- Pending-B2 rows skipped here; the B2 note now requires applying B1.5 scholastic + B1.6 R1/R2/R3 after each successful B2 fix.
- AVG(Marks) rows are NOT excluded from NA/NT/OP (user scoped R3 to totals). Open question for the user: should averages skip them too?
- Stage E: answer layer renders 'scored/max (pct vs 100)' from the Marks + MaxMarks pair; v29 prompt sheet Others line should be refreshed (AB=fail, NA/NT/OP no-totals) when the v29 profile ships.

---

## Stage B2 (2026-09-08) — pending-B2 row rewrites

**Goal:** every row that failed the deployed 54-rule checker gets either a
compliant rewrite or a documented dev question. Rule: never guess an
unproven FK or unconfirmed column value; revert whole row on any failure.

### B2.1 mechanical WHERE fixes (scripts/build_v29_b2mech.py)
WHERE-block-end injection engine (unique FROM-site → WHERE at same depth →
inject before block end; unaliased tables get bare-column predicates;
fallback: B1.5 anchor chain; validation: parens + target rule gone + no new
rule ids). Fixed 148 rows:
FEE-004 x18, FEE-005 x62, FEE-009 x21, FEE-011 x3, FEE-022 x18, FEE-007 x8,
STUD-005 x8, STUD-007 x29, STAFF-005 x13, LEAVE-001 x10 (rule-hit counts;
rows may carry several). Academic-year fixes use the canonical per-branch
Branch_Academic_Details subquery. LEAVE-001: `LeaveApplicationStatusID <> 3`
(list questions) / `= 2` (approved questions); `LeaveStatus_ID = 1` for
LeaveEntryMaster rows.

### B2.2a STUD-006 rebuilds (scripts/build_v29_b2stud006.py)
25 rows failed STUD-006 (`JOIN Subject_Master s ON s.BranchID = smd.BranchID`
— cartesian). No provable smd→Subject FK chain exists (schema catalog:
smd has no SubjectID; ExamConfigurationEvaluationDetails has none either).
Per the user's directive ("Use ProgressCardDataRetrieval table for Max Marks
and other details") the rows were REBUILT on pc via template surgery from
checker-clean pc rows: subject-wise averages, centum counts, fail
counts/pcts, named topN (TOP N + subject literal), weakest subject,
per-subject toppers (pc2 correlated MAX, class-scoped variant adds
pc2.ClassID pin), Term1-vs-Term2 subject compare. Named-subject rows carry
name filter only (DB decides type); generic aggregates carry
pc.SubjectTypeID = 1; fail predicates carry AB. 25/25 fixed, 0 manual.
BUG FOUND+FIXED during this stage: drop_class missed the
`WHERE cm.Name IN (...)` first-predicate form → 11 rows briefly carried a
spurious class filter; detected by post-check, rebuilt, re-verified clean.

### B2.3 remaining structural groups (scripts/build_v29_b2struct.py)
- FEE-025 (15): term rows → `JOIN TermMaster tm ON <t>.Term_ID = tm.ID`,
  SELECT tm.Name AS TermName (raw Term_ID gone); fee-head rows →
  `JOIN Fees_Master fm ON fcd.Fees_Head_ID = fm.ID`, displayed ID becomes
  fm.Name AS FeeHeadName. #2616 needed a tightened anchor (NOT EXISTS twin).
- FEE-024 (6): fee-HEAD questions grouped by fee GROUP → fm.Name AS FeeHead
  (+ Fees_Master join, GROUP BY fm.Name).
- EXAM-007 (8): smd "failed" rows rebuilt on pc (pc not in MARKS_TABLES).
  Shapes: fail-all (HAVING SUM(fail-case) = COUNT(*)), class-wise failed
  count, >3 subjects (=1 variant), "this term" list — current term resolved
  BY NAME via TermMaster date window (confirmed columns only; no unproven
  FK). WATCH-ITEM: pc.TermName ↔ TermMaster.Name value-domain match is an
  assumption; confirm with dev or a data sample.
- FEE-013 (2): TermMaster date window added/completed.
- RBAC-SALARY (1): standard BranchID scoping injected.
- STAFF-004 #1180: Staff_Master swap (ShiftID confirmed on Staff_Master).

### B2 residue — 13 STAFF-004 rows (documented dev questions)
These rows ask about payroll-column facts (IsHold x8, PaymentModeID x2,
LeaveCategoryID x2 + 1 combined on-hold+absent). The columns exist ONLY on
EmployeeMaster; Staff_Master equivalents are UNCONFIRMED (data dictionary:
StaffStatus_ID 1=active confirmed, 2/3 TBC; no IsHold/PaymentModeID/
LeaveCategoryID on Staff_Master). Per v29 discipline these are NOT guessed:
rows stay pending with the violation flagged. DEV QUESTION: confirm the
staff-domain equivalent of "on hold" (StaffStatus_ID value? separate flag?)
and the staff-leave-category / salary-payment-mode source tables; on answer,
rewrite the 13 rows (indices in scripts/b2_groups.json).

### Final gate (post-B2)
- train_v29.jsonl: 3,662 rows = 3,650 checker-clean + 12 pending-dev
- val_v29.jsonl:   319 rows = 318 checker-clean + 1 pending-dev
- ~~instruction drift: NONE~~ **CORRECTED 2026-09-10 (Batch B):** this B2-era line was
  misleading — the third-party audit (P0-A) found **128 train + 8 val rows with NO
  `instruction` field at all** (cluster: drivers/outstanding/guardian/NEET/enquiries/
  tickets). The 136 rows were stamped with the canonical 2,451-char instruction
  (sha `528692397793727d`) on 2026-09-10 — see the Batch B appendix at the end of
  this report. Parens: balanced; duplicate questions: NONE (unchanged)
- marks-rule invariants (I1-I4): NONE failing
- scholastic invariants: NONE failing
- single-application audit: 3451/1923/2472/2616 verified applied exactly once

## Stage B1.7 — averages skip NA/NT/OP (user confirmation 2026-09-08)

User answered the B1.6 open question: AVG(Marks) must skip NA/NT/OP rows,
same guard as R3, so the rule now reads: NA/NT/OP excluded from totals AND
averages; AB stays inside both (R2 handles AB=fail); rankings untouched
(user's B1.6 correction stands).

### Counts

- alias:already-guarded: 90
- train_v29.jsonl:avg-over-guarded-sum-ok: 1
- train_v29.jsonl:edited-parallel-subq: 2
- val_v29.jsonl:avg-over-guarded-sum-ok: 1

### Manual rows (never guessed)

- none

### Notes

- Guard text identical to R3: (a.Others IS NULL OR a.Others NOT IN ('NA','NT','OP')) — one discipline, one string.
- Scope-level guards (e.g. train#920 rank list) already covered their AVG; bottom-25% shape (train#1145 / val#109) averages guarded per-student SUM totals — verified, no edit.
- Stage E note extended: prompt-sheet Others line must say totals AND averages when the v29 profile ships.

## Stage B3 — Column Fitness (2026-09-09, user rules)
User rules implemented:
  R-A: every per-student list answer carries AdmissionNo + StudentName +
       ClassName + SectionName ("always add admission number, class and
       section when the record is about student").
  R-B: raw ClassID/SectionID never exposed where a Name is reachable.
  R-C: marks columns stay out of non-marks lists (rank questions keep marks).
  R-D: centum holders list = AdmissionNo, StudentName, ClassName, SectionName,
       SubjectName — no marks (3 new teaching rows: 2 train + 1 val).

Result: 407 student-list rows detected; 390 auto-edited (360 train + 30 val),
each edit re-verified (paren balance + 59-rule engine). 22 documented residue
rows (b3_residue_list.json): 14 ApplicationEntry (pre-admission applicants —
no admission number exists yet; ClassApplied serves as class context),
3 Student_Master-direct lists, 3 FeedbackTicket, 2 Concession_Master (no safe
class/section link without row-multiplication risk — needs an academic-year
scoped StudentAcademicDetail join decision).

Mechanics: schema-driven injection (schema_catalog.json column lookup over the
top-level FROM/JOIN region only), canonical join keys only (sad.ClassID/
SectionID, pc.ClassID/SectionID, fc.Class_ID/Section_ID → ClassMaster/
SectionMaster), per-arm editing for UNION lists, denormalized columns
(sad.ClassName, f.SectionName, ae.ClassApplied) accepted as context.
Invariants I7-I10 in scripts/verify_v29_columns.py — ALL GREEN.
Backups: train_v29.jsonl.preB3, val_v29.jsonl.preB3.
Final: 3,651 train / 320 val, checker-clean at 59 rules.

================================================================================
B4 ADDENDUM — 2026-09-10: month-bucket labels MM-yyyy (owner go)
================================================================================
Rule: user-facing dates are day-first (dd-mm-yyyy); monthly trend labels
"2025-06" (FORMAT 'yyyy-MM') read ISO and are exactly the keys users see under
trend answers.

Change: FORMAT style literal 'yyyy-MM' -> 'MM-yyyy' in the SQL (output) field
only — 66 occurrences in 32 train rows + 3 occurrences in 2 val rows (34 rows
total). Question text untouched (verified: 0 inputs reference the literal).
Two train rows using month-NAME buckets (FORMAT 'MMMM') reviewed and left
unchanged — "June" has no numeric date order to confuse.

Verification: every line re-parsed as JSON; only the output field changed, and
only by the style literal (asserted per row, per field). 59-rule checker re-run
before AND after — classification byte-identical (train 3,639 clean + 12
STAFF-004 pending; val 319 + 1; zero new violations). SSMS export regenerated
(v29_train_ssms.sql / v29_val_ssms.sql, rev-2 header 2026-09-10).

Backups: train_v29.jsonl.preB4, val_v29.jsonl.preB4.
Counts unchanged: 3,651 train / 320 val, checker-clean at 59 rules.

## Batch A appendix (2026-09-10): English-only purge

Owner directive: "remove all hinglish/hindi questions from training dataset."

- Tool: `scripts/remove_hinglish_v29.py` — Devanagari block + curated unambiguous
  Hinglish lexicon, applied to the **input field only** (output SQL never edited).
  Tier A = unambiguous auto-removal; Tier B = manual review (0 rows escalated).
  `lakh` and `mile` deliberately KEPT (Indian-English unit / English word).
- Result: **train 3,651 → 3,622 (−29) · val 320 → 317 (−3)**. English-only corpus.
- Backups: `train_v29.jsonl.prehinglish`, `val_v29.jsonl.prehinglish` (this folder).
- Audit trail: `download/hinglish_removed_rows.jsonl` +
  `download/hinglish_removal_summary_10-09-2026.csv`.
- Prompt-profile note: the v29 profile sha (`528692397793727d`) pins the 2,451-char
  INSTRUCTION, not the questions — the purge does not invalidate the staged profile.
- Downstream syncs: `ux_config.json` 4 chips replaced (1 phrasing mismatch + 3 were
  removed Hinglish questions) → pool 30/30 exact dataset matches; SSMS export
  regenerated (rev-3 header, 3,939 batches); README.md + SESSION_HANDOFF numbers
  updated; audit package rebuilt as rev-4 (rev-4 marker in the filename — owner
  Decision 3).
- Verification: no SQL output changed by the purge; branch-gate regression suite
  re-ran ALL PASS on the cleaned corpus (3,927 UARD-trained positives clear the
  gate unmodified; 5 hallucination shapes fail closed); 31-point
  `verify_batch_a_v64.py` ALL PASS (counts, zero Devanagari, zero Hinglish tokens,
  chips exact-match).

## Batch B appendix (2026-09-10): instruction stamping (P0-A closure)

Owner review finding: Batch B's core deliverable (stamp the 136 rows missing the
`instruction` field) had not happened — the English-only purge was executed instead.
Closed same day.

- Tool: `scripts/stamp_instruction_batch_b.py` (idempotent, per-line minimal diff).
- Canonical instruction: 2,451 chars, sha256[:16] `528692397793727d` — the SAME string
  already stamped on every other row and embedded in the `v29` prompt profile, so the
  staged profile (owner Decision 1) remains byte-valid; no re-stamp of the profile.
- Result: **train 128 stamped + val 8 stamped = 136/136; 0 rows missing instruction.**
- Immutability: every row's `input`/`output` byte-identical to the `.prestamp` backups;
  pre-existing instructions untouched; `instruction` appended as the LAST key (matches
  the convention of already-stamped rows).
- Backups: `train_v29.jsonl.prestamp`, `val_v29.jsonl.prestamp` (this folder).
- Checker impact: none by construction — the 59-rule engine validates `output` SQL and
  every output is byte-identical to the pre-stamp state; the branch-gate regression
  suite re-ran ALL PASS post-stamp (3,927 UARD positives; 0 corpus false positives).
- Dataset is now Kaggle-ready for the Batch C retrain: 3,622 train / 317 val, every
  row carries the identical instruction the runtime serves under the `v29` profile.

================================================================================
Q&A alignment sweep (2026-09-10, third-party audit, rev8→rev9)
================================================================================
Independent question-vs-SQL alignment check across all 3,939 rows, done in two
passes: an automated heuristic scan (7 mismatch signals: missing aggregation,
wrong ranking direction, missing percentage computation, missing time-window
filter, vanished numeric literals, missing negation logic, question-domain vs.
touched-table mismatch) raised 442 candidates on the first pass; refining the
heuristics against confirmed false positives (e.g. DATEPART(MONTH,...) and
IS NULL are valid equivalents the first-pass regex didn't recognize) brought it
to 135; every remaining candidate in the higher-precision buckets (percentage,
ranking, numeric, negation) and a representative sample of the domain-keyword
buckets were manually verified against the real SQL.

3 genuine defects found (4 rows total, all originally taught to the model, none
introduced by the sweep):

  * #2600 "percentage of students in hostel" — returned two raw, undivided
    counts instead of a computed percentage. Fixed: wrapped in
    HostelStudents * 100.0 / NULLIF(TotalStudents, 0).
  * val #226 "salary expenditure as percentage of fee collection" — same
    defect, same fix pattern (TotalSalary * 100.0 / NULLIF(TotalFeeCollection, 0)).
  * #1785 + #3171 (two phrasings of the same question) "average duration of
    circulars in days" — computed an unrelated metric (circulars-per-month
    frequency, mislabeled AvgCircularsPerMonth) instead of anything resembling
    "duration in days". Fixed using the same age-based convention already
    established elsewhere in the dataset for circular "validity"
    (DATEDIFF(DAY, Circular_Date, GETDATE()), here averaged) as
    AvgCircularAgeDays.

All fixes preserve every existing branch-scoping / academic-year /
soft-delete filter clause verbatim — only the outer SELECT/computation changed.

RECONCILIATION NOTE (2026-09-11): the 4 fixes above were found UNAPPLIED on
disk — all three dataset copies (dev tree, package training/, package app
training/) still carried the old metrics. Re-applied exactly as specified by
scripts/build_v29_rev9_sweepfix.py (backups *.presweep2; subquery and WHERE
text byte-preserved; AVG(... * 1.0) used so the day-average stays decimal,
matching the corpus COUNT(*) * 1.0 convention). Re-verified post-fix: row
counts unchanged (3,622/317); tightened 59-rule engine 0 failing across 3,939;
guardrail/branch-gate regression ALL PASS (3,927 UARD positives, 0 corpus
false positives); instruction field still stamped on all rows; all 30 chips
still match (verify_batch_a_v64 31/31); sql_ssms/*.sql + manifest.csv
regenerated in sync (0 mismatches on a full byte-level diff, all 3,939
batches). Row numbering in this section = 1-based line numbers.

2 items surfaced, deliberately left as-is pending owner confirmation (both are
ambiguous, not clearly wrong):

  * #2214 "scored below 35" and #3082 "remedial classes ... below 35" filter on
    Marks < eced.MinMark (the exam's configured pass threshold) rather than the
    literal number 35. Consistent across both rows, so likely intentional
    (35 is the conventional CBSE/ICSE pass mark) — but if any exam's configured
    MinMark differs from 35, this silently answers a different question than
    asked.
  * #2325 "highest and lowest collection months this year" and #3147 "best and
    worst attendance day this week" return the full ranked list rather than
    isolating the two extreme rows. Consistent with how "rank X" questions work
    elsewhere in the dataset, so likely intentional — flagged only because a
    literal reading of "highest and lowest" implies exactly two results back.

Everything else raised by the scan (staff/fee/transport/attendance domain
buckets, remaining "this month"/"total"/"average"/N-days candidates) was
sampled and confirmed to be legitimate SQL using tables, flags, or arithmetic
forms the heuristics simply didn't recognize (e.g. IsLumpsumApplicable,
GenerateSalaryEmployee_Master, StaffDepartmentMaster, LeaveEntryMaster,
NTILE(), PreviousYearID-based year comparisons) — not a defect class.

================================================================================
Stage B3.5 — Section fitness for per-student GROUP BY lists (2026-09-11)
================================================================================
Gap found while reconciling the third-party sweep: B3's classifier sent every
top-level GROUP BY row to "aggregate", but a large family of rows GROUP BY the
student key only to compute a per-student metric (attendance %, total paid,
receipts...) — the RESULT is still a per-student list, so B3's R-A rule
(owner rule 2026-09-09: every per-student record carries AdmissionNo +
StudentName + ClassName + SectionName) never reached them. An independent scan
(scripts/quant_missing_section.py) found 74 such rows (68 train + 6 val),
including train#2698 — the owner's original "attendance below 75%" case.

Tool: scripts/build_v29_b35_section.py — B3's mechanics with a widened
classifier (per-student GROUP BY lists admitted), same canonical join keys
(sad.SectionID/pc.SectionID -> SectionMaster secm; secm.Name AS SectionName),
GROUP BY sync (the new expression is appended to the GROUP BY list so the
SELECT stays legal T-SQL — no row multiplication: the join is 1:1 on the
already-grouped student key), UNION handled per-arm all-or-nothing.

Conservative auto-edit contract: only grouped lists that ALREADY show class
context are auto-edited (the single-class-per-student assumption is already
baked into those rows). Grouped lists WITHOUT class context (87 rows — same
concern class as B3's Concession_Master residue: needs a per-row
academic-year-scoped StudentAcademicDetail join decision), rows grouped by
class/branch rather than student (77 — one row per group, not a student
record), the 22 rows already documented in b3_residue_list.json (14
ApplicationEntry, 3 Student_Master-direct, 3 FeedbackTicket, 2
Concession_Master), 2 CTE rows and 1 ORDER BY-ordinal row were NOT touched and
are documented in training/b35_residue_list.json (189 entries).

Result: 32 rows auto-edited (26 train + 6 val), each edit re-verified (paren
balance + glued-keyword scan + tightened 59-rule engine + input/instruction
byte-untouched). Full corpus re-check: 3,939/3,939 clear the tightened engine.
Backups: train_v29.jsonl.preB35, val_v29.jsonl.preB35.

Post-edit totals: 3,622 train / 317 val, every row R-A complete among
auto-editable per-student lists, checker-clean at 59 rules, sweep-clean on
both audits (entity/threshold sweep 2026-09-10 + third-party aggregation/
percentage sweep reconciled 2026-09-11).

## Stage B6 — extremes & tie semantics (owner decisions, 2026-09-11)

The two items left pending by rev 9 were decided by the owner and applied the
same day.

Owner decisions:
1. **MinMark is NOT a fixed 35** — it differs from exam to exam (a 100-mark
   exam may set 35 or 33 depending on the school; a 20-mark exam converts
   marks, usually upward to a 100 scale, rarely downward to 10). This
   CONFIRMS the dataset's existing design: all 64 marks-threshold rows
   (56 train + 8 val) already join `ExamConfigurationEvaluationDetails` on
   `EvalHierID` and compare `smd.Marks < eced.MinMark`; a corpus scan found
   ZERO rows hardcoding 35/33 in SQL. Item closed as correct-by-design.
   Open dev question (non-blocking): whether `StudentMarkDetails.Marks`
   stores raw or converted marks for cross-exam aggregates.
2. **"Highest and lowest" returns ONLY the two extremes** — not a ranked list.
3. **Ties are facts**: if two classes both sit at the extreme, both are
   returned (`TOP 1 WITH TIES`; dropping a tied row would misreport).
4. **train#2486** ("highest fee collection AND lowest attendance") = the ONE
   class that best combines both metrics (rank-sum), not a ranked list.

Edits (10 rows: 9 train + 1 val; scripts/build_v29_extremes.py, backups
`*.preEXT`, every candidate SQL gated through ALL FOUR production validators
— 59-rule semantic engine, branch-scoping gate, alias scope, guardrail —
before write):
- train#2325 "Highest and lowest collection months this year": full ranked
  list → `UNION ALL` of two `TOP 1 WITH TIES` derived tables (Highest branch
  ORDER BY SUM DESC, Lowest branch ASC), self-describing `Extreme` label
  column, deterministic outer ordering.
- train#3147 "Best and worst attendance day this week": same shape, labels
  `Best`/`Worst`.
- train#2486: `Ranked` CTE added (RANK by collection DESC + RANK by
  attendance ASC); final `SELECT TOP 1 WITH TIES ... ORDER BY CollRank +
  AttRank` = the single best-combined class.
- train#2042 "Which week had maximum collection this month?": full week list
  → `TOP 1 WITH TIES` single extreme.
- ROW_NUMBER → RANK on 6 per-group extremes that filter `Rn = 1`
  (train#602/#737 term-wise top scorer, #1217/#3237 class-wise toppers,
  #1976 top collecting day per month, val#49 best section per class) — ties
  at rank 1 are now returned instead of silently dropped.

Left alone (deliberate): train#3471 "Top 3 students in each class"
(`Rn <= 3` — per-group Top-N needs ROW_NUMBER to keep exactly N rows);
train#1794 (gaps-and-islands streak calc — not an extreme); #258/#845
(explicit plural/ranking phrasings).

Post-edit verification: 3,939/3,939 rows clean on the 59-rule engine; all 10
edited rows pass branch gate + alias scope + guardrail; branch-gate
regression ALL PASS (3,927 UARD positives, 0 false positives); batch-A 31/31;
date-format ALL GREEN; alignment sweep zero findings; SSMS export
regenerated (rev-6 header). input/instruction byte-identical on every row;
only the 10 outputs changed.

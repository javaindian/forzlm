# ChaloSchools AI Secretary

A Text-to-SQL chatbot for the ChaloSchools school ERP. The user types a question ("What is the fee outstanding for the current term?"); the system generates a T-SQL query, runs it through 11 verification stages (including a 59-rule semantic engine), and returns the answer.

**Production deployment:** the backend API service is called by the mobile app. The local-test web UI is a dev tool, not part of production.

---

## End-to-end status: WORKING (verified 2026-08-31)

The system has been verified end-to-end on Windows. The user successfully asked **"how many students are there in 10 a?"** through the chat UI, and the backend returned the real answer from the school's `V3_TestDatabase`: **`StudentCount = 32`**. The full pipeline trace shows all 6 stages passing: `generate → branch_scoping → validate → semantic (54 rules) → bind → execute`. See `docs/PROJECT_STATUS.md` for the full account.

**2026-09-04 — the ERP codebase analysis is now incorporated** (see `docs/SESSION_HANDOFF.md`, update 2026-09-04):
- **54 semantic rules** (was 32): 22 new rules from the ERP's own C# LINQ filters (11,148 WHERE clauses analyzed) + the production-trace proposals. Measured on the v27 dataset: zero false positives.
- **Expanded system prompt**: the frozen v27 text still leads, followed by a ~1,200-token knowledge block (real joins, mandatory filters, enums, hallucination traps) built from the codebase-analysis extracts. `CTX_SIZE` is now 4096. Rollback: `AI_SECRETARY_PROMPT_PROFILE=legacy` in `backend\.env`.
- **Hint-map retries**: when the model hallucinates a known-trap column, the retry now tells it the CORRECT approach.
- **v28 training data ready**: 4,034 examples (3,867 v27 + 182 new, gated with 0 violations) in `training/train_v28.jsonl` + `val_v28.jsonl`. Next: retrain on Kaggle, benchmark the 50 golden questions (target <5% mismatch).

**2026-09-07 — v97: ERP settings moved into ONE file (`erp_config.json`)** — the only place to change the GetUserContext URL, the ExecuteQuery URL, the per-school API keys, and the `use_inline_params` switch. Edit it, restart the backend, done — no code edits. Loader: `erp_config.py` (file → env var → built-in fallback). Runbook: **`docs/ERP_CONFIG_GUIDE.md`**. What changed and how to deploy: **`V97_RELEASE_NOTES.md`**.

**2026-09-10 — v64 (Batch A): third-party-audit response shipped** — `v29` prompt profile added in code, byte-identical to the dataset instruction (sha 528692397793727d, 2,451 chars), serving still pinned to `expanded` (staged cutover = env-flip + restart after a 24–48 h baseline); Sections fallback accepts 1–3 char literals ONLY when a school's Sections vocab is empty (configured schools stay strict); `sql_source` is a first-class `audit_trail` column (fresh + migrated DBs); suggestion chips rotate after every answer and all 30 pool questions are exact dataset matches; `backend/.env.example` documents the 3 behaviour switches; **guardrail extended (owner-verified fix)** to refuse scoping subqueries that select a wrong column (`SELECT Branch_Id FROM UserAccountRoleDetails` — the class behind 19 live execute errors; zero false positives on 3,939 rows); **all 136 rows missing the `instruction` field stamped** (P0-A closed — dataset now Kaggle-ready). Details + deploy + rollback: **`V64_RELEASE_NOTES.md`**.

**2026-09-10 — v63: quick-wins shipped + v29 dataset FINAL (pending third-party audit)** — four no-retrain patches (bare-number class instant answers — "how many students are in 8" no longer falls to the slow LLM path; Branch_Id→BranchID auto-repair; 90-second total-cycle budget `AI_SECRETARY_TOTAL_BUDGET`; `max_tokens` 512→768) plus UX (6 rotating chips from a 30-question verified pool) plus **Stage B3 column fitness** (390 per-student lists taught to always carry AdmissionNo + StudentName + Class + Section; centum-holders LIST rows added; raw-ID exposure removed). Dataset final: **3,622 train / 317 val, checker-clean at 59 rules** (2026-09-10 Batch A: 32 Hinglish/Hindi questions removed — originals in `training/*.prehinglish`, removed rows in `download/hinglish_removed_rows.jsonl`). Full details + deploy + rollback: **`V63_RELEASE_NOTES.md`**. Next: your third-party audit (Stage D) → Stage E fastpath rebuild → Kaggle retrain.

---

## ⭐ Easiest way to start (Windows, no technical knowledge needed)

Just **double-click `START_HERE.bat`** in the project root. It will:
1. Start the LLM "brain" in one window
2. Start the backend API in another window
3. Open the chat UI in your browser

It tells you what to do at each step. If anything is missing (Python, llama.cpp, the GGUF model), it explains exactly where to get it.

**For first-time setup** (only needed once), you need:
- **Python 3.11+** — from https://www.python.org/downloads/ (CHECK "Add python.exe to PATH" in the installer)
- **llama.cpp's Windows build** — from https://github.com/ggerganov/llama.cpp/releases (unzip to `D:\llama.cpp\`)
- **The trained GGUF model file** (~4-5 GB) — see `scripts/start_llm.bat` for help, or `training/` for the notebooks that produce it

After first-time setup, just double-click `START_HERE.bat` any time you want to use the AI Secretary.

> **Not on Windows?** See `frontend/README.md` for the standalone HTML option (just open `frontend/chat.html` in any browser) and the manual start commands for Mac/Linux.

---

## What's in this package

```
chalo_chatbot/
├── README.md                    — this file (start here)
├── START_HERE.bat              — ★ ONE-CLICK STARTER (Windows) — opens all 3 services
├── STRUCTURE.md                 — the full folder tree with file descriptions
├── run_50_questions.py         — the 50-question benchmark script (used by scripts/run_50.bat)
├── context.json                — sample Context JSON (used by run_50.bat for testing)
├── erp_config.json             — (v97) THE one file for ERP settings: URLs, API keys, inline-params switch
├── erp_config.py               — (v97) loader for erp_config.json (file → env → built-in fallback)
├── backend/                     — the production API service (mobile-app-facing)
│   ├── main.py                  — FastAPI server, 9 endpoints (4 user + 5 admin/audit), Bearer auth
│   ├── security.py              — auth + CORS + rate limiting + audit
│   ├── requirements.txt         — Python dependencies (pip install -r requirements.txt)
│   ├── .env.example             — env vars template (copy to .env, optional)
│   ├── feature_overrides.json   — admin feature flags
│   └── audit_trail.db           — SQLite audit log (auto-created)
├── frontend/                    — the user-facing UI (TWO options)
│   ├── README.md                — how to use the frontend
│   ├── chat.html                — Option A: standalone chat UI (open in browser, no build)
│   ├── audit.html               — Option A: standalone audit-trail viewer
│   ├── start_chat.bat           — Option A: Windows launcher for chat.html
│   └── nextjs-ui/               — Option B: full Next.js React app (requires npm install)
│       ├── src/app/page.tsx     — the main chat page (React)
│       ├── src/components/ui/   — shadcn/ui components (50+)
│       ├── package.json
│       └── ...
├── scripts/                     — Windows launcher scripts (.bat) — all self-bootstrap
│   ├── start_llm.bat            — start llama.cpp LLM server (port 8080) — friendly GGUF help
│   ├── start_backend.bat        — start FastAPI backend (port 8000) — auto-creates venv + installs deps
│   └── run_50.bat               — run the 50-question benchmark — auto-creates venv + uses sample context.json
├── pipeline/                    — the inference pipeline (17 files, ~6,000 LOC)
│   ├── orchestrator.py          — the conductor, 11 stages
│   ├── semantic_rules.py        — the 59-rule semantic engine (history: 32 → 54 on 2026-09-04 → 58 → 59 on 2026-09-09; see rules/SEMANTIC_RULES_59.md in the audit package)
│   ├── schema_knowledge.py      — the expanded system prompt built from the codebase-analysis extracts (profiles: expanded/legacy)
│   ├── schema_catalog.json      — the school's DB schema (475 tables, used by guardrail.py)
│   ├── context.py, context_vocab.py, llm_client.py, guardrail.py,
│   ├── alias_scope_check.py, branch_scoping_gate.py,
│   ├── entity_extractor.py, value_resolver.py, parameter_binder.py,
│   ├── local_executor.py, api_executor.py, user_context_api.py,
│   ├── concept_store.py, dataset_lookup.py, template_lookups.py
├── vocab/                       — the vocab engine (2 files)
│   ├── inject.py                — STOPGAP + FULL modes, config-switchable
│   └── synonyms.json           — 9 concept types, hand-curated
├── semantic_validation/         — the training-data gate (5 files, ~5,000 LOC)
│   ├── README.md, semantic_rules.py, validate_dataset.py,
│   ├── prepare_data.py, rules_catalog.json + reference_inputs/
├── training/                   — the v27/v28 training pipeline (NEW)
│   ├── README.md                — how to use the training pipeline
│   ├── prepare_data_v27.py + the Kaggle/Colab notebooks
├── evaluation/                   — accuracy harness (4 files)
│   ├── golden_questions.json    — 50 questions (20 novel, held out)
│   ├── scoring.py               — 4-axis scoring
│   ├── evaluate.py              — run against a served model
│   └── sample_context.json     — runnable out of the box
├── web/                         — static assets
│   └── screenshot_landing.png   — landing page screenshot
└── docs/                        — the documentation (24 files, .md + .pdf + .xlsx)
    ├── HOW_IT_WORKS.md          — plain-language guide (start here)
    ├── API_CONTRACT.md          — mobile-app integration guide
    ├── PRD.md                   — product requirements (goals, metrics, risks)
    ├── PROJECT_STATUS.md        — the current snapshot (done/pending/issues)
    ├── SESSION_HANDOFF.md        — how to resume work + what NOT to do
    ├── WINDOWS_LOCAL_TESTING.md  — Windows-only local testing guide
    ├── IMPROVEMENTS_VS_AISEC.md  — what I improved vs. the original
    └── ... (see STRUCTURE.md for the full list)
```

> **Frontend note:** The standalone HTML UI (`frontend/chat.html`) is the fastest
> way to test — just open it in a browser, no install needed. The Next.js UI
> (`frontend/nextjs-ui/`) is for teams who want a real React app to customize.
> **The production frontend is the mobile app** (see `docs/API_CONTRACT.md`).

---

## Quick start

### Run the backend API service (production)

```bash
cd chalo_chatbot/backend

# 1. Install Python dependencies (do this ONCE)
pip install -r requirements.txt

# 2. (Optional) Configure .env — the app runs fine without it (uses dev defaults)
#    Copy the template and edit if you want to change tokens, CORS, rate limits:
cp .env.example .env      # Mac/Linux      |  Windows: copy .env.example .env
# Edit .env: set AI_SECRETARY_AUTH_TOKENS to a long random string
# (the mobile app / chat UI will use this token)
# For PRODUCTION, use OCI Vault instead — never create a .env on the server
# NOTE (v97): ERP endpoints + API keys are NOT set here — they live in
# erp_config.json (project root). See docs/ERP_CONFIG_GUIDE.md.

# 3. Start the server
python3 -m uvicorn main:app --host 0.0.0.0 --port 8000
# Production: --workers 4 (but only if your CPU has 4+ cores AND you have
# multiple llama.cpp instances; the LLM is the bottleneck, not the API)
```

The service is now running. Test it:
```bash
curl http://localhost:8000/api/health
# → {"status":"ok","pipeline_loaded":true,"rules_count":54,"prompt_profile":"expanded"}

curl -X POST http://localhost:8000/api/chat \
  -H "Authorization: Bearer <your-token>" \
  -H "Content-Type: application/json" \
  -d '{"question":"test","context_json":{...},"mode":"dry_run"}'
```

### Run the frontend (dev only)

**Option A — standalone HTML (fastest, zero-install):**
```bash
# Just open frontend/chat.html in any browser, OR double-click:
frontend/start_chat.bat    # Windows
# Mac/Linux: open frontend/chat.html
```

**Option B — Next.js React UI (requires Node.js 18+):**
```bash
cd frontend/nextjs-ui
npm install     # install dependencies
npm run dev     # opens on http://localhost:3000
```

See `frontend/README.md` for full details. The frontend is a dev/test tool — **the production frontend is the mobile app.**

### Integrate the mobile app

See `docs/API_CONTRACT.md` — the complete integration guide for the mobile-app team. Covers auth, endpoints, request/response shapes, UX flow, latency expectations, pagination, rate limiting, and security.

---

## The 3 services you need running

> **Easiest on Windows:** just double-click `START_HERE.bat` — it opens all 3 in separate windows.

| Service | Port | What it is | How to start |
|---|---|---|---|
| **llama.cpp LLM** | 8080 | The fine-tuned Qwen 2.5 Coder 7B model | `scripts/start_llm.bat` (Windows, self-bootstrap) or `./llama-server -m your_model.gguf --port 8080` |
| **AI Secretary API** | 8000 | This backend (FastAPI) | `scripts/start_backend.bat` (Windows, auto-creates venv + installs deps) or `cd backend && uvicorn main:app --port 8000` |
| **Frontend (HTML)** | — | Standalone chat UI (no port, just a file) | Open `frontend/chat.html` in a browser, or `frontend/start_chat.bat` (Windows, with health check) |
| **Frontend (Next.js)** | 3000 | Optional React UI (dev only) | `cd frontend/nextjs-ui && npm install && npm run dev` |

The mobile app talks to the AI Secretary API (8000), which talks to the LLM (8080) and the school's ExecuteQuery API.

---

## Health checks (when something's wrong)

Run these in order (each takes <10 seconds):

1. **LLM up?** `curl http://localhost:8080/v1/chat/completions -d '{"messages":[{"role":"user","content":"SELECT 1"}],"max_tokens":20}'`
2. **API up?** `curl http://localhost:8000/api/health` → expect `{"status":"ok","rules_count":54,"prompt_profile":"expanded"}`
3. **Pipeline runs?** `POST /api/chat` with a real Context JSON → expect `outcome: "ANSWER"` (dry_run) or `outcome: "ERROR"` (if LLM down)
4. **Semantic engine healthy?** `POST /api/validate` with `SELECT Password FROM UserAccountMaster` → expect 1 HIGH violation
5. **Context JSON valid?** `POST /api/branches` with the Context JSON → expect a list of branches

Full troubleshooting matrix: see `docs/HOW_IT_WORKS.md` §6 and §7.

---

## Documentation map (read in this order)

1. **`docs/HOW_IT_WORKS.md`** — the plain-language guide (start here). Explains the layers, the journey of a question, each file's job, the variables to check, health checks, troubleshooting.
2. **`docs/API_CONTRACT.md`** — the mobile-app integration guide. Give this to your mobile-app team.
3. **`docs/IMPROVEMENTS_VS_AISEC.md`** — what I improved vs. the original aisec.zip (the 5 new layers + 8 fixes + 3 new rules).
4. **`docs/GUIDELINES.md`** — the single source of truth for all problems, impacts, and mitigations (735 lines).
5. **`docs/BLINDSPOT_AUDIT.md`** — the round-by-round findings with root-cause proofs (for deep dives).
6. **`semantic_validation/README.md`** — how to validate + clean the training dataset.

---

## The architecture in one diagram

```
Mobile App (production)
    │
    │ HTTPS + Bearer token
    ▼
AI Secretary API (FastAPI, port 8000)  ← chalo_chatbot/backend/main.py
    │
    │ imports
    ▼
The Pipeline (orchestrator + 15 modules)  ← chalo_chatbot/pipeline/
    │
    ├──> LLM (llama.cpp, port 8080)  ← you run this separately
    │
    ├──> Vocab Engine  ← chalo_chatbot/vocab/
    │
    ├──> Semantic Engine (59 rules)  ← chalo_chatbot/pipeline/semantic_rules.py
    │
    └──> ExecuteQuery API (school's ASMX endpoint)  ← production DB access
         OR local MS SQL Server  ← local_db mode (testing only)
```

The local-test web UI (Next.js, port 3000) is a dev tool that calls the same API. It's NOT in the production diagram.

---

## What's NOT in this package (your responsibilities)

- **The LLM server** — you run llama.cpp separately at port 8080.
- **The school's ExecuteQuery API** — your existing ASMX endpoint; the backend calls it.
- **The school's GetUserContext API** — your existing endpoint; the mobile app calls it to get the Context JSON.
- **The mobile app** — your team builds it per `docs/API_CONTRACT.md`.
- **The v28 retrain** — I delivered `prepare_data.py` + 50 new training examples; the retrain is yours to run.
- **Production deployment** (Docker/systemd/nginx) — pending Batch 3, or your ops team.

---

## Planned features / Roadmap (added 2026-09-03)

The system is end-to-end verified on Windows (2026-08-31). The following are **pending** (not yet implemented) as of 2026-09-03 (DOC-UPDATE-5):

### Pending UI/UX features (4 new items)

1. **AI disclaimer in `chat.html`** — a subtle footer note below the input box: *"AI can make mistakes. Please verify important information."*
2. **LLM model selector dropdown** in `chat.html` → Settings panel — three options: **Chalo Language Model 1.0** (current, enabled by default), **CLM 2.0** (disabled — coming soon), **CLM 3.0** (disabled — coming soon). When v28 (CLM 2.0) and v29 (CLM 3.0) are trained, users can switch between them.
3. **Configurable "show thinking process" toggle** — because there's 15-35s latency on CPU, show the pipeline stages progressively ("Understanding your question...", "Generating SQL...", "Validating against 59 rules...", "Querying the database..."). Toggle in Settings (default OFF).
4. **Standard reply for unanswerable questions (configurable)** — when the system can't answer (`REFUSED` / `ERROR` / `NEEDS_DISAMBIGUATION`), show a single admin-configurable message instead of the raw error. Configurable via `AI_SECRETARY_FALLBACK_MESSAGE` env var or in `feature_overrides.json`. Default: *"I'm sorry, I couldn't answer that question. Please try rephrasing it, or ask a different question."*

### Pending accuracy improvements (no retrain, no dev-team help needed)

5. **System prompt expansion** — the current system prompt is one paragraph (~80 tokens). The plan is to expand it to ~2 pages (~1,000-1,500 tokens) covering the 7 known schema gotchas, top 5 business formulas, top 10 mandatory filters, key JOIN patterns, and critical enum values. **The #1 accuracy lever available.** Status: PENDING — waiting on the user to paste 4 small extracts (top filters, enums, hub tables, raw SQL) from the codebase-analysis toolkit output.
6. **CTX_SIZE bump (2560 → 4096)** — the `CTX_SIZE=2560` in `scripts/start_llm.bat` is a TRAINING constraint, not an INFERENCE constraint. At inference, Qwen 2.5 Coder 7B natively supports 32K context. Decision: bump to 4096 to unlock the 2-page system prompt above. Adds ~3-4s latency (acceptable: 15-35s → 18-39s). The two changes (5 + 6) go together.

### Architectural decisions (2026-09-03)

- **3B vs 7B model:** keep the 7B. Fine-tuning adds KNOWLEDGE (your schema, your patterns); it does NOT add REASONING capacity. The 3B falls behind on complex queries (~50-65% of 7B accuracy). If latency is the problem, the right fix is a GPU — a $200 used RTX 3060 (12GB VRAM) makes the 7B run in 1-3 seconds with `--n-gpu-layers 99`. Don't shrink the brain to make it faster.

### Project artifacts created alongside the package

- **`chalo-chatbot-persona` skill** — a skill file (`chalo-chatbot-persona/SKILL.md`, also mirrored at `chalo_chatbot/skills/chalo-chatbot-persona/SKILL.md` when included) that captures the project owner's persona, project context, preferences, and key files for future conversations. Auto-triggers when the user mentions ChaloSchools, the chatbot, the pipeline, etc.
- **`SESSION_RECORD.md`** — a complete project record (~526 lines, ~27 KB) at the project root covering the full journey from "I have a school ERP" to end-to-end verified, with 16 sections including the beginning, what the user brought, the initial problems, all 8 phases of work, architectural decisions, dev team asks, and key metrics. Read this for the complete narrative history (`PROJECT_STATUS.md` is the snapshot; `SESSION_RECORD.md` is the story).

> **Verify on download (2026-09-03):** the persona skill and `SESSION_RECORD.md` may or may not be present in your downloaded package depending on when you unpacked it. If missing, ask the project owner for the latest copy. The canonical persona skill lives at `chalo-chatbot-persona/SKILL.md` outside the package.

Full details for all the above are in `docs/PROJECT_STATUS.md` §4.6 + the 2026-09-03 update, and in `docs/SESSION_HANDOFF.md` (2026-09-03 update).

---

## Version

v1.0.0 — initial delivery. See `docs/IMPROVEMENTS_VS_AISEC.md` for the full changelog vs. the original aisec.zip.

# v97 Release Notes — ERP settings moved to ONE file

**Date:** 2026-09-07
**Package:** `chalo_chatbot_v97.zip` (Windows laptop + VPS ready)
**Base:** live VPS code pulled 2026-09-07 (post audit-trace fix, v96 line)

---

## What changed (the promise, kept)

One new file — `erp_config.json` at the project root — is now the ONLY
place to change:

- GetUserContext URL
- ExecuteQuery URL
- per-school API keys (`tenant_api_keys`)
- the `use_inline_params` workaround switch

Edit it, restart the backend, done. See **docs/ERP_CONFIG_GUIDE.md**.

## Files changed / added

| File | Change |
|---|---|
| `erp_config.json` | **NEW** — the single source (holds the real key; keep private) |
| `erp_config.py` | **NEW** — small loader: file → env var → built-in fallback |
| `pipeline/user_context_api.py` | URL + key now read from erp_config first; hardcoded key removed from code |
| `backend/security.py` | key lookup reads erp_config first; hardcoded key removed from code |
| `backend/main.py` | ExecuteQuery URL + inline-params switch read from erp_config; error messages now point to the file |
| `frontend/chat.html` | URL field now empty by default — the server's erp_config.json decides |
| `docs/ERP_CONFIG_GUIDE.md` | **NEW** — the change runbook (all cases, verification, errors) |
| README / STRUCTURE / SESSION_RECORD / other docs | updated for v97 |

Nothing else changed. No behaviour change unless YOU edit the json.

## Safety net (why this is low-risk)

- Old hardcoded values stay in code as silent last-resort fallbacks —
  if `erp_config.json` is missing, the app still boots and behaves like v96.
- Only keys were fully moved out of code (never re-hardcoded): with the
  json missing AND no env var, you get one clear error message telling you
  to add the key to `erp_config.json`.
- A corrupt json raises a loud, named error instead of silently using
  stale settings.

## Deploy to the VPS (from your Windows laptop)

```bash
# 1. Upload the zip (scp / SFTP) to your home dir, then:
cd ~ && unzip -o chalo_chatbot_v97.zip -d v97_stage

# 2. Backup the live tree's changed files
R=/opt/chalo-ai-secretary/chalo_chatbot
sudo cp $R/backend/main.py $R/backend/main.py.bak.$(date +%Y%m%d-%H%M%S)
sudo cp $R/backend/security.py $R/backend/security.py.bak.$(date +%Y%m%d-%H%M%S)
sudo cp $R/pipeline/user_context_api.py $R/pipeline/user_context_api.py.bak.$(date +%Y%m%d-%H%M%S)
sudo cp $R/frontend/chat.html $R/frontend/chat.html.bak.$(date +%Y%m%d-%H%M%S)

# 3. Copy the changed + new files (ONLY these)
sudo cp v97_stage/chalo_chatbot/erp_config.json $R/
sudo cp v97_stage/chalo_chatbot/erp_config.py $R/
sudo cp v97_stage/chalo_chatbot/backend/main.py $R/backend/
sudo cp v97_stage/chalo_chatbot/backend/security.py $R/backend/
sudo cp v97_stage/chalo_chatbot/pipeline/user_context_api.py $R/pipeline/
sudo cp v97_stage/chalo_chatbot/frontend/chat.html $R/frontend/

# 4. Lock the secrets file down
sudo chown chalo:chalo $R/erp_config.json $R/erp_config.py
sudo chmod 600 $R/erp_config.json && sudo chmod 644 $R/erp_config.py

# 5. Restart + verify
sudo systemctl restart chalo-backend
systemctl is-active chalo-backend
sudo journalctl -u chalo-backend -n 20 --no-pager
```

Then ask one question in the chat UI. Same answers as before = success.

## Windows laptop

Unzip anywhere. `START_HERE.bat` works as before. `erp_config.json` is
found automatically. To point the laptop at a test URL/key: edit the json,
restart the backend window.

## Do NOT ship / rotate reminders

- `erp_config.json` contains the real API key: never email it, never put it
  in a web root, never commit it to a public repo.
- The two ERP HTML docs (ExecuteQuery/GetUserContext) also contain keys —
  same handling.
- If a key leaks: ERP team regenerates → you paste the new value into
  `erp_config.json` → restart. That is the whole rotation now.

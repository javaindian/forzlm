"""
AI Secretary — Application Layer :: Pipeline Orchestrator
=========================================================

The conductor. Runs a natural-language question through the full corrected
pipeline and returns either an answer (rows), a disambiguation prompt, or a
fail-closed refusal — wiring together every app-layer component built so far.

Pipeline (corrected inject → generate → validate → substitute → semantic
→ bind → execute architecture)
--------------------------------------------------------------
    1. CONTEXT   — build UserContext from the login Context JSON (identity,
                   authorized branches, per-branch vocab).            [context]
    2. INJECT    — build the branch-vocab injection block for the LLM. [context_vocab]
    3. GENERATE  — call the local LLM (llama.cpp) to produce T-SQL.    [llm_client]
    4. GUARDRAILS— schema-existence guardrail + alias-scope 2nd pass.  [guardrail + alias_scope_check]
                   + branch-scoping security gate (check_branch_scoping).
    5. VALIDATE  — validate any master-data literals the model emitted
                   against the branch's real vocab; fail closed /
                   disambiguate on 0 or 2+.                            [value_resolver.ValueValidator]
    5b. SUBSTIT  — D1.4/F6: rewrite the SQL literals with the validated
                   database_values (only for results with should_substitute=True),
                   BEFORE the semantic-rules check sees the SQL.
                   [parameter_binder.substitute_validated_values]
    5c. SEMANTIC — D1.1: run the 32-rule semantic-rules engine on the
                   (substituted) SQL. If violations, REFUSED.         [semantic_rules]
    6. BIND      — bind security params (+ any resolved values) as real
                   parameters (never concatenated).                    [parameter_binder]
    7. EXECUTE   — one of three modes:
                     dry_run      → return the exact bound request, run nothing
                     local_db     → run on the local DB via sp_executesql [local_executor]
                     api_wrapper  → POST to the ExecuteQuery API          [parameter_binder / api_executor]

Execution mode is chosen by config, so the SAME pipeline serves the dry-run
preview demo, the fully-live local-DB demo, and the eventual production API path
with only a mode flip. Nothing is rebuilt between them.

Fail-closed throughout: any stage that cannot proceed safely stops the pipeline
and returns a structured, honest result — never a guessed answer.

⚠️ ROUND-2 EXTENSIONS:
  D1.1 — NEW Stage.SEMANTIC between VALIDATE and BIND. Runs semantic_rules.check_sql
          (the 32-rule engine) on the SQL post-substitution. If violations,
          REFUSED at Stage.SEMANTIC with the rule's suggested fix in `detail`.
  D1.4/F6 — after VALIDATE, collect (user_value, database_value) pairs from every
          ValueValidator result with should_substitute=True and call
          parameter_binder.substitute_validated_values(sql, substitutions) to
          rewrite the SQL literal BEFORE the semantic-rules check sees it.
  D1.5 — on execute-error retry (local_db mode), RE-RUN check_branch_scoping on
          the retried SQL before re-executing. The original skipped this.
  D1.8 — if llm_client raises TruncationError (finish_reason='length'), return
          REFUSED at Stage.GENERATE with a helpful "ask a more specific question"
          message instead of executing truncated SQL.
  D1.9 — fast-paths (dataset_lookup, class_template, section_template,
          top_n_template, class_section_template) gated by
          `fast_paths_enabled` (default False). When False, the orchestrator
          skips every fast-path entirely and goes straight to the LLM.
          Tests / dry-runs can flip it ON explicitly via the constructor.

No hardcoded paths/keys/clients in code (Bible Rule 1): everything environment-
specific (LLM URL, DB creds, endpoint, api-key, mode) is injected via a config
object by the caller.

Reconstructed from the original app_layer/orchestrator.py + round-2 extensions.
Diff against your real files before deploying.
"""

from __future__ import annotations

import os
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Callable, Tuple

try:
    from .branch_scoping_gate import check_branch_scoping
except ImportError:
    from branch_scoping_gate import check_branch_scoping

try:
    # The semantic-rules engine lives in this same pipeline/ folder.
    # It's importable as a sibling module (relative) OR as a top-level
    # module when the pipeline dir is on sys.path.
    from .semantic_rules import check_sql as _semantic_check_sql
    from .semantic_rules import rule_count as _semantic_rule_count
    from .semantic_rules import lookup_hints as _semantic_lookup_hints
except ImportError:
    from semantic_rules import check_sql as _semantic_check_sql  # type: ignore
    from semantic_rules import rule_count as _semantic_rule_count  # type: ignore
    from semantic_rules import lookup_hints as _semantic_lookup_hints  # type: ignore

try:
    # llm_client.TruncationError — used by the D1.8 check.
    from .llm_client import TruncationError as _LLMTruncationError
except ImportError:
    from llm_client import TruncationError as _LLMTruncationError  # type: ignore


# ── v98: SQL-shaped execution errors worth one corrective retry ──────────
# The api_wrapper execution path used to surface ANY error directly with no
# retry (the local_db path has had a retry since D1.5). Real-world case:
# Msg 4104 'The multi-part identifier "cm.Name" could not be bound.' reached
# the school's screen raw. Only SQL-SHAPED errors retry — auth/network/
# permission failures keep today's immediate-error behavior (no wasted LLM
# round-trip). False negatives simply keep the old behavior; false positives
# cost one extra LLM call and one extra API call, nothing else.
_SQL_ERROR_MARKERS = (
    "multi-part identifier", "could not be bound", "msg ",
    "invalid column", "invalid object", "incorrect syntax", "syntax error",
    "ambiguous column", "conversion failed", "arithmetic overflow",
    "division by zero", "invalid in the select list", "not contained in",
    "was not bound", "is invalid in", "undefined",
)


def _is_sql_shaped_error(err: Any) -> bool:
    """True when an execution error message looks like a SQL defect that a
    corrected regeneration could plausibly fix (vs auth/network failures)."""
    e = str(err or "").lower()
    return any(m in e for m in _SQL_ERROR_MARKERS)


# ── v63: deterministic Branch_Id → BranchID auto-repair (2026-09-09) ──────
# UAT finding: ALL 11 EXECUTE errors shared "SELECT Branch_Id FROM
# UserAccountRoleDetails" — the correct column is BranchID (Branch_Id belongs
# to Branch_Academic_Details, where it IS correct). The v28 model writes the
# typo intermittently; the error only surfaced at EXECUTE, triggering a full
# corrective LLM retry — the single biggest avoidable latency + failure
# source in UAT. Repair applies ONLY to provably-UserAccountRoleDetails
# contexts: (a) the bare "SELECT Branch_Id FROM UserAccountRoleDetails" shape
# from the UAT dump, (b) <alias>.Branch_Id where the alias is bound to
# UserAccountRoleDetails IN THIS QUERY. Branch_Academic_Details.Branch_Id is
# NEVER touched (its aliases are not in the bound set). Idempotent, zero-cost
# on clean SQL (cheap substring guard), applied to every generated SQL
# including retries.
_RE_BRANCH_ID_BARE = re.compile(
    r"(SELECT\s+)(Branch_Id)(\s+FROM\s+UserAccountRoleDetails\b)", re.IGNORECASE)
_RE_BRANCH_ID_QUALIFIED = re.compile(
    r"\b([A-Za-z_][A-Za-z0-9_]*)\.Branch_Id\b", re.IGNORECASE)
_RE_ALIAS_BOUND_UARD = re.compile(
    r"\b(?:FROM|JOIN)\s+UserAccountRoleDetails\s+(?:AS\s+)?([A-Za-z_][A-Za-z0-9_]*)\b",
    re.IGNORECASE)


def _auto_repair_branch_id(sql: str) -> str:
    """Fix the known Branch_Id/BranchID column mix-up on UserAccountRoleDetails.
    Deterministic, idempotent, no-retrain; anything not matching the verified
    shapes passes through untouched (fail-safe: the normal pipeline still runs)."""
    if not sql or "branch_id" not in sql.lower():
        return sql  # clean SQL exits here ("branchid" has no underscore)
    fixed = _RE_BRANCH_ID_BARE.sub(lambda m: f"{m.group(1)}BranchID{m.group(3)}", sql)
    bound = {a.upper() for a in _RE_ALIAS_BOUND_UARD.findall(fixed)}
    if bound:
        def _alias_fix(m: re.Match) -> str:
            return f"{m.group(1)}.BranchID" if m.group(1).upper() in bound else m.group(0)
        fixed = _RE_BRANCH_ID_QUALIFIED.sub(_alias_fix, fixed)
    return fixed


_BUDGET_MESSAGE = ("This question is taking too long to answer safely. "
                   "Please rephrase it more specifically, or pick one of the "
                   "suggested questions.")


class Stage(str, Enum):
    CONTEXT = "context"
    INJECT = "inject"
    GENERATE = "generate"
    GUARDRAIL = "guardrail"
    ALIAS_SCOPE = "alias_scope"
    BRANCH_SCOPING = "branch_scoping"
    VALIDATE = "validate"
    SUBSTIT = "substit"            # NEW (D1.4/F6): rewrite SQL literals post-VALIDATE
    SEMANTIC = "semantic"          # NEW (D1.1): 32-rule semantic-rules check
    BIND = "bind"
    EXECUTE = "execute"


class Outcome(str, Enum):
    ANSWER = "ANSWER"                       # executed, rows returned (or dry-run preview)
    NEEDS_BRANCH_SELECTION = "NEEDS_BRANCH_SELECTION"
    NEEDS_DISAMBIGUATION = "NEEDS_DISAMBIGUATION"
    REFUSED = "REFUSED"                     # fail closed (unsafe/invalid/unresolved)
    ERROR = "ERROR"                         # unexpected failure


@dataclass
class PipelineResult:
    outcome: Outcome
    stage: Stage
    # populated per-outcome:
    sql: Optional[str] = None
    sql_source: Optional[str] = None   # "dataset_exact" | "class_section_template" |
        # "class_template" | "top_n_template" | "section_template" | "llm" |
        # "llm_retry_after_guardrail" | "llm_retry_after_execute_error" | None
        # (None only when no SQL was ever attempted, e.g. a context-stage failure).
        # A retry ALWAYS calls the LLM directly, regardless of what produced the
        # original attempt -- so a retry's source is never the original fast-path
        # label, even if the first attempt was a dataset/template hit.
    bound_request: Optional[Dict[str, Any]] = None   # dry_run / api preview
    columns: List[str] = field(default_factory=list)
    rows: List[Any] = field(default_factory=list)
    total_row_count: Optional[int] = None
    disambiguation: Optional[Dict[str, Any]] = None  # UI payload
    message: Optional[str] = None
    detail: Optional[str] = None
    trace: List[str] = field(default_factory=list)   # human-readable stage log

    @property
    def ok(self) -> bool:
        return self.outcome == Outcome.ANSWER


class Orchestrator:
    """
    Wires the app-layer components into one request flow.

    Dependencies are injected (not imported hard) so the orchestrator is
    testable without a live LLM/DB and has no import-time coupling:

        llm_generate(system_prompt, question) -> sql_string
                   (may raise llm_client.TruncationError — D1.8)
        guardrail_validate(sql) -> object with .is_valid / .issues (or None to skip)
        alias_scope_check(sql) -> object with .is_valid / .issues  (or None to skip)
        make_validator(branch_vocab) -> ValueValidator            (or None to skip validate)
        binder -> ParameterBinderExecutor instance
        local_executor -> LocalDBExecutor instance                (for mode="local_db")
        mode -> "dry_run" | "local_db" | "api_wrapper"
        target_database -> str (e.g. "V3_TestDatabase")

    D1.9 (round-2): `fast_paths_enabled` (default False) is the single gate for
    every fast-path (dataset_lookup, class_template_lookup, top_n_template_lookup,
    section_template_lookup, class_section_template_lookup). When False, the
    orchestrator skips every fast-path entirely and goes straight to the LLM.
    Flip to True in tests / dry-runs that want to exercise the fast-paths.

    D1.1 (round-2): `semantic_rules_enabled` (default True) controls whether
    the SEMANTIC stage runs. When True (default), the 32-rule semantic-rules
    engine runs on the substituted SQL between VALIDATE and BIND. Disable for
    experiments / dry-runs that want to see the raw LLM output without the
    rules layer.

    D1.4/F6 (round-2): substitution is automatic when the wired ValueValidator
    returns results with should_substitute=True. The orchestrator calls
    parameter_binder.substitute_validated_values(sql, substitutions) — the
    caller doesn't need to do anything extra beyond wiring make_validator
    to a value_resolver.ValueValidator that uses the vocab/inject SynonymStore.
    """

    def __init__(
        self,
        llm_generate: Callable[[str, str], str],
        binder: Any,
        mode: str = "dry_run",
        target_database: str = "",
        guardrail_validate: Optional[Callable[[str], Any]] = None,
        alias_scope_check: Optional[Callable[[str], Any]] = None,
        make_validator: Optional[Callable[[Any], Any]] = None,
        local_executor: Any = None,
        base_system_prompt: str = "",
        inject_vocab: bool = False,
        extract_values: Optional[Callable[[str, Any], List[Dict[str, str]]]] = None,
        max_auto_pages: int = 5,   # was hardcoded at 20 -- each page is a
        # real, sequential remote HTTP round-trip; 20 pages meant up to 20
        # network calls before a large-result answer ever appeared, real,
        # noticeable latency in a live demo. Lowered to 5 (50 rows) by
        # default -- enough to show the system genuinely works without
        # the wait. Configurable here rather than hardcoded, so this can
        # be tuned without another code change.
        dataset_lookup: Any = None,   # optional DatasetLookup instance --
        # if set, checked before every LLM call; a normalized-exact hit
        # skips generation entirely. None (default) preserves existing
        # behavior exactly -- this is purely additive.
        class_template_lookup: Any = None,   # optional ClassTemplateLookup --
        # tried AFTER exact dataset_lookup misses, BEFORE the LLM. Handles
        # "same question shape, different class number" (e.g. a Class 7
        # training example correctly answering a live Class 9 question).
        # None (default) preserves existing behavior exactly.
        top_n_template_lookup: Any = None,   # optional TopNTemplateLookup --
        # same idea, for "Top N"/"Bottom N" questions with an explicit
        # number (e.g. "Top 10 defaulters" generalizing to "Top 15").
        section_template_lookup: Any = None,   # optional SectionTemplateLookup
        # -- same idea, for Section letters CONFIRMED present in training
        # data (narrower than Class: section names are branch-specific
        # vocabulary with no universal range to generalize to safely).
        class_section_template_lookup: Any = None,   # optional
        # ClassSectionTemplateLookup -- handles compressed notation like
        # "7A" (Class 7, Section A) as ONE atomic substitution. Kept
        # separate from class_template_lookup/section_template_lookup
        # deliberately: a single-variable lookup can't safely handle a
        # token that encodes two variables at once without risking a
        # partial, contaminated substitution.
        shorthand_class_section_lookup: Any = None,   # optional
        # ShorthandClassSectionLookup -- added 2026-09-06: the school's
        # natural shorthand ("1 talented", "class 5 foundation 2") matched
        # none of the other lookups. Recognizes ONLY tight end-anchored
        # students/girls count questions with a trailing section name, and
        # validates that name against THIS branch's real Sections list
        # (passed to find() per-request below). Unknown section = miss =
        # LLM, exactly as before. Substituted SQL passes the FULL
        # fail-closed chain like every other fast path.
        # ── D1.9: fast-path gate (default OFF in production). ──
        fast_paths_enabled: bool = False,
        # ── D1.1: semantic-rules gate (default ON). ──
        semantic_rules_enabled: bool = True,
    ):
        self._llm = llm_generate
        # ── v98 repair retries (both default ON, env kill switches) ──
        # AI_SECRETARY_SEMANTIC_RETRY=0   -> disable semantic-stage retry
        # AI_SECRETARY_EXECUTE_RETRY=0    -> disable api_wrapper execution retry
        self._semantic_retry_enabled = os.environ.get("AI_SECRETARY_SEMANTIC_RETRY", "1") != "0"
        self._execute_retry_enabled = os.environ.get("AI_SECRETARY_EXECUTE_RETRY", "1") != "0"
        # v63 (2026-09-09): TOTAL wall-clock budget for one question, seconds.
        # Each corrective retry (guardrail / branch-scoping / semantic /
        # execute) is a fresh LLM call; without a cap the worst case stacks
        # 4-5 × AI_SECRETARY_LLM_TIMEOUT ≈ minutes — the ">1 minute" UAT
        # reports. When the budget is gone, remaining retries are skipped and
        # the pipeline returns the honest first-attempt failure (with a
        # friendly timeout message where a retry was the only remaining path).
        # AI_SECRETARY_TOTAL_BUDGET=0 disables (tests). Default 90s (user pick).
        self._total_budget = float(os.environ.get("AI_SECRETARY_TOTAL_BUDGET", "90"))
        self._binder = binder
        self._max_auto_pages = max_auto_pages
        self._dataset_lookup = dataset_lookup
        self._class_template_lookup = class_template_lookup
        self._top_n_template_lookup = top_n_template_lookup
        self._section_template_lookup = section_template_lookup
        self._class_section_template_lookup = class_section_template_lookup
        self._shorthand_class_section_lookup = shorthand_class_section_lookup
        self._fast_paths_enabled = fast_paths_enabled
        self._semantic_rules_enabled = semantic_rules_enabled
        self._mode = mode
        self._target_db = target_database
        self._guardrail = guardrail_validate
        self._alias_scope = alias_scope_check
        self._make_validator = make_validator
        self._local_exec = local_executor
        self._base_prompt = base_system_prompt
        self._inject_vocab = inject_vocab
        # inject_vocab: whether to append the branch-vocab block to the system
        # prompt. DEFAULT FALSE — the v13 model was fine-tuned on a fixed
        # instruction WITHOUT a vocab block, and appending one derailed it
        # (2026-08-07: hallucinated locality-LIKE loop, dropped @UserId scoping).
        # Correctness for per-branch values is instead enforced post-generation
        # by the VALIDATE stage. Enable only if a vocab-aware prompt is trained.
        # Optional hook: given (sql, branch_vocab) return [{concept_type,value}]
        # for the values to validate. If None, the validate stage is skipped
        # (structure-only path). Wired in once the extraction approach is chosen.
        self._extract_values = extract_values

    # ── main entry ──
    def run(self, question: str, ctx: Any,
            page_number: int = 1, page_size: int = 10) -> PipelineResult:
        trace: List[str] = []
        t0 = time.monotonic()

        def _over_budget(where: str) -> bool:
            """v63: True once the total wall-clock budget is gone (trace-logged)."""
            if self._total_budget <= 0:
                return False
            elapsed = time.monotonic() - t0
            if elapsed < self._total_budget:
                return False
            trace.append(f"budget: {elapsed:.0f}s exceeded before {where} retry — retry skipped")
            return True

        # 1. CONTEXT — a branch must be resolved (picker if multi & unselected).
        if getattr(ctx, "needs_branch_selection", False):
            return PipelineResult(
                Outcome.NEEDS_BRANCH_SELECTION, Stage.CONTEXT,
                message="Please choose a branch first.",
                trace=trace + ["context: multi-branch, no branch selected"],
            )
        branch_vocab = ctx.branch_vocab() if hasattr(ctx, "branch_vocab") else None
        trace.append(f"context: user={ctx.user_id} branch={ctx.selected_branch_id}")

        # 2. INJECT — build the system prompt with the branch's real vocab.
        injection = ""
        if self._inject_vocab and branch_vocab is not None:
            try:
                try:
                    from .context_vocab import build_injection_prompt
                except ImportError:
                    from context_vocab import build_injection_prompt
                injection = build_injection_prompt(branch_vocab)
            except Exception:
                injection = ""
        system_prompt = (self._base_prompt + "\n\n" + injection).strip()
        trace.append(f"inject: vocab_block={'yes' if injection else 'no (off — model trained without it; VALIDATE stage enforces values)'}")

        # 3. GENERATE — local LLM produces T-SQL, UNLESS a normalized-exact
        #    match already exists in the training dataset (D1.9: gated by
        #    fast_paths_enabled — default OFF in production until labels are
        #    verified clean).
        cache_hit = False
        sql_source: Optional[str] = None
        if self._fast_paths_enabled and self._dataset_lookup is not None:
            cached_sql = self._dataset_lookup.find(question)
            if cached_sql is not None:
                sql = cached_sql
                cache_hit = True
                sql_source = "dataset_exact"
                trace.append("generate: skipped -- exact dataset match found")

        # Checked before the single-variable class/section templates --
        # "7A"-style compressed notation is a more specific pattern than
        # either alone, and substitutes both atomically.
        if self._fast_paths_enabled and not cache_hit and self._class_section_template_lookup is not None:
            templated_sql = self._class_section_template_lookup.find(question)
            if templated_sql is not None:
                sql = templated_sql
                cache_hit = True
                sql_source = "class_section_template"
                trace.append("generate: skipped -- class-section-template match found")

        if self._fast_paths_enabled and not cache_hit and self._class_template_lookup is not None:
            templated_sql = self._class_template_lookup.find(question)
            if templated_sql is not None:
                sql = templated_sql
                cache_hit = True
                sql_source = "class_template"
                trace.append("generate: skipped -- class-template match found")

        if self._fast_paths_enabled and not cache_hit and self._top_n_template_lookup is not None:
            templated_sql = self._top_n_template_lookup.find(question)
            if templated_sql is not None:
                sql = templated_sql
                cache_hit = True
                sql_source = "top_n_template"
                trace.append("generate: skipped -- top-n-template match found")

        if self._fast_paths_enabled and not cache_hit and self._section_template_lookup is not None:
            templated_sql = self._section_template_lookup.find(question)
            if templated_sql is not None:
                sql = templated_sql
                cache_hit = True
                sql_source = "section_template"
                trace.append("generate: skipped -- section-template match found")

        # Added 2026-09-06: shorthand "<class> <section-name>" questions
        # ("how many students are there in 1 talented?"). The section name
        # is validated against THIS branch's real Sections list before any
        # SQL is produced; unknown names miss and fall to the LLM as usual.
        if self._fast_paths_enabled and not cache_hit and self._shorthand_class_section_lookup is not None:
            _allowed_sections = None
            if branch_vocab is not None:
                try:
                    _allowed_sections = branch_vocab.values("SECTION")
                except Exception:
                    _allowed_sections = None
            templated_sql = self._shorthand_class_section_lookup.find(
                question, allowed_sections=_allowed_sections)
            if templated_sql is not None:
                sql = templated_sql
                cache_hit = True
                sql_source = "shorthand_class_section"
                trace.append("generate: skipped -- shorthand class-section match found")

        if not cache_hit:
            if not self._fast_paths_enabled:
                trace.append("generate: fast-paths disabled (D1.9), calling LLM directly")
            sql_source = "llm"
            try:
                sql = self._llm(system_prompt, question)
            except _LLMTruncationError as e:
                # D1.8: refuse truncated SQL rather than execute it.
                return PipelineResult(
                    Outcome.REFUSED, Stage.GENERATE, sql_source=sql_source,
                    message=(
                        "Output truncated; the query is too complex. "
                        "Please ask a more specific question."
                    ),
                    detail=str(e),
                    trace=trace + ["generate: REFUSED — truncation (finish_reason='length')"],
                )
            except Exception as e:
                return PipelineResult(Outcome.ERROR, Stage.GENERATE, sql_source=sql_source,
                                      detail=f"LLM generation failed: {e}", trace=trace)
        if not sql or not sql.strip():
            return PipelineResult(Outcome.REFUSED, Stage.GENERATE, sql_source=sql_source,
                                  message="No query was generated.", trace=trace)
        sql = sql.strip()
        _fixed = _auto_repair_branch_id(sql)
        if _fixed != sql:
            sql = _fixed
            trace.append("repair: Branch_Id → BranchID (UserAccountRoleDetails)")
        trace.append("generate: sql produced")

        # 4a. GUARDRAIL — schema existence, with one bounded retry.
        if self._guardrail is not None:
            g = self._guardrail(sql)
            if g is not None and not getattr(g, "is_valid", True):
                if _over_budget("guardrail"):
                    return PipelineResult(Outcome.ERROR, Stage.GUARDRAIL, sql=sql, sql_source=sql_source,
                                          message=_BUDGET_MESSAGE,
                                          detail="guardrail failed; no time left to retry",
                                          trace=trace + ["guardrail: budget stop"])
                trace.append("guardrail: FAILED on first attempt, retrying once")
                issues = getattr(g, "issues", [])
                issue_lines = "\n".join(f"- {i.detail}" for i in issues)
                # 2026-09-04 — HINT MAP (PRODUCTION_TRACE_OBSERVATIONS §8):
                # the retry used to say only "that column doesn't exist; try
                # again", so the model re-hallucinated because it had no
                # correct path. lookup_hints() maps known hallucinated
                # (table, column) pairs in the FAILED sql to the right
                # approach, giving the model the correct path this time.
                try:
                    hints = _semantic_lookup_hints(sql)
                except Exception:
                    hints = []
                hint_lines = "\n".join(f"- Hint: {h}" for h in hints)
                retry_question = (
                    f"{question}\n\n"
                    f"Note: a previous attempt at this query used a table or "
                    f"column that does not exist in the real schema:\n{issue_lines}\n"
                )
                if hint_lines:
                    retry_question += (
                        f"The correct approach for the issues above:\n{hint_lines}\n"
                    )
                retry_question += (
                    "Write the correct T-SQL query using only real tables and columns."
                )
                try:
                    sql = self._llm(system_prompt, retry_question).strip()
                    _fixed = _auto_repair_branch_id(sql)
                    if _fixed != sql:
                        sql = _fixed
                        trace.append("repair: Branch_Id → BranchID (guardrail retry)")
                    sql_source = "llm_retry_after_guardrail"  # a retry always calls the LLM directly -- never the original fast-path label, even if the first attempt was a dataset/template hit
                except _LLMTruncationError as e:
                    # D1.8: refuse truncated retry too.
                    return PipelineResult(
                        Outcome.REFUSED, Stage.GENERATE, sql_source=sql_source,
                        message=(
                            "Output truncated; the query is too complex. "
                            "Please ask a more specific question."
                        ),
                        detail=str(e),
                        trace=trace + ["guardrail: retry REFUSED — truncation"],
                    )
                except Exception as e:
                    return PipelineResult(Outcome.ERROR, Stage.GENERATE,
                                          detail=f"Retry generation failed: {e}", trace=trace)

                g2 = self._guardrail(sql)
                if g2 is not None and not getattr(g2, "is_valid", True):
                    return PipelineResult(
                        Outcome.REFUSED, Stage.GUARDRAIL, sql=sql, sql_source=sql_source,
                        message="The generated query referenced unknown tables/columns (after one retry).",
                        detail=getattr(g2, "summary", lambda: "")() if hasattr(g2, "summary") else None,
                        trace=trace + ["guardrail: FAILED after retry"],
                    )
                trace.append("guardrail: passed on retry")
            else:
                trace.append("guardrail: passed")

        # 4b. ALIAS-SCOPE — the Msg 4104 second pass.
        if self._alias_scope is not None:
            a = self._alias_scope(sql)
            if a is not None and not getattr(a, "is_valid", True):
                return PipelineResult(
                    Outcome.REFUSED, Stage.ALIAS_SCOPE, sql=sql, sql_source=sql_source,
                    message="The generated query has an out-of-scope alias (would fail at execution).",
                    detail=getattr(a, "summary", lambda: "")() if hasattr(a, "summary") else None,
                    trace=trace + ["alias_scope: FAILED"],
                )
            trace.append("alias_scope: passed")

        # 4c. BRANCH-SCOPING SECURITY GATE — independent, structural check
        # that the query genuinely, intactly ties results to the real,
        # authenticated @UserId, regardless of whether the model "should"
        # have included this. Fails closed: refuses rather than guessing
        # scoping is probably fine. Runs on EVERY generated query, whether
        # it came from the LLM or a fast-path lookup -- even cached SQL
        # gets checked, not exempted.
        scoping = check_branch_scoping(sql)
        if not scoping.is_valid and str(sql_source or "").startswith("llm") and not _over_budget("branch_scoping"):
            # 2026-09-05 v2 (FIX C): one corrective retry before refusing
            # (mirrors the guardrail retry). Most common near-miss: the model
            # emits @UserId as a bare branch filter (Branch_Id IN (@UserId))
            # instead of the real UserAccountRoleDetails linkage that every
            # training example carries. Fast-path SQL comes from
            # execution-verified rows and is refused immediately, never retried.
            trace.append(f"branch_scoping: FAILED ({scoping.reason}) — retrying once with corrective hint")
            fix_note = (
                "Note: your previous query was rejected because it was not correctly "
                "scoped to the authenticated user's branches.\n"
                "REQUIRED in every query: the branch filter must use this exact "
                "linkage subquery as an IN (...) filter:\n"
                "  IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId)\n"
                "Do NOT write @UserId directly inside the outer IN — Branch_Id IN (@UserId) "
                "is wrong because @UserId is a USER id, not a branch id.\n"
                "Rewrite the complete correct T-SQL query now, including the required "
                "linkage. Output only the SQL."
            )
            try:
                sql2 = self._llm(system_prompt, f"{question}\n\n{fix_note}").strip()
                _fixed2 = _auto_repair_branch_id(sql2)
                if _fixed2 != sql2:
                    sql2 = _fixed2
                    trace.append("repair: Branch_Id → BranchID (branch_scoping retry)")
                sql_source = "llm_retry_after_branch_scoping"
            except _LLMTruncationError as e:
                return PipelineResult(
                    Outcome.REFUSED, Stage.BRANCH_SCOPING, sql=sql, sql_source=sql_source,
                    message="Output truncated; the query is too complex. Please ask a more specific question.",
                    detail=str(e),
                    trace=trace + ["branch_scoping: retry REFUSED — truncation"],
                )
            except Exception as e:
                return PipelineResult(
                    Outcome.ERROR, Stage.BRANCH_SCOPING, sql=sql, sql_source=sql_source,
                    detail=f"Retry generation failed: {e}", trace=trace,
                )
            scoping2 = check_branch_scoping(sql2)
            if scoping2.is_valid:
                sql = sql2
                scoping = scoping2
                trace.append("branch_scoping: passed on retry")
            else:
                return PipelineResult(
                    Outcome.REFUSED, Stage.BRANCH_SCOPING, sql=sql2, sql_source=sql_source,
                    message="The generated query could not be confirmed as properly scoped to your authorized branches.",
                    detail=scoping2.reason,
                    trace=trace + ["branch_scoping: FAILED after retry"],
                )
        elif not scoping.is_valid:
            return PipelineResult(
                Outcome.REFUSED, Stage.BRANCH_SCOPING, sql=sql, sql_source=sql_source,
                message="The generated query could not be confirmed as properly scoped to your authorized branches.",
                detail=scoping.reason,
                trace=trace + ["branch_scoping: FAILED"],
            )
        trace.append(f"branch_scoping: passed ({scoping.matched_pattern})")

        # 5. VALIDATE — master-data literals vs branch vocab (fail closed).
        # D1.4/F6: collect substitution pairs from results with
        # should_substitute=True so the orchestrator can rewrite the SQL
        # literal BEFORE the semantic-rules check sees it.
        resolved_values: Dict[str, Any] = {}
        substitutions: Dict[str, str] = {}
        if self._extract_values is not None and branch_vocab is not None and self._make_validator is not None:
            validator = self._make_validator(branch_vocab)
            for item in self._extract_values(sql, branch_vocab):
                ctype, val = item.get("concept_type"), item.get("value")
                if not ctype or val is None:
                    continue
                vr = validator.validate(ctype, val)
                if getattr(vr, "validated", False):
                    # D1.4/F6: if the validator says "substitute", record
                    # the (user_value, database_value) pair. The SUBSTIT
                    # stage rewrites the SQL literal below.
                    if getattr(vr, "should_substitute", False):
                        db_val = getattr(vr, "database_value", None)
                        if db_val is not None and db_val != val:
                            substitutions[val] = db_val
                            trace.append(
                                f"validate: '{val}' → '{db_val}' (matched_via={getattr(vr,'matched_via','?')})"
                            )
                    continue  # validated — safe as-is (or substituted below)
                # not validated → disambiguate or refuse (fail closed)
                status = getattr(vr, "status", None)
                if str(status) and "DISAMBIG" in str(status).upper():
                    return PipelineResult(
                        Outcome.NEEDS_DISAMBIGUATION, Stage.VALIDATE, sql=sql, sql_source=sql_source,
                        disambiguation={
                            "concept_type": ctype, "user_value": val,
                            "candidates": getattr(vr, "candidates", []),
                            "reason": getattr(vr, "reason", None),
                        },
                        message=f"Which {ctype.lower()} did you mean?",
                        trace=trace + [f"validate: '{val}' needs disambiguation"],
                    )
                return PipelineResult(
                    Outcome.REFUSED, Stage.VALIDATE, sql=sql, sql_source=sql_source,
                    message=f"I don't recognize “{val}” as a {ctype.lower()} at your branch.",
                    detail="; ".join(str(c) for c in getattr(vr, "candidates", [])[:10]),
                    trace=trace + [f"validate: '{val}' not recognized (fail closed)"],
                )
            trace.append("validate: all values ok")
        else:
            trace.append("validate: skipped (no extractor wired)")

        # 5b. SUBSTIT — D1.4/F6: rewrite the SQL literals with the validated
        # database_values BEFORE the semantic-rules check sees the SQL.
        if substitutions:
            try:
                try:
                    from .parameter_binder import substitute_validated_values
                except ImportError:
                    from parameter_binder import substitute_validated_values
                sql = substitute_validated_values(sql, substitutions)
                trace.append(
                    f"substit: rewrote {len(substitutions)} literal(s): "
                    f"{list(substitutions.keys())} → {list(substitutions.values())}"
                )
            except Exception as e:
                # The substitution helper is safe-by-construction (regex
                # on quoted strings only); a failure here is unexpected.
                # Fail closed rather than execute the un-substituted SQL.
                return PipelineResult(
                    Outcome.REFUSED, Stage.SUBSTIT, sql=sql, sql_source=sql_source,
                    message="The validated values could not be safely substituted into the query.",
                    detail=str(e),
                    trace=trace + ["substit: FAILED"],
                )
        else:
            trace.append("substit: no literal rewrites needed")

        # 5c. SEMANTIC — D1.1: run the 32-rule semantic-rules engine on the
        # (substituted) SQL. If violations, REFUSED at Stage.SEMANTIC.
        if self._semantic_rules_enabled:
            try:
                violations = _semantic_check_sql(sql, question)
            except Exception as e:
                # A rules-engine crash should NOT take down the whole
                # pipeline. Log + skip (treat as no violations). The
                # engine itself wraps each rule in try/except, so this is
                # defense-in-depth against a future rule-introduction bug.
                trace.append(f"semantic: engine error (skipped): {e}")
                violations = []
            if violations:
                # High-severity violations refuse outright. Medium
                # violations are surfaced as warnings in `detail` but the
                # query still proceeds (matches the rules engine's
                # documented severity contract).
                high_vs = [v for v in violations if str(getattr(v, "severity", "")).upper() == "HIGH"]
                if high_vs:
                    first = high_vs[0]
                    # ── v98: ONE corrective retry before refusing ──
                    # (mirrors the guardrail/branch_scoping retries; closes
                    # audit finding 2.2). The hint carries the rule id, the
                    # human message, and the rule's suggested_fix so the
                    # model can repair the specific business-rule miss.
                    if self._semantic_retry_enabled and not _over_budget("semantic"):
                        trace.append(
                            f"semantic: REFUSED ({getattr(first, 'rule_id', 'RULE')}) — "
                            f"retrying once with corrective hint"
                        )
                        fix_hint = (getattr(first, "suggested_fix", "") or "").strip()
                        retry_question = (
                            f"{question}\n\n"
                            f"Note: your previous query was rejected by a business-rule check.\n"
                            f"Rule: {getattr(first, 'rule_id', 'RULE')} — {getattr(first, 'message', '')}\n"
                            + (f"Required fix: {fix_hint}\n" if fix_hint else "")
                            + "Rewrite the complete correct T-SQL SELECT query now. Output only the SQL."
                        )
                        sql_retry, failure = self._regen_and_revalidate(
                            system_prompt=system_prompt,
                            retry_question=retry_question,
                            question=question,
                            trace=trace,
                            label="semantic",
                            stage=Stage.SEMANTIC,
                            branch_vocab=branch_vocab,
                        )
                        if failure is not None:
                            if not failure.sql:
                                failure.sql = sql
                            return failure
                        sql = sql_retry
                        sql_source = "llm_retry_after_semantic"
                        trace.append("semantic: passed on retry")
                    else:
                        return PipelineResult(
                            Outcome.REFUSED, Stage.SEMANTIC, sql=sql, sql_source=sql_source,
                            message=f"Semantic check failed: {getattr(first, 'rule_id', 'RULE')} — {getattr(first, 'message', '')}",
                            detail=" | ".join(
                                f"[{getattr(v,'severity','?')}] {getattr(v,'rule_id','?')}: {getattr(v,'message','')}"
                                for v in violations
                            ),
                            trace=trace + [f"semantic: REFUSED — {len(high_vs)} HIGH violation(s)"],
                        )
                # Medium-only: warn, but proceed.
                trace.append(
                    f"semantic: {len(violations)} MEDIUM violation(s) — proceeding with warnings"
                )
            else:
                trace.append(f"semantic: passed ({_semantic_rule_count()} rules)")

        # 6. BIND — security params (+ resolved values) as real parameters.
        security_params = ctx.to_query_params() if hasattr(ctx, "to_query_params") else {}
        try:
            bound = self._binder.bind(sql, security_params, resolved_values,
                                      page_number, page_size)
        except Exception as e:
            return PipelineResult(Outcome.REFUSED, Stage.BIND, sql=sql, sql_source=sql_source,
                                  message="The query could not be safely bound.",
                                  detail=str(e), trace=trace + ["bind: FAILED"])
        trace.append("bind: ok")

        # 7. EXECUTE — dry_run / local_db / api_wrapper.
        if self._mode == "dry_run":
            return PipelineResult(
                Outcome.ANSWER, Stage.EXECUTE, sql=sql, sql_source=sql_source,
                bound_request=bound.to_body(),
                message="[dry_run] Query built and bound; not executed.",
                trace=trace + ["execute: dry_run (no execution)"],
            )

        if self._mode == "local_db":
            if self._local_exec is None:
                return PipelineResult(Outcome.ERROR, Stage.EXECUTE, sql=sql, sql_source=sql_source,
                                      detail="local_db mode but no local executor configured.",
                                      trace=trace)
            r = self._local_exec.execute(bound.sql_query, bound.parameters, self._target_db)
            if not getattr(r, "ok", False):
                if _over_budget("execute"):
                    return PipelineResult(Outcome.ERROR, Stage.EXECUTE, sql=sql, sql_source=sql_source,
                                          message=_BUDGET_MESSAGE,
                                          detail=str(getattr(r, "error", ""))[:300],
                                          trace=trace + ["execute: budget stop"])
                trace.append(f"execute: FAILED on first attempt, retrying once — {getattr(r, 'error', '')[:150]}")
                retry_question = (
                    f"{question}\n\n"
                    f"Note: a previous attempt at this query failed to execute "
                    f"against the real database with this error:\n{getattr(r, 'error', '')}\n"
                    f"Write a corrected T-SQL query that avoids this error."
                )
                try:
                    sql_retry = self._llm(system_prompt, retry_question).strip()
                    _fixed_retry = _auto_repair_branch_id(sql_retry)
                    if _fixed_retry != sql_retry:
                        sql_retry = _fixed_retry
                        trace.append("repair: Branch_Id → BranchID (execute retry)")
                    sql_source = "llm_retry_after_execute_error"  # always a fresh LLM call, regardless of the original source
                except _LLMTruncationError as e:
                    return PipelineResult(
                        Outcome.REFUSED, Stage.EXECUTE, sql=sql, sql_source=sql_source,
                        message=(
                            "Output truncated; the query is too complex. "
                            "Please ask a more specific question."
                        ),
                        detail=str(e),
                        trace=trace + ["execute: retry REFUSED — truncation"],
                    )
                except Exception as e:
                    return PipelineResult(Outcome.ERROR, Stage.EXECUTE, sql=sql, sql_source=sql_source,
                                          detail=f"Retry generation failed: {e}",
                                          trace=trace + ["execute: retry generation FAILED"])
                # Re-check the retry against the SAME guardrail before ever
                # executing it -- a fresh generation, not a guaranteed-safe
                # edit, needs the same scrutiny as any first attempt.
                if self._guardrail is not None:
                    g_retry = self._guardrail(sql_retry)
                    if g_retry is not None and not getattr(g_retry, "is_valid", True):
                        return PipelineResult(Outcome.ERROR, Stage.EXECUTE, sql=sql_retry, sql_source=sql_source,
                                              detail="Retry failed the guardrail check.",
                                              trace=trace + ["execute: retry FAILED guardrail"])
                # D1.5: RE-RUN check_branch_scoping on the retried SQL before
                # re-executing. The original skipped this — a fresh LLM
                # generation, not a guaranteed-safe edit, needs the same
                # branch-scoping scrutiny as any first attempt.
                scoping_retry = check_branch_scoping(sql_retry)
                if not scoping_retry.is_valid:
                    return PipelineResult(
                        Outcome.REFUSED, Stage.BRANCH_SCOPING, sql=sql_retry, sql_source=sql_source,
                        message="The retried query could not be confirmed as properly scoped to your authorized branches.",
                        detail=scoping_retry.reason,
                        trace=trace + ["execute: retry FAILED branch_scoping (D1.5)"],
                    )
                trace.append("execute: retry passed branch_scoping (D1.5)")
                try:
                    bound_retry = self._binder.bind(sql_retry, security_params, resolved_values,
                                                     page_number, page_size)
                except Exception as e:
                    return PipelineResult(Outcome.REFUSED, Stage.EXECUTE, sql=sql_retry, sql_source=sql_source,
                                          message="The retried query could not be safely bound.",
                                          detail=str(e), trace=trace + ["execute: retry bind FAILED"])
                r2 = self._local_exec.execute(bound_retry.sql_query, bound_retry.parameters, self._target_db)
                if not getattr(r2, "ok", False):
                    return PipelineResult(Outcome.ERROR, Stage.EXECUTE, sql=sql_retry, sql_source=sql_source,
                                          bound_request=bound_retry.to_body(),
                                          detail=getattr(r2, "error", "execution failed"),
                                          trace=trace + ["execute: local_db FAILED after retry"])
                trace.append(f"execute: local_db ok on retry ({getattr(r2,'row_count',0)} rows)")
                return PipelineResult(
                    Outcome.ANSWER, Stage.EXECUTE, sql=sql_retry, sql_source=sql_source, bound_request=bound_retry.to_body(),
                    columns=getattr(r2, "columns", []), rows=getattr(r2, "rows", []),
                    total_row_count=getattr(r2, "row_count", None),
                    trace=trace,
                )
            return PipelineResult(
                Outcome.ANSWER, Stage.EXECUTE, sql=sql, sql_source=sql_source, bound_request=bound.to_body(),
                columns=getattr(r, "columns", []), rows=getattr(r, "rows", []),
                total_row_count=getattr(r, "row_count", None),
                trace=trace + [f"execute: local_db ok ({getattr(r,'row_count',0)} rows)"],
            )

        # api_wrapper (default fall-through)
        # Detect TOP N BEFORE the binder strips it. When the LLM emitted
        # "SELECT TOP N ...", it means "I want exactly N rows, period" — the
        # orchestrator must NOT paginate after the first page (the school's
        # API reports TotalRowCount = the FULL unfiltered count, ignoring the
        # client's page_size, so the pagination loop would otherwise fetch the
        # same first page over and over, returning N copies of the same row(s)
        # and a misleading "408 rows" total).
        try:
            from parameter_binder import _extract_top_n as _orch_extract_top_n
            _, _top_n_in_sql = _orch_extract_top_n(sql)
        except Exception:
            _top_n_in_sql = None

        ex = self._binder.execute(sql, security_params, resolved_values,
                                  page_number, page_size)
        if not getattr(ex, "ok", False):
            # Surface the school's actual error message in the `message` field
            # (NOT just `detail`, which is hidden unless DEBUG=true). The school's
            # ErrorMessage is not a security leak — it's their own error about
            # why the query failed (e.g. "Invalid column name 'Class_ID'").
            # We still put the full detail in `detail` for server logs / DEBUG mode.
            api_err = getattr(ex, "error", "execution failed") or "execution failed"
            # ── v98: ONE corrective retry for SQL-shaped execution errors ──
            # (the api_wrapper counterpart of the local_db D1.5 retry; closes
            # the real-world raw Msg 4104 path). Auth/network errors do NOT
            # retry — they keep the immediate-error behavior below.
            if self._execute_retry_enabled and _is_sql_shaped_error(api_err) and not _over_budget("api execute"):
                trace.append(f"execute: api FAILED ({api_err[:150]}) — retrying once with corrective hint")
                retry_question = (
                    f"{question}\n\n"
                    f"Note: a previous attempt at this query failed to execute "
                    f"against the school's database with this error:\n{api_err}\n"
                    f"Write a corrected T-SQL SELECT query that avoids this error. "
                    f"Output only the SQL."
                )
                sql_retry, failure = self._regen_and_revalidate(
                    system_prompt=system_prompt,
                    retry_question=retry_question,
                    question=question,
                    trace=trace,
                    label="execute",
                    stage=Stage.EXECUTE,
                    branch_vocab=branch_vocab,
                )
                if failure is not None:
                    if not failure.sql:
                        failure.sql = sql
                    return failure
                sql = sql_retry
                sql_source = "llm_retry_after_execute_error"
                ex = self._binder.execute(sql, security_params, resolved_values,
                                          page_number, page_size)
                if not getattr(ex, "ok", False):
                    api_err2 = getattr(ex, "error", "execution failed") or "execution failed"
                    return PipelineResult(
                        Outcome.ERROR, Stage.EXECUTE, sql=sql, sql_source=sql_source,
                        bound_request=getattr(ex, "request_body", None),
                        message=f"The school's database rejected the query: {api_err2}",
                        detail=api_err2,
                        trace=trace + ["execute: api FAILED after retry"],
                    )
                trace.append("execute: api ok on retry")
            else:
                return PipelineResult(Outcome.ERROR, Stage.EXECUTE, sql=sql, sql_source=sql_source,
                                      bound_request=getattr(ex, "request_body", None),
                                      message=f"The school's database rejected the query: {api_err}",
                                      detail=api_err,
                                      trace=trace + ["execute: api FAILED"])

        # PAGINATION: the real API returns one page at a time (page_size
        # rows). Loop to fetch every remaining page rather than silently
        # returning only the first, until either everything is fetched or
        # a safety cap is hit -- MAX_AUTO_PAGES below -- to avoid an
        # unbounded loop against a genuinely huge result set. Confirmed
        # real need: an actual live response earlier showed
        # TotalRowCount=42 with only 10 rows returned by default.
        #
        # IMPORTANT: SKIP pagination entirely when the original SQL used
        # "TOP N". The school's ExecuteQuery API reports TotalRowCount as
        # the FULL unfiltered count (ignoring TOP/page_size), so the
        # pagination loop would otherwise re-fetch the same first page
        # over and over — producing N copies of the same row(s) and a
        # wildly misleading "total" (e.g. 408 when there should be 1).
        MAX_AUTO_PAGES = self._max_auto_pages
        all_rows = list(getattr(ex, "rows", []))
        total = getattr(ex, "total_row_count", None)
        pages_fetched = 1
        truncated_by_cap = False
        if _top_n_in_sql is not None:
            # TOP-N query: the first page IS the answer. Trust the row count
            # we actually received, not the school's inflated TotalRowCount.
            # Report total_row_count = len(all_rows) so the UI shows the
            # real number, not the school's "408 rows" fiction.
            total = len(all_rows)
            trace.append(f"execute: TOP {_top_n_in_sql} query — pagination skipped (returned {len(all_rows)} row(s))")
        elif total is not None and total > len(all_rows):
            next_page = page_number + 1
            while len(all_rows) < total and pages_fetched < MAX_AUTO_PAGES:
                ex_next = self._binder.execute(sql, security_params, resolved_values,
                                               next_page, page_size)
                if not getattr(ex_next, "ok", False):
                    # A later page failing shouldn't discard the rows already
                    # fetched -- return what we have, note the shortfall.
                    trace.append(f"execute: page {next_page} FAILED, returning partial results")
                    break
                page_rows = getattr(ex_next, "rows", [])
                if not page_rows:
                    break  # defensive -- server reported more rows than it can deliver
                all_rows.extend(page_rows)
                pages_fetched += 1
                next_page += 1
            if len(all_rows) < total:
                truncated_by_cap = True

        trace_msg = f"execute: api ok ({len(all_rows)} row(s) across {pages_fetched} page(s))"
        if truncated_by_cap:
            trace_msg += f" -- capped at {MAX_AUTO_PAGES} pages, {total - len(all_rows)} row(s) not fetched"

        # NORMALIZE: the real ExecuteQuery API returns Data as a list of
        # DICTS (confirmed from real responses, e.g. [{"FirstName": "...",
        # ...}, ...]) -- but this path never extracted "columns" from
        # them, unlike local_db mode (which always sets columns). Anything
        # downstream (ui_app.py's dict(zip(columns, r)), audit logging)
        # assumed rows were plain value-tuples needing zip with columns --
        # with columns always empty here, every zip produced nothing,
        # silently showing an "empty" table despite rows genuinely being
        # fetched. Confirmed via a real screenshot: 200 real rows fetched,
        # displayed as empty. Converting to the SAME shape local_db
        # produces here, once, so nothing downstream needs to special-case
        # which execution mode actually ran.
        columns: List[str] = []
        normalized_rows: List[List[Any]] = []
        if all_rows and isinstance(all_rows[0], dict):
            columns = list(all_rows[0].keys())
            normalized_rows = [[row.get(c) for c in columns] for row in all_rows]
        else:
            normalized_rows = all_rows  # already list-shaped (e.g. local mock/test), pass through

        return PipelineResult(
            Outcome.ANSWER, Stage.EXECUTE, sql=sql, sql_source=sql_source,
            bound_request=getattr(ex, "request_body", None),
            columns=columns,
            rows=normalized_rows,
            total_row_count=total,
            trace=trace + [trace_msg],
        )

    # ── v98: shared repair path ──────────────────────────────────────────
    def _regen_and_revalidate(
        self, *, system_prompt: str, retry_question: str, question: str,
        trace: List[str], label: str, stage: "Stage", branch_vocab: Any,
    ) -> Tuple[Optional[str], Optional[PipelineResult]]:
        """ONE fresh LLM generation, re-validated through the FULL gate chain:
        guardrail → alias_scope → branch_scoping → value validation →
        semantic. Used by both v98 retries (semantic-stage repair and
        api_wrapper execution repair) so a repair can never be weaker than
        a first attempt.

        Returns (sql, None) when the regenerated SQL is clean — the caller
        adopts it. Returns (None, PipelineResult) when the retry must stop —
        the caller returns that PipelineResult as-is (it carries the retry's
        own failure trace; caller backfills .sql with the original SQL).
        """
        try:
            sql_new = self._llm(system_prompt, retry_question).strip()
            _fixed_new = _auto_repair_branch_id(sql_new)
            if _fixed_new != sql_new:
                sql_new = _fixed_new
                trace.append("repair: Branch_Id → BranchID (retry)")
        except _LLMTruncationError as e:
            return None, PipelineResult(
                Outcome.REFUSED, stage, sql="", sql_source="llm_retry",
                message=("Output truncated; the query is too complex. "
                         "Please ask a more specific question."),
                detail=str(e),
                trace=trace + [f"{label}: retry REFUSED — truncation"],
            )
        except Exception as e:
            return None, PipelineResult(
                Outcome.ERROR, stage, sql="", sql_source="llm_retry",
                detail=f"Retry generation failed: {e}",
                trace=trace + [f"{label}: retry generation FAILED"],
            )
        if not sql_new:
            return None, PipelineResult(
                Outcome.REFUSED, stage, sql="", sql_source="llm_retry",
                message="The retry produced no query.",
                trace=trace + [f"{label}: retry REFUSED — empty output"],
            )

        # (1) guardrail — same scrutiny as any first attempt.
        if self._guardrail is not None:
            g = self._guardrail(sql_new)
            if g is not None and not getattr(g, "is_valid", True):
                return None, PipelineResult(
                    Outcome.REFUSED, stage, sql=sql_new, sql_source="llm_retry",
                    message="The repaired query still referenced unknown tables/columns.",
                    detail=getattr(g, "summary", lambda: str(g))() if hasattr(g, "summary") else str(g),
                    trace=trace + [f"{label}: retry FAILED guardrail"],
                )

        # (2) alias-scope — includes the v98 undefined-alias gap fix.
        if self._alias_scope is not None:
            a = self._alias_scope(sql_new)
            if a is not None and not getattr(a, "is_valid", True):
                return None, PipelineResult(
                    Outcome.REFUSED, stage, sql=sql_new, sql_source="llm_retry",
                    message="The repaired query still has an alias problem (would fail at execution).",
                    detail=getattr(a, "summary", lambda: "")() if hasattr(a, "summary") else None,
                    trace=trace + [f"{label}: retry FAILED alias_scope"],
                )

        # (3) branch-scoping security gate — mandatory on every fresh SQL.
        sc = check_branch_scoping(sql_new)
        if not sc.is_valid:
            return None, PipelineResult(
                Outcome.REFUSED, Stage.BRANCH_SCOPING, sql=sql_new, sql_source="llm_retry",
                message="The repaired query could not be confirmed as properly scoped to your authorized branches.",
                detail=sc.reason,
                trace=trace + [f"{label}: retry FAILED branch_scoping"],
            )

        # (4) value validation — literals must still exist in the branch
        # vocab (the retry SQL is fresh, so the earlier VALIDATE stage's
        # verdicts no longer apply). Substitutions recorded during this
        # re-check are applied immediately (safe-by-construction helper).
        if self._extract_values is not None and branch_vocab is not None and self._make_validator is not None:
            try:
                validator = self._make_validator(branch_vocab)
                for item in self._extract_values(sql_new, branch_vocab):
                    ctype, val = item.get("concept_type"), item.get("value")
                    if not ctype or val is None:
                        continue
                    vr = validator.validate(ctype, val)
                    if getattr(vr, "validated", False):
                        if getattr(vr, "should_substitute", False):
                            db_val = getattr(vr, "database_value", None)
                            if db_val is not None and db_val != val:
                                try:
                                    try:
                                        from .parameter_binder import substitute_validated_values
                                    except ImportError:
                                        from parameter_binder import substitute_validated_values
                                    sql_new = substitute_validated_values(sql_new, {val: db_val})
                                except Exception:
                                    pass  # cosmetic rewrite only; VALIDATE already passed
                        continue
                    return None, PipelineResult(
                        Outcome.REFUSED, stage, sql=sql_new, sql_source="llm_retry",
                        message=f"The repaired query used an unrecognized value “{val}”.",
                        detail="; ".join(str(c) for c in getattr(vr, "candidates", [])[:10]),
                        trace=trace + [f"{label}: retry FAILED value validation"],
                    )
            except Exception as e:
                # Value-validation machinery failed — fail closed on the
                # retry rather than execute an unvalidated repair.
                return None, PipelineResult(
                    Outcome.REFUSED, stage, sql=sql_new, sql_source="llm_retry",
                    message="The repaired query could not be fully re-validated.",
                    detail=str(e),
                    trace=trace + [f"{label}: retry FAILED validation machinery"],
                )

        # (5) semantic rules — the retry must be as clean as a first pass.
        if self._semantic_rules_enabled:
            try:
                vios = _semantic_check_sql(sql_new, question)
            except Exception:
                vios = []
            high = [v for v in vios if str(getattr(v, "severity", "")).upper() == "HIGH"]
            if high:
                return None, PipelineResult(
                    Outcome.REFUSED, Stage.SEMANTIC, sql=sql_new, sql_source="llm_retry",
                    message=(f"The repaired query still failed the business-rule check: "
                             f"{getattr(high[0], 'rule_id', 'RULE')} — {getattr(high[0], 'message', '')}"),
                    detail=" | ".join(
                        f"[{getattr(v,'severity','?')}] {getattr(v,'rule_id','?')}: {getattr(v,'message','')}"
                        for v in vios
                    ),
                    trace=trace + [f"{label}: retry FAILED semantic"],
                )

        return sql_new, None

# v30 Server Deployment Package — ChaloSchools AI Secretary
**Package: `v30_server_deploy_2026-09-13.zip` · date 2026-09-13 · target: live VPS (OCI Ubuntu, `/opt/chalo-ai-secretary/`)**

---

## 1. WHAT CHANGED in v30 (vs the v27 model you serve today)

**Only the LLM brain changes.** No new Python dependencies, no endpoint changes, no
port changes, no DB schema changes, no nginx changes, no llama.cpp flag changes.

| Item | v27 (current) | v30 (this package) |
|---|---|---|
| Model | `AISv27-qwen2.5-coder-7b-instruct.Q4_K_M.gguf` (~4.5 GB) | `AISv30-qwen2.5-coder-7b-instruct.Q4_K_M.gguf` (same arch/size/quant) |
| Training set | old, smaller | **3,991 examples** (3,666 train / 325 val), every row carries the 2,451-char system prompt **trained-in** |
| System prompt the model knows | 340-char "legacy" prompt | 2,451-char **"v29" profile** prompt (SECURITY scoping, two term concepts, outstanding formula, always-filter rules, known traps, output rules) |
| Exception coverage | none | **52 owner-verified pairs** folded into training (44 train / 8 val) |
| "Latest exam" meaning | broken anchor (`ExamPositionID`, NULL on 69/69 exam types) | **new canonical definition**: exam type with most recent `MAX(COALESCE(smes.PortalProgressCardPublishedDate, smes.GeneratedDate))` per branch+year, published outranks generated (owner-confirmed), tie-break `ExamTypeID DESC` |
| Admission "pending" | counted Completed/Dropped too (Q48 bug) | counts only `AdmissionStatusMaster esm.Name IN ('Initiated','Updated')` |

What went into the 52 exception fixes (all verified by you in SSMS before folding):
- 18 alias-scope repairs (SQL Server Msg 4104 class) — rev-12
- 7 numeric-safety repairs with `TRY_CAST` (Msg 8114 class) — rev-13b
- 8 latest-exam rewrites (Q23 Q24 Q26 Q28 Q29 Q30 Q33 Q34) — rev-15
- 1 admission-status fix (Q48): "pending a decision" now means `AdmissionStatusMaster esm.Name IN ('Initiated','Updated')` — the old `NOT LIKE` chain silently counted Completed/Dropped/Cancelled as pending — rev-14
- Full static checker gate on all 3,991 SQL outputs: **0 findings**; final md5s:
  train `7601265206b408797eb09941e2aa8e66`, val `7d7cee4ac1c163cc4714b3122e0f3031`.

**Unchanged:** 54 semantic rules, guardrails, validation/binding stages, `@UserId` /
`@SelectedBranchId` runtime binding, backend `.env` keys (except one line, below),
`--ctx-size 4096`, quantization (Q4_K_M), RAM footprint.

---

## 2. FILES IN THIS PACKAGE → WHERE THEY GO

| In the package | Destination on VPS |
|---|---|
| `chalo_chatbot/` (app tree, incl. the required **v29 prompt profile** in `pipeline/schema_knowledge.py`) | `/opt/chalo-ai-secretary/` (unzip, same layout as the quickstart) |
| `DEPLOY_V30.md` (this file) | anywhere, e.g. `/opt/chalo-ai-secretary/deploy-v30/` |
| `smoke_test_v30.sql` (3 real-DB sanity batches) | run from SSMS against the **real** DB after deploy |
| `MANIFEST.txt` (md5 receipts) | reference only |

**NOT in the package:** the GGUF model — it comes from your Kaggle/Colab export (§3 step 1).

> Why the app tree is included even though v30 changed no app code: the currently
> shipped v98 package does **not** contain the `v29` prompt profile
> (`VALID_PROFILES = ("legacy","expanded")` there). The v30 model requires it.
> The tree in this package is the v29-audit app snapshot (v98-era code + v29 profile),
> with heavyweight non-runtime data removed (`training/*.jsonl`, `sql_tests/`,
> `semantic_validation/reference_inputs/`).

---

## 3. STEP-BY-STEP (VPS)

### 0) Pre-flight
```bash
ssh ubuntu@<PUBLIC-IP>
systemctl status chalo-llm chalo-backend --no-pager | head -20   # both active?
ls -la /opt/chalo-ai-secretary/models/                            # note current gguf
```

### 1) Export the v30 GGUF (Kaggle/Colab side)
Run the existing GGUF export notebook (`finetune_qwen25coder_GGUF_EXPORT_COLAB_v28.ipynb`)
against the v30 training output, with two settings changed:
- `MODEL_VERSION = "v30"` (drives the output filename)
- `quantization_method = "q4_k_m"` (unchanged, same as v27/v28)

Expected output file: **`AISv30-qwen2.5-coder-7b-instruct.Q4_K_M.gguf`** (~4.5 GB).
Download it. If the notebook prints a different name, use that name below.

### 2) Upload to the VPS
```powershell
scp -i $env:USERPROFILE\.ssh\oci_key.pem .\AISv30-qwen2.5-coder-7b-instruct.Q4_K_M.gguf ubuntu@<PUBLIC-IP>:/tmp/
scp -i $env:USERPROFILE\.ssh\oci_key.pem .\v30_server_deploy_2026-09-13.zip  ubuntu@<PUBLIC-IP>:/tmp/
```
> If the 4.5 GB upload keeps dying, use `rsync -avzP -e "ssh -i ~/.ssh/oci_key" AISv30-*.gguf ubuntu@<IP>:/tmp/` — it resumes.

### 3) Install the app tree (with rollback point)
```bash
sudo cp -r /opt/chalo-ai-secretary/chalo_chatbot /opt/chalo-ai-secretary/chalo_chatbot_backup_$(date +%F)
sudo unzip /tmp/v30_server_deploy_2026-09-13.zip -d /opt/chalo-ai-secretary/
sudo chown -R chalo:chalo /opt/chalo-ai-secretary
# venv deps: unchanged in v30, but harmless to re-verify:
sudo /opt/chalo-ai-secretary/venv/bin/pip install -r /opt/chalo-ai-secretary/chalo_chatbot/backend/requirements.txt
```

### 4) Install the model
```bash
sudo mv /tmp/AISv30-qwen2.5-coder-7b-instruct.Q4_K_M.gguf /opt/chalo-ai-secretary/models/
sudo chown chalo:chalo /opt/chalo-ai-secretary/models/AISv30-*.gguf
```

### 5) CONFIG CHANGE 1 of 2 — model path in the systemd unit
```bash
sudo nano /etc/systemd/system/chalo-llm.service
# ExecStart line: change ONLY the -m path:
#   -m /opt/chalo-ai-secretary/models/AISv30-qwen2.5-coder-7b-instruct.Q4_K_M.gguf
# keep: --host 127.0.0.1 --port 8080 --ctx-size 4096 --threads 8
sudo systemctl daemon-reload
```

### 6) CONFIG CHANGE 2 of 2 — prompt profile (REQUIRED for v30)
```bash
sudo nano /opt/chalo-ai-secretary/chalo_chatbot/backend/.env
# set:  AI_SECRETARY_PROMPT_PROFILE=v29
# (it was "expanded" per .env.example, or "legacy" if you set it for v27)
grep AI_SECRETARY_PROMPT_PROFILE /opt/chalo-ai-secretary/chalo_chatbot/backend/.env   # must print =v29
```
**Do not invent a "v30" profile** — the profile name is dataset lineage. The `v29`
profile text is **byte-identical** to the instruction stamped on every v30 training
row (verified md5 `a88cb587…`, 2,451 chars). Serving `legacy` or `expanded` would
feed the model a prompt it was never fine-tuned on → quality drops immediately.
The backend reads the profile **at startup**, so restart after editing.

### 7) Restart in order
```bash
sudo systemctl restart chalo-llm
sudo journalctl -u chalo-llm -f        # wait for: server is listening on 127.0.0.1:8080
curl http://127.0.0.1:8080/health      # {"status":"ok"}
sudo systemctl restart chalo-backend
curl http://127.0.0.1:8000/api/health  # {"status":"ok","rules_count":54,...}
curl http://localhost/api/health       # through nginx
```

### 8) Verify the served prompt (30-second receipt)
```bash
cd /opt/chalo-ai-secretary/chalo_chatbot
sudo -u chalo AI_SECRETARY_PROMPT_PROFILE=v29 /opt/chalo-ai-secretary/venv/bin/python \
  -c "from pipeline.schema_knowledge import build_system_prompt; import hashlib; print(hashlib.md5(build_system_prompt('v29').encode()).hexdigest()[:8])"
# expect: a88cb587
```

### 9) Rollback (keep everything, flip two lines)
```bash
# 1. chalo-llm.service: -m path back to AISv27-...gguf; daemon-reload
# 2. backend/.env: AI_SECRETARY_PROMPT_PROFILE back to previous value
sudo systemctl daemon-reload && sudo systemctl restart chalo-llm chalo-backend
# app tree if needed:
#   sudo rm -rf /opt/chalo-ai-secretary/chalo_chatbot && \
#   sudo mv /opt/chalo-ai-secretary/chalo_chatbot_backup_<date> /opt/chalo-ai-secretary/chalo_chatbot
# DO NOT delete AISv27-*.gguf — it is your instant fallback.
```

---

## 4. WINDOWS LOCAL TESTING (optional)
```bat
D:\llama-b6691\llama-server.exe -m D:\ggufs\AISv30-qwen2.5-coder-7b-instruct.Q4_K_M.gguf --host 127.0.0.1 --port 8080 --ctx-size 4096
```
plus the same one-line `.env` change (`AI_SECRETARY_PROMPT_PROFILE=v29`) in the local backend.

---

## 5. SMOKE TESTS AFTER DEPLOY

**Chat UI (ask the bot, expect clean scoped SQL + answers):**
1. `Which classes had an average score below 50% in the latest exam?` — exercises the new latest-exam definition. Sanity: the exam it picks should match what the school considers the latest exam.
2. `Show students who failed in the same subject in 2 or more consecutive exams` — the rewritten consecutive-exam logic (no more `ExamPositionID+1` arithmetic).
3. `How many admission applications are still pending a decision?` — must count only Initiated/Updated statuses (Q48 fix; Completed/Dropped/Cancelled must not be counted).
4. `Show transport routes with vehicle details` — Q51 sanity on the REAL DB. If routes come back empty while routes exist, that is the known locklist item (test-copy VehicleMaster was empty; join key may need a one-word swap in a future data rev) — **not** a server config problem. Just report it.

**SSMS against the real DB:** run `smoke_test_v30.sql` (3 batches: Q23 latest-exam,
Q28 latest-exam, Q48 pending admission applications). First edit `@UserId` to a real staff UserID
(`@SelectedBranchId NULL` = all that user's branches). Compiling cleanly is the pass
bar; zero rows are fine (data-dependent).

---

## 6. TROUBLESHOOTING

| Symptom | Likely cause / fix |
|---|---|
| Answers feel like v27, ignore scoping/rules | `AI_SECRETARY_PROMPT_PROFILE` not `v29`, or backend not restarted after the .env edit |
| `chalo-llm` fails to start | wrong `-m` path/filename in the unit; check `journalctl -u chalo-llm -n 50`; verify upload with `md5sum` against the Kaggle output |
| Slow first answer after restart | normal — llama-server mmaps 4.5 GB (~30–60 s) |
| `/api/chat` 500 | `journalctl -u chalo-backend -n 50`; v30 added no deps, so this would be pre-existing |
| Latest-exam answers pick an unexpected exam | check the exam's GeneratedDate vs PortalProgressCardPublishedDate in `StudentMarkEntrySettings` (published outranks generated by owner decision) |

---

**Package provenance:** app tree = v29-audit snapshot (v98 code + v29 prompt profile);
v30 dataset md5s train `76012652…` / val `7d7cee4a…` (instruction backfill applied to
all 52 exception rows, full gate 3,991/3,991 findings 0); latest-exam definition locked
rev-15, owner-confirmed 2026-09-12.

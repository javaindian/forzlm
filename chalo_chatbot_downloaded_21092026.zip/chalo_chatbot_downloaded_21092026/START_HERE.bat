@echo off
REM ==========================================================================
REM  ChaloSchools AI Secretary - ONE-CLICK STARTER
REM  Double-click this file to start all 3 services in 3 windows.
REM ==========================================================================

setlocal enabledelayedexpansion

REM Switch to the project root (this .bat lives in chalo_chatbot/)
cd /d "%~dp0"

echo ==========================================================================
echo   ChaloSchools AI Secretary - One-Click Starter
echo ==========================================================================
echo.
echo   This will start 3 things in 3 separate windows:
echo.
echo     Window 1: LLM "brain"   (llama-server, port 8080)
echo     Window 2: Backend API   (FastAPI,       port 8000)
echo     Window 3: Chat UI       (your browser)
echo.
echo   Each window will tell you what it's doing. Read them in order.
echo.
echo   FIRST-TIME SETUP (only needed once):
echo     - Install Python 3.11+ from https://www.python.org/downloads/
echo       (TICK "Add python.exe to PATH" in the installer)
echo     - Download llama.cpp's Windows build from
echo       https://github.com/ggerganov/llama.cpp/releases
echo       Unzip to D:\llama.cpp\
echo     - Get the trained GGUF model file (about 4-5 GB) and put it at
echo       D:\models\qwen25coder_chaloschools_v27.gguf
echo       (See scripts\start_llm.bat for help with this step.)
echo.
echo ==========================================================================
echo.
echo   Press any key to start Window 1 (the LLM server)...
pause >nul

REM -- STEP 1: Start the LLM server in a new window --------------------------
if not exist "scripts\start_llm.bat" (
    echo   ERROR: scripts\start_llm.bat not found at:
    echo     %CD%\scripts\start_llm.bat
    echo.
    echo   Your download may be incomplete - re-download chalo_chatbot.zip.
    pause
    exit /b 1
)

start "1-LLM-Server-port-8080" "%~dp0scripts\start_llm.bat"

echo.
echo   Window 1 (LLM server) opened. It will take 10-30 seconds to load
echo   the model into RAM.
echo.
echo   WAIT until Window 1 says:
echo      "server listening on 127.0.0.1:8080"
echo.
echo   If Window 1 shows an ERROR (e.g. llama-server.exe or GGUF not found),
echo   fix that first - see the instructions in Window 1.
echo.
echo   Once Window 1 says "ready", come back here and press any key
echo   to start Window 2 (the backend).
echo.
pause >nul

REM -- STEP 2: Start the backend in a new window ----------------------------
if not exist "scripts\start_backend.bat" (
    echo   ERROR: scripts\start_backend.bat not found at:
    echo     %CD%\scripts\start_backend.bat
    pause
    exit /b 1
)

start "2-Backend-port-8000" "%~dp0scripts\start_backend.bat"

echo.
echo   Window 2 (backend) opened. On first run it will install Python deps
echo   (about 30 seconds), then start the server.
echo.
echo   WAIT until Window 2 says:
echo      "Uvicorn running on http://127.0.0.1:8000"
echo.
echo   If Window 2 shows an ERROR (e.g. Python not installed), fix that
echo   first - see the instructions in Window 2.
echo.
echo   Once Window 2 says "ready", come back here and press any key
echo   to open Window 3 (the chat UI).
echo.
pause >nul

REM -- STEP 3: Open the chat UI in the browser -----------------------------
if not exist "frontend\start_chat.bat" (
    echo   ERROR: frontend\start_chat.bat not found at:
    echo     %CD%\frontend\start_chat.bat
    pause
    exit /b 1
)

start "3-Chat-UI" "%~dp0frontend\start_chat.bat"

echo.
echo ==========================================================================
echo   All 3 services are now starting (or already running):
echo.
echo     Window 1: LLM server   (port 8080)  - generates the SQL
echo     Window 2: Backend API  (port 8000)  - runs the pipeline
echo     Window 3: Chat UI      (browser)    - where you type questions
echo.
echo   YOU CAN NOW USE THE AI SECRETARY.
echo   In your browser, type a question (e.g. "Who is the principal?")
echo   and press Send. The first answer may take 10-30 seconds (the LLM
echo   is warming up). Subsequent questions take 3-15 seconds.
echo.
echo --------------------------------------------------------------------------
echo   TO STOP EVERYTHING:
echo   1. Go to each of the 3 windows (LLM, Backend, this one)
echo   2. Click in the window
echo   3. Press Ctrl+C (or just close each window)
echo.
echo   TO START AGAIN LATER:
echo   Just double-click this START_HERE.bat again.
echo --------------------------------------------------------------------------
echo.
echo   Press any key to close THIS window. The other 3 windows stay open.
echo.
pause >nul
exit /b 0

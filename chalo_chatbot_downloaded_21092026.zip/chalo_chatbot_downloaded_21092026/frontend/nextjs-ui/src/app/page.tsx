"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Plus, Send, Settings, ChevronDown, ChevronRight, Copy, Check,
  Database, MessageSquare, AlertTriangle, CheckCircle2, XCircle,
  Clock, FileCode, ListTree, Sparkles, Menu, GraduationCap, Zap,
} from "lucide-react";

// ── Types ──────────────────────────────────────────────────────────────────

type Role = "user" | "assistant";
type Outcome = "ANSWER" | "NEEDS_BRANCH_SELECTION" | "NEEDS_DISAMBIGUATION" | "REFUSED" | "ERROR";

interface SemanticViolation {
  rule_id: string;
  severity: string;
  message: string;
  suggested_fix?: string;
  module?: string;
}

interface ChatResult {
  outcome: string;
  stage: string;
  sql?: string | null;
  sql_source?: string | null;
  bound_request?: Record<string, unknown> | null;
  columns?: string[];
  rows?: unknown[][];
  total_row_count?: number | null;
  message?: string | null;
  detail?: string | null;
  trace?: string[];
  semantic_violations?: SemanticViolation[];
  latency_ms?: number;
}

interface Message {
  id: string;
  role: Role;
  content: string;             // the user's question OR the assistant's natural-language summary
  result?: ChatResult;         // attached to assistant messages — the full pipeline result
  timestamp: number;
}

interface Conversation {
  id: string;
  title: string;
  messages: Message[];
  createdAt: number;
}

interface AppSettings {
  backendUrl: string;       // the FastAPI backend URL (e.g. http://localhost:8000)
  authToken: string;         // Bearer token (must match AI_SECRETARY_AUTH_TOKENS in backend .env)
  modelUrl: string;          // the llama.cpp LLM URL
  apiWrapperUrl: string;    // the school's ExecuteQuery ASMX endpoint
  targetDatabase: string;   // the DBPrefix (e.g. V3_TestDatabase)
  injectVocab: boolean;
  fastPaths: boolean;
  mode: "dry_run" | "api_wrapper";
  branchId: number | null;
  contextJson: Record<string, unknown> | null;
}

// ── Default sample context (matches the sample_context.json) ────────────────

const SAMPLE_CONTEXT = {
  UserMasterDetails: {
    Id: 116,
    UserName: "abav",
    StaffName: "ABAVITHRA NN",
    IsSuperUser: false,
    DBPrefix: "V3_TestDatabase",
    ShortName: "inspace",
    UserBranchDetails: [
      {
        ID: 1,
        Name: "CHALO INTERNATIONAL SCHOOL",
        IsPrimary: true,
        AcademicYears: [
          { Id: 6, Name: "2026-2027", IsCurrentYear: true, PreviousAcademicYearID: 5 },
        ],
        Classes: [
          { Name: "PreKG", DisplayOrder: 1 }, { Name: "LKG", DisplayOrder: 2 },
          { Name: "UKG", DisplayOrder: 3 }, { Name: "I", DisplayOrder: 4 },
          { Name: "II", DisplayOrder: 5 }, { Name: "III", DisplayOrder: 6 },
          { Name: "IV", DisplayOrder: 7 }, { Name: "V", DisplayOrder: 8 },
          { Name: "VI", DisplayOrder: 9 }, { Name: "VII", DisplayOrder: 10 },
          { Name: "VIII", DisplayOrder: 11 }, { Name: "IX", DisplayOrder: 12 },
          { Name: "X", DisplayOrder: 13 }, { Name: "XI", DisplayOrder: 14 },
          { Name: "XII", DisplayOrder: 15 },
        ],
        Sections: ["All", "BRAINY", "EXPERT", "FOUNDATION", "FOUNDATION 1", "FOUNDATION 2",
                   "INTELLIGENT", "New Admission", "TALENTED", "TALENTED 1"],
        Subjects: ["MATHS", "ENGLISH", "SCIENCE", "PHYSICS", "CHEMISTRY"],
        EnquiryStatuses: ["Initiated", "Updated", "Completed", "Dropped"],
        FeeHeads: ["Admission Fee", "Tuition Fees", "Transport Fee"],
        ExamTerms: ["Term I", "Term II", "EoY"],
        FeeTerms: ["Term 1", "Term 2", "Term 3"],
      },
    ],
  },
};

const DEFAULT_SETTINGS: AppSettings = {
  backendUrl: "http://localhost:8000",
  authToken: "dev-token-please-change-in-prod",
  modelUrl: "http://localhost:8080/v1/chat/completions",
  apiWrapperUrl: "https://chaloschools.in/testv4service/DigitalSecretary/AISecretary.asmx/ExecuteQuery",
  targetDatabase: "V3_TestDatabase",
  injectVocab: false,
  fastPaths: false,
  mode: "dry_run",
  branchId: 1,
  contextJson: SAMPLE_CONTEXT as Record<string, unknown>,
};

// ── Suggested questions (shown in the empty state) ──────────────────────────

const SUGGESTED_QUESTIONS = [
  { icon: "💰", text: "What is the fee outstanding for the current term?" },
  { icon: "👨‍🏫", text: "Who is the principal?" },
  { icon: "📚", text: "How many students are currently enrolled in Class 10?" },
  { icon: "📊", text: "Class-wise student count" },
  { icon: "🏆", text: "How many students passed maths in term 1?" },
  { icon: "🚌", text: "How many students use transport?" },
];

// ── Helpers ────────────────────────────────────────────────────────────────

function uid() {
  return Math.random().toString(36).slice(2, 11);
}

function loadConversations(): Conversation[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem("chalo_conversations");
    if (!raw) return [];
    return JSON.parse(raw);
  } catch { return []; }
}

function saveConversations(convs: Conversation[]) {
  if (typeof window === "undefined") return;
  try { localStorage.setItem("chalo_conversations", JSON.stringify(convs)); } catch {}
}

function loadSettings(): AppSettings {
  if (typeof window === "undefined") return DEFAULT_SETTINGS;
  try {
    const raw = localStorage.getItem("chalo_settings");
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch { return DEFAULT_SETTINGS; }
}

function saveSettings(s: AppSettings) {
  if (typeof window === "undefined") return;
  try { localStorage.setItem("chalo_settings", JSON.stringify(s)); } catch {}
}

// ── Outcome badge ───────────────────────────────────────────────────────────

function OutcomeBadge({ outcome }: { outcome: string }) {
  if (outcome === "ANSWER") {
    return <Badge variant="default" className="bg-emerald-600 hover:bg-emerald-700 gap-1"><CheckCircle2 className="w-3 h-3" /> Answered</Badge>;
  }
  if (outcome === "REFUSED") {
    return <Badge variant="destructive" className="gap-1"><XCircle className="w-3 h-3" /> Refused</Badge>;
  }
  if (outcome === "NEEDS_DISAMBIGUATION") {
    return <Badge variant="secondary" className="gap-1"><AlertTriangle className="w-3 h-3" /> Clarify</Badge>;
  }
  if (outcome === "NEEDS_BRANCH_SELECTION") {
    return <Badge variant="secondary" className="gap-1"><AlertTriangle className="w-3 h-3" /> Pick branch</Badge>;
  }
  return <Badge variant="destructive" className="gap-1"><XCircle className="w-3 h-3" /> Error</Badge>;
}

// ── Code block with copy ────────────────────────────────────────────────────

function CodeBlock({ code, language = "sql" }: { code: string; language?: string }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };
  return (
    <div className="relative group rounded-lg overflow-hidden border border-border bg-zinc-900">
      <div className="flex items-center justify-between px-3 py-1.5 bg-zinc-800 border-b border-zinc-700">
        <span className="text-xs font-mono text-zinc-400">{language}</span>
        <Button variant="ghost" size="sm" onClick={copy} className="h-7 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-700">
          {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
          <span className="text-xs ml-1">{copied ? "Copied" : "Copy"}</span>
        </Button>
      </div>
      <pre className="p-3 text-xs font-mono text-zinc-100 overflow-x-auto max-h-80 leading-relaxed">
        <code>{code}</code>
      </pre>
    </div>
  );
}

// ── Result panel (the rich display of a chat result) ────────────────────────

function ResultPanel({ result }: { result: ChatResult }) {
  const [showTrace, setShowTrace] = useState(false);
  const [showDetail, setShowDetail] = useState(false);
  const highViolations = (result.semantic_violations || []).filter(v => v.severity === "HIGH");
  const medViolations = (result.semantic_violations || []).filter(v => v.severity !== "HIGH");

  return (
    <div className="mt-3 space-y-3">
      {/* Status row */}
      <div className="flex items-center gap-2 flex-wrap">
        <OutcomeBadge outcome={result.outcome} />
        {result.sql_source && (
          <Badge variant="outline" className="text-xs">{result.sql_source}</Badge>
        )}
        {result.latency_ms != null && (
          <Badge variant="outline" className="text-xs gap-1">
            <Clock className="w-3 h-3" /> {result.latency_ms < 1000 ? `${Math.round(result.latency_ms)}ms` : `${(result.latency_ms/1000).toFixed(1)}s`}
          </Badge>
        )}
        {(result.semantic_violations || []).length > 0 && (
          <Badge variant={highViolations.length > 0 ? "destructive" : "secondary"} className="text-xs gap-1">
            <AlertTriangle className="w-3 h-3" />
            {result.semantic_violations!.length} violation{result.semantic_violations!.length !== 1 ? "s" : ""}
          </Badge>
        )}
        {result.total_row_count != null && result.total_row_count > 0 && (
          <Badge variant="outline" className="text-xs gap-1">
            <Database className="w-3 h-3" /> {result.total_row_count} row{result.total_row_count !== 1 ? "s" : ""}
          </Badge>
        )}
      </div>

      {/* Refusal / error message */}
      {result.message && result.outcome !== "ANSWER" && (
        <div className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">
          <div className="flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-medium">{result.message}</p>
              {result.detail && (
                <Collapsible open={showDetail} onOpenChange={setShowDetail}>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" size="sm" className="h-6 mt-1 text-xs text-amber-700">
                      {showDetail ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />} Details
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <pre className="mt-1 text-xs font-mono whitespace-pre-wrap text-amber-800 max-h-40 overflow-y-auto">{result.detail}</pre>
                  </CollapsibleContent>
                </Collapsible>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Generated SQL */}
      {result.sql && (
        <div>
          <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground mb-1.5">
            <FileCode className="w-3.5 h-3.5" /> Generated SQL
          </div>
          <CodeBlock code={result.sql} />
        </div>
      )}

      {/* Bound request (dry_run preview) */}
      {result.bound_request && (
        <Collapsible>
          <CollapsibleTrigger asChild>
            <Button variant="ghost" size="sm" className="h-7 text-xs text-muted-foreground">
              <ListTree className="w-3.5 h-3.5 mr-1" /> Bound request
            </Button>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <CodeBlock code={JSON.stringify(result.bound_request, null, 2)} language="json" />
          </CollapsibleContent>
        </Collapsible>
      )}

      {/* Result rows */}
      {result.rows && result.rows.length > 0 && result.columns && result.columns.length > 0 && (
        <div>
          <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground mb-1.5">
            <Database className="w-3.5 h-3.5" /> Results ({result.rows.length} row{result.rows.length !== 1 ? "s" : ""})
          </div>
          <div className="rounded-lg border border-border overflow-hidden max-h-64 overflow-y-auto">
            <table className="w-full text-xs">
              <thead className="bg-muted sticky top-0">
                <tr>
                  {result.columns.map((c, i) => (
                    <th key={i} className="text-left p-2 font-medium border-b border-border">{c}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {result.rows.slice(0, 50).map((row, i) => (
                  <tr key={i} className={i % 2 ? "bg-muted/30" : ""}>
                    {Array.isArray(row) && row.map((cell, j) => (
                      <td key={j} className="p-2 border-b border-border/50 align-top">{String(cell ?? "")}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
            {result.rows.length > 50 && (
              <div className="p-2 text-xs text-muted-foreground text-center bg-muted/30">
                Showing first 50 of {result.rows.length} rows
              </div>
            )}
          </div>
        </div>
      )}

      {/* Semantic violations */}
      {(result.semantic_violations || []).length > 0 && (
        <div>
          <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground mb-1.5">
            <AlertTriangle className="w-3.5 h-3.5" /> Semantic violations ({(result.semantic_violations || []).length})
          </div>
          <div className="space-y-1.5">
            {(result.semantic_violations || []).map((v, i) => (
              <div key={i} className={`rounded-md border p-2 text-xs ${
                v.severity === "HIGH" ? "border-red-200 bg-red-50" : "border-amber-200 bg-amber-50"
              }`}>
                <div className="flex items-center gap-2 mb-1">
                  <Badge variant={v.severity === "HIGH" ? "destructive" : "secondary"} className="text-[10px]">{v.severity}</Badge>
                  <span className="font-mono font-medium">{v.rule_id}</span>
                  {v.module && <span className="text-muted-foreground">· {v.module}</span>}
                </div>
                <p className="text-foreground">{v.message}</p>
                {v.suggested_fix && (
                  <p className="mt-1 text-emerald-700"><span className="font-medium">Fix:</span> {v.suggested_fix}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Trace */}
      {result.trace && result.trace.length > 0 && (
        <Collapsible open={showTrace} onOpenChange={setShowTrace}>
          <CollapsibleTrigger asChild>
            <Button variant="ghost" size="sm" className="h-7 text-xs text-muted-foreground">
              {showTrace ? <ChevronDown className="w-3.5 h-3.5 mr-1" /> : <ChevronRight className="w-3.5 h-3.5 mr-1" />}
              Pipeline trace ({result.trace.length} step{result.trace.length !== 1 ? "s" : ""})
            </Button>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <div className="rounded-lg border border-border bg-muted/30 p-2 font-mono text-xs space-y-0.5 max-h-48 overflow-y-auto">
              {result.trace.map((t, i) => (
                <div key={i} className="text-muted-foreground">
                  <span className="text-foreground/40">{i + 1}.</span> {t}
                </div>
              ))}
            </div>
          </CollapsibleContent>
        </Collapsible>
      )}
    </div>
  );
}

// ── Single message bubble ───────────────────────────────────────────────────

function MessageBubble({ message }: { message: Message }) {
  const isUser = message.role === "user";
  return (
    <div className={isUser ? "flex justify-end px-4 md:px-6" : "flex justify-start px-4 md:px-6"}>
      <div className={isUser ? "max-w-3xl w-full md:w-auto" : "max-w-3xl w-full"}>
        {isUser ? (
          <div className="bg-primary text-primary-foreground rounded-2xl rounded-br-md px-4 py-2.5 text-sm shadow-sm">
            {message.content}
          </div>
        ) : (
          <div className="space-y-1">
            {/* Assistant avatar row */}
            <div className="flex items-center gap-2 mb-1">
              <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center">
                <Sparkles className="w-3.5 h-3.5 text-primary" />
              </div>
              <span className="text-xs font-medium text-muted-foreground">AI Secretary</span>
            </div>
            {/* Summary line */}
            <div className="text-sm text-foreground">
              {message.content || "Here's what I found:"}
            </div>
            {/* Rich result panel */}
            {message.result && <ResultPanel result={message.result} />}
          </div>
        )}
      </div>
    </div>
  );
}

// ── Sidebar (conversation list) ──────────────────────────────────────────────

function Sidebar({
  conversations,
  currentId,
  onSelect,
  onNew,
  onDelete,
}: {
  conversations: Conversation[];
  currentId: string | null;
  onSelect: (id: string) => void;
  onNew: () => void;
  onDelete: (id: string) => void;
}) {
  return (
    <div className="flex flex-col h-full">
      {/* New chat button */}
      <div className="p-3">
        <Button onClick={onNew} className="w-full justify-start gap-2 bg-primary hover:bg-primary/90">
          <Plus className="w-4 h-4" /> New chat
        </Button>
      </div>
      <Separator />
      {/* Conversation list */}
      <ScrollArea className="flex-1 px-2">
        <div className="space-y-0.5 py-2">
          {conversations.length === 0 ? (
            <div className="text-center text-xs text-muted-foreground py-8 px-4">
              No conversations yet. Start a new chat to begin.
            </div>
          ) : (
            conversations.map((c) => (
              <div
                key={c.id}
                className={`group flex items-center gap-2 rounded-lg px-2.5 py-2 cursor-pointer transition-colors ${
                  c.id === currentId ? "bg-sidebar-accent text-sidebar-accent-foreground" : "hover:bg-sidebar-accent/50"
                }`}
                onClick={() => onSelect(c.id)}
              >
                <MessageSquare className="w-3.5 h-3.5 flex-shrink-0 text-muted-foreground" />
                <span className="flex-1 truncate text-sm">{c.title || "New conversation"}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100"
                  onClick={(e) => { e.stopPropagation(); onDelete(c.id); }}
                >
                  <XCircle className="w-3 h-3" />
                </Button>
              </div>
            ))
          )}
        </div>
      </ScrollArea>
      <Separator />
      {/* Footer */}
      <div className="p-3 text-xs text-muted-foreground">
        <div className="flex items-center gap-1.5">
          <GraduationCap className="w-3.5 h-3.5" />
          <span>ChaloSchools AI Secretary</span>
        </div>
        <p className="mt-1 text-[11px]">v1.0 · 32 semantic rules</p>
      </div>
    </div>
  );
}

// ── Settings panel ───────────────────────────────────────────────────────────

function SettingsPanel({
  settings, onChange,
}: {
  settings: AppSettings;
  onChange: (s: AppSettings) => void;
}) {
  const branches = (settings.contextJson as any)?.UserMasterDetails?.UserBranchDetails || [];
  return (
    <div className="space-y-4 p-1">
      <div>
        <Label className="text-xs">Backend URL (FastAPI, port 8000)</Label>
        <Input
          value={settings.backendUrl}
          onChange={(e) => onChange({ ...settings, backendUrl: e.target.value })}
          className="mt-1 text-sm font-mono"
          placeholder="http://localhost:8000"
        />
      </div>
      <div>
        <Label className="text-xs">Auth token (Bearer)</Label>
        <Input
          type="password"
          value={settings.authToken}
          onChange={(e) => onChange({ ...settings, authToken: e.target.value })}
          className="mt-1 text-sm font-mono"
          placeholder="dev-token-please-change-in-prod"
        />
        <p className="text-[11px] text-muted-foreground mt-1">
          Must match <code className="text-foreground/80">AI_SECRETARY_AUTH_TOKENS</code> in your backend <code className="text-foreground/80">.env</code>.
        </p>
      </div>
      <div>
        <Label className="text-xs">llama.cpp endpoint (port 8080)</Label>
        <Input
          value={settings.modelUrl}
          onChange={(e) => onChange({ ...settings, modelUrl: e.target.value })}
          className="mt-1 text-sm font-mono"
          placeholder="http://localhost:8080/v1/chat/completions"
        />
      </div>
      <div>
        <Label className="text-xs">Branch</Label>
        <Select
          value={String(settings.branchId ?? "")}
          onValueChange={(v) => onChange({ ...settings, branchId: Number(v) })}
        >
          <SelectTrigger className="mt-1"><SelectValue placeholder="Select branch" /></SelectTrigger>
          <SelectContent>
            {branches.map((b: any) => (
              <SelectItem key={b.ID} value={String(b.ID)}>
                {b.Name}{b.IsPrimary ? " (primary)" : ""}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label className="text-xs">Execution mode</Label>
        <Select
          value={settings.mode}
          onValueChange={(v) => onChange({ ...settings, mode: v as "dry_run" | "api_wrapper" })}
        >
          <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="dry_run">Dry run (preview SQL, no execution)</SelectItem>
            <SelectItem value="api_wrapper">API wrapper (execute via ExecuteQuery)</SelectItem>
          </SelectContent>
        </Select>
      </div>
      {settings.mode === "api_wrapper" && (
        <>
          <div>
            <Label className="text-xs">ExecuteQuery API URL</Label>
            <Input
              value={settings.apiWrapperUrl}
              onChange={(e) => onChange({ ...settings, apiWrapperUrl: e.target.value })}
              className="mt-1 text-sm font-mono"
            />
          </div>
          <div>
            <Label className="text-xs">Target database (DBPrefix)</Label>
            <Input
              value={settings.targetDatabase}
              onChange={(e) => onChange({ ...settings, targetDatabase: e.target.value })}
              className="mt-1 text-sm font-mono"
              placeholder="V3_TestDatabase"
            />
            <p className="text-[11px] text-muted-foreground mt-1">
              The backend looks up the ExecuteQuery API key server-side
              (see <code className="text-foreground/80">AI_SECRETARY_TENANT_KEYS</code> in your <code className="text-foreground/80">.env</code>) —
              you don&apos;t enter it here.
            </p>
          </div>
        </>
      )}
      <Separator />
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <Label className="text-xs">Inject vocab (FULL mode)</Label>
            <p className="text-[11px] text-muted-foreground">Requires v28 retrain</p>
          </div>
          <Switch
            checked={settings.injectVocab}
            onCheckedChange={(v) => onChange({ ...settings, injectVocab: v })}
          />
        </div>
        <div className="flex items-center justify-between">
          <div>
            <Label className="text-xs">Fast-paths (cache)</Label>
            <p className="text-[11px] text-muted-foreground">Off until labels cleaned</p>
          </div>
          <Switch
            checked={settings.fastPaths}
            onCheckedChange={(v) => onChange({ ...settings, fastPaths: v })}
          />
        </div>
      </div>
    </div>
  );
}

// ── Main page ───────────────────────────────────────────────────────────────

export default function Home() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentId, setCurrentId] = useState<string | null>(null);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [showSettings, setShowSettings] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Load on mount
  useEffect(() => {
    setConversations(loadConversations());
    setSettings(loadSettings());
  }, []);

  // Persist settings
  useEffect(() => { saveSettings(settings); }, [settings]);
  useEffect(() => { saveConversations(conversations); }, [conversations]);

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [conversations, currentId, loading]);

  const current = conversations.find(c => c.id === currentId) || null;

  const newChat = useCallback(() => {
    const conv: Conversation = { id: uid(), title: "New conversation", messages: [], createdAt: Date.now() };
    setConversations([conv, ...conversations]);
    setCurrentId(conv.id);
    setSidebarOpen(false);
  }, [conversations]);

  const deleteChat = useCallback((id: string) => {
    setConversations(conversations.filter(c => c.id !== id));
    if (currentId === id) setCurrentId(null);
  }, [conversations, currentId]);

  const sendQuestion = useCallback(async (question: string) => {
    if (!question.trim() || loading) return;
    if (!settings.contextJson) {
      setError("No Context JSON configured. Set one in Settings.");
      return;
    }
    // Ensure a conversation exists
    let conv = current;
    if (!conv) {
      conv = { id: uid(), title: question.slice(0, 40), messages: [], createdAt: Date.now() };
      setConversations([conv, ...conversations]);
      setCurrentId(conv.id);
    }
    const userMsg: Message = { id: uid(), role: "user", content: question, timestamp: Date.now() };
    const placeholder: Message = { id: uid(), role: "assistant", content: "", timestamp: Date.now() };
    // Update the conversation with the user message + a placeholder assistant message
    const convId = conv.id;
    setConversations(prev => prev.map(c =>
      c.id === convId ? { ...c, title: c.messages.length === 0 ? question.slice(0, 40) : c.title, messages: [...c.messages, userMsg, placeholder] } : c
    ));
    setInput("");
    setLoading(true);
    setError(null);
    try {
      // Call the FastAPI backend directly with Bearer auth.
      // The backend looks up the tenant ExecuteQuery API key server-side
      // (V4 fix) — we never send it from the browser.
      const res = await fetch(`${settings.backendUrl}/api/chat`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${settings.authToken}`,
        },
        body: JSON.stringify({
          question,
          context_json: settings.contextJson,
          branch_id: settings.branchId,
          model_url: settings.modelUrl,
          api_wrapper_url: settings.apiWrapperUrl,
          target_database: settings.targetDatabase,
          inject_vocab: settings.injectVocab,
          fast_paths: settings.fastPaths,
          mode: settings.mode,
        }),
      });
      if (!res.ok) {
        const errText = await res.text().catch(() => "");
        throw new Error(`Backend returned ${res.status}${errText ? ": " + errText.slice(0, 200) : ""}`);
      }
      const result: ChatResult = await res.json();
      // Build the assistant's natural-language summary
      let summary = "";
      if (result.outcome === "ANSWER") {
        summary = result.rows && result.rows.length > 0
          ? `Here are the results — ${result.rows.length} row${result.rows.length !== 1 ? "s" : ""}.`
          : "The query executed successfully but returned no rows.";
      } else if (result.outcome === "REFUSED") {
        summary = result.message || "I couldn't answer that.";
      } else if (result.outcome === "NEEDS_DISAMBIGUATION") {
        summary = result.message || "I need clarification.";
      } else if (result.outcome === "ERROR") {
        summary = "Something went wrong.";
      } else {
        summary = result.message || "";
      }
      // Replace the placeholder with the real result
      setConversations(prev => prev.map(c =>
        c.id === convId ? {
          ...c,
          messages: c.messages.map(m =>
            m.id === placeholder.id ? { ...m, content: summary, result } : m
          ),
        } : c
      ));
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Unknown error";
      setError(`Failed to reach the backend. Is the FastAPI server running on port 8000? (${msg})`);
      setConversations(prev => prev.map(c =>
        c.id === convId ? {
          ...c,
          messages: c.messages.map(m =>
            m.id === placeholder.id ? { ...m, content: "I couldn't reach the backend.", result: { outcome: "ERROR", stage: "execute", message: msg, trace: [], semantic_violations: [] } } : m
          ),
        } : c
      ));
    } finally {
      setLoading(false);
    }
  }, [loading, settings, current, conversations]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendQuestion(input);
    }
  };

  return (
    <div className="h-screen flex bg-background overflow-hidden">
      {/* Desktop sidebar */}
      <aside className="hidden md:flex w-64 flex-shrink-0 flex-col border-r border-sidebar-border bg-sidebar">
        <Sidebar
          conversations={conversations}
          currentId={currentId}
          onSelect={(id) => { setCurrentId(id); }}
          onNew={newChat}
          onDelete={deleteChat}
        />
      </aside>

      {/* Mobile sidebar (Sheet) */}
      <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
        <SheetContent side="left" className="w-72 p-0 bg-sidebar">
          <Sidebar
            conversations={conversations}
            currentId={currentId}
            onSelect={(id) => { setCurrentId(id); setSidebarOpen(false); }}
            onNew={newChat}
            onDelete={deleteChat}
          />
        </SheetContent>
      </Sheet>

      {/* Main chat area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="flex items-center justify-between px-4 py-2.5 border-b border-border bg-background/80 backdrop-blur-sm flex-shrink-0">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" className="md:hidden" onClick={() => setSidebarOpen(true)}>
              <Menu className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center">
                <GraduationCap className="w-4 h-4 text-primary" />
              </div>
              <div>
                <h1 className="text-sm font-semibold leading-none">ChaloSchools AI Secretary</h1>
                <p className="text-[11px] text-muted-foreground mt-0.5">
                  {settings.mode === "dry_run" ? "Dry run" : "API wrapper"} · Branch {settings.branchId ?? "—"}
                  {settings.injectVocab && " · vocab on"}
                </p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="sm" onClick={() => setShowSettings(s => !s)} className={showSettings ? "bg-accent" : ""}>
                    <Settings className="w-4 h-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Settings</TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </header>

        {/* Settings drawer (collapsible) */}
        {showSettings && (
          <div className="border-b border-border bg-muted/30 p-4 max-h-[60vh] overflow-y-auto">
            <SettingsPanel settings={settings} onChange={setSettings} />
          </div>
        )}

        {/* Error banner */}
        {error && (
          <div className="mx-4 mt-3 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-800">
            {error}
          </div>
        )}

        {/* Messages */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto">
          {(!current || current.messages.length === 0) ? (
            <div className="h-full flex flex-col items-center justify-center px-4 py-8">
              <div className="max-w-2xl w-full">
                <div className="flex flex-col items-center text-center mb-8">
                  <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
                    <Sparkles className="w-7 h-7 text-primary" />
                  </div>
                  <h2 className="text-2xl font-semibold mb-1.5">Ask about your school data</h2>
                  <p className="text-muted-foreground text-sm max-w-md">
                    I translate your questions into T-SQL queries against the ChaloSchools database, with branch-scoped access and 32 semantic rules that catch wrong answers.
                  </p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {SUGGESTED_QUESTIONS.map((q, i) => (
                    <button
                      key={i}
                      onClick={() => sendQuestion(q.text)}
                      className="flex items-start gap-3 text-left p-3 rounded-xl border border-border bg-card hover:bg-accent transition-colors text-sm"
                    >
                      <span className="text-lg flex-shrink-0">{q.icon}</span>
                      <span className="text-foreground">{q.text}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="py-6 space-y-6">
              {current.messages.map((m) => (
                <MessageBubble key={m.id} message={m} />
              ))}
              {loading && (
                <div className="px-4 md:px-6 flex items-center gap-2 text-sm text-muted-foreground">
                  <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                  <div className="w-2 h-2 rounded-full bg-primary animate-pulse" style={{ animationDelay: "150ms" }} />
                  <div className="w-2 h-2 rounded-full bg-primary animate-pulse" style={{ animationDelay: "300ms" }} />
                  <span className="ml-2">Thinking…</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Composer (sticky bottom) */}
        <div className="border-t border-border bg-background px-4 py-3 flex-shrink-0">
          <div className="max-w-3xl mx-auto">
            <div className="relative flex items-end gap-2 rounded-2xl border border-border bg-card focus-within:ring-2 focus-within:ring-ring/40 transition-shadow shadow-sm">
              <Textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask about fees, students, staff, exams…"
                className="flex-1 resize-none border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 min-h-[44px] max-h-32 text-sm py-3 px-4"
                rows={1}
                disabled={loading}
              />
              <Button
                size="icon"
                className="m-1.5 rounded-lg flex-shrink-0"
                onClick={() => sendQuestion(input)}
                disabled={!input.trim() || loading}
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-[11px] text-muted-foreground text-center mt-2">
              Press Enter to send · Shift+Enter for a new line · AI can make mistakes. Verify critical data.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

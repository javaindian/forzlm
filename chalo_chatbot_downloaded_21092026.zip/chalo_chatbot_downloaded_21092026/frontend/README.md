# Frontend — ChaloSchools AI Secretary

This folder contains the **user-facing frontend** for the AI Secretary.
There are TWO options — pick the one that fits your team.

---

## Option A — Standalone HTML UI (recommended, zero-install)

| File | What it is |
|------|------------|
| `chat.html` | The main chat UI. **One self-contained HTML file** — HTML + CSS + JavaScript, no build step, no npm install. Just open it in a browser. |
| `audit.html` | The audit-trail viewer. Also self-contained. Shows past questions, outcomes, latency, violations, with dashboard stats. **New (2026-08-31): Export XLSX (green) + Reset (red) buttons** for bulk export and clearing. |
| `start_chat.bat` | Windows double-click launcher — opens `chat.html` in your default browser. |

### How to run

1. Start the LLM server (port 8080) — see `../scripts/start_llm.bat`
2. Start the backend (port 8000) — see `../scripts/start_backend.bat`
3. Double-click **`start_chat.bat`** (or just open `chat.html` in any browser)

That's it. No npm, no bun, no Node.js, no build step. The HTML file talks to the
backend at `http://localhost:8000` directly via `fetch()`.

### Settings (inside the chat UI)

Click the **⚙ Settings** button in the top-right of the chat page to set:
- Backend URL (default `http://localhost:8000`; leave EMPTY when served by nginx on the server — same origin)
- Auth token (must match `AI_SECRETARY_AUTH_TOKENS` in your backend `.env`)
- Branch ID
- Execution mode (`api_wrapper` = execute against DB, `dry_run` = preview SQL only)
- Context JSON (load it from a file)
- **LLM Model** — Chalo Language Model 1.0 (current); CLM 2.0 / 3.0 are listed but disabled until their GGUFs are trained
- **Show thinking process** — progressive pipeline-stage text under the loading dots while a query runs (default off)

Settings are saved to `localStorage`, so they persist across browser sessions (implemented 2026-09-04 — previously documented but not wired up).

### Why a single HTML file?

- The mobile app is the **production** frontend. This HTML UI is a **dev/test tool**.
- A single HTML file is trivially easy to share, email, or open on any machine.
- No dependency hell, no `npm install`, no version conflicts.
- If you want the React/Next.js version instead, see Option B below.

---

## Option B — Next.js React UI (full app, requires build)

The full React/Next.js version lives in `nextjs-ui/` (if included in this download).
It uses the same backend API and gives you:

- shadcn/ui component library (50+ components)
- Dark/light theme with `next-themes`
- Responsive mobile-first design
- Toast notifications, loading skeletons, framer-motion transitions
- The same chat + audit features, but built as a real React app

### How to run (Option B)

```bash
cd frontend/nextjs-ui
npm install      # install dependencies
npm run dev      # starts on http://localhost:3000
```

Open `http://localhost:3000` in your browser.

> **Note:** Option B requires Node.js 18+ installed. Option A does not.
> For quick testing or sharing with non-developers, use Option A.

---

## Folder layout

```
frontend/
├── README.md              ← this file
├── chat.html              ← Option A: standalone chat UI (open in browser)
├── audit.html             ← Option A: standalone audit-trail viewer
├── start_chat.bat         ← Option A: Windows launcher for chat.html
└── nextjs-ui/             ← Option B: full Next.js React app (if included)
    ├── src/app/page.tsx   ← the main chat page (React)
    ├── src/components/ui/  ← shadcn/ui components
    ├── package.json
    └── ...
```

---

## Which one should I use?

| Use case | Choose |
|----------|--------|
| Quick local testing of the backend | **Option A** (chat.html) |
| Sharing with a non-developer | **Option A** (chat.html) |
| Demoing on a clean machine | **Option A** (chat.html) |
| Building a real web product | **Option B** (Next.js) |
| Customizing the UI heavily | **Option B** (Next.js) |
| Production frontend | **The mobile app** (neither — see `docs/API_CONTRACT.md`) |

---

## Troubleshooting

**"Backend offline" badge in the chat UI**
→ The backend isn't running. Start it with `../scripts/start_backend.bat`.

**401 Unauthorized when sending a question**
→ Your auth token in Settings doesn't match `AI_SECRETARY_AUTH_TOKENS` in the backend `.env`.

**Blank page when opening chat.html**
→ Open the browser console (F12). Most likely the backend URL in Settings is wrong, or CORS is blocking the request. The backend has CORS enabled by default — check `backend/.env`.

**Audit page shows no rows**
→ Run some questions in chat first. The audit page reads from the backend's `/api/audit` endpoint, which only has data after you've asked questions.

**Export XLSX button does nothing**
→ Check your internet connection — the button uses SheetJS loaded from a CDN. If you're offline, it falls back to CSV automatically (check the browser console for the warning).

**Reset button asks for confirmation but nothing happens**
→ You need the admin token (not the user token) — set it in the audit.html header bar. The `DELETE /api/audit` endpoint requires `AI_SECRETARY_ADMIN_TOKENS`, not `AI_SECRETARY_AUTH_TOKENS`.

---

## UI improvements — IMPLEMENTED (2026-09-04, CODE-UPDATE-10)

The 4 items requested on 2026-09-03 are now implemented in **`chat.html`** + **`backend/main.py`** (backend v1.3.0):

| # | Item | Status | How it works now |
|---|---|---|---|
| 1 | **AI disclaimer** | ✅ Done | Subtle muted footer note below the input box: *"AI can make mistakes. Please verify important information."* (no modal) |
| 2 | **LLM model selector** | ✅ Done | Settings → "LLM Model" dropdown: CLM 1.0 (enabled, default), CLM 2.0 + CLM 3.0 (disabled, "coming soon"). CLM 1.0 maps to the LLM URL setting (`model_url` in the request body). When the v28/v29 GGUFs are trained, enable the options + point them at their own URLs/ports. |
| 3 | **Show thinking process** | ✅ Done (frontend; SSE later) | Settings toggle (default off). When on: progressive stage text ("Understanding your question..." → "Generating SQL..." → "Validating against 54 rules..." → "Querying the database...") under the loading dots. Stages are shown on a timer; TRUE per-stage streaming still needs SSE in the backend (kept as a future enhancement — the trace array arrives with the final response as before). |
| 4 | **Standard reply for unanswerable questions** | ✅ Done (backend) | `backend/main.py` v1.3.0: when outcome ∈ {REFUSED, ERROR, NEEDS_DISAMBIGUATION}, the user-facing `message` becomes the standard reply; the original message moves into `detail` (debugging unaffected). Config priority: `AI_SECRETARY_FALLBACK_MESSAGE` env var > `"fallback_message"` key in `feature_overrides.json` > built-in default. Empty env var disables. Response gains a `fallback_used` boolean. |

Also shipped with this update: version footer 1.1.0/32-rules → **v1.3.0 · 54 rules** (matches the backend), all UI text updated 32 → 54 rules, and settings now genuinely persist to localStorage.

### Remaining future enhancement

- **True stage streaming (SSE)** for item 3 — `backend/main.py` + `pipeline/orchestrator.py` would need to emit stage events (`StreamingResponse`); the frontend's timed stages cover the UX in the meantime.

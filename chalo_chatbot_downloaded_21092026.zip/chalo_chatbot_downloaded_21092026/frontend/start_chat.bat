@echo off
REM ==========================================================================
REM  ChaloSchools AI Secretary - Chat UI Launcher
REM  Double-click this file to open the chat UI in your browser.
REM ==========================================================================

setlocal enabledelayedexpansion

cd /d "%~dp0"

echo ==========================================================================
echo   ChaloSchools AI Secretary - Chat UI Launcher
echo ==========================================================================
echo.

REM -- Check that chat.html exists in this folder ---------------------------
if not exist "chat.html" (
    echo   ERROR: chat.html not found in this folder:
    echo     %CD%\chat.html
    echo.
    echo   Your download may be incomplete - re-download chalo_chatbot.zip.
    echo.
    pause
    exit /b 1
)

REM -- Quick health check: is the backend up on port 8000? --------------------
echo   Checking if the backend is running on http://127.0.0.1:8000...

powershell -NoProfile -Command "try { (Invoke-WebRequest -Uri 'http://127.0.0.1:8000/api/health' -TimeoutSec 2 -UseBasicParsing).StatusCode } catch { exit 1 }" >nul 2>nul

if %errorlevel%==0 (
    echo     Backend is up. Good.
    goto :open
)

echo.
echo   WARNING: The backend is NOT running on port 8000.
echo.
echo   The chat UI will still open, but you will see "Backend offline".
echo   To actually ask questions, you need to:
echo.
echo     1. Start the LLM server  - double-click scripts\start_llm.bat
echo     2. Start the backend     - double-click scripts\start_backend.bat
echo     3. Wait until the backend window says "Uvicorn running"
echo     4. Refresh the chat page in your browser.
echo.

:open
echo.
echo ==========================================================================
echo   Opening the chat UI in your browser...
echo.
echo   WHAT TO EXPECT:
echo     Your browser opens to the ChaloSchools AI Secretary chat page.
echo     Type a question (e.g. "Who is the principal?") and press Send.
echo.
echo   IF YOU SEE "Backend offline" in the chat page:
echo     Click the gear (Settings) button in the top-right of the chat page.
echo     Make sure:
echo       - Backend URL = http://localhost:8000
echo       - Auth token = dev-token-please-change-in-prod
echo     Then refresh the page.
echo ==========================================================================
echo.

REM Open chat.html in the default browser
start "" "%CD%\chat.html"

REM Give the browser a moment to open, then this window can close
timeout /t 3 /nobreak >nul
endlocal

# Conversational Handling — Casual To-and-Fro UX Design

The project owner raised a real UX point: "people type in conversational way casually. We need to handle that — to and fro the UI." This doc designs how the chatbot handles casual, multi-turn, follow-up, and ambiguous questions. It's a design doc — implementation is v1.1+.

---

## 1. The problem

The current backend is **stateless** — each `/api/chat` call is independent. The model sees only the current question, not the conversation history. This works for one-shot questions ("What is the fee outstanding for the current term?") but fails for casual conversational patterns:

| User says | The model needs | Current behavior |
|---|---|---|
| "who is the principal?" → "what about the besant nagar branch?" | The follow-up means "what is the principal of the Besant Nagar branch?" | Fails — the follow-up has no branch context; the model doesn't know it's about the principal |
| "show me defaulters" → "top 10 only" | The follow-up means "show me the top 10 defaulters" | Fails — "top 10 only" is meaningless on its own |
| "how many students in class 10?" → "and class 9?" | The follow-up means "how many students in class 9?" | Fails — "and class 9?" isn't a complete question |
| "fee outstanding for current term" → "now show term-wise" | The follow-up means "show term-wise fee outstanding" | Fails — "now show term-wise" has no anchor |
| "who teaches maths in 8A?" → "wait, I meant 8B" | The follow-up corrects the previous question | Fails — the system can't tell it's a correction |

People talk like this. The chatbot needs to handle it.

---

## 2. The design: conversation context injection

The fix is **conversation-context injection** — the backend (or the mobile app) builds a short conversation history and includes it in the request so the model can resolve follow-ups.

### Two implementation paths

**Path A — client-side (mobile app builds the history):** the mobile app keeps the last N turns and sends a rewritten, self-contained question to the backend. The backend stays stateless. This is simpler and keeps the backend stateless.

**Path B — server-side (backend maintains the conversation):** the backend keeps a conversation ID + history, and the model gets the full history in its prompt. This is more powerful but adds state (a conversation store).

**Recommendation: Path A for v1.1.** The mobile app already maintains the chat history locally (per `API_CONTRACT.md`). It can do a lightweight rewrite step before sending. Path B is v2.0 (cross-device sync).

---

## 3. Path A design — the "conversation resolver" on the client

The mobile app runs a small "conversation resolver" step before sending the question to the backend. The resolver takes the new question + the recent conversation history and produces a self-contained question.

### The resolver (a small LLM call, or rule-based)

**Option 1 — rule-based (fast, no extra LLM call):** pattern-match common follow-up shapes and rewrite them:
- "what about X?" → replace the subject of the last question with X.
- "top N only" / "top N" → add `TOP N` to the last question.
- "and class N?" / "and section N?" → replace the class/section in the last question.
- "wait, I meant X" / "no, I meant X" → replace the relevant entity in the last question.
- "now show X" / "now by X" → add an X grouping to the last question.

**Option 2 — LLM-based (more flexible, one extra small-LLM call):** send the new question + the last 3 turns to a small, fast model (or the same Qwen model with a different prompt) and ask it to produce a self-contained question:
```
Conversation so far:
User: who is the principal?
Assistant: ABAVITHRA NN
User: what about the besant nagar branch?

Rewrite the last user question as a self-contained question that would make
sense without the conversation history. Output only the rewritten question.
→ "Who is the principal of the Besant Nagar branch?"
```

**Recommendation: Option 1 (rule-based) for v1.1** — it handles 80% of cases with zero latency cost. Option 2 is v1.2 for the long tail.

### The rewrite rules (concrete examples)

| Pattern | Last question | New input | Rewritten question |
|---|---|---|---|
| `what about <entity>?` | "who is the principal?" | "what about besant nagar?" | "who is the principal of the Besant Nagar branch?" |
| `and <class>?` | "how many students in class 10?" | "and class 9?" | "how many students in class 9?" |
| `top <N>` / `top <N> only` | "show me defaulters" | "top 10 only" | "show me the top 10 defaulters" |
| `now show <group>` / `now by <group>` | "fee outstanding for current term" | "now show term-wise" | "show term-wise fee outstanding for the current term" |
| `wait, I meant <entity>` / `no, I meant <entity>` | "who teaches maths in 8A?" | "wait, I meant 8B" | "who teaches maths in 8B?" |
| `and <section>?` | "who teaches maths in 8A?" | "and 8B?" | "who teaches maths in 8B?" |
| `how about <entity>?` | "total fees collected today" | "how about this month?" | "total fees collected this month" |
| `compare <entity> vs <entity>` | "fee outstanding for class 10" | "compare vs class 9" | "compare fee outstanding for class 10 vs class 9" |
| `as of <date>` | "fee outstanding" | "as of last month" | "fee outstanding as of last month" |
| `<entity>-wise` / `by <entity>` | "fee outstanding" | "class-wise" | "class-wise fee outstanding" |

### Edge cases (the resolver should NOT rewrite)

- A completely new question ("who teaches maths in 8A?" → "how many students in class 10?") — no rewrite; send as-is.
- A question that's already self-contained ("what is the fee outstanding for the current term?") — no rewrite.
- A clarification in response to a disambiguation prompt ("Which section did you mean?" → "TALENTED") — no rewrite; this is handled by the disambiguation flow, not the resolver.

### How the mobile app implements it

```python
# Pseudocode for the mobile app's send-question flow
def on_user_send(new_question):
    history = get_last_3_turns()  # from local conversation store
    if is_followup(new_question, history):
        rewritten = resolve_followup(new_question, history)  # rule-based or LLM
        send_to_backend(rewritten)
    else:
        send_to_backend(new_question)
```

The mobile app shows the user's original (un-rewritten) input in the chat, but sends the rewritten version to the backend. The backend's response is attributed to the user's original input. (Optional: the mobile app can show a small "Interpreted as: <rewritten>" hint so the user can correct if the rewrite was wrong.)

---

## 4. The disambiguation flow (already designed, needs UX polish)

The backend returns `NEEDS_DISAMBIGUATION` with `candidates` (e.g. "Which section did you mean? A, B, C, D, E"). The mobile app should:
- Show the candidates as **selectable chips**, not a free-text input.
- When the user picks one, re-send the original question with the chosen value substituted (the backend's `disambiguation` field tells the mobile app which concept_type to substitute).
- If the user types a different value instead of picking, send that as a follow-up (the resolver handles "wait, I meant X").

---

## 5. The refusal flow (needs UX polish)

The backend returns `REFUSED` with a `message` + `semantic_violations` (each with a `suggested_fix`). The mobile app should:
- Show the `message` in a friendly tone.
- Show the first violation's `suggested_fix` as a **"Try asking: <suggested phrasing>"** hint button. Tapping it fills the composer with the suggested phrasing.
- If the refusal is "I don't recognize 'X' as a section at your branch", show the branch's real sections as selectable chips (same as disambiguation).

---

## 6. The "what about..." entity-substitution flow

The most common conversational pattern is "what about <entity>?" — the user wants the same query but with a different entity (branch, class, section, subject, term). The resolver should:
- Identify the entity type in the follow-up (branch name, class number, section letter, subject name, term name).
- Find the corresponding entity in the last question.
- Substitute and send.

The entity types to handle:
- **Branch names** (from the Context JSON's `UserBranchDetails[].Name`): "besant nagar", "golden gates", etc.
- **Class numbers**: "class 8", "8th", "VIII", "8".
- **Section letters**: "A", "B", "C" (or ability-stream names: "TALENTED", "EXPERT").
- **Subject names**: "maths", "english", "physics".
- **Term names**: "term 1", "term I", "summative assessment I".

The resolver needs the Context JSON to recognize branch-specific entity names (e.g. "TALENTED" is a section only at branch 1). This is why the resolver runs client-side — the mobile app has the Context JSON.

---

## 7. The "compare X vs Y" flow

A powerful pattern: "compare fee outstanding for class 10 vs class 9". The resolver should:
- Recognize the "vs" pattern.
- Send two questions to the backend in parallel (or one question that asks for both, if the model can handle it).
- The mobile app renders the two results side-by-side.

This is a v1.2 feature — the v27 model wasn't trained on "compare" questions. The v28 retrain should add ~10 "compare X vs Y" training examples.

---

## 8. The "show me more" / drill-down flow

When the backend returns a table of results, the user might want to drill down: "show me the defaulters" → "show me the top 10 defaulters" → "show me the details for the first one". The resolver should:
- Recognize "show me more about <entity>" or "drill into <entity>".
- Send a new query that filters on the entity (e.g. "show me the fee details for student ID 12345").

This requires the mobile app to track which entity the user is pointing at (the row they tapped, or the one they mentioned). v1.2.

---

## 9. What NOT to do

- **Do NOT send the full conversation history to the backend's main LLM call.** That bloats the prompt, increases latency, and risks the model getting confused. The resolver produces a self-contained question; the backend sees only that.
- **Do NOT make the resolver a second Qwen-7B call** (too slow on CPU). Use rule-based for v1.1; if you need LLM-based resolution, use a smaller model (Qwen 1.5B or similar) or a cloud API (with the user's consent — latency vs. cost tradeoff).
- **Do NOT rewrite questions the user explicitly self-contained.** If the user types "what is the fee outstanding for the current term for class 10 section A", don't rewrite it — it's already complete.
- **Do NOT hide the rewrite from the user.** Show "Interpreted as: <rewritten>" so the user can correct a bad rewrite. Transparency builds trust.

---

## 10. Implementation phasing

| Phase | Feature | Effort |
|---|---|---|
| v1.0 (current) | Stateless backend; mobile app sends self-contained questions. | Done. |
| v1.1 | Client-side rule-based resolver (the 10 patterns in §3). Disambiguation as chips. Refusal with "try asking" hint. | ~1 week (mobile app). |
| v1.2 | "Compare X vs Y" + drill-down. | ~2 weeks (mobile app + a few v28 training examples). |
| v1.3 | LLM-based resolver for the long tail (small model). | ~1 week + model selection. |
| v2.0 | Server-side conversation store (cross-device sync, conversation persistence). | ~1 month (backend + DB). |

---

## 11. The bottom line

The chatbot's current stateless design works for one-shot questions but fails for casual conversation. The fix is a client-side conversation resolver that rewrites follow-ups into self-contained questions before sending them to the backend. This keeps the backend stateless (simple, scalable) and puts the conversation logic where it belongs (the mobile app, which already maintains the chat history).

The resolver starts rule-based (10 patterns, 80% coverage, zero latency) and graduates to LLM-based for the long tail. The disambiguation and refusal flows need UX polish (chips, "try asking" hints). Compare and drill-down are v1.2. Server-side conversation persistence is v2.0.

**The key insight:** the model doesn't need to "remember" the conversation. The mobile app remembers it and feeds the model a self-contained question every time. This is how Claude.ai and ChatGPT work under the hood — the conversation history is reformatted into the prompt, not stored in the model.

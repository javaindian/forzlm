# ChaloSchools V3_CHALO — Living Data Dictionary

**What this is:** a structured, annotated, trackable data dictionary for the school ERP database. Built from the schema dump + 1,095 stored procedures + production traces. The dev team fills in the gaps over time.

**Status tags:** ✅ CONFIRMED | 🟡 PARTIAL | 🔴 PENDING | ⚠️ GOTCHA | 🗑️ DEPRECATED

**Scale:** 475 tables, 8685 columns across 15 modules.

---

## 1. Summary Dashboard


| Status | Tables | % |
|---|---:|---:|

| ✅ CONFIRMED | 25 | 5.3% |

| 🟡 PARTIAL | 13 | 2.7% |

| 🔴 PENDING | 432 | 90.9% |

| 🗑️ DEPRECATED | 5 | 1.1% |

| **Total** | **475** | **100%** |


### Module breakdown


| Module | Tables | Confirmed | Partial | Pending |
|---|---:|---:|---:|---:|

| Students | 98 | 8 | 3 | 87 |

| Other | 80 | 3 | 0 | 76 |

| Fees | 59 | 4 | 1 | 54 |

| Exams | 46 | 2 | 0 | 44 |

| Staff | 40 | 2 | 0 | 37 |

| Transport | 31 | 0 | 2 | 29 |

| Admin | 20 | 2 | 1 | 16 |

| Payroll | 18 | 1 | 2 | 15 |

| Timetable | 17 | 0 | 0 | 17 |

| Inventory | 15 | 0 | 1 | 13 |

| Admissions | 14 | 1 | 2 | 10 |

| RBAC | 13 | 2 | 0 | 11 |

| Communication | 11 | 0 | 1 | 10 |

| CircularsHomework | 7 | 0 | 0 | 7 |

| ParentFeedback | 6 | 0 | 0 | 6 |


---

## 2. Known Gotchas (read this first)


These are schema-level issues that cause the most bugs:


- **BusFeeStrucure**: ⚠️ MISSPELLED in production — missing the second 't'. 'BusFeeStructure' does NOT exist. 32 SPs use the misspelled name.

- **ExamTermMaster**: ⚠️ Soft-delete column is 'Deleted' (NOT 'IsDeleted'). Date columns are 'StartDate/EndDate' (datetime, NOT 'StartingDate/EndingDate'). Has a typo: 'CreaedOn' instead of 'CreatedOn'.

- **FeesCollection**: ⚠️ PK is lowercase 'Id' (not 'ID'). Amount column is 'Receipt_Amt' (not 'Amt' — 'Amt' doesn't exist).

- **Subject_Master**: ⚠️ PK is lowercase 'Id' (not 'ID').

- **FeesInformationStudentDetail**: ⚠️ Does NOT have an IsDeleted column — soft-delete is via Paid_Amt/Lien_Amount updates (via SP_Update_OutstandingAmount).

- **Student_Master**: ⚠️ Has NO ClassID, SectionID, or AcademicYearID — those live on StudentAcademicDetail.

- **SL_Student_Master**: ⚠️ SL_ prefixed variant — near-identical to Student_Master but with 307 cols. Purpose unknown; 196:1 ratio of non-SL to SL in SP usage.


---

## 3. Deprecated Tables (do not use)


| Table | Use instead | Note |
|---|---|---|

| 🗑️ EnquiryMaster | GeneralCallRegister | Use GeneralCallRegister (deprecated — zero live SP usage) |

| 🗑️ Department_Master | StaffDepartmentMaster | Use StaffDepartmentMaster (deprecated despite identical schema) |

| 🗑️ PurchaseRequest | IPurchaseRequest | Use IPurchaseRequest (deprecated — has misspelled 'ApprovaStatus') |

| 🗑️ Academic_Month_Master | Month_Master | Use Month_Master (deprecated despite the name) |

| 🗑️ EmployeeMaster | Staff_Master | Use Staff_Master (deprecated — empty or stale in the live DB) |


---

## 4. Known Enums (lookup values)


- **FeesInformationStudentDetail.Structure_Type** (CONFIRMED): `Academic`, `Optional`, `Hostel`, `Bus`, `Misc`, `Others`
  - Note: Filter IN ('Academic','Optional') for general fee queries. Use = 'Bus'/'Hostel' for specific.


- **FeesCollection.ChequeStatus_ID** (PARTIAL): `1`, `2`, `3`, `4`, `5`
  - Note: Filter NOT IN (3,4) for collection totals. Status 5's meaning is unconfirmed.


- **StudentAttendance.Attendance_Status_ID** (CONFIRMED): `1`, `2`, `3`, `4`


- **StudentAcademicDetail.TransportRequired** (PARTIAL): `True`, `False`, `1`, `0`
  - Note: nvarchar(10) — inconsistent: some SPs use ='True', others use =1. The schema type is nvarchar(10), not bit.


- **Staff_Master.StaffStatus_ID** (PARTIAL): `1`, `2`, `3`
  - Note: 1=active is confirmed; other values need dev-team confirmation.


- **Staff_Master.Gender** (CONFIRMED): `Male`, `Female`, `Boy`, `Girl`, `MALE`, `FEMALE`, `Transcend`
  - Note: Not uniform — multiple casings + 'Boy'/'Girl' for student contexts + 'Transcend' for FeeStructureMonth.



---

## 5. Known Foreign Key Relationships


| From | Column | To | Column | Status | Note |
|---|---|---|---|---|---|

| FeesInformationStudentDetail | Term_ID | TermMaster | ID | CONFIRMED | Fee terms — NOT ExamTermMaster |

| FeesInformationStudentDetail | Student_ID | Student_Master | ID | CONFIRMED |  |

| FeesInformationStudentDetail | Fees_ID | Fees_Master | ID | CONFIRMED |  |

| FeesCollection_Details | Term_ID | TermMaster | ID | CONFIRMED | Fee terms — NOT ExamTermMaster |

| FeesCollection_Details | Fees_Collection_ID | FeesCollection | Id | CONFIRMED | PK is lowercase 'Id' |

| BusFeeStrucure | Term_ID | TermMaster | ID | CONFIRMED | Fee terms |

| BusFeeStrucure | TripID | Transport_TripDetails | ID | CONFIRMED | NOT a fixed enum 1/2 — real FK |

| HostelFeeStructure | Term_ID | TermMaster | ID | CONFIRMED | Fee terms |

| StudentAcademicDetail | StudentID | Student_Master | ID | CONFIRMED |  |

| StudentAcademicDetail | ClassID | ClassMaster | ID | CONFIRMED |  |

| StudentAcademicDetail | SectionID | SectionMaster | ID | CONFIRMED |  |

| StudentAcademicDetail | AcademicYearID | Branch_Academic_Details | Id | CONFIRMED | PK is lowercase 'Id' |

| StudentAttendance | Student_ID | Student_Master | ID | CONFIRMED |  |

| StudentAttendance | Class_ID | ClassMaster | ID | CONFIRMED |  |

| SubjectAllocation_Master | Staff_ID | Staff_Master | Staff_ID | CONFIRMED |  |

| SubjectAllocation_Master | Subject_ID | Subject_Master | Id | CONFIRMED | PK is lowercase 'Id' |

| SubjectAllocation_Master | Class_ID | ClassMaster | ID | CONFIRMED |  |

| SubjectAllocation_Master | Section_ID | SectionMaster | ID | CONFIRMED |  |

| ExamTypeMaster | TermID | ExamTermMaster | ID | CONFIRMED | EXAM terms — NOT TermMaster |

| StudentMarkMaster | ExamTypeID | ExamTypeMaster | ID | PARTIAL |  |

| StudentMarkDetails | HeaderID | StudentMarkMaster | ID | PARTIAL |  |

| StudentMarkDetails | StudentID | Student_Master | ID | PARTIAL |  |

| EmployeeSalaryDetails | EmployeeID | Staff_Master | Staff_ID | CONFIRMED | EmployeeID → Staff_Master.Staff_ID |

| GenerateSalaryEmployee_Master | HeaderID | GenerateSalary_Master | ID | PARTIAL |  |

| UserAccountRoleDetails | UserID | UserAccountMaster | ID | CONFIRMED |  |

| UserAccountRoleDetails | BranchID | BranchMaster | ID | CONFIRMED |  |

| UserAccountRoleDetails | RoleID | UserAccountRoleMaster | ID | CONFIRMED |  |

| Branch_Academic_Details | Branch_Id | BranchMaster | ID | CONFIRMED | Column is 'Branch_Id' (with underscore) |

| Branch_Academic_Details | PreviousYearID | Branch_Academic_Details | Id | CONFIRMED | Self-reference to the previous AY |


---

## 6. Table Documentation (by module)


### Students (98 tables)


#### 🔴 AttendanceCertificate (31 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdmissionNo | nvarchar | YES | TBC | 🔴 |

| AttendancePercentage | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ClassName | nvarchar | YES | TBC | 🔴 |

| FatherName | nvarchar | YES | TBC | 🔴 |

| GuardianName | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IssuedBy | nvarchar | YES | TBC | 🔴 |

| IssuedDate | date | YES | TBC | 🔴 |

| MotherName | nvarchar | YES | TBC | 🔴 |

| Purpose | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| SchoolAcademicYear | nvarchar | YES | TBC | 🔴 |

| SchoolAddress1 | nvarchar | YES | TBC | 🔴 |

| SchoolAddress2 | nvarchar | YES | TBC | 🔴 |

| SchoolLogo | nvarchar | YES | TBC | 🔴 |

| SchoolMobileNo | nvarchar | YES | TBC | 🔴 |

| SchoolName | nvarchar | YES | TBC | 🔴 |

| SchoolPhone1 | nvarchar | YES | TBC | 🔴 |

| SchoolPhone2 | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| SectionName | nvarchar | YES | TBC | 🔴 |

| SequenceNumber | nvarchar | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| StudentName | nvarchar | YES | TBC | 🔴 |

| TotalAbsentDays | nvarchar | YES | TBC | 🔴 |

| TotalPresentDays | nvarchar | YES | TBC | 🔴 |

| TotalWorkingDays | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 AttendanceConfiguration (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Attendance_Status_ID | bigint | YES | TBC | 🔴 |

| Attendance_Status_Name | varchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| EndTime | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| ShiftID | bigint | YES | TBC | 🔴 |

| StartTime | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 AttendanceReasonMaster (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBY | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 BlockClassDetail (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Block_ID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_ID | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |



---


#### 🔴 ClassDetails (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| ApplicableFromDob | datetime | YES | TBC | 🔴 |

| ApplicableToDob | datetime | YES | TBC | 🔴 |

| Class_Id | bigint | YES | TBC | 🔴 |

| EndDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsOnlineApplicationEnabled | bit | YES | TBC | 🔴 |

| LastSerialNumber | nvarchar | YES | TBC | 🔴 |

| OnlineApplicationEndDate | date | YES | TBC | 🔴 |

| OnlineApplicationStartDate | date | YES | TBC | 🔴 |

| StartDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 ClassEvaluationMaster (10 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | int | NO | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| EvaluationID | int | NO | TBC | 🔴 |

| EvaluationName | nvarchar | YES | TBC | 🔴 |

| ID | int | NO | TBC | 🔴 |

| IsDeleted | bit | NO | TBC | 🔴 |

| Parent | nvarchar | YES | TBC | 🔴 |

| SubjectID | bigint | NO | TBC | 🔴 |



---


#### ✅ ClassMaster (18 columns) — [CONFIRMED]


**Purpose:** Class list. PK is 'ID' (uppercase). Has Name (e.g. 'Class 10', 'X').


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| DisplayOrder | int | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Level_Id | bigint | YES | TBC | 🔴 |

| MaxAgeLimit | bigint | YES | TBC | 🔴 |

| MinAgeLimit | bigint | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| ReportTemplateID | nvarchar | YES | TBC | 🔴 |

| ReportTypeID | int | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 ClassPromotionDetails (3 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| ClassID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| PromotionClassID | bigint | YES | TBC | 🔴 |



---


#### 🔴 ClassSectionChangeDetails (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdmissionNo | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ChangeDate | date | YES | TBC | 🔴 |

| ChangeReason | nvarchar | YES | TBC | 🔴 |

| ClassID_From | bigint | YES | TBC | 🔴 |

| ClassID_To | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| RollNo | nvarchar | YES | TBC | 🔴 |

| SectionID_From | bigint | YES | TBC | 🔴 |

| SectionID_To | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |



---


#### 🔴 ClassSectionMaster (17 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AvailableSeats | bigint | YES | TBC | 🔴 |

| Block | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_Id | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| Floor | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Section_Id | bigint | YES | TBC | 🔴 |

| TotalSeats | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 ClassSubjectDetails (8 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_Id | int | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsOptional | int | YES | TBC | 🔴 |

| Section_Id | int | YES | TBC | 🔴 |

| Subject | nvarchar | YES | TBC | 🔴 |

| Subject_Id | bigint | YES | TBC | 🔴 |



---


#### 🔴 ClassTermAssignment (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | NO | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 ClassTermDetails (10 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassAssignmentID | bigint | YES | TBC | 🔴 |

| FromDate | datetime | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsChecked | bit | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| TermID | bigint | YES | TBC | 🔴 |

| TermName | nvarchar | YES | TBC | 🔴 |

| ToDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 ClassTermMasterMapping (15 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | date | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| EndingDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| StartingDate | datetime | YES | TBC | 🔴 |

| TermID | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 Class_Subject_Mapping_Details (15 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_Id | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| DisplayOrder | int | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IsOptional | bit | YES | TBC | 🔴 |

| Section_Id | bigint | YES | TBC | 🔴 |

| Subject_Id | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 Class_TimeTable (42 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_Id | bigint | YES | TBC | 🔴 |

| Day | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| P1 | nvarchar | YES | TBC | 🔴 |

| P1_Staff | nvarchar | YES | TBC | 🔴 |

| P1_Staff_Id | nvarchar | YES | TBC | 🔴 |

| P1_SubjectId | nvarchar | YES | TBC | 🔴 |

| P2 | nvarchar | YES | TBC | 🔴 |

| P2_Staff | nvarchar | YES | TBC | 🔴 |

| P2_Staff_Id | nvarchar | YES | TBC | 🔴 |

| P2_SubjectId | nvarchar | YES | TBC | 🔴 |

| P3 | nvarchar | YES | TBC | 🔴 |

| P3_Staff | nvarchar | YES | TBC | 🔴 |

| P3_Staff_Id | nvarchar | YES | TBC | 🔴 |

| P3_SubjectId | nvarchar | YES | TBC | 🔴 |

| P4 | nvarchar | YES | TBC | 🔴 |

| P4_Staff | nvarchar | YES | TBC | 🔴 |

| P4_Staff_Id | nvarchar | YES | TBC | 🔴 |

| P4_SubjectId | nvarchar | YES | TBC | 🔴 |

| P5 | nvarchar | YES | TBC | 🔴 |

| P5_Staff | nvarchar | YES | TBC | 🔴 |

| P5_Staff_Id | nvarchar | YES | TBC | 🔴 |

| P5_SubjectId | nvarchar | YES | TBC | 🔴 |

| P6 | nvarchar | YES | TBC | 🔴 |

| P6_Staff | nvarchar | YES | TBC | 🔴 |

| P6_Staff_Id | nvarchar | YES | TBC | 🔴 |

| P6_SubjectId | nvarchar | YES | TBC | 🔴 |

| P7 | nvarchar | YES | TBC | 🔴 |

| P7_Staff | nvarchar | YES | TBC | 🔴 |

| P7_Staff_Id | nvarchar | YES | TBC | 🔴 |

| P7_SubjectId | nvarchar | YES | TBC | 🔴 |

| P8 | nvarchar | YES | TBC | 🔴 |

| P8_Staff | nvarchar | YES | TBC | 🔴 |

| P8_Staff_Id | nvarchar | YES | TBC | 🔴 |

| P8_SubjectId | nvarchar | YES | TBC | 🔴 |

| P9 | nvarchar | YES | TBC | 🔴 |

| P9_Staff | nvarchar | YES | TBC | 🔴 |

| P9_Staff_Id | nvarchar | YES | TBC | 🔴 |

| P9_SubjectId | nvarchar | YES | TBC | 🔴 |

| Section_Id | bigint | YES | TBC | 🔴 |



---


#### 🔴 ConductCertificate (28 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdmissionNo | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ClassName | nvarchar | YES | TBC | 🔴 |

| FatherName | nvarchar | YES | TBC | 🔴 |

| GuardianName | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IssuedBy | nvarchar | YES | TBC | 🔴 |

| IssuedDate | date | YES | TBC | 🔴 |

| MotherName | nvarchar | YES | TBC | 🔴 |

| Purpose | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| SchoolAcademicYear | nvarchar | YES | TBC | 🔴 |

| SchoolAddress1 | nvarchar | YES | TBC | 🔴 |

| SchoolAddress2 | nvarchar | YES | TBC | 🔴 |

| SchoolLogo | nvarchar | YES | TBC | 🔴 |

| SchoolMobileNo | nvarchar | YES | TBC | 🔴 |

| SchoolName | nvarchar | YES | TBC | 🔴 |

| SchoolPhone1 | nvarchar | YES | TBC | 🔴 |

| SchoolPhone2 | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| SectionName | nvarchar | YES | TBC | 🔴 |

| SequenceNumber | nvarchar | YES | TBC | 🔴 |

| StudentDOB | date | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| StudentName | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 ConsolidatedExamConfigurationClassSectionDetails (7 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| ClassID | bigint | YES | TBC | 🔴 |

| ClassName | varchar | YES | TBC | 🔴 |

| ClassSectionID | bigint | YES | TBC | 🔴 |

| ConsolidatedExamHeaderID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| SectionName | varchar | YES | TBC | 🔴 |



---


#### 🔴 ExamConfigurationClassSectionDetails (7 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| ClassID | bigint | YES | TBC | 🔴 |

| ClassName | varchar | YES | TBC | 🔴 |

| ClassSectionID | bigint | YES | TBC | 🔴 |

| ExamHeaderID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| SectionName | varchar | YES | TBC | 🔴 |



---


#### 🔴 ExamTypeClassDetails (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | NO | TBC | 🔴 |

| Deleted | bit | NO | TBC | 🔴 |

| ExamTypeID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |



---


#### 🔴 GenerateSalaryEmployee_Leave_Details (9 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| EmployeeID | bigint | YES | TBC | 🔴 |

| HeaderID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| LeaveCount | decimal | YES | TBC | 🔴 |

| LeaveTypeID | bigint | YES | TBC | 🔴 |

| LeaveTypeName | nvarchar | YES | TBC | 🔴 |

| MasterID | bigint | YES | TBC | 🔴 |



---


#### 🔴 HallTicketConfigMaster (9 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| HT_Data | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 HolidayClassDetails (8 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_ID | bigint | YES | TBC | 🔴 |

| Class_Name | nvarchar | YES | TBC | 🔴 |

| Holiday_ID | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| Section_ID | bigint | YES | TBC | 🔴 |

| Section_Name | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 HomeWorkAndAssignment_StudentDetails (3 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| HomeWorkAndAssignmentID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |



---


#### 🔴 HouseMaster (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Description | varchar | YES | TBC | 🔴 |

| ID | int | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 LeaveApplicationEntry (22 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| ApprovedBy | bigint | YES | TBC | 🔴 |

| ApprovedDate | datetime | YES | TBC | 🔴 |

| Attachment | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CancelledBy | bigint | YES | TBC | 🔴 |

| CancelledDate | datetime | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| FromDate | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsAttachmentAvailable | bit | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| LeaveApplicationStatus | nvarchar | YES | TBC | 🔴 |

| LeaveApplicationStatusID | bigint | YES | TBC | 🔴 |

| Reason | nvarchar | YES | TBC | 🔴 |

| ReasonForLeaveCancellation | nvarchar | YES | TBC | 🔴 |

| RequestedBy | bigint | YES | TBC | 🔴 |

| RequestedDate | datetime | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| ToDate | nvarchar | YES | TBC | 🔴 |

| TotalLeaveDays | bigint | YES | TBC | 🔴 |



---


#### 🔴 LeaveCategoryMaster (9 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 LeaveCategoryMasterDetails (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| ID | bigint | NO | TBC | 🔴 |

| LeaveCategoryMasterID | bigint | YES | TBC | 🔴 |

| LeaveDays | decimal | YES | TBC | 🔴 |

| LeaveTypeID | bigint | YES | TBC | 🔴 |

| MaximumLimitPerMonth | decimal | YES | TBC | 🔴 |



---


#### 🔴 LeaveEntryDetails (3 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| HeaderID | bigint | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| LeaveDate | date | NO | TBC | 🔴 |



---


#### ✅ LeaveEntryMaster (22 columns) — [CONFIRMED]


**Purpose:** Staff leave requests. Has LeaveFromDate, LeaveToDate, NoOfDays, LeaveStatus_ID, Purpose.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| LeaveFromDate | date | YES | TBC | 🔴 |

| LeaveSessionID | int | YES | TBC | 🔴 |

| LeaveSessionName | nvarchar | YES | TBC | 🔴 |

| LeaveStatus_ID | bigint | YES | TBC | 🔴 |

| LeaveToDate | date | YES | TBC | 🔴 |

| LeaveType_ID | bigint | YES | TBC | 🔴 |

| NoOfDays | numeric | YES | TBC | 🔴 |

| Purpose | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| StaffType_ID | bigint | YES | TBC | 🔴 |

| Staff_ID | bigint | YES | TBC | 🔴 |

| Staff_Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 LeaveStatus (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Desc | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Name | nvarchar | NO | TBC | 🔴 |



---


#### 🔴 LeaveType (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Desc | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| ShortName | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 NEET_JEE_Students (14 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| EmailAddress | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| MobileNo | nvarchar | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| RollNo | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 ObservationCategory (8 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| DisplayOrder | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 ObservationSubCategory (7 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| DisplayOrder | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| ObservationCatID | bigint | YES | TBC | 🔴 |

| ObservationCatName | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 OtherExamConfigurationClassSectionDetails (7 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| ClassID | bigint | YES | TBC | 🔴 |

| ClassName | varchar | YES | TBC | 🔴 |

| ClassSectionID | bigint | YES | TBC | 🔴 |

| ExamHeaderID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| SectionName | varchar | YES | TBC | 🔴 |



---


#### 🔴 OtherExam_StudentMarkDetails (16 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | NO | TBC | 🔴 |

| CreatedOn | datetime | NO | TBC | 🔴 |

| Deleted | bit | NO | TBC | 🔴 |

| EvalHierID | bigint | YES | TBC | 🔴 |

| Grade | nvarchar | YES | TBC | 🔴 |

| HeaderID | bigint | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IDS | varchar | YES | TBC | 🔴 |

| Marks | numeric | NO | TBC | 🔴 |

| Others | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedOn | datetime | YES | TBC | 🔴 |



---


#### 🔴 OtherExam_StudentMarkMaster (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | NO | TBC | 🔴 |

| CreatedOn | datetime | NO | TBC | 🔴 |

| Deleted | bit | NO | TBC | 🔴 |

| ExamSettingID | bigint | YES | TBC | 🔴 |

| ExamTypeID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedOn | datetime | YES | TBC | 🔴 |



---


#### 🔴 PaymentConfiguration (36 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| APIKey | nvarchar | YES | TBC | 🔴 |

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BCCeMailAddress | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CCeMailAddress | nvarchar | YES | TBC | 🔴 |

| ChecksumKey | nvarchar | YES | TBC | 🔴 |

| Child1_Merchant_Key | nvarchar | YES | TBC | 🔴 |

| Child2_Merchant_Key | nvarchar | YES | TBC | 🔴 |

| Child3_Merchant_Key | nvarchar | YES | TBC | 🔴 |

| Child4_Merchant_Key | nvarchar | YES | TBC | 🔴 |

| FURL | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Ischarges | nvarchar | YES | TBC | 🔴 |

| MailID | nvarchar | YES | TBC | 🔴 |

| Merchant | nvarchar | YES | TBC | 🔴 |

| MerchantID | nvarchar | YES | TBC | 🔴 |

| MerchantKey | nvarchar | YES | TBC | 🔴 |

| PAYU_BASE_URL | nvarchar | YES | TBC | 🔴 |

| PPassword | nvarchar | YES | TBC | 🔴 |

| PUserName | nvarchar | YES | TBC | 🔴 |

| Parent_Merchant_Key | nvarchar | YES | TBC | 🔴 |

| Password | nvarchar | YES | TBC | 🔴 |

| PaymentOptionID | bigint | YES | TBC | 🔴 |

| PaymentURL | nvarchar | YES | TBC | 🔴 |

| Port | nvarchar | YES | TBC | 🔴 |

| ReceiptFor | nvarchar | YES | TBC | 🔴 |

| RedirectURL | nvarchar | YES | TBC | 🔴 |

| SALT | nvarchar | YES | TBC | 🔴 |

| SMTPServer | nvarchar | YES | TBC | 🔴 |

| SSL | nvarchar | YES | TBC | 🔴 |

| SURL | nvarchar | YES | TBC | 🔴 |

| SecurityID | nvarchar | YES | TBC | 🔴 |

| SplitEnabled | bit | YES | TBC | 🔴 |

| Status | bit | YES | TBC | 🔴 |

| hashSequence | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 PaymentConfiguration_Details (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Branch_Code | nvarchar | YES | TBC | 🔴 |

| CompanyID | bigint | YES | TBC | 🔴 |

| CompanyName | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| PaymentConfigurationID | bigint | NO | TBC | 🔴 |



---


#### 🔴 ProgressCardClassDetails (7 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| Deleted | bit | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| ModelSchoolID | bigint | NO | TBC | 🔴 |

| ModelTypeID | bigint | NO | TBC | 🔴 |



---


#### 🔴 ProgressCardClassSectionConfiguration (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| ClassID | bigint | YES | TBC | 🔴 |

| ClassSectionID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ExamTypeID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| ModelID | bigint | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | NO | TBC | 🔴 |



---


#### 🔴 ProgressCardSettingExamAttendanceDetails (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| EndDate | datetime | YES | TBC | 🔴 |

| ExamTypeID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| StartDate | datetime | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 ProgressCardTypeClassMapping (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | NO | TBC | 🔴 |

| Deleted | bit | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| TypeID | bigint | NO | TBC | 🔴 |



---


#### 🔴 ReportColumnSetting (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| BranchID | int | YES | TBC | 🔴 |

| ColumnKey | varchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| DisplayName | varchar | YES | TBC | 🔴 |

| DisplayOrder | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsMandatory | bit | YES | TBC | 🔴 |

| IsTotal | bit | YES | TBC | 🔴 |

| ReportType | int | YES | TBC | 🔴 |

| ScreenID | bigint | YES | TBC | 🔴 |

| ScreenName | varchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Visible | bit | YES | TBC | 🔴 |



---


#### 🔴 SL_StudentAcademicDetail (32 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ClassName | nvarchar | YES | TBC | 🔴 |

| ExamRegistrationNo | nvarchar | YES | TBC | 🔴 |

| FoodRequired | bit | YES | TBC | 🔴 |

| HostelRequired | bit | YES | TBC | 🔴 |

| HouseID | bigint | YES | TBC | 🔴 |

| HouseName | varchar | YES | TBC | 🔴 |

| IDCardNo | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsLumpsumApplicable | bit | YES | TBC | 🔴 |

| IsNEETJEE | bit | YES | TBC | 🔴 |

| IsNewAdmission | bit | YES | TBC | 🔴 |

| IsPromoted | bit | YES | TBC | 🔴 |

| IsSectionChanged | bit | YES | TBC | 🔴 |

| IsTCIssued | bit | YES | TBC | 🔴 |

| Lumpsum_Amount | bigint | YES | TBC | 🔴 |

| Lumpsum_Id | bigint | YES | TBC | 🔴 |

| OtherExam | varchar | YES | TBC | 🔴 |

| OtherExamName | varchar | YES | TBC | 🔴 |

| Paid_Date | datetime | YES | TBC | 🔴 |

| Return_Date | datetime | YES | TBC | 🔴 |

| RollNo | nvarchar | YES | TBC | 🔴 |

| SMSFile | nvarchar | YES | TBC | 🔴 |

| SectionChangeReason | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| StudentFeeCategoryID | bigint | YES | TBC | 🔴 |

| StudentFeeSubCategoryID | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| StudentRollNowithoutPrefix | bigint | YES | TBC | 🔴 |

| TCIssuedDate | datetime | YES | TBC | 🔴 |

| TransportRequired | bit | YES | TBC | 🔴 |



---


#### 🔴 SL_Student_Document (8 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| DocumentName | nvarchar | YES | TBC | 🔴 |

| DocumentType | nvarchar | YES | TBC | 🔴 |

| DocumentUrl | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 SL_Student_Master (307 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**⚠️ Gotcha:** SL_ prefixed variant — near-identical to Student_Master but with 307 cols. Purpose unknown; 196:1 ratio of non-SL to SL in SP usage.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| APAARID | nvarchar | YES | TBC | 🔴 |

| AdhaarCardNo | nvarchar | YES | TBC | 🔴 |

| AdmissionCategoryID | bigint | YES | TBC | 🔴 |

| AdmissionDate | date | YES | TBC | 🔴 |

| AdmissionNo | nvarchar | YES | TBC | 🔴 |

| AdmissionPriorityID | bigint | YES | TBC | 🔴 |

| AdmissionStatus | bit | YES | TBC | 🔴 |

| AdmissionTypeName | nvarchar | YES | TBC | 🔴 |

| AdmissionType_ID | bigint | YES | TBC | 🔴 |

| AdmissionWaiverOptionId | bigint | YES | TBC | 🔴 |

| AdmissionWaiverOptionName | nvarchar | YES | TBC | 🔴 |

| AgeAsOn | nvarchar | YES | TBC | 🔴 |

| Allergies | nvarchar | YES | TBC | 🔴 |

| Applicant_ID | bigint | YES | TBC | 🔴 |

| ApplicationNo | nvarchar | YES | TBC | 🔴 |

| AvailableCredit | numeric | YES | TBC | 🔴 |

| BMI | nvarchar | YES | TBC | 🔴 |

| BankAccountNo | nvarchar | YES | TBC | 🔴 |

| BankAddress | nvarchar | YES | TBC | 🔴 |

| BankIfscCode | nvarchar | YES | TBC | 🔴 |

| BankName | nvarchar | YES | TBC | 🔴 |

| Block_ID | bigint | YES | TBC | 🔴 |

| Block_Name | nvarchar | YES | TBC | 🔴 |

| BloodGroup_ID | bigint | YES | TBC | 🔴 |

| BloodGroup_Name | nvarchar | YES | TBC | 🔴 |

| BoardingPoint_ID | bigint | YES | TBC | 🔴 |

| BoardingPoint_Name | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CanditateID | nvarchar | YES | TBC | 🔴 |

| CasteID | bigint | YES | TBC | 🔴 |

| Chest | nvarchar | YES | TBC | 🔴 |

| ChildBornOrder | int | YES | TBC | 🔴 |

| ChildDisadvantagedGroup | nvarchar | YES | TBC | 🔴 |

| ClassLastStudied | nvarchar | YES | TBC | 🔴 |

| ComAddress | nvarchar | YES | TBC | 🔴 |

| ComCity | nvarchar | YES | TBC | 🔴 |

| ComCity_ID | bigint | YES | TBC | 🔴 |

| ComCountry | nvarchar | YES | TBC | 🔴 |

| ComCountry_ID | bigint | YES | TBC | 🔴 |

| ComDistrictId | bigint | YES | TBC | 🔴 |

| ComDistrictName | nvarchar | YES | TBC | 🔴 |

| ComEmail | nvarchar | YES | TBC | 🔴 |

| ComMobile | nvarchar | YES | TBC | 🔴 |

| ComPhone | nvarchar | YES | TBC | 🔴 |

| ComPincode | nvarchar | YES | TBC | 🔴 |

| ComPlace | nvarchar | YES | TBC | 🔴 |

| ComState | nvarchar | YES | TBC | 🔴 |

| ComState_ID | bigint | YES | TBC | 🔴 |

| ComTaluk | nvarchar | YES | TBC | 🔴 |

| ComVillage | nvarchar | YES | TBC | 🔴 |

| CombinedSubjects | nvarchar | YES | TBC | 🔴 |

| CommunicationMailID | nvarchar | YES | TBC | 🔴 |

| CommunicationMobileNo | nvarchar | YES | TBC | 🔴 |

| CommunicationeMailID | nvarchar | YES | TBC | 🔴 |

| CommunityCertificate | nvarchar | YES | TBC | 🔴 |

| Community_ID | bigint | YES | TBC | 🔴 |

| Community_Name | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| DateOfPassportIssue | date | YES | TBC | 🔴 |

| DateOfVISAIssue | date | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Dental | nvarchar | YES | TBC | 🔴 |

| Disability_ID | int | YES | TBC | 🔴 |

| Disability_Name | nvarchar | YES | TBC | 🔴 |

| DocumentsCheckList | nvarchar | YES | TBC | 🔴 |

| EMISNo | nvarchar | YES | TBC | 🔴 |

| EducationMedium | nvarchar | YES | TBC | 🔴 |

| EmergencyContactIdentificationNo | nvarchar | YES | TBC | 🔴 |

| EmergencyContactPersonMobileNo | nvarchar | YES | TBC | 🔴 |

| EmergencyContactPersonName | nvarchar | YES | TBC | 🔴 |

| EmergencyContactPersonRelationship | nvarchar | YES | TBC | 🔴 |

| EnrollmentNo | nvarchar | YES | TBC | 🔴 |

| ExtraCurricularActivity | nvarchar | YES | TBC | 🔴 |

| FatherAadhaarNo | nvarchar | YES | TBC | 🔴 |

| FatherAdhaarCardNo | nvarchar | YES | TBC | 🔴 |

| FatherAge | int | YES | TBC | 🔴 |

| FatherAnnualIncome | nvarchar | YES | TBC | 🔴 |

| FatherContactNo | nvarchar | YES | TBC | 🔴 |

| FatherDesignation | nvarchar | YES | TBC | 🔴 |

| FatherDesignationLevel | nvarchar | YES | TBC | 🔴 |

| FatherDob | date | YES | TBC | 🔴 |

| FatherEPCard | nvarchar | YES | TBC | 🔴 |

| FatherEducation | nvarchar | YES | TBC | 🔴 |

| FatherEmail | nvarchar | YES | TBC | 🔴 |

| FatherEmploymentPassNo | nvarchar | YES | TBC | 🔴 |

| FatherEmploymentPassNoExpiryDate | date | YES | TBC | 🔴 |

| FatherEmploymentStatus | nvarchar | YES | TBC | 🔴 |

| FatherEmploymentStatusExpiryDate | date | YES | TBC | 🔴 |

| FatherEmploymentStatusID | bigint | YES | TBC | 🔴 |

| FatherHome_PhoneNo | nvarchar | YES | TBC | 🔴 |

| FatherIdentificationCardIssueDate | date | YES | TBC | 🔴 |

| FatherImg | nvarchar | YES | TBC | 🔴 |

| FatherLastName | nvarchar | YES | TBC | 🔴 |

| FatherNRIC | nvarchar | YES | TBC | 🔴 |

| FatherName | nvarchar | YES | TBC | 🔴 |

| FatherNameInRegionalLanguage | nvarchar | YES | TBC | 🔴 |

| FatherNationality | nvarchar | YES | TBC | 🔴 |

| FatherNatureOfBusiness | nvarchar | YES | TBC | 🔴 |

| FatherOccupation | nvarchar | YES | TBC | 🔴 |

| FatherOfficeAddress | nvarchar | YES | TBC | 🔴 |

| FatherOrganization | nvarchar | YES | TBC | 🔴 |

| FatherPassportNo | nvarchar | YES | TBC | 🔴 |

| FatherPassportcopy | nvarchar | YES | TBC | 🔴 |

| FatherSchoolAlumni | nvarchar | YES | TBC | 🔴 |

| FatherTitleName | nvarchar | YES | TBC | 🔴 |

| FatherWork_PhoneNo | nvarchar | YES | TBC | 🔴 |

| Fees_Effective_AdmissionDate | date | YES | TBC | 🔴 |

| FirstName | nvarchar | YES | TBC | 🔴 |

| Gender | nvarchar | YES | TBC | 🔴 |

| GuardianAadhaarNo | nvarchar | YES | TBC | 🔴 |

| GuardianAdhaarCardNo | nvarchar | YES | TBC | 🔴 |

| GuardianAge | int | YES | TBC | 🔴 |

| GuardianAnnualIncome | nvarchar | YES | TBC | 🔴 |

| GuardianContactNo | nvarchar | YES | TBC | 🔴 |

| GuardianDesignation | nvarchar | YES | TBC | 🔴 |

| GuardianDesignationLevel | nvarchar | YES | TBC | 🔴 |

| GuardianDob | date | YES | TBC | 🔴 |

| GuardianEducation | nvarchar | YES | TBC | 🔴 |

| GuardianEmail | nvarchar | YES | TBC | 🔴 |

| GuardianEmploymentPassNo | nvarchar | YES | TBC | 🔴 |

| GuardianEmploymentPassNoExpiryDate | date | YES | TBC | 🔴 |

| GuardianEmploymentStatus | nvarchar | YES | TBC | 🔴 |

| GuardianEmploymentStatusExpiryDate | date | YES | TBC | 🔴 |

| GuardianEmploymentStatusID | bigint | YES | TBC | 🔴 |

| GuardianHome_PhoneNo | nvarchar | YES | TBC | 🔴 |

| GuardianIdentificationCardIssueDate | date | YES | TBC | 🔴 |

| GuardianImg | nvarchar | YES | TBC | 🔴 |

| GuardianLastName | nvarchar | YES | TBC | 🔴 |

| GuardianName | nvarchar | YES | TBC | 🔴 |

| GuardianNationality | nvarchar | YES | TBC | 🔴 |

| GuardianNatureOfBusiness | nvarchar | YES | TBC | 🔴 |

| GuardianOccupation | nvarchar | YES | TBC | 🔴 |

| GuardianOfficeAddress | nvarchar | YES | TBC | 🔴 |

| GuardianOrganization | nvarchar | YES | TBC | 🔴 |

| GuardianPassportExpiryDate | date | YES | TBC | 🔴 |

| GuardianPassportIssueDate | date | YES | TBC | 🔴 |

| GuardianPassportNo | nvarchar | YES | TBC | 🔴 |

| GuardianSchoolAlumni | nvarchar | YES | TBC | 🔴 |

| GuardianTitleName | nvarchar | YES | TBC | 🔴 |

| GuardianWork_PhoneNo | nvarchar | YES | TBC | 🔴 |

| Guardian_Relationshipwithstudent | nvarchar | YES | TBC | 🔴 |

| Height | nvarchar | YES | TBC | 🔴 |

| Hostname | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IdentificationMarks | nvarchar | YES | TBC | 🔴 |

| IdentificationMarks_2 | nvarchar | YES | TBC | 🔴 |

| IsFatherJobTransferrable | bit | YES | TBC | 🔴 |

| IsFatherSchoolAlumni | bit | YES | TBC | 🔴 |

| IsGuardianJobTransferrable | bit | YES | TBC | 🔴 |

| IsGuardianSchoolAlumni | bit | YES | TBC | 🔴 |

| IsLumpsumApplicable | bit | YES | TBC | 🔴 |

| IsMotherJobTransferrable | bit | YES | TBC | 🔴 |

| IsMotherSchoolAlumni | bit | YES | TBC | 🔴 |

| IsOrphanOrAdopted | bit | YES | TBC | 🔴 |

| IsPortalLogin | bigint | YES | TBC | 🔴 |

| IsVIP | bit | YES | TBC | 🔴 |

| LaptopIssued | nvarchar | YES | TBC | 🔴 |

| LaptopSlno | nvarchar | YES | TBC | 🔴 |

| LastName | nvarchar | YES | TBC | 🔴 |

| LoginCount | int | YES | TBC | 🔴 |

| LoginStatus | int | YES | TBC | 🔴 |

| Lumpsum_Amount | bigint | YES | TBC | 🔴 |

| Lumpsum_Id | bigint | YES | TBC | 🔴 |

| MiddleName | nvarchar | YES | TBC | 🔴 |

| MotherAadhaarNo | nvarchar | YES | TBC | 🔴 |

| MotherAdhaarCardNo | nvarchar | YES | TBC | 🔴 |

| MotherAge | int | YES | TBC | 🔴 |

| MotherAnnualIncome | nvarchar | YES | TBC | 🔴 |

| MotherContactNo | nvarchar | YES | TBC | 🔴 |

| MotherDesignation | nvarchar | YES | TBC | 🔴 |

| MotherDesignationLevel | nvarchar | YES | TBC | 🔴 |

| MotherDob | date | YES | TBC | 🔴 |

| MotherEPCard | nvarchar | YES | TBC | 🔴 |

| MotherEducation | nvarchar | YES | TBC | 🔴 |

| MotherEmail | nvarchar | YES | TBC | 🔴 |

| MotherEmploymentPassNo | nvarchar | YES | TBC | 🔴 |

| MotherEmploymentPassNoExpiryDate | date | YES | TBC | 🔴 |

| MotherEmploymentStatus | nvarchar | YES | TBC | 🔴 |

| MotherEmploymentStatusExpiryDate | date | YES | TBC | 🔴 |

| MotherEmploymentStatusID | bigint | YES | TBC | 🔴 |

| MotherHome_PhoneNo | nvarchar | YES | TBC | 🔴 |

| MotherIdentificationCardIssueDate | date | YES | TBC | 🔴 |

| MotherImg | nvarchar | YES | TBC | 🔴 |

| MotherLastName | nvarchar | YES | TBC | 🔴 |

| MotherNRIC | nvarchar | YES | TBC | 🔴 |

| MotherName | nvarchar | YES | TBC | 🔴 |

| MotherNameInRegionalLanguage | nvarchar | YES | TBC | 🔴 |

| MotherNationality | nvarchar | YES | TBC | 🔴 |

| MotherNatureOfBusiness | nvarchar | YES | TBC | 🔴 |

| MotherOccupation | nvarchar | YES | TBC | 🔴 |

| MotherOfficeAddress | nvarchar | YES | TBC | 🔴 |

| MotherOrganization | nvarchar | YES | TBC | 🔴 |

| MotherPassportNo | nvarchar | YES | TBC | 🔴 |

| MotherPassportcopy | nvarchar | YES | TBC | 🔴 |

| MotherSchoolAlumni | nvarchar | YES | TBC | 🔴 |

| MotherTitleName | nvarchar | YES | TBC | 🔴 |

| MotherTongue_ID | bigint | YES | TBC | 🔴 |

| MotherTongue_Name | nvarchar | YES | TBC | 🔴 |

| MotherWork_PhoneNo | nvarchar | YES | TBC | 🔴 |

| Nationality_ID | bigint | YES | TBC | 🔴 |

| Nationality_Name | nvarchar | YES | TBC | 🔴 |

| NeetCount | nvarchar | YES | TBC | 🔴 |

| NeetMarks | nvarchar | YES | TBC | 🔴 |

| OldStudentId | bigint | YES | TBC | 🔴 |

| OnlineLinkExpiresOn | datetime | YES | TBC | 🔴 |

| OptionalSubject | nvarchar | YES | TBC | 🔴 |

| OtherReferenceNo | nvarchar | YES | TBC | 🔴 |

| Others | nvarchar | YES | TBC | 🔴 |

| PANNo | nvarchar | YES | TBC | 🔴 |

| PENNumber | nvarchar | YES | TBC | 🔴 |

| POBox | nvarchar | YES | TBC | 🔴 |

| Paid_Date | datetime | YES | TBC | 🔴 |

| ParentSignature | nvarchar | YES | TBC | 🔴 |

| ParentWeddingDate | date | YES | TBC | 🔴 |

| PassportExpiryDate | date | YES | TBC | 🔴 |

| PassportNo | nvarchar | YES | TBC | 🔴 |

| Password | nvarchar | YES | TBC | 🔴 |

| PaymentLinkID | nvarchar | YES | TBC | 🔴 |

| PerAddress | nvarchar | YES | TBC | 🔴 |

| PerCity | nvarchar | YES | TBC | 🔴 |

| PerCity_ID | bigint | YES | TBC | 🔴 |

| PerCountry | nvarchar | YES | TBC | 🔴 |

| PerCountry_ID | bigint | YES | TBC | 🔴 |

| PerDistrictId | bigint | YES | TBC | 🔴 |

| PerDistrictName | nvarchar | YES | TBC | 🔴 |

| PerEmail | nvarchar | YES | TBC | 🔴 |

| PerMobile | nvarchar | YES | TBC | 🔴 |

| PerPhone | nvarchar | YES | TBC | 🔴 |

| PerPincode | nvarchar | YES | TBC | 🔴 |

| PerState | nvarchar | YES | TBC | 🔴 |

| PerState_ID | bigint | YES | TBC | 🔴 |

| PerTaluk | nvarchar | YES | TBC | 🔴 |

| PerVillage | nvarchar | YES | TBC | 🔴 |

| Picked_Up_By | nvarchar | YES | TBC | 🔴 |

| PlaceOfBirth | nvarchar | YES | TBC | 🔴 |

| PortalMenus | nvarchar | YES | TBC | 🔴 |

| PortalStatus | bit | YES | TBC | 🔴 |

| PreferLangOne_ID | bigint | YES | TBC | 🔴 |

| PreferLangOne_Name | nvarchar | YES | TBC | 🔴 |

| PreferLangTwo_ID | bigint | YES | TBC | 🔴 |

| PreferLangTwo_Name | nvarchar | YES | TBC | 🔴 |

| PrimaryCommunicationMobile | nvarchar | YES | TBC | 🔴 |

| ReferenceDetails | nvarchar | YES | TBC | 🔴 |

| ReferenceLetter | nvarchar | YES | TBC | 🔴 |

| Religion_ID | bigint | YES | TBC | 🔴 |

| Religion_Name | nvarchar | YES | TBC | 🔴 |

| Residence | nvarchar | YES | TBC | 🔴 |

| Return_Date | datetime | YES | TBC | 🔴 |

| Room_ID | bigint | YES | TBC | 🔴 |

| Room_Name | nvarchar | YES | TBC | 🔴 |

| Route_ID | bigint | YES | TBC | 🔴 |

| Route_Name | nvarchar | YES | TBC | 🔴 |

| SATSNo | nvarchar | YES | TBC | 🔴 |

| SameAddress | bit | YES | TBC | 🔴 |

| SchoolLastStudied | nvarchar | YES | TBC | 🔴 |

| SearchImportedRecord | nvarchar | YES | TBC | 🔴 |

| SecondaryCommunicationMobile | nvarchar | YES | TBC | 🔴 |

| Security_Deposit_Amount | bigint | YES | TBC | 🔴 |

| Security_Deposit_Date | date | YES | TBC | 🔴 |

| SiblingStudyingInSchool | nvarchar | YES | TBC | 🔴 |

| SpecialNeeds | bit | YES | TBC | 🔴 |

| SportParticipation | nvarchar | YES | TBC | 🔴 |

| SportsName | nvarchar | YES | TBC | 🔴 |

| SportsPlayer | nvarchar | YES | TBC | 🔴 |

| StaffBranchID | varchar | YES | TBC | 🔴 |

| StaffChild | int | YES | TBC | 🔴 |

| StaffID | varchar | YES | TBC | 🔴 |

| StaffName | nvarchar | YES | TBC | 🔴 |

| StayWithParent | bit | YES | TBC | 🔴 |

| StayingWithGuardian | bit | YES | TBC | 🔴 |

| Stream | nvarchar | YES | TBC | 🔴 |

| StreamID | int | YES | TBC | 🔴 |

| StudentAdmittedSection | nvarchar | YES | TBC | 🔴 |

| StudentAge | nvarchar | YES | TBC | 🔴 |

| StudentBirthCertificate | nvarchar | YES | TBC | 🔴 |

| StudentClass_ID | bigint | YES | TBC | 🔴 |

| StudentCode | nvarchar | YES | TBC | 🔴 |

| StudentDepPassCard | nvarchar | YES | TBC | 🔴 |

| StudentDob | date | YES | TBC | 🔴 |

| StudentIdentificationCardExpiryDate | date | YES | TBC | 🔴 |

| StudentIdentificationCardIssueDate | date | YES | TBC | 🔴 |

| StudentIdentificationNo | nvarchar | YES | TBC | 🔴 |

| StudentImg | nvarchar | YES | TBC | 🔴 |

| StudentImmigrationStatus | nvarchar | YES | TBC | 🔴 |

| StudentImmigrationStatusID | bigint | YES | TBC | 🔴 |

| StudentImmunizationCertificate | nvarchar | YES | TBC | 🔴 |

| StudentMobileNo | nvarchar | YES | TBC | 🔴 |

| StudentNRIC | nvarchar | YES | TBC | 🔴 |

| StudentNameInRegionalLanguage | nvarchar | YES | TBC | 🔴 |

| StudentPassportExpiryDate | date | YES | TBC | 🔴 |

| StudentPassportcopy | nvarchar | YES | TBC | 🔴 |

| StudentReportCard | nvarchar | YES | TBC | 🔴 |

| StudentTCcopy | nvarchar | YES | TBC | 🔴 |

| SubCaste | nvarchar | YES | TBC | 🔴 |

| SubjectCombinations | nvarchar | YES | TBC | 🔴 |

| SubjectCombinationsID | bigint | YES | TBC | 🔴 |

| Token | nvarchar | YES | TBC | 🔴 |

| UnitNo | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Username | nvarchar | YES | TBC | 🔴 |

| VISAExpiryDate | date | YES | TBC | 🔴 |

| VISANo | nvarchar | YES | TBC | 🔴 |

| Vision | nvarchar | YES | TBC | 🔴 |

| Weight | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 SL_Student_PreviousSchool (16 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ExamResult | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| PreAddress | nvarchar | YES | TBC | 🔴 |

| PreBoardOfStudy | nvarchar | YES | TBC | 🔴 |

| PreCity | nvarchar | YES | TBC | 🔴 |

| PreClass | nvarchar | YES | TBC | 🔴 |

| PreLeavingReason | nvarchar | YES | TBC | 🔴 |

| PrePeriod | nvarchar | YES | TBC | 🔴 |

| PrePincode | nvarchar | YES | TBC | 🔴 |

| PreSchoolName | nvarchar | YES | TBC | 🔴 |

| PreState | nvarchar | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |

| Syllabus | nvarchar | YES | TBC | 🔴 |

| UDISENo | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 SL_Student_Siblings (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassName | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| PortalEnabled | bit | YES | TBC | 🔴 |

| SchoolName | nvarchar | YES | TBC | 🔴 |

| SectionName | nvarchar | YES | TBC | 🔴 |

| SiblingClassID | bigint | YES | TBC | 🔴 |

| SiblingName | nvarchar | YES | TBC | 🔴 |

| SiblingRelationship_ID | bigint | YES | TBC | 🔴 |

| SiblingSectionID | bigint | YES | TBC | 🔴 |

| SiblingStudentID | bigint | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |



---


#### ✅ SectionMaster (14 columns) — [CONFIRMED]


**Purpose:** Section list. Has Name (e.g. 'A', 'B', 'BRAINY', 'EXPERT' — varies by branch).


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| DisplayOrder | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 SpecialClassEntry (20 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_ID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | NO | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_by | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Isdeleted | bit | YES | TBC | 🔴 |

| Purpose | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| Section_ID | bigint | YES | TBC | 🔴 |

| SpecialClass_Date | datetime | YES | TBC | 🔴 |

| Staff_ID | bigint | YES | TBC | 🔴 |

| Staff_Name | nvarchar | YES | TBC | 🔴 |

| Subject_ID | bigint | YES | TBC | 🔴 |

| TimeFrom | nvarchar | YES | TBC | 🔴 |

| TimeTo | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 SpecialClassEntryDetails (3 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| ID | bigint | NO | TBC | 🔴 |

| SpecialClassEntryID | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |



---


#### 🔴 SpecialEventClassDetails (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_ID | bigint | YES | TBC | 🔴 |

| Class_Name | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| SpecialEvent_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 StaffEvaluationObservationDetails (22 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_ID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| EvaluationName | nvarchar | YES | TBC | 🔴 |

| Evaluation_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Observation | nvarchar | YES | TBC | 🔴 |

| Observation_ID | bigint | YES | TBC | 🔴 |

| Rating | bigint | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| Section_ID | bigint | YES | TBC | 🔴 |

| StaffType_ID | bigint | YES | TBC | 🔴 |

| Staff_ID | bigint | YES | TBC | 🔴 |

| Subject_ID | bigint | YES | TBC | 🔴 |

| SubmissionDate | datetime | YES | TBC | 🔴 |

| Update_Date | datetime | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |



---


#### 🔴 StaffObservationDetails (14 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Criteria_Name | nvarchar | YES | TBC | 🔴 |

| EvaluationCriteria_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsChecked | bit | YES | TBC | 🔴 |

| IsDeleted | bigint | YES | TBC | 🔴 |

| ObsDescription | nvarchar | YES | TBC | 🔴 |

| ObservationID | bigint | YES | TBC | 🔴 |

| Rating_ID | bigint | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| SubmissionDate | datetime | YES | TBC | 🔴 |

| SubmittedBy | bigint | YES | TBC | 🔴 |

| Weightage | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 StaffObservationMaster (15 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Descriptions | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| PlannedFromDate | datetime | YES | TBC | 🔴 |

| PlannedToDate | datetime | YES | TBC | 🔴 |

| StaffType_ID | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### ✅ Staff_Attendance (16 columns) — [CONFIRMED]


**Purpose:** Daily staff attendance. Has Attendance_Date, Attendance_Status_ID, Staff_ID.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Attendance_Date | date | YES | TBC | 🔴 |

| Attendance_Reason | nvarchar | YES | TBC | 🔴 |

| Attendance_Status_ID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| InTime | nvarchar | YES | TBC | 🔴 |

| OutTime | nvarchar | YES | TBC | 🔴 |

| StaffType_ID | bigint | YES | TBC | 🔴 |

| Staff_ID | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 Staff_Attendance_InOutTime (16 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Attendance_Date | date | YES | TBC | 🔴 |

| Attendance_Reason | nvarchar | YES | TBC | 🔴 |

| Attendance_Status_ID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| InTime | datetime | YES | TBC | 🔴 |

| OutTime | datetime | YES | TBC | 🔴 |

| StaffType_ID | bigint | YES | TBC | 🔴 |

| Staff_ID | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### ✅ StudentAcademicDetail (34 columns) — [CONFIRMED]


**Purpose:** Per-year student enrollment. Has ClassID, SectionID, AcademicYearID, IsActive, IsPromoted, IsNewAdmission, IsTCIssued, RollNo, TransportRequired, HostelRequired.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ClassName | nvarchar | YES | TBC | 🔴 |

| ExamRegistrationNo | nvarchar | YES | TBC | 🔴 |

| FoodRequired | bit | YES | TBC | 🔴 |

| HostelRequired | bit | YES | TBC | 🔴 |

| HouseID | bigint | YES | TBC | 🔴 |

| HouseName | varchar | YES | TBC | 🔴 |

| IDCardNo | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsActive | bit | YES | 1 = currently enrolled; 0 = inactive. | ✅ |

| IsLumpsumApplicable | bit | YES | TBC | 🔴 |

| IsNEETJEE | bit | YES | TBC | 🔴 |

| IsNewAdmission | bit | YES | 1 = new admission this year; 0 = returning student. | ✅ |

| IsPromoted | bit | YES | 1 = promoted to the next class; 0 = not promoted. | ✅ |

| IsSectionChanged | bit | YES | TBC | 🔴 |

| IsTCIssued | bit | YES | 1 = TC issued (student has left); NULL/0 = still enrolled. Filter (IsTCIssued = 0 OR IsTCIssued IS NULL) for current students. | ✅ |

| Lumpsum_Amount | bigint | YES | TBC | 🔴 |

| Lumpsum_Id | bigint | YES | TBC | 🔴 |

| OtherExam | varchar | YES | TBC | 🔴 |

| OtherExamName | varchar | YES | TBC | 🔴 |

| Paid_Date | datetime | YES | TBC | 🔴 |

| PaymentTypeId | int | YES | TBC | 🔴 |

| Return_Date | datetime | YES | TBC | 🔴 |

| RollNo | nvarchar | YES | The student's roll number in their class/section. | ✅ |

| SMSFile | nvarchar | YES | TBC | 🔴 |

| SectionChangeReason | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| StudentFeeCategoryID | bigint | YES | FK → StudentFeeCategory.ID (fee category — e.g. 'Regular', 'Staff Child'). | ✅ |

| StudentFeeSubCategoryID | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| StudentRollNowithoutPrefix | bigint | YES | TBC | 🔴 |

| TCIssuedDate | datetime | YES | The date the TC was issued. Used by Sp_Chalo_ReportFeeOustandingCategoryWise to exclude students who left BEFORE the term started. | ✅ |

| TransportRequired | bit | YES | nvarchar(10) — stored as 'True'/'False' or 1/0 (inconsistent across SPs). | ✅ |



**Foreign keys:**

- StudentID → Student_Master.ID (CONFIRMED)


- ClassID → ClassMaster.ID (CONFIRMED)


- SectionID → SectionMaster.ID (CONFIRMED)


- AcademicYearID → Branch_Academic_Details.Id (CONFIRMED)
 — PK is lowercase 'Id'




---


#### 🔴 StudentAnnualRemarks (18 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | NO | TBC | 🔴 |

| CombinedExamId | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bigint | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| RemarksTypeID | bigint | YES | TBC | 🔴 |

| Remarks_ID | bigint | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| SubjectID | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### ✅ StudentAttendance (16 columns) — [CONFIRMED]


**Purpose:** Daily student attendance. Has Attendance_Date, Attendance_Status_ID (1=present, 2=absent, 3=late, 4=other), Student_ID, Class_ID, BranchID.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Attendance_Date | date | YES | The date of attendance. | ✅ |

| Attendance_Reason | nvarchar | YES | TBC | 🔴 |

| Attendance_Status_ID | bigint | YES | 1=present, 2=absent, 3=late, 4=other. The attendance status enum. | ✅ |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_ID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Section_ID | bigint | YES | TBC | 🔴 |

| StudentRollNo | nvarchar | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



**Foreign keys:**

- Student_ID → Student_Master.ID (CONFIRMED)


- Class_ID → ClassMaster.ID (CONFIRMED)




---


#### 🔴 StudentAttendancePresentMaster (8 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_Id | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| Present_Date | date | YES | TBC | 🔴 |

| Section_Id | bigint | YES | TBC | 🔴 |

| Staff_TypeId | bigint | YES | TBC | 🔴 |

| Type | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 StudentContractConfiguration (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| LateAdmission | nvarchar | YES | TBC | 🔴 |

| PhotoContestForm | nvarchar | YES | TBC | 🔴 |

| TermsAndConditions | nvarchar | YES | TBC | 🔴 |

| TransportAgreement | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 StudentGatePass_Entry (28 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdmissionNO | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ClassName | nvarchar | YES | TBC | 🔴 |

| ContactNo | nvarchar | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| EscortPerson_Name | nvarchar | YES | TBC | 🔴 |

| EscortRelation_ID | bigint | YES | TBC | 🔴 |

| EscortRelation_Name | nvarchar | YES | TBC | 🔴 |

| GatepassDate | date | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| PermissionGivenBy | nvarchar | YES | TBC | 🔴 |

| Reason | text | YES | TBC | 🔴 |

| ReferenceNO | nvarchar | YES | TBC | 🔴 |

| RequestedFrom | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| SectionName | nvarchar | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| StudentName | nvarchar | YES | TBC | 🔴 |

| TimeofLeaving | time | YES | TBC | 🔴 |

| TimeofReturn | time | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 StudentHealthEvaluation (21 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BMI | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Chest | nvarchar | YES | TBC | 🔴 |

| Class_ID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Dental | nvarchar | YES | TBC | 🔴 |

| EvaluationDate | date | YES | TBC | 🔴 |

| HealthRemarks | nvarchar | YES | TBC | 🔴 |

| Height | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Section_ID | bigint | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Vision | nvarchar | YES | TBC | 🔴 |

| Weight | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 StudentHealthRemarks (10 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Dental | nvarchar | YES | TBC | 🔴 |

| EvaluationDate | datetime | YES | TBC | 🔴 |

| HealthRemark | nvarchar | YES | TBC | 🔴 |

| Height | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| StudentHealthID | bigint | YES | TBC | 🔴 |

| Vision | nvarchar | YES | TBC | 🔴 |

| Weight | nvarchar | YES | TBC | 🔴 |



---


#### ✅ StudentMarkDetails (16 columns) — [CONFIRMED]


**Purpose:** Per-student exam marks. Has Marks, Grade, Deleted (not IsDeleted). Does NOT have MinMark (lives on ExamConfigurationEvaluationDetails).


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | NO | TBC | 🔴 |

| CreatedOn | datetime | NO | TBC | 🔴 |

| Deleted | bit | NO | The soft-delete column (NOT IsDeleted). | ✅ |

| EvalHierID | bigint | YES | FK → ExamConfigurationEvaluationDetails.ID (the exam config that holds MinMark). | ✅ |

| Grade | nvarchar | YES | TBC | 🔴 |

| HeaderID | bigint | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IDS | varchar | YES | TBC | 🔴 |

| Marks | numeric | NO | The student's mark for this exam entry (numeric 18,2). | ✅ |

| Others | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedOn | datetime | YES | TBC | 🔴 |



**Foreign keys:**

- HeaderID → StudentMarkMaster.ID (PARTIAL)


- StudentID → Student_Master.ID (PARTIAL)




---


#### 🔴 StudentMarkEntrySettings (22 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ExamTypeID | bigint | YES | TBC | 🔴 |

| FreezStatus | bit | YES | TBC | 🔴 |

| FreezedBy | bigint | YES | TBC | 🔴 |

| FreezedDate | datetime | YES | TBC | 🔴 |

| GeneratedBy | bigint | YES | TBC | 🔴 |

| GeneratedDate | datetime | YES | TBC | 🔴 |

| GenerationStatus | bit | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| MarkEntryCompletedBy | bigint | YES | TBC | 🔴 |

| MarkEntryCompletedDate | datetime | YES | TBC | 🔴 |

| MarkEntryStatus | bit | YES | TBC | 🔴 |

| PortalProgressCardPublishStatus | bit | YES | TBC | 🔴 |

| PortalProgressCardPublishedBy | bigint | YES | TBC | 🔴 |

| PortalProgressCardPublishedDate | datetime | YES | TBC | 🔴 |

| PublishStatus | bit | YES | TBC | 🔴 |

| PublishedBy | bigint | YES | TBC | 🔴 |

| PublishedDate | datetime | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| SubjectID | bigint | YES | TBC | 🔴 |



---


#### 🔴 StudentMarkEntrySettingsActivityLog (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| ActivityType | varchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| LoggedBy | bigint | YES | TBC | 🔴 |

| LoggedDate | datetime | YES | TBC | 🔴 |

| MarkEntrySettingsID | bigint | YES | TBC | 🔴 |



---


#### 🟡 StudentMarkMaster (12 columns) — [PARTIAL]


**Purpose:** Exam marks header. Has ExamTypeID → ExamTypeMaster.ID (which has TermID → ExamTermMaster.ID).


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | NO | TBC | 🔴 |

| CreatedOn | datetime | NO | TBC | 🔴 |

| Deleted | bit | NO | TBC | 🔴 |

| ExamSettingID | bigint | YES | TBC | 🔴 |

| ExamTypeID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedOn | datetime | YES | TBC | 🔴 |



**Foreign keys:**

- ExamTypeID → ExamTypeMaster.ID (PARTIAL)




---


#### 🔴 StudentMarkRemarksMaster (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Deleted | bit | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Name | nvarchar | NO | TBC | 🔴 |



---


#### 🔴 StudentObservation (17 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Observation | nvarchar | YES | TBC | 🔴 |

| ObservationCategoryID | bigint | YES | TBC | 🔴 |

| ObservationSubCategoryID | bigint | YES | TBC | 🔴 |

| RequestType | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 StudentObservationRequest (20 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| ApprovalStatus | int | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Observation | nvarchar | YES | TBC | 🔴 |

| ObservationCategoryID | bigint | YES | TBC | 🔴 |

| ObservationDocument | nvarchar | YES | TBC | 🔴 |

| ObservationSubCategoryID | bigint | YES | TBC | 🔴 |

| Reason | nvarchar | YES | TBC | 🔴 |

| RequestType | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 StudentProfileVerification (41 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| ColumnName | nvarchar | YES | TBC | 🔴 |

| ContractApprovalStatus | int | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedOn | datetime | YES | TBC | 🔴 |

| EmergencyContactImmigrationcopy | nvarchar | YES | TBC | 🔴 |

| EmergencyContactImmigrationcopy1 | nvarchar | YES | TBC | 🔴 |

| FatherImmigrationcopy | nvarchar | YES | TBC | 🔴 |

| FatherImmigrationcopy1 | nvarchar | YES | TBC | 🔴 |

| FatherPassportcopy | nvarchar | YES | TBC | 🔴 |

| FatherPassportcopy1 | nvarchar | YES | TBC | 🔴 |

| GuardianImmigrationcopy | nvarchar | YES | TBC | 🔴 |

| GuardianImmigrationcopy1 | nvarchar | YES | TBC | 🔴 |

| GuardianNRICcopy | nvarchar | YES | TBC | 🔴 |

| GuardianNRICcopy1 | nvarchar | YES | TBC | 🔴 |

| GuardianPassportcopy | nvarchar | YES | TBC | 🔴 |

| GuardianPassportcopy1 | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDocumentVerified | bit | YES | TBC | 🔴 |

| IsVerified | bit | YES | TBC | 🔴 |

| LateAdmissionDeclineReason | nvarchar | YES | TBC | 🔴 |

| LateAdmissionStatus | bigint | YES | TBC | 🔴 |

| MotherImmigrationcopy | nvarchar | YES | TBC | 🔴 |

| MotherImmigrationcopy1 | nvarchar | YES | TBC | 🔴 |

| MotherPassportcopy | nvarchar | YES | TBC | 🔴 |

| MotherPassportcopy1 | nvarchar | YES | TBC | 🔴 |

| OTP | nvarchar | YES | TBC | 🔴 |

| PhotoConsentFormDeclineReason | nvarchar | YES | TBC | 🔴 |

| PhotoConsentFormStatus | bigint | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| StudentBirthCertificate | nvarchar | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| StudentImmigrationcopy | nvarchar | YES | TBC | 🔴 |

| StudentImmigrationcopy1 | nvarchar | YES | TBC | 🔴 |

| StudentPassportcopy | nvarchar | YES | TBC | 🔴 |

| StudentPassportcopy1 | nvarchar | YES | TBC | 🔴 |

| TermsAndConditionStatus | bigint | YES | TBC | 🔴 |

| TermsAndConditionsDeclineReason | nvarchar | YES | TBC | 🔴 |

| TransportAgreementDeclineReason | nvarchar | YES | TBC | 🔴 |

| TransportAgreementStatus | bigint | YES | TBC | 🔴 |

| UpdatedOn | datetime | YES | TBC | 🔴 |



---


#### 🔴 StudentPromotionCancellationLog (15 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdmissionNo | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CancelledDate | datetime | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| CurrentClass_ID | bigint | YES | TBC | 🔴 |

| CurrentSection_ID | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| FeesPaid | decimal | YES | TBC | 🔴 |

| ID | int | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| PreviousYearName | nvarchar | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |



---


#### 🔴 StudentPromotionStatus (21 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdmissionNo | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | NO | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| ExamTermID | bigint | YES | TBC | 🔴 |

| ID | int | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| NonPromotedText | nvarchar | YES | TBC | 🔴 |

| PromotedStatusID | bigint | YES | TBC | 🔴 |

| PromotedStatusName | nvarchar | YES | TBC | 🔴 |

| PromotedText | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| StudentName | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 StudentRemarksTypeMaster (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Deleted | bit | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Name | nvarchar | NO | TBC | 🔴 |



---


#### 🔴 StudentSelfAssessment (20 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Animals | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | NO | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| FavColours | nvarchar | YES | TBC | 🔴 |

| FavFoods | nvarchar | YES | TBC | 🔴 |

| FavGames | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IiveIn | nvarchar | YES | TBC | 🔴 |

| IsDeleted | bigint | YES | TBC | 🔴 |

| MyFriends | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| ThingsILike | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 StudentStaffSMSEmailDetails (14 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Message | text | YES | TBC | 🔴 |

| MessageFor | nvarchar | YES | TBC | 🔴 |

| MessageSender | nvarchar | YES | TBC | 🔴 |

| MessageSentDate | datetime | YES | TBC | 🔴 |

| MessageSentTo | nvarchar | YES | TBC | 🔴 |

| MessageType | nvarchar | YES | TBC | 🔴 |

| Screen | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| StaffID | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |



---


#### 🔴 StudentSubjectGrouping (16 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| GroupSubject | nvarchar | YES | TBC | 🔴 |

| GroupSubjectID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| SubjectID | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 StudentTermAttendance (16 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | NO | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bigint | YES | TBC | 🔴 |

| PresentDays | numeric | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| TermID | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |

| WorkingDays | numeric | YES | TBC | 🔴 |



---


#### 🔴 StudentTermRemarks (19 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | NO | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| ExamTypeID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bigint | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| RemarksTypeID | bigint | YES | TBC | 🔴 |

| Remarks_ID | bigint | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| SubjectID | bigint | YES | TBC | 🔴 |

| TermID | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 Student_Activity (7 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Achievement | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |



---


#### 🔴 Student_AuthorizedPerson (8 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AuthorizedPerson | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| Email | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| Phone | nvarchar | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 Student_ContractForm (23 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ContractApprovalStatus | int | YES | TBC | 🔴 |

| ContractStatus | bigint | YES | TBC | 🔴 |

| DeclineReason | nvarchar | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| DocCreatedBy | nvarchar | YES | TBC | 🔴 |

| DocCreatedDate | datetime | YES | TBC | 🔴 |

| DocUpdatedBy | nvarchar | YES | TBC | 🔴 |

| DocUpdatedDate | datetime | YES | TBC | 🔴 |

| DocumentName | nvarchar | YES | TBC | 🔴 |

| DocumentType | nvarchar | YES | TBC | 🔴 |

| DocumentUrl | nvarchar | YES | TBC | 🔴 |

| GeneratedPath | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| ModificationReason | nvarchar | YES | TBC | 🔴 |

| ParentSignDate | datetime | YES | TBC | 🔴 |

| ParentSignPath | nvarchar | YES | TBC | 🔴 |

| ParentSignUrl | nvarchar | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |

| UploadedDocumentUrl | nvarchar | YES | TBC | 🔴 |

| UploadedPath | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 Student_Data_Import (113 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdhaarCardNo | nvarchar | YES | TBC | 🔴 |

| AdmissionDate | date | YES | TBC | 🔴 |

| AdmissionNo | nvarchar | YES | TBC | 🔴 |

| AdmissionTypeName | nvarchar | YES | TBC | 🔴 |

| AdmissionType_ID | bigint | YES | TBC | 🔴 |

| Allergies | nvarchar | YES | TBC | 🔴 |

| ApplicationNo | nvarchar | YES | TBC | 🔴 |

| BloodGroup_ID | bigint | YES | TBC | 🔴 |

| BloodGroup_Name | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CasteID | bigint | YES | TBC | 🔴 |

| CasteName | nvarchar | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ClassName | nvarchar | YES | TBC | 🔴 |

| ComAddress | nvarchar | YES | TBC | 🔴 |

| ComCity | nvarchar | YES | TBC | 🔴 |

| ComCity_ID | bigint | YES | TBC | 🔴 |

| ComCountry | nvarchar | YES | TBC | 🔴 |

| ComCountry_ID | bigint | YES | TBC | 🔴 |

| ComEmail | nvarchar | YES | TBC | 🔴 |

| ComPhone | nvarchar | YES | TBC | 🔴 |

| ComPincode | nvarchar | YES | TBC | 🔴 |

| ComState | nvarchar | YES | TBC | 🔴 |

| ComState_ID | bigint | YES | TBC | 🔴 |

| CommunicationMobileNo | nvarchar | YES | TBC | 🔴 |

| CommunicationeMailID | nvarchar | YES | TBC | 🔴 |

| Community_ID | bigint | YES | TBC | 🔴 |

| Community_Name | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Dental | nvarchar | YES | TBC | 🔴 |

| Disability_Name | nvarchar | YES | TBC | 🔴 |

| EMISNo | nvarchar | YES | TBC | 🔴 |

| EnrollmentNo | nvarchar | YES | TBC | 🔴 |

| FatherAge | int | YES | TBC | 🔴 |

| FatherAnnualIncome | nvarchar | YES | TBC | 🔴 |

| FatherContactNo | nvarchar | YES | TBC | 🔴 |

| FatherDob | date | YES | TBC | 🔴 |

| FatherEducation | nvarchar | YES | TBC | 🔴 |

| FatherEmail | nvarchar | YES | TBC | 🔴 |

| FatherName | nvarchar | YES | TBC | 🔴 |

| FatherOccupation | nvarchar | YES | TBC | 🔴 |

| FatherOrganization | nvarchar | YES | TBC | 🔴 |

| Fees_Effective_AdmissionDate | date | YES | TBC | 🔴 |

| FirstName | nvarchar | YES | TBC | 🔴 |

| Gender | nvarchar | YES | TBC | 🔴 |

| GuardianAge | int | YES | TBC | 🔴 |

| GuardianAnnualIncome | nvarchar | YES | TBC | 🔴 |

| GuardianContactNo | nvarchar | YES | TBC | 🔴 |

| GuardianDob | date | YES | TBC | 🔴 |

| GuardianEducation | nvarchar | YES | TBC | 🔴 |

| GuardianEmail | nvarchar | YES | TBC | 🔴 |

| GuardianName | nvarchar | YES | TBC | 🔴 |

| GuardianOccupation | nvarchar | YES | TBC | 🔴 |

| GuardianOrganization | nvarchar | YES | TBC | 🔴 |

| Height | nvarchar | YES | TBC | 🔴 |

| HostelRequired | bit | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IdentificationMarks | nvarchar | YES | TBC | 🔴 |

| IsNewAdmission | bit | YES | TBC | 🔴 |

| LastName | nvarchar | YES | TBC | 🔴 |

| MiddleName | nvarchar | YES | TBC | 🔴 |

| MotherAge | int | YES | TBC | 🔴 |

| MotherAnnualIncome | nvarchar | YES | TBC | 🔴 |

| MotherContactNo | nvarchar | YES | TBC | 🔴 |

| MotherDob | date | YES | TBC | 🔴 |

| MotherEducation | nvarchar | YES | TBC | 🔴 |

| MotherEmail | nvarchar | YES | TBC | 🔴 |

| MotherName | nvarchar | YES | TBC | 🔴 |

| MotherOccupation | nvarchar | YES | TBC | 🔴 |

| MotherOrganization | nvarchar | YES | TBC | 🔴 |

| MotherTongue_ID | bigint | YES | TBC | 🔴 |

| MotherTongue_Name | nvarchar | YES | TBC | 🔴 |

| Nationality_ID | bigint | YES | TBC | 🔴 |

| Nationality_Name | nvarchar | YES | TBC | 🔴 |

| Others | nvarchar | YES | TBC | 🔴 |

| PANNo | nvarchar | YES | TBC | 🔴 |

| PerAddress | nvarchar | YES | TBC | 🔴 |

| PerCity | nvarchar | YES | TBC | 🔴 |

| PerCity_ID | bigint | YES | TBC | 🔴 |

| PerCountry | nvarchar | YES | TBC | 🔴 |

| PerCountry_ID | bigint | YES | TBC | 🔴 |

| PerEmail | nvarchar | YES | TBC | 🔴 |

| PerPhone | nvarchar | YES | TBC | 🔴 |

| PerPincode | nvarchar | YES | TBC | 🔴 |

| PerState | nvarchar | YES | TBC | 🔴 |

| PerState_ID | bigint | YES | TBC | 🔴 |

| PreferLangOne_ID | bigint | YES | TBC | 🔴 |

| PreferLangOne_Name | nvarchar | YES | TBC | 🔴 |

| PreferLangTwo_ID | bigint | YES | TBC | 🔴 |

| PreferLangTwo_Name | nvarchar | YES | TBC | 🔴 |

| Religion_ID | bigint | YES | TBC | 🔴 |

| Religion_Name | nvarchar | YES | TBC | 🔴 |

| SameAddress | bit | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| SectionName | nvarchar | YES | TBC | 🔴 |

| StaffChild | int | YES | TBC | 🔴 |

| StaffName | nvarchar | YES | TBC | 🔴 |

| StudentAge | int | YES | TBC | 🔴 |

| StudentClass_ID | bigint | YES | TBC | 🔴 |

| StudentCode | nvarchar | YES | TBC | 🔴 |

| StudentDob | date | YES | TBC | 🔴 |

| StudentFeeCategory_ID | bigint | YES | TBC | 🔴 |

| StudentFeeCategory_Name | nvarchar | YES | TBC | 🔴 |

| StudentFeeSUBCategory_ID | bigint | YES | TBC | 🔴 |

| StudentFeeSUBCategory_Name | nvarchar | YES | TBC | 🔴 |

| StudentImg | nvarchar | YES | TBC | 🔴 |

| StudentImgPath | nvarchar | YES | TBC | 🔴 |

| StudentRollNo | nvarchar | YES | TBC | 🔴 |

| TransportRequired | bit | YES | TBC | 🔴 |

| Vision | nvarchar | YES | TBC | 🔴 |

| Weight | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 Student_Document (8 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| DocumentName | nvarchar | YES | TBC | 🔴 |

| DocumentType | nvarchar | YES | TBC | 🔴 |

| DocumentUrl | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |



---


#### ✅ Student_Master (328 columns) — [CONFIRMED]


**Purpose:** Static student profile. Has NO ClassID, SectionID, or AcademicYearID (those live on StudentAcademicDetail). Has FirstName/MiddleName/LastName (NOT Staff_FirstName).


**⚠️ Gotcha:** Has NO ClassID, SectionID, or AcademicYearID — those live on StudentAcademicDetail.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| APAARID | nvarchar | YES | TBC | 🔴 |

| AdhaarCardNo | nvarchar | YES | TBC | 🔴 |

| AdmissionCategoryID | bigint | YES | TBC | 🔴 |

| AdmissionDate | date | YES | TBC | 🔴 |

| AdmissionNo | nvarchar | YES | TBC | 🔴 |

| AdmissionPriorityID | bigint | YES | TBC | 🔴 |

| AdmissionTypeName | nvarchar | YES | TBC | 🔴 |

| AdmissionType_ID | bigint | YES | TBC | 🔴 |

| AdmissionWaiverOptionId | bigint | YES | TBC | 🔴 |

| AdmissionWaiverOptionName | nvarchar | YES | TBC | 🔴 |

| AgeAsOn | nvarchar | YES | TBC | 🔴 |

| Allergies | nvarchar | YES | TBC | 🔴 |

| Applicant_ID | bigint | YES | TBC | 🔴 |

| ApplicationNo | nvarchar | YES | TBC | 🔴 |

| AvailableCredit | numeric | YES | TBC | 🔴 |

| BMI | nvarchar | YES | TBC | 🔴 |

| BankAccountNo | nvarchar | YES | TBC | 🔴 |

| BankAddress | nvarchar | YES | TBC | 🔴 |

| BankIfscCode | nvarchar | YES | TBC | 🔴 |

| BankName | nvarchar | YES | TBC | 🔴 |

| Block_ID | bigint | YES | TBC | 🔴 |

| Block_Name | nvarchar | YES | TBC | 🔴 |

| BloodGroup_ID | bigint | YES | TBC | 🔴 |

| BloodGroup_Name | nvarchar | YES | TBC | 🔴 |

| BoardingPoint_ID | bigint | YES | TBC | 🔴 |

| BoardingPoint_Name | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CanditateID | nvarchar | YES | TBC | 🔴 |

| CasteID | bigint | YES | TBC | 🔴 |

| Chest | nvarchar | YES | TBC | 🔴 |

| ChildBornOrder | int | YES | TBC | 🔴 |

| ChildDisadvantagedGroup | nvarchar | YES | TBC | 🔴 |

| ClassLastStudied | nvarchar | YES | TBC | 🔴 |

| ComAddress | nvarchar | YES | TBC | 🔴 |

| ComCity | nvarchar | YES | TBC | 🔴 |

| ComCity_ID | bigint | YES | TBC | 🔴 |

| ComCountry | nvarchar | YES | TBC | 🔴 |

| ComCountry_ID | bigint | YES | TBC | 🔴 |

| ComDistrictId | bigint | YES | TBC | 🔴 |

| ComDistrictName | nvarchar | YES | TBC | 🔴 |

| ComEmail | nvarchar | YES | TBC | 🔴 |

| ComMobile | nvarchar | YES | TBC | 🔴 |

| ComPhone | nvarchar | YES | TBC | 🔴 |

| ComPincode | nvarchar | YES | TBC | 🔴 |

| ComPlace | nvarchar | YES | TBC | 🔴 |

| ComState | nvarchar | YES | TBC | 🔴 |

| ComState_ID | bigint | YES | TBC | 🔴 |

| ComTaluk | nvarchar | YES | TBC | 🔴 |

| ComVillage | nvarchar | YES | TBC | 🔴 |

| CombinedSubjects | nvarchar | YES | TBC | 🔴 |

| CommunicationMailID | nvarchar | YES | TBC | 🔴 |

| CommunicationMobileNo | nvarchar | YES | TBC | 🔴 |

| CommunicationeMailID | nvarchar | YES | TBC | 🔴 |

| CommunityCertificate | nvarchar | YES | TBC | 🔴 |

| Community_ID | bigint | YES | TBC | 🔴 |

| Community_Name | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| DateOfPassportIssue | date | YES | TBC | 🔴 |

| DateOfVISAIssue | date | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Dental | nvarchar | YES | TBC | 🔴 |

| Disability_ID | int | YES | TBC | 🔴 |

| Disability_Name | nvarchar | YES | TBC | 🔴 |

| DocumentsCheckList | nvarchar | YES | TBC | 🔴 |

| EMISNo | nvarchar | YES | TBC | 🔴 |

| EducationMedium | nvarchar | YES | TBC | 🔴 |

| EmergencyContactIdentificationNo | nvarchar | YES | TBC | 🔴 |

| EmergencyContactImmigrationcopy | nvarchar | YES | TBC | 🔴 |

| EmergencyContactImmigrationcopy1 | nvarchar | YES | TBC | 🔴 |

| EmergencyContactPersonMobileNo | nvarchar | YES | TBC | 🔴 |

| EmergencyContactPersonName | nvarchar | YES | TBC | 🔴 |

| EmergencyContactPersonRelationship | nvarchar | YES | TBC | 🔴 |

| EnrollmentNo | nvarchar | YES | TBC | 🔴 |

| ExtraCurricularActivity | nvarchar | YES | TBC | 🔴 |

| FatherAadhaarNo | nvarchar | YES | TBC | 🔴 |

| FatherAdhaarCardNo | nvarchar | YES | TBC | 🔴 |

| FatherAge | int | YES | TBC | 🔴 |

| FatherAnnualIncome | nvarchar | YES | TBC | 🔴 |

| FatherContactNo | nvarchar | YES | TBC | 🔴 |

| FatherDesignation | nvarchar | YES | TBC | 🔴 |

| FatherDesignationLevel | nvarchar | YES | TBC | 🔴 |

| FatherDob | date | YES | TBC | 🔴 |

| FatherEPCard | nvarchar | YES | TBC | 🔴 |

| FatherEducation | nvarchar | YES | TBC | 🔴 |

| FatherEmail | nvarchar | YES | TBC | 🔴 |

| FatherEmploymentPassNo | nvarchar | YES | TBC | 🔴 |

| FatherEmploymentPassNoExpiryDate | date | YES | TBC | 🔴 |

| FatherEmploymentPassNoIssueDate | date | YES | TBC | 🔴 |

| FatherEmploymentStatus | nvarchar | YES | TBC | 🔴 |

| FatherEmploymentStatusExpiryDate | date | YES | TBC | 🔴 |

| FatherEmploymentStatusID | bigint | YES | TBC | 🔴 |

| FatherHome_PhoneNo | nvarchar | YES | TBC | 🔴 |

| FatherIdentificationCardIssueDate | date | YES | TBC | 🔴 |

| FatherImg | nvarchar | YES | TBC | 🔴 |

| FatherImmigrationcopy | nvarchar | YES | TBC | 🔴 |

| FatherImmigrationcopy1 | nvarchar | YES | TBC | 🔴 |

| FatherLastName | nvarchar | YES | TBC | 🔴 |

| FatherNRIC | nvarchar | YES | TBC | 🔴 |

| FatherName | nvarchar | YES | TBC | 🔴 |

| FatherNameInRegionalLanguage | nvarchar | YES | TBC | 🔴 |

| FatherNationality | nvarchar | YES | TBC | 🔴 |

| FatherNatureOfBusiness | nvarchar | YES | TBC | 🔴 |

| FatherOccupation | nvarchar | YES | TBC | 🔴 |

| FatherOfficeAddress | nvarchar | YES | TBC | 🔴 |

| FatherOrganization | nvarchar | YES | TBC | 🔴 |

| FatherPassportNo | nvarchar | YES | TBC | 🔴 |

| FatherPassportcopy | nvarchar | YES | TBC | 🔴 |

| FatherPassportcopy1 | nvarchar | YES | TBC | 🔴 |

| FatherSchoolAlumni | nvarchar | YES | TBC | 🔴 |

| FatherTitleName | nvarchar | YES | TBC | 🔴 |

| FatherWork_PhoneNo | nvarchar | YES | TBC | 🔴 |

| Fees_Effective_AdmissionDate | date | YES | TBC | 🔴 |

| FirstName | nvarchar | YES | TBC | 🔴 |

| Gender | nvarchar | YES | TBC | 🔴 |

| GuardianAadhaarNo | nvarchar | YES | TBC | 🔴 |

| GuardianAdhaarCardNo | nvarchar | YES | TBC | 🔴 |

| GuardianAge | int | YES | TBC | 🔴 |

| GuardianAnnualIncome | nvarchar | YES | TBC | 🔴 |

| GuardianContactNo | nvarchar | YES | TBC | 🔴 |

| GuardianDesignation | nvarchar | YES | TBC | 🔴 |

| GuardianDesignationLevel | nvarchar | YES | TBC | 🔴 |

| GuardianDob | date | YES | TBC | 🔴 |

| GuardianEducation | nvarchar | YES | TBC | 🔴 |

| GuardianEmail | nvarchar | YES | TBC | 🔴 |

| GuardianEmploymentPassNo | nvarchar | YES | TBC | 🔴 |

| GuardianEmploymentPassNoExpiryDate | date | YES | TBC | 🔴 |

| GuardianEmploymentPassNoIssueDate | date | YES | TBC | 🔴 |

| GuardianEmploymentStatus | nvarchar | YES | TBC | 🔴 |

| GuardianEmploymentStatusExpiryDate | date | YES | TBC | 🔴 |

| GuardianEmploymentStatusID | bigint | YES | TBC | 🔴 |

| GuardianHome_PhoneNo | nvarchar | YES | TBC | 🔴 |

| GuardianIdentificationCardIssueDate | date | YES | TBC | 🔴 |

| GuardianImg | nvarchar | YES | TBC | 🔴 |

| GuardianImmigrationcopy | nvarchar | YES | TBC | 🔴 |

| GuardianImmigrationcopy1 | nvarchar | YES | TBC | 🔴 |

| GuardianLastName | nvarchar | YES | TBC | 🔴 |

| GuardianNRICcopy | nvarchar | YES | TBC | 🔴 |

| GuardianNRICcopy1 | nvarchar | YES | TBC | 🔴 |

| GuardianName | nvarchar | YES | TBC | 🔴 |

| GuardianNationality | nvarchar | YES | TBC | 🔴 |

| GuardianNatureOfBusiness | nvarchar | YES | TBC | 🔴 |

| GuardianOccupation | nvarchar | YES | TBC | 🔴 |

| GuardianOfficeAddress | nvarchar | YES | TBC | 🔴 |

| GuardianOrganization | nvarchar | YES | TBC | 🔴 |

| GuardianPassportExpiryDate | date | YES | TBC | 🔴 |

| GuardianPassportIssueDate | date | YES | TBC | 🔴 |

| GuardianPassportNo | nvarchar | YES | TBC | 🔴 |

| GuardianPassportcopy | nvarchar | YES | TBC | 🔴 |

| GuardianPassportcopy1 | nvarchar | YES | TBC | 🔴 |

| GuardianSchoolAlumni | nvarchar | YES | TBC | 🔴 |

| GuardianTitleName | nvarchar | YES | TBC | 🔴 |

| GuardianWork_PhoneNo | nvarchar | YES | TBC | 🔴 |

| Guardian_Relationshipwithstudent | nvarchar | YES | TBC | 🔴 |

| Height | nvarchar | YES | TBC | 🔴 |

| Hostname | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IdentificationMarks | nvarchar | YES | TBC | 🔴 |

| IdentificationMarks_2 | nvarchar | YES | TBC | 🔴 |

| IsFatherJobTransferrable | bit | YES | TBC | 🔴 |

| IsFatherSchoolAlumni | bit | YES | TBC | 🔴 |

| IsGuardianJobTransferrable | bit | YES | TBC | 🔴 |

| IsGuardianSchoolAlumni | bit | YES | TBC | 🔴 |

| IsLumpsumApplicable | bit | YES | TBC | 🔴 |

| IsMotherJobTransferrable | bit | YES | TBC | 🔴 |

| IsMotherSchoolAlumni | bit | YES | TBC | 🔴 |

| IsOrphanOrAdopted | bit | YES | TBC | 🔴 |

| IsPortalLogin | bigint | YES | TBC | 🔴 |

| IsVIP | bit | YES | TBC | 🔴 |

| LaptopIssued | nvarchar | YES | TBC | 🔴 |

| LaptopSlno | nvarchar | YES | TBC | 🔴 |

| LastName | nvarchar | YES | TBC | 🔴 |

| Latitude | nvarchar | YES | TBC | 🔴 |

| LoginCount | int | YES | TBC | 🔴 |

| LoginStatus | int | YES | TBC | 🔴 |

| Longitude | nvarchar | YES | TBC | 🔴 |

| Lumpsum_Amount | bigint | YES | TBC | 🔴 |

| Lumpsum_Id | bigint | YES | TBC | 🔴 |

| MiddleName | nvarchar | YES | TBC | 🔴 |

| MotherAadhaarNo | nvarchar | YES | TBC | 🔴 |

| MotherAdhaarCardNo | nvarchar | YES | TBC | 🔴 |

| MotherAge | int | YES | TBC | 🔴 |

| MotherAnnualIncome | nvarchar | YES | TBC | 🔴 |

| MotherContactNo | nvarchar | YES | TBC | 🔴 |

| MotherDesignation | nvarchar | YES | TBC | 🔴 |

| MotherDesignationLevel | nvarchar | YES | TBC | 🔴 |

| MotherDob | date | YES | TBC | 🔴 |

| MotherEPCard | nvarchar | YES | TBC | 🔴 |

| MotherEducation | nvarchar | YES | TBC | 🔴 |

| MotherEmail | nvarchar | YES | TBC | 🔴 |

| MotherEmploymentPassNo | nvarchar | YES | TBC | 🔴 |

| MotherEmploymentPassNoExpiryDate | date | YES | TBC | 🔴 |

| MotherEmploymentPassNoIssueDate | date | YES | TBC | 🔴 |

| MotherEmploymentStatus | nvarchar | YES | TBC | 🔴 |

| MotherEmploymentStatusExpiryDate | date | YES | TBC | 🔴 |

| MotherEmploymentStatusID | bigint | YES | TBC | 🔴 |

| MotherHome_PhoneNo | nvarchar | YES | TBC | 🔴 |

| MotherIdentificationCardIssueDate | date | YES | TBC | 🔴 |

| MotherImg | nvarchar | YES | TBC | 🔴 |

| MotherImmigrationcopy | nvarchar | YES | TBC | 🔴 |

| MotherImmigrationcopy1 | nvarchar | YES | TBC | 🔴 |

| MotherLastName | nvarchar | YES | TBC | 🔴 |

| MotherNRIC | nvarchar | YES | TBC | 🔴 |

| MotherName | nvarchar | YES | TBC | 🔴 |

| MotherNameInRegionalLanguage | nvarchar | YES | TBC | 🔴 |

| MotherNationality | nvarchar | YES | TBC | 🔴 |

| MotherNatureOfBusiness | nvarchar | YES | TBC | 🔴 |

| MotherOccupation | nvarchar | YES | TBC | 🔴 |

| MotherOfficeAddress | nvarchar | YES | TBC | 🔴 |

| MotherOrganization | nvarchar | YES | TBC | 🔴 |

| MotherPassportNo | nvarchar | YES | TBC | 🔴 |

| MotherPassportcopy | nvarchar | YES | TBC | 🔴 |

| MotherPassportcopy1 | nvarchar | YES | TBC | 🔴 |

| MotherSchoolAlumni | nvarchar | YES | TBC | 🔴 |

| MotherTitleName | nvarchar | YES | TBC | 🔴 |

| MotherTongue_ID | bigint | YES | TBC | 🔴 |

| MotherTongue_Name | nvarchar | YES | TBC | 🔴 |

| MotherWork_PhoneNo | nvarchar | YES | TBC | 🔴 |

| Nationality_ID | bigint | YES | TBC | 🔴 |

| Nationality_Name | nvarchar | YES | TBC | 🔴 |

| NeetCount | nvarchar | YES | TBC | 🔴 |

| Neetmarks | nvarchar | YES | TBC | 🔴 |

| OldStudentId | bigint | YES | TBC | 🔴 |

| OptionalSubject | nvarchar | YES | TBC | 🔴 |

| OtherReferenceNo | nvarchar | YES | TBC | 🔴 |

| Others | nvarchar | YES | TBC | 🔴 |

| PANNo | nvarchar | YES | TBC | 🔴 |

| PENNumber | nvarchar | YES | TBC | 🔴 |

| POBox | nvarchar | YES | TBC | 🔴 |

| Paid_Date | datetime | YES | TBC | 🔴 |

| ParentSignature | nvarchar | YES | TBC | 🔴 |

| ParentWeddingDate | date | YES | TBC | 🔴 |

| PassportExpiryDate | date | YES | TBC | 🔴 |

| PassportNo | nvarchar | YES | TBC | 🔴 |

| Password | nvarchar | YES | TBC | 🔴 |

| PerAddress | nvarchar | YES | TBC | 🔴 |

| PerCity | nvarchar | YES | TBC | 🔴 |

| PerCity_ID | bigint | YES | TBC | 🔴 |

| PerCountry | nvarchar | YES | TBC | 🔴 |

| PerCountry_ID | bigint | YES | TBC | 🔴 |

| PerDistrictId | bigint | YES | TBC | 🔴 |

| PerDistrictName | nvarchar | YES | TBC | 🔴 |

| PerEmail | nvarchar | YES | TBC | 🔴 |

| PerMobile | nvarchar | YES | TBC | 🔴 |

| PerPhone | nvarchar | YES | TBC | 🔴 |

| PerPincode | nvarchar | YES | TBC | 🔴 |

| PerState | nvarchar | YES | TBC | 🔴 |

| PerState_ID | bigint | YES | TBC | 🔴 |

| PerTaluk | nvarchar | YES | TBC | 🔴 |

| PerVillage | nvarchar | YES | TBC | 🔴 |

| Picked_Up_By | nvarchar | YES | TBC | 🔴 |

| PlaceOfBirth | nvarchar | YES | TBC | 🔴 |

| PortalMenus | nvarchar | YES | TBC | 🔴 |

| PortalStatus | bit | YES | TBC | 🔴 |

| PreferLangOne_ID | bigint | YES | TBC | 🔴 |

| PreferLangOne_Name | nvarchar | YES | TBC | 🔴 |

| PreferLangTwo_ID | bigint | YES | TBC | 🔴 |

| PreferLangTwo_Name | nvarchar | YES | TBC | 🔴 |

| PrimaryCommunicationMobile | nvarchar | YES | TBC | 🔴 |

| ReferenceDetails | nvarchar | YES | TBC | 🔴 |

| ReferenceLetter | nvarchar | YES | TBC | 🔴 |

| Religion_ID | bigint | YES | TBC | 🔴 |

| Religion_Name | nvarchar | YES | TBC | 🔴 |

| Residence | nvarchar | YES | TBC | 🔴 |

| Return_Date | datetime | YES | TBC | 🔴 |

| Room_ID | bigint | YES | TBC | 🔴 |

| Room_Name | nvarchar | YES | TBC | 🔴 |

| Route_ID | bigint | YES | TBC | 🔴 |

| Route_Name | nvarchar | YES | TBC | 🔴 |

| SATSNo | nvarchar | YES | TBC | 🔴 |

| SameAddress | bit | YES | TBC | 🔴 |

| SchoolLastStudied | nvarchar | YES | TBC | 🔴 |

| SearchImportedRecord | nvarchar | YES | TBC | 🔴 |

| SecondaryCommunicationMobile | nvarchar | YES | TBC | 🔴 |

| Security_Deposit_Amount | bigint | YES | TBC | 🔴 |

| Security_Deposit_Date | date | YES | TBC | 🔴 |

| SiblingStudyingInSchool | nvarchar | YES | TBC | 🔴 |

| SpecialNeeds | bit | YES | TBC | 🔴 |

| SportParticipation | nvarchar | YES | TBC | 🔴 |

| SportsName | nvarchar | YES | TBC | 🔴 |

| SportsPlayer | nvarchar | YES | TBC | 🔴 |

| StaffBranchID | varchar | YES | TBC | 🔴 |

| StaffChild | int | YES | TBC | 🔴 |

| StaffID | varchar | YES | TBC | 🔴 |

| StaffName | nvarchar | YES | TBC | 🔴 |

| StayWithParent | bit | YES | TBC | 🔴 |

| StayingWithGuardian | bit | YES | TBC | 🔴 |

| Stream | nvarchar | YES | TBC | 🔴 |

| StreamID | int | YES | TBC | 🔴 |

| StudentAdmittedSection | nvarchar | YES | TBC | 🔴 |

| StudentAge | nvarchar | YES | TBC | 🔴 |

| StudentBirthCertificate | nvarchar | YES | TBC | 🔴 |

| StudentClass_ID | bigint | YES | TBC | 🔴 |

| StudentCode | nvarchar | YES | TBC | 🔴 |

| StudentDepPassCard | nvarchar | YES | TBC | 🔴 |

| StudentDob | date | YES | TBC | 🔴 |

| StudentIdentificationCardExpiryDate | date | YES | TBC | 🔴 |

| StudentIdentificationCardIssueDate | date | YES | TBC | 🔴 |

| StudentIdentificationNo | nvarchar | YES | TBC | 🔴 |

| StudentImg | nvarchar | YES | TBC | 🔴 |

| StudentImmigrationStatus | nvarchar | YES | TBC | 🔴 |

| StudentImmigrationStatusID | bigint | YES | TBC | 🔴 |

| StudentImmigrationcopy | nvarchar | YES | TBC | 🔴 |

| StudentImmigrationcopy1 | nvarchar | YES | TBC | 🔴 |

| StudentImmunizationCertificate | nvarchar | YES | TBC | 🔴 |

| StudentMobileNo | nvarchar | YES | TBC | 🔴 |

| StudentNRIC | nvarchar | YES | TBC | 🔴 |

| StudentNameInRegionalLanguage | nvarchar | YES | TBC | 🔴 |

| StudentPassExpiryDate | date | YES | TBC | 🔴 |

| StudentPassIssueDate | date | YES | TBC | 🔴 |

| StudentPassportExpiryDate | date | YES | TBC | 🔴 |

| StudentPassportcopy | nvarchar | YES | TBC | 🔴 |

| StudentPassportcopy1 | nvarchar | YES | TBC | 🔴 |

| StudentReportCard | nvarchar | YES | TBC | 🔴 |

| StudentTCcopy | nvarchar | YES | TBC | 🔴 |

| SubCaste | nvarchar | YES | TBC | 🔴 |

| SubjectCombinations | nvarchar | YES | TBC | 🔴 |

| SubjectCombinationsID | bigint | YES | TBC | 🔴 |

| Token | nvarchar | YES | TBC | 🔴 |

| UnitNo | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Username | nvarchar | YES | TBC | 🔴 |

| VISAExpiryDate | date | YES | TBC | 🔴 |

| VISANo | nvarchar | YES | TBC | 🔴 |

| Vision | nvarchar | YES | TBC | 🔴 |

| Weight | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 Student_Master_Draft (294 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearId | bigint | YES | TBC | 🔴 |

| AdhaarCardNo | nvarchar | YES | TBC | 🔴 |

| AdmissionCategoryID | bigint | YES | TBC | 🔴 |

| AdmissionDate | date | YES | TBC | 🔴 |

| AdmissionNo | nvarchar | YES | TBC | 🔴 |

| AdmissionPriorityID | bigint | YES | TBC | 🔴 |

| AdmissionTypeName | nvarchar | YES | TBC | 🔴 |

| AdmissionType_ID | bigint | YES | TBC | 🔴 |

| AdmissionWaiverOptionId | bigint | YES | TBC | 🔴 |

| AdmissionWaiverOptionName | nvarchar | YES | TBC | 🔴 |

| Allergies | nvarchar | YES | TBC | 🔴 |

| Applicant_ID | bigint | YES | TBC | 🔴 |

| ApplicationNo | nvarchar | YES | TBC | 🔴 |

| AvailableCredit | numeric | YES | TBC | 🔴 |

| BMI | nvarchar | YES | TBC | 🔴 |

| BankAccountNo | nvarchar | YES | TBC | 🔴 |

| BankAddress | nvarchar | YES | TBC | 🔴 |

| BankIfscCode | nvarchar | YES | TBC | 🔴 |

| BankName | nvarchar | YES | TBC | 🔴 |

| BloodGroup_ID | bigint | YES | TBC | 🔴 |

| BloodGroup_Name | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CanditateID | nvarchar | YES | TBC | 🔴 |

| CasteID | bigint | YES | TBC | 🔴 |

| Chest | nvarchar | YES | TBC | 🔴 |

| ChildBornOrder | int | YES | TBC | 🔴 |

| ChildDisadvantagedGroup | nvarchar | YES | TBC | 🔴 |

| ClassLastStudied | nvarchar | YES | TBC | 🔴 |

| ComAddress | nvarchar | YES | TBC | 🔴 |

| ComCity | nvarchar | YES | TBC | 🔴 |

| ComCity_ID | bigint | YES | TBC | 🔴 |

| ComCountry | nvarchar | YES | TBC | 🔴 |

| ComCountry_ID | bigint | YES | TBC | 🔴 |

| ComEmail | nvarchar | YES | TBC | 🔴 |

| ComMobile | nvarchar | YES | TBC | 🔴 |

| ComPhone | nvarchar | YES | TBC | 🔴 |

| ComPincode | nvarchar | YES | TBC | 🔴 |

| ComPlace | nvarchar | YES | TBC | 🔴 |

| ComState | nvarchar | YES | TBC | 🔴 |

| ComState_ID | bigint | YES | TBC | 🔴 |

| CombinedSubjects | nvarchar | YES | TBC | 🔴 |

| CommunicationMailID | nvarchar | YES | TBC | 🔴 |

| CommunicationMobileNo | nvarchar | YES | TBC | 🔴 |

| CommunicationeMailID | nvarchar | YES | TBC | 🔴 |

| CommunityCertificate | nvarchar | YES | TBC | 🔴 |

| Community_ID | bigint | YES | TBC | 🔴 |

| Community_Name | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| DateOfPassportIssue | date | YES | TBC | 🔴 |

| DateOfVISAIssue | date | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Dental | nvarchar | YES | TBC | 🔴 |

| Disability_ID | int | YES | TBC | 🔴 |

| Disability_Name | nvarchar | YES | TBC | 🔴 |

| DocumentsCheckList | nvarchar | YES | TBC | 🔴 |

| EMISNo | nvarchar | YES | TBC | 🔴 |

| EducationMedium | nvarchar | YES | TBC | 🔴 |

| EmergencyContactIdentificationNo | nvarchar | YES | TBC | 🔴 |

| EmergencyContactImmigrationcopy | nvarchar | YES | TBC | 🔴 |

| EmergencyContactImmigrationcopy1 | nvarchar | YES | TBC | 🔴 |

| EmergencyContactPersonMobileNo | nvarchar | YES | TBC | 🔴 |

| EmergencyContactPersonName | nvarchar | YES | TBC | 🔴 |

| EmergencyContactPersonRelationship | nvarchar | YES | TBC | 🔴 |

| EnrollmentNo | nvarchar | YES | TBC | 🔴 |

| ExtraCurricularActivity | nvarchar | YES | TBC | 🔴 |

| FatherAadhaarNo | nvarchar | YES | TBC | 🔴 |

| FatherAge | int | YES | TBC | 🔴 |

| FatherAnnualIncome | nvarchar | YES | TBC | 🔴 |

| FatherContactNo | nvarchar | YES | TBC | 🔴 |

| FatherDesignation | nvarchar | YES | TBC | 🔴 |

| FatherDob | date | YES | TBC | 🔴 |

| FatherEPCard | nvarchar | YES | TBC | 🔴 |

| FatherEducation | nvarchar | YES | TBC | 🔴 |

| FatherEmail | nvarchar | YES | TBC | 🔴 |

| FatherEmploymentPassNo | nvarchar | YES | TBC | 🔴 |

| FatherEmploymentPassNoExpiryDate | date | YES | TBC | 🔴 |

| FatherEmploymentPassNoIssueDate | date | YES | TBC | 🔴 |

| FatherEmploymentStatus | nvarchar | YES | TBC | 🔴 |

| FatherEmploymentStatusExpiryDate | date | YES | TBC | 🔴 |

| FatherEmploymentStatusID | bigint | YES | TBC | 🔴 |

| FatherHome_PhoneNo | nvarchar | YES | TBC | 🔴 |

| FatherIdentificationCardIssueDate | date | YES | TBC | 🔴 |

| FatherImg | nvarchar | YES | TBC | 🔴 |

| FatherImmigrationcopy | nvarchar | YES | TBC | 🔴 |

| FatherImmigrationcopy1 | nvarchar | YES | TBC | 🔴 |

| FatherLastName | nvarchar | YES | TBC | 🔴 |

| FatherNRIC | nvarchar | YES | TBC | 🔴 |

| FatherName | nvarchar | YES | TBC | 🔴 |

| FatherNameInRegionalLanguage | nvarchar | YES | TBC | 🔴 |

| FatherNationality | nvarchar | YES | TBC | 🔴 |

| FatherOccupation | nvarchar | YES | TBC | 🔴 |

| FatherOfficeAddress | nvarchar | YES | TBC | 🔴 |

| FatherOrganization | nvarchar | YES | TBC | 🔴 |

| FatherPassportNo | nvarchar | YES | TBC | 🔴 |

| FatherPassportcopy | nvarchar | YES | TBC | 🔴 |

| FatherPassportcopy1 | nvarchar | YES | TBC | 🔴 |

| FatherWork_PhoneNo | nvarchar | YES | TBC | 🔴 |

| Fees_Effective_AdmissionDate | date | YES | TBC | 🔴 |

| FirstName | nvarchar | YES | TBC | 🔴 |

| Gender | nvarchar | YES | TBC | 🔴 |

| GuardianAadhaarNo | nvarchar | YES | TBC | 🔴 |

| GuardianAge | int | YES | TBC | 🔴 |

| GuardianAnnualIncome | nvarchar | YES | TBC | 🔴 |

| GuardianContactNo | nvarchar | YES | TBC | 🔴 |

| GuardianDesignation | nvarchar | YES | TBC | 🔴 |

| GuardianDob | date | YES | TBC | 🔴 |

| GuardianEducation | nvarchar | YES | TBC | 🔴 |

| GuardianEmail | nvarchar | YES | TBC | 🔴 |

| GuardianEmploymentPassNo | nvarchar | YES | TBC | 🔴 |

| GuardianEmploymentPassNoExpiryDate | date | YES | TBC | 🔴 |

| GuardianEmploymentPassNoIssueDate | date | YES | TBC | 🔴 |

| GuardianEmploymentStatus | nvarchar | YES | TBC | 🔴 |

| GuardianEmploymentStatusExpiryDate | date | YES | TBC | 🔴 |

| GuardianEmploymentStatusID | bigint | YES | TBC | 🔴 |

| GuardianHome_PhoneNo | nvarchar | YES | TBC | 🔴 |

| GuardianIdentificationCardIssueDate | date | YES | TBC | 🔴 |

| GuardianImg | nvarchar | YES | TBC | 🔴 |

| GuardianImmigrationcopy | nvarchar | YES | TBC | 🔴 |

| GuardianImmigrationcopy1 | nvarchar | YES | TBC | 🔴 |

| GuardianLastName | nvarchar | YES | TBC | 🔴 |

| GuardianNRICcopy | nvarchar | YES | TBC | 🔴 |

| GuardianNRICcopy1 | nvarchar | YES | TBC | 🔴 |

| GuardianName | nvarchar | YES | TBC | 🔴 |

| GuardianNationality | nvarchar | YES | TBC | 🔴 |

| GuardianOccupation | nvarchar | YES | TBC | 🔴 |

| GuardianOfficeAddress | nvarchar | YES | TBC | 🔴 |

| GuardianOrganization | nvarchar | YES | TBC | 🔴 |

| GuardianPassportExpiryDate | date | YES | TBC | 🔴 |

| GuardianPassportIssueDate | date | YES | TBC | 🔴 |

| GuardianPassportNo | nvarchar | YES | TBC | 🔴 |

| GuardianPassportcopy | nvarchar | YES | TBC | 🔴 |

| GuardianPassportcopy1 | nvarchar | YES | TBC | 🔴 |

| GuardianWork_PhoneNo | nvarchar | YES | TBC | 🔴 |

| Guardian_Relationshipwithstudent | nvarchar | YES | TBC | 🔴 |

| Height | nvarchar | YES | TBC | 🔴 |

| Hostname | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IdentificationMarks | nvarchar | YES | TBC | 🔴 |

| IdentificationMarks_2 | nvarchar | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IsFatherSchoolAlumni | bit | YES | TBC | 🔴 |

| IsGuardianSchoolAlumni | bit | YES | TBC | 🔴 |

| IsLumpsumApplicable | bit | YES | TBC | 🔴 |

| IsMotherSchoolAlumni | bit | YES | TBC | 🔴 |

| IsPortalLogin | bigint | YES | TBC | 🔴 |

| IsVIP | bit | YES | TBC | 🔴 |

| LaptopIssued | nvarchar | YES | TBC | 🔴 |

| LaptopSlno | nvarchar | YES | TBC | 🔴 |

| LastName | nvarchar | YES | TBC | 🔴 |

| LateAdmissionDeclineReason | nvarchar | YES | TBC | 🔴 |

| LateAdmissionStatus | bigint | YES | TBC | 🔴 |

| LoginCount | int | YES | TBC | 🔴 |

| LoginStatus | int | YES | TBC | 🔴 |

| Lumpsum_Amount | bigint | YES | TBC | 🔴 |

| Lumpsum_Id | bigint | YES | TBC | 🔴 |

| MiddleName | nvarchar | YES | TBC | 🔴 |

| MotherAadhaarNo | nvarchar | YES | TBC | 🔴 |

| MotherAge | int | YES | TBC | 🔴 |

| MotherAnnualIncome | nvarchar | YES | TBC | 🔴 |

| MotherContactNo | nvarchar | YES | TBC | 🔴 |

| MotherDesignation | nvarchar | YES | TBC | 🔴 |

| MotherDob | date | YES | TBC | 🔴 |

| MotherEPCard | nvarchar | YES | TBC | 🔴 |

| MotherEducation | nvarchar | YES | TBC | 🔴 |

| MotherEmail | nvarchar | YES | TBC | 🔴 |

| MotherEmploymentPassNo | nvarchar | YES | TBC | 🔴 |

| MotherEmploymentPassNoExpiryDate | date | YES | TBC | 🔴 |

| MotherEmploymentPassNoIssueDate | date | YES | TBC | 🔴 |

| MotherEmploymentStatus | nvarchar | YES | TBC | 🔴 |

| MotherEmploymentStatusExpiryDate | date | YES | TBC | 🔴 |

| MotherEmploymentStatusID | bigint | YES | TBC | 🔴 |

| MotherHome_PhoneNo | nvarchar | YES | TBC | 🔴 |

| MotherIdentificationCardIssueDate | date | YES | TBC | 🔴 |

| MotherImg | nvarchar | YES | TBC | 🔴 |

| MotherImmigrationcopy | nvarchar | YES | TBC | 🔴 |

| MotherImmigrationcopy1 | nvarchar | YES | TBC | 🔴 |

| MotherLastName | nvarchar | YES | TBC | 🔴 |

| MotherNRIC | nvarchar | YES | TBC | 🔴 |

| MotherName | nvarchar | YES | TBC | 🔴 |

| MotherNameInRegionalLanguage | nvarchar | YES | TBC | 🔴 |

| MotherNationality | nvarchar | YES | TBC | 🔴 |

| MotherOccupation | nvarchar | YES | TBC | 🔴 |

| MotherOfficeAddress | nvarchar | YES | TBC | 🔴 |

| MotherOrganization | nvarchar | YES | TBC | 🔴 |

| MotherPassportNo | nvarchar | YES | TBC | 🔴 |

| MotherPassportcopy | nvarchar | YES | TBC | 🔴 |

| MotherPassportcopy1 | nvarchar | YES | TBC | 🔴 |

| MotherTongue_ID | bigint | YES | TBC | 🔴 |

| MotherTongue_Name | nvarchar | YES | TBC | 🔴 |

| MotherWork_PhoneNo | nvarchar | YES | TBC | 🔴 |

| Nationality_ID | bigint | YES | TBC | 🔴 |

| Nationality_Name | nvarchar | YES | TBC | 🔴 |

| NeetCount | nvarchar | YES | TBC | 🔴 |

| NeetMarks | nvarchar | YES | TBC | 🔴 |

| OldStudentId | bigint | YES | TBC | 🔴 |

| OptionalSubject | nvarchar | YES | TBC | 🔴 |

| OtherReferenceNo | nvarchar | YES | TBC | 🔴 |

| Others | nvarchar | YES | TBC | 🔴 |

| PANNo | nvarchar | YES | TBC | 🔴 |

| POBox | nvarchar | YES | TBC | 🔴 |

| Paid_Date | datetime | YES | TBC | 🔴 |

| ParentSignature | nvarchar | YES | TBC | 🔴 |

| ParentWeddingDate | date | YES | TBC | 🔴 |

| PassportExpiryDate | date | YES | TBC | 🔴 |

| PassportNo | nvarchar | YES | TBC | 🔴 |

| Password | nvarchar | YES | TBC | 🔴 |

| PerAddress | nvarchar | YES | TBC | 🔴 |

| PerCity | nvarchar | YES | TBC | 🔴 |

| PerCity_ID | bigint | YES | TBC | 🔴 |

| PerCountry | nvarchar | YES | TBC | 🔴 |

| PerCountry_ID | bigint | YES | TBC | 🔴 |

| PerEmail | nvarchar | YES | TBC | 🔴 |

| PerMobile | nvarchar | YES | TBC | 🔴 |

| PerPhone | nvarchar | YES | TBC | 🔴 |

| PerPincode | nvarchar | YES | TBC | 🔴 |

| PerState | nvarchar | YES | TBC | 🔴 |

| PerState_ID | bigint | YES | TBC | 🔴 |

| PhotoConsentFormDeclineReason | nvarchar | YES | TBC | 🔴 |

| PhotoConsentFormStatus | bigint | YES | TBC | 🔴 |

| Picked_Up_By | nvarchar | YES | TBC | 🔴 |

| PlaceOfBirth | nvarchar | YES | TBC | 🔴 |

| PortalMenus | nvarchar | YES | TBC | 🔴 |

| PortalStatus | bit | YES | TBC | 🔴 |

| PreferLangOne_ID | bigint | YES | TBC | 🔴 |

| PreferLangOne_Name | nvarchar | YES | TBC | 🔴 |

| PreferLangTwo_ID | bigint | YES | TBC | 🔴 |

| PreferLangTwo_Name | nvarchar | YES | TBC | 🔴 |

| PrimaryCommunicationMobile | nvarchar | YES | TBC | 🔴 |

| Religion_ID | bigint | YES | TBC | 🔴 |

| Religion_Name | nvarchar | YES | TBC | 🔴 |

| Residence | nvarchar | YES | TBC | 🔴 |

| Return_Date | datetime | YES | TBC | 🔴 |

| SameAddress | bit | YES | TBC | 🔴 |

| SchoolLastStudied | nvarchar | YES | TBC | 🔴 |

| SearchImportedRecord | nvarchar | YES | TBC | 🔴 |

| SecondaryCommunicationMobile | nvarchar | YES | TBC | 🔴 |

| Security_Deposit_Amount | bigint | YES | TBC | 🔴 |

| Security_Deposit_Date | date | YES | TBC | 🔴 |

| SportParticipation | nvarchar | YES | TBC | 🔴 |

| SportsName | nvarchar | YES | TBC | 🔴 |

| SportsPlayer | nvarchar | YES | TBC | 🔴 |

| StaffBranchID | varchar | YES | TBC | 🔴 |

| StaffChild | int | YES | TBC | 🔴 |

| StaffID | varchar | YES | TBC | 🔴 |

| StaffName | nvarchar | YES | TBC | 🔴 |

| StayWithParent | bit | YES | TBC | 🔴 |

| StayingWithGuardian | bit | YES | TBC | 🔴 |

| Stream | nvarchar | YES | TBC | 🔴 |

| StreamID | int | YES | TBC | 🔴 |

| StudentAdmittedSection | nvarchar | YES | TBC | 🔴 |

| StudentAge | nvarchar | YES | TBC | 🔴 |

| StudentBirthCertificate | nvarchar | YES | TBC | 🔴 |

| StudentClass_ID | bigint | YES | TBC | 🔴 |

| StudentCode | nvarchar | YES | TBC | 🔴 |

| StudentDepPassCard | nvarchar | YES | TBC | 🔴 |

| StudentDob | date | YES | TBC | 🔴 |

| StudentId | bigint | YES | TBC | 🔴 |

| StudentIdentificationCardExpiryDate | date | YES | TBC | 🔴 |

| StudentIdentificationCardIssueDate | date | YES | TBC | 🔴 |

| StudentIdentificationNo | nvarchar | YES | TBC | 🔴 |

| StudentImg | nvarchar | YES | TBC | 🔴 |

| StudentImmigrationStatus | nvarchar | YES | TBC | 🔴 |

| StudentImmigrationStatusID | bigint | YES | TBC | 🔴 |

| StudentImmigrationcopy | nvarchar | YES | TBC | 🔴 |

| StudentImmigrationcopy1 | nvarchar | YES | TBC | 🔴 |

| StudentImmunizationCertificate | nvarchar | YES | TBC | 🔴 |

| StudentMobileNo | nvarchar | YES | TBC | 🔴 |

| StudentNRIC | nvarchar | YES | TBC | 🔴 |

| StudentNameInRegionalLanguage | nvarchar | YES | TBC | 🔴 |

| StudentPassExpiryDate | date | YES | TBC | 🔴 |

| StudentPassIssueDate | date | YES | TBC | 🔴 |

| StudentPassportExpiryDate | date | YES | TBC | 🔴 |

| StudentPassportcopy | nvarchar | YES | TBC | 🔴 |

| StudentPassportcopy1 | nvarchar | YES | TBC | 🔴 |

| StudentReportCard | nvarchar | YES | TBC | 🔴 |

| StudentTCcopy | nvarchar | YES | TBC | 🔴 |

| SubCaste | nvarchar | YES | TBC | 🔴 |

| SubjectCombinations | nvarchar | YES | TBC | 🔴 |

| SubjectCombinationsID | bigint | YES | TBC | 🔴 |

| TermsAndConditionStatus | bigint | YES | TBC | 🔴 |

| TermsAndConditionsDeclineReason | nvarchar | YES | TBC | 🔴 |

| Token | nvarchar | YES | TBC | 🔴 |

| TransportAgreementDeclineReason | nvarchar | YES | TBC | 🔴 |

| TransportAgreementStatus | bigint | YES | TBC | 🔴 |

| UnitNo | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Username | nvarchar | YES | TBC | 🔴 |

| VISAExpiryDate | date | YES | TBC | 🔴 |

| VISANo | nvarchar | YES | TBC | 🔴 |

| Vision | nvarchar | YES | TBC | 🔴 |

| Weight | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 Student_PreviousSchool (16 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ExamResult | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| PreAddress | nvarchar | YES | TBC | 🔴 |

| PreBoardOfStudy | nvarchar | YES | TBC | 🔴 |

| PreCity | nvarchar | YES | TBC | 🔴 |

| PreClass | nvarchar | YES | TBC | 🔴 |

| PreLeavingReason | nvarchar | YES | TBC | 🔴 |

| PrePeriod | nvarchar | YES | TBC | 🔴 |

| PrePincode | nvarchar | YES | TBC | 🔴 |

| PreSchoolName | nvarchar | YES | TBC | 🔴 |

| PreState | nvarchar | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |

| Syllabus | nvarchar | YES | TBC | 🔴 |

| UDISENo | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 Student_Scholarship (8 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| ScholarshipName | nvarchar | YES | TBC | 🔴 |

| ScholarshipOrganizedBy | nvarchar | YES | TBC | 🔴 |

| ScholarshipReferenceNo | nvarchar | YES | TBC | 🔴 |

| ScholarshipValidity | nvarchar | YES | TBC | 🔴 |

| Student_ID | bigint | NO | TBC | 🔴 |



---


#### 🔴 Student_Siblings (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassName | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| PortalEnabled | bit | YES | TBC | 🔴 |

| SchoolName | nvarchar | YES | TBC | 🔴 |

| SectionName | nvarchar | YES | TBC | 🔴 |

| SiblingClassID | bigint | YES | TBC | 🔴 |

| SiblingName | nvarchar | YES | TBC | 🔴 |

| SiblingRelationship_ID | bigint | YES | TBC | 🔴 |

| SiblingSectionID | bigint | YES | TBC | 🔴 |

| SiblingStudentID | bigint | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 SubjectCombinationsMaster (15 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CombinationID | nvarchar | YES | TBC | 🔴 |

| CombinationName | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Stream | nvarchar | YES | TBC | 🔴 |

| StreamID | int | YES | TBC | 🔴 |

| SubjectCombinationName | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 TCCheckListUpdation (9 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Checklist_Id | bigint | YES | TBC | 🔴 |

| Date | date | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| Status_Id | bigint | YES | TBC | 🔴 |

| Status_Name | nvarchar | YES | TBC | 🔴 |

| Student_Id | bigint | YES | TBC | 🔴 |



---


#### 🟡 TCRequest (96 columns) — [PARTIAL]


**Purpose:** TC (Transfer Certificate) requests. Has 96 columns. Has TC_Status (e.g. 'Pending').


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdmissionClass_ID | bigint | YES | TBC | 🔴 |

| AdmissionDate | date | YES | TBC | 🔴 |

| AdmissionNo | nvarchar | YES | TBC | 🔴 |

| Age | nvarchar | YES | TBC | 🔴 |

| AppliedDate | date | YES | TBC | 🔴 |

| ApprovalStatus | nvarchar | YES | TBC | 🔴 |

| Attendance | nvarchar | YES | TBC | 🔴 |

| Board | bigint | YES | TBC | 🔴 |

| BookNo | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CasteCaption | nvarchar | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| Community | nvarchar | YES | TBC | 🔴 |

| Concession_Nature | nvarchar | YES | TBC | 🔴 |

| Conduct | nvarchar | YES | TBC | 🔴 |

| CourseOffered | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| DISECode | nvarchar | YES | TBC | 🔴 |

| DOB | date | YES | TBC | 🔴 |

| DOBProof | nvarchar | YES | TBC | 🔴 |

| DateLeftSchool | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Details | nvarchar | YES | TBC | 🔴 |

| ElectiveSubjects | nvarchar | YES | TBC | 🔴 |

| EnrollmentNo | nvarchar | YES | TBC | 🔴 |

| ExamResult | nvarchar | YES | TBC | 🔴 |

| ExtraActivities | nvarchar | YES | TBC | 🔴 |

| FailedStatus | nvarchar | YES | TBC | 🔴 |

| FeesConcession | nvarchar | YES | TBC | 🔴 |

| FeesPendency | nvarchar | YES | TBC | 🔴 |

| FirstName | nvarchar | YES | TBC | 🔴 |

| Gender | nvarchar | YES | TBC | 🔴 |

| GeneralContact | nvarchar | YES | TBC | 🔴 |

| HealthRemarks | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IdentificationMark1 | nvarchar | YES | TBC | 🔴 |

| IdentificationMark2 | nvarchar | YES | TBC | 🔴 |

| IfFailed | nvarchar | YES | TBC | 🔴 |

| InsuranceLastPaidDate | date | YES | TBC | 🔴 |

| IsDeleted | bigint | YES | TBC | 🔴 |

| IssuedDate | date | YES | TBC | 🔴 |

| Language | nvarchar | YES | TBC | 🔴 |

| LanguagesStudied | nvarchar | YES | TBC | 🔴 |

| LastAttendanceDate | date | YES | TBC | 🔴 |

| LastClassinWords | nvarchar | YES | TBC | 🔴 |

| LastName | nvarchar | YES | TBC | 🔴 |

| LastStudiedClass | bigint | YES | TBC | 🔴 |

| MarkCertificationNo | nvarchar | YES | TBC | 🔴 |

| MedicalCheck | nvarchar | YES | TBC | 🔴 |

| MedicalInspection | nvarchar | YES | TBC | 🔴 |

| Medium | nvarchar | YES | TBC | 🔴 |

| MiddleName | nvarchar | YES | TBC | 🔴 |

| MonthFeesPaid | nvarchar | YES | TBC | 🔴 |

| NCC_Scout | nvarchar | YES | TBC | 🔴 |

| Nationality | nvarchar | YES | TBC | 🔴 |

| OverAllPresentDay | decimal | YES | TBC | 🔴 |

| OverAllWorkingDays | decimal | YES | TBC | 🔴 |

| ParentName | nvarchar | YES | TBC | 🔴 |

| Place | nvarchar | YES | TBC | 🔴 |

| Prograss | nvarchar | YES | TBC | 🔴 |

| PromotedClass | nvarchar | YES | TBC | 🔴 |

| PromotedClassID | bigint | YES | TBC | 🔴 |

| PromotedClassinWords | nvarchar | YES | TBC | 🔴 |

| PromotionDate | date | YES | TBC | 🔴 |

| PromotionStatus | nvarchar | YES | TBC | 🔴 |

| Purpose | nvarchar | YES | TBC | 🔴 |

| ReasonforLeaving | nvarchar | YES | TBC | 🔴 |

| RegisterNo | nvarchar | YES | TBC | 🔴 |

| Religion | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| RollDate | date | YES | TBC | 🔴 |

| RollNo | nvarchar | YES | TBC | 🔴 |

| Scholarship | nvarchar | YES | TBC | 🔴 |

| ScholarshipNature | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| StudentNameInRegionalLanguage | nvarchar | YES | TBC | 🔴 |

| StudentTrackingNo | nvarchar | YES | TBC | 🔴 |

| Subject1 | nvarchar | YES | TBC | 🔴 |

| Subject2 | nvarchar | YES | TBC | 🔴 |

| Subject3 | nvarchar | YES | TBC | 🔴 |

| Subject4 | nvarchar | YES | TBC | 🔴 |

| Subject5 | nvarchar | YES | TBC | 🔴 |

| Subjects | nvarchar | YES | TBC | 🔴 |

| SubjectsStudiedCaption | nvarchar | YES | TBC | 🔴 |

| TCPrintStatus | nvarchar | YES | TBC | 🔴 |

| TC_ReferenceNo | nvarchar | YES | TBC | 🔴 |

| TC_Status | nvarchar | YES | TBC | 🔴 |

| TMRCode | nvarchar | YES | TBC | 🔴 |

| TMRDate | date | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| WhetherFailedInTheSameClass | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 TT_Class_Subject_Mapping_Details (14 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_Id | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IsOptional | bit | YES | TBC | 🔴 |

| Section_Id | bigint | YES | TBC | 🔴 |

| Subject_Id | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🟡 UserRoleClassMapping (16 columns) — [PARTIAL]


**Purpose:** Class-scoped role mapping (class-teacher). Has ClassIDs (CSV), StaffID, AcademicYearID.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassIDs | nvarchar | YES | TBC | 🔴 |

| ClassNames | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| StaffID | bigint | YES | TBC | 🔴 |

| StaffName | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| UserRoleID | bigint | YES | TBC | 🔴 |

| UserRoleName | nvarchar | YES | TBC | 🔴 |



---


### Other (80 tables)


#### 🔴 ASLReportSubjectDetails (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Deleted | bit | NO | TBC | 🔴 |

| EvalTypeID | bigint | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| SubjectID | bigint | YES | TBC | 🔴 |



---


#### 🔴 AllGroups (4 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| GroupIcon | nvarchar | YES | TBC | 🔴 |

| GroupText | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| ModuleID | bigint | YES | TBC | 🔴 |



---


#### 🔴 AllModules (4 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| ImageUrl | nvarchar | YES | TBC | 🔴 |

| ModuleName | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 AppHelpQueries (23 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearId | bigint | NO | TBC | 🔴 |

| AppVersion | nvarchar | YES | TBC | 🔴 |

| BranchId | bigint | NO | TBC | 🔴 |

| ClassId | bigint | NO | TBC | 🔴 |

| ClassName | nvarchar | NO | TBC | 🔴 |

| CreatedDate | datetime | NO | TBC | 🔴 |

| CurrentStatus | nvarchar | NO | TBC | 🔴 |

| DeviceOS | nvarchar | YES | TBC | 🔴 |

| DeviceType | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsActive | bit | NO | TBC | 🔴 |

| LatestResolution | nvarchar | YES | TBC | 🔴 |

| QueryText | nvarchar | NO | TBC | 🔴 |

| QueryType | nvarchar | NO | TBC | 🔴 |

| ResolvedBy | nvarchar | YES | TBC | 🔴 |

| ResolvedDate | datetime | YES | TBC | 🔴 |

| SectionId | bigint | NO | TBC | 🔴 |

| SectionName | nvarchar | NO | TBC | 🔴 |

| StudentId | bigint | NO | TBC | 🔴 |

| StudentName | nvarchar | NO | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |

| UserFeedback | nvarchar | YES | TBC | 🔴 |

| UserRating | int | YES | TBC | 🔴 |



---


#### 🔴 AppHelpQueryHistory (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| ActionDate | datetime | NO | TBC | 🔴 |

| ActionType | nvarchar | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| InternalNotes | nvarchar | YES | TBC | 🔴 |

| NewStatus | nvarchar | NO | TBC | 🔴 |

| PreviousStatus | nvarchar | YES | TBC | 🔴 |

| QueryId | bigint | NO | TBC | 🔴 |

| ReopenReason | nvarchar | YES | TBC | 🔴 |

| RepliedByType | varchar | YES | TBC | 🔴 |

| ResolutionBy | nvarchar | YES | TBC | 🔴 |

| ResolutionText | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 Applicant_DocumentDetails (8 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Applicant_ID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| DocumentName | nvarchar | YES | TBC | 🔴 |

| DocumentType | nvarchar | YES | TBC | 🔴 |

| DocumentUrl | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |



---


#### 🔴 Applicant_Siblings (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Applicant_ID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassName | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| PortalEnabled | bit | YES | TBC | 🔴 |

| SchoolName | nvarchar | YES | TBC | 🔴 |

| SectionName | nvarchar | YES | TBC | 🔴 |

| SiblingClassID | bigint | YES | TBC | 🔴 |

| SiblingName | nvarchar | YES | TBC | 🔴 |

| SiblingRelationshipID | bigint | YES | TBC | 🔴 |

| SiblingSectionID | bigint | YES | TBC | 🔴 |

| SiblingStudentID | bigint | YES | TBC | 🔴 |



---


#### 🔴 AssessmentEntry (17 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ClassSectionID | bigint | YES | TBC | 🔴 |

| CompetencyID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| CurriculumID | bigint | YES | TBC | 🔴 |

| ExamTypeID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Rating | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| SubjectID | bigint | YES | TBC | 🔴 |

| Type | int | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 AssessmentTypeMaster (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Desc | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bigint | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 BloodGroup_Master (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 BonafideCertificate (30 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdmissionNo | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ClassName | nvarchar | YES | TBC | 🔴 |

| FatherName | nvarchar | YES | TBC | 🔴 |

| GuardianName | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IssuedBy | nvarchar | YES | TBC | 🔴 |

| IssuedDate | date | YES | TBC | 🔴 |

| MotherName | nvarchar | YES | TBC | 🔴 |

| Purpose | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| SchoolAcademicYear | nvarchar | YES | TBC | 🔴 |

| SchoolAddress1 | nvarchar | YES | TBC | 🔴 |

| SchoolAddress2 | nvarchar | YES | TBC | 🔴 |

| SchoolLogo | nvarchar | YES | TBC | 🔴 |

| SchoolMobileNo | nvarchar | YES | TBC | 🔴 |

| SchoolName | nvarchar | YES | TBC | 🔴 |

| SchoolPhone1 | nvarchar | YES | TBC | 🔴 |

| SchoolPhone2 | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| SectionName | nvarchar | YES | TBC | 🔴 |

| SequenceNumber | nvarchar | YES | TBC | 🔴 |

| StudentAddress | nvarchar | YES | TBC | 🔴 |

| StudentDOB | date | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| StudentImage | nvarchar | YES | TBC | 🔴 |

| StudentName | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 Bonafide_Certificate (17 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Address | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_Id | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| DOB | date | YES | TBC | 🔴 |

| Father_Name | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bigint | YES | TBC | 🔴 |

| Purpose | nvarchar | YES | TBC | 🔴 |

| Section_Id | bigint | YES | TBC | 🔴 |

| Sent_Date | date | YES | TBC | 🔴 |

| StudentName | nvarchar | YES | TBC | 🔴 |

| Student_Id | bigint | YES | TBC | 🔴 |

| TuitionFee | nvarchar | YES | TBC | 🔴 |

| Type | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 CallCategory_Master (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 CallFollowup (16 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CallStatus | int | YES | TBC | 🔴 |

| CallType | int | NO | TBC | 🔴 |

| Call_ID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| FollowedBy_Id | bigint | YES | TBC | 🔴 |

| Followup_Date | date | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IsFollowup | bit | YES | TBC | 🔴 |

| Next_Followup_Date | date | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| Status_Id | bigint | YES | TBC | 🔴 |

| Status_Name | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 CallPurpose_Master (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 CallStatus_Master (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 CashDenominationMaster (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| DisplayOrder | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |

| Value | numeric | YES | TBC | 🔴 |



---


#### 🔴 CasteMaster (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CasteName | nvarchar | YES | TBC | 🔴 |

| CommunityID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | date | YES | TBC | 🔴 |

| Desc | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 CategoryChangeRequest (22 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdmissionNo | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| CurrentFeesAmount | numeric | YES | TBC | 🔴 |

| CurrentFeesCategoryID | bigint | YES | TBC | 🔴 |

| CurrentFeesSubCategoryID | bigint | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | date | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| NewFeesCategoryID | bigint | YES | TBC | 🔴 |

| NewFeesSubCategoryID | bigint | YES | TBC | 🔴 |

| PaidAmount | numeric | YES | TBC | 🔴 |

| ReasonForChange | varchar | YES | TBC | 🔴 |

| RequestStatus | varchar | YES | TBC | 🔴 |

| Requested_Date | datetime | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| StudentName | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 CertificateTemplate (18 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CertificateContent | nvarchar | YES | TBC | 🔴 |

| CertificateDate | nvarchar | YES | TBC | 🔴 |

| CertificateNo | nvarchar | YES | TBC | 🔴 |

| CertificateSignatureLeft | nvarchar | YES | TBC | 🔴 |

| CertificateSignatureMiddle | nvarchar | YES | TBC | 🔴 |

| CertificateSignatureRight | nvarchar | YES | TBC | 🔴 |

| CertificateTitle | nvarchar | YES | TBC | 🔴 |

| CertificateTypeID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | date | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 ChaloBanner (3 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| ID | bigint | NO | TBC | 🔴 |

| Image | nvarchar | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 CheckListMapping (14 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Department_Id | bigint | YES | TBC | 🔴 |

| Description | nvarchar | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Role_Id | bigint | YES | TBC | 🔴 |

| Role_Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 ChecklistMaster (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | date | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IsMandatory | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| TypeID | int | YES | TBC | 🔴 |

| TypeName | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | date | YES | TBC | 🔴 |



---


#### 🔴 CityMaster (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Country_ID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| State_ID | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 CoSholasticTypeOneMaster (14 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CategoryType | nvarchar | NO | TBC | 🔴 |

| CategoryTypeID | bigint | NO | TBC | 🔴 |

| CreatedBy | bigint | NO | TBC | 🔴 |

| CreatedOn | datetime | NO | TBC | 🔴 |

| Deleted | bit | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsActive | bit | NO | TBC | 🔴 |

| PageNumber | nvarchar | NO | TBC | 🔴 |

| PageNumberID | bigint | NO | TBC | 🔴 |

| SubjectID | bigint | NO | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedOn | datetime | YES | TBC | 🔴 |



---


#### 🔴 Community_Master (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 Competencies (15 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassIDs | nvarchar | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| CurriculumID | bigint | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| DisplayOrder | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| SubjectIDs | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 CountryMaster (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 CourseCompletionCertificate (27 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdmissionNo | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ClassName | nvarchar | YES | TBC | 🔴 |

| FatherName | nvarchar | YES | TBC | 🔴 |

| GuardianName | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IssuedBy | nvarchar | YES | TBC | 🔴 |

| IssuedDate | date | YES | TBC | 🔴 |

| MotherName | nvarchar | YES | TBC | 🔴 |

| Purpose | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| SchoolAcademicYear | nvarchar | YES | TBC | 🔴 |

| SchoolAddress1 | nvarchar | YES | TBC | 🔴 |

| SchoolAddress2 | nvarchar | YES | TBC | 🔴 |

| SchoolLogo | nvarchar | YES | TBC | 🔴 |

| SchoolMobileNo | nvarchar | YES | TBC | 🔴 |

| SchoolName | nvarchar | YES | TBC | 🔴 |

| SchoolPhone1 | nvarchar | YES | TBC | 🔴 |

| SchoolPhone2 | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| SectionName | nvarchar | YES | TBC | 🔴 |

| SequenceNumber | nvarchar | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| StudentName | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 CreditNoteMaster (18 columns) — [PENDING]


**Purpose:** Credit notes (salary adjustments).


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdjustedBillNos | varchar | YES | TBC | 🔴 |

| BalanceAmount | numeric | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| CreditNoteAmount | numeric | YES | TBC | 🔴 |

| CreditNoteDate | datetime | YES | TBC | 🔴 |

| CreditNoteNo | varchar | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Narration | varchar | YES | TBC | 🔴 |

| PaidBillNos | varchar | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 CumulativeLogicMaster (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Deleted | bit | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Name | nvarchar | NO | TBC | 🔴 |



---


#### 🔴 CurriculumGoals (20 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | nvarchar | YES | TBC | 🔴 |

| ClassName | nvarchar | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| DisplayOrder | bigint | YES | TBC | 🔴 |

| GradeID | bigint | YES | TBC | 🔴 |

| GradeName | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| SubjectID | nvarchar | YES | TBC | 🔴 |

| SubjectName | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 DayclosureMaster (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CollectedByID | bigint | YES | TBC | 🔴 |

| CollectedByName | nvarchar | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DayClosureDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 DayclosureMaster_Details (15 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| CollectedAmount | decimal | YES | TBC | 🔴 |

| CollectionMode_ID | bigint | YES | TBC | 🔴 |

| CollectionMode_Name | nvarchar | YES | TBC | 🔴 |

| CompanyID | bigint | YES | TBC | 🔴 |

| CompanyName | nvarchar | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| HeaderID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Type | bigint | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 Dayclosuremaster_cashdenomination (14 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Amount | decimal | YES | TBC | 🔴 |

| CompanyID | bigint | YES | TBC | 🔴 |

| CompanyName | nvarchar | YES | TBC | 🔴 |

| Count | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| Denomination | nvarchar | YES | TBC | 🔴 |

| HeaderID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 Device_Master (18 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| DeviceId | nvarchar | YES | TBC | 🔴 |

| DeviceName | nvarchar | YES | TBC | 🔴 |

| DeviceType | nvarchar | YES | TBC | 🔴 |

| DeviceTypeId | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IPAddress | nvarchar | YES | TBC | 🔴 |

| IsActive | bit | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| LastSyncTime | datetime | YES | TBC | 🔴 |

| Location | nvarchar | YES | TBC | 🔴 |

| MachineNumber | nvarchar | YES | TBC | 🔴 |

| PortNumber | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 DistrictMaster (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Country_ID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | varchar | YES | TBC | 🔴 |

| State_ID | bigint | YES | TBC | 🔴 |

| Updated_By_ID | bigint | YES | TBC | 🔴 |



---


#### 🗑️ EmployeeMaster (18 columns) — [DEPRECATED]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**🗑️ Deprecated:** Use Staff_Master (deprecated — empty or stale in the live DB)


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BankAccountNo | nvarchar | YES | TBC | 🔴 |

| BankBranchName | nvarchar | YES | TBC | 🔴 |

| BankIFSCCode | nvarchar | YES | TBC | 🔴 |

| BankName | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IsHold | bit | YES | TBC | 🔴 |

| LeaveCategoryID | bigint | YES | TBC | 🔴 |

| PaymentModeID | bigint | YES | TBC | 🔴 |

| SalaryStructureID | bigint | YES | TBC | 🔴 |

| ShiftID | bigint | YES | TBC | 🔴 |

| StaffID | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 ExcuseEntry (21 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdmissionNo | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ClassName | nvarchar | YES | TBC | 🔴 |

| ContactNo | nvarchar | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | date | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| EnrollmentNo | nvarchar | YES | TBC | 🔴 |

| ExcuseDate | date | YES | TBC | 🔴 |

| FatherName | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| RollNo | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| SectionName | nvarchar | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| StudentName | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | date | YES | TBC | 🔴 |



---


#### 🔴 ExperienceCertificate (14 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| BranchName | nvarchar | YES | TBC | 🔴 |

| Designation | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IssuedBy | nvarchar | YES | TBC | 🔴 |

| IssuedDate | date | YES | TBC | 🔴 |

| Purpose | nvarchar | YES | TBC | 🔴 |

| RelievingDate | date | YES | TBC | 🔴 |

| SequenceNumber | nvarchar | YES | TBC | 🔴 |

| StaffDOJ | date | YES | TBC | 🔴 |

| StaffID | bigint | YES | TBC | 🔴 |

| StaffName | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 ExtraCurricularActivityMaster (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| DisplayOrder | int | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | NO | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 GQPaymentInstalment (17 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| CreatedDate | datetime | YES | TBC | 🔴 |

| EventAmount | decimal | YES | TBC | 🔴 |

| EventDate | datetime | YES | TBC | 🔴 |

| EventName | nvarchar | YES | TBC | 🔴 |

| EventStatusID | int | YES | TBC | 🔴 |

| EventStatusName | nvarchar | YES | TBC | 🔴 |

| EventType | nvarchar | YES | TBC | 🔴 |

| Event_Paidamount | decimal | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| TxnHeaderID | bigint | YES | TBC | 🔴 |

| UTR | nvarchar | YES | TBC | 🔴 |

| tenure | int | YES | TBC | 🔴 |

| tenure_paid | int | YES | TBC | 🔴 |

| tenure_pending | int | YES | TBC | 🔴 |

| total_outstanding | decimal | YES | TBC | 🔴 |

| total_paid | decimal | YES | TBC | 🔴 |



---


#### 🔴 GQPaymentTXNDetails (7 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| ApplicantID | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| EventName | nvarchar | YES | TBC | 🔴 |

| GQData | text | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| OrderID | nvarchar | YES | TBC | 🔴 |

| TxnHeaderID | bigint | YES | TBC | 🔴 |



---


#### 🔴 GSTMaster (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Description | varchar | YES | TBC | 🔴 |

| DisplayOrder | bigint | YES | TBC | 🔴 |

| ID | int | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 GalleryFiles (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Folder_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Imagepath | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 GalleryFolder (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| FolderName | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 GenderMaster (3 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| ID | bigint | NO | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Type | bigint | YES | TBC | 🔴 |



---


#### 🔴 Hostel_Master (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 Hostel_MasterDetails (9 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Amenities | nvarchar | YES | TBC | 🔴 |

| Amount | numeric | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Dimension | nvarchar | YES | TBC | 🔴 |

| HostelMaster_ID | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| MaximumNoStudent | bigint | YES | TBC | 🔴 |

| RoomNo | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 ImmigrationStatusMaster (10 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | NO | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 LaboratoryDetails (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| LaboratoryMasterID | bigint | YES | TBC | 🔴 |

| SubjectID | bigint | YES | TBC | 🔴 |

| SubjectName | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 LaboratoryMaster (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 Language_Master (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 LevelMaster (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Desc | nvarchar | YES | TBC | 🔴 |

| DisplayOrder | int | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 Month_Master (8 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Actual_Month_No | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| EndDate | date | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Month_Name | nvarchar | YES | TBC | 🔴 |

| Month_No | bigint | YES | TBC | 🔴 |

| StartDate | date | YES | TBC | 🔴 |



---


#### 🔴 MotherTongue_Master (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 Nationality_Master (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 OnlinePaymentOptions (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Code | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| PaymentMode | nvarchar | YES | TBC | 🔴 |

| Status | bit | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 PaymentGatewayLog (14 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| ChaloOrderID | nvarchar | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| ErrorMessage | nvarchar | YES | TBC | 🔴 |

| GatewayName | nvarchar | YES | TBC | 🔴 |

| GatewayOrderID | nvarchar | YES | TBC | 🔴 |

| LogID | bigint | NO | TBC | 🔴 |

| RequestID | nvarchar | YES | TBC | 🔴 |

| RequestPayload | nvarchar | YES | TBC | 🔴 |

| RequestTimeStamp | nvarchar | YES | TBC | 🔴 |

| RequestType | nvarchar | YES | TBC | 🔴 |

| RequestURL | nvarchar | YES | TBC | 🔴 |

| ResponsePayload | nvarchar | YES | TBC | 🔴 |

| ServiceAgent | nvarchar | YES | TBC | 🔴 |

| Status | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 Reason_Master (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Code | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Reason | nvarchar | YES | TBC | 🔴 |

| ScreenID | numeric | YES | TBC | 🔴 |

| ScreenName | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 Relationship_Master (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Desc | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bigint | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 Religion_Master (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 RollNumAllocation (17 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| GenderType_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| OrderType_ID | bigint | YES | TBC | 🔴 |

| Prefix | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| SelectedSort | nvarchar | YES | TBC | 🔴 |

| StartsWithRollNumber | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 SpecialEventMaster (24 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| ActualEndDate | datetime | YES | TBC | 🔴 |

| ActualStartDate | datetime | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| EventDescription | nvarchar | YES | TBC | 🔴 |

| EventStatus | int | YES | TBC | 🔴 |

| From_Date | datetime | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| NoofPeoples | int | YES | TBC | 🔴 |

| NoofStaffs | int | YES | TBC | 🔴 |

| NoofStudents | int | YES | TBC | 🔴 |

| School_Id | bigint | YES | TBC | 🔴 |

| To_Date | datetime | YES | TBC | 🔴 |

| Type_ID | bigint | YES | TBC | 🔴 |

| Type_Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 StateMaster (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Country_ID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 StreamMaster (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Description | varchar | YES | TBC | 🔴 |

| DisplayOrder | bigint | YES | TBC | 🔴 |

| ID | int | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 StudyCertificate (27 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdmissionNo | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ClassName | nvarchar | YES | TBC | 🔴 |

| FatherName | nvarchar | YES | TBC | 🔴 |

| GuardianName | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IssuedBy | nvarchar | YES | TBC | 🔴 |

| IssuedDate | date | YES | TBC | 🔴 |

| MotherName | nvarchar | YES | TBC | 🔴 |

| Purpose | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| SchoolAcademicYear | nvarchar | YES | TBC | 🔴 |

| SchoolAddress1 | nvarchar | YES | TBC | 🔴 |

| SchoolAddress2 | nvarchar | YES | TBC | 🔴 |

| SchoolLogo | nvarchar | YES | TBC | 🔴 |

| SchoolMobileNo | nvarchar | YES | TBC | 🔴 |

| SchoolName | nvarchar | YES | TBC | 🔴 |

| SchoolPhone1 | nvarchar | YES | TBC | 🔴 |

| SchoolPhone2 | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| SectionName | nvarchar | YES | TBC | 🔴 |

| SequenceNumber | nvarchar | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| StudentName | nvarchar | YES | TBC | 🔴 |



---


#### ✅ SubjectAllocation_Master (17 columns) — [CONFIRMED]


**Purpose:** Teacher→Subject→Class→Section mapping. Has Staff_ID, Subject_ID, Class_ID, Section_ID, IsClassTeacher.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AssociateStaffID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_ID | bigint | YES | FK → ClassMaster.ID (the class). | ✅ |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsClassTeacher | bit | YES | 1 = this teacher is the class teacher for this class+section. | ✅ |

| IsDeleted | bit | YES | TBC | 🔴 |

| Proficiency_Level | bigint | YES | TBC | 🔴 |

| Section_ID | bigint | YES | FK → SectionMaster.ID (the section). | ✅ |

| Staff_ID | bigint | YES | FK → Staff_Master.Staff_ID (the teacher assigned). | ✅ |

| Subject_ID | bigint | YES | FK → Subject_Master.Id (the subject taught). | ✅ |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



**Foreign keys:**

- Staff_ID → Staff_Master.Staff_ID (CONFIRMED)


- Subject_ID → Subject_Master.Id (CONFIRMED)
 — PK is lowercase 'Id'


- Class_ID → ClassMaster.ID (CONFIRMED)


- Section_ID → SectionMaster.ID (CONFIRMED)




---


#### 🔴 SubjectGroupMapping (15 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AvailabilityType | int | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| GroupID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| SubjectID | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 SubjectTypeMaster (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Type | bit | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### ✅ Subject_Master (25 columns) — [CONFIRMED]


**Purpose:** Subject list. PK is 'Id' (lowercase d, NOT 'ID'). Has Name (the subject name — casing varies by branch: 'MATHS' or 'Maths').


**⚠️ Gotcha:** PK is lowercase 'Id' (not 'ID').


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| HPCDisplayName | nvarchar | YES | TBC | 🔴 |

| HaveExam | bit | YES | TBC | 🔴 |

| HaveTimeTable | bit | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsActivity | bit | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IsDomain | bit | YES | TBC | 🔴 |

| IsGroup | bit | YES | TBC | 🔴 |

| IsHPCApplicable | bit | YES | TBC | 🔴 |

| IsLab | bit | YES | TBC | 🔴 |

| IsLanguage | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| OrderNo | bigint | YES | TBC | 🔴 |

| Parentid | bigint | YES | TBC | 🔴 |

| SubShortName | nvarchar | YES | TBC | 🔴 |

| Subject_Type_Id | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 TT_SubjectAllocation_Master (17 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AssociateStaffID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_ID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsClassTeacher | bit | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Proficiency_Level | bigint | YES | TBC | 🔴 |

| Section_ID | bigint | YES | TBC | 🔴 |

| Staff_ID | bigint | YES | TBC | 🔴 |

| Subject_ID | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### ✅ TermMaster (18 columns) — [CONFIRMED]


**Purpose:** Stores fee payment terms/installments for a branch. Each term has a date range (StartingDate/EndingDate) for 'current term' resolution.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| DisplayOrder | int | YES | The term's display order (1, 2, 3). Used to find the 'previous term' (DisplayOrder < current). | ✅ |

| EndingDate | date | YES | The fee term's end date (type: date). | ✅ |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IsMandatory | bit | YES | 1 = mandatory fee term (must be paid); 0 = optional. | ✅ |

| Name | nvarchar | YES | TBC | 🔴 |

| StartingDate | date | YES | The fee term's start date (type: date). Use GETDATE() BETWEEN StartingDate AND EndingDate for 'current term'. | ✅ |

| TotalNoMonths | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 ThingsDid (19 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_Id | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Date | date | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| Section_Id | bigint | YES | TBC | 🔴 |

| Staff_Id | bigint | YES | TBC | 🔴 |

| SubjectName | nvarchar | YES | TBC | 🔴 |

| Subject_Id | bigint | YES | TBC | 🔴 |

| Teacher | nvarchar | YES | TBC | 🔴 |

| ThingsWeDidImg | varchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 ThingsWeDidDetails (9 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_Id | bigint | YES | TBC | 🔴 |

| FromDate | date | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Section_Id | bigint | YES | TBC | 🔴 |

| Title | nvarchar | YES | TBC | 🔴 |

| ToDate | date | YES | TBC | 🔴 |



---


#### 🔴 UOM_Master (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 VoiceAudioLibrary (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearId | bigint | YES | TBC | 🔴 |

| BranchId | bigint | YES | TBC | 🔴 |

| CreatedBy | int | NO | TBC | 🔴 |

| CreatedOn | datetime | NO | TBC | 🔴 |

| GatewayLibraryId | nvarchar | NO | TBC | 🔴 |

| Id | int | NO | TBC | 🔴 |

| LocalAudioFileName | nvarchar | YES | TBC | 🔴 |

| Name | nvarchar | NO | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | int | YES | TBC | 🔴 |

| UpdatedOn | datetime | YES | TBC | 🔴 |



---


#### 🔴 WorkFlowMaster (18 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Is_Mandatory | bit | YES | TBC | 🔴 |

| ScreenID | bigint | YES | TBC | 🔴 |

| ScreenName | nvarchar | YES | TBC | 🔴 |

| Stage_Order | bigint | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |

| UserID | bigint | YES | TBC | 🔴 |

| UserName | nvarchar | YES | TBC | 🔴 |

| Workflow_Code | nvarchar | YES | TBC | 🔴 |

| Workflow_Name | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 WorkFlow_Details (21 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| ApprovalRemarks | nvarchar | YES | TBC | 🔴 |

| ApprovalStatus | int | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| CurrentStageID | bigint | YES | TBC | 🔴 |

| CurrentStageName | nvarchar | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| HeaderID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| MasterID | bigint | YES | TBC | 🔴 |

| NextStageID | bigint | YES | TBC | 🔴 |

| NextStageName | nvarchar | YES | TBC | 🔴 |

| ScreenID | bigint | YES | TBC | 🔴 |

| Stage_Order | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 tblPCConfiguration (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ExamTermID | bigint | YES | TBC | 🔴 |

| ExamTypeID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bigint | YES | TBC | 🔴 |

| ModelTypeID | bigint | YES | TBC | 🔴 |

| ModelTypeName | nvarchar | YES | TBC | 🔴 |

| ProgressCardTypeID | bigint | YES | TBC | 🔴 |

| RTID | bigint | YES | TBC | 🔴 |

| RTName | nvarchar | YES | TBC | 🔴 |

| RandomColorNo | bigint | YES | TBC | 🔴 |



---


### Fees (59 tables)


#### ✅ BusFeeStrucure (24 columns) — [CONFIRMED]


**Purpose:** Per-student bus fee. MISSPELLED (no second 't' — 'Strucure' not 'Structure'). Has Term_ID → TermMaster.ID, Route_ID, TripID → Transport_TripDetails.


**⚠️ Gotcha:** MISSPELLED in production — missing the second 't'. 'BusFeeStructure' does NOT exist. 32 SPs use the misspelled name.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AcademicYearName | nvarchar | YES | TBC | 🔴 |

| Amount | numeric | YES | TBC | 🔴 |

| BoardingPoint_ID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| BranchName | nvarchar | YES | TBC | 🔴 |

| Class_ID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| FeeApplicableDate | date | YES | TBC | 🔴 |

| Fees_ID | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Month_Name | nvarchar | YES | TBC | 🔴 |

| Month_No | bigint | YES | TBC | 🔴 |

| Route_ID | bigint | YES | TBC | 🔴 |

| Section_ID | bigint | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |

| Term_ID | bigint | YES | TBC | 🔴 |

| TripID | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



**Foreign keys:**

- Term_ID → TermMaster.ID (CONFIRMED)
 — Fee terms


- TripID → Transport_TripDetails.ID (CONFIRMED)
 — NOT a fixed enum 1/2 — real FK




---


#### 🔴 ChecklistCollection (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ChecklistID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| StaffID | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |



---


#### 🔴 CollectionMode_Master (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsClearance | bit | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 Concession_Category_Details (7 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ConcessionCategoryID | bigint | YES | TBC | 🔴 |

| Concession_Flat | numeric | YES | TBC | 🔴 |

| Concession_Percent | numeric | YES | TBC | 🔴 |

| FeesID | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |



---


#### 🔴 Concession_Category_Master (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 Concession_Master (19 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdmissionType_ID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ConcessionCategory_ID | bigint | YES | TBC | 🔴 |

| Concession_Amount | numeric | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| FeeStructureMonthDetails_ID | bigint | YES | TBC | 🔴 |

| Fees_ID | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| MonthNo | int | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| Structure_Type | nvarchar | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 Concession_Master_Request (21 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdminRemarks | nvarchar | YES | TBC | 🔴 |

| AdmissionType_ID | bigint | YES | TBC | 🔴 |

| ApprovalStatus | int | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ConcessionCategory_ID | bigint | YES | TBC | 🔴 |

| Concession_Amount | numeric | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| FeeStructureMonthDetails_ID | bigint | YES | TBC | 🔴 |

| Fees_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| MonthNo | int | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| Structure_Type | nvarchar | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 DonationFeesCollection (41 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Admission_No | nvarchar | YES | TBC | 🔴 |

| Bank | nvarchar | YES | TBC | 🔴 |

| Bill_Date | datetime | YES | TBC | 🔴 |

| Bill_No | nvarchar | YES | TBC | 🔴 |

| Bill_No_WO_Prefix | bigint | YES | TBC | 🔴 |

| Branch | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Cancellation_Date | date | YES | TBC | 🔴 |

| Cancelled_By_ID | bigint | YES | TBC | 🔴 |

| Cancelled_By_Name | nvarchar | YES | TBC | 🔴 |

| ChequeClearanceDate | datetime | YES | TBC | 🔴 |

| ChequeStatus_ID | int | YES | TBC | 🔴 |

| ChequeStatus_Name | nvarchar | YES | TBC | 🔴 |

| Class_ID | bigint | YES | TBC | 🔴 |

| Collected_By_ID | bigint | YES | TBC | 🔴 |

| Collected_By_Name | nvarchar | YES | TBC | 🔴 |

| CollectionType_ID | bigint | YES | TBC | 🔴 |

| CollectionType_Name | nvarchar | YES | TBC | 🔴 |

| Collection_Mode_ID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Enrollment_No | nvarchar | YES | TBC | 🔴 |

| FromMonth | bigint | YES | TBC | 🔴 |

| FromMonthName | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| ItemReference_Date | date | YES | TBC | 🔴 |

| ItemReference_No | nvarchar | YES | TBC | 🔴 |

| Misc_Receipt_Amt | numeric | YES | TBC | 🔴 |

| Narration | nvarchar | YES | TBC | 🔴 |

| Reason_For_Cancellation | nvarchar | YES | TBC | 🔴 |

| Receipt_Amt | numeric | YES | TBC | 🔴 |

| Section_ID | bigint | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |

| ToMonth | bigint | YES | TBC | 🔴 |

| ToMonthName | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 DonationFeesCollection_Details (22 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Company_ID | bigint | YES | TBC | 🔴 |

| Concession_Amount | numeric | YES | TBC | 🔴 |

| FeeStructureMonths_ID | bigint | YES | TBC | 🔴 |

| FeesCategory_ID | bigint | YES | TBC | 🔴 |

| FeesCategory_Name | nvarchar | YES | TBC | 🔴 |

| FeesGroup_ID | bigint | YES | TBC | 🔴 |

| FeesGroup_Name | nvarchar | YES | TBC | 🔴 |

| FeesType_ID | bigint | YES | TBC | 🔴 |

| FeesType_Name | nvarchar | YES | TBC | 🔴 |

| Fees_Amount | numeric | YES | TBC | 🔴 |

| Fees_Collection_ID | bigint | YES | TBC | 🔴 |

| Fees_Head_ID | bigint | YES | TBC | 🔴 |

| Fees_Month | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| Month_No | bigint | YES | TBC | 🔴 |

| Paid_Amt | numeric | YES | TBC | 🔴 |

| Remaining_Amt | numeric | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| Structure_Type | nvarchar | YES | TBC | 🔴 |

| Term_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 FeeStructure (24 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AcademicYearName | nvarchar | YES | TBC | 🔴 |

| AnnualDiscountConcessionCategoryID | bigint | YES | TBC | 🔴 |

| Approved_By_Id | bigint | YES | TBC | 🔴 |

| Approved_By_Name | nvarchar | YES | TBC | 🔴 |

| Approved_Date | datetime | YES | TBC | 🔴 |

| Approved_Status_Id | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| BranchName | nvarchar | YES | TBC | 🔴 |

| Class_ID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_By_Name | nvarchar | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsAnnualDiscountApplicable | bit | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Section_ID | bigint | YES | TBC | 🔴 |

| Structure_Code | nvarchar | YES | TBC | 🔴 |

| StudentFeeCategoryID | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |

| ValidUpto | date | YES | TBC | 🔴 |



---


#### 🔴 FeeStructureDetail (16 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Applicable_For | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Company_Id | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| FeesCategory_ID | bigint | YES | TBC | 🔴 |

| FeesCategory_Name | nvarchar | YES | TBC | 🔴 |

| FeesStructure_ID | bigint | YES | TBC | 🔴 |

| FeesType_ID | bigint | YES | TBC | 🔴 |

| FeesType_Name | nvarchar | YES | TBC | 🔴 |

| Fees_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDonation | nvarchar | YES | TBC | 🔴 |

| IsFeeOptional | nvarchar | YES | TBC | 🔴 |

| IsVaryForGender | nvarchar | YES | TBC | 🔴 |

| LastDay_To_Pay | int | YES | TBC | 🔴 |



---


#### 🔴 FeeStructureMonth (18 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Amount_For_Boy | numeric | YES | TBC | 🔴 |

| Amount_For_Girl | numeric | YES | TBC | 🔴 |

| Amount_For_Transcend | numeric | YES | TBC | 🔴 |

| AnnualDiscountFlat | numeric | YES | TBC | 🔴 |

| AnnualDiscountFlat_Girl | numeric | YES | TBC | 🔴 |

| AnnualDiscountFlat_Transgen | numeric | YES | TBC | 🔴 |

| AnnualDiscountPercent | numeric | YES | TBC | 🔴 |

| AnnualDiscountPercent_Girl | numeric | YES | TBC | 🔴 |

| AnnualDiscountPercent_Transgen | numeric | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| FeeApplicableDate | date | YES | TBC | 🔴 |

| FeesStructureDetail_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsChecked | nvarchar | YES | TBC | 🔴 |

| Month_Name | nvarchar | YES | TBC | 🔴 |

| Month_No | bigint | YES | TBC | 🔴 |

| Term_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 FeeStructureMonthPartialPayments (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Amount | numeric | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| FeeStructureMonthID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| PartialNo | int | YES | TBC | 🔴 |



---


#### 🔴 FeedbackCategory (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsActive | bit | NO | TBC | 🔴 |

| IsDeleted | bit | NO | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 FeedbackEmailTemplates (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AvailablePlaceholders | varchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| EmailBodyHTML | nvarchar | NO | TBC | 🔴 |

| EmailSubject | nvarchar | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsActive | bit | NO | TBC | 🔴 |

| IsDeleted | bit | NO | TBC | 🔴 |

| TemplateCode | varchar | NO | TBC | 🔴 |

| TemplateName | varchar | NO | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 FeedbackEscalationLog (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| CreatedDate | datetime | NO | TBC | 🔴 |

| EscalatedLevel | int | NO | TBC | 🔴 |

| EscalatedToDeptID | bigint | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsEmailSent | bit | NO | TBC | 🔴 |

| TicketID | bigint | NO | TBC | 🔴 |



---


#### 🔴 FeedbackEscalationMatrix (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| DepartmentID | bigint | NO | TBC | 🔴 |

| DisplayOrder | int | NO | TBC | 🔴 |

| EscalationHours | int | NO | TBC | 🔴 |

| FeedbackCategoryID | bigint | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |



---


#### 🟡 FeedbackTicket (17 columns) — [PARTIAL]


**Purpose:** Parent feedback tickets. Columns partially known — the model hallucinated 'ParentChildIndicator' which doesn't exist.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AttachmentFile | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CategoryID | bigint | YES | TBC | 🔴 |

| ContactName | nvarchar | YES | TBC | 🔴 |

| ContactNumber | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| EmailID | nvarchar | YES | TBC | 🔴 |

| FeedbackText | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Relation | nvarchar | YES | TBC | 🔴 |

| Status | nvarchar | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| Subject | nvarchar | YES | TBC | 🔴 |

| TicketNo | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 FeedbackTicketReplies (7 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AttachmentFile | nvarchar | YES | TBC | 🔴 |

| RepliedBy | bigint | NO | TBC | 🔴 |

| RepliedOn | datetime | NO | TBC | 🔴 |

| ReplyFrom | varchar | NO | TBC | 🔴 |

| ReplyID | bigint | NO | TBC | 🔴 |

| ReplyText | nvarchar | NO | TBC | 🔴 |

| TicketID | bigint | NO | TBC | 🔴 |



---


#### ✅ FeesCollection (46 columns) — [CONFIRMED]


**Purpose:** Actual money received. Amount column is Receipt_Amt (not 'Amt'). Has ChequeStatus_ID (3=bounced, 4=cancelled — filter NOT IN (3,4)). PK is lowercase 'Id'.


**⚠️ Gotcha:** PK is lowercase 'Id' (not 'ID'). Amount column is 'Receipt_Amt' (not 'Amt' — 'Amt' doesn't exist).


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Admission_No | nvarchar | YES | TBC | 🔴 |

| AnnualDiscount_Amt | numeric | YES | TBC | 🔴 |

| Bank | nvarchar | YES | TBC | 🔴 |

| Bill_Date | datetime | YES | The receipt date. Use CAST(Bill_Date AS DATE) for date comparisons. | ✅ |

| Bill_No | nvarchar | YES | TBC | 🔴 |

| Bill_No_WO_Prefix | bigint | YES | TBC | 🔴 |

| Branch | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Cancellation_Date | date | YES | TBC | 🔴 |

| Cancelled_By_ID | bigint | YES | TBC | 🔴 |

| Cancelled_By_Name | nvarchar | YES | TBC | 🔴 |

| ChequeClearanceDate | datetime | YES | TBC | 🔴 |

| ChequeStatus_ID | int | YES | 1=cleared, 2=deposited, 3=bounced, 4=cancelled. Filter NOT IN (3,4) for collection totals. | ✅ |

| ChequeStatus_Name | nvarchar | YES | TBC | 🔴 |

| Class_ID | bigint | YES | TBC | 🔴 |

| Collected_By_ID | bigint | YES | TBC | 🔴 |

| Collected_By_Name | nvarchar | YES | TBC | 🔴 |

| CollectionType_ID | bigint | YES | TBC | 🔴 |

| CollectionType_Name | nvarchar | YES | TBC | 🔴 |

| Collection_Mode_ID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Enrollment_No | nvarchar | YES | TBC | 🔴 |

| FromMonth | bigint | YES | TBC | 🔴 |

| FromMonthName | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | PK — lowercase 'd' (not 'ID'). Inconsistent with most other tables. | ✅ |

| IsAnnualDiscountApplied | bit | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IsReceiptPrinted | bit | YES | TBC | 🔴 |

| IsTallyPosted | bit | YES | TBC | 🔴 |

| ItemReference_Date | date | YES | TBC | 🔴 |

| ItemReference_No | nvarchar | YES | TBC | 🔴 |

| Misc_Receipt_Amt | numeric | YES | TBC | 🔴 |

| Narration | nvarchar | YES | TBC | 🔴 |

| Reason_For_Cancellation | nvarchar | YES | TBC | 🔴 |

| ReceiptPrintedOn | datetime | YES | TBC | 🔴 |

| Receipt_Amt | numeric | YES | The real amount column (NOT 'Amt' — 'Amt' doesn't exist). | ✅ |

| Section_ID | bigint | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |

| ToMonth | bigint | YES | TBC | 🔴 |

| ToMonthName | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 FeesCollectionPriority (17 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AcademicYearName | nvarchar | YES | TBC | 🔴 |

| ActiveStatus | int | YES | TBC | 🔴 |

| ApprovalStatus | int | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Reason | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 FeesCollectionPriority_Details (15 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Amount | decimal | YES | TBC | 🔴 |

| Company_ID | bigint | YES | TBC | 🔴 |

| Company_Name | nvarchar | YES | TBC | 🔴 |

| FeeGroup_ID | bigint | YES | TBC | 🔴 |

| FeeGroup_Name | nvarchar | YES | TBC | 🔴 |

| FeesCategory_ID | bigint | YES | TBC | 🔴 |

| FeesCategory_Name | nvarchar | YES | TBC | 🔴 |

| Fees_ID | bigint | YES | TBC | 🔴 |

| Fees_Name | nvarchar | YES | TBC | 🔴 |

| HeaderID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Month_Name | nvarchar | YES | TBC | 🔴 |

| Month_No | bigint | YES | TBC | 🔴 |

| Term_ID | bigint | YES | TBC | 🔴 |

| Term_Name | nvarchar | YES | TBC | 🔴 |



---


#### ✅ FeesCollection_Details (31 columns) — [CONFIRMED]


**Purpose:** Per-receipt line items. Term_ID → TermMaster.ID. Has Paid_Amt, Remaining_Amt, Concession_Amount.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AnnualDiscount_Amt | numeric | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Company_ID | bigint | YES | TBC | 🔴 |

| Concession_Amount | numeric | YES | TBC | 🔴 |

| Concession_With_GST | numeric | YES | TBC | 🔴 |

| FeeStructureMonths_ID | bigint | YES | TBC | 🔴 |

| FeesCategory_ID | bigint | YES | TBC | 🔴 |

| FeesCategory_Name | nvarchar | YES | TBC | 🔴 |

| FeesGroup_ID | bigint | YES | TBC | 🔴 |

| FeesGroup_Name | nvarchar | YES | TBC | 🔴 |

| FeesType_ID | bigint | YES | TBC | 🔴 |

| FeesType_Name | nvarchar | YES | TBC | 🔴 |

| Fees_Amount | numeric | YES | TBC | 🔴 |

| Fees_Collection_ID | bigint | YES | TBC | 🔴 |

| Fees_Head_ID | bigint | YES | TBC | 🔴 |

| Fees_Month | nvarchar | YES | TBC | 🔴 |

| GSTAmount | decimal | YES | TBC | 🔴 |

| GSTPercentage | decimal | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsAnnualDiscountApplied | bit | YES | TBC | 🔴 |

| LateFeeAmount | numeric | YES | TBC | 🔴 |

| LateFeeName | varchar | YES | TBC | 🔴 |

| Month_No | bigint | YES | TBC | 🔴 |

| Paid_Amt | numeric | YES | TBC | 🔴 |

| Payable_Amt | numeric | YES | TBC | 🔴 |

| Remaining_Amt | numeric | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| Structure_Type | nvarchar | YES | TBC | 🔴 |

| Term_ID | bigint | YES | TBC | 🔴 |

| TotalAmountExcludingGst | decimal | YES | TBC | 🔴 |



**Foreign keys:**

- Term_ID → TermMaster.ID (CONFIRMED)
 — Fee terms — NOT ExamTermMaster


- Fees_Collection_ID → FeesCollection.Id (CONFIRMED)
 — PK is lowercase 'Id'




---


#### 🔴 FeesCollection_MiscellaneousDetails (21 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Company_ID | bigint | YES | TBC | 🔴 |

| FeesCategory_ID | bigint | YES | TBC | 🔴 |

| FeesCategory_Name | nvarchar | YES | TBC | 🔴 |

| FeesGroup_ID | bigint | YES | TBC | 🔴 |

| FeesGroup_Name | nvarchar | YES | TBC | 🔴 |

| FeesType_ID | bigint | YES | TBC | 🔴 |

| FeesType_Name | nvarchar | YES | TBC | 🔴 |

| Fees_Collection_ID | bigint | YES | TBC | 🔴 |

| Fees_Head_ID | bigint | YES | TBC | 🔴 |

| Fees_Month | nvarchar | YES | TBC | 🔴 |

| GSTAmount | decimal | YES | TBC | 🔴 |

| GSTPercentage | decimal | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| Month_No | bigint | YES | TBC | 🔴 |

| Paid_Amt | numeric | YES | TBC | 🔴 |

| Payable_Amt | numeric | YES | TBC | 🔴 |

| Structure_Type | nvarchar | YES | TBC | 🔴 |

| Term_ID | bigint | YES | TBC | 🔴 |

| TotalAmountExcludingGst | decimal | YES | TBC | 🔴 |



---


#### 🔴 FeesCollection_ModeDetails (9 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Amount | numeric | YES | TBC | 🔴 |

| Bank | nvarchar | YES | TBC | 🔴 |

| Branch | nvarchar | YES | TBC | 🔴 |

| Collection_Mode_ID | bigint | YES | TBC | 🔴 |

| Company_ID | bigint | YES | TBC | 🔴 |

| Fees_Collection_ID | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| ItemReference_Date | date | YES | TBC | 🔴 |

| ItemReference_No | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 FeesGroup_Master (18 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| GSTValue | numeric | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IsGSTApplicable | bit | YES | TBC | 🔴 |

| IsShowOnline | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| School_ID | bigint | YES | TBC | 🔴 |

| TallyName | nvarchar | YES | TBC | 🔴 |

| TypeID | bit | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### ✅ FeesInformationStudentDetail (39 columns) — [CONFIRMED]


**Purpose:** Per-student fee demand — THE table for 'how much does a student owe'. Outstanding = Amount - Concession_Amt - Paid_Amt - Lien_Amount. Has Term_ID → TermMaster.ID (fee terms, NOT exam terms).


**⚠️ Gotcha:** Does NOT have an IsDeleted column — soft-delete is via Paid_Amt/Lien_Amount updates (via SP_Update_OutstandingAmount).


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AcademicYearName | nvarchar | YES | TBC | 🔴 |

| Amount | numeric | YES | The fee demand amount (what the student owes before concessions). | ✅ |

| BranchID | bigint | YES | TBC | 🔴 |

| BranchName | nvarchar | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ClassName | nvarchar | YES | Denormalized class name (e.g. 'Class 10'). Useful for GROUP BY without a JOIN. | ✅ |

| Company_ID | bigint | YES | TBC | 🔴 |

| Company_Name | nvarchar | YES | TBC | 🔴 |

| ConcessionCategoryName | nvarchar | YES | TBC | 🔴 |

| ConcessionCategory_ID | bigint | YES | TBC | 🔴 |

| Concession_Amt | numeric | YES | The concession/discount given. Use ISNULL(Concession_Amt, 0) in formulas. | ✅ |

| FeeApplicableDate | datetime | YES | TBC | 🔴 |

| FeeGroup_ID | bigint | YES | TBC | 🔴 |

| FeeGroup_Name | nvarchar | YES | TBC | 🔴 |

| FeesCategory_ID | bigint | YES | TBC | 🔴 |

| FeesCategory_Name | nvarchar | YES | TBC | 🔴 |

| FeesType_ID | bigint | YES | TBC | 🔴 |

| FeesType_Name | nvarchar | YES | TBC | 🔴 |

| Fees_ID | bigint | YES | TBC | 🔴 |

| Fees_Name | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsBusFee | bit | YES | 1 = bus fee row. Filter = 1 for bus-fee queries. | ✅ |

| IsDonation | bit | YES | 0 = regular fee; 1 = donation. Filter = 0 for academic-fee queries. | ✅ |

| IsHostelFee | bit | YES | 1 = hostel fee row. Filter = 1 for hostel-fee queries. | ✅ |

| IsIncludedInLumpSum | bit | YES | 0 = stand-alone fee; 1 = included in a lump-sum package. Filter = 0 to avoid double-counting. | ✅ |

| IsOptionalFee | bit | YES | TBC | 🔴 |

| LastDayToPay | int | YES | TBC | 🔴 |

| LastPaidDate | datetime | YES | TBC | 🔴 |

| Lien_Amount | numeric | YES | The amount held/locked. MUST be subtracted from the outstanding formula. | ✅ |

| Month_Name | nvarchar | YES | TBC | 🔴 |

| Month_No | bigint | YES | TBC | 🔴 |

| Paid_Amt | numeric | YES | The amount paid so far. This is a CACHED value (updated by SP_Update_OutstandingAmount). | ✅ |

| SectionID | bigint | YES | TBC | 🔴 |

| SectionName | nvarchar | YES | TBC | 🔴 |

| Structure_Type | nvarchar | YES | Fee type: 'Academic', 'Optional', 'Hostel', 'Bus', 'Misc', 'Others'. Filter IN ('Academic','Optional') for general fee queries. | ✅ |

| Student_ID | bigint | YES | TBC | 🔴 |

| Term_ID | bigint | YES | FK → TermMaster.ID (FEE terms, NOT ExamTermMaster.ID). | ✅ |

| Term_Name | nvarchar | YES | TBC | 🔴 |



**Foreign keys:**

- Term_ID → TermMaster.ID (CONFIRMED)
 — Fee terms — NOT ExamTermMaster


- Student_ID → Student_Master.ID (CONFIRMED)


- Fees_ID → Fees_Master.ID (CONFIRMED)




---


#### 🔴 Fees_Data_Import (58 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AcademicYearName | nvarchar | YES | TBC | 🔴 |

| Admission_No | nvarchar | YES | TBC | 🔴 |

| Bank | nvarchar | YES | TBC | 🔴 |

| Bill_Date | datetime | YES | TBC | 🔴 |

| Bill_No | nvarchar | YES | TBC | 🔴 |

| Bill_No_WO_Prefix | bigint | YES | TBC | 🔴 |

| Branch | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| BranchName | nvarchar | YES | TBC | 🔴 |

| Cancelled_By_ID | bigint | YES | TBC | 🔴 |

| Cancelled_By_Name | nvarchar | YES | TBC | 🔴 |

| ChequeClearanceDate | datetime | YES | TBC | 🔴 |

| ChequeStatus_ID | int | YES | TBC | 🔴 |

| ChequeStatus_Name | nvarchar | YES | TBC | 🔴 |

| Class_ID | bigint | YES | TBC | 🔴 |

| Class_Name | nvarchar | YES | TBC | 🔴 |

| Collected_By_ID | bigint | YES | TBC | 🔴 |

| Collected_By_Name | nvarchar | YES | TBC | 🔴 |

| CollectionType_ID | bigint | YES | TBC | 🔴 |

| CollectionType_Name | nvarchar | YES | TBC | 🔴 |

| Collection_Mode_ID | bigint | YES | TBC | 🔴 |

| Collection_Mode_Name | nvarchar | YES | TBC | 🔴 |

| Company_ID | bigint | YES | TBC | 🔴 |

| Company_Name | nvarchar | YES | TBC | 🔴 |

| Concession_Amount | numeric | YES | TBC | 🔴 |

| Concession_With_GST | nvarchar | YES | TBC | 🔴 |

| Enrollment_No | nvarchar | YES | TBC | 🔴 |

| FeesCategory_ID | bigint | YES | TBC | 🔴 |

| FeesCategory_Name | nvarchar | YES | TBC | 🔴 |

| FeesGroup_ID | bigint | YES | TBC | 🔴 |

| FeesGroup_Name | nvarchar | YES | TBC | 🔴 |

| FeesType_ID | bigint | YES | TBC | 🔴 |

| FeesType_Name | nvarchar | YES | TBC | 🔴 |

| Fees_Amount | numeric | YES | TBC | 🔴 |

| Fees_Head_ID | bigint | YES | TBC | 🔴 |

| Fees_Head_Name | nvarchar | YES | TBC | 🔴 |

| Fees_Month | nvarchar | YES | TBC | 🔴 |

| GSTAmount | nvarchar | YES | TBC | 🔴 |

| GSTPercentage | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsTallyPosted | bit | YES | TBC | 🔴 |

| ItemReference_Date | date | YES | TBC | 🔴 |

| ItemReference_No | nvarchar | YES | TBC | 🔴 |

| Misc_Receipt_Amt | numeric | YES | TBC | 🔴 |

| Narration | nvarchar | YES | TBC | 🔴 |

| Paid_Amt | numeric | YES | TBC | 🔴 |

| Reason_For_Cancellation | nvarchar | NO | TBC | 🔴 |

| Receipt_Amt | numeric | YES | TBC | 🔴 |

| Remaining_Amt | numeric | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| Section_ID | bigint | YES | TBC | 🔴 |

| Section_Name | nvarchar | YES | TBC | 🔴 |

| Structure_Type | nvarchar | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |

| Student_Name | nvarchar | YES | TBC | 🔴 |

| Term_ID | bigint | YES | TBC | 🔴 |

| Term_Name | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 Fees_Invoice_Generation (57 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearId | bigint | YES | TBC | 🔴 |

| AccountCode | nvarchar | YES | TBC | 🔴 |

| ClassId | bigint | YES | TBC | 🔴 |

| CompanyId | bigint | YES | TBC | 🔴 |

| ContactName | nvarchar | YES | TBC | 🔴 |

| Currency | nvarchar | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| Discount | numeric | YES | TBC | 🔴 |

| DueDate | date | YES | TBC | 🔴 |

| EmailAddress | nvarchar | YES | TBC | 🔴 |

| FeeGroupId | bigint | YES | TBC | 🔴 |

| FeeHeadId | bigint | YES | TBC | 🔴 |

| FeesCategoryId | bigint | YES | TBC | 🔴 |

| FeesTypeId | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| InventoryItemCode | nvarchar | YES | TBC | 🔴 |

| InvoiceAmountDue | numeric | YES | TBC | 🔴 |

| InvoiceAmountPaid | numeric | YES | TBC | 🔴 |

| InvoiceDate | date | YES | TBC | 🔴 |

| InvoiceNumber | nvarchar | YES | TBC | 🔴 |

| InvoiceNumberWoPrefix | bigint | YES | TBC | 🔴 |

| LineAmount | numeric | YES | TBC | 🔴 |

| MonthNo | bigint | YES | TBC | 🔴 |

| POAddressLine1 | nvarchar | YES | TBC | 🔴 |

| POAddressLine2 | nvarchar | YES | TBC | 🔴 |

| POAddressLine3 | nvarchar | YES | TBC | 🔴 |

| POAddressLine4 | nvarchar | YES | TBC | 🔴 |

| POCity | nvarchar | YES | TBC | 🔴 |

| POCountry | nvarchar | YES | TBC | 🔴 |

| POPostalCode | nvarchar | YES | TBC | 🔴 |

| PORegion | nvarchar | YES | TBC | 🔴 |

| PlannedDate | date | YES | TBC | 🔴 |

| Quantity | int | YES | TBC | 🔴 |

| Reference | nvarchar | YES | TBC | 🔴 |

| SAAddressLine1 | nvarchar | YES | TBC | 🔴 |

| SAAddressLine2 | nvarchar | YES | TBC | 🔴 |

| SAAddressLine3 | nvarchar | YES | TBC | 🔴 |

| SAAddressLine4 | nvarchar | YES | TBC | 🔴 |

| SACity | nvarchar | YES | TBC | 🔴 |

| SACountry | nvarchar | YES | TBC | 🔴 |

| SAPostalCode | nvarchar | YES | TBC | 🔴 |

| SARegion | nvarchar | YES | TBC | 🔴 |

| SectionId | bigint | YES | TBC | 🔴 |

| Sent | nvarchar | YES | TBC | 🔴 |

| Status | nvarchar | YES | TBC | 🔴 |

| StudentId | bigint | YES | TBC | 🔴 |

| TaxAmount | numeric | YES | TBC | 🔴 |

| TaxTotal | numeric | YES | TBC | 🔴 |

| TaxType | nvarchar | YES | TBC | 🔴 |

| TermId | bigint | YES | TBC | 🔴 |

| Total | numeric | YES | TBC | 🔴 |

| TrackingName1 | nvarchar | YES | TBC | 🔴 |

| TrackingName2 | nvarchar | YES | TBC | 🔴 |

| TrackingOption1 | nvarchar | YES | TBC | 🔴 |

| TrackingOption2 | nvarchar | YES | TBC | 🔴 |

| Type | nvarchar | YES | TBC | 🔴 |

| UnitAmount | numeric | YES | TBC | 🔴 |



---


#### 🔴 Fees_Master (40 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AcademicYearName | nvarchar | YES | TBC | 🔴 |

| ApplicableFor | bigint | YES | TBC | 🔴 |

| ApplicableGenderID | bigint | YES | TBC | 🔴 |

| ApplicableGenderName | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| BranchName | nvarchar | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Company_ID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| DisplayOrder | bigint | YES | TBC | 🔴 |

| FeesCategory_ID | bigint | YES | TBC | 🔴 |

| FeesCategory_Name | nvarchar | YES | TBC | 🔴 |

| FeesGroup_ID | bigint | YES | TBC | 🔴 |

| FeesType_ID | bigint | YES | TBC | 🔴 |

| FeesType_Name | nvarchar | YES | TBC | 🔴 |

| GSTPer | numeric | YES | TBC | 🔴 |

| GSTTypeID | bigint | YES | TBC | 🔴 |

| GSTTypeName | nvarchar | YES | TBC | 🔴 |

| GSTValue | numeric | YES | TBC | 🔴 |

| HSNCode | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IgnoreForGroupSameStudent | nvarchar | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IsDonationFee | bit | YES | TBC | 🔴 |

| IsGSTApplicable | bit | YES | TBC | 🔴 |

| IsIncludeinEMI | bit | YES | TBC | 🔴 |

| IsIncludeinLateFee | bit | YES | TBC | 🔴 |

| IsShowOnline | bit | YES | TBC | 🔴 |

| IsVaryForGender | nvarchar | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| ProspectusAmount | numeric | YES | TBC | 🔴 |

| TallyName | nvarchar | YES | TBC | 🔴 |

| TypeID | bit | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 Fees_Master_ClassDetails (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearId | bigint | YES | TBC | 🔴 |

| ClassId | bigint | YES | TBC | 🔴 |

| FeesId | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsActive | bit | YES | TBC | 🔴 |

| ProspectusAmount | numeric | YES | TBC | 🔴 |



---


#### 🔴 GoodsReceiptInfo (24 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| DeliveryNote | nvarchar | YES | TBC | 🔴 |

| DeliveryStatus | bigint | YES | TBC | 🔴 |

| Discount | bigint | YES | TBC | 🔴 |

| DueDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| InvoiceDate | datetime | YES | TBC | 🔴 |

| InvoiceNO | nvarchar | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| NetAmount | bigint | YES | TBC | 🔴 |

| PurchaseRequestID | bigint | YES | TBC | 🔴 |

| ReceiptDate | datetime | YES | TBC | 🔴 |

| ReferenceNo | nvarchar | YES | TBC | 🔴 |

| SupplierAddress | nvarchar | YES | TBC | 🔴 |

| SupplierID | bigint | YES | TBC | 🔴 |

| Tax | bigint | YES | TBC | 🔴 |

| TotalAmountGRN | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 Goods_Receipt_Details (16 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Goods_Receipt_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| ItemCode | nvarchar | YES | TBC | 🔴 |

| ItemID | bigint | YES | TBC | 🔴 |

| ItemName | nvarchar | YES | TBC | 🔴 |

| ItemRate | numeric | YES | TBC | 🔴 |

| ItemTotal | numeric | YES | TBC | 🔴 |

| MRNID | bigint | YES | TBC | 🔴 |

| Orderedquantity | bigint | YES | TBC | 🔴 |

| Price | decimal | YES | TBC | 🔴 |

| Quantity | bigint | YES | TBC | 🔴 |

| ReceivedQuantity | bigint | YES | TBC | 🔴 |

| UOMName | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 HostelFeeStructure (23 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AcademicYearName | nvarchar | YES | TBC | 🔴 |

| Amount | numeric | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| BranchName | nvarchar | YES | TBC | 🔴 |

| Class_ID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| FeeApplicableDate | date | YES | TBC | 🔴 |

| Fees_ID | bigint | YES | TBC | 🔴 |

| Hostel_ID | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Month_Name | nvarchar | YES | TBC | 🔴 |

| Month_No | bigint | YES | TBC | 🔴 |

| Room_ID | bigint | YES | TBC | 🔴 |

| Section_ID | bigint | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |

| Term_ID | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



**Foreign keys:**

- Term_ID → TermMaster.ID (CONFIRMED)
 — Fee terms




---


#### 🔴 ItemFeesAssignment (14 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| FeesID | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 ItemFeesDetails (10 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsChecked | bit | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| ItemAssignmentID | bigint | YES | TBC | 🔴 |

| ItemID | bigint | YES | TBC | 🔴 |

| ItemName | nvarchar | YES | TBC | 🔴 |

| ItemQuantity | bigint | YES | TBC | 🔴 |

| UOMName | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 LateFeeDetails (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Amount | numeric | YES | TBC | 🔴 |

| ClassId | bigint | YES | TBC | 🔴 |

| FeeID | bigint | YES | TBC | 🔴 |

| FeeName | nvarchar | YES | TBC | 🔴 |

| FromDate | date | YES | TBC | 🔴 |

| FromDay | int | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| LastDay | int | YES | TBC | 🔴 |

| LateFeeID | bigint | YES | TBC | 🔴 |

| ToDate | date | YES | TBC | 🔴 |

| ToDay | int | YES | TBC | 🔴 |



---


#### 🔴 LateFeeMaster (25 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AcademicYearName | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| BranchName | nvarchar | YES | TBC | 🔴 |

| CanBeEdited | bit | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Company_ID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| GSTPer | decimal | YES | TBC | 🔴 |

| GSTTypeID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsActive | bit | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IsGSTApplicable | bit | YES | TBC | 🔴 |

| LastDate | date | YES | TBC | 🔴 |

| LateFeeHeadId | bigint | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| TermId | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |

| ValidityDate | date | YES | TBC | 🔴 |



---


#### 🔴 LateFee_Concession (15 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | NO | TBC | 🔴 |

| BranchID | bigint | NO | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| Concession_Amount | decimal | NO | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| LateFeeHeadId | bigint | NO | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| Student_ID | bigint | NO | TBC | 🔴 |

| Term_ID | bigint | NO | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 LumpSum_Amount_Configuration (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| Lumpsum_Amount | bigint | YES | TBC | 🔴 |

| Title | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 LumpSum_Classes (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_Id | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| LumpSum_Id | bigint | YES | TBC | 🔴 |



---


#### 🔴 LumpSum_Fees (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| FeesHead_Id | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| LumpSum_Id | bigint | YES | TBC | 🔴 |



---


#### 🔴 LumpsumFees_StudentDetails (15 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| FeeId | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| LumpsumConfig_Amount | numeric | YES | TBC | 🔴 |

| LumpsumConfig_ID | bigint | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 OptionalFeeMapping_Student (14 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_ID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| FeeStructureDetails_ID | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Section_ID | bigint | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 OptionalFeeMapping_StudentMonths (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Amount | numeric | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_ID | bigint | YES | TBC | 🔴 |

| Fees_ID | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| Month_Name | nvarchar | YES | TBC | 🔴 |

| Month_No | bigint | YES | TBC | 🔴 |

| OptionalFeeMapping_Id | bigint | YES | TBC | 🔴 |

| Section_ID | bigint | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |

| Term_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 ProspectusFeesCollection (34 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| ApplicationNo | nvarchar | YES | TBC | 🔴 |

| Bank | nvarchar | YES | TBC | 🔴 |

| Bill_Date | datetime | YES | TBC | 🔴 |

| Bill_No | nvarchar | YES | TBC | 🔴 |

| Bill_No_WO_Prefix | bigint | YES | TBC | 🔴 |

| Branch | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Cancellation_Date | date | YES | TBC | 🔴 |

| Cancelled_By_ID | bigint | YES | TBC | 🔴 |

| Cancelled_By_Name | nvarchar | YES | TBC | 🔴 |

| ChequeClearanceDate | datetime | YES | TBC | 🔴 |

| ChequeStatus_ID | int | YES | TBC | 🔴 |

| ChequeStatus_Name | nvarchar | YES | TBC | 🔴 |

| Class_ID | bigint | YES | TBC | 🔴 |

| Collected_By_ID | bigint | YES | TBC | 🔴 |

| Collected_By_Name | nvarchar | YES | TBC | 🔴 |

| Collection_Mode_ID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| EnquiryNo | nvarchar | YES | TBC | 🔴 |

| FatherContactNo | nvarchar | YES | TBC | 🔴 |

| FatherName | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| ItemReference_Date | date | YES | TBC | 🔴 |

| ItemReference_No | nvarchar | YES | TBC | 🔴 |

| Mobile | nvarchar | YES | TBC | 🔴 |

| Narration | nvarchar | YES | TBC | 🔴 |

| Reason_For_Cancellation | nvarchar | YES | TBC | 🔴 |

| Receipt_Amt | numeric | YES | TBC | 🔴 |

| Student_Name | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 ProspectusFeesCollectionDetails (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Company_ID | bigint | YES | TBC | 🔴 |

| Fees_Amount | numeric | YES | TBC | 🔴 |

| Fees_Head_ID | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| ProspectusFees_Collection_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 ReceiptEmailSendingStatus (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYear | nvarchar | YES | TBC | 🔴 |

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdmissionNo | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| FeeCollectionID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| MailSentStatus | bigint | YES | TBC | 🔴 |

| SentMailID | nvarchar | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |



---


#### 🔴 ReceiptSettings (18 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CompanyID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| DeliveryTrackingURL | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| ISDeliveryTracking | bit | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| PrintType | nvarchar | YES | TBC | 🔴 |

| ReportAddress | nvarchar | YES | TBC | 🔴 |

| ReportLogo | nvarchar | YES | TBC | 🔴 |

| ReportTitle | nvarchar | YES | TBC | 🔴 |

| TypeOfReceipt | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 RefundEntry (23 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| CreditNoteAmount | numeric | YES | TBC | 🔴 |

| CreditNoteDate | datetime | YES | TBC | 🔴 |

| CreditNoteID | bigint | YES | TBC | 🔴 |

| CreditNoteNo | varchar | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Narration | varchar | YES | TBC | 🔴 |

| PaidBillNos | varchar | YES | TBC | 🔴 |

| RefundAmount | numeric | YES | TBC | 🔴 |

| RefundEntryDate | datetime | YES | TBC | 🔴 |

| Remarks | varchar | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| StudentName | varchar | YES | TBC | 🔴 |

| Type | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |

| VoucherNo | varchar | YES | TBC | 🔴 |



---


#### 🔴 RefundReceipt (19 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| ApprovalRemarks | nvarchar | YES | TBC | 🔴 |

| ApprovalStatus | bigint | YES | TBC | 🔴 |

| Bill_Date | datetime | YES | TBC | 🔴 |

| Bill_No | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_ID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| FeesCollection_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Receipt_Amt | numeric | YES | TBC | 🔴 |

| Refund_Amt | numeric | YES | TBC | 🔴 |

| Refund_No | nvarchar | YES | TBC | 🔴 |

| RequestRemarks | nvarchar | YES | TBC | 🔴 |

| Section_ID | bigint | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 RefundReceipt_Detail (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Fees_Head_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Paid_Amt | numeric | YES | TBC | 🔴 |

| Refund_Amt | numeric | YES | TBC | 🔴 |

| Refund_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 RefundRequest (18 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| ApprovalRemarks | nvarchar | YES | TBC | 🔴 |

| ApprovalStatus | bigint | YES | TBC | 🔴 |

| Bill_Date | datetime | YES | TBC | 🔴 |

| Bill_No | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_ID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| FeesCollection_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Receipt_Amt | numeric | YES | TBC | 🔴 |

| Refund_Amt | numeric | YES | TBC | 🔴 |

| RequestRemarks | nvarchar | YES | TBC | 🔴 |

| Section_ID | bigint | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 RefundRequest_Detail (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Fees_Head_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Paid_Amt | numeric | YES | TBC | 🔴 |

| Refund_Amt | numeric | YES | TBC | 🔴 |

| Refund_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 SL_Concession_Master (19 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdmissionType_ID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ConcessionCategory_ID | bigint | YES | TBC | 🔴 |

| Concession_Amount | numeric | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| FeeStructureMonthDetails_ID | bigint | YES | TBC | 🔴 |

| Fees_ID | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| MonthNo | int | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| Structure_Type | nvarchar | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 SL_FeesInformationStudentDetail (39 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AcademicYearName | nvarchar | YES | TBC | 🔴 |

| Amount | numeric | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| BranchName | nvarchar | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ClassName | nvarchar | YES | TBC | 🔴 |

| Company_ID | bigint | YES | TBC | 🔴 |

| Company_Name | nvarchar | YES | TBC | 🔴 |

| ConcessionCategoryName | nvarchar | YES | TBC | 🔴 |

| ConcessionCategory_ID | bigint | YES | TBC | 🔴 |

| Concession_Amt | numeric | YES | TBC | 🔴 |

| FeeApplicableDate | datetime | YES | TBC | 🔴 |

| FeeGroup_ID | bigint | YES | TBC | 🔴 |

| FeeGroup_Name | nvarchar | YES | TBC | 🔴 |

| FeesCategory_ID | bigint | YES | TBC | 🔴 |

| FeesCategory_Name | nvarchar | YES | TBC | 🔴 |

| FeesType_ID | bigint | YES | TBC | 🔴 |

| FeesType_Name | nvarchar | YES | TBC | 🔴 |

| Fees_ID | bigint | YES | TBC | 🔴 |

| Fees_Name | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsBusFee | bit | YES | TBC | 🔴 |

| IsDonation | bit | YES | TBC | 🔴 |

| IsHostelFee | bit | YES | TBC | 🔴 |

| IsIncludedInLumpSum | bit | YES | TBC | 🔴 |

| IsOptionalFee | bit | YES | TBC | 🔴 |

| LastDayToPay | int | YES | TBC | 🔴 |

| LastPaidDate | datetime | YES | TBC | 🔴 |

| Lien_Amount | numeric | YES | TBC | 🔴 |

| Month_Name | nvarchar | YES | TBC | 🔴 |

| Month_No | bigint | YES | TBC | 🔴 |

| Paid_Amt | numeric | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| SectionName | nvarchar | YES | TBC | 🔴 |

| Structure_Type | nvarchar | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |

| Term_ID | bigint | YES | TBC | 🔴 |

| Term_Name | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 StudentFeeCategory (7 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 StudentFeeCategoryDetails (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| SFCID | bigint | YES | TBC | 🔴 |

| SFCName | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 StudentFeeCertificate (31 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdmissionNo | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ClassName | nvarchar | YES | TBC | 🔴 |

| FatherName | nvarchar | YES | TBC | 🔴 |

| FeeHead_ID | bigint | YES | TBC | 🔴 |

| FeeHead_Name | nvarchar | YES | TBC | 🔴 |

| GuardianName | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IssuedBy | nvarchar | YES | TBC | 🔴 |

| IssuedDate | date | YES | TBC | 🔴 |

| MotherName | nvarchar | YES | TBC | 🔴 |

| Paid_Amount | numeric | YES | TBC | 🔴 |

| Purpose | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| SchoolAcademicYear | nvarchar | YES | TBC | 🔴 |

| SchoolAddress1 | nvarchar | YES | TBC | 🔴 |

| SchoolAddress2 | nvarchar | YES | TBC | 🔴 |

| SchoolLogo | nvarchar | YES | TBC | 🔴 |

| SchoolMobileNo | nvarchar | YES | TBC | 🔴 |

| SchoolName | nvarchar | YES | TBC | 🔴 |

| SchoolPhone1 | nvarchar | YES | TBC | 🔴 |

| SchoolPhone2 | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| SectionName | nvarchar | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| StudentName | nvarchar | YES | TBC | 🔴 |

| TermIDs | nvarchar | YES | TBC | 🔴 |

| TermName | nvarchar | YES | TBC | 🔴 |



---


### Exams (46 tables)


#### 🔴 CoScholasticTypeOneExamDetails (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | NO | TBC | 🔴 |

| CreatedOn | datetime | NO | TBC | 🔴 |

| Deleted | bit | NO | TBC | 🔴 |

| EvalRefID | bigint | NO | TBC | 🔴 |

| ExamTypeID | bigint | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsActive | bit | NO | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedOn | datetime | YES | TBC | 🔴 |



---


#### 🔴 ConsolidatedExamConfigurationExamTypeDetails (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| ConsolidatedExamHeaderID | bigint | YES | TBC | 🔴 |

| ConversionScores | decimal | YES | TBC | 🔴 |

| CumlationLogicID | bigint | YES | TBC | 🔴 |

| CumlationLogicName | varchar | YES | TBC | 🔴 |

| DisplayOrderNo | bigint | YES | TBC | 🔴 |

| ExamTypeID | bigint | YES | TBC | 🔴 |

| ExamTypeName | varchar | YES | TBC | 🔴 |

| GradeID | bigint | YES | TBC | 🔴 |

| GradeName | varchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| MaxMark | decimal | YES | TBC | 🔴 |

| MinMark | decimal | YES | TBC | 🔴 |

| ParentID | bigint | YES | TBC | 🔴 |



---


#### 🔴 ConsolidatedExamConfigurationHeader (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| Description | varchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | NO | TBC | 🔴 |

| Title | varchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 ExamConfigurationExamTypeDetails (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| ExamHeaderID | bigint | YES | TBC | 🔴 |

| ExamTermID | bigint | YES | TBC | 🔴 |

| ExamTermName | varchar | YES | TBC | 🔴 |

| ExamTypeID | bigint | YES | TBC | 🔴 |

| ExamTypeName | varchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |



---


#### 🔴 ExamConfigurationHeader (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| Description | varchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | NO | TBC | 🔴 |

| Title | varchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 ExamMarksEntryunfreezeRequest (23 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| ApprovalStatus | int | YES | TBC | 🔴 |

| ApprovedBy_ID | bigint | YES | TBC | 🔴 |

| ApprovedBy_Name | nvarchar | YES | TBC | 🔴 |

| Approver_Reason | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| ExamTypeID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IDS | nvarchar | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| RequestedBy_ID | bigint | YES | TBC | 🔴 |

| RequestedBy_Name | nvarchar | YES | TBC | 🔴 |

| Requester_Reason | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| SubjectEvaluationName | nvarchar | YES | TBC | 🔴 |

| SubjectID | bigint | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 ExamProgressCardModel (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ExamTypeID | bigint | YES | TBC | 🔴 |

| ID | int | NO | TBC | 🔴 |

| ProgressCardID | bigint | YES | TBC | 🔴 |



---


#### ✅ ExamTermMaster (12 columns) — [CONFIRMED]


**Purpose:** Stores exam terms (Term I, Term II, etc.) — distinct from fee terms. Uses 'Deleted' (not 'IsDeleted') for soft-delete. Date columns are StartDate/EndDate (datetime, not StartingDate/EndingDate).


**⚠️ Gotcha:** Soft-delete column is 'Deleted' (NOT 'IsDeleted'). Date columns are 'StartDate/EndDate' (datetime, NOT 'StartingDate/EndingDate'). Has a typo: 'CreaedOn' instead of 'CreatedOn'.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| CreaedOn | datetime | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| Deleted | bit | YES | The soft-delete column (NOT IsDeleted — non-standard). | ✅ |

| EndDate | datetime | YES | The exam term's end date (type: datetime — NOT EndingDate). | ✅ |

| ID | bigint | NO | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| StartDate | datetime | YES | The exam term's start date (type: datetime — NOT StartingDate). | ✅ |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedOn | datetime | YES | TBC | 🔴 |



---


#### 🔴 ExamTypeGraphDetails (3 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| ClassId | bigint | YES | TBC | 🔴 |

| ExamTypeId | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |



---


#### ✅ ExamTypeMaster (15 columns) — [CONFIRMED]


**Purpose:** Exam types. Has TermID → ExamTermMaster.ID (exam terms, NOT TermMaster).


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AssesmentTypeID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| ColorRequired | nvarchar | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ExamPositionID | bigint | YES | TBC | 🔴 |

| ExamTypeWiseID | bigint | YES | TBC | 🔴 |

| HaveProgressCard | bit | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IsHPCApplicable | bit | YES | TBC | 🔴 |

| IsSummativeAssement | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| TermID | bigint | YES | FK → ExamTermMaster.ID (EXAM terms, NOT TermMaster). The exam-type-to-exam-term link. | ✅ |



**Foreign keys:**

- TermID → ExamTermMaster.ID (CONFIRMED)
 — EXAM terms — NOT TermMaster




---


#### 🔴 ExamTypeOrderConfig (9 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| DisplayOrder | bigint | YES | TBC | 🔴 |

| ExamTermID | bigint | YES | TBC | 🔴 |

| ExamTermName | nvarchar | YES | TBC | 🔴 |

| ExamTypeID | bigint | YES | TBC | 🔴 |

| ExamTypeName | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |



---


#### 🔴 ExaminationPlanningDetails (15 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | NO | TBC | 🔴 |

| CreatedOn | datetime | NO | TBC | 🔴 |

| Deleted | bit | NO | TBC | 🔴 |

| EndTime | nvarchar | YES | TBC | 🔴 |

| ExamDate | datetime | YES | TBC | 🔴 |

| ExamTypeID | bigint | NO | TBC | 🔴 |

| HeaderID | bigint | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| StartTime | nvarchar | YES | TBC | 🔴 |

| SubjectID | bigint | NO | TBC | 🔴 |

| Syllabus | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedOn | datetime | YES | TBC | 🔴 |



---


#### 🔴 ExaminationPlanningMaster (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | NO | TBC | 🔴 |

| CreatedBy | bigint | NO | TBC | 🔴 |

| CreatedOn | datetime | NO | TBC | 🔴 |

| Deleted | bit | NO | TBC | 🔴 |

| EndDate | datetime | NO | TBC | 🔴 |

| ExamTypeID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| SectionID | bigint | NO | TBC | 🔴 |

| StartDate | datetime | NO | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedOn | datetime | YES | TBC | 🔴 |



---


#### 🔴 ExaminationUserRequestLog (10 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | date | YES | TBC | 🔴 |

| Details | text | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Operation | nvarchar | YES | TBC | 🔴 |

| ScreenName | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | date | YES | TBC | 🔴 |



---


#### 🔴 GradeMaster (7 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 Grade_Details (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| GID | bigint | YES | TBC | 🔴 |

| Grade | nvarchar | YES | TBC | 🔴 |

| GradeAlias | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsMin | nvarchar | YES | TBC | 🔴 |

| MaxGP | numeric | YES | TBC | 🔴 |

| MaxMark | numeric | YES | TBC | 🔴 |

| MinGP | numeric | YES | TBC | 🔴 |

| MinMark | numeric | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 HallTicketGeneralDetails (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| ConfigID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Evaluation | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Marks | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |

| instrunctionTypeID | bigint | YES | TBC | 🔴 |



---


#### 🔴 HallTicketGeneration (17 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearId | bigint | YES | TBC | 🔴 |

| BranchId | bigint | YES | TBC | 🔴 |

| ClassId | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| ExamTypeId | bigint | YES | TBC | 🔴 |

| FormatId | int | YES | TBC | 🔴 |

| HT_Data | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| InstructionType | nvarchar | YES | TBC | 🔴 |

| InstructionTypeID | bigint | YES | TBC | 🔴 |

| IsSubjectWiseTeacherSignNeeded | bit | YES | TBC | 🔴 |

| NoOfInstructions | bigint | YES | TBC | 🔴 |

| SectionIds | nvarchar | YES | TBC | 🔴 |

| TypeId | int | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 HallTicketGenerationExamDetails (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| ConfigId | bigint | YES | TBC | 🔴 |

| ExamDate | date | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| StaffId | bigint | YES | TBC | 🔴 |

| SubjectId | bigint | YES | TBC | 🔴 |



---


#### 🔴 InterviewMarkDetails (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| ApplicantId | bigint | YES | TBC | 🔴 |

| HeaderId | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| Marks | numeric | YES | TBC | 🔴 |

| SubjectId | bigint | YES | TBC | 🔴 |

| SubjectName | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 InterviewMarkHeader (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearId | bigint | YES | TBC | 🔴 |

| BranchId | bigint | YES | TBC | 🔴 |

| ClassId | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| EvaluationDate | date | YES | TBC | 🔴 |

| EvaluationName | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 MarkRangeFilterMaster (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| DisplayName | nvarchar | YES | TBC | 🔴 |

| EndValue | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| ScreenId | bigint | YES | TBC | 🔴 |

| ScreenName | nvarchar | YES | TBC | 🔴 |

| StartValue | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 OtherExamConfiguration (14 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | date | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | date | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ExamName | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Status | nvarchar | YES | TBC | 🔴 |

| StatusID | bigint | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | date | YES | TBC | 🔴 |



---


#### 🔴 OtherExamConfigurationHeader (15 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Category | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| Description | varchar | YES | TBC | 🔴 |

| FromDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | NO | TBC | 🔴 |

| Title | varchar | YES | TBC | 🔴 |

| ToDate | datetime | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 OtherExamMarkDetails (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| ClassName | varchar | YES | TBC | 🔴 |

| EnrollmentNo | nvarchar | YES | TBC | 🔴 |

| HeaderID | bigint | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Mark | nvarchar | YES | TBC | 🔴 |

| Message | nvarchar | YES | TBC | 🔴 |

| MobileNo | nvarchar | YES | TBC | 🔴 |

| Rank | nvarchar | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| StundentName | varchar | YES | TBC | 🔴 |

| SubjectID | bigint | NO | TBC | 🔴 |

| SubjectMaxMark | nvarchar | YES | TBC | 🔴 |

| SubjectMinMark | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 OtherExamMarkMaster (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | NO | TBC | 🔴 |

| CreatedOn | datetime | NO | TBC | 🔴 |

| ExamDate | datetime | NO | TBC | 🔴 |

| ExamDescription | varchar | YES | TBC | 🔴 |

| ExamSettingID | bigint | YES | TBC | 🔴 |

| ExamTypeID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | NO | TBC | 🔴 |

| StudentType | int | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedOn | datetime | YES | TBC | 🔴 |



---


#### 🔴 OtherExamSubjectDetails (4 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| ColumnIndex | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| OtherExam_ID | bigint | YES | TBC | 🔴 |

| SubjectName | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 OtherExam_Master (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | date | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 OtherExam_ProgressCardDataRetrieval (61 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdmissionNo | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ChildOrderNo | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ColorRequired | bigint | YES | TBC | 🔴 |

| ColumnIndex | numeric | YES | TBC | 🔴 |

| ComMarks | numeric | YES | TBC | 🔴 |

| ConversionScore | numeric | YES | TBC | 🔴 |

| ConvertedMarks | numeric | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| EvaluationTypeID | bigint | YES | TBC | 🔴 |

| ExamTypeID | bigint | YES | TBC | 🔴 |

| ExamTypeName | nvarchar | YES | TBC | 🔴 |

| Grade | nvarchar | YES | TBC | 🔴 |

| GradeID | bigint | YES | TBC | 🔴 |

| GradeMarks | nvarchar | YES | TBC | 🔴 |

| GradePoint | numeric | YES | TBC | 🔴 |

| GradeVisibility | bit | NO | TBC | 🔴 |

| GradingConvertionMarks | numeric | YES | TBC | 🔴 |

| GradingMarks | numeric | YES | TBC | 🔴 |

| Height | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IDs | nvarchar | YES | TBC | 🔴 |

| IsDeleted | bit | NO | TBC | 🔴 |

| MarkVisibility | bit | NO | TBC | 🔴 |

| Marks | numeric | YES | TBC | 🔴 |

| MaxGP | numeric | YES | TBC | 🔴 |

| MaxGradeMarks | nvarchar | YES | TBC | 🔴 |

| MaxMarks | numeric | YES | TBC | 🔴 |

| NonGrade | nvarchar | YES | TBC | 🔴 |

| OrderNo | bigint | YES | TBC | 🔴 |

| Others | nvarchar | YES | TBC | 🔴 |

| OverAllGrade | nvarchar | YES | TBC | 🔴 |

| OverAllRank | bigint | YES | TBC | 🔴 |

| ParentName | nvarchar | YES | TBC | 🔴 |

| ParentSubjectID | bigint | YES | TBC | 🔴 |

| ParentSubjectName | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| StudentName | nvarchar | YES | TBC | 🔴 |

| SubjectCode | nvarchar | YES | TBC | 🔴 |

| SubjectID | bigint | YES | TBC | 🔴 |

| SubjectName | nvarchar | YES | TBC | 🔴 |

| SubjectTypeID | bigint | YES | TBC | 🔴 |

| SubjectTypeName | nvarchar | YES | TBC | 🔴 |

| TermID | bigint | YES | TBC | 🔴 |

| TermMarks | numeric | YES | TBC | 🔴 |

| TermName | nvarchar | YES | TBC | 🔴 |

| TotalCount | bigint | YES | TBC | 🔴 |

| TotalPerMax | numeric | YES | TBC | 🔴 |

| TotalSubMarks | numeric | YES | TBC | 🔴 |

| TreeNode | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |

| Weight | nvarchar | YES | TBC | 🔴 |

| totalMarks | numeric | YES | TBC | 🔴 |

| totalMaxMarks | numeric | YES | TBC | 🔴 |

| totalMaxgp | numeric | YES | TBC | 🔴 |



---


#### 🔴 PortalProgressCardConfiguration (33 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Attendance | bit | YES | TBC | 🔴 |

| Average | bit | YES | TBC | 🔴 |

| BlackAndWhite | bit | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ClassRank | bit | YES | TBC | 🔴 |

| CombineExamTypeID | bigint | YES | TBC | 🔴 |

| ConvertedMarks | bit | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| ExamTypeID | bigint | YES | TBC | 🔴 |

| Grade | bit | YES | TBC | 🔴 |

| GraphValues | bit | YES | TBC | 🔴 |

| ID | int | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IsGraphNeeded | bit | YES | TBC | 🔴 |

| Marks | bit | YES | TBC | 🔴 |

| OverallGrade | bit | YES | TBC | 🔴 |

| Promotion | bit | YES | TBC | 🔴 |

| PublishStatus | bit | YES | TBC | 🔴 |

| Remarks | bit | YES | TBC | 🔴 |

| ReportModelID | bigint | YES | TBC | 🔴 |

| ReportType | nvarchar | YES | TBC | 🔴 |

| ReportTypeID | bigint | YES | TBC | 🔴 |

| SectionRank | bit | YES | TBC | 🔴 |

| TermID | bigint | YES | TBC | 🔴 |

| Title | nvarchar | YES | TBC | 🔴 |

| Total | bit | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 PreviousSchoolMarks (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Applicant_ID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassName | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| MarksObtained | numeric | YES | TBC | 🔴 |

| MaxMarks | numeric | YES | TBC | 🔴 |

| SchoolName | nvarchar | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| SubjectName | nvarchar | YES | TBC | 🔴 |

| TotalMarks | numeric | YES | TBC | 🔴 |

| YearOfExam | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 ProgressCardConfigDetails (15 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| CumLogic | nvarchar | YES | TBC | 🔴 |

| EvaluationOrder | bigint | YES | TBC | 🔴 |

| GradeType | nvarchar | YES | TBC | 🔴 |

| GradeTypeID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| PGCardConfigID | bigint | YES | TBC | 🔴 |

| SubjectID | bigint | YES | TBC | 🔴 |

| SubjectName | nvarchar | YES | TBC | 🔴 |

| SubjectOrder | bigint | YES | TBC | 🔴 |

| SubjectTypeID | bigint | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 ProgressCardDataRetrieval (68 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdmissionNo | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ChildOrderNo | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ColorRequired | bigint | YES | TBC | 🔴 |

| ColumnIndex | numeric | YES | TBC | 🔴 |

| ComMarks | numeric | YES | TBC | 🔴 |

| ConversionScore | numeric | YES | TBC | 🔴 |

| ConvertedMarks | numeric | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| EvaluationTypeID | bigint | YES | TBC | 🔴 |

| ExamGrade | nvarchar | YES | TBC | 🔴 |

| ExamTotal | numeric | YES | TBC | 🔴 |

| ExamTypeID | bigint | YES | TBC | 🔴 |

| ExamTypeName | nvarchar | YES | TBC | 🔴 |

| Grade | nvarchar | YES | TBC | 🔴 |

| GradeID | bigint | YES | TBC | 🔴 |

| GradeMarks | nvarchar | YES | TBC | 🔴 |

| GradePoint | numeric | YES | TBC | 🔴 |

| GradeVisibility | bit | NO | TBC | 🔴 |

| GradingConvertionMarks | numeric | YES | TBC | 🔴 |

| GradingMarks | numeric | YES | TBC | 🔴 |

| Height | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IDs | nvarchar | YES | TBC | 🔴 |

| IsDeleted | bit | NO | TBC | 🔴 |

| MarkVisibility | bit | NO | TBC | 🔴 |

| Marks | numeric | YES | TBC | 🔴 |

| MaxGP | numeric | YES | TBC | 🔴 |

| MaxGradeMarks | nvarchar | YES | TBC | 🔴 |

| MaxMarks | numeric | YES | TBC | 🔴 |

| MinMark | numeric | YES | TBC | 🔴 |

| NonGrade | nvarchar | YES | TBC | 🔴 |

| OrderNo | bigint | YES | TBC | 🔴 |

| Others | nvarchar | YES | TBC | 🔴 |

| OverAllGrade | nvarchar | YES | TBC | 🔴 |

| OverAllRank | bigint | YES | TBC | 🔴 |

| ParentName | nvarchar | YES | TBC | 🔴 |

| ParentSubjectID | bigint | YES | TBC | 🔴 |

| ParentSubjectName | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| StudentName | nvarchar | YES | TBC | 🔴 |

| SubjectCode | nvarchar | YES | TBC | 🔴 |

| SubjectID | bigint | YES | TBC | 🔴 |

| SubjectName | nvarchar | YES | TBC | 🔴 |

| SubjectTypeID | bigint | YES | TBC | 🔴 |

| SubjectTypeName | nvarchar | YES | TBC | 🔴 |

| TermAllGrade | nvarchar | YES | TBC | 🔴 |

| TermAllTotal | numeric | YES | TBC | 🔴 |

| TermGrade | nvarchar | YES | TBC | 🔴 |

| TermID | bigint | YES | TBC | 🔴 |

| TermMarks | numeric | YES | TBC | 🔴 |

| TermName | nvarchar | YES | TBC | 🔴 |

| TermTotal | numeric | YES | TBC | 🔴 |

| TotalCount | bigint | YES | TBC | 🔴 |

| TotalPerMax | numeric | YES | TBC | 🔴 |

| TotalSubMarks | numeric | YES | TBC | 🔴 |

| TreeNode | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |

| Weight | nvarchar | YES | TBC | 🔴 |

| totalMarks | numeric | YES | TBC | 🔴 |

| totalMaxMarks | numeric | YES | TBC | 🔴 |

| totalMaxgp | numeric | YES | TBC | 🔴 |



---


#### 🔴 ProgressCardModelMaster (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Deleted | bit | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Name | nvarchar | NO | TBC | 🔴 |



---


#### 🔴 ProgressCardModelSchoolMappingDetails (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Deleted | bit | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| ModelID | bigint | NO | TBC | 🔴 |



---


#### 🔴 ProgressCardModelTypeMappingDetails (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Deleted | bit | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| ModelID | bigint | NO | TBC | 🔴 |

| TypeID | bigint | NO | TBC | 🔴 |



---


#### 🔴 ProgressCardSettingDetails (18 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | NO | TBC | 🔴 |

| CreatedOn | datetime | NO | TBC | 🔴 |

| CumLogicID | bigint | NO | TBC | 🔴 |

| Deleted | bit | NO | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| FormatTypeID | bigint | YES | TBC | 🔴 |

| GradeType | nvarchar | NO | TBC | 🔴 |

| GradeTypeID | bigint | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| MasterID | bigint | NO | TBC | 🔴 |

| OrderNo | bigint | YES | TBC | 🔴 |

| SubjectID | bigint | NO | TBC | 🔴 |

| SubjectName | nvarchar | NO | TBC | 🔴 |

| SubjectTypeID | bigint | NO | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedOn | datetime | YES | TBC | 🔴 |



---


#### 🔴 ProgressCardSettingExamDetails (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | NO | TBC | 🔴 |

| CreatedOn | datetime | NO | TBC | 🔴 |

| Deleted | bit | NO | TBC | 🔴 |

| EvalHierRefID | bigint | NO | TBC | 🔴 |

| ExamTypeID | bigint | NO | TBC | 🔴 |

| HeaderID | bigint | NO | TBC | 🔴 |

| HierarchyLevel | bigint | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| MasterRefID | bigint | NO | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedOn | datetime | YES | TBC | 🔴 |



---


#### 🔴 ProgressCardSettingMaster (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | NO | TBC | 🔴 |

| CreatedBy | bigint | NO | TBC | 🔴 |

| CreatedOn | datetime | NO | TBC | 🔴 |

| Deleted | bit | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| SectionID | bigint | NO | TBC | 🔴 |

| TypeID | bigint | NO | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedOn | datetime | YES | TBC | 🔴 |



---


#### 🔴 ProgressCardSettingSubjectDetails (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | NO | TBC | 🔴 |

| CreatedOn | datetime | NO | TBC | 🔴 |

| Deleted | bit | NO | TBC | 🔴 |

| HeaderID | bigint | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsActive | bit | NO | TBC | 🔴 |

| SubjectID | bigint | NO | TBC | 🔴 |

| SubjectName | nvarchar | NO | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedOn | datetime | YES | TBC | 🔴 |



---


#### 🔴 ProgressCardSubjectDetails (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| ExemptClassId | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | NO | TBC | 🔴 |

| PlaceID | bigint | YES | TBC | 🔴 |

| SubjectID | bigint | YES | TBC | 🔴 |

| SubjectName | nvarchar | YES | TBC | 🔴 |

| SubjectTypeID | bigint | YES | TBC | 🔴 |

| SubjectTypeName | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 ProgressCardTypeMaster (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Deleted | bit | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Name | nvarchar | NO | TBC | 🔴 |



---


#### 🔴 SL_PreviousSchoolMarks (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Applicant_ID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassName | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| MarksObtained | numeric | YES | TBC | 🔴 |

| MaxMarks | numeric | YES | TBC | 🔴 |

| SchoolName | nvarchar | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| SubjectName | nvarchar | YES | TBC | 🔴 |

| TotalMarks | numeric | YES | TBC | 🔴 |

| YearOfExam | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 TermProgressCardModel (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| CummalativeCardID | bigint | YES | TBC | 🔴 |

| ID | int | NO | TBC | 🔴 |

| TermCardID | bigint | YES | TBC | 🔴 |



---


#### 🔴 TermwiseProgressCardConfiguration (27 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AttendanceExamTypeID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ClassName | varchar | YES | TBC | 🔴 |

| CombineExamHeaderID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeleteReason | varchar | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| DisplayOrderNo | bigint | YES | TBC | 🔴 |

| EvaluationTypeID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | NO | TBC | 🔴 |

| IsDisciplineVisible | bit | NO | TBC | 🔴 |

| IsGraphSubject | bit | NO | TBC | 🔴 |

| RemarksExamTypeID | bigint | YES | TBC | 🔴 |

| RemarksTermTypeID | bigint | YES | TBC | 🔴 |

| RemarksType | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| SectionName | varchar | YES | TBC | 🔴 |

| SubjectID | bigint | YES | TBC | 🔴 |

| SubjectName | varchar | YES | TBC | 🔴 |

| SubjectTypeID | bigint | YES | TBC | 🔴 |

| UpdateBy | bigint | YES | TBC | 🔴 |

| UpdateDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 tblProgressCardModelTypeMaster (14 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AttendanceRequired | bit | NO | TBC | 🔴 |

| ClassTeacherRemarks | bit | NO | TBC | 🔴 |

| CoScholasticArea | bit | NO | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| Discipline | bit | NO | TBC | 🔴 |

| GraphRequired | bit | NO | TBC | 🔴 |

| HeightAndWeight | bit | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| ImageURL | nvarchar | YES | TBC | 🔴 |

| IsDeleted | bit | NO | TBC | 🔴 |

| MarksOrGrade | bit | NO | TBC | 🔴 |

| ModelTypeID | bigint | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| ScholasticArea | bit | NO | TBC | 🔴 |



---


### Staff (40 tables)


#### 🔴 BlockStaffDetail (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Block_ID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| Staff_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 CoScholasticTypeOneEvaluationDetails (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | NO | TBC | 🔴 |

| CreatedOn | datetime | NO | TBC | 🔴 |

| CumLogicID | bigint | NO | TBC | 🔴 |

| Deleted | bit | NO | TBC | 🔴 |

| EvalHierRefID | bigint | NO | TBC | 🔴 |

| EvaluationID | bigint | NO | TBC | 🔴 |

| HeaderID | bigint | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsActive | bit | NO | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedOn | datetime | YES | TBC | 🔴 |



---


#### 🗑️ Department_Master (12 columns) — [DEPRECATED]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**🗑️ Deprecated:** Use StaffDepartmentMaster (deprecated despite identical schema)


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | NO | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 EvaluationMaster (7 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | int | NO | TBC | 🔴 |

| IsDeleted | bit | NO | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 ExamConfigurationEvaluationDetails (16 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| ConvertionScores | decimal | YES | TBC | 🔴 |

| CumlationLogicID | bigint | YES | TBC | 🔴 |

| CumlationLogicName | varchar | YES | TBC | 🔴 |

| DisplayOrderNo | bigint | YES | TBC | 🔴 |

| EvaluationTypeID | bigint | YES | TBC | 🔴 |

| ExamHeaderID | bigint | YES | TBC | 🔴 |

| GradeID | bigint | YES | TBC | 🔴 |

| GradeName | varchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsGradeVisibility | bit | NO | TBC | 🔴 |

| IsMarkVisibility | bit | NO | TBC | 🔴 |

| MaxMark | decimal | YES | TBC | 🔴 |

| MinMark | decimal | YES | TBC | 🔴 |

| ParentID | bigint | YES | TBC | 🔴 |

| SubjectEvaluationID | bigint | YES | TBC | 🔴 |

| SubjectEvaluationName | varchar | YES | TBC | 🔴 |



---


#### 🔴 HPCRatingMaster (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Code | int | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | NO | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| NoOfRatings | int | YES | TBC | 🔴 |

| TypeId | int | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 HPCRatingMasterDetails (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| HPCRatingID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| RatingDecimalValue | decimal | YES | TBC | 🔴 |

| RatingDetailRemarks | nvarchar | YES | TBC | 🔴 |

| RatingName | nvarchar | YES | TBC | 🔴 |

| RatingValue | int | YES | TBC | 🔴 |



---


#### 🔴 HolidayStaffDetails (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Holiday_ID | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| StaffType_Name | nvarchar | YES | TBC | 🔴 |

| Staff_Type_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 OtherExamConfigurationEvaluationDetails (17 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| ConvertionScores | decimal | YES | TBC | 🔴 |

| CumlationLogicID | bigint | YES | TBC | 🔴 |

| CumlationLogicName | varchar | YES | TBC | 🔴 |

| DisplayOrderNo | bigint | YES | TBC | 🔴 |

| EvaluationTypeID | bigint | YES | TBC | 🔴 |

| ExamDate | datetime | YES | TBC | 🔴 |

| ExamHeaderID | bigint | YES | TBC | 🔴 |

| GradeID | bigint | YES | TBC | 🔴 |

| GradeName | varchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsGradeVisibility | bit | NO | TBC | 🔴 |

| IsMarkVisibility | bit | NO | TBC | 🔴 |

| MaxMark | decimal | YES | TBC | 🔴 |

| MinMark | decimal | YES | TBC | 🔴 |

| ParentID | bigint | YES | TBC | 🔴 |

| SubjectEvaluationID | bigint | YES | TBC | 🔴 |

| SubjectEvaluationName | varchar | YES | TBC | 🔴 |



---


#### 🔴 ProgressCardSettingEvaluationDetails (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | NO | TBC | 🔴 |

| CreatedOn | datetime | NO | TBC | 🔴 |

| Deleted | bit | NO | TBC | 🔴 |

| EvalHierID | bigint | NO | TBC | 🔴 |

| ExamTypeID | bigint | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| MasterID | bigint | NO | TBC | 🔴 |

| SubjectID | bigint | NO | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedOn | datetime | YES | TBC | 🔴 |



---


#### 🔴 ProgressCardSettingEvaluationMaster (15 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | NO | TBC | 🔴 |

| CreatedOn | datetime | NO | TBC | 🔴 |

| Deleted | bit | NO | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsGrade | bit | NO | TBC | 🔴 |

| MasterID | bigint | NO | TBC | 🔴 |

| OrderNo | bigint | YES | TBC | 🔴 |

| SubjectName | nvarchar | NO | TBC | 🔴 |

| TreeNode | nvarchar | NO | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedOn | datetime | YES | TBC | 🔴 |

| Visibility | bit | NO | TBC | 🔴 |

| VisibilityTwo | bit | NO | TBC | 🔴 |



---


#### 🔴 Shift_Master (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| End_time | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Shift_Name | nvarchar | YES | TBC | 🔴 |

| Start_time | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 SpecialEventStaffDetails (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| SpecialEvent_ID | bigint | YES | TBC | 🔴 |

| StaffType_Name | nvarchar | YES | TBC | 🔴 |

| Staff_Type_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 StaffActivityTypeMaster (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | date | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | date | YES | TBC | 🔴 |

| Desc | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| TypeName | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | date | YES | TBC | 🔴 |



---


#### 🔴 StaffDepartmentMapping (10 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| DepartmentID | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDefault | bit | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 StaffDepartmentMappingDetail (3 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Id | bigint | NO | TBC | 🔴 |

| MappingID | bigint | YES | TBC | 🔴 |

| StaffID | bigint | YES | TBC | 🔴 |



---


#### ✅ StaffDepartmentMaster (12 columns) — [CONFIRMED]


**Purpose:** Staff departments — LIVE table (Department_Master is deprecated).


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 StaffDesignationMaster (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 StaffEvaluationCriteria (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 StaffEvaluationMaster (16 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Created_by | bigint | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| Evaluation | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| MaxMark | bigint | YES | TBC | 🔴 |

| Rating_Id | bigint | YES | TBC | 🔴 |

| Staff_TypeID | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Weightage | bigint | YES | TBC | 🔴 |



---


#### 🔴 StaffManagementAppraisal (14 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AnalyzingCriteria | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Comment | nvarchar | YES | TBC | 🔴 |

| EvaluationCriteria_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| ManagementComment | nvarchar | YES | TBC | 🔴 |

| ObservationID | bigint | YES | TBC | 🔴 |

| RatingID | bigint | YES | TBC | 🔴 |

| StaffManagementAppraisalRating | bigint | YES | TBC | 🔴 |

| StaffSelfAppraisal_ID | bigint | YES | TBC | 🔴 |

| StaffType_ID | bigint | YES | TBC | 🔴 |

| Staff_ID | bigint | YES | TBC | 🔴 |

| Staff_Name | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 StaffPortalLogin (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Password | nvarchar | YES | TBC | 🔴 |

| Staff_ID | bigint | NO | TBC | 🔴 |

| Username | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 StaffRatingDetails (9 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsMin | nvarchar | YES | TBC | 🔴 |

| MaxMark | numeric | YES | TBC | 🔴 |

| MinMark | numeric | YES | TBC | 🔴 |

| RID | bigint | YES | TBC | 🔴 |

| Rating | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 StaffRatingMaster (7 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 StaffSelfAppraisal (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AnalyzingCriteria | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Comment | nvarchar | YES | TBC | 🔴 |

| EvaluationCriteria_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsAppraisalSubmitted | bit | YES | TBC | 🔴 |

| ObservationID | bigint | YES | TBC | 🔴 |

| Rating | bigint | YES | TBC | 🔴 |

| StaffType_ID | bigint | YES | TBC | 🔴 |

| Staff_ID | bigint | YES | TBC | 🔴 |

| Staff_Name | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 StaffSpecialization (8 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Proficiencylevel | bigint | YES | TBC | 🔴 |

| StaffID | bigint | YES | TBC | 🔴 |

| StaffTypeID | bigint | YES | TBC | 🔴 |

| SubjectID | bigint | YES | TBC | 🔴 |



---


#### 🔴 StaffTypeCategoryMaster (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bigint | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 StaffType_Master (14 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Type_Id | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 Staff_Data_Import (119 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdditionalInfo | nvarchar | YES | TBC | 🔴 |

| AdhaarCardNo | nvarchar | YES | TBC | 🔴 |

| Allergies | nvarchar | YES | TBC | 🔴 |

| Anniversary_Date | date | YES | TBC | 🔴 |

| AppointedBranchID | bigint | YES | TBC | 🔴 |

| AppointedBranchName | nvarchar | YES | TBC | 🔴 |

| BankAccountNo | nvarchar | YES | TBC | 🔴 |

| BiometricCode | nvarchar | YES | TBC | 🔴 |

| BloodGroup_ID | bigint | YES | TBC | 🔴 |

| BloodGroup_Name | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CasteID | bigint | YES | TBC | 🔴 |

| CasteName | nvarchar | YES | TBC | 🔴 |

| ComCity_ID | bigint | YES | TBC | 🔴 |

| ComCountry_ID | bigint | YES | TBC | 🔴 |

| ComState_ID | bigint | YES | TBC | 🔴 |

| Com_Address | nvarchar | YES | TBC | 🔴 |

| Com_City | nvarchar | YES | TBC | 🔴 |

| Com_Country | nvarchar | YES | TBC | 🔴 |

| Com_Email | nvarchar | NO | TBC | 🔴 |

| Com_Mobile | nvarchar | YES | TBC | 🔴 |

| Com_Phone | nvarchar | YES | TBC | 🔴 |

| Com_Pincode | nvarchar | YES | TBC | 🔴 |

| Com_State | nvarchar | YES | TBC | 🔴 |

| Community_ID | bigint | YES | TBC | 🔴 |

| Community_Name | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Dental | nvarchar | YES | TBC | 🔴 |

| DeputedBranchID | bigint | YES | TBC | 🔴 |

| DeputedBranchName | nvarchar | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| Designation_ID | bigint | YES | TBC | 🔴 |

| Designation_Name | nvarchar | YES | TBC | 🔴 |

| Disablity | nvarchar | YES | TBC | 🔴 |

| ESINo | nvarchar | YES | TBC | 🔴 |

| Experience | nvarchar | YES | TBC | 🔴 |

| FatherAge | int | YES | TBC | 🔴 |

| FatherAnnualIncome | nvarchar | YES | TBC | 🔴 |

| FatherDob | date | YES | TBC | 🔴 |

| FatherEducation | nvarchar | YES | TBC | 🔴 |

| FatherEmail | nvarchar | YES | TBC | 🔴 |

| FatherName | nvarchar | YES | TBC | 🔴 |

| FatherOccupation | nvarchar | YES | TBC | 🔴 |

| FatherOrganization | nvarchar | YES | TBC | 🔴 |

| FatherPhone | nvarchar | YES | TBC | 🔴 |

| GuardianAge | int | YES | TBC | 🔴 |

| GuardianAnnualIncome | nvarchar | YES | TBC | 🔴 |

| GuardianContactNo | nvarchar | YES | TBC | 🔴 |

| GuardianDob | date | YES | TBC | 🔴 |

| GuardianEducation | nvarchar | YES | TBC | 🔴 |

| GuardianEmail | nvarchar | YES | TBC | 🔴 |

| GuardianName | nvarchar | YES | TBC | 🔴 |

| GuardianOccupation | nvarchar | YES | TBC | 🔴 |

| GuardianOrganization | nvarchar | YES | TBC | 🔴 |

| Height | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| MaritalStatus | nvarchar | YES | TBC | 🔴 |

| MotherAge | int | YES | TBC | 🔴 |

| MotherAnnualIncome | nvarchar | YES | TBC | 🔴 |

| MotherContactNo | nvarchar | YES | TBC | 🔴 |

| MotherDob | date | YES | TBC | 🔴 |

| MotherEducation | nvarchar | YES | TBC | 🔴 |

| MotherEmail | nvarchar | YES | TBC | 🔴 |

| MotherName | nvarchar | YES | TBC | 🔴 |

| MotherOccupation | nvarchar | YES | TBC | 🔴 |

| MotherOrganization | nvarchar | YES | TBC | 🔴 |

| Mother_Tongue_ID | bigint | YES | TBC | 🔴 |

| Mother_Tongue_Name | nvarchar | YES | TBC | 🔴 |

| Nationality_ID | bigint | YES | TBC | 🔴 |

| Nationality_Name | nvarchar | YES | TBC | 🔴 |

| NoOfChildren | bigint | YES | TBC | 🔴 |

| Others | nvarchar | YES | TBC | 🔴 |

| PANNo | nvarchar | YES | TBC | 🔴 |

| PerCity_ID | bigint | YES | TBC | 🔴 |

| PerCountry_ID | bigint | YES | TBC | 🔴 |

| PerState_ID | bigint | YES | TBC | 🔴 |

| Per_Address | nvarchar | YES | TBC | 🔴 |

| Per_City | nvarchar | YES | TBC | 🔴 |

| Per_Country | nvarchar | YES | TBC | 🔴 |

| Per_Email | nvarchar | YES | TBC | 🔴 |

| Per_Mobile | nvarchar | YES | TBC | 🔴 |

| Per_Phone | nvarchar | YES | TBC | 🔴 |

| Per_Pincode | nvarchar | YES | TBC | 🔴 |

| Per_State | nvarchar | YES | TBC | 🔴 |

| Qualification | nvarchar | YES | TBC | 🔴 |

| Reason | nvarchar | YES | TBC | 🔴 |

| ReleiveingDate | date | YES | TBC | 🔴 |

| Religion_ID | bigint | YES | TBC | 🔴 |

| Religion_Name | nvarchar | YES | TBC | 🔴 |

| ResignedDate | date | YES | TBC | 🔴 |

| Salary | nvarchar | YES | TBC | 🔴 |

| Same_Address | bit | YES | TBC | 🔴 |

| Specilization | nvarchar | YES | TBC | 🔴 |

| Spouse_Address | nvarchar | YES | TBC | 🔴 |

| Spouse_Name | nvarchar | YES | TBC | 🔴 |

| Spouse_Phone | bigint | YES | TBC | 🔴 |

| StaffImg | nvarchar | YES | TBC | 🔴 |

| StaffImgPath | nvarchar | YES | TBC | 🔴 |

| StaffShortName | nvarchar | YES | TBC | 🔴 |

| StaffStatus_ID | bigint | YES | TBC | 🔴 |

| StaffStatus_Name | nvarchar | YES | TBC | 🔴 |

| StaffType_ID | bigint | YES | TBC | 🔴 |

| StaffType_Name | nvarchar | YES | TBC | 🔴 |

| Staff_Age | int | YES | TBC | 🔴 |

| Staff_Code | nvarchar | YES | TBC | 🔴 |

| Staff_DOB | datetime | YES | TBC | 🔴 |

| Staff_DOJ | datetime | YES | TBC | 🔴 |

| Staff_FirstName | nvarchar | YES | TBC | 🔴 |

| Staff_Gender | nvarchar | YES | TBC | 🔴 |

| Staff_LastName | nvarchar | YES | TBC | 🔴 |

| Staff_MiddleName | nvarchar | YES | TBC | 🔴 |

| SubCaste | nvarchar | YES | TBC | 🔴 |

| TypeID | bigint | YES | TBC | 🔴 |

| TypeName | nvarchar | YES | TBC | 🔴 |

| UAN | nvarchar | YES | TBC | 🔴 |

| Vision | nvarchar | YES | TBC | 🔴 |

| Weight | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 Staff_Document (8 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| DocumentName | nvarchar | YES | TBC | 🔴 |

| DocumentType | nvarchar | YES | TBC | 🔴 |

| DocumentUrl | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Staff_ID | bigint | YES | TBC | 🔴 |



---


#### ✅ Staff_Master (145 columns) — [CONFIRMED]


**Purpose:** Staff profiles. Uses Staff_FirstName/Staff_MiddleName/Staff_LastName (NOT FirstName). Has StaffStatus_ID (1=active). Has Staff_ID (the PK).


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdditionalInfo | nvarchar | YES | TBC | 🔴 |

| AdhaarCardNo | nvarchar | YES | TBC | 🔴 |

| Allergies | nvarchar | YES | TBC | 🔴 |

| Anniversary_Date | date | YES | TBC | 🔴 |

| AppointedBranchID | bigint | YES | TBC | 🔴 |

| BEdHolder | bit | YES | TBC | 🔴 |

| BankAccountNo | nvarchar | YES | TBC | 🔴 |

| BiometricCode | nvarchar | YES | TBC | 🔴 |

| BloodGroup_ID | bigint | YES | TBC | 🔴 |

| BloodGroup_Name | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CasteID | bigint | YES | TBC | 🔴 |

| ColorCode | int | YES | TBC | 🔴 |

| ComCity_ID | bigint | YES | TBC | 🔴 |

| ComCountry_ID | bigint | YES | TBC | 🔴 |

| ComState_ID | bigint | YES | TBC | 🔴 |

| Com_Address | nvarchar | YES | TBC | 🔴 |

| Com_City | nvarchar | YES | TBC | 🔴 |

| Com_Country | nvarchar | YES | TBC | 🔴 |

| Com_Email | nvarchar | YES | TBC | 🔴 |

| Com_Mobile | nvarchar | YES | TBC | 🔴 |

| Com_Phone | nvarchar | YES | TBC | 🔴 |

| Com_Pincode | nvarchar | YES | TBC | 🔴 |

| Com_State | nvarchar | YES | TBC | 🔴 |

| CommunicationMailID | nvarchar | YES | TBC | 🔴 |

| Community_ID | bigint | YES | TBC | 🔴 |

| Community_Name | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Dental | nvarchar | YES | TBC | 🔴 |

| DeputedBranchID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| Designation_ID | bigint | YES | TBC | 🔴 |

| Disablity | nvarchar | YES | TBC | 🔴 |

| ESINo | nvarchar | YES | TBC | 🔴 |

| EmergencyContact | nvarchar | YES | TBC | 🔴 |

| Experience | nvarchar | YES | TBC | 🔴 |

| ExperienceInYears | varchar | YES | TBC | 🔴 |

| FatherAge | int | YES | TBC | 🔴 |

| FatherAnnualIncome | nvarchar | YES | TBC | 🔴 |

| FatherDob | date | YES | TBC | 🔴 |

| FatherEducation | nvarchar | YES | TBC | 🔴 |

| FatherEmail | nvarchar | YES | TBC | 🔴 |

| FatherName | nvarchar | YES | TBC | 🔴 |

| FatherOccupation | nvarchar | YES | TBC | 🔴 |

| FatherOrganization | nvarchar | YES | TBC | 🔴 |

| FatherPhone | nvarchar | YES | TBC | 🔴 |

| GuardianAge | int | YES | TBC | 🔴 |

| GuardianAnnualIncome | nvarchar | YES | TBC | 🔴 |

| GuardianContactNo | nvarchar | YES | TBC | 🔴 |

| GuardianDob | date | YES | TBC | 🔴 |

| GuardianEducation | nvarchar | YES | TBC | 🔴 |

| GuardianEmail | nvarchar | YES | TBC | 🔴 |

| GuardianName | nvarchar | YES | TBC | 🔴 |

| GuardianOccupation | nvarchar | YES | TBC | 🔴 |

| GuardianOrganization | nvarchar | YES | TBC | 🔴 |

| Height | nvarchar | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IsDriver | bit | YES | TBC | 🔴 |

| IsVehicleStaff | bit | YES | TBC | 🔴 |

| LicenseExpiryDate | date | YES | TBC | 🔴 |

| LicenseNumber | nvarchar | YES | TBC | 🔴 |

| MaritalStatus | nvarchar | YES | TBC | 🔴 |

| MotherAge | int | YES | TBC | 🔴 |

| MotherAnnualIncome | nvarchar | YES | TBC | 🔴 |

| MotherContactNo | nvarchar | YES | TBC | 🔴 |

| MotherDob | date | YES | TBC | 🔴 |

| MotherEducation | nvarchar | YES | TBC | 🔴 |

| MotherEmail | nvarchar | YES | TBC | 🔴 |

| MotherName | nvarchar | YES | TBC | 🔴 |

| MotherOccupation | nvarchar | YES | TBC | 🔴 |

| MotherOrganization | nvarchar | YES | TBC | 🔴 |

| Mother_Tongue_ID | bigint | YES | TBC | 🔴 |

| Mother_Tongue_Name | nvarchar | YES | TBC | 🔴 |

| Nationality_ID | bigint | YES | TBC | 🔴 |

| Nationality_Name | nvarchar | YES | TBC | 🔴 |

| NoOfChildren | bigint | YES | TBC | 🔴 |

| NoOfChildrens | varchar | YES | TBC | 🔴 |

| Others | nvarchar | YES | TBC | 🔴 |

| PANNo | nvarchar | YES | TBC | 🔴 |

| PassportExpiryDate | date | YES | TBC | 🔴 |

| PassportNo | nvarchar | YES | TBC | 🔴 |

| PerCity_ID | bigint | YES | TBC | 🔴 |

| PerCountry_ID | bigint | YES | TBC | 🔴 |

| PerState_ID | bigint | YES | TBC | 🔴 |

| Per_Address | nvarchar | YES | TBC | 🔴 |

| Per_City | nvarchar | YES | TBC | 🔴 |

| Per_Country | nvarchar | YES | TBC | 🔴 |

| Per_Email | nvarchar | YES | TBC | 🔴 |

| Per_Mobile | nvarchar | YES | TBC | 🔴 |

| Per_Phone | nvarchar | YES | TBC | 🔴 |

| Per_Pincode | nvarchar | YES | TBC | 🔴 |

| Per_State | nvarchar | YES | TBC | 🔴 |

| PrimaryCommunicationMobile | nvarchar | YES | TBC | 🔴 |

| Qualification | nvarchar | YES | TBC | 🔴 |

| Reason | nvarchar | YES | TBC | 🔴 |

| ReleiveingDate | date | YES | TBC | 🔴 |

| Religion_ID | bigint | YES | TBC | 🔴 |

| Religion_Name | nvarchar | YES | TBC | 🔴 |

| Reporting_StaffId | bigint | YES | TBC | 🔴 |

| ResignedDate | date | YES | TBC | 🔴 |

| Salary | nvarchar | YES | TBC | 🔴 |

| Same_Address | bit | YES | TBC | 🔴 |

| SecondaryCommunicationMobile | nvarchar | YES | TBC | 🔴 |

| ServiceConfirmationDate | datetime | YES | TBC | 🔴 |

| ShiftID | bigint | YES | TBC | 🔴 |

| SignatureURL | nvarchar | YES | TBC | 🔴 |

| Specilization | nvarchar | YES | TBC | 🔴 |

| SpouseDesignation | nvarchar | YES | TBC | 🔴 |

| SpouseOccupation | nvarchar | YES | TBC | 🔴 |

| Spouse_Address | nvarchar | YES | TBC | 🔴 |

| Spouse_Name | nvarchar | YES | TBC | 🔴 |

| Spouse_Phone | bigint | YES | TBC | 🔴 |

| StaffImg | nvarchar | YES | TBC | 🔴 |

| StaffShortName | nvarchar | YES | TBC | 🔴 |

| StaffStatus_ID | bigint | YES | 1 = active; other values = inactive/resigned. Filter = 1 for active staff. | ✅ |

| StaffStatus_Name | nvarchar | YES | TBC | 🔴 |

| StaffType_ID | bigint | YES | TBC | 🔴 |

| Staff_Age | int | YES | TBC | 🔴 |

| Staff_Code | nvarchar | YES | TBC | 🔴 |

| Staff_DOB | datetime | YES | TBC | 🔴 |

| Staff_DOJ | datetime | YES | TBC | 🔴 |

| Staff_FirstName | nvarchar | YES | The staff member's first name (NOT 'FirstName' — that's on Student_Master). | ✅ |

| Staff_Gender | nvarchar | YES | TBC | 🔴 |

| Staff_ID | bigint | NO | The PK (NOT 'ID' — different naming from Student_Master.ID). | ✅ |

| Staff_LastName | nvarchar | YES | The staff member's last name. | ✅ |

| Staff_MiddleName | nvarchar | YES | The staff member's middle name. | ✅ |

| Staff_RetirementDate | datetime | YES | TBC | 🔴 |

| SubCaste | nvarchar | YES | TBC | 🔴 |

| TitleID | int | YES | TBC | 🔴 |

| TitleName | nvarchar | YES | TBC | 🔴 |

| TypeID | bigint | YES | TBC | 🔴 |

| TypeName | nvarchar | YES | TBC | 🔴 |

| UAN | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| VISAExpiryDate | date | YES | TBC | 🔴 |

| VISANo | nvarchar | YES | TBC | 🔴 |

| Vehicle_RoleType | nvarchar | YES | TBC | 🔴 |

| Vehicle_RoleTypeId | int | YES | TBC | 🔴 |

| Vision | nvarchar | YES | TBC | 🔴 |

| Weight | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 Staff_OtherActivities (9 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Date | date | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Organization | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| StaffID | bigint | YES | TBC | 🔴 |

| TitleName | nvarchar | YES | TBC | 🔴 |

| TypeID | bigint | YES | TBC | 🔴 |



---


#### 🔴 Staff_PreviousExperience (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Experience | nvarchar | YES | TBC | 🔴 |

| FromDate | date | YES | TBC | 🔴 |

| ID | int | NO | TBC | 🔴 |

| Leaving_Reason | nvarchar | YES | TBC | 🔴 |

| Period | nvarchar | YES | TBC | 🔴 |

| School_Name | nvarchar | YES | TBC | 🔴 |

| Staff_ID | bigint | YES | TBC | 🔴 |

| ToDate | date | YES | TBC | 🔴 |

| Total_Years | bigint | YES | TBC | 🔴 |



---


#### 🔴 Staff_ReferredChildren (8 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Relationship | bigint | YES | TBC | 🔴 |

| Section_ID | bigint | YES | TBC | 🔴 |

| Staff_ID | bigint | YES | TBC | 🔴 |

| Student_Name | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 Staff_ServiceExtension (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| FromDate | date | NO | TBC | 🔴 |

| ID | int | NO | TBC | 🔴 |

| Remarks | varchar | YES | TBC | 🔴 |

| StaffID | bigint | NO | TBC | 🔴 |

| ToDate | date | NO | TBC | 🔴 |



---


#### 🔴 Staff_Subject_ProficiencyLevel (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Proficiency_Level | bigint | YES | TBC | 🔴 |

| Staff_ID | bigint | YES | TBC | 🔴 |

| Subject_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 Staff_TimeTable (14 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Day | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| P1 | nvarchar | YES | TBC | 🔴 |

| P2 | nvarchar | YES | TBC | 🔴 |

| P3 | nvarchar | YES | TBC | 🔴 |

| P4 | nvarchar | YES | TBC | 🔴 |

| P5 | nvarchar | YES | TBC | 🔴 |

| P6 | nvarchar | YES | TBC | 🔴 |

| P7 | nvarchar | YES | TBC | 🔴 |

| P8 | nvarchar | YES | TBC | 🔴 |

| P9 | nvarchar | YES | TBC | 🔴 |

| Staff_Id | bigint | YES | TBC | 🔴 |



---


#### 🔴 Staff_WorkFlow_Details (21 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| ApprovalRemarks | nvarchar | YES | TBC | 🔴 |

| ApprovalStatus | int | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| CurrentStageID | bigint | YES | TBC | 🔴 |

| CurrentStageName | nvarchar | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| HeaderID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| MasterID | bigint | YES | TBC | 🔴 |

| NextStageID | bigint | YES | TBC | 🔴 |

| NextStageName | nvarchar | YES | TBC | 🔴 |

| ScreenID | bigint | YES | TBC | 🔴 |

| StaffID | bigint | YES | TBC | 🔴 |

| Stage_Order | bigint | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 TM_RouteStaffMapping_Details (17 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BoardingPoint_ID | bigint | YES | TBC | 🔴 |

| BoardingType_ID | bigint | YES | TBC | 🔴 |

| BoardingType_Name | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Route_Staff_Mapping_ID | bigint | YES | TBC | 🔴 |

| Staff_ID | bigint | YES | TBC | 🔴 |

| Staff_Name | nvarchar | YES | TBC | 🔴 |

| Staff_Type_ID | bigint | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 TM_RouteStaffMapping_Master (18 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Route_Code | nvarchar | YES | TBC | 🔴 |

| Route_ID | bigint | YES | TBC | 🔴 |

| Route_Name | nvarchar | YES | TBC | 🔴 |

| Seating_Capacity | bigint | YES | TBC | 🔴 |

| Total_Count | bigint | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |

| Vacancy | bigint | YES | TBC | 🔴 |

| VehicleIdentification_No | nvarchar | YES | TBC | 🔴 |

| VehicleRegister_ID | bigint | YES | TBC | 🔴 |



---


### Transport (31 tables)


#### 🔴 BoardingMonthDetails (7 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Amount | numeric | YES | TBC | 🔴 |

| Boarding_ID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| Month_Name | nvarchar | YES | TBC | 🔴 |

| Month_No | bigint | YES | TBC | 🔴 |



---


#### 🟡 BoardingPoint_Master (13 columns) — [PARTIAL]


**Purpose:** Transport boarding points. Has Amount (the boarding fee).


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Amount | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 DriverMaster (22 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Aadhar_Number | nvarchar | YES | TBC | 🔴 |

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Address | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| DistancePerDay | nvarchar | YES | TBC | 🔴 |

| Email | nvarchar | YES | TBC | 🔴 |

| Experience | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| License_Expiry_Date | datetime | YES | TBC | 🔴 |

| License_Number | nvarchar | YES | TBC | 🔴 |

| Mobile | nvarchar | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Qualification | nvarchar | YES | TBC | 🔴 |

| Staff_Type_ID | bigint | YES | TBC | 🔴 |

| Staff_Type_Name | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 NewSyllabusMaster (15 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| MonthID | bigint | YES | TBC | 🔴 |

| MonthName | nvarchar | YES | TBC | 🔴 |

| SubjectID | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🟡 Route_Master (18 columns) — [PARTIAL]


**Purpose:** Transport routes. Dual-purpose: route config + GPS tracker config.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Imei | nvarchar | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Password | nvarchar | YES | TBC | 🔴 |

| URL | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |

| Username | nvarchar | YES | TBC | 🔴 |

| VehicleNo | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 Route_MasterDetails (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BoardingPoint_ID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| Route_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 SyllabusActivityStatus (16 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| ActivityID | bigint | YES | TBC | 🔴 |

| ActivityName | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CompletionDate | datetime | YES | TBC | 🔴 |

| CompletionPercentage | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Created_by | bigint | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| Status | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 SyllabusDailyUpdation (21 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_Id | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Period_Id | bigint | YES | TBC | 🔴 |

| Period_Name | nvarchar | YES | TBC | 🔴 |

| Section_Id | bigint | YES | TBC | 🔴 |

| Staff_Id | bigint | YES | TBC | 🔴 |

| Status_Id | bigint | YES | TBC | 🔴 |

| Status_Name | nvarchar | YES | TBC | 🔴 |

| Subject_Id | bigint | YES | TBC | 🔴 |

| SyllabusUpdationDate | date | YES | TBC | 🔴 |

| Topic_Id | bigint | YES | TBC | 🔴 |

| Topic_Name | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 SyllabusLessonPlan (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| FromDate | date | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| StaffID | bigint | YES | TBC | 🔴 |

| ToDate | date | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 SyllabusTopicMaster (10 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Topic | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 Syllabus_ActivityDetails (8 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Activity | nvarchar | YES | TBC | 🔴 |

| ActivityType | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| FromDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Syllabus_ID | bigint | YES | TBC | 🔴 |

| ToDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 TM_FuelRefillingMaster (21 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| Document | nvarchar | YES | TBC | 🔴 |

| FuelType_ID | bigint | YES | TBC | 🔴 |

| FuelType_Name | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Odometer_Count | numeric | YES | TBC | 🔴 |

| Refill_Cost | numeric | YES | TBC | 🔴 |

| Refill_Date | datetime | YES | TBC | 🔴 |

| Refill_Liters | numeric | YES | TBC | 🔴 |

| Route_ID | bigint | YES | TBC | 🔴 |

| Route_Name | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |

| VehicleIdentification_No | nvarchar | YES | TBC | 🔴 |

| VehicleRegister_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 TM_GeofenceTrackerResponse (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| CreatedDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| LastStatusUpdate | datetime | YES | TBC | 🔴 |

| Status | int | YES | TBC | 🔴 |

| TxnData | text | YES | TBC | 🔴 |



---


#### 🔴 TM_ParentTransportation_Request (27 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| ApprovalDate | datetime | YES | TBC | 🔴 |

| Approved_By_ID | bigint | YES | TBC | 🔴 |

| Approved_By_Name | nvarchar | YES | TBC | 🔴 |

| BoardingPoint_ID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CancellationReason | nvarchar | YES | TBC | 🔴 |

| CancellationType_ID | bigint | YES | TBC | 🔴 |

| CancellationType_Name | nvarchar | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| FromDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsApproved | int | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| RejectedReason | nvarchar | YES | TBC | 🔴 |

| RequestType_ID | bigint | YES | TBC | 🔴 |

| RequestType_Name | nvarchar | YES | TBC | 🔴 |

| Route_ID | bigint | YES | TBC | 🔴 |

| Status | nvarchar | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| ToDate | datetime | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |

| VehicleRegister_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 TM_Route_Vehicle_Mapping (17 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Route_Code | nvarchar | YES | TBC | 🔴 |

| Route_ID | bigint | YES | TBC | 🔴 |

| Route_Name | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |

| VehicleIdentification_No | nvarchar | YES | TBC | 🔴 |

| VehicleRegister_ID | bigint | YES | TBC | 🔴 |

| VehicleType_ID | bigint | YES | TBC | 🔴 |

| VehicleType_Name | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 TM_VehicleDocumentMaster (10 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| ISDeleted | bit | NO | TBC | 🔴 |

| IsAttachmentAvailable | bit | NO | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |

| VehicleDocumentName | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 TM_VehicleDocumentMaster_Details (8 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| DataType_ID | bigint | YES | TBC | 🔴 |

| DataType_Name | nvarchar | YES | TBC | 🔴 |

| FieldName | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsMandatory | bit | NO | TBC | 🔴 |

| MaxLength | numeric | YES | TBC | 🔴 |

| Validation | nvarchar | YES | TBC | 🔴 |

| VehicleDocument_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 TM_VehicleRegisterDocument_Details (16 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Attachment | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| Document_ID | bigint | YES | TBC | 🔴 |

| Document_Name | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Key | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |

| Value | nvarchar | YES | TBC | 🔴 |

| VehicleRegister_ID | bigint | NO | TBC | 🔴 |



---


#### 🔴 TM_VehicleRegisterMaster (52 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdditionalPurchase_Ids | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| BuyerName | nvarchar | YES | TBC | 🔴 |

| CCTV_Installed | bit | NO | TBC | 🔴 |

| City | nvarchar | YES | TBC | 🔴 |

| Cost_of_Vehicle | numeric | YES | TBC | 🔴 |

| Country | nvarchar | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| CurrentAddress | nvarchar | YES | TBC | 🔴 |

| Date_of_Purchase | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| Email | nvarchar | YES | TBC | 🔴 |

| EndDate | datetime | YES | TBC | 🔴 |

| GPS_Device_ID | nvarchar | YES | TBC | 🔴 |

| GPS_Device_URL | nvarchar | YES | TBC | 🔴 |

| HypothecationBy | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| ISGPS_Enabled | bit | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Leased_From | nvarchar | YES | TBC | 🔴 |

| Location_of_Purchase | nvarchar | YES | TBC | 🔴 |

| Make | nvarchar | YES | TBC | 🔴 |

| Mode_of_Purchase_ID | bigint | YES | TBC | 🔴 |

| Mode_of_Purchase_Name | nvarchar | YES | TBC | 🔴 |

| Model | nvarchar | YES | TBC | 🔴 |

| Month_Year_of_Manufacture | nvarchar | YES | TBC | 🔴 |

| Owner_Name | nvarchar | YES | TBC | 🔴 |

| Payment_Status | nvarchar | YES | TBC | 🔴 |

| Phone_NO | nvarchar | YES | TBC | 🔴 |

| Pincode | nvarchar | YES | TBC | 🔴 |

| PrimaryResponsible_Staff_ID | bigint | YES | TBC | 🔴 |

| PrimaryResponsible_Staff_Name | nvarchar | YES | TBC | 🔴 |

| SeatingCapacity | bigint | YES | TBC | 🔴 |

| SellerName | nvarchar | YES | TBC | 🔴 |

| StartDate | datetime | YES | TBC | 🔴 |

| State | nvarchar | YES | TBC | 🔴 |

| Type_of_Ownership_ID | bigint | YES | TBC | 🔴 |

| Type_of_Ownership_Name | nvarchar | YES | TBC | 🔴 |

| Type_of_Vehicle_ID | bigint | YES | TBC | 🔴 |

| Type_of_Vehicle_Name | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |

| VehicleCategory_ID | bigint | YES | TBC | 🔴 |

| VehicleCategory_Name | nvarchar | YES | TBC | 🔴 |

| VehicleIdentification_No | nvarchar | YES | TBC | 🔴 |

| VehicleLicense_No | nvarchar | YES | TBC | 🔴 |

| Vehicle_Status_ID | bigint | YES | TBC | 🔴 |

| Vehicle_Status_Name | nvarchar | YES | TBC | 🔴 |

| Warranty_Details | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 TM_VehicleRegisterScheduledMaintenancePlan_Details (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Comments | nvarchar | YES | TBC | 🔴 |

| FromDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsAlertRequired | bit | NO | TBC | 🔴 |

| SendAlert_ID | bigint | YES | TBC | 🔴 |

| SendAlert_Name | nvarchar | YES | TBC | 🔴 |

| ToDate | datetime | YES | TBC | 🔴 |

| ToWhom_ID | bigint | YES | TBC | 🔴 |

| ToWhom_Name | nvarchar | YES | TBC | 🔴 |

| Type_of_Manitanance_ID | bigint | YES | TBC | 🔴 |

| Type_of_Manitanance_Name | nvarchar | YES | TBC | 🔴 |

| VehicleRegister_ID | bigint | NO | TBC | 🔴 |



---


#### 🔴 TM_Vehicle_Maintenance (27 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| ApprovalStatus | nvarchar | YES | TBC | 🔴 |

| Approved_By_ID | bigint | YES | TBC | 🔴 |

| Approved_By_Name | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Comments | nvarchar | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| EstimatedAmount | numeric | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsApproved | int | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| MaintenanceEndDate | datetime | YES | TBC | 🔴 |

| MaintenanceStartDate | datetime | YES | TBC | 🔴 |

| Reason | nvarchar | YES | TBC | 🔴 |

| RejectReason | nvarchar | YES | TBC | 🔴 |

| Route_Code | nvarchar | YES | TBC | 🔴 |

| Route_ID | bigint | YES | TBC | 🔴 |

| Route_Name | nvarchar | YES | TBC | 🔴 |

| Staff_ID | bigint | YES | TBC | 🔴 |

| Staff_Name | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |

| VehicleIdentification_No | nvarchar | YES | TBC | 🔴 |

| VehicleRegister_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 TM_Vehicle_Maintenance_Activity (15 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| ActivityDate | datetime | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| MaintenanceStatus_ID | bigint | YES | TBC | 🔴 |

| MaintenanceStatus_Name | nvarchar | YES | TBC | 🔴 |

| Maintenance_ID | bigint | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 TM_Vehicle_Maintenance_Document (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| DocumentName | nvarchar | YES | TBC | 🔴 |

| DocumentPath | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Maintenance_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 TM_Vehicle_Maintenance_Expenses (28 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AddExpenses_By | nvarchar | YES | TBC | 🔴 |

| Bank | nvarchar | YES | TBC | 🔴 |

| Branch | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| EndPoint | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Narration | text | YES | TBC | 🔴 |

| PaymentDate | datetime | YES | TBC | 🔴 |

| PaymentMode_ID | bigint | YES | TBC | 🔴 |

| PaymentMode_Name | nvarchar | YES | TBC | 🔴 |

| Payment_No | nvarchar | YES | TBC | 🔴 |

| ReferenceDate | datetime | YES | TBC | 🔴 |

| Reference_No | nvarchar | YES | TBC | 🔴 |

| Route_Code | nvarchar | YES | TBC | 🔴 |

| Route_ID | bigint | YES | TBC | 🔴 |

| Route_Name | nvarchar | YES | TBC | 🔴 |

| StartingPoint | nvarchar | YES | TBC | 🔴 |

| TotalAmount | numeric | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |

| VehicleIdentification_No | nvarchar | YES | TBC | 🔴 |

| VehicleRegister_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 TM_Vehicle_Maintenance_Expenses_Details (14 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Amount | numeric | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| MaintenanceExpenses_ID | bigint | YES | TBC | 🔴 |

| Purpose_ID | bigint | YES | TBC | 🔴 |

| Purpose_Name | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 TM_Vehicle_Maintenance_Expenses_Document_Details (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| DocumentName | nvarchar | YES | TBC | 🔴 |

| DocumentPath | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| MaintenanceExpenses_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 TM_Vehicle_Travel_History (14 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Add_travel_history_by | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| TravelDate | datetime | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |

| VehicleIdentification_No | nvarchar | YES | TBC | 🔴 |

| VehicleRegister_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 TM_Vehicle_Travel_History_Details (16 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| End_KM | numeric | YES | TBC | 🔴 |

| End_Point | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| Route_Code | nvarchar | YES | TBC | 🔴 |

| Route_ID | bigint | YES | TBC | 🔴 |

| Route_Name | nvarchar | YES | TBC | 🔴 |

| Staff_ID | bigint | YES | TBC | 🔴 |

| Staff_Name | nvarchar | YES | TBC | 🔴 |

| Start_KM | numeric | YES | TBC | 🔴 |

| Start_Point | nvarchar | YES | TBC | 🔴 |

| Total_KM | numeric | YES | TBC | 🔴 |

| TripID | nvarchar | YES | TBC | 🔴 |

| Vehicle_Travel_History_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 Transport_TripDetails (8 columns) — [PENDING]


**Purpose:** Transport trip/session config. BusFeeStrucure.TripID → this table.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| RouteID | bigint | YES | TBC | 🔴 |

| TransportEndTime | time | YES | TBC | 🔴 |

| TransportSessionID | int | YES | TBC | 🔴 |

| TransportSessionName | varchar | YES | TBC | 🔴 |

| TransportStartTime | time | YES | TBC | 🔴 |



---


#### 🔴 VehicleMaster (24 columns) — [PENDING]


**Purpose:** Transport vehicles.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Engine_Number | nvarchar | YES | TBC | 🔴 |

| FC_Date | datetime | YES | TBC | 🔴 |

| Fuel_Type_ID | bigint | YES | TBC | 🔴 |

| Fuel_Type_Name | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Insurance_Expiry_Date | datetime | YES | TBC | 🔴 |

| Insurance_Number | nvarchar | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Make | nvarchar | YES | TBC | 🔴 |

| Model | nvarchar | YES | TBC | 🔴 |

| Registration_Number | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| Seating_Capacity | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |

| Vehicle_Number | nvarchar | YES | TBC | 🔴 |

| Vehicle_Type_ID | bigint | YES | TBC | 🔴 |

| Vehicle_Type_Name | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 VehicleTypeMaster (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


### Admin (20 tables)


#### 🗑️ Academic_Month_Master (8 columns) — [DEPRECATED]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**🗑️ Deprecated:** Use Month_Master (deprecated despite the name)


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Actual_Month_No | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| EndDate | date | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Month_Name | nvarchar | YES | TBC | 🔴 |

| Month_No | bigint | YES | TBC | 🔴 |

| StartDate | date | YES | TBC | 🔴 |



---


#### 🔴 Academic_Weeklyoff_Details (4 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Academic_Id | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 AccountTypeMaster (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 Applicant_PreviousSchool (16 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Address | nvarchar | YES | TBC | 🔴 |

| Applicant_ID | bigint | YES | TBC | 🔴 |

| BoardOfStudy | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| City | nvarchar | YES | TBC | 🔴 |

| ExamResult | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Pincode | nvarchar | YES | TBC | 🔴 |

| PreClass | nvarchar | YES | TBC | 🔴 |

| PreLeavingReason | nvarchar | YES | TBC | 🔴 |

| PrePeriod | nvarchar | YES | TBC | 🔴 |

| PreSchoolName | nvarchar | YES | TBC | 🔴 |

| State | nvarchar | YES | TBC | 🔴 |

| Syllabus | nvarchar | YES | TBC | 🔴 |

| UDISENo | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 AutoNumber (25 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AutoNumberType | nvarchar | YES | TBC | 🔴 |

| BlockID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Character | nvarchar | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| Company_ID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| Deleted | bit | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsAcademicYearWise | bit | YES | TBC | 🔴 |

| IsApplicableFor | int | YES | TBC | 🔴 |

| LastSerialNumber | nvarchar | YES | TBC | 🔴 |

| MaxLength | int | YES | TBC | 🔴 |

| Prefix | nvarchar | YES | TBC | 🔴 |

| Prefix2 | nvarchar | YES | TBC | 🔴 |

| Prefix3 | nvarchar | YES | TBC | 🔴 |

| StartingNumber | int | YES | TBC | 🔴 |

| Suffix1 | nvarchar | YES | TBC | 🔴 |

| Suffix2 | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedOn | datetime | YES | TBC | 🔴 |

| Year | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 BlockMaster (15 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Address1 | nvarchar | YES | TBC | 🔴 |

| Address2 | nvarchar | YES | TBC | 🔴 |

| BlockName | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| RegisterNumber | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 BoardMaster (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### ✅ BranchMaster (118 columns) — [CONFIRMED]


**Purpose:** Branch configuration (118 columns). Has 'Principal' column (denormalized — the principal's name). Has SGC_Password/SGC_UserId (sensitive — block in queries).


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| APIKey | nvarchar | YES | SENSITIVE — API key. Never query. | ✅ |

| AddressLine1 | nvarchar | YES | TBC | 🔴 |

| AddressLine2 | nvarchar | YES | TBC | 🔴 |

| AffiliationFrom | date | YES | TBC | 🔴 |

| AffiliationNo | nvarchar | YES | TBC | 🔴 |

| AffiliationStatus | nvarchar | YES | TBC | 🔴 |

| AffiliationValidity | date | YES | TBC | 🔴 |

| AnsappMenus | nvarchar | YES | TBC | 🔴 |

| AppID | nvarchar | YES | TBC | 🔴 |

| ApplicationPrintType | int | YES | TBC | 🔴 |

| ApprovedBy | nvarchar | YES | TBC | 🔴 |

| BlockWiseBilling | bigint | YES | TBC | 🔴 |

| BuildArea | nvarchar | YES | TBC | 🔴 |

| CampusArea | nvarchar | YES | TBC | 🔴 |

| CaseType | varchar | YES | TBC | 🔴 |

| CaseTypeID | bigint | YES | TBC | 🔴 |

| CertificateLogo | nvarchar | YES | TBC | 🔴 |

| ChaloReportURL | nvarchar | YES | TBC | 🔴 |

| ChaloServiceURL | nvarchar | YES | TBC | 🔴 |

| ChaloURL | nvarchar | YES | TBC | 🔴 |

| ChatEndpointURL | nvarchar | YES | TBC | 🔴 |

| ChatIframeURL | nvarchar | YES | TBC | 🔴 |

| City | nvarchar | YES | TBC | 🔴 |

| CollectionType_ID | bigint | YES | TBC | 🔴 |

| ContactPerson | nvarchar | YES | TBC | 🔴 |

| Country | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| DBIsBlockAddress | bit | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| DisplayOrder | int | YES | TBC | 🔴 |

| EducationDistrict | nvarchar | YES | TBC | 🔴 |

| Email | nvarchar | YES | TBC | 🔴 |

| EndTime | nvarchar | YES | TBC | 🔴 |

| EstablishmentYear | datetime | YES | TBC | 🔴 |

| Fax | nvarchar | YES | TBC | 🔴 |

| FeeCustomisation | bit | YES | TBC | 🔴 |

| FeesCollectionView | int | YES | TBC | 🔴 |

| GSTPercentage | numeric | YES | The GST percentage for fee receipts. | ✅ |

| Gallerypath | nvarchar | YES | TBC | 🔴 |

| HideMonthDetails | bit | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IconSet | int | YES | TBC | 🔴 |

| IsBlockEnabled | bit | YES | TBC | 🔴 |

| IsBlockReceipt | bit | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IsFeeRefundable | bit | YES | TBC | 🔴 |

| IsOnlineApplicationLinkActive | bit | YES | TBC | 🔴 |

| IsPartialPayment | bit | NO | TBC | 🔴 |

| IsSequenceNeeded | bit | YES | TBC | 🔴 |

| IsZeroMarkGradeAllowed | bit | YES | TBC | 🔴 |

| LeftLogoURL | nvarchar | YES | TBC | 🔴 |

| LibraryURL | nvarchar | YES | TBC | 🔴 |

| LicensedExpiryDate | date | YES | TBC | 🔴 |

| LicensedStudents | nvarchar | YES | TBC | 🔴 |

| LiveStreamURL | nvarchar | YES | TBC | 🔴 |

| Logo | nvarchar | YES | TBC | 🔴 |

| LogoText | nvarchar | YES | TBC | 🔴 |

| LogoURL | nvarchar | YES | TBC | 🔴 |

| MessageDate | date | YES | TBC | 🔴 |

| MessageURL | nvarchar | YES | TBC | 🔴 |

| MgmtAppMenus | nvarchar | YES | TBC | 🔴 |

| MiddleLogoURL | nvarchar | YES | TBC | 🔴 |

| Mobile | nvarchar | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| NewsURL | nvarchar | YES | TBC | 🔴 |

| OnlineApplicationFeeCollectionStage | varchar | YES | TBC | 🔴 |

| OnlineApplicationFees | bit | YES | TBC | 🔴 |

| OnlineApplicationURL | nvarchar | YES | TBC | 🔴 |

| PastFeeColletionDay | bigint | YES | TBC | 🔴 |

| PastPreAdmissionDay | bigint | YES | TBC | 🔴 |

| PaymentLinkExpiresDay | bigint | YES | TBC | 🔴 |

| PaymentMode | nvarchar | YES | TBC | 🔴 |

| PeriodicFessCollection | bit | YES | TBC | 🔴 |

| Phone1 | nvarchar | YES | TBC | 🔴 |

| Phone2 | nvarchar | YES | TBC | 🔴 |

| PinCode | nvarchar | YES | TBC | 🔴 |

| PlayGroundArea | nvarchar | YES | TBC | 🔴 |

| PortalMenus | nvarchar | YES | TBC | 🔴 |

| PortalPasswordField | nvarchar | YES | TBC | 🔴 |

| PortalPopUpTimeOut | int | YES | TBC | 🔴 |

| PortalUserNameField | nvarchar | YES | TBC | 🔴 |

| PortalUserNamePrefix | nvarchar | YES | TBC | 🔴 |

| Prefix | nvarchar | YES | The branch's receipt/bill-number prefix (NOT a database-name prefix). | ✅ |

| Principal | nvarchar | YES | The principal's name — DENORMALIZED directly on the branch record. Use SELECT bm.Principal for 'who is the principal' queries (not a relational join). | ✅ |

| PrintType | nvarchar | YES | TBC | 🔴 |

| ProspectusFeesAmount | numeric | YES | TBC | 🔴 |

| ReceiptPeriod | int | YES | TBC | 🔴 |

| RecgAuthority | nvarchar | YES | TBC | 🔴 |

| RegionID | bigint | YES | TBC | 🔴 |

| RegionName | nvarchar | YES | TBC | 🔴 |

| ReportFormat | nvarchar | YES | TBC | 🔴 |

| ReportPrefix | nvarchar | YES | TBC | 🔴 |

| RevenueDistrict | nvarchar | YES | TBC | 🔴 |

| RightLogoURL | nvarchar | YES | TBC | 🔴 |

| SGC_Password | nvarchar | YES | SENSITIVE — SMS gateway password. Never query. | ✅ |

| SGC_UserId | nvarchar | YES | SENSITIVE — SMS gateway user ID. Never query. | ✅ |

| SMSAPIURL | nvarchar | YES | TBC | 🔴 |

| SchoolCode | nvarchar | YES | TBC | 🔴 |

| SchoolImg | nvarchar | YES | TBC | 🔴 |

| ShortName | nvarchar | YES | TBC | 🔴 |

| SignatureURL | nvarchar | YES | TBC | 🔴 |

| StaffIDCard | int | YES | TBC | 🔴 |

| StartTime | nvarchar | YES | TBC | 🔴 |

| State | nvarchar | YES | TBC | 🔴 |

| StudentIDCard | int | YES | TBC | 🔴 |

| SubTitle | nvarchar | YES | TBC | 🔴 |

| Trust | nvarchar | YES | TBC | 🔴 |

| TrustRegistration | nvarchar | YES | TBC | 🔴 |

| TypeOfReceipt | nvarchar | YES | TBC | 🔴 |

| TypeOfReceiptParent | varchar | YES | TBC | 🔴 |

| UDISENo | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| VideoURL | nvarchar | YES | TBC | 🔴 |

| Website | nvarchar | YES | TBC | 🔴 |

| locktime | nvarchar | YES | TBC | 🔴 |



---


#### ✅ Branch_Academic_Details (15 columns) — [CONFIRMED]


**Purpose:** The current-academic-year resolver. The row where GETDATE() BETWEEN Start_Date AND End_Date is the current AY. Has PreviousYearID for year-over-year comparison.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Branch_Id | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| DB_Suffix | nvarchar | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| DisplayOrder | int | YES | TBC | 🔴 |

| End_Date | datetime | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| PreviousYearID | bigint | YES | TBC | 🔴 |

| Start_Date | datetime | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



**Foreign keys:**

- Branch_Id → BranchMaster.ID (CONFIRMED)
 — Column is 'Branch_Id' (with underscore)


- PreviousYearID → Branch_Academic_Details.Id (CONFIRMED)
 — Self-reference to the previous AY




---


#### 🔴 Branch_Facility_Details (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Branch_Id | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Quantity | bigint | YES | TBC | 🔴 |



---


#### 🔴 Branch_Government_Certificate_Details (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Branch_Id | bigint | YES | TBC | 🔴 |

| Date_Of_Issue | date | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Reference_No | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 Branch_Management_Details (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Branch_Id | bigint | YES | TBC | 🔴 |

| Designation_Name | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| Mobile | nvarchar | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 Company_Master (26 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AccountType_Id | bigint | YES | TBC | 🔴 |

| Account_No | nvarchar | YES | TBC | 🔴 |

| Address | nvarchar | YES | TBC | 🔴 |

| BankLogo | nvarchar | YES | TBC | 🔴 |

| Bank_Name | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Branch_Code | nvarchar | YES | TBC | 🔴 |

| Branch_Name | nvarchar | YES | TBC | 🔴 |

| CompanyImg | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| Email | nvarchar | YES | TBC | 🔴 |

| GSTIN | nvarchar | YES | TBC | 🔴 |

| IFSC_Code | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Phone | nvarchar | YES | TBC | 🔴 |

| ShortName | nvarchar | YES | TBC | 🔴 |

| TallyName | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🟡 HolidayMaster (22 columns) — [PARTIAL]


**Purpose:** School holidays. Has HolidayDate, HolidayName, BranchID.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| From_Date | datetime | YES | TBC | 🔴 |

| GovernmentHoliday | bit | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IsHalfDay | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| School_Id | bigint | YES | TBC | 🔴 |

| TimeSlotId | bigint | YES | TBC | 🔴 |

| TimeSlotName | nvarchar | YES | TBC | 🔴 |

| To_Date | datetime | YES | TBC | 🔴 |

| Type_ID | bigint | YES | TBC | 🔴 |

| Type_Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| withsection | bit | YES | TBC | 🔴 |



---


#### 🔴 RegionMaster (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Description | varchar | YES | TBC | 🔴 |

| DisplayOrder | bigint | YES | TBC | 🔴 |

| ID | int | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 SchoolMaster (40 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AddressLine1 | nvarchar | YES | TBC | 🔴 |

| AddressLine2 | nvarchar | YES | TBC | 🔴 |

| AffiliationFrom | date | YES | TBC | 🔴 |

| AffiliationNo | nvarchar | YES | TBC | 🔴 |

| AffiliationStatus | nvarchar | YES | TBC | 🔴 |

| AffiliationValidity | date | YES | TBC | 🔴 |

| Board_ID | bigint | YES | TBC | 🔴 |

| BuildArea | nvarchar | YES | TBC | 🔴 |

| CampusArea | nvarchar | YES | TBC | 🔴 |

| City | nvarchar | YES | TBC | 🔴 |

| ContactPerson | nvarchar | YES | TBC | 🔴 |

| Country | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| EducationDistrict | nvarchar | YES | TBC | 🔴 |

| Email | nvarchar | YES | TBC | 🔴 |

| EstablishmentYear | datetime | YES | TBC | 🔴 |

| Fax | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Logo | nvarchar | YES | TBC | 🔴 |

| Mobile | nvarchar | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Phone1 | nvarchar | YES | TBC | 🔴 |

| Phone2 | nvarchar | YES | TBC | 🔴 |

| PlayGroundArea | nvarchar | YES | TBC | 🔴 |

| Prefix | nvarchar | YES | TBC | 🔴 |

| ProspectusFeesAmount | numeric | YES | TBC | 🔴 |

| RecgAuthority | nvarchar | YES | TBC | 🔴 |

| RevenueDistrict | nvarchar | YES | TBC | 🔴 |

| SchoolImg | nvarchar | YES | TBC | 🔴 |

| ShortName | nvarchar | YES | TBC | 🔴 |

| State | nvarchar | YES | TBC | 🔴 |

| Trust | nvarchar | YES | TBC | 🔴 |

| TrustRegistration | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Website | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 SchoolReOpeningDateConfiguration (9 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassIDs | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| ReOpeningDate | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 StorageConfiguration (20 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AccessToken | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| FTPName | nvarchar | YES | TBC | 🔴 |

| FileLocation | nvarchar | YES | TBC | 🔴 |

| ID | int | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Password | nvarchar | YES | TBC | 🔴 |

| Port | nvarchar | YES | TBC | 🔴 |

| ScreenID | bigint | YES | TBC | 🔴 |

| ScreenName | nvarchar | YES | TBC | 🔴 |

| StorageTypeID | bigint | YES | TBC | 🔴 |

| StorageTypeName | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |

| UserName | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 WeekMaster (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Day | nvarchar | YES | TBC | 🔴 |

| ID | int | NO | TBC | 🔴 |

| OrderNo | int | YES | TBC | 🔴 |



---


#### 🔴 tblAuditTrailLog (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | date | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IPAddress | nvarchar | YES | TBC | 🔴 |

| NewDetails | text | YES | TBC | 🔴 |

| OldDetail | text | YES | TBC | 🔴 |

| Operation | nvarchar | YES | TBC | 🔴 |

| ScreenName | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | date | YES | TBC | 🔴 |



---


### Payroll (18 tables)


#### 🔴 AdhocSalaryEmployeeMapping (16 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AmountTypeID | int | YES | TBC | 🔴 |

| AmountValue | decimal | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DesignationID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsSettlementMonth | bit | YES | TBC | 🔴 |

| MonthID | bigint | YES | TBC | 🔴 |

| SalaryRuleID | bigint | YES | TBC | 🔴 |

| SettlementMonthID | bigint | YES | TBC | 🔴 |

| StaffID | bigint | YES | TBC | 🔴 |

| StaffTypeID | bigint | YES | TBC | 🔴 |

| UpdatedAt | datetime | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |



---


#### 🔴 AdhocSalaryRuleLedger (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Amount | decimal | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedAt | datetime | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsSettlement | bit | YES | TBC | 🔴 |

| MonthID | bigint | YES | TBC | 🔴 |

| SalaryRuleID | bigint | YES | TBC | 🔴 |

| SettlementMonthID | bigint | YES | TBC | 🔴 |

| StaffID | bigint | YES | TBC | 🔴 |

| TransactionType | varchar | YES | TBC | 🔴 |



---


#### 🔴 AdhocSalaryRuleMaster (15 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedAt | datetime | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IsPayslipCreditVisible | bit | YES | TBC | 🔴 |

| IsPayslipDebitVisible | bit | YES | TBC | 🔴 |

| PayslipCreditParticularID | bigint | YES | TBC | 🔴 |

| PayslipDebitParticularID | bigint | YES | TBC | 🔴 |

| RuleModeID | int | YES | TBC | 🔴 |

| RuleName | varchar | YES | TBC | 🔴 |

| SalaryRuleComponentID | bigint | YES | TBC | 🔴 |

| UpdatedAt | datetime | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |



---


#### 🔴 AllowanceDeductionMaster (16 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsApplicableAfterRetirement | bit | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| MaxLimit | bigint | YES | TBC | 🔴 |

| ParticularKeyword | nvarchar | YES | TBC | 🔴 |

| Particulars | nvarchar | YES | TBC | 🔴 |

| ParticularsCode | nvarchar | YES | TBC | 🔴 |

| SalaryFormula | nvarchar | YES | TBC | 🔴 |

| TypeId | bigint | YES | TBC | 🔴 |

| TypeName | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### ✅ EmployeeSalaryDetails (8 columns) — [CONFIRMED]


**Purpose:** Static salary structure. Has TypeID (1=Earning, 2=Deduction), EmployeeID, Amount, Particulars, EffectiveDate. Has BranchID (must be scoped — L3732 RBAC violation found).


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Amount | decimal | YES | TBC | 🔴 |

| EffectiveDate | datetime | YES | TBC | 🔴 |

| EmployeeID | bigint | YES | FK → Staff_Master.Staff_ID (the employee). | ✅ |

| ID | bigint | NO | TBC | 🔴 |

| Particulars | nvarchar | YES | TBC | 🔴 |

| ParticularsID | bigint | YES | TBC | 🔴 |

| SalaryStructureID | bigint | YES | TBC | 🔴 |

| TypeID | bigint | YES | 1 = Earning; 2 = Deduction (NOT a bit — it's an int). | ✅ |



**Foreign keys:**

- EmployeeID → Staff_Master.Staff_ID (CONFIRMED)
 — EmployeeID → Staff_Master.Staff_ID




---


#### 🔴 EmployeeSalaryHoldDetail (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | NO | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| EmployeeID | bigint | NO | TBC | 🔴 |

| EmployeeMasterID | bigint | NO | TBC | 🔴 |

| HoldFromDate | date | YES | TBC | 🔴 |

| HoldToDate | date | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | NO | TBC | 🔴 |

| Reason | varchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 GenerateSalaryEmployee_Details (8 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Amount | decimal | YES | TBC | 🔴 |

| EmployeeID | bigint | YES | TBC | 🔴 |

| HeaderID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| MasterID | bigint | YES | TBC | 🔴 |

| Particulars | nvarchar | YES | TBC | 🔴 |

| ParticularsID | bigint | YES | TBC | 🔴 |

| TypeID | bigint | YES | TBC | 🔴 |



---


#### 🟡 GenerateSalaryEmployee_Master (22 columns) — [PARTIAL]


**Purpose:** Per-employee payroll detail for a run. Has HeaderID → GenerateSalary_Master.ID, MasterID, NetPay.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| DesignationID | bigint | YES | TBC | 🔴 |

| DesignationName | nvarchar | YES | TBC | 🔴 |

| EmployeeCode | nvarchar | YES | TBC | 🔴 |

| EmployeeID | bigint | YES | TBC | 🔴 |

| EmployeeName | nvarchar | YES | TBC | 🔴 |

| GrossAmount | decimal | YES | TBC | 🔴 |

| HeaderID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | NO | TBC | 🔴 |

| LOPDays | decimal | YES | TBC | 🔴 |

| NetPay | decimal | YES | TBC | 🔴 |

| NoofLeave | decimal | YES | TBC | 🔴 |

| PresentDays | decimal | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |

| WorkingDays | bigint | YES | TBC | 🔴 |



**Foreign keys:**

- HeaderID → GenerateSalary_Master.ID (PARTIAL)




---


#### 🟡 GenerateSalary_Master (14 columns) — [PARTIAL]


**Purpose:** Payroll run header. Has MonthID, AcademicYearID, BranchID.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | NO | TBC | 🔴 |

| MonthID | bigint | YES | TBC | 🔴 |

| MonthName | nvarchar | YES | TBC | 🔴 |

| StaffTypeID | bigint | YES | TBC | 🔴 |

| StaffTypeName | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 PayRollRuleMaster (26 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AmountConfigurationID | int | YES | TBC | 🔴 |

| AmountValue | decimal | YES | TBC | 🔴 |

| ApplicableForID | bigint | YES | TBC | 🔴 |

| ApplicableForName | nvarchar | YES | TBC | 🔴 |

| ApplicableValue | nvarchar | YES | TBC | 🔴 |

| AttendanceStatusID | bigint | YES | TBC | 🔴 |

| AttendanceStatusName | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ConditionValues | nvarchar | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| ImpactTypeID | int | YES | TBC | 🔴 |

| OperatorID | bigint | YES | TBC | 🔴 |

| OperatorName | nvarchar | YES | TBC | 🔴 |

| PayrollActionID | int | YES | TBC | 🔴 |

| PayslipComponentID | bigint | YES | TBC | 🔴 |

| RuleName | nvarchar | YES | TBC | 🔴 |

| SalaryCalculationComponentIds | nvarchar | YES | TBC | 🔴 |

| StaffTypeIds | nvarchar | YES | TBC | 🔴 |

| UpdateDate | datetime | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |



---


#### 🔴 PayrollRuleLog (35 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AmountConfigurationID | int | YES | TBC | 🔴 |

| AmountValue | decimal | YES | TBC | 🔴 |

| ApplicableEndDate | date | YES | TBC | 🔴 |

| ApplicableForID | bigint | YES | TBC | 🔴 |

| ApplicableForName | nvarchar | YES | TBC | 🔴 |

| ApplicableStartDate | date | YES | TBC | 🔴 |

| ApplicableValue | nvarchar | YES | TBC | 🔴 |

| AttendanceStatusID | bigint | YES | TBC | 🔴 |

| AttendanceStatusName | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ConditionValues | nvarchar | YES | TBC | 🔴 |

| EmployeeCode | nvarchar | YES | TBC | 🔴 |

| EmployeeID | bigint | YES | TBC | 🔴 |

| EmployeeName | nvarchar | YES | TBC | 🔴 |

| GenerateSalaryEmployee_MasterID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| ImpactTypeID | int | YES | TBC | 🔴 |

| ImpactTypeName | nvarchar | YES | TBC | 🔴 |

| LogMessage | nvarchar | YES | TBC | 🔴 |

| MonthID | bigint | YES | TBC | 🔴 |

| MonthName | nvarchar | YES | TBC | 🔴 |

| OperatorID | bigint | YES | TBC | 🔴 |

| OperatorName | nvarchar | YES | TBC | 🔴 |

| PayrollActionID | int | YES | TBC | 🔴 |

| PayrollActionName | nvarchar | YES | TBC | 🔴 |

| PayslipComponentID | bigint | YES | TBC | 🔴 |

| PresentDays | decimal | YES | TBC | 🔴 |

| RuleAppliedValue | decimal | YES | TBC | 🔴 |

| RuleID | bigint | YES | TBC | 🔴 |

| RuleName | nvarchar | YES | TBC | 🔴 |

| SalaryCalculationComponentIds | nvarchar | YES | TBC | 🔴 |

| StaffTypeID | bigint | YES | TBC | 🔴 |

| StaffTypeName | nvarchar | YES | TBC | 🔴 |

| WorkingDays | bigint | YES | TBC | 🔴 |



---


#### 🔴 PayrollSettings (14 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Retirement_Age | int | YES | TBC | 🔴 |

| SalaryDate | datetime | YES | TBC | 🔴 |

| SalaryFromDate | datetime | YES | TBC | 🔴 |

| SalaryToDate | datetime | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 SalaryAdvanceIssue (19 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | NO | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| EmployeeID | bigint | NO | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | NO | TBC | 🔴 |

| IssueDate | datetime | YES | TBC | 🔴 |

| IssueStatus | int | YES | TBC | 🔴 |

| LoanAmount | numeric | YES | TBC | 🔴 |

| RepaymentID | int | YES | TBC | 🔴 |

| RepaymentStartDate | datetime | YES | TBC | 🔴 |

| RequestID | bigint | NO | TBC | 🔴 |

| ReturnDate | date | YES | TBC | 🔴 |

| Tenure | int | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 SalaryAdvanceIssueDetails (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Amount | numeric | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | NO | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | NO | TBC | 🔴 |

| IssueID | bigint | NO | TBC | 🔴 |

| Month_No | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 SalaryAdvanceRequest (19 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| ApprovalStatus | int | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | NO | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| EmployeeID | bigint | NO | TBC | 🔴 |

| EmployeeName | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | NO | TBC | 🔴 |

| IssueStatus | int | YES | TBC | 🔴 |

| LoanAmount | numeric | YES | TBC | 🔴 |

| Reason | nvarchar | YES | TBC | 🔴 |

| RepaymentID | int | YES | TBC | 🔴 |

| ReturnDate | date | YES | TBC | 🔴 |

| Tenure | int | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 SalaryAdvanceRequestDetails (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Amount | numeric | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | NO | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | NO | TBC | 🔴 |

| Month_No | bigint | YES | TBC | 🔴 |

| RequestID | bigint | NO | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 SalaryStructure (10 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 SalaryStructureDetails (7 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Amount | decimal | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| ISLOPNeeded | bit | YES | TBC | 🔴 |

| Particulars | nvarchar | YES | TBC | 🔴 |

| ParticularsID | bigint | YES | TBC | 🔴 |

| SalaryStructureID | bigint | YES | TBC | 🔴 |

| TypeID | bigint | YES | TBC | 🔴 |



---


### Timetable (17 tables)


#### 🔴 AirpayTXNDataTable (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| APTransactionID | nvarchar | YES | TBC | 🔴 |

| AdmissionNo | varchar | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| Hash | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| TXNMessage | nvarchar | YES | TBC | 🔴 |

| TransactionAmount | nvarchar | YES | TBC | 🔴 |

| TransactionDate | datetime | YES | TBC | 🔴 |

| TransactionID | nvarchar | YES | TBC | 🔴 |

| TransactionStatus | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 BonafideSetting (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AuthorisedSignature | nvarchar | YES | TBC | 🔴 |

| BodyoftheContent | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| Subjectline | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 CommonSettings (10 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| SMSType | bigint | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 GQPaymentTXNTable (16 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DbPrefix | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| OrderID | nvarchar | YES | TBC | 🔴 |

| PaymentConID | bigint | YES | TBC | 🔴 |

| SchoolID | bigint | YES | TBC | 🔴 |

| StudentEmail | nvarchar | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| StudentMobile | nvarchar | YES | TBC | 🔴 |

| StudentName | nvarchar | YES | TBC | 🔴 |

| TotalPaidAmount | bigint | YES | TBC | 🔴 |

| TransactionType | nvarchar | YES | TBC | 🔴 |

| TxnData | text | YES | TBC | 🔴 |

| UpdateDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 PaymentTXNTable (19 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DbPrefix | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Narration | ntext | YES | TBC | 🔴 |

| OrderID | nvarchar | YES | TBC | 🔴 |

| PaymentID | nvarchar | YES | TBC | 🔴 |

| PaymentProvider | nvarchar | YES | TBC | 🔴 |

| SchoolID | bigint | YES | TBC | 🔴 |

| StudentEmail | nvarchar | YES | TBC | 🔴 |

| StudentMobile | nvarchar | YES | TBC | 🔴 |

| StudentName | nvarchar | YES | TBC | 🔴 |

| TotalPaidAmount | bigint | YES | TBC | 🔴 |

| TransactionType | bigint | YES | TBC | 🔴 |

| TxnData | nvarchar | YES | TBC | 🔴 |

| TxnStatus | nvarchar | YES | TBC | 🔴 |

| UpdateDate | datetime | YES | TBC | 🔴 |

| studentid | bigint | YES | TBC | 🔴 |



---


#### 🔴 PaymentTXNTableLog (7 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| CreatedDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| OrderID | nvarchar | YES | TBC | 🔴 |

| PaymentID | nvarchar | YES | TBC | 🔴 |

| PaymentStatus | nvarchar | YES | TBC | 🔴 |

| TxnStatus | nvarchar | YES | TBC | 🔴 |

| studentid | bigint | YES | TBC | 🔴 |



---


#### 🔴 SubjectForTimeTable (15 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ColorCode | int | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IsGroup | bit | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| SubjectID | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 SubstitutionTimeTableDetails (8 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| ClassID | numeric | YES | TBC | 🔴 |

| ColumnNo | int | YES | TBC | 🔴 |

| ID | numeric | NO | TBC | 🔴 |

| ReplacingStaffID | numeric | YES | TBC | 🔴 |

| RowNo | int | YES | TBC | 🔴 |

| SectionID | numeric | YES | TBC | 🔴 |

| SubjectID | numeric | YES | TBC | 🔴 |

| SubstitutionID | numeric | YES | TBC | 🔴 |



---


#### 🔴 SubstitutionTimeTableMaster (15 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| FromDate | datetime | YES | TBC | 🔴 |

| GeneratedHtml | nvarchar | YES | TBC | 🔴 |

| ID | numeric | NO | TBC | 🔴 |

| IsDeleted | bit | NO | TBC | 🔴 |

| PrimaryStaffID | bigint | YES | TBC | 🔴 |

| SubstitutionType | nvarchar | YES | TBC | 🔴 |

| ToDate | datetime | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | nchar | YES | TBC | 🔴 |



---


#### 🔴 SubstitutionTimeTableRule (39 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| ApplicableClasses | nvarchar | YES | TBC | 🔴 |

| ApplicableClassesName | nvarchar | YES | TBC | 🔴 |

| ApplicableLevels | nvarchar | YES | TBC | 🔴 |

| ApplicableLevelsNames | nvarchar | YES | TBC | 🔴 |

| ApplyRuleFor | int | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| BreakAllowed | bit | YES | TBC | 🔴 |

| Cols | int | YES | TBC | 🔴 |

| Created_By_ID | numeric | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | numeric | YES | TBC | 🔴 |

| Grid | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| MaxBlockSubjectsPerDay | int | YES | TBC | 🔴 |

| MaxContinuesCount | int | YES | TBC | 🔴 |

| MaxCountPerDay | int | YES | TBC | 🔴 |

| MaxCountPerWeek | int | YES | TBC | 🔴 |

| MaxPeriodPerDay | int | YES | TBC | 🔴 |

| MaxPeriodPerWeek | int | YES | TBC | 🔴 |

| MaxSimultaneousCount | int | YES | TBC | 🔴 |

| MinCountPerDay | int | YES | TBC | 🔴 |

| MinCountPerWeek | int | YES | TBC | 🔴 |

| MinPeriodPerDay | int | YES | TBC | 🔴 |

| MinPeriodPerWeek | int | YES | TBC | 🔴 |

| PeriodsCount | int | YES | TBC | 🔴 |

| Rows | int | YES | TBC | 🔴 |

| RuleCategory | nvarchar | YES | TBC | 🔴 |

| RuleCategoryID | int | YES | TBC | 🔴 |

| SectionWise | bit | YES | TBC | 🔴 |

| StaffAvailability | nvarchar | YES | TBC | 🔴 |

| StaffIDs | nvarchar | YES | TBC | 🔴 |

| StaffNames | nvarchar | YES | TBC | 🔴 |

| SubjectIDs | nvarchar | YES | TBC | 🔴 |

| SubjectNames | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | numeric | YES | TBC | 🔴 |



---


#### 🔴 TimeTableBreakDetails (7 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| BreakName | nvarchar | YES | TBC | 🔴 |

| BreakPeriods | bigint | YES | TBC | 🔴 |

| Duration | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| TimeTableSettingID | bigint | YES | TBC | 🔴 |



---


#### 🔴 TimeTableGeneration (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AStaff_ID | bigint | YES | TBC | 🔴 |

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_ID | bigint | YES | TBC | 🔴 |

| ColumnNo | int | YES | TBC | 🔴 |

| GroupSubjectID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsCombined | bit | YES | TBC | 🔴 |

| IsGroup | bit | YES | TBC | 🔴 |

| RowNo | int | YES | TBC | 🔴 |

| Section_ID | bigint | YES | TBC | 🔴 |

| Staff_ID | bigint | YES | TBC | 🔴 |

| Subject_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 TimeTableGenerationComplete (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_ID | bigint | YES | TBC | 🔴 |

| ColumnNo | int | YES | TBC | 🔴 |

| GroupSubjectID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsCombined | bit | YES | TBC | 🔴 |

| IsGroup | bit | YES | TBC | 🔴 |

| RowNo | int | YES | TBC | 🔴 |

| Section_ID | bigint | NO | TBC | 🔴 |

| Staff_ID | bigint | YES | TBC | 🔴 |

| Subject_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 TimeTablePriority (16 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ClassIDs | nvarchar | YES | TBC | 🔴 |

| ClassNames | nvarchar | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| CriteriaID | int | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ExecutionOrder | int | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| Title | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 TimeTablePriorityDetails (4 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| CategoryID | int | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| SubjectID | bigint | YES | TBC | 🔴 |

| TPID | bigint | YES | TBC | 🔴 |



---


#### 🔴 TimeTableRule (36 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| ApplicableClasses | nvarchar | YES | TBC | 🔴 |

| ApplicableClassesName | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| BreakAllowed | bit | YES | TBC | 🔴 |

| Cols | int | YES | TBC | 🔴 |

| Created_By_ID | numeric | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | numeric | YES | TBC | 🔴 |

| Grid | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| MaxBlockSubjectsPerDay | int | YES | TBC | 🔴 |

| MaxContinuesCount | int | YES | TBC | 🔴 |

| MaxCountPerDay | int | YES | TBC | 🔴 |

| MaxCountPerWeek | int | YES | TBC | 🔴 |

| MaxPeriodPerDay | int | YES | TBC | 🔴 |

| MaxPeriodPerWeek | int | YES | TBC | 🔴 |

| MaxSimultaneousCount | int | YES | TBC | 🔴 |

| MinCountPerDay | int | YES | TBC | 🔴 |

| MinCountPerWeek | int | YES | TBC | 🔴 |

| MinPeriodPerDay | int | YES | TBC | 🔴 |

| MinPeriodPerWeek | int | YES | TBC | 🔴 |

| PeriodsCount | int | YES | TBC | 🔴 |

| Rows | int | YES | TBC | 🔴 |

| RuleCategory | nvarchar | YES | TBC | 🔴 |

| RuleCategoryID | int | YES | TBC | 🔴 |

| SectionWise | bit | YES | TBC | 🔴 |

| StaffAvailability | nvarchar | YES | TBC | 🔴 |

| StaffIDs | nvarchar | YES | TBC | 🔴 |

| StaffNames | nvarchar | YES | TBC | 🔴 |

| SubjectIDs | nvarchar | YES | TBC | 🔴 |

| SubjectNames | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | numeric | YES | TBC | 🔴 |



---


#### 🔴 TimeTableSetting (18 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassEndTime | nvarchar | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ClassStartTime | nvarchar | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| Days | nvarchar | YES | TBC | 🔴 |

| HalfDayPeriods | int | YES | TBC | 🔴 |

| HalfDaySessions | nvarchar | YES | TBC | 🔴 |

| HalfDays | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| MaxFreePeriodPerDay | int | YES | TBC | 🔴 |

| MaxFreePeriodPerWeek | int | YES | TBC | 🔴 |

| PeriodPerDay | bigint | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


### Inventory (15 tables)


#### 🔴 IPurchaseRequest (16 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| ApprovalStatus | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| PurchaseRequestDate | datetime | YES | TBC | 🔴 |

| PurchaseStatus | nvarchar | YES | TBC | 🔴 |

| ReferenceNo | nvarchar | YES | TBC | 🔴 |

| RequestedBy | bigint | YES | TBC | 🔴 |

| SupplierID | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 InventoryCategory_Master (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🟡 InventoryItem_Master (22 columns) — [PARTIAL]


**Purpose:** Inventory items. Has StockInHand, ItemStatus ('Active'/'Inactive'). Does NOT have 'MinStockLevel' (the model hallucinated it — the low-stock indicator is unknown).


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | nvarchar | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | nvarchar | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| DeliveredBy | nvarchar | YES | TBC | 🔴 |

| DeliveredBy_ID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| ItemCategory_ID | bigint | YES | TBC | 🔴 |

| ItemCode | nvarchar | YES | TBC | 🔴 |

| ItemName | nvarchar | YES | TBC | 🔴 |

| ItemStatus | nvarchar | YES | TBC | 🔴 |

| StockInHand | bigint | YES | TBC | 🔴 |

| SupplierID | bigint | YES | TBC | 🔴 |

| UOMID | bigint | YES | TBC | 🔴 |

| Updated_By | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Vendor_ID | bigint | YES | TBC | 🔴 |

| Vendor_Name | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 InventorySupplierMaster (26 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Address | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CSTNumber | nvarchar | YES | TBC | 🔴 |

| CityID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| CountryID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| EmailId | nvarchar | YES | TBC | 🔴 |

| FaxNo | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| MobileNo | nvarchar | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| PhoneNo | nvarchar | YES | TBC | 🔴 |

| Pincode | bigint | YES | TBC | 🔴 |

| ServiceTaxNo | nvarchar | YES | TBC | 🔴 |

| StateID | bigint | YES | TBC | 🔴 |

| SupplierType_ID | bigint | YES | TBC | 🔴 |

| TINNo | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Website | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 InventorySupplierType_Master (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 ItemIssueEntry (26 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdmissionNo | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IssuedBy | bigint | YES | TBC | 🔴 |

| IssuedOn | datetime | YES | TBC | 🔴 |

| ItemIssuedStatus | bigint | YES | TBC | 🔴 |

| ItemRequestID | bigint | YES | TBC | 🔴 |

| ReferenceNo | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| RequestReferenceNo | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| StaffCode | nvarchar | YES | TBC | 🔴 |

| StaffID | bigint | YES | TBC | 🔴 |

| StaffName | nvarchar | YES | TBC | 🔴 |

| StaffType_ID | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| TypeFlag | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 ItemIssueEntry_Details (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| DeliveredBy | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IssuedItemID | bigint | YES | TBC | 🔴 |

| IssuedQuantity | bigint | YES | TBC | 🔴 |

| ItemID | bigint | YES | TBC | 🔴 |

| ItemName | nvarchar | YES | TBC | 🔴 |

| RequestedQuantity | bigint | YES | TBC | 🔴 |

| UOMName | nvarchar | YES | TBC | 🔴 |

| Variant | numeric | YES | TBC | 🔴 |



---


#### 🔴 ItemMaster_Data_Import (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| DeliveredBy | nvarchar | YES | TBC | 🔴 |

| ID | numeric | NO | TBC | 🔴 |

| ItemCategory | nvarchar | YES | TBC | 🔴 |

| ItemCode | nvarchar | YES | TBC | 🔴 |

| ItemName | nvarchar | YES | TBC | 🔴 |

| ItemStatus | nvarchar | YES | TBC | 🔴 |

| UOM | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 ItemRequestEntry (25 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdmissionNo | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| ItemRequestStatus | nvarchar | YES | TBC | 🔴 |

| ReferenceNo | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| RequestedBy | bigint | YES | TBC | 🔴 |

| RequestedOn | datetime | YES | TBC | 🔴 |

| SaveFlag | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| StaffCode | nvarchar | YES | TBC | 🔴 |

| StaffID | bigint | YES | TBC | 🔴 |

| StaffName | nvarchar | YES | TBC | 🔴 |

| StaffType_ID | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| Test | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 ItemRequestEntry_Details (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | NO | TBC | 🔴 |

| IssuedQuantity | bigint | YES | TBC | 🔴 |

| ItemCode | nvarchar | YES | TBC | 🔴 |

| ItemID | bigint | YES | TBC | 🔴 |

| ItemName | nvarchar | NO | TBC | 🔴 |

| RequestItemID | bigint | NO | TBC | 🔴 |

| RequestedQuantity | bigint | NO | TBC | 🔴 |

| UOMName | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 OpeningStock (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearId | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| ItemId | bigint | YES | TBC | 🔴 |

| Opening_Stock | bigint | YES | TBC | 🔴 |

| StockAdjusmentHeaderId | bigint | YES | TBC | 🔴 |



---


#### 🗑️ PurchaseRequest (22 columns) — [DEPRECATED]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**🗑️ Deprecated:** Use IPurchaseRequest (deprecated — has misspelled 'ApprovaStatus')


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| ApprovaStatus | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Department | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Item | bigint | YES | TBC | 🔴 |

| Product | nvarchar | YES | TBC | 🔴 |

| PurchaseDate | datetime | YES | TBC | 🔴 |

| PurchaseStatus | nvarchar | YES | TBC | 🔴 |

| Quantity | bigint | YES | TBC | 🔴 |

| Reasonforpurchase | nvarchar | YES | TBC | 🔴 |

| ReferenceNo | nvarchar | YES | TBC | 🔴 |

| RequestedBy | nvarchar | YES | TBC | 🔴 |

| Role | nvarchar | YES | TBC | 🔴 |

| SupplierofChoice | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 Purchase_Item_Details (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IssuedQuantity | bigint | YES | TBC | 🔴 |

| ItemCode | nvarchar | YES | TBC | 🔴 |

| ItemID | bigint | YES | TBC | 🔴 |

| ItemName | nvarchar | YES | TBC | 🔴 |

| OrderedQuantity | bigint | YES | TBC | 🔴 |

| Product_ItemID | bigint | YES | TBC | 🔴 |

| UOMName | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 StockAdjustmentDetails (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| CurrentStock | bigint | YES | TBC | 🔴 |

| Difference | bigint | YES | TBC | 🔴 |

| HeaderId | bigint | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| ItemId | bigint | YES | TBC | 🔴 |

| PhysicalStock | bigint | YES | TBC | 🔴 |



---


#### 🔴 StockAdjustmentHeader (9 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearId | bigint | YES | TBC | 🔴 |

| BranchId | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| ReferenceNo | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


### Admissions (14 tables)


#### 🔴 AdmissionCategoryMaster (15 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdmissionPriorityID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Status | bit | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 AdmissionPriorityMaster (14 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Status | bit | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 AdmissionType_Master (14 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Percentage | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🟡 ApplicationEntry (257 columns) — [PARTIAL]


**Purpose:** Admission applications. Has ApplicationStatus_ID → ApplicationStatus_Master. Has 257 columns (very wide).


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| APAARID | nvarchar | YES | TBC | 🔴 |

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdhaarCardNo | nvarchar | YES | TBC | 🔴 |

| AdmissionCategoryID | bigint | YES | TBC | 🔴 |

| AdmissionDate | date | YES | TBC | 🔴 |

| AdmissionNo | nvarchar | YES | TBC | 🔴 |

| AdmissionPriorityID | bigint | YES | TBC | 🔴 |

| AdmissionType_ID | bigint | YES | TBC | 🔴 |

| AdmissionType_Name | nvarchar | YES | TBC | 🔴 |

| AdmissionWaiverOptionId | bigint | YES | TBC | 🔴 |

| AdmissionWaiverOptionName | nvarchar | YES | TBC | 🔴 |

| AgeAsOn | nvarchar | YES | TBC | 🔴 |

| ApplicationDate | date | YES | TBC | 🔴 |

| ApplicationNo | nvarchar | YES | TBC | 🔴 |

| ApplicationRefNo | nvarchar | YES | TBC | 🔴 |

| ApplicationStatus_ID | bigint | YES | TBC | 🔴 |

| Block_ID | bigint | YES | TBC | 🔴 |

| Block_Name | nvarchar | YES | TBC | 🔴 |

| BloodGroupID | bigint | YES | TBC | 🔴 |

| BloodGroupName | nvarchar | YES | TBC | 🔴 |

| BoardingPoint_ID | bigint | YES | TBC | 🔴 |

| BoardingPoint_Name | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CasteID | bigint | YES | TBC | 🔴 |

| ChildBornOrder | int | YES | TBC | 🔴 |

| ClassName | nvarchar | YES | TBC | 🔴 |

| ComAddress | nvarchar | YES | TBC | 🔴 |

| ComCity | nvarchar | YES | TBC | 🔴 |

| ComCity_ID | bigint | YES | TBC | 🔴 |

| ComCountry | nvarchar | YES | TBC | 🔴 |

| ComCountry_ID | bigint | YES | TBC | 🔴 |

| ComDistrictId | bigint | YES | TBC | 🔴 |

| ComDistrictName | nvarchar | YES | TBC | 🔴 |

| ComEmail | nvarchar | YES | TBC | 🔴 |

| ComMobile | nvarchar | YES | TBC | 🔴 |

| ComPhone | nvarchar | YES | TBC | 🔴 |

| ComPincode | nvarchar | YES | TBC | 🔴 |

| ComPlace | nvarchar | YES | TBC | 🔴 |

| ComState | nvarchar | YES | TBC | 🔴 |

| ComState_ID | bigint | YES | TBC | 🔴 |

| ComTaluk | nvarchar | YES | TBC | 🔴 |

| ComVillage | nvarchar | YES | TBC | 🔴 |

| CombinedSubjects | nvarchar | YES | TBC | 🔴 |

| CommunicationMailID | nvarchar | YES | TBC | 🔴 |

| CommunicationMobileNo | nvarchar | YES | TBC | 🔴 |

| CommunicationeMailID | nvarchar | YES | TBC | 🔴 |

| Community_ID | bigint | YES | TBC | 🔴 |

| Community_Name | nvarchar | YES | TBC | 🔴 |

| ConveyanceMode | nvarchar | YES | TBC | 🔴 |

| ConveyanceModeId | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| CurrentLevelID | bigint | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| EMISNo | nvarchar | YES | TBC | 🔴 |

| EmergencyContactPerson | nvarchar | YES | TBC | 🔴 |

| EmergencyContactPersonEmail | nvarchar | YES | TBC | 🔴 |

| EmergencyContactPersonMobileNo | nvarchar | YES | TBC | 🔴 |

| EmergencyContactPersonName | nvarchar | YES | TBC | 🔴 |

| EnquiryNo | nvarchar | YES | TBC | 🔴 |

| EnrollmentNo | nvarchar | YES | TBC | 🔴 |

| ExistingStudent | nvarchar | YES | TBC | 🔴 |

| ExpecedJoiningDate | date | YES | TBC | 🔴 |

| ExtraCurricularActivity | nvarchar | YES | TBC | 🔴 |

| FatherAdhaarCardNo | nvarchar | YES | TBC | 🔴 |

| FatherAge | int | YES | TBC | 🔴 |

| FatherAnnualIncome | nvarchar | YES | TBC | 🔴 |

| FatherContactNo | nvarchar | YES | TBC | 🔴 |

| FatherDesignation | nvarchar | YES | TBC | 🔴 |

| FatherDesignationLevel | nvarchar | YES | TBC | 🔴 |

| FatherDob | date | YES | TBC | 🔴 |

| FatherEducation | nvarchar | YES | TBC | 🔴 |

| FatherEmail | nvarchar | YES | TBC | 🔴 |

| FatherEmploymentPassNo | nvarchar | YES | TBC | 🔴 |

| FatherEmploymentPassNoExpiryDate | date | YES | TBC | 🔴 |

| FatherEmploymentStatus | nvarchar | YES | TBC | 🔴 |

| FatherEmploymentStatusExpiryDate | date | YES | TBC | 🔴 |

| FatherEmploymentStatusID | bigint | YES | TBC | 🔴 |

| FatherHome_PhoneNo | nvarchar | YES | TBC | 🔴 |

| FatherImg | nvarchar | YES | TBC | 🔴 |

| FatherLastName | nvarchar | YES | TBC | 🔴 |

| FatherName | nvarchar | YES | TBC | 🔴 |

| FatherNameInRegionalLanguage | nvarchar | YES | TBC | 🔴 |

| FatherNationality | nvarchar | YES | TBC | 🔴 |

| FatherNatureOfBusiness | nvarchar | YES | TBC | 🔴 |

| FatherOccupation | nvarchar | YES | TBC | 🔴 |

| FatherOfficeAddress | nvarchar | YES | TBC | 🔴 |

| FatherOrganization | nvarchar | YES | TBC | 🔴 |

| FatherPassportNo | nvarchar | YES | TBC | 🔴 |

| FatherSchoolAlumni | nvarchar | YES | TBC | 🔴 |

| FatherTitleName | nvarchar | YES | TBC | 🔴 |

| FatherWork_PhoneNo | nvarchar | YES | TBC | 🔴 |

| FirstName | nvarchar | YES | TBC | 🔴 |

| FoodRequired | bit | YES | TBC | 🔴 |

| Gender | nvarchar | YES | TBC | 🔴 |

| GuardianAdhaarCardNo | nvarchar | YES | TBC | 🔴 |

| GuardianAge | int | YES | TBC | 🔴 |

| GuardianAnnualIncome | nvarchar | YES | TBC | 🔴 |

| GuardianContactNo | nvarchar | YES | TBC | 🔴 |

| GuardianDesignation | nvarchar | YES | TBC | 🔴 |

| GuardianDesignationLevel | nvarchar | YES | TBC | 🔴 |

| GuardianDob | date | YES | TBC | 🔴 |

| GuardianEducation | nvarchar | YES | TBC | 🔴 |

| GuardianEmail | nvarchar | YES | TBC | 🔴 |

| GuardianEmploymentPassNo | nvarchar | YES | TBC | 🔴 |

| GuardianEmploymentPassNoExpiryDate | date | YES | TBC | 🔴 |

| GuardianEmploymentStatus | nvarchar | YES | TBC | 🔴 |

| GuardianEmploymentStatusExpiryDate | date | YES | TBC | 🔴 |

| GuardianEmploymentStatusID | bigint | YES | TBC | 🔴 |

| GuardianHome_PhoneNo | nvarchar | YES | TBC | 🔴 |

| GuardianImg | nvarchar | YES | TBC | 🔴 |

| GuardianLastName | nvarchar | YES | TBC | 🔴 |

| GuardianName | nvarchar | YES | TBC | 🔴 |

| GuardianNationality | nvarchar | YES | TBC | 🔴 |

| GuardianNatureOfBusiness | nvarchar | YES | TBC | 🔴 |

| GuardianOccupation | nvarchar | YES | TBC | 🔴 |

| GuardianOfficeAddress | nvarchar | YES | TBC | 🔴 |

| GuardianOrganization | nvarchar | YES | TBC | 🔴 |

| GuardianPassportNo | nvarchar | YES | TBC | 🔴 |

| GuardianSchoolAlumni | nvarchar | YES | TBC | 🔴 |

| GuardianTitleName | nvarchar | YES | TBC | 🔴 |

| GuardianWork_PhoneNo | nvarchar | YES | TBC | 🔴 |

| Guardian_Relationshipwithstudent | nvarchar | YES | TBC | 🔴 |

| HandledBy_ID | bigint | YES | TBC | 🔴 |

| HostelRequired | bit | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IdentificationMarks | nvarchar | YES | TBC | 🔴 |

| IdentificationMarks_2 | nvarchar | YES | TBC | 🔴 |

| InterViewRemarks | nvarchar | YES | TBC | 🔴 |

| InterviewDate | datetime | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IsFatherJobTransferrable | bit | YES | TBC | 🔴 |

| IsFatherSchoolAlumni | bit | YES | TBC | 🔴 |

| IsGuardianJobTransferrable | bit | YES | TBC | 🔴 |

| IsGuardianSchoolAlumni | bit | YES | TBC | 🔴 |

| IsMotherJobTransferrable | bit | YES | TBC | 🔴 |

| IsMotherSchoolAlumni | bit | YES | TBC | 🔴 |

| IsNEETJEE | bit | YES | TBC | 🔴 |

| IsOldStudent | bit | YES | TBC | 🔴 |

| IsOrphanOrAdopted | bit | YES | TBC | 🔴 |

| IsVIP | bit | YES | TBC | 🔴 |

| LastName | nvarchar | YES | TBC | 🔴 |

| MiddleName | nvarchar | YES | TBC | 🔴 |

| MotherAdhaarCardNo | nvarchar | YES | TBC | 🔴 |

| MotherAge | int | YES | TBC | 🔴 |

| MotherAnnualIncome | nvarchar | YES | TBC | 🔴 |

| MotherContactNo | nvarchar | YES | TBC | 🔴 |

| MotherDesignation | nvarchar | YES | TBC | 🔴 |

| MotherDesignationLevel | nvarchar | YES | TBC | 🔴 |

| MotherDob | date | YES | TBC | 🔴 |

| MotherEducation | nvarchar | YES | TBC | 🔴 |

| MotherEmail | nvarchar | YES | TBC | 🔴 |

| MotherEmploymentPassNo | nvarchar | YES | TBC | 🔴 |

| MotherEmploymentPassNoExpiryDate | date | YES | TBC | 🔴 |

| MotherEmploymentStatus | nvarchar | YES | TBC | 🔴 |

| MotherEmploymentStatusExpiryDate | date | YES | TBC | 🔴 |

| MotherEmploymentStatusID | bigint | YES | TBC | 🔴 |

| MotherHome_PhoneNo | nvarchar | YES | TBC | 🔴 |

| MotherImg | nvarchar | YES | TBC | 🔴 |

| MotherLastName | nvarchar | YES | TBC | 🔴 |

| MotherName | nvarchar | YES | TBC | 🔴 |

| MotherNameInRegionalLanguage | nvarchar | YES | TBC | 🔴 |

| MotherNationality | nvarchar | YES | TBC | 🔴 |

| MotherNatureOfBusiness | nvarchar | YES | TBC | 🔴 |

| MotherOccupation | nvarchar | YES | TBC | 🔴 |

| MotherOfficeAddress | nvarchar | YES | TBC | 🔴 |

| MotherOrganization | nvarchar | YES | TBC | 🔴 |

| MotherPassportNo | nvarchar | YES | TBC | 🔴 |

| MotherSchoolAlumni | nvarchar | YES | TBC | 🔴 |

| MotherTitleName | nvarchar | YES | TBC | 🔴 |

| MotherTongue_ID | bigint | YES | TBC | 🔴 |

| MotherTongue_Name | nvarchar | YES | TBC | 🔴 |

| MotherWork_PhoneNo | nvarchar | YES | TBC | 🔴 |

| Nationality_ID | bigint | YES | TBC | 🔴 |

| Nationality_Name | nvarchar | YES | TBC | 🔴 |

| NeetCount | nvarchar | YES | TBC | 🔴 |

| NeetMarks | nvarchar | YES | TBC | 🔴 |

| OldStudentId | bigint | YES | TBC | 🔴 |

| OtherExam | varchar | YES | TBC | 🔴 |

| OtherExamName | varchar | YES | TBC | 🔴 |

| PENNumber | nvarchar | YES | TBC | 🔴 |

| ParentWeddingDate | date | YES | TBC | 🔴 |

| PaymentTypeId | int | YES | TBC | 🔴 |

| PerAddress | nvarchar | YES | TBC | 🔴 |

| PerCity | nvarchar | YES | TBC | 🔴 |

| PerCity_ID | bigint | YES | TBC | 🔴 |

| PerCountry | nvarchar | YES | TBC | 🔴 |

| PerCountry_ID | bigint | YES | TBC | 🔴 |

| PerDistrictId | bigint | YES | TBC | 🔴 |

| PerDistrictName | nvarchar | YES | TBC | 🔴 |

| PerEmail | nvarchar | YES | TBC | 🔴 |

| PerMobile | nvarchar | YES | TBC | 🔴 |

| PerPhone | nvarchar | YES | TBC | 🔴 |

| PerPincode | nvarchar | YES | TBC | 🔴 |

| PerState | nvarchar | YES | TBC | 🔴 |

| PerState_ID | bigint | YES | TBC | 🔴 |

| PerTaluk | nvarchar | YES | TBC | 🔴 |

| PerVillage | nvarchar | YES | TBC | 🔴 |

| PhysicalDefects | nvarchar | YES | TBC | 🔴 |

| Picked_Up_By | nvarchar | YES | TBC | 🔴 |

| PlaceOfBirth | nvarchar | YES | TBC | 🔴 |

| PreferLangOne_ID | bigint | YES | TBC | 🔴 |

| PreferLangOne_Name | nvarchar | YES | TBC | 🔴 |

| PreferLangTwo_ID | bigint | YES | TBC | 🔴 |

| PreferLangTwo_Name | nvarchar | YES | TBC | 🔴 |

| PrimaryMobileNo | nvarchar | YES | TBC | 🔴 |

| ReferenceDetails | nvarchar | YES | TBC | 🔴 |

| ReferenceLetter | nvarchar | YES | TBC | 🔴 |

| Religion_ID | bigint | YES | TBC | 🔴 |

| Religion_Name | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| Residence | nvarchar | YES | TBC | 🔴 |

| Room_ID | bigint | YES | TBC | 🔴 |

| Room_Name | nvarchar | YES | TBC | 🔴 |

| Route_ID | bigint | YES | TBC | 🔴 |

| Route_Name | nvarchar | YES | TBC | 🔴 |

| SATSNo | nvarchar | YES | TBC | 🔴 |

| SameAddress | bit | YES | TBC | 🔴 |

| SchoolDistance | nvarchar | YES | TBC | 🔴 |

| School_ID | bigint | YES | TBC | 🔴 |

| SearchImportedRecord | nvarchar | YES | TBC | 🔴 |

| SecondaryMobileNo | nvarchar | YES | TBC | 🔴 |

| SectionName | nvarchar | YES | TBC | 🔴 |

| SeriousIllness | nvarchar | YES | TBC | 🔴 |

| SiblingStudyingInSchool | nvarchar | YES | TBC | 🔴 |

| SingleParent | nvarchar | YES | TBC | 🔴 |

| SingleParentId | bigint | YES | TBC | 🔴 |

| SpecialNeeds | bit | YES | TBC | 🔴 |

| StaffChild | int | YES | TBC | 🔴 |

| StaffName | nvarchar | YES | TBC | 🔴 |

| StayWithParent | bit | YES | TBC | 🔴 |

| Stream | nvarchar | YES | TBC | 🔴 |

| StreamID | int | YES | TBC | 🔴 |

| StudentAge | nvarchar | YES | TBC | 🔴 |

| StudentCode | nvarchar | YES | TBC | 🔴 |

| StudentDob | date | YES | TBC | 🔴 |

| StudentFeeCategoryID | bigint | YES | TBC | 🔴 |

| StudentFeeSubCategoryID | bigint | YES | TBC | 🔴 |

| StudentIdentificationNo | nvarchar | YES | TBC | 🔴 |

| StudentImg | nvarchar | YES | TBC | 🔴 |

| StudentImmigrationStatus | nvarchar | YES | TBC | 🔴 |

| StudentImmigrationStatusID | bigint | YES | TBC | 🔴 |

| StudentMobileNo | nvarchar | YES | TBC | 🔴 |

| StudentNameInRegionalLanguage | nvarchar | YES | TBC | 🔴 |

| StudentPassportExpiryDate | date | YES | TBC | 🔴 |

| StudentPassportNo | nvarchar | YES | TBC | 🔴 |

| Student_ClassID | bigint | YES | TBC | 🔴 |

| SubCaste | nvarchar | YES | TBC | 🔴 |

| SubjectCombinations | nvarchar | YES | TBC | 🔴 |

| SubjectCombinationsID | bigint | YES | TBC | 🔴 |

| ToiletTrained | bit | YES | TBC | 🔴 |

| TransportRequired | bit | YES | TBC | 🔴 |

| UnitNo | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Vacinnated | bit | YES | TBC | 🔴 |



---


#### 🟡 ApplicationStatus_Master (13 columns) — [PARTIAL]


**Purpose:** Application status lookup (e.g. 'Admitted', 'Pending', 'Rejected').


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 Application_Data_Import (139 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdhaarCardNo | nvarchar | YES | TBC | 🔴 |

| AdmissionCategoryName | nvarchar | YES | TBC | 🔴 |

| AdmissionCategory_ID | bigint | YES | TBC | 🔴 |

| AdmissionDate | datetime | YES | TBC | 🔴 |

| AdmissionNo | nvarchar | YES | TBC | 🔴 |

| AdmissionPriorityName | nvarchar | YES | TBC | 🔴 |

| AdmissionPriority_ID | bigint | YES | TBC | 🔴 |

| AdmissionType_ID | bigint | YES | TBC | 🔴 |

| AdmissionType_Name | nvarchar | YES | TBC | 🔴 |

| AdmissionWaiverOptionName | nvarchar | YES | TBC | 🔴 |

| ApplicationDate | datetime | YES | TBC | 🔴 |

| ApplicationNo | nvarchar | YES | TBC | 🔴 |

| ApplicationRefNo | nvarchar | YES | TBC | 🔴 |

| ApplicationStatus_ID | bigint | YES | TBC | 🔴 |

| ApplicationStatus_Name | nvarchar | YES | TBC | 🔴 |

| BloodGroupID | bigint | YES | TBC | 🔴 |

| BloodGroupName | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CasteID | bigint | YES | TBC | 🔴 |

| CasteName | nvarchar | YES | TBC | 🔴 |

| ClassName | nvarchar | YES | TBC | 🔴 |

| ComAddress | nvarchar | YES | TBC | 🔴 |

| ComCity | nvarchar | YES | TBC | 🔴 |

| ComCity_ID | bigint | YES | TBC | 🔴 |

| ComCountry | nvarchar | YES | TBC | 🔴 |

| ComCountry_ID | bigint | YES | TBC | 🔴 |

| ComEmail | nvarchar | YES | TBC | 🔴 |

| ComMobile | nvarchar | YES | TBC | 🔴 |

| ComPhone | nvarchar | YES | TBC | 🔴 |

| ComPincode | nvarchar | YES | TBC | 🔴 |

| ComState | nvarchar | YES | TBC | 🔴 |

| ComState_ID | bigint | YES | TBC | 🔴 |

| CombinedSubjects | nvarchar | YES | TBC | 🔴 |

| CommunicationMobileNo | nvarchar | YES | TBC | 🔴 |

| CommunicationeMailID | nvarchar | YES | TBC | 🔴 |

| Community_ID | bigint | YES | TBC | 🔴 |

| Community_Name | nvarchar | YES | TBC | 🔴 |

| ConveyanceMode | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| EMISNo | nvarchar | YES | TBC | 🔴 |

| EnquiryNo | nvarchar | YES | TBC | 🔴 |

| EnrollmentNo | nvarchar | YES | TBC | 🔴 |

| ExistingStudent | nvarchar | YES | TBC | 🔴 |

| ExpecedJoiningDate | datetime | YES | TBC | 🔴 |

| FatherAge | int | YES | TBC | 🔴 |

| FatherAnnualIncome | nvarchar | YES | TBC | 🔴 |

| FatherContactNo | nvarchar | YES | TBC | 🔴 |

| FatherDob | datetime | YES | TBC | 🔴 |

| FatherEducation | nvarchar | YES | TBC | 🔴 |

| FatherEmail | nvarchar | YES | TBC | 🔴 |

| FatherName | nvarchar | YES | TBC | 🔴 |

| FatherNameInRegionalLanguage | nvarchar | YES | TBC | 🔴 |

| FatherOccupation | nvarchar | YES | TBC | 🔴 |

| FatherOrganization | nvarchar | YES | TBC | 🔴 |

| FirstName | nvarchar | YES | TBC | 🔴 |

| Gender | nvarchar | YES | TBC | 🔴 |

| GuardianAge | int | YES | TBC | 🔴 |

| GuardianAnnualIncome | nvarchar | YES | TBC | 🔴 |

| GuardianContactNo | nvarchar | YES | TBC | 🔴 |

| GuardianDob | datetime | YES | TBC | 🔴 |

| GuardianEducation | nvarchar | YES | TBC | 🔴 |

| GuardianEmail | nvarchar | YES | TBC | 🔴 |

| GuardianName | nvarchar | YES | TBC | 🔴 |

| GuardianOccupation | nvarchar | YES | TBC | 🔴 |

| GuardianOrganization | nvarchar | YES | TBC | 🔴 |

| HostelRequired | bit | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IdentificationMarks | nvarchar | YES | TBC | 🔴 |

| IdentificationMarks_2 | nvarchar | YES | TBC | 🔴 |

| InterViewRemarks | nvarchar | YES | TBC | 🔴 |

| InterviewDate | datetime | YES | TBC | 🔴 |

| IsNEETJEE | bit | YES | TBC | 🔴 |

| IsOldStudent | bit | YES | TBC | 🔴 |

| IsVIP | bit | YES | TBC | 🔴 |

| LastName | nvarchar | YES | TBC | 🔴 |

| MiddleName | nvarchar | YES | TBC | 🔴 |

| MotherAge | int | YES | TBC | 🔴 |

| MotherAnnualIncome | nvarchar | YES | TBC | 🔴 |

| MotherContactNo | nvarchar | YES | TBC | 🔴 |

| MotherDob | datetime | YES | TBC | 🔴 |

| MotherEducation | nvarchar | YES | TBC | 🔴 |

| MotherEmail | nvarchar | YES | TBC | 🔴 |

| MotherName | nvarchar | YES | TBC | 🔴 |

| MotherNameInRegionalLanguage | nvarchar | YES | TBC | 🔴 |

| MotherOccupation | nvarchar | YES | TBC | 🔴 |

| MotherOrganization | nvarchar | YES | TBC | 🔴 |

| MotherTongue_ID | bigint | YES | TBC | 🔴 |

| MotherTongue_Name | nvarchar | YES | TBC | 🔴 |

| Nationality_ID | bigint | YES | TBC | 🔴 |

| Nationality_Name | nvarchar | YES | TBC | 🔴 |

| NeetCount | nvarchar | YES | TBC | 🔴 |

| NeetMarks | nvarchar | YES | TBC | 🔴 |

| OtherExam | nvarchar | YES | TBC | 🔴 |

| OtherExamName | nvarchar | YES | TBC | 🔴 |

| PerAddress | nvarchar | YES | TBC | 🔴 |

| PerCity | nvarchar | YES | TBC | 🔴 |

| PerCity_ID | bigint | YES | TBC | 🔴 |

| PerCountry | nvarchar | YES | TBC | 🔴 |

| PerCountry_ID | bigint | YES | TBC | 🔴 |

| PerEmail | nvarchar | YES | TBC | 🔴 |

| PerMobile | nvarchar | YES | TBC | 🔴 |

| PerPhone | nvarchar | YES | TBC | 🔴 |

| PerPincode | nvarchar | YES | TBC | 🔴 |

| PerState | nvarchar | YES | TBC | 🔴 |

| PerState_ID | bigint | YES | TBC | 🔴 |

| PhysicalDefects | nvarchar | YES | TBC | 🔴 |

| PreferLangOne_ID | bigint | YES | TBC | 🔴 |

| PreferLangOne_Name | nvarchar | YES | TBC | 🔴 |

| PreferLangTwo_ID | bigint | YES | TBC | 🔴 |

| PreferLangTwo_Name | nvarchar | YES | TBC | 🔴 |

| Religion_ID | bigint | YES | TBC | 🔴 |

| Religion_Name | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| SameAddress | bit | YES | TBC | 🔴 |

| SchoolDistance | nvarchar | YES | TBC | 🔴 |

| SectionName | nvarchar | YES | TBC | 🔴 |

| SeriousIllness | nvarchar | YES | TBC | 🔴 |

| SingleParent | nvarchar | YES | TBC | 🔴 |

| SpecialNeeds | bit | YES | TBC | 🔴 |

| StaffChild | int | YES | TBC | 🔴 |

| StaffName | nvarchar | YES | TBC | 🔴 |

| Stream | nvarchar | YES | TBC | 🔴 |

| StudentAge | nvarchar | YES | TBC | 🔴 |

| StudentCode | nvarchar | YES | TBC | 🔴 |

| StudentDob | datetime | YES | TBC | 🔴 |

| StudentFeeCategory_ID | bigint | YES | TBC | 🔴 |

| StudentFeeCategory_Name | nvarchar | YES | TBC | 🔴 |

| StudentFeeSUBCategory_ID | bigint | YES | TBC | 🔴 |

| StudentFeeSUBCategory_Name | nvarchar | YES | TBC | 🔴 |

| StudentImg | nvarchar | YES | TBC | 🔴 |

| StudentImgPath | nvarchar | YES | TBC | 🔴 |

| StudentNameInRegionalLanguage | nvarchar | YES | TBC | 🔴 |

| Student_ClassID | bigint | YES | TBC | 🔴 |

| SubjectCombinations | nvarchar | YES | TBC | 🔴 |

| ToiletTrained | bit | YES | TBC | 🔴 |

| TransportRequired | bit | YES | TBC | 🔴 |

| Vacinnated | bit | YES | TBC | 🔴 |



---


#### 🔴 CallRegister (34 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CallCategory_ID | bigint | YES | TBC | 🔴 |

| CallDate | datetime | YES | TBC | 🔴 |

| CallDescription | nvarchar | YES | TBC | 🔴 |

| CallPurpose_ID | bigint | YES | TBC | 🔴 |

| CallRefNo | nvarchar | YES | TBC | 🔴 |

| CallStatus | int | YES | TBC | 🔴 |

| CallStatus_ID | bigint | YES | TBC | 🔴 |

| Class_ID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| HandledBy_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Mode_ID | bigint | YES | TBC | 🔴 |

| MovetoEnquiry | bit | YES | TBC | 🔴 |

| Next_FollowupDate | date | YES | TBC | 🔴 |

| Others_Email | nvarchar | YES | TBC | 🔴 |

| Others_Name | nvarchar | YES | TBC | 🔴 |

| Others_Phone | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| Section_ID | bigint | YES | TBC | 🔴 |

| StaffCode | nvarchar | YES | TBC | 🔴 |

| StaffType_ID | bigint | YES | TBC | 🔴 |

| Staff_ID | bigint | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |

| Vendor_Email | nvarchar | YES | TBC | 🔴 |

| Vendor_Name | nvarchar | YES | TBC | 🔴 |

| Vendor_Phone | nvarchar | YES | TBC | 🔴 |



---


#### 🗑️ EnquiryMaster (36 columns) — [DEPRECATED]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**🗑️ Deprecated:** Use GeneralCallRegister (deprecated — zero live SP usage)


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYear | bigint | YES | TBC | 🔴 |

| Address | nvarchar | YES | TBC | 🔴 |

| AdmissionEligibility | bigint | YES | TBC | 🔴 |

| ApplicationIssue | bigint | YES | TBC | 🔴 |

| Area | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| City | nvarchar | YES | TBC | 🔴 |

| Class_Id | bigint | YES | TBC | 🔴 |

| Code | nvarchar | YES | TBC | 🔴 |

| Country | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Email | nvarchar | YES | TBC | 🔴 |

| EnquiryDate | datetime | YES | TBC | 🔴 |

| EnquiryMode | nvarchar | YES | TBC | 🔴 |

| EnquirySource_Id | bigint | YES | TBC | 🔴 |

| EnquirySource_RefName | nvarchar | YES | TBC | 🔴 |

| EnquiryStatus_Id | bigint | YES | TBC | 🔴 |

| Gender | nvarchar | YES | TBC | 🔴 |

| HandledBy_Id | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| ParentName | nvarchar | YES | TBC | 🔴 |

| Phone1 | nvarchar | YES | TBC | 🔴 |

| Phone2 | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| School_Id | bigint | YES | TBC | 🔴 |

| SeatsAvailable | nvarchar | YES | TBC | 🔴 |

| State | nvarchar | YES | TBC | 🔴 |

| StudentAge | int | YES | TBC | 🔴 |

| StudentDOB | datetime | YES | TBC | 🔴 |

| StudentName | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 EnquirySourceMaster (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 Enquiry_Activity (9 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Enquiry_Id | bigint | YES | TBC | 🔴 |

| FollowedBy_Id | bigint | YES | TBC | 🔴 |

| Followup_Date | date | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| Next_Followup_Date | date | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| Status_Id | bigint | YES | TBC | 🔴 |



---


#### 🔴 Enquiry_Mode_Master (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 Enquiry_Status_Master (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### ✅ GeneralCallRegister (44 columns) — [CONFIRMED]


**Purpose:** Enquiry records — LIVE table (EnquiryMaster is deprecated). Has CallDate, EnquirySource, EnquiryStatus.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Address | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CallCategory_ID | bigint | YES | TBC | 🔴 |

| CallDate | datetime | YES | TBC | 🔴 |

| CallDescription | nvarchar | YES | TBC | 🔴 |

| CallRefNo | nvarchar | YES | TBC | 🔴 |

| CallStatus | int | YES | TBC | 🔴 |

| CallStatus_ID | bigint | YES | TBC | 🔴 |

| Class_ID | bigint | YES | TBC | 🔴 |

| CommunicationEmail | nvarchar | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| DOB | date | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| FatherOfficeAddress | nvarchar | YES | TBC | 🔴 |

| GuardianOfficeAddress | nvarchar | YES | TBC | 🔴 |

| HandledBy_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| MobileNo1 | nvarchar | YES | TBC | 🔴 |

| MobileNo2 | nvarchar | YES | TBC | 🔴 |

| Mode_ID | bigint | YES | TBC | 🔴 |

| MotherOfficeAddress | nvarchar | YES | TBC | 🔴 |

| MovetoEnquiry | bit | YES | TBC | 🔴 |

| Next_FollowupDate | date | YES | TBC | 🔴 |

| Others_Email | nvarchar | YES | TBC | 🔴 |

| Others_Name | nvarchar | YES | TBC | 🔴 |

| Others_Phone | nvarchar | YES | TBC | 🔴 |

| Parent_Name | nvarchar | YES | TBC | 🔴 |

| SchoolName | nvarchar | YES | TBC | 🔴 |

| Section_ID | bigint | YES | TBC | 🔴 |

| SourceClass_ID | bigint | YES | TBC | 🔴 |

| StaffCode | nvarchar | YES | TBC | 🔴 |

| StaffType_ID | bigint | YES | TBC | 🔴 |

| Staff_ID | bigint | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |

| Student_Name | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |

| Vendor_Email | nvarchar | YES | TBC | 🔴 |

| Vendor_Name | nvarchar | YES | TBC | 🔴 |

| Vendor_Phone | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 NewCallRegister (31 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CallCategory_ID | bigint | YES | TBC | 🔴 |

| CallDate | datetime | YES | TBC | 🔴 |

| CallDescription | nvarchar | YES | TBC | 🔴 |

| CallPurpose_ID | bigint | YES | TBC | 🔴 |

| CallRefNo | nvarchar | YES | TBC | 🔴 |

| CallStatus | int | NO | TBC | 🔴 |

| CallStatus_ID | bigint | YES | TBC | 🔴 |

| CallType | int | NO | TBC | 🔴 |

| CallerEmail | nvarchar | YES | TBC | 🔴 |

| CallerEmailAlert | bit | YES | TBC | 🔴 |

| CallerName | nvarchar | YES | TBC | 🔴 |

| CallerPhone | nvarchar | YES | TBC | 🔴 |

| CallerSMSAlert | bit | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| FollowerEmailAlert | bit | YES | TBC | 🔴 |

| FollowerSMSAlert | bit | YES | TBC | 🔴 |

| HandledBy_ID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IsFollowup | bit | YES | TBC | 🔴 |

| Mode_ID | bigint | YES | TBC | 🔴 |

| Next_FollowupDate | date | YES | TBC | 🔴 |

| ReferenceName | nvarchar | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


### RBAC (13 tables)


#### 🔴 LoginUserDetails (8 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| CurrentYear | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IpAddress | nvarchar | YES | TBC | 🔴 |

| LoggedFrom | nvarchar | YES | TBC | 🔴 |

| UserName | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 ManagementAppScreens (19 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| CardField | nvarchar | YES | TBC | 🔴 |

| CardName | nvarchar | YES | TBC | 🔴 |

| CardOrder | int | YES | TBC | 🔴 |

| Filters | varchar | YES | TBC | 🔴 |

| HasFilter | bit | YES | TBC | 🔴 |

| HasSubPage | bit | YES | TBC | 🔴 |

| HasTable | bit | YES | TBC | 🔴 |

| Id | int | NO | TBC | 🔴 |

| PageId | int | YES | TBC | 🔴 |

| PageName | nvarchar | YES | TBC | 🔴 |

| PageOrder | int | YES | TBC | 🔴 |

| ShowCard | bit | YES | TBC | 🔴 |

| ShowPage | bit | YES | TBC | 🔴 |

| ShowSubPage | bit | YES | TBC | 🔴 |

| ShowTable | bit | YES | TBC | 🔴 |

| SubPageId | int | YES | TBC | 🔴 |

| SubPageName | nvarchar | YES | TBC | 🔴 |

| SubPageOrder | int | YES | TBC | 🔴 |

| TableName | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 PasswordRecovery (9 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicyearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| OTP | nvarchar | YES | TBC | 🔴 |

| OTPExpiryTime | datetime | YES | TBC | 🔴 |

| OTPStatus | varchar | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 PrivilegeMaster (2 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Id | bigint | NO | TBC | 🔴 |

| Privilege | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 Role_Privilege_Details (11 columns) — [PENDING]


**Purpose:** Role → screen privileges. The screen-level RBAC table.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Privilege | nvarchar | YES | TBC | 🔴 |

| Role_Id | bigint | YES | TBC | 🔴 |

| Screen_Id | bigint | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 ScreenMaster (6 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AnsappMenuId | int | YES | TBC | 🔴 |

| Icon | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| MenuText | nvarchar | YES | TBC | 🔴 |

| Menu_URL | nvarchar | YES | TBC | 🔴 |

| ParentId | bigint | YES | TBC | 🔴 |



---


#### 🔴 Screen_Keywords (3 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Id | bigint | NO | TBC | 🔴 |

| Keywords | nvarchar | YES | TBC | 🔴 |

| ScreenId | bigint | YES | TBC | 🔴 |



---


#### 🔴 Screen_Privilege_Details (3 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Id | bigint | NO | TBC | 🔴 |

| Privilege_Id | bigint | YES | TBC | 🔴 |

| Screen_Id | bigint | YES | TBC | 🔴 |



---


#### 🔴 ScreensAndGroups (4 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| GID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| MID | bigint | YES | TBC | 🔴 |

| SID | bigint | YES | TBC | 🔴 |



---


#### ✅ UserAccountMaster (30 columns) — [CONFIRMED]


**Purpose:** User accounts. Has Password/Token (sensitive — block). Has IsSuperUser (bypasses branch scoping).


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AcademicYearName | nvarchar | YES | TBC | 🔴 |

| AnsappMenus | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| BranchName | nvarchar | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | date | YES | TBC | 🔴 |

| Hostname | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsAnsappEnabled | bit | YES | TBC | 🔴 |

| IsBranchAdmin | bit | YES | TBC | 🔴 |

| IsClassTeacher | bit | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IsMgmtAppEnabled | bit | YES | TBC | 🔴 |

| IsSuperUser | bit | YES | TBC | 🔴 |

| IsSupportUser | bit | YES | TBC | 🔴 |

| LockTime | datetime | YES | TBC | 🔴 |

| LoginCount | int | YES | TBC | 🔴 |

| LoginStatus | int | YES | TBC | 🔴 |

| Mail | nvarchar | YES | TBC | 🔴 |

| MgmtAppMenus | nvarchar | YES | TBC | 🔴 |

| Password | nvarchar | YES | TBC | 🔴 |

| StaffID | bigint | YES | TBC | 🔴 |

| StaffName | nvarchar | YES | TBC | 🔴 |

| Status | nvarchar | YES | TBC | 🔴 |

| StatusID | bigint | YES | TBC | 🔴 |

| Token | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | date | YES | TBC | 🔴 |

| Username | nvarchar | YES | TBC | 🔴 |



---


#### ✅ UserAccountRoleDetails (6 columns) — [CONFIRMED]


**Purpose:** The core RBAC table. Links UserID → BranchID. The branch-scoping subquery reads from this.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| BranchID | bigint | YES | FK → BranchMaster.ID. The branch the user is authorized to access. | ✅ |

| ID | bigint | NO | TBC | 🔴 |

| IsPrimary | bit | YES | 1 = this is the user's primary branch/role. | ✅ |

| RoleID | bigint | YES | FK → UserAccountRoleMaster.ID. The user's role. | ✅ |

| StaffID | bigint | YES | FK → Staff_Master.Staff_ID. The staff member linked to this user account. | ✅ |

| UserID | bigint | YES | FK → UserAccountMaster.ID. The core RBAC link. | ✅ |



**Foreign keys:**

- UserID → UserAccountMaster.ID (CONFIRMED)


- BranchID → BranchMaster.ID (CONFIRMED)


- RoleID → UserAccountRoleMaster.ID (CONFIRMED)




---


#### 🔴 UserAccountRoleMaster (9 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | date | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | date | YES | TBC | 🔴 |



---


#### 🔴 UserActivityMaster (18 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AcademicYearName | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| BranchName | nvarchar | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| DateTime | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Logged_Off | datetime | YES | TBC | 🔴 |

| Logged_On | datetime | YES | TBC | 🔴 |

| Operation | nvarchar | YES | TBC | 🔴 |

| PersonID | bigint | YES | TBC | 🔴 |

| PersonName | nvarchar | YES | TBC | 🔴 |

| ScreenName | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| UsedFrom | nvarchar | YES | TBC | 🔴 |

| UserID | bigint | YES | TBC | 🔴 |

| UserTypeID | nvarchar | YES | TBC | 🔴 |

| Username | nvarchar | YES | TBC | 🔴 |



---


### Communication (11 tables)


#### 🔴 NotificationOptIn (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Action | nvarchar | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| ScreenID | bigint | YES | TBC | 🔴 |

| ScreenName | nvarchar | YES | TBC | 🔴 |

| Status | bit | NO | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🟡 SMSAuditTrail (11 columns) — [PARTIAL]


**Purpose:** SMS sent log. Has SentDate, MobileNumber, Message.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | date | YES | TBC | 🔴 |

| Details | ntext | YES | TBC | 🔴 |

| Existing_Details | ntext | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| Operation | nvarchar | YES | TBC | 🔴 |

| Screen_Names | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | date | YES | TBC | 🔴 |



---


#### 🔴 SMSGroupMaster (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 SMSGroupMemberDetails (17 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| GroupTypeName | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| MembersInfo | nvarchar | YES | TBC | 🔴 |

| MembersName | nvarchar | YES | TBC | 🔴 |

| MobileNo | nvarchar | YES | TBC | 🔴 |

| SMSGroupMaster_ID | bigint | YES | TBC | 🔴 |

| Staff_ID | bigint | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 SMSScreenMaster (10 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Branch_Id | numeric | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 SMSScreenTypeMaster (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Branch_Id | numeric | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bigint | YES | TBC | 🔴 |

| ScreenId | bigint | YES | TBC | 🔴 |

| TypeName | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 SMS_ConfigurationSettings (11 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AuthenticKey | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Password | nvarchar | YES | TBC | 🔴 |

| Route | nvarchar | YES | TBC | 🔴 |

| SMSServiceType | nvarchar | YES | TBC | 🔴 |

| SecureKey | nvarchar | YES | TBC | 🔴 |

| SenderID | nvarchar | YES | TBC | 🔴 |

| URL | nvarchar | YES | TBC | 🔴 |

| UserName | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 SMS_Email_Settings (39 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| Branch_Id | numeric | YES | TBC | 🔴 |

| Class_Id | nvarchar | YES | TBC | 🔴 |

| Class_Name | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | NO | TBC | 🔴 |

| DLT_TemplateID | nvarchar | YES | TBC | 🔴 |

| Date | datetime | YES | TBC | 🔴 |

| Day | nvarchar | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Email | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IsOtherChecked | bit | YES | TBC | 🔴 |

| IsParentChecked | bit | YES | TBC | 🔴 |

| IsStaffChecked | bit | YES | TBC | 🔴 |

| Operation_Id | bigint | YES | TBC | 🔴 |

| Operation_Name | nvarchar | YES | TBC | 🔴 |

| OtherRecipientEmail | nvarchar | YES | TBC | 🔴 |

| OtherRecipientMobile | nvarchar | YES | TBC | 🔴 |

| Parent_Recipient | nvarchar | YES | TBC | 🔴 |

| SMS | nvarchar | YES | TBC | 🔴 |

| Screen_Id | bigint | YES | TBC | 🔴 |

| Screen_Name | nvarchar | YES | TBC | 🔴 |

| Section_Id | nvarchar | YES | TBC | 🔴 |

| Section_Name | nvarchar | YES | TBC | 🔴 |

| StaffID | nvarchar | YES | TBC | 🔴 |

| StaffName | nvarchar | YES | TBC | 🔴 |

| Staff_Class_Id | nvarchar | YES | TBC | 🔴 |

| Staff_Class_Name | nvarchar | YES | TBC | 🔴 |

| Staff_Recipient | nvarchar | YES | TBC | 🔴 |

| Staff_Section_Id | nvarchar | YES | TBC | 🔴 |

| Staff_Section_Name | nvarchar | YES | TBC | 🔴 |

| Time | time | YES | TBC | 🔴 |

| Title | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| WhatsAppMessage | nvarchar | YES | TBC | 🔴 |

| WhatsAppTemplateId | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 SMS_Sent_Details (13 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdmissionType | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CCRecipient | nvarchar | YES | TBC | 🔴 |

| Category | nvarchar | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IPAddress | nvarchar | YES | TBC | 🔴 |

| LoggedUserName | nvarchar | YES | TBC | 🔴 |

| Recipient | nvarchar | YES | TBC | 🔴 |

| SMSMessage | nvarchar | YES | TBC | 🔴 |

| SentCount | nvarchar | YES | TBC | 🔴 |

| SentTo | ntext | YES | TBC | 🔴 |



---


#### 🔴 SmsEmailTemplateConfiguration (10 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| BranchID | int | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| EmailTemplate | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| SmsTemplate | nvarchar | YES | TBC | 🔴 |

| TemplateName | varchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |



---


#### 🔴 WhatsAppConfiguration (17 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearId | bigint | YES | TBC | 🔴 |

| BranchId | bigint | YES | TBC | 🔴 |

| ContentType | nvarchar | YES | TBC | 🔴 |

| Contents | nvarchar | YES | TBC | 🔴 |

| CreatedBy | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| DeletedBy | bigint | YES | TBC | 🔴 |

| DeletedDate | datetime | YES | TBC | 🔴 |

| Id | int | NO | TBC | 🔴 |

| IsActive | bit | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Password | nvarchar | YES | TBC | 🔴 |

| PhoneNumber | nvarchar | YES | TBC | 🔴 |

| UpdatedBy | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |

| Url | nvarchar | YES | TBC | 🔴 |

| UserName | nvarchar | YES | TBC | 🔴 |



---


### CircularsHomework (7 tables)


#### 🔴 CircularEntry (28 columns) — [PENDING]


**Purpose:** School circulars. Has Created_Date, Subject, Body, etc.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CategoryID | int | YES | TBC | 🔴 |

| CircularApplicableFor | nvarchar | YES | TBC | 🔴 |

| CircularApplicableForID | bigint | YES | TBC | 🔴 |

| Circular_Date | date | YES | TBC | 🔴 |

| Class_ID | nvarchar | YES | TBC | 🔴 |

| Class_Name | nvarchar | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_by | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| FileNames | nvarchar | YES | TBC | 🔴 |

| Group_ID | bigint | YES | TBC | 🔴 |

| Group_Name | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Image | nvarchar | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| IsResponseNeeded | bit | YES | TBC | 🔴 |

| IsStaffTypewithClass | nvarchar | YES | TBC | 🔴 |

| Section_ID | nvarchar | YES | TBC | 🔴 |

| Section_Name | nvarchar | YES | TBC | 🔴 |

| StaffType_ID | nvarchar | YES | TBC | 🔴 |

| StaffType_Name | nvarchar | YES | TBC | 🔴 |

| Title | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 CircularEntryDetails (5 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| CircularEntryID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| StaffID | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| Type | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 HomeWorkAndAssignment (21 columns) — [PENDING]


**Purpose:** Homework assignments. Has AssignedDate, etc.


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AssignmentDate | date | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_ID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | NO | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_by | bigint | YES | TBC | 🔴 |

| FilesName | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Remarks | nvarchar | YES | TBC | 🔴 |

| Section_ID | nvarchar | YES | TBC | 🔴 |

| StaffName | nvarchar | YES | TBC | 🔴 |

| Staff_ID | bigint | YES | TBC | 🔴 |

| Subject_ID | bigint | YES | TBC | 🔴 |

| SubmissionDate | date | YES | TBC | 🔴 |

| Type_Id | bigint | YES | TBC | 🔴 |

| Type_Name | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 LessonPlanDetails (9 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| LessonPlanID | bigint | YES | TBC | 🔴 |

| MonthID | bigint | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| SubjectID | bigint | YES | TBC | 🔴 |

| Syllabus | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 LessonPlanTopicDetails (8 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Description | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| PlanDetailID | bigint | YES | TBC | 🔴 |

| Status_Id | bigint | YES | TBC | 🔴 |

| Status_Name | nvarchar | YES | TBC | 🔴 |

| TopicID | bigint | YES | TBC | 🔴 |



---


#### 🔴 Lesson_Plan (25 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Aids | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| Class_Id | bigint | YES | TBC | 🔴 |

| Concepts | nvarchar | YES | TBC | 🔴 |

| Created_By_ID | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Date | date | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| Deleted_ID | bigint | YES | TBC | 🔴 |

| Evaluation_LessonWise_Test_Dates | nvarchar | YES | TBC | 🔴 |

| From_Date | date | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| Motivation | nvarchar | YES | TBC | 🔴 |

| NotesGivenStudyMaterialMainPointsOralwritten | nvarchar | YES | TBC | 🔴 |

| NotesGivenStudyMaterialMainPointsOralwrittenwithoutcharacter | nvarchar | YES | TBC | 🔴 |

| Section_Id | bigint | YES | TBC | 🔴 |

| Staff_Id | bigint | YES | TBC | 🔴 |

| Subject_Id | bigint | YES | TBC | 🔴 |

| Teacher | nvarchar | YES | TBC | 🔴 |

| To_Date | date | YES | TBC | 🔴 |

| Topic_Character | nvarchar | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |

| Updated_ID | bigint | YES | TBC | 🔴 |



---


#### 🔴 NotesOfLesson (19 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| Activity | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Deleted_By | bigint | YES | TBC | 🔴 |

| Deleted_Date | datetime | YES | TBC | 🔴 |

| FilesName | nvarchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| StaffID | bigint | YES | TBC | 🔴 |

| StaffName | nvarchar | YES | TBC | 🔴 |

| SubjectID | bigint | YES | TBC | 🔴 |

| SyllabusID | bigint | YES | TBC | 🔴 |

| Title | nvarchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


### ParentFeedback (6 tables)


#### 🔴 ParentPortalActivity (15 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| ActivityDate | datetime | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| Created_By | bigint | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| Description | varchar | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Icon_Name | varchar | YES | TBC | 🔴 |

| IsDeleted | bit | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| Title | varchar | YES | TBC | 🔴 |

| Updated_By | bigint | YES | TBC | 🔴 |

| Updated_Date | datetime | YES | TBC | 🔴 |



---


#### 🔴 ParentPortalCircularStatus (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AcknowledgementStatusID | int | YES | TBC | 🔴 |

| AcknowledgementStatusName | varchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CircularID | bigint | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Remarks | varchar | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |

| ViewStatusID | int | YES | TBC | 🔴 |

| ViewStatusName | varchar | YES | TBC | 🔴 |



---


#### 🔴 ParentPortalHomeworkAssignmentStatus (12 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| CompletionStatusID | int | YES | TBC | 🔴 |

| CompletionStatusName | varchar | YES | TBC | 🔴 |

| CreatedDate | datetime | YES | TBC | 🔴 |

| HomeworkAssignementID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Remarks | varchar | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| UpdatedDate | datetime | YES | TBC | 🔴 |

| ViewStatusID | int | YES | TBC | 🔴 |

| ViewStatusName | varchar | YES | TBC | 🔴 |



---


#### 🔴 PortalLoginUserDetails (14 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ClassID | bigint | YES | TBC | 🔴 |

| ClassName | nvarchar | YES | TBC | 🔴 |

| Created_Date | datetime | YES | TBC | 🔴 |

| CurrentYear | nvarchar | YES | TBC | 🔴 |

| Id | bigint | NO | TBC | 🔴 |

| IpAddress | nvarchar | YES | TBC | 🔴 |

| LoggedFrom | nvarchar | YES | TBC | 🔴 |

| SectionID | bigint | YES | TBC | 🔴 |

| SectionName | nvarchar | YES | TBC | 🔴 |

| StudentID | bigint | YES | TBC | 🔴 |

| StudentName | nvarchar | YES | TBC | 🔴 |

| UserName | nvarchar | YES | TBC | 🔴 |



---


#### 🔴 PortalMenuMaster (10 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| ApplicableFor | int | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Icon | varchar | YES | TBC | 🔴 |

| Levels | int | YES | TBC | 🔴 |

| Name | varchar | YES | TBC | 🔴 |

| Parent_Id | bigint | YES | TBC | 🔴 |

| Position | int | YES | TBC | 🔴 |

| ScreenName | varchar | YES | TBC | 🔴 |

| Status | bit | YES | TBC | 🔴 |

| Url | varchar | YES | TBC | 🔴 |



---


#### 🔴 Portal_Login (8 columns) — [PENDING]


**Purpose:** 🔴 *TBC — the dev team needs to confirm what this table is for.*


**Columns:**


| Column | Type | Nullable | Purpose | Status |
|---|---|---|---|---|

| AcademicYearID | bigint | YES | TBC | 🔴 |

| AdmissionNo | nvarchar | YES | TBC | 🔴 |

| BranchID | bigint | YES | TBC | 🔴 |

| ID | bigint | NO | TBC | 🔴 |

| Password | nvarchar | YES | TBC | 🔴 |

| Status | nvarchar | YES | TBC | 🔴 |

| Student_ID | bigint | YES | TBC | 🔴 |

| Username | nvarchar | YES | TBC | 🔴 |



---



## 7. How to update this dictionary


The dev team updates this dictionary as they confirm tables/columns:


1. **For a table you confirm:** change its status from 🔴 PENDING to ✅ CONFIRMED. Add the purpose text.

2. **For a column you confirm:** add its purpose text in the column's row. Change the status to ✅.

3. **For a new enum:** add it to §4 (Known Enums) with the values + status.

4. **For a new FK:** add it to §5 (Known FKs) with the from/to columns + confidence.

5. **For a deprecated table:** add it to §3 (Deprecated Tables) + add a DEPRECATED rule to `semantic_rules.py`.

6. **For a gotcha:** add it to §2 (Known Gotchas).


The machine-readable version is `DATA_DICTIONARY.json`. The markdown is the human-readable version. Keep both in sync.


---


*Generated: 2026-08-29T06:36:13*

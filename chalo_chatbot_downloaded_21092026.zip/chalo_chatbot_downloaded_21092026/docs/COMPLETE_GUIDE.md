# ChaloSchools AI Secretary — Complete Guide

**Version:** 1.1.3
**Last updated:** 2026-09-03

This is the single, consolidated document for the ChaloSchools AI Secretary chatbot. It covers installation, configuration, and instructions for three teams (Infra, Dev, Admin) plus troubleshooting and maintenance. For distribution as Markdown and PDF.

---

## Table of Contents

1. [Overview — What This System Is](#1-overview)
2. [Installation Guide — From Zero to Running](#2-installation-guide)
3. [Infra Team Instructions](#3-infra-team-instructions)
4. [Dev Team Instructions](#4-dev-team-instructions)
5. [Admin Instructions](#5-admin-instructions)
6. [Troubleshooting (All Teams)](#6-troubleshooting)
7. [Maintenance Schedule (All Teams)](#7-maintenance-schedule)
8. [Quick Reference](#8-quick-reference)

---

## 1. Overview

### What it does

A school staff member types a question in a chat box ("What is the fee outstanding for the current term?"). A fine-tuned Qwen 2.5 Coder 7B model (served by llama.cpp) reads the question and writes a T-SQL query. Before the query touches the school's database, it passes through 11 verification stages — does it only read? does it reference real tables? does it scope to the user's authorized branches? does it follow 32 business rules mined from the school's 1,095 stored procedures? If anything fails, it refuses with a specific reason. If everything passes, the query runs and the answer comes back.

### The three services

| Service | Port | What | Who manages |
|---|---|---|---|
| llama.cpp (the LLM) | 8080 | The fine-tuned model — writes T-SQL from questions | Infra (deploys) / Dev (model) |
| FastAPI backend | 8000 | The API service — 11-stage pipeline + 32-rule semantic engine + VAPT hardening | Dev |
| nginx | 443 | TLS, rate limiting, security headers, WAF | Infra |

The mobile app (production frontend) calls the FastAPI backend over HTTPS. A local-test Next.js web UI exists for development only — it is NOT deployed to production.

### Hardware requirements (minimum)

| Component | Minimum | Recommended | Why |
|---|---|---|---|
| CPU | 4 OCPU (AVX2) | 8 OCPU | The LLM uses every core; below 4 = unusably slow |
| RAM | 16 GB | 24 GB | The GGUF (4.5GB) + KV cache (1-2GB) + OS (1-2GB) + backend (0.5GB) |
| Storage | 20 GB SSD | 50 GB SSD | The GGUF + datasets + logs |
| GPU | None needed | Optional (16GB VRAM = 10x faster) | CPU-only is acceptable for 20-25 users |
| Network | Same OCI region as the DB | Same VCN | 1ms RTT for ExecuteQuery calls |

**Note: 2 OCPU / 4GB RAM will NOT work.** The 7B model needs at least 8-10GB of RAM to load. Below that, it swaps to disk and takes minutes per token.

---

## 2. Installation Guide

### 2.1 Prerequisites

- An OCI account with access to the same region as the ChaloSchools DB server.
- The ChaloSchools DB server running MS SQL Server with the ExecuteQuery ASMX endpoint.
- The `GetUserContext` API running (the school's auth system).
- SSH access to the OCI instance you'll create.
- The trained GGUF model file (Qwen 2.5 Coder 7B, fine-tuned by your team).

### 2.2 Quick install (single-instance, cheapest — for the first 5-10 clients)

#### Step 1 — Launch the OCI instance

1. OCI Console → Compute → Instances → Create Instance.
   - Shape: **VM.Standard.E4.Flex** (AMD EPYC with AVX2).
   - OCPUs: 8. Memory: 24 GB. Boot volume: 50 GB.
   - Image: Oracle Linux 9 (or Ubuntu 22.04).
   - Subnet: a subnet in the same VCN as your ChaloSchools DB (for 1ms RTT).
   - SSH key: your public key.

#### Step 2 — SSH in and install dependencies

```bash
ssh opc@<instance-public-ip>

# Update the OS
sudo dnf update -y

# Install Python 3.11+ + pip + git + nginx
sudo dnf install -y python3.11 python3.11-pip git nginx

# Install pyodbc dependencies (for local_db mode — optional)
sudo dnf install -y unixODBC-devel
# Install the MS SQL ODBC driver 17 per Microsoft's docs (optional — only for local_db mode)

# Create a dedicated user
sudo useradd -r -s /bin/bash -d /opt/ai-secretary ai-secretary
sudo mkdir -p /opt/ai-secretary
sudo chown ai-secretary:ai-secretary /opt/ai-secretary
```

#### Step 3 — Clone the codebase + install Python dependencies

```bash
sudo su - ai-secretary
cd /opt/ai-secretary

# Clone the repo (replace with your repo URL)
git clone <your-repo-url> .
cd chalo_chatbot

# Create a virtual environment
python3.11 -m venv venv
source venv/bin/activate

# Install the backend dependencies
pip install fastapi uvicorn pydantic

# (Optional — for local_db mode only)
pip install pyodbc

# Verify the backend imports
cd backend
python3 -c "from main import app; print('Backend OK')"
```

#### Step 4 — Configure the environment

**⚠️ Two modes — .env is for LOCAL DEV ONLY; OCI Vault is for PRODUCTION.**

**For LOCAL DEV (your laptop):**
```bash
# Create the env file (copy the template)
cp .env.example .env

# Edit .env with your real values:
# AI_SECRETARY_AUTH_TOKENS=<a-long-random-string>      ← user auth
# AI_SECRETARY_ADMIN_TOKENS=<a-different-long-string>   ← admin auth
# AI_SECRETARY_TENANT_KEYS=V3_TestDatabase:<the-real-api-key>
# AI_SECRETARY_CORS_ORIGINS=http://localhost:3000
# AI_SECRETARY_DEBUG=true   ← debug mode shows real SQL errors (for dev only)
```
This `.env` file is for your LOCAL machine only. Never deploy it to the production server.

**For PRODUCTION (OCI server):**
Do NOT create a `.env` file on the server. Instead, store these secrets in OCI Vault (see §3.2 below). A cloud-init script fetches the secrets from Vault at boot and writes them to `/etc/ai-secretary/env` (a file only readable by the `ai-secretary` user, not in the repo). The systemd service reads from `EnvironmentFile=/etc/ai-secretary/env`.

#### Step 5 — Install + start the LLM (llama.cpp)

```bash
# Still as the ai-secretary user
cd /opt/ai-secretary

# Clone + build llama.cpp
git clone https://github.com/ggerganov/llama.cpp
cd llama.cpp
make  # or: cmake -B build && cmake --build build

# Copy your trained GGUF model
# (Upload it from your machine: scp qwen25coder_chaloschools_v27.gguf opc@<ip>:/opt/ai-secretary/llama.cpp/models/)
cp /path/to/qwen25coder_chaloschools_v27.gguf models/

# Test that it starts
./llama-server -m models/qwen25coder_chaloschools_v27.gguf --host 127.0.0.1 --port 8080 --ctx-size 2560
# → should say "server listening on 127.0.0.1:8080"
# Ctrl+C to stop; we'll set it up as a service next.
```

#### Step 6 — Create systemd services (auto-start + auto-restart)

```bash
# Exit back to a sudo-capable user
exit

# Create the llama.cpp service
sudo tee /etc/systemd/system/llama-cpp.service << 'EOF'
[Unit]
Description=llama.cpp LLM Server
After=network.target

[Service]
Type=simple
User=ai-secretary
ExecStart=/opt/ai-secretary/llama.cpp/llama-server -m /opt/ai-secretary/llama.cpp/models/qwen25coder_chaloschools_v27.gguf --host 127.0.0.1 --port 8080 --ctx-size 2560
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

# Create the backend service
sudo tee /etc/systemd/system/ai-secretary.service << 'EOF'
[Unit]
Description=ChaloSchools AI Secretary API
After=network.target llama-cpp.service

[Service]
Type=simple
User=ai-secretary
WorkingDirectory=/opt/ai-secretary/chalo_chatbot/backend
# LOCAL DEV: EnvironmentFile points to backend/.env (created in Step 4)
# PRODUCTION: EnvironmentFile points to /etc/ai-secretary/env (created by cloud-init from OCI Vault)
# Choose ONE of these lines based on your environment:
# EnvironmentFile=/opt/ai-secretary/chalo_chatbot/backend/.env          ← dev
# EnvironmentFile=/etc/ai-secretary/env                                   ← production
ExecStart=/opt/ai-secretary/chalo_chatbot/backend/venv/bin/uvicorn main:app --host 127.0.0.1 --port 8000
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

# Enable + start both
sudo systemctl daemon-reload
sudo systemctl enable llama-cpp ai-secretary
sudo systemctl start llama-cpp
sudo systemctl start ai-secretary
```

#### Step 7 — Configure nginx (TLS + security headers + rate limiting)

```bash
# Get a TLS cert (use Let's Encrypt with certbot)
sudo dnf install -y certbot python3-certbot-nginx
sudo certbot certonly --nginx -d chatbot.chaloschools.in

# Create the nginx config
sudo tee /etc/nginx/conf.d/ai-secretary.conf << 'NGINXEOF'
server {
    listen 80;
    server_name chatbot.chaloschools.in;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name chatbot.chaloschools.in;

    ssl_certificate /etc/letsencrypt/live/chatbot.chaloschools.in/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/chatbot.chaloschools.in/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;

    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "DENY" always;
    add_header Content-Security-Policy "default-src 'none'; frame-ancestors 'none'" always;
    add_header Referrer-Policy "no-referrer" always;

    client_max_body_size 1m;

    limit_req_zone $binary_remote_addr zone=ip:10m rate=10r/s;

    location /api/ {
        limit_req zone=ip burst=20 nodelay;
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 120s;
    }

    location /api/health {
        proxy_pass http://127.0.0.1:8000;
        access_log off;
    }
}
NGINXEOF

# Test + restart nginx
sudo nginx -t
sudo systemctl restart nginx
sudo systemctl enable nginx
```

#### Step 8 — Verify

```bash
# From the instance (local):
curl http://127.0.0.1:8080/v1/models        # → should list the model
curl http://127.0.0.1:8000/api/health       # → {"status":"ok","pipeline_loaded":true,"rules_count":32,"version":"1.1.0"}

# From outside (via the public IP / domain):
curl https://chatbot.chaloschools.in/api/health
# → same response + security headers present

# Check security headers:
curl -I https://chatbot.chaloschools.in/api/health
# → HSTS, X-Content-Type-Options, X-Frame-Options, CSP headers present
```

If all three pass, the system is running. The mobile app can now call `https://chatbot.chaloschools.in/api/chat`.

### 2.3 Two-instance setup (recommended before VAPT or 10+ clients)

For the VAPT test or when you exceed 10 concurrent users, split into two instances:
- **API instance** (public subnet): nginx + the FastAPI backend. 4 OCPU, 16GB.
- **LLM instance** (private subnet): llama.cpp only. 8 OCPU, 24GB.

The LLM listens on its private IP (not 127.0.0.1). The API instance's `model_url` config points to the LLM's private IP: `http://10.0.2.10:8080/v1/chat/completions`. The security list allows port 8080 only from the API subnet.

See `docs/OCI_DEPLOYMENT.md` for the full VCN topology + security lists.

---

## 3. Infra Team Instructions

**Your role:** deploy and maintain the OCI infrastructure, nginx, WAF, and secrets. You don't touch the application code.

### 3.1 What to do (the ongoing tasks)

| Task | When | How |
|---|---|---|
| Health monitoring | Daily (automated) | OCI alarm pings `/api/health` every minute; alert if non-200 or `status: "degraded"` |
| Audit trail backup | Weekly | `sqlite3 audit_trail.db ".backup '/backup/audit_trail_$(date +%Y%m%d).db'"` → copy to OCI Object Storage |
| Log review | Weekly | `journalctl -u ai-secretary --since "1 week ago" \| grep ERROR` |
| Dependency CVE scan | Monthly | `pip-audit` on the backend's venv; if CVEs, update + re-deploy |
| nginx config review | Monthly | Check for config drift (did someone edit without documenting?) |
| Vault key rotation | Monthly | Rotate auth tokens + admin tokens + tenant API keys; restart the backend |
| TLS cert renewal | Every 90 days (automated) | `sudo certbot renew` → `sudo systemctl reload nginx` |

### 3.2 Secrets in OCI Vault (PRODUCTION ONLY — do NOT use .env on the server)

**⚠️ The rule is simple:** `.env` files are for your LOCAL LAPTOP (dev/testing). On the PRODUCTION OCI server, never create a `.env` file — use OCI Vault instead. The cloud-init script fetches secrets from Vault at boot and writes them to `/etc/ai-secretary/env` (owned by the `ai-secretary` user, not in the repo).

1. OCI Console → Security → Vaults → Create Vault → create a master key.
2. Create secrets:
   | Secret | Value |
   |---|---|
   | `auth-tokens` | `user-token-abc123,...` |
   | `admin-tokens` | `admin-token-xyz789,...` |
   | `tenant-keys` | `V3_TestDatabase:5e8d1e96...,V3_GG:...` |
3. Create a cloud-init script that fetches these at boot → writes to `/etc/ai-secretary/env`.
4. The systemd service reads from `EnvironmentFile=/etc/ai-secretary/env`.

### 3.3 WAF configuration

1. OCI Console → WAF → Create WAF Policy.
2. Attach to the load balancer.
3. Enable the OWASP preconfigured ruleset (Top 10 protections).
4. Enable rate limiting: 100 req/min per IP.
5. Enable threat intelligence feeds.

### 3.4 What NOT to do

- **Do NOT deploy the Next.js dev UI to production.** It's a local testing tool only.
- **Do NOT expose the LLM (port 8080) to the public internet.** Private subnet or localhost only.
- **Do NOT store secrets in `.env` files on disk** in production. Use OCI Vault.
- **Do NOT use `*` for CORS origins** in production. Set explicit origins (or leave empty for native mobile apps).
- **Do NOT skip the WAF.** It's defense-in-depth.
- **Do NOT use the default auth tokens** (`dev-token-please-change-in-prod`). Generate long random strings.
- **Do NOT run the backend as root.** Use the `ai-secretary` user.

### 3.5 Infra troubleshooting

| Symptom | Check | Fix |
|---|---|---|
| `/api/health` returns nothing | Is nginx running? Is the backend running? | `sudo systemctl status nginx` → `sudo systemctl status ai-secretary` |
| `pipeline_loaded: false` | A Python import failed | `journalctl -u ai-secretary -n 50` |
| LLM returns "Connection refused" | Is llama.cpp running? | `sudo systemctl status llama-cpp` → check the GGUF exists |
| 502 Bad Gateway | nginx can't reach the backend (port 8000) | `curl http://127.0.0.1:8000/api/health` from the instance |
| 429 Too Many Requests | Rate limit hit | Wait 60s; or increase `AI_SECRETARY_RATE_LIMIT_IP` if legitimate |
| TLS cert expired | Let's Encrypt cert is 90 days | `sudo certbot renew` → `sudo systemctl reload nginx` |
| High CPU (sustained) | The LLM is under load | Check concurrent connections; consider a second LLM instance |
| Disk full | The audit_trail.db or logs grew | `du -sh audit_trail.db` → vacuum or archive |

---

## 4. Dev Team Instructions

**Your role:** develop, test, and deploy the application code (the backend, the pipeline, the semantic engine, the vocab engine, the training data). You don't touch OCI infrastructure.

### 4.1 Dev environment setup

```bash
# Clone the repo
git clone <repo-url> ai-secretary
cd ai-secretary/chalo_chatbot

# Create a virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install fastapi uvicorn pydantic
# (pipeline modules are stdlib-only; pyodbc is lazy-loaded for local_db mode)

# === LOCAL DEV ONLY — do NOT do this on the production server ===
# Copy the env template (for your laptop's local testing)
cp backend/.env.example backend/.env
# Edit .env: set AI_SECRETARY_AUTH_TOKENS + AI_SECRETARY_ADMIN_TOKENS to dev values
# (For production, use OCI Vault instead — see §3.2)

# Start the backend (for local testing)
cd backend
uvicorn main:app --host 0.0.0.0 --port 8000 --reload

# In another terminal, start the Next.js dev UI (local testing only)
cd <the-nextjs-project-root>
npm run dev
# → open http://localhost:3000
```

### 4.2 Daily workflow — the 4 commands you run before any change

```bash
# 1. Run the security self-test (V4/V5/V7/V9/V10)
cd backend && python3 security.py

# 2. Run the semantic engine self-test (13 cases)
cd pipeline && python3 semantic_rules.py

# 3. Run the semantic validation on the training dataset
cd semantic_validation && python3 validate_dataset.py

# 4. Run ESLint on the frontend (if you changed it)
cd <nextjs-root> && npm run lint
```

### 4.3 How to add a new semantic rule

1. Open `pipeline/semantic_rules.py`.
2. Write a function `r_yourrule(sql, q, tables) -> Optional[Violation]`.
3. Add it to the `RULES` list + `RULE_META` dict.
4. Add a self-test case.
5. Run `python3 semantic_rules.py` → verify.
6. Sync to `semantic_validation/semantic_rules.py`.
7. Run `python3 validate_dataset.py` → verify it fires on the expected examples.

**Example:**
```python
def r_fee014(sql, q, tables):
    if "FeesInformationStudentDetail" not in tables: return None
    if "bus fee" not in q.lower(): return None
    if not _has(sql, r"IsBusFee\s*=\s*1"):
        return Violation("FEE-014", "HIGH",
            "Bus-fee query omits IsBusFee = 1 filter.",
            "Add AND f.IsBusFee = 1 to restrict to bus-fee rows only.", "Fees")
    return None
```

### 4.4 How to update training data (the v28 retrain path)

1. **Clean the existing labels:** run `validate_dataset.py` → triage flagged examples in `output/report.html` → fix the SQL → re-run until flag rate < 5%.
2. **Add new training examples:** for the coverage gaps (per `docs/PRODUCTION_TRACE_OBSERVATIONS.md`).
3. **Update `prepare_data.py`'s `FROZEN_SYSTEM_PROMPT`** if the instruction is changing (per `docs/INSTRUCTION_IMPROVEMENT.md`).
4. **Run `prepare_data.py`:** validates every example, refuses if HIGH > 0, splits into train/val.
5. **Train:** r=16, dropout 0.05, lr 1e-4, warmup 35, MAX_SEQ_LENGTH 2560, epochs 2.
6. **Export:** q5_k_m quantization.
7. **Evaluate:** run the accuracy harness (50 golden Qs). v28 must beat v27.
8. **Deploy:** upload the GGUF; restart llama-cpp. Flip `inject_vocab: true` if using FULL mode.

### 4.5 What NOT to do

- **Do NOT change the frozen system prompt at runtime without retraining.** The v27 model derails on prompt changes (confirmed twice).
- **Do NOT enable `fast_paths` in production until the 480 flagged examples are cleaned.**
- **Do NOT enable `inject_vocab` without the v28 retrain.**
- **Do NOT ship a model without running the accuracy harness.** `eval_loss` ≠ semantic correctness.
- **Do NOT add a dependency without running `pip-audit`.**
- **Do NOT concatenate user input into SQL.** All values go through parameterized binding.
- **Do NOT skip the semantic engine** (`semantic_rules_enabled=True` always in production).
- **Do NOT log the Context JSON to the audit trail.** Log only user_id + branch_id.
- **Do NOT commit secrets to the repo.**

### 4.6 Dev troubleshooting

| Symptom | Check | Fix |
|---|---|---|
| Backend won't start | Import error | `python3 -c "from main import app"` → look for the ImportError |
| `pipeline_loaded: false` | A pipeline module didn't import | Check `sys.path` includes `pipeline/` and `vocab/` |
| LLM returns empty/garbled | Wrong model URL or model not loaded | `curl http://localhost:8080/v1/models` |
| Semantic engine doesn't fire | `semantic_rules_enabled` is False | Check the orchestrator's constructor |
| Validate-and-substitute doesn't rewrite | Synonym store didn't load | Check `vocab/synonyms.json` exists |
| `prepare_data.py` gate fails | HIGH violations > 0 | Run `validate_dataset.py` → fix the flagged examples |
| Accuracy regression | The model changed something | Compare v27 vs v28 on the 50 golden Qs |

### 4.7 Pending UI/UX features (added 2026-09-03 — DOC-UPDATE-5)

These 4 items were requested by the project owner on 2026-09-03 and are **not yet implemented**. They're queued for the dev team's next sprint. Full descriptions are in `docs/PROJECT_STATUS.md` §4.6 and `docs/SESSION_HANDOFF.md` (2026-09-03 update).

| # | Item | Where | Effort |
|---|---|---|---|
| 1 | **AI disclaimer in `chat.html`** — a subtle footer note: *"AI can make mistakes. Please verify important information."* | `frontend/chat.html` (HTML/CSS only) | Small |
| 2 | **LLM model selector dropdown** — three options: **Chalo Language Model 1.0** (current, selected by default), **CLM 2.0** (disabled — coming soon), **CLM 3.0** (disabled — coming soon). Maps to a different GGUF path in `scripts/start_llm.bat` or a different `model_url` in the request body. | `frontend/chat.html` → Settings panel | Medium |
| 3 | **Configurable "show thinking process" toggle** — show pipeline stages progressively ("Understanding your question...", "Generating SQL...", "Validating against 32 rules...", "Querying the database..."). Toggle in Settings; default OFF. Needs backend SSE/streaming (today the trace is returned only at the end). | `frontend/chat.html` + `backend/main.py` (StreamingResponse) + `pipeline/orchestrator.py` (yield stage events) | Medium-large |
| 4 | **Standard reply for unanswerable questions (configurable)** — when `outcome ∈ {REFUSED, ERROR, NEEDS_DISAMBIGUATION}`, show a single admin-configurable message in the user-facing `message` field. Default: *"I'm sorry, I couldn't answer that question. Please try rephrasing it, or ask a different question."* Configurable via `AI_SECRETARY_FALLBACK_MESSAGE` env var in `backend/.env` or a new key in `backend/feature_overrides.json`. The raw `detail` + `semantic_violations` stay in the response body for debugging. | `backend/main.py` + `backend/.env` (or `feature_overrides.json`) | Small-medium |

**Suggested order:** 1 → 2 → 4 → 3 (smallest to largest). Items 1 and 2 are pure frontend. Item 4 is small backend. Item 3 is the largest because it requires streaming stage events from the orchestrator through the backend to the frontend.

### 4.8 Pending accuracy improvements (added 2026-09-03 — DOC-UPDATE-5)

Two non-code, non-retrain accuracy improvements were identified on 2026-09-03:

1. **System prompt expansion** — the current system prompt is one paragraph (~80 tokens). The plan is to expand it to ~2 pages (~1,000-1,500 tokens) covering the 7 schema gotchas, top 5 business formulas, top 10 mandatory filters, key JOIN patterns, and critical enum values. This is the **#1 accuracy lever without retraining or dev-team help**. Status: PENDING — waiting for the user to paste 4 small extracts (top filters, enums, hub tables, raw SQL) from the codebase-analysis toolkit output so the prompt can be built from real data. See `docs/INSTRUCTION_IMPROVEMENT.md` for the v28 retrain variant.

2. **CTX_SIZE bump** — the `CTX_SIZE=2560` in `scripts/start_llm.bat` (and the `--ctx-size 2560` lines in §2.2 Step 5 + the systemd `ExecStart` example in §2.2 Step 6 above) is a **TRAINING** constraint (Claude set it to prevent silent truncation of training sequences — the longest example was ~1,750 tokens). At **INFERENCE** time, the context window is independent; Qwen 2.5 Coder 7B's base model natively supports 32K tokens. **Decision:** bump inference `--ctx-size` from 2560 → **4096** (not 8192 — that might degrade attention on CPU). This unlocks the 2-page system prompt above. Going 2560 → 4096 adds ~3-4 seconds of latency (acceptable: 15-35s → 18-39s on CPU). **The two changes (prompt expansion + CTX_SIZE bump) go together.** Update all three `--ctx-size 2560` references (the install-step command, the systemd `ExecStart` line, and `scripts/start_llm.bat`) when this change goes in.

---

## 5. Admin Instructions

**Your role:** manage the chatbot's configuration (feature flags, auth tokens, monitoring). You don't touch code or infrastructure.

### 5.1 Managing feature flags (the 24 toggles)

All 24 feature flags are **OFF by default**. You flip them on/off via the admin API.

**View the current flags:**
```bash
curl -H "Authorization: Bearer <admin-token>" \
     https://chatbot.chaloschools.in/api/admin/features
```

**Enable a feature:**
```bash
curl -X PUT -H "Authorization: Bearer <admin-token>" \
     -H "Content-Type: application/json" \
     -d '{"flags": {"auto_chart": true}}' \
     https://chatbot.chaloschools.in/api/admin/features
```

**Disable a feature:**
```bash
curl -X PUT -H "Authorization: Bearer <admin-token>" \
     -H "Content-Type: application/json" \
     -d '{"flags": {"auto_chart": false}}' \
     https://chatbot.chaloschools.in/api/admin/features
```

**Important:** flipping a flag on does NOT immediately add the feature. The flag is a governance layer — it tells the backend "this feature is allowed." The feature's code must be implemented (by the dev team) for the flag to have an effect. Flags marked "v1.1+" are not yet implemented; flipping them on today does nothing.

**The 24 flags:**

| Flag | Description | Phase |
|---|---|---|
| `auto_chart` | Auto-chart result tables | v1.1 (mobile-app) |
| `insight_cards` | 1-3 auto-generated insight cards | v1.2 (second LLM call) |
| `trend_comparison` | This-year-vs-last-year auto-add | v1.1 |
| `drill_down` | Tappable rows → follow-ups | v1.1 |
| `morning_briefing` | Scheduled 6am insights + push | v1.3 (scheduler + push) |
| `anomaly_alerts` | Nightly anomaly detection + push | v1.3 |
| `you_might_also_ask` | 3 follow-up suggestions | v1.1 (rule-based) |
| `hinglish_tamil` | Bilingual mode | v28 retrain |
| `school_jargon` | Jargon glossary in the prompt | v28 |
| `voice_input` | STT integration | v1.2 (mobile-app) |
| `why_this_answer` | "Why this answer?" expandable | v1.1 |
| `capability_card` | "What I can/can't answer" page | v1.0 (static) |
| `share_qa` | Deep-link sharing | v1.2 |
| `pin_questions` | Pin frequent questions | v1.1 |
| `schedule_questions` | Scheduled queries + push | v1.3 |
| `feedback_loop` | Thumbs up/down on every answer | v1.1 (logging ready; UI pending) |
| `question_clustering` | Weekly clustering report | v1.3 |
| `active_learning` | Chatbot asks admin for help | v2.0 |
| `multi_school_benchmark` | Cross-branch comparison | v1.1 (super-user) |
| `parent_mode` | Parent-facing | v2.0 (parent RBAC) |
| `teacher_mode` | Teacher-facing | v1.2 (class-teacher RBAC) |
| `confidence_score` | Green/amber dot on every answer | v1.1 |
| `source_sp` | Show the SP the query is based on | v1.2 |
| `audit_trail` | Show audit trail in admin UI | v1.1 (table is always logged) |

### 5.2 Monitoring

**Daily health check:**
```bash
curl https://chatbot.chaloschools.in/api/health
# Expected: {"status":"ok","pipeline_loaded":true,"rules_count":32,"version":"1.1.0"}
```

If `status: "degraded"` or the response is empty → contact the infra team.

**Review the audit trail** (ask the infra team for access):
```bash
sqlite3 /opt/ai-secretary/chalo_chatbot/backend/audit_trail.db \
  "SELECT timestamp, user_id, question, outcome, latency_ms FROM audit_trail ORDER BY id DESC LIMIT 20;"
```

Or, **easier:** open `frontend/audit.html` in a browser, paste your admin token, and click Load — see the audit trail as a paginated table with dashboard stats (total / answered / refused / error counts + avg latency + last-7-days count + refused-by-stage breakdown).

**Export the audit trail to Excel (XLSX):** in `frontend/audit.html`, click the green **Export XLSX** button. It fetches ALL rows (respecting the current outcome filter, up to 100,000) and downloads them as `.xlsx` via SheetJS (CDN-loaded). Falls back to CSV if offline. Filename includes date + row count.

**Reset (clear) the audit trail:** in `frontend/audit.html`, click the red **Reset** button. Confirms how many rows will be deleted, then calls `DELETE /api/audit` (admin-only). **Cannot be undone — export first if you want a copy.**

Look for:
- High `ERROR` rate → the LLM or the DB may be down.
- High `REFUSED` rate → a new semantic rule may be over-firing.
- `stage = 'security'` refusals → prompt injection attempts.

### 5.3 What NOT to do

- **Do NOT share the admin token.** It controls the feature flags.
- **Do NOT flip on features marked "v1.1+" or "v2.0".** They're not implemented yet.
- **Do NOT flip on `hinglish_tamil` until the v28 retrain is done.** This flag changes the prompt; the v27 model will derail.
- **Do NOT delete the audit_trail.db.** It's the compliance record.
- **Do NOT edit the code or the nginx config yourself.** That's the dev / infra team's job.
- **Do NOT use the user auth token for admin operations.** The admin token is separate.

### 5.4 Admin troubleshooting

| Symptom | Check | Who to contact |
|---|---|---|
| The chatbot doesn't answer at all | `/api/health` | Infra team (LLM or backend down) |
| The chatbot answers but the SQL is wrong | The audit trail — check `semantic_violations` | Dev team |
| The chatbot refuses everything | The audit trail — a new rule over-firing? | Dev team |
| A feature flag doesn't take effect | Is the feature implemented? (check the table) | Dev team |
| 401 on admin API | Is the admin token correct? Was it rotated? | Infra team |
| 403 on admin API | Using a user token, not admin token | Use the admin token |

---

## 6. Troubleshooting (All Teams)

The universal troubleshooting matrix — find your symptom, check the first column, then the second.

| Symptom | First check | Second check | Who |
|---|---|---|---|
| The chatbot doesn't answer at all | Is the LLM up? `curl http://localhost:8080/v1/models` | Is the backend up? `curl http://localhost:8000/api/health` | Infra |
| It answers but the SQL is wrong | The `semantic_violations` in the response — they name the bug | The `trace` — which stage produced the SQL | Dev |
| It refuses with "column X does not exist" | The model hallucinated a column — the guardrail caught it (good) | Training coverage — add examples for the concept | Dev |
| Fee query mixes up fee term and exam term | The model joined ExamTermMaster instead of TermMaster | FEE-006 rule should catch it; if not, add training examples | Dev |
| The query returns zero rows when it shouldn't | Did validate-and-substitute rewrite the literal? Check `substit: rewrote N literal(s)` in the trace | The branch's real vocab — the model's literal may not be a synonym | Dev |
| Latency is 30+ seconds | The LLM is on CPU + the query is long → switch to CTE-form scoping (cuts length 30-50%) | `max_auto_pages` — sequential pagination; lower it | Dev + Infra |
| Super-user sees zero branches | The branch-scoping subquery is missing the super-user UNION half | RBAC-001 rule should fire | Dev |
| Cross-branch data leak | The query has no `@UserId` scoping — the BRANCH_SCOPING stage should have refused | If it didn't refuse, the gate's regex missed a pattern | Dev |
| Sensitive data exposed | The SENSITIVE-COL rule should have refused | If not, the column isn't in `SENSITIVE_COLUMN_OWNERS` — add it | Dev |
| Fast-path served a wrong answer | The cached training SQL has a bug → disable fast-paths | Clean the flagged examples then re-enable | Dev |
| execute: api FAILED (UNION ALL queries) | The ExecuteQuery API's repeated-placeholder bug | Switch to CTE-form scoping; or the dev team fixes the API | Dev + Dev team (school) |
| execute: api FAILED (other) | The real SQL Server error is in the `detail` field (if debug mode) | Check `journalctl -u ai-secretary` for the full error | Dev + Infra |

---

## 7. Maintenance Schedule (All Teams)

### Daily (automated)
| Task | Who |
|---|---|
| Health monitoring (OCI alarm pings `/api/health` every minute) | Infra |
| Log rotation (nginx + journald — automatic) | Infra |

### Weekly
| Task | Who |
|---|---|
| Audit trail backup → OCI Object Storage | Infra |
| Log review (`journalctl -u ai-secretary \| grep ERROR`) | Infra |
| Accuracy harness spot-check (run 5 golden Qs manually) | Dev |

### Monthly
| Task | Who |
|---|---|
| Dependency CVE scan (`pip-audit`) + pin versions | Dev |
| nginx config review (check for config drift) | Infra |
| Vault key rotation (auth tokens, admin tokens, tenant keys) | Infra |
| Rotate the admin token | Infra → Admin |
| Review the audit trail (patterns, injection attempts, error spikes) | Admin |
| Review feature flags (are all enabled features still wanted?) | Admin |

### Quarterly
| Task | Who |
|---|---|
| Re-run the full accuracy harness (50 golden Qs) + compare to previous | Dev |
| Review the dev team asks (`docs/DEV_TEAM_ASKS.md`) — any resolved? | Admin |
| Pen-test (VAPT) — re-run the pre-VAPT checklist (`docs/VAPT_READINESS.md` §3) | Dev + Infra |

### On each model update (v28, v29, etc.)
1. Dev: upload the new GGUF to the LLM instance.
2. Infra: update the systemd service → restart llama-cpp.
3. Dev: run the accuracy harness → verify no regressions.
4. Admin: verify `/api/health` → test a few questions via the mobile app.

### On each backend update (code change)
1. Dev: `git pull` → `pip install -r requirements.txt` → `pip-audit`.
2. Dev: run the 4 self-tests (§4.2).
3. Infra: `sudo systemctl restart ai-secretary`.
4. Infra: `curl https://chatbot.chaloschools.in/api/health` → verify `status: "ok"`.

---

## 8. Quick Reference

### The API endpoints

| Endpoint | Method | Auth | Purpose |
|---|---|---|---|
| `/api/health` | GET | None | Health check (public, for monitoring) |
| `/api/chat` | POST | User token | Run a question through the pipeline |
| `/api/branches` | POST | User token | List branches (for the picker) |
| `/api/validate` | POST | User token | Validate a SQL query (debug) |
| `/api/admin/features` | GET | Admin token | View feature flags |
| `/api/admin/features` | PUT | Admin token | Update feature flags |
| `/api/audit` | GET | Admin token | Fetch audit-trail rows (paginated, optional `outcome` filter) |
| `/api/audit/stats` | GET | Admin token | Aggregate audit stats (counts, avg latency, refused-by-stage) |
| `/api/audit` | DELETE | Admin token | Clear ALL audit-trail rows (used by the audit.html **Reset** button) |

**Total: 9 endpoints (4 user + 5 admin/audit).**

### The environment variables

| Var | Purpose | Set by |
|---|---|---|
| `AI_SECRETARY_AUTH_TOKENS` | User auth tokens (comma-separated) | Infra (Vault) |
| `AI_SECRETARY_ADMIN_TOKENS` | Admin auth tokens | Infra (Vault) |
| `AI_SECRETARY_TENANT_KEYS` | `DBPrefix:apikey` pairs | Infra (from dev team) |
| `AI_SECRETARY_CORS_ORIGINS` | Allowed CORS origins | Infra |
| `AI_SECRETARY_DEBUG` | `true` for debug (shows real errors); `false` for prod | Infra |
| `AI_SECRETARY_LLM_TIMEOUT` | LLM timeout in seconds (default 45) | Infra |
| `AI_SECRETARY_RATE_LIMIT_IP` | Per-IP rate limit (default 100/min) | Infra |
| `AI_SECRETARY_RATE_LIMIT_TOKEN` | Per-token rate limit (default 20/min) | Infra |
| `AI_SECRETARY_FEATURE_OVERRIDES` | Path to the feature overrides file | Infra |

### The documentation map (read in this order)

| When you're... | Read this |
|---|---|
| New to the project | `docs/HOW_IT_WORKS.md` |
| The mobile-app team | `docs/API_CONTRACT.md` |
| The infra team | This document (§3) + `docs/OCI_DEPLOYMENT.md` |
| The dev team | This document (§4) + `docs/HOW_IT_WORKS.md` |
| The admin | This document (§5) + `docs/ADMIN_CONFIG_UI.md` |
| Preparing for VAPT | `docs/VAPT_READINESS.md` |
| Investigating a failure | `docs/PRODUCTION_TRACE_OBSERVATIONS.md` + the audit trail |
| Planning the v28 retrain | `docs/INSTRUCTION_IMPROVEMENT.md` + `docs/PRODUCTION_TRACE_OBSERVATIONS.md` |
| Want the full picture | `docs/GUIDELINES.md` (the single source of truth) |

---

*This document is the consolidated guide. For depth on any topic, follow the links to the specific docs in `docs/`. For the latest project status, see `docs/PROJECT_STATUS.md`. For the session handoff, see `docs/SESSION_HANDOFF.md`.*

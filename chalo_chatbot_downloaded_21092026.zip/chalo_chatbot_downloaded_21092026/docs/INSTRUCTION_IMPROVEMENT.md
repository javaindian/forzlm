# Improving the Instruction (the Frozen System Prompt)

The "instruction" is the system prompt the model is trained on — the exact text that tells it what to do. The project owner asked: can we improve it? This doc analyzes the current instruction, explains why it's frozen, and proposes improvements for the v28 retrain.

---

## 1. The current instruction (verbatim)

```
You are a T-SQL expert for the ChaloSchools (V3_CHALO) school management
database. Convert the following natural language question into a single,
executable T-SQL query. Use @UserId (bound as a query parameter at runtime
from the logged-in user's session) to scope results to the branches that
user has access to via UserAccountRoleDetails.
```

This is the `FROZEN_SYSTEM_PROMPT` in `prepare_data.py` and the `_read_base_prompt` in the original `demo_runner.py`. The model was fine-tuned with this exact text in every training example's `instruction` field.

---

## 2. Why it's frozen (the constraint)

The model is **brittle to prompt changes**. The original code comments confirm this twice:
- "the old prompts/system_text_to_sql.txt prototype prompt caused a hallucinated locality-LIKE loop and dropped the @UserId scoping entirely" (2026-08-07).
- "appending a vocab block to the v13 model derailed it" (the round-1 finding).

The reason: the model was trained on exactly one instruction. Any deviation at runtime produces a distribution shift — the model generates out-of-distribution output (loops, dropped scoping, hallucinations).

**This means:** you cannot improve the instruction at runtime without retraining. Any improvement to the instruction MUST be accompanied by a retrain (v28) where every training example uses the new instruction.

---

## 3. Analysis of the current instruction

### What it does well
1. **Role:** "T-SQL expert for the ChaloSchools (V3_CHALO) school management database" — clear role, clear scope.
2. **Task:** "Convert the following natural language question into a single, executable T-SQL query" — unambiguous.
3. **Security:** "Use @UserId (bound as a query parameter at runtime from the logged-in user's session) to scope results to the branches that user has access to via UserAccountRoleDetails" — the branch-scoping is baked into the instruction.

### What it's missing (the gaps that caused real failures)

**Gap 1: No mention of fee terms vs exam terms.** The instruction doesn't tell the model that there are TWO different "term" concepts (fee terms in `TermMaster`, exam terms in `ExamTermMaster`). This is the root cause of the headline bug — the model has no signal to distinguish them.

**Gap 2: No mention of the current academic year.** The instruction tells the model to use `@UserId` for branch scoping, but says nothing about `@AcademicYearID`. So the model guesses or hardcodes the year (or omits the filter entirely — 149 v27 examples do this).

**Gap 3: No mention of the branch's real vocabulary.** The instruction doesn't tell the model to use the branch's real names for classes/subjects/sections/etc. The model writes the names it memorized during training, which may not match the branch's database.

**Gap 4: No mention of the business rules.** The instruction doesn't hint at the semantic rules (outstanding formula must subtract Lien_Amount, Structure_Type filter, ChequeStatus_ID filter, soft-delete column varies per table, etc.). The model has to infer these from the training examples — and 12.4% of those are wrong.

**Gap 5: No mention of soft-deletes.** The instruction doesn't tell the model that most tables have an `IsDeleted` column (and `ExamTermMaster` has `Deleted` instead). The model sometimes applies the wrong filter or omits it.

**Gap 6: No instruction on output format.** The instruction says "a single, executable T-SQL query" but doesn't say "no markdown fences, no explanation, no trailing semicolon" — the `clean_sql` function in `llm_client.py` has to strip these.

**Gap 7: No mention of what to refuse.** The instruction doesn't say "if the question is out of scope (not about school data), refuse with a message." The v27 training has 11 refusal examples for this, but the instruction itself doesn't mention refusals.

---

## 4. The proposed improved instruction (for the v28 retrain)

This is the instruction I'd recommend for v28. It's longer (the model can handle a longer instruction if trained on it), addresses all 7 gaps, and is compatible with the FULL vocab-injection mode.

```
You are a T-SQL expert for the ChaloSchools (V3_CHALO) school management
database. Your job: convert the user's natural-language question into a
single, executable T-SQL SELECT query.

SECURITY (always do this):
- Use @UserId (bound at runtime from the logged-in user's session) to scope
  results to the branches the user can access via UserAccountRoleDetails.
  Always include this scoping subquery in every query:
  BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId
  AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
  UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster
  WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId)
  AND (IsDeleted IS NULL OR IsDeleted = 0))
- Use @AcademicYearID (bound at runtime) for the current academic year. Never
  hardcode the year; never use YEAR(GETDATE()) (the academic year crosses the
  calendar-year boundary).

TWO TERM CONCEPTS (do not confuse them):
- FEE terms live in TermMaster (columns: StartingDate, EndingDate, IsDeleted).
  Fee tables (FeesInformationStudentDetail, FeesCollection_Details, BusFeeStrucure,
  HostelFeeStructure) join Term_ID → TermMaster.ID.
- EXAM terms live in ExamTermMaster (columns: StartDate, EndDate, Deleted — note:
  NOT IsDeleted). Exam tables (ExamTypeMaster, StudentMarkMaster) join TermID →
  ExamTermMaster.ID.
- Never join a fee table to ExamTermMaster, and never join an exam table to TermMaster.

OUTSTANDING FORMULA (for fee-outstanding queries):
  Outstanding = Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)
  Always subtract Lien_Amount. Filter: Structure_Type IN ('Academic', 'Optional'),
  IsIncludedInLumpSum = 0, IsDonation = 0.

FEE COLLECTION:
- Use FeesCollection.Receipt_Amt (not "Amt" — that column doesn't exist).
- Filter ChequeStatus_ID NOT IN (3, 4) (3 = bounced, 4 = cancelled).

SOFT-DELETES:
- Most tables: (IsDeleted IS NULL OR IsDeleted = 0).
- ExamTermMaster uses "Deleted", not "IsDeleted".

USE THE BRANCH'S REAL VOCABULARY:
- The branch's real Classes, Sections, Subjects, FeeHeads, ExamTerms, FeeTerms are
  listed in the context block below (if present). Use those EXACT names in your SQL
  literals. Do not invent or approximate.

OUTPUT FORMAT:
- Output ONLY the T-SQL query. No markdown fences, no explanation, no trailing
  semicolon.
- A single SELECT statement (or a single WITH ... SELECT for CTEs).

REFUSAL:
- If the question is not about school data (e.g. "write a poem", "what is the
  capital of France"), or asks for a write operation (INSERT/UPDATE/DELETE/DROP),
  output a SELECT that returns a single row with a Message column explaining
  the refusal.

[OPTIONAL — for FULL vocab-injection mode, the following block is appended:]
This branch's real master-data values (use these EXACT names, do not invent):
- Classes: <from Context JSON>
- Sections: <from Context JSON>
- Subjects: <from Context JSON>
- Fee heads: <from Context JSON>
- Exam terms: <from Context JSON>
- Fee terms: <from Context JSON>
```

---

## 5. The risk of changing the instruction

**The v27 model will derail on this instruction at runtime** — it's too different from what it was trained on. So this instruction is ONLY for the v28 retrain, where every training example uses this new instruction in its `instruction` field.

**For v28, the retrain process is:**
1. Update `prepare_data.py`'s `FROZEN_SYSTEM_PROMPT` to the new instruction.
2. For FULL mode: prepend the vocab block (per-branch) to the instruction in every training example.
3. Regenerate the training JSONL with the new instruction.
4. Run the `prepare_data.py` gate (must pass with 0 HIGH violations — the 480 flagged examples need cleaning first).
5. Fine-tune with the §F parameters (r=16, dropout=0.05, lr=1e-4, warmup 35, MAX_SEQ_LENGTH 2560, epochs 2).
6. Run the accuracy harness (50 golden Qs) — must meet the §7 targets.
7. Deploy with `inject_vocab: true` (FULL mode) in config.

---

## 6. What to do TODAY (with the v27 model)

**Do NOT change the runtime instruction.** The v27 model needs the exact text it was trained on. The improvements (the semantic engine, the vocab engine's STOPGAP mode, the `@AcademicYearID` injection, the validate-and-substitute path) all happen OUTSIDE the instruction — in the pipeline stages that run after the model generates SQL.

The instruction stays frozen until v28. The pipeline does the heavy lifting. After v28, the improved instruction + FULL vocab injection will let the model do more of the work itself (and the pipeline becomes a thinner safety net).

---

## 7. The bottom line

The current instruction is minimal — it works, but it leaves the model to infer a lot (term disambiguation, academic year, business rules, vocab). The v27 model infers these from training, and 12.4% of the time it infers wrong. The pipeline's semantic engine + vocab engine catch the wrong inferences at runtime.

The improved instruction (for v28) tells the model the rules explicitly — the two term concepts, the outstanding formula, the soft-delete variation, the refusal format. Combined with FULL vocab injection, the model should make fewer wrong inferences, and the pipeline's semantic engine catches the residual ones.

**The instruction is frozen for v27. It's improvable for v28. The improvement requires the retrain. Don't change it at runtime.**

# ChaloSchools AI Secretary — Fix Guidelines (Single Source of Truth)

**Purpose:** One document that captures every confirmed problem, its impact, and the mitigation. Maintain this alongside your codebase; when something changes, update here first.

**Current model version:** v27 (per `training_dataset_final_v27.jsonl`). The "v28" referenced below means "the next version after v27" — pick your own naming.

**Scope:** Text-to-SQL chatbot for school management. Fine-tuned Qwen 2.5 Coder 7B Instruct → T-SQL over the V3_CHALO database. Runs on CPU. Stored procedures are NOT callable in production (used only by the AI agent that generated the training labels). RBAC is a hard requirement. Sensitive/credential tables must be excluded.

---

## Table of Contents

- [A. Executive Summary](#a-executive-summary)
- [B. The Three Confirmed Failures (with root causes)](#b-the-three-confirmed-failures-with-root-causes)
- [C. The Problem Catalog](#c-the-problem-catalog)
  - [C1. Semantic correctness — the central gap](#c1-semantic-correctness--the-central-gap)
  - [C2. RBAC and security](#c2-rbac-and-security)
  - [C3. Hallucination vectors](#c3-hallucination-vectors)
  - [C4. Latency](#c4-latency)
  - [C5. Coverage](#c5-coverage)
  - [C6. Training data quality](#c6-training-data-quality)
  - [C7. The section-concept problem](#c7-the-section-concept-problem)
- [D. Mitigation Plan (priority-ordered, no code)](#d-mitigation-plan-priority-ordered-no-code)
  - [D1. Pipeline changes](#d1-pipeline-changes)
  - [D2. Data changes](#d2-data-changes)
  - [D3. The v28 retrain (vocab-aware)](#d3-the-v28-retrain-vocab-aware)
  - [D4. Evaluation harness design](#d4-evaluation-harness-design)
  - [D5. Deep RBAC — class-teacher row-level scoping](#d5-deep-rbac--class-teacher-row-level-scoping)
  - [D6. Triage methodology for flagged examples](#d6-triage-methodology-for-flagged-examples)
- [E. Maintenance](#e-maintenance)

---

## A. Executive Summary

The pipeline has solid **structural** safety: SELECT-only enforcement, parameterized binding, schema-existence guardrail, alias-scope check, branch-scoping gate, value-membership validation. These all work and were verified against live traces.

The pipeline has **no semantic-verification layer**. A query can be syntactically valid, schema-correct, branch-scoped, value-validated — and still return **wrong or empty data**. This is the central project-failure risk, and it is the root cause of all three confirmed failures.

**The single most important fact:** 12.4% of your v27 training labels (480 of 3,867 examples) contain semantic bugs that pass every existing gate and execute as confident wrong answers. The model is learning these bugs. Until a semantic-verification layer exists between VALIDATE and EXECUTE, and until the training labels are cleaned, every reported "wrong answer" could be either a model mistake or a correctly-reproduced-but-wrong training label — and you cannot tell which without manual inspection.

**The fix strategy, in one line:** add a deterministic semantic-rules engine to the pipeline (catches wrong answers at runtime), clean the training labels (stops teaching wrong answers), and retrain a vocab-aware version (lets the model write the right literal per branch at generation time). All three are needed; any one alone is insufficient.

---

## B. The Three Confirmed Failures (with root causes)

### B1. "Fee outstanding of the current term" mixes up fee term and exam term

**Symptom:** The query fails or returns wrong data when asking about the current fee term.

**Root cause (proven from the data):** The bug is NOT a `JOIN ExamTermMaster` mistake baked into training (0 of 1,097 fee queries do that). It's an **inference-time generalization gap**. The v27 dataset has only **2 fee examples** that resolve "current term" by a date window on `TermMaster` (`GETDATE() BETWEEN tm.StartingDate AND tm.EndingDate`). Both are about *collection*, not *outstanding*. The Examinations module has 119 examples using the analogous exam-term date window (`ExamTermMaster.StartDate/EndDate`). With only 2 anchors for the fee date-window pattern, the model reaches for the better-anchored exam-term pattern — cross-module contamination.

**Impact:** Every "current term fee outstanding / defaulters / pending" question is at risk of producing a query that joins `ExamTermMaster` instead of `TermMaster`, returns zero or wrong rows, and is presented as a confident `ANSWER`.

**Mitigation:** Add 20–30 "current term fee outstanding" training examples that join `TermMaster` with the date window AND use the full outstanding formula (`Amount - Concession - Paid - Lien`, `Structure_Type IN ('Academic','Optional')`, `IsIncludedInLumpSum = 0`). This anchors the fee date-window pattern as strongly as the exam pattern. See D2.

### B2. "Who is the principal / what is the principal name" → refused

**Symptom:** Refused at the GUARDRAIL stage after one retry.

**Root cause (proven from a live trace):** The model hallucinated `Branch_Academic_Details.Principal_ID` — a column that does not exist. The guardrail caught it correctly on both attempts. The real column is `BranchMaster.Principal` (a denormalized string holding the principal's name directly on the branch record). Only 2 v27 examples use this column (L3645 "list all my branches with their principal names", L3650 "show the principal of the Besant Nagar branch"), both using the **list/show** phrasing. There are **zero** examples for the **"who is / what is"** phrasing. With no close neighbor, the model generalizes to a relational guess (there must be a Principal_ID that joins to a staff table) and invents the column.

**Impact:** Any "who is the principal" / "what is the principal name" / "name of the principal" phrasing fails. The guardrail is working correctly — the failure is a training-coverage gap.

**Mitigation:** Add ~10 training examples covering the "who is / what is the principal [of my branch]" phrasing that `SELECT bm.Principal` directly, reusing the L3650 SQL shape minus the name filter. See D2.

### B3. "Who teaches maths in class 8A" → refused at VALIDATE

**Symptom:** Refused: "'A' not recognized as a section at your branch."

**Root cause (proven from a live trace + the branch's real vocab):** The model's SQL was structurally perfect (passed guardrail, alias-scope, branch-scoping). The class hedge `('Class 8','VIII')` was correct; the subject `'Maths'` validated OK (this branch stores `'Maths'` exactly). The only failure was `secm.Name = 'A'`. The validate stage's candidates — the branch's real section vocab — were:
`All; BRAINY; EXPERT; FOUNDATION; FOUNDATION 1; FOUNDATION 2; INTELLIGENT; New Admission; TALENTED; TALENTED 1`

**Your branch does not use lettered sections.** `SectionMaster` for this branch contains ability-stream names, not A/B/C/D. Every v27 example that writes `secm.Name = 'A'/'B'/'C'/'D'` cannot match a single row in this branch's data.

**Impact:** Every section-based query fails for this branch. The model literally cannot answer "8A" because there is no "A" section. This is a **data-reality mismatch**, not a pipeline bug and not a model bug — the validate stage is correctly refusing a non-existent section.

**Mitigation (your decision: Option A — retrain vocab-aware):** The structurally correct fix is to retrain with the branch vocabulary block injected into the system prompt, so the model writes real section literals (`secm.Name = 'TALENTED'`) instead of guessing `'A'`. This also fixes the subject-casing issue for all branches in one shot. See D3.

**Secondary question for your dev team:** is `SectionMaster` actually the right table for this branch's sections, or do real sections live in `ClassSectionMasterMapping` / `ClassTermAssignment`? The "All" and "New Admission" rows in the vocab suggest `SectionMaster` may be contaminated or repurposed at this branch. Confirm before retraining.

---

## C. The Problem Catalog

Each problem below is stated as: **Problem · Impact · Mitigation (summary)**. Full mitigations are in §D.

### C1. Semantic correctness — the central gap

**Problem:** No pipeline stage verifies that a query is *semantically* correct. The existing stages verify structure (tables/columns exist, aliases in scope, branch scoping present, value is a real vocab member) but not meaning (right term master joined, right outstanding formula, right filters present, right academic-year resolution).

**Concrete semantic traps the pipeline cannot catch (each proven to exist in v27):**
1. Fee table joined to `ExamTermMaster` instead of `TermMaster` (the §B1 bug).
2. Academic-year filter omitted — returns all-time data (149 v27 examples).
3. `Structure_Type` filter omitted or over-applied — includes hostel/bus/misc (378 v27 examples).
4. `IsIncludedInLumpSum = 0` omitted — double-counts lump-sum rows (18 v27 examples).
5. TC-issued students not excluded — ghosts in outstanding.
6. `Lien_Amount` not subtracted from the outstanding formula — overstates what's owed (refined count in the rules engine).
7. `ChequeStatus_ID NOT IN (3,4)` omitted on `FeesCollection` — bounced/cancelled cheques counted as collected (4 v27 examples).
8. Soft-delete applied to the wrong table — `ExamTermMaster` uses `Deleted`, not `IsDeleted`; `DonationFeesCollection` never applies the filter.
9. `Student_Master` read for `ClassID`/`SectionID`/`AcademicYearID` — those columns don't exist there (they're on `StudentAcademicDetail`).
10. Misspelled `BusFeeStrucure` auto-corrected to `BusFeeStructure` — the production table is misspelled; the correct spelling doesn't exist.
11. Deprecated table twins used — `EnquiryMaster` (stale) vs `GeneralCallRegister` (live), `Department_Master` vs `StaffDepartmentMaster`, `PurchaseRequest` vs `IPurchaseRequest`, `Academic_Month_Master` vs `Month_Master`.
12. `Get_TermList` SP called for fee-term lookups — it reads from `ExamTermMaster` despite its generic name (the smoking gun behind fee/exam confusion).
13. Late-fee rows not UNIONed into outstanding — `GetFeePendingByFeesInformationStudentDetail` UNIONs a separate late-fee computation; naive outstanding queries miss late fees entirely.
14. `Receipt_Amt` vs hallucinated `Amt` on `FeesCollection` — there is no `Amt` column.
15. Current academic year resolved via `YEAR(GETDATE())` — academic year crosses the calendar-year boundary.
16. Month numbering assumed calendar-based — `Month_Master.Month_No` is board/branch-aware (CBSE April=1, matric June=1).

**Impact:** 12.4% of v27 training labels contain at least one of these (480 of 3,867 examples). The model learns and reproduces them. Every reported "wrong answer" is potentially a correctly-reproduced-but-wrong training label.

**Mitigation summary:** Add a deterministic semantic-rules engine between VALIDATE and EXECUTE (D1); clean the training labels (D2); the engine catches residual model mistakes at runtime, the clean labels stop teaching the bugs.

### C2. RBAC and security

**Problem — branch scoping:**
- The branch-scoping gate is a single regex requiring `UserAccountRoleDetails WHERE UserID = @UserId` with a preceding `IN`. It does not detect an `OR` that widens scope (`OR BranchID = 999` passes).
- It doesn't verify the super-user `UNION` (with `EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID=@UserId AND IsSuperUser=1)`) is present. For a super-user, a query omitting this returns zero branches (safe but wrong).
- It can refuse valid CTE-form scoping (used by the entire Enquiry module, 134 examples) if the CTE isn't referenced via `IN (SELECT ... FROM <cte>)`.

**Problem — RBAC bypass on retry:** When execution fails in `local_db` mode, the orchestrator regenerates SQL and re-runs `guardrail` + `bind` — but does NOT re-run `check_branch_scoping` on the retried SQL. A retry that drops the `@UserId` scoping subquery (but still mentions `@UserId` somewhere, satisfying binder parity) can execute unscoped. This is a real privilege-escalation path under failure conditions.

**Problem — row/class-level RBAC absent:** `UserRoleClassMapping` (class-scoped roles), `Role_Privilege_Details`, `Screen_Privilege_Details` exist in the schema but the chatbot only scopes by branch. A class-teacher role that should only see their class's students is not enforced — the query returns all classes in their branch. The schema audit explicitly flags whether read-access restriction exists at all as OPEN.

**Problem — sensitive tables not blocked:** `UserAccountMaster.Password/Token`, `BranchMaster.SGC_Password/SGC_UserId/APIKey`, `StorageConfiguration`, `SMS_ConfigurationSettings`, `WhatsAppConfiguration`, `Student_Master_Draft.Password/Token`, `PasswordRecovery`, payment tables — are not in any hard-blocked list. `SELECT Password FROM UserAccountMaster` would execute today (it's a SELECT; the blocked-keyword list blocks verbs, not sensitive columns/tables). v27 training is clean on this (0 sensitive references), but defense in depth requires the blocklist.

**Problem — one confirmed RBAC violation in v27:** L3732 "show me the salary structure template for employee ID 5" has NO branch scoping. `EmployeeSalaryDetails` has `BranchID` but it's not filtered. A staff member can query any branch's salary. The model learned this pattern.

**Problem — multi-branch correctness unverified:** The dev team confirmed branch data is "strictly separated" verbally with no concrete multi-branch test. `TENANT_API_KEY_MAP` has only one real key (`V3_TestDatabase`); the `V3_GG` key is a TODO. Cross-tenant behavior is unverified.

**Impact:** Cross-branch data leak (salary, fees, student PII). Potential credential disclosure if a user asks the wrong question. Privilege escalation under failure-retry conditions. Non-compliance with your stated RBAC requirement.

**Mitigation summary:** Add a sensitive-object blocklist to the guardrail (D1). Re-run branch-scoping on every retried SQL (D1). Implement class-teacher row-level scoping via `UserRoleClassMapping` (D5). Fix L3732 in the training data (D2). Verify multi-tenant isolation with a real two-user test before going live.

### C3. Hallucination vectors

**Problem — `inject_vocab` is OFF by default:** The model gets no runtime branch vocabulary. It must recall Class/Section/Subject/FeeHead/ExamTerm literals from training weights. For a branch whose literals differ from training, the model emits the trained literal, VALIDATE catches the mismatch (if the alias matches) → disambiguation/refusal. The user perceives this as "refused to answer."

**Problem — VALIDATE coverage is regex-brittle:** The entity extractor only catches literals written as `alias.Name = '...'` for six fixed alias sets. It explicitly excludes `s.` (Student_Master vs Subject_Master ambiguity) and `et.` (ExamTypeMaster vs ExamTermMaster ambiguity). Values in JOINs, CASE, IN-lists (for non-CLASS/SECTION concepts), numeric FKs, or any other alias are never validated.

**Problem — model is brittle to prompt changes (confirmed twice in code comments):** Expanding the system prompt caused a "hallucinated locality-LIKE loop and dropped @UserId scoping". The execute-error retry appends raw DB error text to the prompt — which is a prompt change. So the retry meant to fix a failure can itself trigger the derailment mode.

**Problem — no `max_tokens` truncation guard:** `max_tokens=512`. A complex fee-outstanding query with the full scoping UNION, multiple JOINs, and a HAVING clause can exceed 512 tokens. 110 v27 examples are over ~480 tokens. A truncated SQL string is syntactically broken → guardrail/execute fail → retry → another 512-token attempt. No detection of "output was truncated" (no `finish_reason` check).

**Problem — fast-paths replay unverified training SQL verbatim:** `dataset_lookup` and the four template lookups bypass the LLM and trust training SQL. Since v27 training SQL is 12.4% semantically wrong, the cache silently serves wrong queries with zero LLM cost and zero semantic check. The fast-path is a semantic-error amplifier.

**Problem — deprecated/live twin tables are pure hallucination bait:** The model picks whichever twin it saw more in training. v27 has 17 examples using `EnquiryMaster` (deprecated) — these should use `GeneralCallRegister`.

**Problem — cross-document inconsistencies seed hallucinations:** 22 inconsistencies between the schema txt, the xlsx docs, and the PDF (e.g. the PDF claims "no SPs confirmed" while the SP xlsx has 1,095). The training corpus likely contains contradictory signals.

**Impact:** Wrong literals → disambiguation → "refused to answer" UX. Truncation → broken SQL → retry loops → 30–80s CPU latency. Fast-paths → silent wrong answers. Deprecated twins → queries against stale tables.

**Mitigation summary:** Retrain vocab-aware (D3, fixes the injection issue at the root). Switch to CTE-form scoping to cut query length 30–50% (D1, fixes truncation + latency). Disable fast-paths until labels are cleaned (D2). Add a `finish_reason == 'length'` truncation guard (D1).

### C4. Latency

**Problem — LLM is the dominant cost on CPU:** Qwen-7B on CPU is ~5–30s per generation. No output streaming, no speculative decoding, no KV-cache reuse across requests (each question is a fresh chat-completions POST).

**Problem — sequential pagination:** `api_wrapper` auto-pages up to `max_auto_pages` (default 5 = 50 rows). Each page is a separate sequential HTTP round-trip with double JSON-encoding + double-decode. A 200-row answer = 5 sequential calls before the user sees anything.

**Problem — retry doubles latency on failure:** Guardrail failure → one extra LLM call. Execute failure → one extra LLM call + re-bind + re-execute. Both sequential. Worst case: 3 LLM calls + 2 executions serially.

**Problem — `local_db` opens a fresh pyodbc connection per query:** No connection pool. Connection setup (auth + driver handshake) is 100–500ms each, repeated per query and per retry.

**Problem — no result caching:** Only question-level exact-match is cached. No (question+branch+user) tuple cache, no LLM-output cache, no computed-answer cache. Re-asking the same question for a different branch re-runs the LLM.

**Problem — Sections fallback runs a synchronous pyodbc query per branch** on every context fetch because the real API doesn't return Sections yet. For a 5-branch user that's 5 sequential DB calls before the first query even starts.

**Impact:** 10–40s for a typical query on CPU; 30–80s for complex/truncated/retry cases. UX is poor.

**Mitigation summary:** CTE-form scoping cuts generation time 30–50% (D1). Cache (question, branch, user) → result in memory (D1). Prefetch pages in parallel for `api_wrapper` (D1). Connection pool for `local_db` (D1). The vocab-aware retrain (D3) doesn't directly help latency but reduces disambiguation round-trips.

### C5. Coverage

**Module coverage in v27 (3,867 examples):**

| Module | Examples | % | Risk |
|---|---:|---:|---|
| Fees | 1,097 | 28.4% | largest, most error-prone (30.4% flagged by rules engine) |
| Students | 731 | 18.9% | ok volume |
| Other (refusals + uncategorized) | 466 | 12.0% | mixed |
| Staff | 458 | 11.8% | clean |
| Administration | 321 | 8.3% | 11.5% flagged |
| Admissions | 224 | 5.8% | 8.1% flagged |
| Transport | 163 | 4.2% | clean |
| Examinations | 119 | 3.1% | clean |
| Payroll | 84 | 2.2% | 1 RBAC violation (L3732) |
| Parent Feedback | 56 | 1.4% | thin |
| General Enquiries | 53 | 1.4% | 30.2% flagged |
| Circulars | 42 | 1.1% | thin |
| Home Works | 37 | 1.0% | thin |
| **Inventory** | **8** | **0.2%** | **dangerously thin — hallucination bait** |
| **Communication** | **8** | **0.2%** | **dangerously thin — hallucination bait** |

**Impact:** Inventory and Communication (8 examples each) have near-zero training signal. Any question in those modules will be a near-distributional guess. Parent Feedback, Circulars, Home Works, General Enquiries are also thin.

**Mitigation summary:** Either add 30–50 examples each for Inventory/Communication, or explicitly declare those modules out-of-scope and route to a refusal. Don't ship thin modules as "supported" — the model will hallucinate.

### C6. Training data quality

**Problem — 12.4% of v27 labels are semantically wrong** (480 of 3,867, per the rules engine). The labels were AI-generated from the SPs, so any semantic mistake the generator made is baked in. Notable subsets:
- 378 fee queries missing `Structure_Type` filter.
- 149 fee queries missing the academic-year filter (~half are real bugs; the other half are date-scoped queries where it's redundant).
- 36 missing `Lien_Amount` in the outstanding formula.
- 18 missing `IsIncludedInLumpSum = 0`.
- 4 missing `ChequeStatus_ID` on `FeesCollection`.
- 2 using the wrong date window for current-term fee.
- 1 RBAC violation (L3732, salary).
- 17 using deprecated `EnquiryMaster`.

**Problem — ground-truth SPs themselves have bugs:** 6 confirmed inconsistencies in the reference SPs (the SPs the labels were generated from). The most important: `sp_ClasswiseOutstandingCountReport` omits `Lien_Amount` (the canonical wrong-answer bug exists in the ground truth); `Get_TermList` reads from `ExamTermMaster` despite its generic name. The label generator likely propagated these.

**Problem — synonym store is CLASS-only:** `concept_store.db` has 86 synonyms, all for `CLASS` (GRADE_1..12 → "Class N", "Nth", Roman numerals). Zero for `SUBJECT`, `SECTION`, `ENQUIRY_STATUS`, `FEE_HEAD`, `EXAM_TERM`. No `FEE_TERM` concept type exists. So "maths" → "MATHS" has no synonym path; it goes straight to a case-sensitive branch-vocab check and routes to disambiguation.

**Impact:** The model learns wrong semantics. Fast-paths replay the wrong SQL. Users see wrong answers or disambiguation prompts for simple questions.

**Mitigation summary:** Clean the 480 flagged examples (D2, D6). Populate synonyms for all five existing concept types + add `FEE_TERM` (D1). Audit the generator pipeline so v28 labels don't reintroduce the same bugs.

### C7. The section-concept problem

**Problem:** Your branch (branch 1, CHALO INTERNATIONAL SCHOOL) does not use lettered sections. `SectionMaster` for this branch contains ability-stream names: BRAINY, EXPERT, FOUNDATION, FOUNDATION 1, FOUNDATION 2, INTELLIGENT, TALENTED, TALENTED 1, plus junk rows ("All", "New Admission"). Every v27 example that writes `secm.Name = 'A'/'B'/'C'/'D'` cannot match a single row.

**This is a data-reality mismatch, not a pipeline or model bug.** The validate stage is correctly refusing non-existent sections. The problem is upstream: the model never knew the branch's real sections because `inject_vocab` is off.

**Secondary question (unresolved):** is `SectionMaster` actually the right table for this branch's sections, or do real sections live in `ClassSectionMasterMapping` / `ClassTermAssignment`? The "All" and "New Admission" rows strongly suggest `SectionMaster` may be contaminated or repurposed. Confirm with your dev team before retraining.

**Impact:** Every section-based query fails for ability-stream branches. "Who teaches maths in 8A" is unanswerable as asked.

**Mitigation (your decision: Option A — retrain vocab-aware):** Retrain with the branch-vocab block injected into the system prompt, so the model writes real section literals at generation time. This also fixes the subject-casing issue for all branches in one shot. See D3. As a stopgap until the retrain lands, consider a pre-generation check: if the question has a "class + letter" pattern AND the branch has no single-letter sections, immediately return a clarifying prompt listing the real sections (avoids a wasted 10–30s CPU LLM call).

---

## D. Mitigation Plan (priority-ordered, no code)

### D1. Pipeline changes

These are changes to the Python pipeline code. I'm describing them as guidelines — what to change and why — not as code. Order by priority.

**D1.1 — Add a semantic-rules engine between VALIDATE and EXECUTE (HIGHEST PRIORITY).**
This is the single highest-leverage fix. A deterministic, regex-based rules engine that checks each generated query against the semantic rules mined from the 1,095 SPs. It runs on every query (including fast-path cache hits), adds <1ms per query, and converts every semantic violation into a structured REFUSED with a specific actionable message. The 20 highest-severity rules to start with (organized by module) are in the SP-mined catalog (`semantic_rules_catalog.md`, 78 rules total). Wire it in after the existing VALIDATE stage, before BIND. The engine should be pure-stdlib, dependency-free, and never crash the pipeline (wrap each rule in try/except, log crashes as MEDIUM violations).

**D1.2 — Add a sensitive-object blocklist to the guardrail.**
Hard-block SELECT against: `UserAccountMaster.Password`, `UserAccountMaster.Token`, `BranchMaster.SGC_Password`, `BranchMaster.SGC_UserId`, `BranchMaster.APIKey`, `StorageConfiguration` (whole table), `SMS_ConfigurationSettings` (whole table), `WhatsAppConfiguration` (whole table), `Student_Master_Draft.Password`, `Student_Master_Draft.Token`, `PasswordRecovery` (whole table), `PaymentConfiguration*`, `AirpayTXNDataTable`. Block both qualified (`alias.Password`) and bare (`SELECT Password FROM ...`) forms when an owner table is in scope. Fail closed. v27 training is clean on this, but defense in depth is required per your stated requirement.

**D1.3 — Inject `@AcademicYearID` as a trusted, derived parameter.**
The binder currently injects only `@UserId` and `@SelectedBranchId`. The Context JSON carries `AcademicYears` with `IsCurrentYear` — resolve the current academic-year ID for the selected branch from that, and inject it as `@AcademicYearID` exactly like `@UserId`. This stops the model from guessing or hardcoding the year (149 v27 examples omit the filter; the model must currently guess). The parameter should be trusted (from the Context JSON, never from user input) and bound via the existing parameterized mechanism.

**D1.4 — Fix VALIDATE to substitute the validated `database_value` back into the SQL.**
The current VALIDATE stage does `if validated: continue` — it does NOT rewrite the SQL literal. So if the model emits `CM.Name = 'Class 8'` and the branch stores `'VIII'`, the CLASS synonyms resolve it to `VALIDATED` with `database_value='VIII'`, but the SQL still says `'Class 8'`, the DB stores `'VIII'`, and the query returns zero rows as a confident ANSWER. When `matched_via == 'synonym_exact'`, rewrite the literal the model emitted into the branch's real literal. Either substitute, or refuse when the model's literal isn't already an exact member. This is a fundamental correctness fix.

**D1.5 — Re-run `check_branch_scoping` on every retried SQL.**
In `local_db` mode, when execution fails, the orchestrator regenerates SQL and re-runs guardrail + bind — but not branch-scoping. A retry that drops the `@UserId` scoping can execute unscoped. Add the branch-scoping check to the retry path. One-line change in the orchestrator's retry logic.

**D1.6 — Add a loud startup assertion that the guardrail loaded.**
The guardrail loads `schema_catalog.json` from CWD with a relative path. `_try_load_guardrail` swallows all exceptions and returns `None`. If the runtime CWD is wrong, the orchestrator silently runs with no schema guardrail at all. Add a startup health-check that fails fast and loudly if the catalog can't be opened, instead of silently degrading.

**D1.7 — Switch the branch-scoping boilerplate to CTE-form.**
Every v27 query repeats the ~400-char scoping subquery 2–3 times. A CTE form (`WITH AllowedBranches AS (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId ... UNION SELECT ID FROM BranchMaster WHERE ...)`) declared once and referenced via `IN (SELECT BranchID FROM AllowedBranches)` cuts query length 30–50%. This directly cuts CPU generation time 30–50%, eliminates most of the 110 truncation-risk examples, and the branch-scoping gate already supports CTE form. The Enquiry module (134 v27 examples) already uses CTE-form; standardize the rest. Update the system prompt / few-shot examples to use CTE-form, and regenerate the training data accordingly for v28.

**D1.8 — Add a `finish_reason == 'length'` truncation guard.**
If `max_tokens` is hit, refuse instead of executing broken SQL. Check the LLM response's `finish_reason` (the `llm_client` currently ignores it). On truncation, either retry with a shorter prompt (drop the error-append text) or refuse with "the query is too complex; please ask a more specific question."

**D1.9 — Disable fast-paths in production until labels are cleaned.**
`dataset_lookup` + the four template lookups replay v27 training SQL verbatim. 12.4% of that SQL is semantically wrong. Disable these fast-paths in production until D2 is complete. Re-enable after the labels are clean and the semantic-rules engine is in place (so even cached SQL is re-checked). On CPU, this trades latency for correctness — the right tradeoff until the labels are fixed.

**D1.10 — Add a (question, branch, user) → result cache.**
In-memory cache, keyed by (normalized question, selected branch, user id). Cuts repeat latency to zero for the same user re-asking. Invalidate on schema change or context refresh. This is additive — doesn't change correctness, just latency.

**D1.11 — Connection pool for `local_db` mode.**
`local_executor` opens a fresh pyodbc connection per query. Use a connection pool (or a single long-lived connection). Saves 100–500ms per query.

**D1.12 — Parallelize `api_wrapper` pagination.**
Currently sequential (up to 5 serial HTTP round-trips). Prefetch pages in parallel once `TotalRowCount` is known from the first page. Cuts a 200-row answer from 5 serial calls to ~1 round-trip's worth of latency.

**D1.13 — Populate the synonym store.**
`concept_store.db` has 86 CLASS synonyms only. Populate synonyms for `SUBJECT`, `SECTION`, `ENQUIRY_STATUS`, `FEE_HEAD`, `EXAM_TERM`, and add the missing `FEE_TERM` concept type end-to-end (Context JSON contract + concept type + entity extractor pattern + synonyms). This is the bridge fix until the vocab-aware retrain (D3) lands. After D3, the synonym store becomes less critical (the model writes the right literal at generation time), but it remains a useful fallback.

### D2. Data changes

These are changes to the training data. Guidelines, not generated files.

**D2.1 — Add 20–30 "current term fee outstanding" examples.**
All must: join `TermMaster tm ON tm.ID = f.Term_ID`; use `GETDATE() BETWEEN tm.StartingDate AND tm.EndingDate`; subtract `Lien_Amount` in the outstanding expression (`Amount - ISNULL(Concession_Amt,0) - ISNULL(Paid_Amt,0) - ISNULL(Lien_Amount,0)`); filter `Structure_Type IN ('Academic','Optional')` and `IsIncludedInLumpSum = 0`; exclude TC-issued students (`(sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL)`); scope academic year via `Branch_Academic_Details`. Cover: outstanding, pending, due, balance, defaulters list, collection percentage, collection amount, demand vs collected, concession, lien, top 10, class-wise, bus fee, hostel fee, fee-head-wise, percentage of demand. This anchors the fee date-window pattern as strongly as the exam pattern (currently 2 vs 119). Fixes the §B1 bug.

**D2.2 — Add ~10 "who is the principal" examples.**
All use `SELECT bm.Principal FROM BranchMaster bm` with the full scoping boilerplate. Phrasings: "who is the principal", "what is the principal name", "who is our principal", "name of the principal", "who is the principal of this branch", "current principal name", "tell me the principal's name", "who is the head of this school", "principal name please", "who's the principal of my branch". Fixes the §B2 hallucination.

**D2.3 — Add ~15 "who teaches" examples with mixed section naming.**
Mix of lettered sections (8A, 8B, 9C) AND named/ability-stream sections (TALENTED, EXPERT, FOUNDATION, INTELLIGENT, BRAINY) across classes 7–12 and 5 subjects. This teaches the model that section names vary by branch — preparation for the Option A retrain. Uses `SubjectAllocation_Master` + the full scoping boilerplate. (Note: for branches that store subjects as `'MATHS'` uppercase, the examples should use the branch's real casing — or rely on D1.13 synonyms + D1.4 validate-substitute to handle the mapping.)

**D2.4 — Fix the 480 flagged examples.**
Triage methodology in D6. The biggest buckets: 378 missing `Structure_Type` (add `AND Structure_Type IN ('Academic','Optional')` to academic-fee queries; leave bus/hostel/donation queries alone), 149 missing academic-year filter (add the `Branch_Academic_Details` subquery to outstanding/demand queries; leave date-scoped queries alone), 36 missing `Lien_Amount`, 18 missing `IsIncludedInLumpSum`, 4 missing `ChequeStatus`, 1 RBAC violation (L3732 — add branch scoping), 17 using `EnquiryMaster` (rewrite to `GeneralCallRegister`).

**D2.5 — Fix L3732 specifically (RBAC violation).**
"show me the salary structure template for employee ID 5" — add `AND esd.BranchID IN (<scoping boilerplate>)`. This is the one confirmed cross-branch data leak in v27.

**D2.6 — Decide on Inventory and Communication.**
Either add 30–50 examples each (with hand-verified SQL, not AI-generated, since the AI generator had almost no signal), or declare them out-of-scope and add explicit refusal examples ("I can't answer inventory questions; please use the inventory module"). Don't ship 8-example modules as "supported."

**D2.7 — Audit the label generator pipeline.**
The labels were AI-generated from the SPs. The 6 INCONSISTENT rules (ground-truth bugs in the SPs themselves, listed in the catalog) likely propagated into the labels. Before regenerating v28, fix the generator to: (a) always include the full scoping boilerplate; (b) always filter `Structure_Type` for academic-fee queries; (c) always subtract `Lien_Amount` in outstanding formulas; (d) always resolve academic year via `Branch_Academic_Details`; (e) never use deprecated tables. Run the semantic-rules engine (D1.1) as a pre-commit check on every generated label.

### D3. The v28 retrain (vocab-aware)

This is the Option A fix for the section-concept problem (C7) and the hallucination vectors (C3). It's the structurally correct long-term fix.

**D3.1 — Regenerate the training data with the vocab block prepended.**
The v27 model was trained WITHOUT a vocab block in the system prompt, so appending one at runtime "derailed it" (per code comments). The v28 retrain must be trained WITH the vocab block. The exact prompt format: the frozen base prompt (from `demo_runner._read_base_prompt`) + the branch-vocab block (from `context_vocab.build_injection_prompt`). The vocab block lists the branch's real Classes, Sections, Subjects, EnquiryStatuses, FeeHeads, ExamTerms, AND FeeTerms (the missing concept type). Regenerate every v27 example with the appropriate vocab block prepended (each example needs a branch context — use the sample contexts or generate per-branch variants).

**D3.2 — Confirm the Context JSON contract carries FeeTerms.**
The current Context JSON (`demo_runner._sample_context`) injects `ExamTerms` but has no `FeeTerms` key. Add `FeeTerms` to the contract (request from the dev team's `GetUserContext` API, sourced from `TermMaster.Name` for the branch). Without this, the vocab block can't list fee terms and the model still won't know they exist.

**D3.3 — Confirm `SectionMaster` is the right section source for ability-stream branches.**
The "All" and "New Admission" rows suggest `SectionMaster` may be contaminated. Confirm with your dev team whether real sections live in `SectionMaster` or in `ClassSectionMasterMapping` / `ClassTermAssignment`. If a different table is the right source, update the `_merge_local_sections` fallback query before regenerating training data.

**D3.4 — Retrain.**
Fine-tune Qwen 2.5 Coder 7B Instruct on the regenerated dataset with the vocab block in every example's system prompt. Use the same generation params as v27 (temperature 0.1, max_tokens 512, repeat_penalty 1.1). After retraining, turn `inject_vocab` ON in the orchestrator (it's currently OFF by default).

**D3.5 — Verify with the evaluation harness (D4).**
Before shipping v28, run the evaluation harness (D4) against both v27 and v28. v28 must show: (a) no regressions on queries v27 answered correctly, (b) the three confirmed failures now answer correctly, (c) the semantic-rules engine flag rate on v28-generated SQL is near-zero.

### D4. Evaluation harness design

You need a way to measure v27 vs v28 objectively. Here's the design (describe, not code).

**D4.1 — Golden question set (50 questions).**
Hand-curate 50 questions across all 14 modules, weighted by real-world frequency. Include:
- The 3 confirmed failures (fee outstanding current term, who is the principal, who teaches maths in 8A).
- 10 fee questions (mix of current-term, term-wise, class-wise, defaulters, collection).
- 5 student questions (class, section, attendance, TC, promotion).
- 5 staff questions (designation, department, class teacher).
- 5 admission/enquiry questions.
- 5 exam questions (including exam-term to confirm no fee/exam contamination the other way).
- 3 transport questions (bus fee, route, vehicle).
- 3 payroll questions (with branch scoping verified).
- 3 inventory/communication questions (to confirm they refuse cleanly if out-of-scope).
- 5 edge cases (out-of-scope questions that should refuse, prompt-injection attempts, multi-branch user questions).
For each, hand-write the expected SQL AND the expected outcome (ANSWER with specific columns/row-count sanity, or REFUSED with a specific reason).

**D4.2 — Scoring rubric.**
For each golden question, score the model's output on:
- **Structural pass:** does it pass guardrail + alias-scope + branch-scoping + validate + the new semantic-rules engine? (binary)
- **Semantic match:** does the generated SQL match the expected SQL's semantic intent (same tables joined, same filters, same formula)? Not a string match — a semantic equivalence. (3-point scale: correct, partially correct, wrong.)
- **Outcome match:** does the pipeline outcome match the expected outcome (ANSWER with sane rows, or REFUSED with the right reason)? (binary)
- **Latency:** generation time on CPU. (numeric, for tracking.)

**D4.3 — Run protocol.**
Run the 50 questions against v27, record scores. Run the same 50 against v28, record scores. Compare. v28 must show: (a) structural pass rate ≥ v27, (b) semantic match rate > v27 (especially on the 3 confirmed failures), (c) outcome match rate > v27, (d) no regressions (any question v27 answered correctly, v28 must also answer correctly).

**D4.4 — Regression prevention.**
Add the 50 golden questions as a CI check. Every model version must pass the harness before shipping. The semantic-rules engine (D1.1) also runs as part of the harness — any v28-generated SQL that the engine flags is a failure.

**D4.5 — Don't use training examples as golden questions.**
The golden set must be held out — never used in training. Otherwise you're measuring memorization, not generalization.

### D5. Deep RBAC — class-teacher row-level scoping

Your RBAC requirement is "a hard requirement." Branch-level isn't enough if a class-teacher should only see their class. Here's the design.

**D5.1 — Understand the existing RBAC objects.**
- `UserAccountRoleDetails` (UserID, RoleID, BranchID, StaffID, IsPrimary) — the current scoping source (branch-level).
- `UserRoleClassMapping` (AcademicYearID, BranchID, StaffID, UserRoleID, ClassIDs as nvarchar CSV, ClassNames, IsDeleted) — the class-scoped role mapping. `ClassIDs` is a comma-separated list of class IDs the user/role is scoped to.
- `UserAccountRoleMaster` (ID, Name) — role names (Teacher, Principal, Accountant — real values not yet confirmed).
- `UserAccountMaster.IsSuperUser` — bypasses all scoping.

**D5.2 — The class-scoped scoping subquery.**
For a class-teacher (non-super-user with `UserRoleClassMapping` rows), the scoping should be: `BranchID IN (<existing branch scoping>) AND ClassID IN (SELECT value FROM dbo.SplitDelimited(ClassIDs, ',') FROM UserRoleClassMapping WHERE StaffID = @UserId AND AcademicYearID = @AcademicYearID AND IsDeleted = 0)`. This restricts results to the classes the user is assigned to. Super-users bypass this (see all classes in their branches).

**D5.3 — When to apply class scoping.**
Not every query needs class scoping — only queries that touch student/class data where a class-teacher's view should be restricted. The decision belongs in the semantic-rules engine or a separate "intent class" classifier: if the query is about students/marks/attendance/fees for a class, apply class scoping; if it's about branch-wide aggregates (total collection, branch summary), branch scoping alone is enough. This is a design decision — document which intents trigger class scoping.

**D5.4 — Inject `@AcademicYearID` first.**
Class scoping via `UserRoleClassMapping` requires `AcademicYearID`. D1.3 (inject `@AcademicYearID`) is a prerequisite.

**D5.5 — Confirm role names with the dev team.**
The schema audit flagged role-name vocabulary as OPEN. Before implementing class scoping, confirm the real role names in `UserAccountRoleMaster` (Teacher, Principal, Accountant, ClassTeacher, etc.) and which roles trigger class scoping vs full-branch access.

**D5.6 — Test with real multi-role users.**
Verify with a real class-teacher user that they see only their classes, and a real principal/admin that they see all classes. The `verify_branch_isolation` pattern in `user_context_api.py` is the model — a real, runnable check, not a trust exercise.

**D5.7 — Update the branch-scoping gate.**
The current gate checks for `UserAccountRoleDetails WHERE UserID = @UserId`. Class scoping adds a second check for `UserRoleClassMapping`. The gate should accept either (or both, depending on the intent class). Don't make the gate so strict that it refuses valid class-scoped queries.

### D6. Triage methodology for flagged examples

The semantic-rules engine flagged 480 of 3,867 v27 examples. Here's how to triage them.

**D6.1 — Use the violations CSV as the work list.**
The CSV (`semantic_rules_violations.csv`, 632 violation rows) has one row per (example, rule) pair. Sort by rule_id, then by line number. Triage rule-by-rule (all FEE-005 violations together, then all FEE-007, etc.) — the fix pattern is the same within a rule.

**D6.2 — Triage order (by count, highest impact first).**
1. **FEE-005 (378)** — missing `Structure_Type`. Fix: add `AND Structure_Type IN ('Academic','Optional')` to academic-fee queries. CAUTION: do NOT add it to bus-fee, hostel-fee, donation, or misc-fee queries — those need different `Structure_Type` values. Check the question intent before fixing. ~half of the 378 are pure academic-fee queries that need the filter; the rest are bus/hostel/donation that are false positives (the rule should be refined to exclude them).
2. **FEE-007 (149)** — missing academic-year filter. Fix: add `AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (<scoping>))` to outstanding/demand queries. CAUTION: skip queries that are already date-scoped (today, this month, last 7 days) — those don't need the academic-year filter.
3. **WRITE-VERB (44)** — these are refusal messages (poem, joke, capital-of-France) that start with a `--` comment then a SELECT. The rules engine flags them because the comment contains a write verb. NOT real bugs — refine the rule to skip SQL that starts with `--` (refusal pattern). Or leave them; they don't execute write verbs.
4. **MULTI-STMT (36)** — semicolons inside subquery IN-lists, not real multi-statement. NOT real bugs — refine the rule to strip string literals before counting semicolons (the current audit script does this; the rules engine should too).
5. **FEE-004 (18)** — missing `IsIncludedInLumpSum = 0`. Fix: add to outstanding queries.
6. **FEE-001 (refined)** — missing `Lien_Amount` in outstanding formulas. Fix: add `ISNULL(Lien_Amount,0)` to the subtraction.
7. **FEE-011 (4)** — missing `ChequeStatus_ID NOT IN (3,4)` on `FeesCollection`. Fix: add.
8. **FEE-013 (2)** — wrong current-term date window. Fix: rewrite to use `TermMaster.StartingDate/EndingDate`.
9. **RBAC-SALARY (1)** — L3732. Fix: add branch scoping.

**D6.3 — For each fix, re-run the semantic-rules engine.**
After fixing a batch, re-run the engine. The violation should disappear. If new violations appear (e.g. adding `Structure_Type` revealed a missing `AcademicYearID`), fix those too. Iterate until the engine reports zero violations on the cleaned dataset.

**D6.4 — Hand-verify a sample.**
After the engine reports zero violations, hand-verify 20 randomly-chosen fixed examples against the SPs (the ground truth). The engine is regex-based and can miss semantic errors the rules don't cover. The hand-verification is a sanity check, not exhaustive.

**D6.5 — Refine the rules engine based on false positives.**
During triage you'll find false positives (e.g. FEE-005 firing on bus-fee queries). Refine the rules to exclude them. The engine should have a low false-positive rate — otherwise users ignore its REFUSED messages. Target <5% false-positive rate on the cleaned dataset.

---

## E. Maintenance

**This document is the single source of truth.** When something changes — a new failure mode is discovered, a rule is added, a fix is applied — update this document first, then update the code/data. Keep the document and the codebase in sync.

**What to update when:**
- A new failing question is reported → add to §B with root cause; add the underlying problem to §C if it's a new class; add the mitigation to §D if it's a new fix.
- A pipeline change is made → update §D1; mark the item as DONE with the date.
- A data fix is applied → update §D2; mark the item as DONE with the count of examples fixed.
- A new semantic rule is added to the engine → add to the catalog; update the §C1 count if it changes the flag rate.
- A retrain is done → update §D3 with the version number, date, and evaluation results.
- The evaluation harness is run → record the scores in §D4; compare to the previous run.

**Supporting artifacts (reference, not the source of truth):**
- `semantic_rules_catalog.md` / `semantic_rules.json` — the 78-rule catalog mined from the SPs. Update when new rules are mined.
- `semantic_rules.py` — the working rules engine. Update when rules are added/refined.
- `semantic_rules_violations.csv` — the per-example violations. Regenerate after every data fix or rule change.
- `training_audit_failures.csv` — the per-example audit from the first-pass dataset audit. Superseded by the semantic-rules engine output, but kept for history.
- `schema_audit_report.md` — the full schema/SP evidence (term tables, fee-outstanding SPs, RBAC tables, 25-risk register, 22 cross-doc inconsistencies). Reference for schema questions.

**The decision log:**
- §30 of the findings report records your Option A decision (retrain vocab-aware). When you make future decisions (e.g. Inventory in-scope vs out-of-scope, which roles trigger class scoping), record them here in §E as a dated decision log entry.

**Review cadence:**
- After every retrain: re-run the evaluation harness, update §D4.
- After every pipeline change: re-run the semantic-rules engine on the full dataset, update §C1 and §D6 counts.
- Monthly: review the decision log, confirm still-valid, archive superseded decisions.

---

*End of guidelines. This document supersedes the round-by-round findings in `BLINDSPOT_AUDIT.md` (which is retained for audit history). For any "why" question, the answer is here; for any "what's the evidence" question, the answer is in the supporting artifacts listed in §E.*

---

## F. Training Parameters Audit (v16 train notebook + v17 export notebook)

Audited `finetune_qwen25coder_TRAIN_KAGGLE_v16.ipynb` and `finetune_qwen25coder_GGUF_EXPORT_COLAB_v17.ipynb`. Token-length checks use the real Qwen tokenizer (`Qwen/Qwen2.5-Coder-7B-Instruct`), not the chars/4 heuristic.

### F1. Token-length analysis (authoritative, real tokenizer)

Ran every one of the 3,867 v27 examples through the real Qwen tokenizer with the frozen system prompt + Qwen-2.5 chat template applied:

| Metric | Value |
|---|---|
| Min | 145 tokens |
| Max | **1,687 tokens** |
| Mean | 361 |
| p50 | 351 |
| p90 | 471 |
| p95 | 553 |
| p99 | 667 |
| Over 1,750 | 0 |
| Over 2,048 (old limit) | 0 |
| Over 2,560 (current limit) | **0** |

**`MAX_SEQ_LENGTH = 2560` is safe for v27.** Real max is 1,687 — 873 tokens of headroom (52% margin). The notebook comment ("v11's longest example is ~1750 estimated tokens") was accurate; the chars/4 heuristic slightly overstated, and the real tokenizer count is 1,687. No silent truncation in v27.

**Option A vocab block adds ~172 tokens.** With the realistic vocab block (8 concept types: 15 Classes + 10 Sections + 5 Subjects + 4 EnquiryStatuses + 3 FeeHeads + 3 ExamTerms + 3 FeeTerms), the longest example becomes ~1,859 tokens. Still well under 2,560. **The Option A retrain (D3) does NOT require raising `MAX_SEQ_LENGTH`.** This is an important confirmation — D3.1 is feasible without a context-length change.

**For v28 data:** the new examples (current-term fee with full scoping + TermMaster date window + Branch_Academic_Details + TC filter) are longer than typical v27 examples but still well under 2,560 (~600-700 tokens each with the prompt). If you switch to CTE-form scoping (D1.7), queries get shorter. 2,560 remains safe for v28.

### F2. Dataset schema mismatch (critical for the v28 retrain)

**The v27 JSONL has fields `input` and `output` only.** The training notebook's `formatting_prompts_func` expects `instruction`, `input`, and `output`:

```python
for instruction, inp, output in zip(examples["instruction"], examples["input"], examples["output"]):
    messages = [
        {"role": "system", "content": instruction},
        {"role": "user", "content": inp},
        {"role": "assistant", "content": output},
    ]
```

Since the notebook works in production, `prepare_data.py` (referenced in the notebook but not provided to me) must be adding the `instruction` field to each example before training. **`instruction` is almost certainly the frozen system prompt** (`demo_runner._read_base_prompt`): "You are a T-SQL expert for the ChaloSchools (V3_CHALO) school management database. Convert the following natural language question into a single, executable T-SQL query. Use @UserId..."

**This is the mechanism that makes the model prompt-sensitive.** The model is trained with that exact instruction in every example's system message. At runtime, the same instruction is used. They match — which is why any change to the prompt "derails" the model (it never saw a different prompt in training).

**This is also the mechanism for D3.1 (the v28 vocab-aware retrain).** To retrain vocab-aware: update `prepare_data.py` to prepend the vocab-aware prompt (frozen base prompt + the branch-vocab block) as the `instruction` field, instead of the frozen base prompt alone. The model then trains with the vocab block in every example and, at runtime, the same vocab-aware prompt is used. They match. No derailment. This is not a model-architecture change — it's a data-prep change. **Before the v28 retrain, locate `prepare_data.py` and update the `instruction` field generation.**

**Action item:** locate `prepare_data.py` in your pipeline. Confirm it sets `instruction` = frozen system prompt. For v28, change it to `instruction` = frozen system prompt + vocab block (per-branch, sourced from the Context JSON).

### F3. LoRA parameters — the overfitting direction is inconsistent

| Parameter | v1 (per comment) | Current v16 | Direction |
|---|---|---|---|
| `r` (LoRA rank) | 16 | **32** | ↑ increased |
| `num_train_epochs` | 3 | **2** | ↓ decreased |
| `lora_dropout` | ? | **0** | (no regularization) |

The comment says: "v1 run (r=16, 3 epochs) overfit past step ~500/849." The fix was reducing epochs (3→2). **But increasing r from 16 to 32 works AGAINST the overfitting fix** — higher rank = more trainable parameters = more capacity to memorize, including memorizing the 12.4% semantic bugs in the labels. If r=16 overfit, r=32 overfits more, not less. The epochs reduction helps, but the rank increase partially cancels it.

**Recommendation:** for v28, consider one of:
- **r=16, 2 epochs, dropout=0.05** — less capacity, more regularization, fewer epochs. Cautious; may underfit semantic patterns.
- **r=32, 2 epochs, dropout=0.1** — current capacity, add regularization. Balanced.
- **r=64, 3 epochs, dropout=0.1** — more capacity to learn the (cleaned) semantic patterns, but more regularization and epochs. Aggressive; only if the v28 dataset is large and clean.

Track eval_loss per epoch. If eval_loss rises in epoch 2, r=32 is overfitting — reduce to r=16 or add dropout. If eval_loss is still falling at end of epoch 2, the model is underfitting — add a 3rd epoch or increase r.

### F4. `lora_dropout = 0` — no regularization

The comment says "0 is optimized in Unsloth's kernels." This is a speed optimization, not a correctness one. **With a dataset that is 12.4% semantically buggy, dropout=0 means the model memorizes the bugs perfectly.** A small dropout (0.05-0.1) adds minimal overhead and significantly reduces overfitting to noisy labels. This is especially important for v28 if you can't clean all 480 flagged examples before retraining.

**Recommendation:** set `lora_dropout = 0.05` (conservative) to `0.1` (moderate) for v28. The Unsloth speed cost is negligible; the regularization benefit on a noisy dataset is real.

### F5. `learning_rate = 2e-4` — aggressive for a noisy dataset

2e-4 is on the higher end for LoRA fine-tuning (typical range 1e-4 to 3e-4). With a noisy dataset (12.4% bugs), a lower LR generalizes better and is less likely to memorize buggy patterns. A higher LR converges faster but locks in whatever patterns (including wrong ones) it sees first.

**Recommendation:** for v28, consider `learning_rate = 1e-4`. Training will take ~1.5x longer to converge but the model will be less likely to memorize residual bugs. If the v28 dataset is fully clean (all 480 fixed), 2e-4 is fine.

### F6. `warmup_steps = 10` — too short

10 warmup steps out of ~575-966 steps per epoch (total ~1,150-1,932 for 2 epochs) is <1%. Standard is 3-10% of total steps. With ~1,150 steps, 10 is ~0.9%. The LR ramps up very fast, which can cause early instability, especially with an aggressive LR like 2e-4.

**Recommendation:** use `warmup_ratio = 0.03` (3% = ~35-58 steps) instead of `warmup_steps = 10`. This is the modern TRL convention (the notebook already notes `warmup_ratio` is deprecated in favor of `warmup_steps`, but 10 is too few). If `warmup_steps` is required, set it to 35-50.

### F7. `eval_loss` is necessary but insufficient

`load_best_model_at_end = True` with `metric_for_best_model = "eval_loss"` is correct — the saved adapter is the one with the lowest eval_loss, not the last one. This avoids end-of-training overfitting.

**But eval_loss measures token-level next-token prediction, NOT semantic correctness.** A model can have low eval_loss and still produce semantically wrong SQL, because the bugs are in the training labels and the model learns them perfectly (low loss on wrong answers). **eval_loss is a necessary but insufficient metric.** The evaluation harness (D4) is required to measure semantic correctness.

**Recommendation:** after training, do NOT ship based on eval_loss alone. Run the D4 evaluation harness (50 golden questions with semantic scoring) before promoting a model to production. A model with eval_loss 0.8 and 90% semantic correctness is better than one with eval_loss 0.6 and 70% semantic correctness.

### F8. No semantic check during training

The notebook evaluates on `val.jsonl` but only computes eval_loss. There's no SQL execution, no guardrail run, no semantic-rules check during training. A model could have low eval_loss and produce semantically wrong SQL that passes the structural guardrail but fails the semantic rules.

**Recommendation:** add a lightweight semantic check every N steps (e.g., every 50 steps, run 10 held-out val examples through generation + the semantic-rules engine). Log the semantic pass rate alongside eval_loss. If semantic pass rate drops while eval_loss falls, the model is memorizing buggy patterns — stop early. This is a training-time version of the D4 harness.

### F9. No assertion that no example exceeds `MAX_SEQ_LENGTH`

The notebook sets `MAX_SEQ_LENGTH = 2560` but never checks that no training example exceeds it. If a future dataset version has a longer example, it's silently truncated during training (the chat template + tokenizer truncates at `max_seq_length`). The truncated example teaches the model to produce truncated SQL.

**Recommendation:** add a pre-training assertion cell that tokenizes every training example (with the instruction + input + output + chat template) and fails loudly if any exceed `MAX_SEQ_LENGTH`. One-time check, runs in seconds. Prevents the silent-truncation failure mode the notebook comment acknowledges but doesn't guard against.

### F10. `max_new_tokens` inconsistency (minor)

The training notebook's test cell (Cell 12) uses `max_new_tokens = 400`. The runtime config (`demo_runner` / `llm_client`) uses `max_tokens = 512`. These should be consistent. 400 < 512, so the test cell is more conservative — not a bug, but the test cell doesn't reflect real runtime behavior. A query that the test cell generates in 400 tokens might truncate at 512 in production.

**Recommendation:** align both to 512 (or whatever the production value is). The test cell should reflect production conditions.

### F11. Export notebook: `q4_k_m` quantization compounds quality loss

The export notebook uses `quantization_method = "q4_k_m"`. This is reasonable for CPU inference (~4.5GB, fits in ~8GB RAM). But the training is already in 4-bit (`LOAD_IN_4BIT = True` — the base model is loaded 4-bit, and LoRA trains on top). The export then quantizes the merged model to 4-bit again. **Double-4-bit compounds quality loss.** For a fine-tuned model where the LoRA weights encode subtle SQL patterns, this can degrade output quality noticeably.

**Recommendation:** for v28, if the production machine has ≥16GB RAM, consider `quantization_method = "q5_k_m"` (~5.5GB, better quality, ~10% slower) or `q8_0` (~8GB, best quality, ~2x slower but still usable on CPU). The quality difference is most noticeable for code generation tasks. Test with the D4 harness: run the same model exported at q4_k_m vs q5_k_m vs q8_0 and compare semantic pass rates.

### F12. Export notebook: `MODEL_VERSION = "v23"` is out of sync

The export notebook has `MODEL_VERSION = "v23"` as a placeholder. Your current dataset is v27. If you export with `MODEL_VERSION = "v23"`, the GGUF filename will say v23 but it's actually trained on v27 data. **This is the exact version-naming bug the notebook's Cell 2b was written to fix — and the placeholder still hasn't been updated.**

**Recommendation:** set `MODEL_VERSION` to match the dataset version every run. Better: automate it — write the dataset version to a file in the adapter directory during training (e.g., `adapter_version.txt`), and read it in the export notebook. This eliminates the manual step that's already been forgotten once.

### F13. Export notebook: `MAX_SEQ_LENGTH` must match training (no automated check)

The export notebook sets `MAX_SEQ_LENGTH = 2560` with a comment "must match training config." There's no automated check. If someone changes the training `max_seq_length` but forgets the export one, the model is exported with a context limit that doesn't match training — silent behavior change.

**Recommendation:** write `max_seq_length` to the adapter directory during training (e.g., in `adapter_config.json` or a separate `training_config.json`), and read it in the export notebook. Eliminates the manual sync.

### F14. Export notebook: sanity check uses only 1 test question

Cell 5 runs one test question ("How many students are currently enrolled in Class 10?") before the 10-20 min GGUF export. If the adapter is bad, this catches it — but only if the bug manifests on that one question. A bad adapter that fails on fee queries but works on student queries would pass this check.

**Recommendation:** expand the sanity check to 5-10 questions covering different modules (fees, students, staff, exams, transport). The 30 seconds of extra generation time is worth it before a 10-20 min export. If any question produces garbled output, stop and investigate before exporting.

### F15. Export notebook: the Drive glob fix is correct and important

Cell 6's glob excludes `drive/` after mounting Drive — this fixes a confirmed real bug where the glob swept every past export from the entire mounted Drive. This is a good fix; keep it.

### F16. Summary — training parameter changes for v28

For the v28 vocab-aware retrain (D3), the recommended parameter changes:

| Parameter | v27 (current) | v28 (recommended) | Why |
|---|---|---|---|
| `MAX_SEQ_LENGTH` | 2560 | 2560 (no change) | Real max 1,687 + 172 vocab = ~1,859; safe |
| `r` (LoRA rank) | 32 | 16 or 32 (test both) | r=32 may overfit; r=16 with 2 epochs is cautious |
| `lora_dropout` | 0 | 0.05-0.1 | Regularize against residual label bugs |
| `learning_rate` | 2e-4 | 1e-4 (if data not fully clean) or 2e-4 (if clean) | Lower LR generalizes better on noisy data |
| `warmup_steps` | 10 | 35-50 (or `warmup_ratio=0.03`) | 10 is <1%; 3% is standard |
| `num_train_epochs` | 2 | 2-3 (monitor eval_loss) | Track per-epoch; stop if eval_loss rises |
| `quantization_method` | q4_k_m | q5_k_m or q8_0 (if RAM allows) | Avoid double-4-bit quality loss |
| `instruction` field | frozen prompt (via prepare_data.py) | frozen prompt + vocab block (via prepare_data.py) | The D3.1 mechanism |
| Pre-training check | none | assert no example > MAX_SEQ_LENGTH | Prevents silent truncation |
| During-training check | eval_loss only | eval_loss + semantic pass rate (every 50 steps) | Catches semantic regression early |
| Post-training check | eval_loss | D4 harness (50 golden questions) | eval_loss ≠ semantic correctness |
| Export `MODEL_VERSION` | "v23" (stale) | "v28" (or auto-read from adapter) | Fix the version-naming bug |
| Export sanity check | 1 question | 5-10 questions (multi-module) | Catch more issues before 10-20 min export |

**The single most important training-parameter insight:** `MAX_SEQ_LENGTH = 2560` is safe for both v27 and v28 (including the Option A vocab block). You do NOT need to raise it or buy a bigger GPU. The context-length constraint is not the blocker — the label quality and the missing vocab block are.


---

## G. The Semantic Validation Suite — full package delivered

Per your request, this is a **full package** for semantic validation of the training dataset, not a bandaid patch. It's at `/home/z/my-project/semantic_validation/`.

### G1. What's in the package

```
semantic_validation/
├── README.md                  — how to use, how to add rules, design principles
├── semantic_rules.py          — 29-rule engine, stdlib-only, <1ms/query, importable
├── validate_dataset.py        — standalone validator → HTML + CSV + MD report
├── prepare_data.py            — drop-in replacement for your prepare_data.py
│                                (adds instruction field + validation gate)
├── rules_catalog.json         — full 78-rule catalog mined from 1,095 SPs
├── semantic_rules_catalog.md  — human-readable version of the catalog
└── output/                    — generated artifacts
    ├── report.html            — interactive triage report (open in browser)
    ├── violations.csv         — 706 violation rows, machine-readable
    ├── summary.md             — aggregate summary
    └── dataset_version.txt    — provenance
```

### G2. The validation gate — the single most important mechanism

`prepare_data.py` now **refuses to produce train/val splits if the dataset has HIGH-severity violations above a threshold (default 0)**. This is the "you can't ship broken labels" gate. Tested against v27:

```
$ python prepare_data.py
Dataset version: v27
Loaded 3867 pairs
Added/verified 'instruction' field on all 3867 examples.
Running semantic validation engine...
  Flagged: 515 / 3867 (13.3%)
  HIGH severity: 688
  Total violations: 706
  GATE FAILED: 688 HIGH violations (threshold: 0).
  Refusing to produce train/val split.
  Fix the violations in the dataset, or re-run with --allow-violations.
```

Override with `--allow-violations` (NOT recommended for production). Validate without splitting with `--report-only`.

### G3. The `instruction` field fix (addresses the prepare_data.py discovery)

The sample `prepare_data.py` you provided reads `{instruction, input, output}` and passes them through unchanged — but the v27 JSONL only has `{input, output}`. The training notebook's `formatting_prompts_func` expects all three and would `KeyError`. The new `prepare_data.py` fixes this:

1. Loads the source (tolerates 2-field or 3-field input).
2. **Sets `instruction = FROZEN_SYSTEM_PROMPT` on every example** (overwriting if present, so the dataset and runtime prompt always match — the model is brittle to prompt changes; this is the single source of truth).
3. Runs the validation gate.
4. Splits + writes train/val.

**For the Option A vocab-aware retrain (D3):** replace `FROZEN_SYSTEM_PROMPT` in `prepare_data.py` with the vocab-aware version (frozen prompt + per-branch vocab block). The rest of the pipeline stays the same. This is the D3.1 mechanism.

### G4. The 29 implemented rules

| Module | Rules |
|---|---|
| Fees | FEE-001 (Lien), FEE-004 (LumpSum), FEE-005 (Structure_Type), FEE-006 (term join), FEE-007 (AcademicYearID), FEE-009 (TC filter), FEE-011 (ChequeStatus), FEE-013 (date window), FEE-014 (IsBusFee), FEE-019 (Amt), FEE-022 (IsDonation) |
| Examinations | EXAM-001 (term join), EXAM-002 (soft-delete), EXAM-003 (date cols), EXAM-004 (Get_TermList trap) |
| Students | STUD-001 (Student_Master cols), STUD-004 (YEAR(GETDATE)), STUD-005 (AcademicYearID) |
| Staff | STAFF-002 (Staff_FirstName), STAFF-003 (StaffStatus_ID) |
| Admissions | ADM-001 (ProspectusFeesCollection), ADM-002 (EnquiryMaster) |
| Cross-cutting | DEPRECATED, DEPRECATED-004 (BusFeeStrucure), SENSITIVE-TABLE, SENSITIVE-COL, RBAC-001, RBAC-SALARY, TRANS-001, MULTI-STMT, WRITE-VERB |

The remaining 49 of 78 catalog rules are documented in `rules_catalog.json` but not yet implemented (they need more complex logic — late-fee UNION, prior-term carry-over, dual-FK salary). Add them as the engine matures.

### G5. Validation results on v27 (authoritative)

- **515 of 3,867 examples flagged (13.3%)** with 706 total violations.
- **688 HIGH severity**, 18 MEDIUM.
- Top: FEE-005 missing Structure_Type (382), FEE-007 missing AcademicYearID (146), STUD-005 student AcademicYearID (42), FEE-009 TC filter (22), FEE-004 LumpSum (18), FEE-022 IsDonation (18).
- The 36 MULTI-STMT and 36 WRITE-VERB are mostly false positives (semicolons in subqueries; write verbs in refusal-message comments). Refine these rules in the next iteration.
- **Fees module: 30.4% flagged** — the largest, most error-prone module.

### G6. The HTML report — your triage tool

`output/report.html` (1.15 MB, self-contained, no external dependencies):
- **Summary cards:** total, flagged, clean, violations by severity.
- **Module breakdown table:** flagged % per module.
- **Rule hit table:** count + % + title for every rule.
- **516 example rows:** line #, question, severity badge, module, violations with fix suggestions, "Show SQL" toggle.
- **Filters:** by module, by rule, by severity, by question text search.
- **Per-example detail:** click "Show SQL" to see the full SQL + the specific suggested fix for each violation.

Open it in any browser. Use the filters to triage rule-by-rule (all FEE-005 violations together, apply the same fix, re-run). This is the D6 triage methodology made concrete.

### G7. Integration into the live pipeline (runtime, not just training-time)

The same `check_sql()` function drops into `orchestrator.py` between VALIDATE and EXECUTE (one-line wire in §31 of the findings). This catches both:
- Model mistakes at runtime (a query the model generates that violates a rule).
- Buggy labels at training-time (via the `prepare_data.py` gate).

The engine is deterministic, stdlib-only, <1ms per query, safe to run on every SQL including fast-path cache hits. Rules are pure functions; adding one is a 10-line change.

### G8. How to use the package (3 commands)

```bash
# 1. Validate a dataset (standalone, produces HTML + CSV + MD):
python semantic_validation/validate_dataset.py \
    --dataset /path/to/training_dataset_final_v27.jsonl

# 2. Replace your prepare_data.py with the gated version:
cp semantic_validation/prepare_data.py finetune/prepare_data.py
# Edit DATASET_VERSION at the top to match your source file.
python finetune/prepare_data.py
# → refuses if violations exceed threshold; produces train/val if clean.

# 3. After fixing flagged examples, re-validate:
python semantic_validation/validate_dataset.py --dataset /path/to/cleaned_v28.jsonl
# → flag rate should drop near 0. Then: python finetune/prepare_data.py (gate passes).
```

### G9. Maintenance

- **Adding a rule:** 10-line change to `semantic_rules.py` (function + RULES list + RULE_META). See README.md §"How to add a new rule."
- **After cleaning examples:** re-run `validate_dataset.py` to confirm violations disappear. Iterate until flag rate <5%.
- **When the schema changes:** update table sets in `semantic_rules.py` (`FEE_TERM_FK_TABLES`, `SENSITIVE_TABLES`, `DEPRECATED`, etc.).
- **The catalog is the backlog:** `rules_catalog.json` has 78 rules; 29 are implemented. The remaining 49 are the roadmap for the engine's maturity.

### G10. What this package does NOT do (honest limits)

- It does NOT execute the SQL (no DB connection). It's static analysis only.
- It does NOT catch every semantic error — 29 of 78 rules are implemented. Creative SQL can evade regex-based rules.
- It does NOT fix the examples automatically (the suggested fixes are guidance, not auto-applied — auto-applying SQL rewrites is risky and error-prone; human triage is safer).
- It does NOT replace the evaluation harness (D4) — it validates labels, not model behavior. You still need golden questions to measure end-to-end correctness.

This package is the foundation for D2 (data fixes) and D1.1 (the runtime semantic-rules engine). It's a full, self-contained, maintainable validation system — not a bandaid.

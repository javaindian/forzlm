# Windows Local Testing Guide — ChaloSchools AI Secretary

**For:** the project owner's personal use (local testing on a Windows laptop).
**Not for:** production deployment (use `docs/OCI_DEPLOYMENT.md` for that).
**Not for:** distribution to other teams.

This guide assumes:
- Windows 10/11 laptop
- llama.cpp running locally (your trained model)
- The school's ExecuteQuery API reachable over HTTPS
- Python 3.11+ installed

---

## 0. Easiest way: double-click `START_HERE.bat` (NEW, 2026-08-31)

The package now ships with a **one-click starter** at the project root: `chalo_chatbot\\START_HERE.bat`. Just double-click it. It opens 3 windows in order:

1. **Window 1 — the LLM** (port 8080). Uses `scripts\\start_llm.bat`, which has your real paths pre-filled:
   - `D:\llama-b6691\\llama-server.exe`
   - `D:\ggufs\\AISv27-qwen2.5-coder-7b-instruct.Q4_K_M.gguf`
   - (If you move either file, edit those two lines at the top of `start_llm.bat`.)
2. **Window 2 — the backend** (port 8000). Uses `scripts\\start_backend.bat`, which **auto-creates `.venv` and runs `pip install -r backend\\requirements.txt`** the first time.
3. **Window 3 — your browser** at `frontend\\chat.html` (after a backend health check).

You don't need any of the manual steps in §3 below — `START_HERE.bat` does them for you. The instructions below are for **manual control** or for understanding what the batch files do.

---

## 1. What you need installed

### Python 3.11+
Download from https://www.python.org/downloads/ — check "Add Python to PATH" during install.

Verify:
```cmd
python --version
```

### pip packages
```cmd
pip install fastapi uvicorn pydantic requests
```

### llama.cpp (Windows build)
Download the pre-built Windows binary from https://github.com/ggerganov/llama.cpp/releases — look for `llama-*-bin-win-*.zip`.

Unzip to `D:\llama.cpp\` (or wherever you want). You should have:
```
D:\llama.cpp\llama-server.exe
D:\llama.cpp\llama-cli.exe
```

### Your trained GGUF model
Place the GGUF at `D:\models\qwen25coder_chaloschools_v27.gguf` (or wherever — just remember the path).

### The chalo_chatbot folder
Copy/extract the `chalo_chatbot/` folder to `D:\aisec-zv27\chalo_chatbot\`.

> **Note (2026-08-31):** the package now ships with all 5 batch files (`START_HERE.bat`, `scripts\\start_llm.bat`, `scripts\\start_backend.bat`, `scripts\\run_50.bat`, `frontend\\start_chat.bat`) — you no longer need to create them manually. They're **self-bootstrapping** (auto-create `.venv`, install deps, fall back to a sample `context.json` if yours is missing) and **pure ASCII** (no Unicode box-drawing chars that confuse `cmd.exe`). The instructions below in §3 Step 3 are preserved for reference but **are optional** — use the bundled batch files instead.
>
> The batch files have your real paths **pre-filled** (`D:\llama-b6691\\llama-server.exe`, `D:\ggufs\\AISv27-qwen2.5-coder-7b-instruct.Q4_K_M.gguf`). If you move the files, just edit those two lines at the top of `start_llm.bat`.

---

## 2. Folder structure on your laptop

```
D:\aisec-zv27\
├── chalo_chatbot\           ← the app (copy from the package)
│   ├── backend\
│   │   ├── main.py
│   │   ├── security.py
│   │   ├── .env.example
│   │   └── ...
│   ├── pipeline\
│   ├── vocab\
│   └── ...
├── run_50_questions.py      ← the benchmark script (copy from the package)
├── context.json             ← your real Context JSON (from GetUserContext)
└── start_llm.bat            ← the batch file (below)
└── start_backend.bat        ← the batch file (below)
```

---

## 3. One-time setup

### Step 1 — Configure .env

```cmd
cd D:\aisec-zv27\chalo_chatbot\backend
copy .env.example .env
notepad .env
```

Edit `.env`:
```
AI_SECRETARY_AUTH_TOKENS=dev-token-please-change-in-prod
AI_SECRETARY_ADMIN_TOKENS=admin-token-please-change-in-prod
AI_SECRETARY_TENANT_KEYS=V3_TestDatabase:5e8d1e96c0ac2a3fd31cf83ca26eb675e5ae2e4d8f33e4017be0f2b6ec0636d2
AI_SECRETARY_CORS_ORIGINS=*
AI_SECRETARY_DEBUG=true
AI_SECRETARY_LLM_TIMEOUT=45
```

Save and close.

### Step 2 — Save your Context JSON

Save your real Context JSON (the one from `GetUserContext`) as `D:\aisec-zv27\context.json`.

### Step 3 — Create the batch files

Create `D:\aisec-zv27\start_llm.bat`:
```bat
@echo off
echo Starting llama.cpp (LLM server)...
echo.
echo Model: D:\models\qwen25coder_chaloschools_v27.gguf
echo Port: 8080
echo.
echo Press Ctrl+C to stop.
echo.
D:\llama.cpp\llama-server.exe -m D:\models\qwen25coder_chaloschools_v27.gguf --host 127.0.0.1 --port 8080 --ctx-size 2560
pause
```

Create `D:\aisec-zv27\start_backend.bat`:
```bat
@echo off
echo Starting AI Secretary backend...
echo.
echo Port: 8000
echo.
cd /d D:\aisec-zv27\chalo_chatbot\backend
python -m uvicorn main:app --host 127.0.0.1 --port 8000
pause
```

Create `D:\aisec-zv27\run_50.bat`:
```bat
@echo off
echo Running 50-question benchmark...
echo.
cd /d D:\aisec-zv27
python run_50_questions.py --mode api_wrapper --branch 1 --context-json context.json --auth-token "dev-token-please-change-in-prod"
pause
```

### Step 4 — Copy the run_50_questions.py

Copy `run_50_questions.py` to `D:\aisec-zv27\run_50_questions.py`.

---

## 4. Running the app (daily use)

### Option A — Use the batch files (easiest)

1. **Double-click `start_llm.bat`** — starts the LLM (wait until it says "server listening on 127.0.0.1:8080").
2. **Double-click `start_backend.bat`** — starts the backend (wait until it says "Uvicorn running on http://127.0.0.1:8000").
3. **Double-click `run_50.bat`** — runs the 50 questions (takes ~5-15 minutes on CPU).
4. Open `D:\aisec-zv27\output\50_questions_results.md` — paste it back to me.

### Option B — Manual (three terminal windows)

Open three Command Prompt (cmd) windows:

**Terminal 1 — the LLM:**
```cmd
D:\llama.cpp\llama-server.exe -m D:\models\qwen25coder_chaloschools_v27.gguf --host 127.0.0.1 --port 8080 --ctx-size 2560
```

**Terminal 2 — the backend:**
```cmd
cd D:\aisec-zv27\chalo_chatbot\backend
python -m uvicorn main:app --host 127.0.0.1 --port 8000
```

**Terminal 3 — the 50 questions:**
```cmd
cd D:\aisec-zv27
python run_50_questions.py --mode api_wrapper --branch 1 --context-json context.json
```

### Verifying it works

Before running the 50 questions, verify both services are up:
```cmd
curl http://127.0.0.1:8080/v1/models
```
(Should return a JSON listing your model.)

```cmd
curl http://127.0.0.1:8000/api/health
```
(Should return `{"status":"ok","pipeline_loaded":true,"rules_count":32,"version":"1.1.0"}`)

If both pass, the system is running. The 50-question script will talk to the backend, which talks to the LLM and the ExecuteQuery API.

---

## 5. After a model update (v27 → v28)

When you train a new model version:

1. Export the new GGUF (from the Colab notebook) → download to `D:\models\qwen25coder_chaloschools_v28.gguf`.
2. Edit `start_llm.bat` — change the model path:
```bat
D:\llama.cpp\llama-server.exe -m D:\models\qwen25coder_chaloschools_v28.gguf --host 127.0.0.1 --port 8080 --ctx-size 2560
```
3. Stop the old LLM (Ctrl+C in Terminal 1).
4. Start the new LLM (double-click `start_llm.bat`).
5. Run the 50 questions (double-click `run_50.bat`).
6. Paste `output/50_questions_results.md` back to me.
7. I compare v27 vs v28 — same 50 questions, different model.

---

## 6. Troubleshooting on Windows

| Problem | Fix |
|---|---|
| `python` not found | Add Python to PATH: `setx PATH "%PATH%;C:\Python311"` or reinstall with "Add to PATH" checked |
| `pip install` fails | Try `python -m pip install fastapi uvicorn pydantic requests` |
| `llama-server.exe` not found | Check the path in `start_llm.bat` matches where you unzipped llama.cpp |
| LLM returns "Connection refused" | Is Terminal 1 running? Wait until it says "server listening" before starting Terminal 2 |
| Backend returns "Connection refused" | Is Terminal 2 running? Wait until it says "Uvicorn running" before running the 50 questions |
| `curl` not found | Windows 10+ has curl built in. Or use `Invoke-WebRequest` in PowerShell |
| Backend says `pipeline_loaded: false` | Check the `.env` file exists at `D:\aisec-zv27\chalo_chatbot\backend\.env` |
| 50-question script says `AUTH_ERROR` | The auth token in `.env` doesn't match `--auth-token` in `run_50.bat`. Use the same token in both |
| 50-question script says `CONNECTION_ERROR` | The backend isn't running on port 8000. Start `start_backend.bat` first |
| ExecuteQuery API fails | Check your internet connection + the API URL in the question script (it uses the backend's default, which comes from `.env`) |
| Slow (30+ seconds per question) | Normal on CPU. The LLM is the bottleneck. A GPU would make it 10x faster |

---

## 7. The Chat UI + Audit Trail Viewer (optional, zero-dependency HTML files)

Two standalone HTML files are included — just open them in any browser (Chrome, Firefox, Edge). No Node.js, no build step, no dependencies.

### chat.html — the interactive chat interface
- Claude.ai-style chat UI (same look as the preview panel).
- Type a question, hit Send, see the full result (SQL, trace, violations, rows).
- No predefined questions (you type your own).
- Shows `features_enabled` from the backend response (the admin's feature flags).
- Conversations persist in the browser's localStorage (per browser session).
- Settings drawer: backend URL, auth token, mode, branch, context JSON file upload, inject-vocab toggle, fast-paths toggle.

**Usage:**
1. Start the LLM (start_llm.bat) + the backend (start_backend.bat).
2. Open `chat.html` in Chrome.
3. Click ⚙️ Settings → enter your auth token → upload your context.json file.
4. Type a question, hit Enter.

### audit.html — the audit trail viewer (admin-only)
- Shows every question the backend has processed (from the audit_trail.db).
- Dashboard: total queries, answered/refused/error counts + percentages, avg latency, last-7-days count.
- Refused-by-stage breakdown (which pipeline stage refused most often).
- Table: id, timestamp, user_id, branch_id, question, outcome badge, stage badge, SQL preview, violation count, latency, IP.
- Pagination (50 per page) + outcome filter (all/answered/refused/error).
- Admin token required (enter in the header bar).
- **Export XLSX (green button, NEW 2026-08-31):** fetches ALL rows (respecting the current filter) and downloads them as an Excel `.xlsx` file via SheetJS (loaded from CDN). Falls back to CSV if offline.
- **Reset (red button, NEW 2026-08-31):** clears the entire audit trail via `DELETE /api/audit` (admin-only). Confirms how many rows will be deleted, reminds you to export first. Cannot be undone.

**Usage:**
1. Start the backend (start_backend.bat).
2. Open `audit.html` in Chrome.
3. Enter the admin token (from your .env file).
4. Click "Load" — see all logged questions.
5. After a week of use, click **Export XLSX** to download all rows for postmortem analysis.
6. Click **Reset** to clear the audit trail (e.g. after a long testing session) — exports first if you want a copy.

**How to collect "one week of actual user questions":**
1. Run the chat UI (chat.html) for a week — every question is logged to audit_trail.db.
2. Open audit.html → see the full list of what people asked.
3. Copy the questions (or export the table) → paste them back to me.
4. I categorize them (most-asked, most-refused, new question types) → feeds the v29 training data.

## 8. Notes

- **Don't deploy this to a server.** This is for your laptop only. For production, use `docs/OCI_DEPLOYMENT.md` (Linux/OCI).
- **The `.env` file is fine on your laptop** (LOCAL DEV). Just don't put it on a production server (use OCI Vault there).
- **The `context.json` contains user identity.** Don't share it or commit it to git.
- **The output files** (`output/50_questions_results.md`, `.json`) are the only things you need to paste back to me. Everything else is local.

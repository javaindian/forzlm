# ChaloSchools AI Secretary — Flow Diagrams (draw.io / diagrams.net)

This folder contains **4 draw.io-compatible XML flow diagrams** that explain the ChaloSchools AI Secretary app — including **exactly where to place the GGUF model file**.

## Files

| File | Diagram | What it shows |
|------|---------|---------------|
| `01-folder-structure.drawio` | **1. Project Folder Structure** | Complete file tree with a description of every file. The ★ red node shows where the GGUF model file must be placed (`backend/models/`). |
| `02-system-workflow.drawio` | **2. End-to-End Query Workflow** | High-level flow: User → Frontend → Backend → LLM → Rules → DB → Answer, with the REFUSED branch. |
| `03-query-pipeline.drawio` | **3. Query Processing Pipeline** | Detailed pipeline with **5 diamond decision points** (valid SQL?, violations?, branch access?, dry_run?, execution success?) and every ERROR/REFUSED branch. |
| `04-llm-setup.drawio` | **4. Local LLM Setup** | The startup sequence (run `llm.bat` → llama-server loads GGUF → start backend → open browser) plus a runtime data-flow and a file-system view showing where the GGUF goes. |
| `chalo-ai-secretary-all-diagrams.drawio` | **All 4 in one file** | Open this single file to see all 4 diagrams as tabs in draw.io. |

## How to open

### Option A — Online (no install)
1. Go to **https://app.diagrams.net** (or https://draw.io).
2. **File → Open** → choose `chalo-ai-secretary-all-diagrams.drawio` (or any single file).
3. The 4 diagrams appear as tabs at the bottom of the screen.

### Option B — Desktop app
1. Download **diagrams.net** desktop from https://github.com/jgraph/drawio-desktop/releases.
2. **File → Open** → select any `.drawio` file here.

### Option C — VS Code
1. Install the **Draw.io Integration** extension (by Hediet).
2. Just double-click any `.drawio` file — it opens in a VS Code tab.

## Where does the GGUF file go?

**The GGUF model file goes in `backend/models/`.**

```
chalo-ai-secretary/
└── backend/
    ├── llm.bat                  ← Windows batch that starts llama-server
    └── models/
        └── qwen2.5-7b-instruct-q4_k_m.gguf   ← ★ PUT THE GGUF FILE HERE
```

`llm.bat` runs (from inside the `backend/` folder):

```bat
@echo off
llama-server.exe --model models\qwen2.5-7b-instruct-q4_k_m.gguf --port 8080 --host 0.0.0.0
```

Because `llm.bat` is run from `backend/`, the relative path `models\qwen2.5-7b-instruct-q4_k_m.gguf` resolves to `backend\models\qwen2.5-7b-instruct-q4_k_m.gguf`. **That is why the GGUF file must live in `backend/models/`** — the same folder that `llm.bat` references.

See **Diagram 1** (red ★ node) and **Diagram 4** (file-system view at the bottom) for a visual confirmation.

## Conventions used in all diagrams

- **Same-size rounded rectangles** for all process / file / step nodes (220×60 by default).
- **Diamond shapes** (`rhombus`) for every decision point.
- **Cylinder shape** for the database (T-SQL execution).
- **Oval-ish (arcSize=50) rounded rectangles** for Start / End terminators.
- **Orthogonal connectors with rounded corners** (`edgeStyle=orthogonalEdgeStyle;rounded=1`) — no diagonal lines.
- **Green edges = "Yes / success" path**, **Red edges = "No / REFUSED / ERROR" path**, **Grey = normal flow**, **Dashed = alternative branch**.
- **Color legend** is included in every diagram (top-right corner).

## Color palette (consistent across diagrams)

| Color (hex) | Meaning |
|-------------|---------|
| `#D5E8D4` / `#82B366` (green) | Start / End / project root |
| `#DAE8FC` / `#6C8EBF` (blue) | Backend process / file |
| `#F8CECC` / `#B85450` (red/pink) | Frontend file / ERROR / REFUSED / **★ GGUF highlight** |
| `#E1D5E7` / `#9673A6` (purple) | LLM step |
| `#FFF2CC` / `#D6B656` (yellow) | Rules / branch-access logic |
| `#FFE6CC` / `#D79B00` (orange) | Folder / decision diamond |
| `#B0E3FF` / `#629AC9` (cyan) | Feature flags / insights |
| `#F5F5F5` / `#666666` (grey) | Audit / legend |

## Editing tips

- All nodes use `rounded=1` so corners stay round — keep this when you add new shapes.
- To keep the "same-size rounded shapes" rule, copy an existing node and just change its `value` and position.
- Decision labels (`Yes` / `No`) are set on the **edge**, not on the diamond — look for `value="Yes"` / `value="No"` on `<mxCell edge="1">` elements.
- Connectors auto-route; if two edges overlap, drag a node slightly and draw.io re-routes orthogonally.

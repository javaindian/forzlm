# Dev Team Asks

**For:** the ChaloSchools dev team.
**From:** the AI Secretary project.
**Purpose:** a single, prioritized list of everything we need from the dev team to make the chatbot production-grade. Each ask has: what we need, why we need it, the impact if not done, and the effort estimate (our guess).

This doc is the actionable subset of the open questions. The full audit is in `GUIDELINES.md`; the full architecture is in `HOW_IT_WORKS.md`.

---

## Priority 1 — BLOCKING for v1.0 production launch

These must be done before the chatbot can ship to production.

### Ask 1.1 — Standardize the `GetUserContext` API response

**What we need:**
The `GetUserContext` API currently returns an inconsistent response across branches:
- **Sections**: returned by some branches (e.g. Golden Gates — "A", "B", "C", "D", "E") but not others (e.g. CHALO INTERNATIONAL — we get it via a local-DB fallback).
- **FeeTerms**: never returned by any branch (we get it via a local-DB fallback that queries `TermMaster`).
- **Optional fields** (`IsMgmtAppEnabled`, `ShortName`, `StaffName`): present in some responses, absent in others.

We need the API to **always return, for every branch, every user**:
- `UserMasterDetails.Id`, `UserName`, `StaffName`, `IsSuperUser`, `DBPrefix`, `ShortName` (consistently)
- `UserBranchDetails[].ID`, `Name`, `IsPrimary`
- `UserBranchDetails[].AcademicYears[]` (with `IsCurrentYear` + `PreviousAcademicYearID`)
- `UserBranchDetails[].Classes[]` (with `Name` + `DisplayOrder`)
- `UserBranchDetails[].Sections[]` (the real section names — lettered OR ability-stream, whatever the branch uses)
- `UserBranchDetails[].Subjects[]` (the real subject names, exact casing)
- `UserBranchDetails[].EnquiryStatuses[]`
- `UserBranchDetails[].FeeHeads[]` (the real fee-head names, exact strings)
- `UserBranchDetails[].ExamTerms[]` (the real exam-term names, exact strings)
- **`UserBranchDetails[].FeeTerms[]`** (NEW — the real fee-term names from `TermMaster.Name`)

**Why we need it:**
The chatbot's vocab engine depends on the branch's real vocabulary to:
- Validate the model's SQL literals (e.g. is `'MATHS'` a real subject at this branch?).
- Substitute the model's literal with the branch's real literal (e.g. `'maths'` → `'Maths'`).
- For the v28 FULL-mode retrain: inject the vocab into the prompt so the model writes the correct literal the first time.

Without `Sections` and `FeeTerms` from the API, we run local-DB fallbacks (`SELECT DISTINCT Name FROM SectionMaster WHERE BranchID=?` and `SELECT Name FROM TermMaster WHERE BranchID=? AND AcademicYearID=? AND IsDeleted=0`). These work but:
- They add a DB round-trip per context fetch (latency).
- They're fragile (if the table changes, the fallback breaks).
- They're inconsistent (the API is the source of truth for some concept types; the local DB for others).

**Impact if not done:** the chatbot works in STOPGAP mode (with fallbacks) but can't do the v28 FULL-mode retrain reliably (the training data needs the real vocab for every branch). v1.0 ships; v1.1 is harder.

**Effort (dev team):** low-medium. The data already exists in the DB (`SectionMaster`, `TermMaster`); it's a matter of adding the fields to the API response + a schema doc.

**Where it's tracked:** PRD §10 (Q-ContextAPI), `SESSION_HANDOFF.md` §5.

---

### Ask 1.2 — Confirm the `SectionMaster` source for ability-stream branches

**What we need:**
For branch 1 (CHALO INTERNATIONAL), `SectionMaster` contains ability-stream names ("All", "BRAINY", "EXPERT", "FOUNDATION", "FOUNDATION 1", "FOUNDATION 2", "INTELLIGENT", "New Admission", "TALENTED", "TALENTED 1"). Some of these look like junk/test rows ("All", "New Admission").

We need the dev team to confirm:
1. Is `SectionMaster` the right table for this branch's sections, or do the real sections live in `ClassSectionMasterMapping` / `ClassTermAssignment` / another table?
2. Are "All" and "New Admission" real section rows, or contamination that should be excluded?
3. For the chatbot's section vocab, should we filter `SectionMaster` by an `IsActive`/`SectionType` column, or is every row a real section?

**Why we need it:**
The chatbot validates section literals against the branch's real sections. If `SectionMaster` is contaminated (the "All" and "New Admission" rows aren't real sections), the chatbot might accept "All" as a valid section and run a query that returns every student (wrong) instead of refusing. If the real sections live in a different table, our fallback queries the wrong table.

**Impact if not done:** section-based queries at ability-stream branches may return wrong data or refuse valid questions. The §26 finding (round-4) documented this; we need the dev team's confirmation to close it.

**Effort (dev team):** low. A 10-minute conversation or a SQL query to check.

**Where it's tracked:** PRD §10 (Q-SectionSource), `SESSION_HANDOFF.md` §5.

---

### Ask 1.3 — Provide the role→screen→table mapping (for v1.1 RBAC)

**What we need:**
You confirmed (Q12) the school's RBAC is **screen-level**: every user has a role → every role grants screens → each screen touches multiple tables (e.g. the attendance screen joins to fee-due details). The `config.yaml` `allowed_tables` whitelist (16 tables) is NOT the right enforcement.

For the chatbot to enforce screen-level RBAC, we need:
1. **The role names** in `UserAccountRoleMaster` (real values — Teacher, Principal, Accountant, ClassTeacher, Admin, etc. — currently unverified, Deep-Dive #11 OPEN).
2. **The screen→table mapping**: for each screen in `Screen_Privilege_Details` (or wherever screens are defined), which tables does it touch? This may already exist in your code (the screen definitions must know their tables to render), or it may need to be compiled.
3. **A way to query a user's authorized screens** at runtime (via the Context JSON, or an API endpoint, or a DB query the chatbot can run).

**Why we need it:**
Without this, the chatbot enforces only branch-level scoping (a user can see their branches' data) + sensitive-table blocking (no passwords/Aadhaar). It does NOT enforce "a teacher can only see attendance, not fees" — a teacher with the chatbot can ask "what's the fee outstanding for class 10" and get the answer, even if they don't have the Fees screen.

**Impact if not done:** v1.0 ships with branch-level + sensitive blocking (acceptable for a management-chatbot launch — the users are principals/admins who have broad access). v1.1 (screen-level RBAC) is blocked until this mapping is provided.

**Effort (dev team):** medium. The role names are a SQL query; the screen→table mapping may need to be compiled from the screen definitions (or extracted from the existing RBAC enforcement in the web app).

**Where it's tracked:** PRD §10 (Q-RBAC-Screen), `SESSION_HANDOFF.md` §5.

---

## Priority 2 — NEEDED for the v28 retrain (v1.1)

These can be done in parallel with v1.0 launch; needed before the v28 retrain.

### Ask 2.1 — Confirm the ExecuteQuery API `Parameters`-binding bug status

**What we need:**
The original `parameter_binder.py` has a config flag `use_inline_params: true` that works around a confirmed bug: the real `ExecuteQuery` API fails on repeated `@`-placeholders in nested subqueries (the dev team was "working on it" per the code comment).

We need to know:
1. Is the bug fixed? If yes, we flip `use_inline_params` to `false` (use real parameter binding — safer).
2. If not fixed, what's the ETA? The inline-params fallback escapes single quotes (safe), but real parameter binding is preferred for defense in depth.

**Why we need it:**
The branch-scoping subquery repeats `@UserId` 2-3 times per query. With the bug, these repeated placeholders fail. The workaround inlines the values as escaped string literals. It's safe (values are pre-validated), but it's a workaround. We'd rather use the real `sp_executesql` parameter binding.

**Impact if not done:** the chatbot runs on the workaround indefinitely. Functionally fine; architecturally a tech-debt item.

**Effort (dev team):** low. A fix to the `ExecuteQuery` API's parameter-binding logic, OR a confirmation that the workaround is the permanent path.

**Where it's tracked:** `GUIDELINES.md` §F (the `use_inline_params` note), `BLINDSPOT_AUDIT.md` §7 (R4).

---

### Ask 2.2 — Provide the per-tenant API keys

**What we need:**
The `user_context_api.py` has a `TENANT_API_KEY_MAP` that maps `TargetDatabase` → API key. Currently only `V3_TestDatabase` is populated; `V3_GG` (Golden Gates) is a TODO.

For each tenant (school) the chatbot serves, we need:
1. The `TargetDatabase` (the `DBPrefix` — e.g. `V3_TestDatabase`, `V3_GG`, `jvv_db`).
2. The `AISecretaryApiKey` for that tenant (from `chalov3common.dbo.SchoolMaster` per the dev team's documentation).

**Why we need it:**
Without the per-tenant key, the chatbot can't call `GetUserContext` or `ExecuteQuery` for that tenant — it returns "Invalid API key for the specified tenant." The chatbot only works for `V3_TestDatabase` today.

**Impact if not done:** the chatbot works for one tenant only. Multi-tenant rollout is blocked.

**Effort (dev team):** low. A SQL query per tenant (`SELECT AISecretaryApiKey FROM chalov3common.dbo.SchoolMaster WHERE DBPrefix=?`), then hand us the key-value pairs.

**Where it's tracked:** `user_context_api.py` `TENANT_API_KEY_MAP`, `BLINDSPOT_AUDIT.md` §3 (R8).

---

### Ask 2.3 — Provide 10-20 concrete failing examples (with the right answer)

**What we need:**
You've given us 4 failing examples so far:
1. "fee outstanding of the current term" (mixes up fee/exam term).
2. "who is the principal" / "what is the principal name" (hallucinated `Principal_ID`).
3. "who teaches maths in class 8A" (branch uses ability-stream sections).
4. "how many students passed maths in term 1?" (hallucinated `MinMark`, cartesian subject join, no exam-term filter).

We need 10-20 more, with:
- The exact question the user typed.
- The wrong SQL the model produced (from the `trace`).
- The right SQL (hand-written by the dev team).
- The user's branch + the branch's real vocab (so we can reproduce).

**Why we need it:**
Each failing example becomes:
- A new semantic rule (if it's a class of bug — e.g. the "MinMark hallucination" became EXAM-006).
- New training examples (if it's a coverage gap — e.g. "who is the principal" became 10 new training examples).
- A golden question for the accuracy harness (if it's a held-out case).

The 50 golden questions in `evaluation/golden_questions.json` are hand-written from the schema; the real failing examples are more valuable because they're what users actually ask.

**Impact if not done:** the chatbot improves via the audit + the harness, but the "long tail" of failure modes (the ones only real users find) is invisible. The v28 retrain improves the average case but not the edge cases real users hit.

**Effort (dev team):** low-medium. Each example is 5 minutes (the trace is already logged; you write the right SQL). 10-20 examples = 1-2 hours.

**Where it's tracked:** `evaluation/golden_questions.json`, `BLINDSPOT_AUDIT.md` §9 (the standing request).

---

## Priority 3 — NICE-TO-HAVE for v1.1+ (not blocking)

### Ask 3.1 — An audit-trail table for chatbot queries

**What we need:**
The original Streamlit app had an `audit_trail.db` (SQLite) that logged every chatbot query. We'd like the same in the FastAPI backend — a table (or a log stream) that records, per `/api/chat` call:
- The user_id, branch_id, timestamp.
- The question.
- The generated SQL.
- The outcome (ANSWER/REFUSED/etc.).
- The semantic violations.
- The latency.

**Why we need it:**
- Compliance (who asked what, when).
- The feedback loop (cluster questions to find the most-asked + most-refused patterns — drives the v29 data collection).
- Debugging (when a user reports "the chatbot gave me a wrong answer", we can look it up).

**Impact if not done:** the chatbot runs without an audit trail. We can't diagnose user-reported issues without asking them to reproduce. The feedback loop is manual.

**Effort (dev team):** low (a SQLite table + a logging hook) — or we can do it ourselves if you prefer.

**Where it's tracked:** `BRAINSTORM.md` §8.3.

---

### Ask 3.2 — A `/api/context` endpoint (alternative to the mobile-app fetching Context JSON)

**What we need:**
Today the mobile app calls `GetUserContext` (the school's existing API) to get the Context JSON, then passes it to the chatbot's `/api/chat` endpoint. An alternative: the chatbot backend calls `GetUserContext` itself, given the user's auth token.

We need the dev team to confirm:
1. Can the chatbot backend call `GetUserContext` directly with the user's Bearer token? (If yes, the mobile app doesn't have to fetch + forward the Context JSON — simpler mobile integration.)
2. If yes, what's the auth flow? (The Bearer token the mobile app sends to the chatbot — is it the same token `GetUserContext` accepts, or does it need translation?)

**Why we need it:**
Simpler mobile integration + the chatbot can cache the Context JSON server-side (faster, no repeated fetches).

**Impact if not done:** the mobile app does the fetch + forward (works, just more work for the mobile team).

**Effort (dev team):** low. A confirmation + the auth flow doc.

**Where it's tracked:** `API_CONTRACT.md` §11 (recommended next steps, item 1).

---

### Ask 3.3 — Confirm the `Branch_Academic_Details` is the authoritative current-year source

**What we need:**
The chatbot resolves "current academic year" via `Branch_Academic_Details` (the row where `GETDATE() BETWEEN Start_Date AND End_Date` for the user's branch). This is the approach the 1,095 SPs use.

We need the dev team to confirm:
1. Is `Branch_Academic_Details` the authoritative source, or is there another table?
2. What happens during the gap between academic years (e.g. April 1 — the old year ended March 31, the new year starts April 1 — is there a day where no row matches `GETDATE() BETWEEN Start_Date AND End_Date`)?
3. For a super-user with multiple branches, each branch may have a different current academic year. The chatbot uses the selected branch's current year. Confirm this is correct.

**Why we need it:**
The `@AcademicYearID` injection (D1.3) depends on this. If the source is wrong, every academic-year-scoped query (most of them) returns wrong data.

**Impact if not done:** the chatbot uses the best guess; the 1,005 v27 examples that use `Branch_Academic_Details` confirm it's the right table. Low risk, but confirmation closes the loop.

**Effort (dev team):** low. A 5-minute confirmation.

**Where it's tracked:** `GUIDELINES.md` §D1.3, the schema audit.

---

## Summary table

| # | Ask | Priority | Effort (dev) | Blocks |
|---|---|---|---|---|
| 1.1 | Standardize `GetUserContext` (add Sections + FeeTerms, always) | **P1 — blocking v1.0** | Low-medium | v1.0 reliability + v28 retrain |
| 1.2 | Confirm `SectionMaster` source for ability-stream branches | **P1 — blocking v1.0** | Low | Section queries at branch 1 |
| 1.3 | Provide role→screen→table mapping | **P1 — but for v1.1** | Medium | v1.1 screen-level RBAC |
| 2.1 | Confirm `ExecuteQuery` Parameters-binding bug status | P2 — for v28 | Low | The `use_inline_params` flag |
| 2.2 | Provide per-tenant API keys | P2 — for multi-tenant | Low | Multi-tenant rollout |
| 2.3 | Provide 10-20 concrete failing examples | P2 — for v28 | Low-medium | v28 retrain quality |
| 3.1 | Audit-trail table for chatbot queries | P3 — nice-to-have | Low | Feedback loop |
| 3.2 | Confirm chatbot can call `GetUserContext` directly | P3 — simplification | Low | Mobile integration |
| 3.3 | Confirm `Branch_Academic_Details` is the current-year source | P3 — confirmation | Low | Closes a loop |

**Minimum to ship v1.0:** Asks 1.1 + 1.2 (the chatbot works without them via fallbacks, but they're needed for production reliability).
**Minimum for the v28 retrain:** Asks 1.1 + 2.1 + 2.2 + 2.3.
**For v1.1 (screen-level RBAC):** Ask 1.3.

---

## What we DON'T need from the dev team

To be clear, these are NOT asks (we handle them):
- The chatbot backend code (we built it).
- The semantic rules engine (we built it; 32 rules).
- The vocab engine + synonyms (we built it; 9 concept types).
- The accuracy harness (we built it; 50 golden Qs).
- The training-data gate (we built it).
- The local-test web UI (we built it; dev only).
- The v28 retrain (we deliver the notebooks + the gated `prepare_data.py`; your team runs the retrain).
- The mobile app (your mobile-app team builds it per `API_CONTRACT.md`).
- Production deployment (Docker/systemd/nginx — Batch 3 or your ops team).

The asks above are the **dependencies on the dev team** — things only the dev team can provide (API changes, schema confirmations, tenant keys, failing examples).

---

## How to track this

- This doc is the single list. Print it, share it, check items off.
- `PROJECT_STATUS.md` and `SESSION_HANDOFF.md` (in `chalo_chatbot/docs/`) are updated as items are resolved.
- When an ask is resolved, tell us — we'll update the docs + the code (e.g. add a tenant key to `TENANT_API_KEY_MAP`, flip `use_inline_params` to false, add a new semantic rule from a failing example).

---

## The bottom line

**To ship v1.0:** the chatbot is feature-complete on our side. The dev team's P1 asks (1.1 standardize GetUserContext, 1.2 confirm SectionMaster) are needed for production reliability but the chatbot works without them via fallbacks. If you can do 1.1 + 1.2 before launch, great; if not, we ship with fallbacks and fix in v1.1.

**For the v28 retrain (v1.1):** the P2 asks (2.1, 2.2, 2.3) are needed. The retrain is yours to run; we deliver the notebooks + the gate. The P1 ask 1.3 (role→screen→table) is needed for v1.1's screen-level RBAC.

**The cheapest high-value ask:** 2.3 (10-20 failing examples). Each one becomes a rule or a training example or a golden question. 1-2 hours of dev-team time, disproportionate impact on the chatbot's quality.

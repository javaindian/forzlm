# ChaloSchools AI Secretary — Product Requirements Document (PRD)

**Version:** 1.0
**Status:** In development (backend complete; mobile-app integration pending; v28 retrain pending)
**Owner:** ChaloSchools management
**Last updated:** 2026-08-27

---

## 1. Problem statement

ChaloSchools is a multi-tenant school ERP with 14 modules (Administration, Admissions, General Enquiries, Fees, Examinations, Inventory, Staff, Student, Circulars, Home Works, Communication, Payroll, Transport, Parent Feedback). Management and staff need quick answers to operational questions ("What is the fee outstanding for the current term?", "Who is the principal?", "How many students passed maths in term 1?"). Today they navigate the ERP's menus, run reports, and manually assemble answers — slow, error-prone, and inaccessible to non-technical staff.

The goal: a natural-language chatbot, embedded as a menu item in the school's mobile app, that translates questions into T-SQL queries against the ERP database and returns answers with branch-scoped access control.

---

## 2. Goals and non-goals

### Goals
1. **Answer natural-language questions** about school data across all 14 modules.
2. **Branch-scoped access control** — a user only sees data for branches they're authorized to access (per `UserAccountRoleDetails`).
3. **Fail closed** — refuse with a specific, actionable reason rather than return wrong data.
4. **Read-only** — the chatbot never writes to the database.
5. **Mobile-app integration** — production deployment is a menu item in the school's mobile app, calling a backend API service.
6. **Measurable** — an accuracy harness that scores the model objectively (structural, semantic, outcome, latency).
7. **Self-improving** — a training-data gate that prevents semantically-buggy labels from being trained on.

### Non-goals (explicitly out of scope)
1. **Write operations** — no INSERT/UPDATE/DELETE/DROP. The chatbot is read-only.
2. **Stored-procedure execution** — SPs are used as reference for training-label generation; the chatbot emits raw SELECT only.
3. **Multi-turn conversational state** — each question is independent; no "follow up on my last question" context (the mobile app maintains the chat history locally).
4. **Voice input** — text only.
5. **Multi-language** — English only (the model is trained on English questions; some training examples are in Hinglish/Hindi but not officially supported).
6. **Server-side conversation persistence** — conversations live on the device; cross-device sync is a future enhancement.
7. **Streaming responses** — the backend returns the full result when ready; token streaming is a future enhancement.

---

## 3. User personas

### P1 — Principal / Administrator (the primary user)
- **Who:** the school principal or a senior administrator. Has access to all branches (super-user) or multiple branches.
- **What they ask:** "What is the fee outstanding for the current term?", "Class-wise student count", "How many new admissions this year?", "Who is the principal of the Besant Nagar branch?"
- **Frequency:** 5-20 questions/day.
- **Latency tolerance:** willing to wait 10-20s for complex fee queries; expects <5s for simple counts.
- **Failure mode:** must see a clear reason when the chatbot refuses ("I don't recognize 'A' as a section at your branch — your sections are BRAINY, EXPERT, ...").

### P2 — Class teacher (secondary)
- **Who:** a teacher assigned to specific classes/sections.
- **What they ask:** "Who teaches maths in 8B?", "Students who failed in any subject this term", "Class-wise topper list for Term II"
- **Frequency:** 1-5 questions/day.
- **Latency tolerance:** patient — teachers use the chatbot between classes.
- **Failure mode:** expects the chatbot to know which classes they teach (class-level RBAC — designed but not yet implemented).

### P3 — Accountant (secondary)
- **Who:** the fee clerk or accountant. Has access to the Fees module + cross-branch financial visibility.
- **What they ask:** "Total fees collected today", "Defaulters list", "Concession given this year", "Cheque bounce report"
- **Frequency:** 10-30 questions/day.
- **Latency tolerance:** expects fast answers for daily-collection queries; patient for term-wise reports.
- **Failure mode:** financial accuracy is critical — a wrong answer has direct cost.

---

## 4. Functional requirements

### FR-1 — Question intake
The mobile app sends a natural-language question (1-1000 chars) + the user's Context JSON + the selected branch ID to the backend.

### FR-2 — Context resolution
The backend parses the Context JSON into a `UserContext` (user_id, is_super_user, authorized_branches, selected_branch_id, per-branch vocab). It resolves the current academic year from `IsCurrentYear` and injects `@AcademicYearID` as a trusted parameter.

### FR-3 — SQL generation
The backend calls the fine-tuned Qwen 2.5 Coder 7B model (served by llama.cpp at port 8080) with the question + the frozen system prompt. The model returns a single T-SQL SELECT query.

### FR-4 — Structural validation
The generated SQL passes through:
- **Guardrail** — schema existence (tables/columns must exist in the 475-table catalog) + sensitive-table/column blocklist.
- **Alias-scope check** — catches Msg 4104 (alias used outside its subquery).
- **Branch-scoping gate** — verifies the SQL genuinely scopes results to `@UserId`'s branches via `UserAccountRoleDetails WHERE UserID = @UserId`.
- **Truncation guard** — if `finish_reason == 'length'`, refuse instead of executing truncated SQL.

### FR-5 — Value validation and substitution
For each master-data literal the model writes (class name, subject, section, fee head, exam term, fee term), the backend:
- Validates it against the branch's real vocabulary (from the Context JSON).
- If the literal is a synonym ("maths" → "MATHS"), substitutes the branch's real literal back into the SQL.
- If 0 or 2+ matches, returns `NEEDS_DISAMBIGUATION` with the candidate list.

### FR-6 — Semantic verification
The backend runs the 32-rule semantic engine on the (substituted) SQL. Each rule checks one business rule mined from the 1,095 reference stored procedures. Violations return `REFUSED` with the specific rule_id, message, and suggested fix.

The 32 rules cover:
- **Fees (11)** — outstanding formula (Lien/Concession/Paid), Structure_Type, IsIncludedInLumpSum, ChequeStatus_ID, current-term date window, IsBusFee, IsDonation, term-master join (NOT ExamTermMaster).
- **Examinations (5)** — exam-term join (ExamTypeMaster → ExamTermMaster), ExamTermMaster soft-delete (`Deleted`, not `IsDeleted`), date columns (`StartDate`, not `StartingDate`), `Get_TermList` name trap, `MinMark` hallucination.
- **Students (6)** — Student_Master has no ClassID/SectionID/AcademicYearID, academic year via `Branch_Academic_Details` (not `YEAR(GETDATE())`), AcademicYearID filter, Subject join must use SubjectID (not BranchID — cartesian-product bug).
- **Staff (2)** — Staff_FirstName naming, StaffStatus_ID=1 for active staff.
- **Admissions (2)** — ProspectusFeesCollection links via ApplicationNo, EnquiryMaster is deprecated.
- **Cross-cutting (6)** — deprecated tables, sensitive tables/columns, RBAC (super-user UNION, salary branch scoping), BusFeeStrucure misspelling, multi-statement, write verbs.

### FR-7 — Execution
The bound SQL executes in one of three modes:
- **dry_run** — no execution; returns the bound request body (for testing).
- **local_db** — direct MS SQL Server via pyodbc + sp_executesql (testing).
- **api_wrapper** — via the school's ExecuteQuery ASMX endpoint (production). Double-JSON-encoded request/response.

### FR-8 — Result rendering
The backend returns a structured result with: outcome (ANSWER/REFUSED/NEEDS_DISAMBIGUATION/NEEDS_BRANCH_SELECTION/ERROR), the generated SQL, the result rows + columns, the pipeline trace, any semantic violations. The mobile app renders this appropriately.

### FR-9 — Branch picker
When a user has 2+ branches, the mobile app shows a branch picker (populated via `/api/branches`). Single-branch users skip the picker.

### FR-10 — Disambiguation flow
When the backend returns `NEEDS_DISAMBIGUATION`, the mobile app shows the candidate list; the user picks one, and the mobile app re-sends the question with the chosen value.

---

## 5. Non-functional requirements

### NFR-1 — Latency
- Simple count queries: <8s (p95) on CPU.
- Complex fee-outstanding queries: <20s (p95) on CPU.
- Pagination: each additional page adds <5s.
- Backend-only stages (guardrail, semantic, validate, bind): <500ms total.

### NFR-2 — Availability
- The backend API service: 99.5% uptime.
- The LLM (llama.cpp): 99% (it's a single process; restart on crash).
- Health check (`/api/health`): always responds within 2s.

### NFR-3 — Security
- **Auth:** Bearer token on all endpoints except `/api/health`. Constant-time comparison.
- **RBAC:** branch-level (via `UserAccountRoleDetails`). Class-level (via `UserRoleClassMapping`) — designed but not yet implemented.
- **Sensitive data:** `UserAccountMaster.Password/Token`, `BranchMaster.SGC_Password/SGC_UserId/APIKey`, `StorageConfiguration`, `SMS_ConfigurationSettings`, `WhatsAppConfiguration`, `Student_Master_Draft`, `PasswordRecovery`, payment tables — blocked at the guardrail AND the semantic engine (defense in depth).
- **SQL injection:** impossible by construction — all values are bound as sp_executesql parameters (never concatenated). The `use_inline_params` fallback escapes single quotes (defense in depth).
- **PII in logs:** the Context JSON contains user identity; logs must not persist it unencrypted.

### NFR-4 — Correctness
- 0 HIGH-severity semantic violations on shipped training labels (enforced by the `prepare_data.py` gate).
- The accuracy harness (50 golden questions) must show: structural pass ≥ 90%, semantic match avg ≥ 2.5/3, outcome match ≥ 80% before each model version ships.

### NFR-5 — Maintainability
- Adding a semantic rule: a 10-line change to `semantic_rules.py`.
- Adding a concept type: a 5-line change to `vocab/synonyms.json` + the `CONCEPT_TO_JSON_KEY` map.
- The frozen system prompt changes only with a retrain (documented in `prepare_data.py`).
- Documentation: 6 standalone docs in `docs/`; the single source of truth is `GUIDELINES.md`.

### NFR-6 — Observability
- Every chat response includes the full `trace` (the list of stages that ran) — visible in the local-test UI and in the API response.
- The `semantic_violations` field lists every rule that fired with the suggested fix.
- The `latency_ms` field measures end-to-end time.
- (Future: structured logging to a log aggregator; audit trail to `audit_trail.db`.)

---

## 6. Architecture overview

```
Mobile App (production)  ──HTTPS+Bearer──>  AI Secretary API (FastAPI, port 8000)
                                              │
                                              ├── Pipeline (11 stages)
                                              │   ├── Context → Inject → Generate
                                              │   ├── Guardrail → Alias → Branch-scoping
                                              │   ├── Validate → Substitute → Semantic
                                              │   └── Bind → Execute
                                              │
                                              ├── Vocab Engine (synonyms + injection)
                                              ├── Semantic Engine (32 rules)
                                              └── LLM Client (llama.cpp, port 8080)
                                                    │
                                                    ▼
                                              ExecuteQuery API (school's ASMX)
                                                    │
                                                    ▼
                                              V3_CHALO database
```

The local-test Next.js web UI (port 3000) is a dev tool that calls the same API — NOT part of production.

---

## 7. Success metrics

| Metric | Target | Measured by |
|---|---|---|
| Structural pass rate | ≥ 90% | Accuracy harness (50 golden Qs) |
| Semantic match avg | ≥ 2.5/3 | Accuracy harness |
| Outcome match rate | ≥ 80% | Accuracy harness |
| Latency p95 (simple) | < 8s | Accuracy harness |
| Latency p95 (complex) | < 20s | Accuracy harness |
| Training-label bug rate | < 5% | `semantic_validation/validate_dataset.py` |
| HIGH-severity violations on shipped labels | 0 | `prepare_data.py` gate |
| Sensitive-table leakage | 0 | Pen-test (manual + automated) |
| Cross-branch data leak | 0 | Pen-test (manual + automated) |

---

## 8. Constraints

- **CPU-only LLM** — Qwen 2.5 Coder 7B runs on CPU via llama.cpp. No GPU in production. This sets the latency budget (5-30s per query).
- **Single-tenant model, multi-tenant data** — the model is fine-tuned on one school's data; the Context JSON carries per-branch vocabulary to bridge the gap.
- **The frozen system prompt must match training verbatim** — any change derails the model. Changes require a retrain.
- **`max_tokens = 512`** — the model's output cap. 110 training examples are near this limit. The truncation guard catches overruns.
- **No stored-procedure execution in production** — SPs are reference-only (for label generation).

---

## 9. Assumptions

- The school's `GetUserContext` API returns the Context JSON with `UserMasterDetails` + `UserBranchDetails` per the contract. (Sections and FeeTerms are not yet returned; the backend has fallbacks.)
- The school's `ExecuteQuery` ASMX endpoint accepts the double-JSON-encoded request format and returns the `d`-field-encoded response.
- The llama.cpp server runs on the same machine as the backend (or a reachable network host).
- The mobile app obtains the Bearer auth token from the school's existing auth system.

---

## 10. Open questions (for the project owner)

| # | Question | Status | Impact |
|---|---|---|---|
| Q11 | Is there school-routing code (parses `username@shortschoolname` → DB target)? | **RESOLVED** — the school's auth system (GetUserContext) already validates this. The backend receives the validated Context JSON. | No action needed. |
| Q12 | Where is `config.yaml`'s `allowed_tables` / `blocked_columns` / `max_joins` enforced? | **RESOLVED** — the school's RBAC is screen-level (role → screens → tables), not table-level. The `allowed_tables` whitelist is not the right enforcement. | New question Q-RBAC-Screen raised. |
| Q16 | Training notebooks: (a) updated, (b) documented diff, or (c) untouched? | **RESOLVED** — (a) updated + (b) documented diff. | Will deliver in Batch 3. |
| Q-RBAC-Screen | Should the chatbot enforce role→screen→table RBAC (Path B), or is branch-level + sensitive-table blocking sufficient for v1.0? | NEW — raised by Q12's answer. | Affects v1.1 RBAC hardening. Recommendation: ship v1.0 with current RBAC; v1.1 adds screen-level. |
| Q-ContextAPI | Ask the dev team to standardize GetUserContext: always return Sections + FeeTerms; document the contract. | NEW — the real Context JSON shows Sections is returned by some branches but not others; FeeTerms is never returned. | Affects the vocab engine's reliability. |
| Q-SectionSource | Is `SectionMaster` the right table for ability-stream branches (BRAINY/EXPERT), or do sections live in `ClassSectionMasterMapping`? | OPEN. | Affects the vocab engine + the Option A retrain. |
| Q-RBAC | Is class-teacher row-level RBAC a requirement, or is branch-level sufficient for the management chatbot? | OPEN. | Affects whether D5 (class-scoping) is built. |

---

## 11. Milestones

| Milestone | Status |
|---|---|
| M1 — Blindspot audit (rounds 1-4) | Done. `docs/BLINDSPOT_AUDIT.md`. |
| M2 — Semantic rules engine (32 rules) | Done. `pipeline/semantic_rules.py`. |
| M3 — Vocab engine (9 concept types) | Done. `vocab/inject.py` + `vocab/synonyms.json`. |
| M4 — Pipeline reconstruction + 8 fixes | Done. `pipeline/` (17 files). |
| M5 — Backend API (mobile-app-facing) | Done. `backend/main.py`. |
| M6 — Local-test web UI | Done. `src/app/page.tsx`. |
| M7 — Accuracy harness (50 golden Qs) | Done. `evaluation/`. |
| M8 — Training-data gate | Done. `semantic_validation/prepare_data.py`. |
| M9 — Documentation (6 docs) | Done. `docs/`. |
| M10 — v28 retrain | Pending. Requires decision on Q16. |
| M11 — Class-teacher row-level RBAC | Pending. Requires decision on Q-RBAC. |
| M12 — Production deployment (Docker/systemd/nginx) | Pending (Batch 3). |
| M13 — Mobile-app integration | Pending (the mobile-app team's work, per `docs/API_CONTRACT.md`). |

---

## 12. Risks

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| The v27 model derails on prompt changes (confirmed twice) | High | High | The frozen prompt is version-controlled in `prepare_data.py`; changes require a retrain. |
| 12.4% of v27 labels are semantically buggy | Certain | High | The training-data gate (`prepare_data.py`) refuses to ship buggy labels. Clean before retrain. |
| The fee/exam-term confusion resurfaces on out-of-distribution questions | Medium | High | 32-rule semantic engine catches it at runtime; the v28 retrain adds more training anchors. |
| CPU latency exceeds 20s on complex queries | Medium | Medium | CTE-form scoping cuts query length 30-50% (recommended for v28). |
| Sensitive-table blocklist incomplete | Low | Critical | Defense in depth: guardrail + semantic engine. Add tables as discovered. |
| Cross-tenant data leak | Low | Critical | Branch-scoping gate + RBAC-001 semantic rule. Pen-test before each release. |
| The model hallucinates columns (e.g. Principal_ID) | Medium | Medium | Guardrail catches it; add training examples for the phrasing (round-2 §27). |

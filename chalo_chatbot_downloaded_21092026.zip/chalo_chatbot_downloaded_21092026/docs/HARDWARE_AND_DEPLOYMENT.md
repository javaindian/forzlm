# Hardware + Deployment — The Lean Config

**For:** the project owner deciding what hardware to buy/rent.
**Context:** 0 clients today; 20-25 onboarded in 6 months; DB is in Oracle Cloud; don't burn money.

---

## 1. The one-box answer

**One OCI VM.Standard.E4.Flex with 8 OCPUs + 24GB RAM, in the same region as your DB. ~$60-80/month.**

That's it. No GPU. No multi-instance setup. No over-provisioning. This handles 20-25 onboarded users (1-3 concurrent) at 5-25s per query, which is acceptable for school staff.

---

## 2. Why this is enough

**20-25 users onboard ≠ 20-25 concurrent users.** School staff aren't power users. A principal asks ~5-10 questions/day. 25 users × 10 questions = 250/day, spread over 8 hours = 1 question every 2 minutes. Your real concurrency is 1-2, maybe 3 at peak. The 8-OCPU / 24GB box handles this without breaking a sweat.

**The 7B model on CPU is tolerable.** 5-25s per query (v27 today; v28 + CTE-form scoping will be faster). For school staff asking a few questions a day, the wait is fine. A GPU would drop it to 0.5-4s — nice, but you don't need it at 25 users.

**Proximity to the DB is free in OCI.** Put the LLM in the same region (ideally the same VCN) as the DB. Execute round-trips are 1ms. No WAN latency. See `docs/OCI_DEPLOYMENT.md` for the topology.

---

## 3. The three options (cheapest to most)

| Option | What | Cost | When |
|---|---|---|---|
| **1. Single OCI instance** | VM.Standard.E4.Flex, 8 OCPU, 24GB, same region as DB | ~$60-80/month | **Now.** 0-25 clients. |
| **2. Two OCI instances** | API (public subnet) + LLM (private subnet) | ~$140-180/month | Before the VAPT test (the isolation matters) OR when you exceed 10 clients. |
| **3. Add a GPU** | + a VM with an A10 (24GB VRAM) | +$300-500/month | Only if 25+ concurrent users (unlikely for a school ERP). |

**Recommendation:** start with Option 1 today. Move to Option 2 before the VAPT test. Skip Option 3 unless you hit a wall.

---

## 4. The latency math

| Component | Time | Where |
|---|---|---|
| LLM generation (v27, CPU 8 OCPU) | 5-25s | The dominant cost |
| Pipeline stages (guardrail, semantic, validate, bind) | <500ms | Local Python |
| ExecuteQuery round-trip (1 page) | ~200-500ms | LAN to the DB (1ms RTT) |
| Pagination (5 pages) | ~1-2s | 5 sequential calls |
| **Total (simple query)** | **~6-28s** | |
| **Total (complex query + 5 pages)** | **~8-30s** | |

After v28 (CTE-form scoping cuts SQL 30-50% → fewer tokens → faster inference):

| Component | v27 | v28 |
|---|---|---|
| LLM generation | 5-25s | 3-15s (shorter SQL) |
| **Total (simple)** | 6-28s | **4-18s** |
| **Total (complex)** | 8-30s | **6-20s** |

The 8-OCPU box handles this. A GPU would drop the LLM to 0.5-4s, but for 25 users it's a luxury, not a necessity.

---

## 5. The scale-up triggers

Move to Option 2 (two instances) or add a GPU when:

- **You exceed 10 concurrent users** (the single-instance CPU starts contending between the backend + the LLM).
- **Before the VAPT test** (the two-instance topology isolates the LLM in a private subnet — defense-in-depth).
- **If latency exceeds 30s consistently** (a GPU cuts it 10x).

For 20-25 onboarded users (1-3 concurrent), none of these triggers fire. Stay lean.

---

## 6. The cost trajectory

| Phase | Users | Config | Monthly cost |
|---|---|---|---|
| Demo / first 1-2 clients | 0-5 | Single OCI instance | ~$60-80 |
| 5-25 clients onboard | 5-25 | Single OCI instance | ~$60-80 |
| Before VAPT / 10+ clients | 10-25 | Two OCI instances | ~$140-180 |
| 25+ concurrent (unlikely) | 25+ | Add a GPU | +$300-500 |

**Total to get from 0 to 25 clients: ~$60-80/month.** No on-prem hardware (you're all-cloud). No GPU. No over-provisioning.

---

## 7. The deployment checklist (the short version)

1. [ ] Launch the OCI VM.Standard.E4.Flex (8 OCPU, 24GB) in the same region as the DB.
2. [ ] Put it in a VCN with a public subnet (the API) + a private subnet (the LLM), per `docs/OCI_DEPLOYMENT.md`.
3. [ ] Install nginx + the FastAPI backend on the API instance; llama.cpp on the LLM instance (or both on one for the cheapest start).
4. [ ] Store secrets in OCI Vault (auth tokens, admin tokens, tenant API keys).
5. [ ] Configure the WAF + TLS + security headers (per `docs/OCI_DEPLOYMENT.md`).
6. [ ] Run the pre-VAPT checklist (`docs/VAPT_READINESS.md` §3).

The full deployment doc is `docs/OCI_DEPLOYMENT.md`. The VAPT checklist is `docs/VAPT_READINESS.md`. This doc is the "what hardware do I need" answer — lean, for your situation.

---

## 8. The bottom line

**One OCI VM.Standard.E4.Flex, 8 OCPU, 24GB, same region as your DB. ~$60-80/month.** That's the lean config for 20-25 onboarded users. No GPU, no on-prem, no multi-instance (until the VAPT test or 10+ concurrent users). Keep it lean; scale only when you hit a wall.

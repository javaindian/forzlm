# Production Trace Observations — Batch 1

**Date:** 2026-08-27
**Source:** 18 real production traces from the user (api_wrapper mode, user 116, branch 1)
**Purpose:** observe the patterns, record them for future action (rule additions, training-data gaps, schema-catalog drift, semantic-engine improvements). Not a fix — a memory.

---

## 1. Summary tally

| Outcome | Count | % |
|---|---|---|
| ANSWER (executed, returned rows) | 14 | 78% |
| execute: api FAILED (passed all gates, DB execution failed) | 4 | 22% |
| guardrail FAILED (hallucinated table/column, refused) | 6 | 33% |
| alias_scope FAILED (alias out of scope, refused) | 1 | 6% |

(Some questions hit multiple categories — e.g. Q14 failed guardrail AND alias_scope. The counts overlap.)

**Of the 14 ANSWERs, 6 have semantic mismatches** (the SQL executed and returned rows, but the answer doesn't match what the user asked). That's a **43% semantic-mismatch rate among "successful" answers** — the most important finding in this batch.

---

## 2. The 5 failure patterns

### Pattern 1 — Hallucinated "convenience" columns (6 cases)

The model invents columns that SHOULD exist for the concept but don't:

| Question | Hallucinated column | Where it actually lives |
|---|---|---|
| "How many Bonafide certificates generated" | `StudentAcademicDetail.IsBonafide` | Not in the catalog — may be a different table (`StudentCertificate`? `BonafideCertificate`?) — needs schema check |
| "Preadmission fee collected" | `FeesCollection.IsPreAdmissionFee` | Not a flag — pre-admission fees are in `ProspectusFeesCollection` (a different table) |
| "Report card published" | `StudentAcademicDetail.IsReportSubmitted` | Likely in `ExamProgressCardModel` or a report-card-specific table |
| "Class wise concession" | `ClassMaster.ClassName` (alias `f`) | `ClassMaster.Name` — the model used the wrong column name |
| "Class wise concession" | `FeesCollection_Details.IsIncludedInLumpSum` | `IsIncludedInLumpSum` is on `FeesInformationStudentDetail`, NOT on `FeesCollection_Details` |
| "Exam wise failed students" | `StudentMarkDetails.MinMark` + `StudentMarkDetails.SubjectsFailed` | `MinMark` is on exam-config tables (EXAM-006 rule); `SubjectsFailed` doesn't exist anywhere |
| "Exam mark entry not entered" | `Subject_Master.ExamTypeID` | No direct link — the relationship is via `SubjectAllocation_Master` |

**The retry doesn't help** — the model re-hallucinates the same or a similar column. The training data doesn't have enough correct examples for these concepts.

**Implied action:**
- Add 3 new semantic rules: a "column exists on table X but not on table Y" cross-table check for the known confusions (`IsIncludedInLumpSum` on `_Details` not `FeesCollection_Details`; `ClassName` on `ClassMaster` is actually `Name`; `MinMark` not on marks tables — already EXAM-006).
- Add training examples for: bonafide certificates, pre-admission fees (use `ProspectusFeesCollection`), report card publication, exam mark entry status, rank generation status. These are all coverage gaps.
- **Ask the dev team (2.3)** for the correct table/column for each of these concepts — the model is guessing because the training data doesn't cover them.

### Pattern 2 — Wrong table (deprecated/live twin confusion) (2 cases)

| Question | Wrong table the model used | Correct table |
|---|---|---|
| "Staff type wise count" | `EmployeeMaster` | `Staff_Master` (alias `sm`/`sfm`). `EmployeeMaster` may not exist in the live DB. |
| "How many feedback received" | `GeneralFeedback` (hallucinated — doesn't exist) | `FeedbackTicket` (the Parent Feedback module table) |

**Note:** the `EmployeeMaster` case passed the guardrail (it's in the schema catalog) but the execute failed — suggesting the catalog has drifted from the live DB, OR `EmployeeMaster` exists but is empty/inaccessible. **The `GeneralFeedback` case was caught by the guardrail (table doesn't exist).**

**Implied action:**
- Add a new semantic rule: `STAFF-004` — staff queries must use `Staff_Master`, not `EmployeeMaster` (deprecated/empty twin). Same pattern as the existing deprecated-table rules.
- Add `FeedbackTicket` to the training data for feedback questions (the Parent Feedback module has only 56 training examples — thin).
- **Schema-catalog drift check (ask 3.3 update):** the dev team should confirm whether `EmployeeMaster` exists in the live DB or is a stale catalog entry.

### Pattern 3 — Semantic mismatch (right syntax, wrong meaning) (6 cases)

**These are the hardest to catch** — the SQL passes every gate, executes, returns rows, but the answer doesn't match the question:

| Question | What the SQL returned | What the user wanted | The gap |
|---|---|---|---|
| "Fee head wise paid amount" | Grouped by `FeesCollection_Details.FeesGroup_Name` | Fee HEAD (e.g. "Admission Fee", "Tuition Fee") | Model confused fee GROUP (`FeesGroup_Name`) with fee HEAD (`Fees_Head_ID` → `Fees_Master.Name`). Different concepts. |
| "How many messages sent in the AY" | Counted `GeneralCallRegister` rows (13) | SMS/WhatsApp messages (`SMSAuditTrail`) | Model used the enquiry table for "messages." Completely wrong data. |
| "Attendance not entered" | Listed students with `Attendance_Status_ID = 2` (absent) | Students with NO attendance record for the day | "Not entered" ≠ "marked absent." The model doesn't understand the "no record exists" concept (needs a `LEFT JOIN ... WHERE x IS NULL` or `NOT EXISTS`). |
| "Compare with yesterday" | Combined today + yesterday into one row per class | Two columns or two rows (today vs yesterday) | Model doesn't understand "compare" — it unions the dates instead of separating them. |
| "Fee head wise concession" | Returned `Fees_Head_ID` (numeric: 1, 2, 3...) | Fee head NAMES (e.g. "Admission Fee") | Missing JOIN to `Fees_Master` for the name. Technically correct but not human-readable. |
| "Exam wise rank generation pending" | Listed all subjects (`SELECT DISTINCT s.Name FROM Subject_Master`) | Subjects where rank generation is pending | The model has no idea where rank-generation status lives, so it returned all subjects. |

**The semantic engine cannot catch these** without understanding the difference between `FeesGroup_Name` and `Fees_Head_ID`, or between "absent" and "not entered." This is the next frontier for the semantic engine — **intent-level semantic checks**, not just column-existence checks.

**Implied action (v1.1 semantic engine):**
- A new rule class: "group-by column must match the requested dimension." If the user asks "fee head wise," the GROUP BY must reference a fee-head column (`Fees_Master.Name` via JOIN, or `Fees_Head_ID` + a JOIN for the name), not a fee-group column (`FeesGroup_Name`).
- A new rule class: "messages ≠ enquiries." If the user asks about "messages sent," the query must touch `SMSAuditTrail` or `WhatsAppConfiguration`-related tables, not `GeneralCallRegister`.
- A new rule class: "absent ≠ not entered." If the user asks "attendance not entered," the query must use `NOT EXISTS` or `LEFT JOIN ... IS NULL` (find students with NO record), not `Attendance_Status_ID = 2` (find students marked absent).
- A new rule class: "compare requires separation." If the user asks "compare X vs Y," the query must produce two distinct columns or rows (e.g. via a CASE pivot or a UNION with a label), not combine them.
- A new rule class: "ID columns must be joined to their name table for human-readable output." If the SELECT includes a numeric ID (`Fees_Head_ID`, `StaffType_ID`, `ApplicationStatus_ID`), it must JOIN to the master table for the name.

### Pattern 4 — execute: api FAILED with no specific error (4 cases)

| Question | Likely cause |
|---|---|
| "Enquiries + this week class wise" (CTE + UNION ALL) | The CTE `WITH AllowedBranches AS (...)` references `@UserId` + `@SelectedBranchId`, then two UNION ALL branches each re-reference `@UserId`/`@SelectedBranchId`. Even with `use_inline_params: true`, the CTE + UNION ALL may trigger the ExecuteQuery API's known bug with repeated placeholders. OR a timeout (the query is complex). |
| "Bonafide certificates" | `IsBonafide` column may not exist in the live DB (catalog drift) — passed the guardrail because the catalog has it, but the live DB doesn't. |
| "Staff type wise count" | `EmployeeMaster` may not exist in the live DB (same drift issue). |
| "Exam rank generation pending" | The query is trivially wrong (returns all subjects) — the execution failure may be unrelated (a permission issue, or the query is fine but the API timed out). |

**Implied action:**
- **Ask the dev team (2.1):** confirm the ExecuteQuery API bug status — the CTE+UNION ALL case is the most complex query shape and the most likely to hit the repeated-placeholder bug.
- **Schema-catalog drift audit:** compare the 475-table catalog against the live DB. The `IsBonafide` and `EmployeeMaster` cases suggest the catalog has tables/columns the live DB doesn't. A drift audit catches this.
- **Improve the error surface:** when execute fails, the backend returns "A database error occurred" with no detail. The `detail` field should include the actual SQL Server error message (the `ErrorMessage` from the ExecuteQuery response) so we can diagnose. This is a backend improvement.

### Pattern 5 — Retry doesn't help (observed in 4 guardrail-failure cases)

When the guardrail fails, the orchestrator appends the error to the prompt and regenerates. But the model re-hallucinates the same or a similar column:

| Question | First attempt | Retry |
|---|---|---|
| "Class wise concession" | `f.ClassName` + `fcd.IsIncludedInLumpSum` | Same hallucinations |
| "Preadmission fee" | `fc.IsPreAdmissionFee` | Same hallucination |
| "Exam mark entry not entered" | `sub.ExamTypeID` | Same hallucination |
| "Report card published" | `sad.IsReportSubmitted` | Same hallucination |

**The retry prompt says "a previous attempt used a column that doesn't exist; write the correct T-SQL."** But the model doesn't know the correct column — it has no training examples for the concept, so it guesses the same way again.

**Implied action:**
- The retry prompt should include a HINT about the correct table/column, not just the error. E.g. "Column `IsPreAdmissionFee` does not exist on `FeesCollection`. Pre-admission fees are in `ProspectusFeesCollection`. Use that table." This requires a "hint map" (hallucinated column → correct location) — a new component.
- OR: the retry should refuse after the first failure if the hallucination is in a known-uncoverable concept (one with no training examples). Don't waste a second LLM call that will re-hallucinate.

---

## 3. The brightest spots (what worked well)

To be balanced — these worked correctly and show the pipeline's strengths:

| Question | Why it's good |
|---|---|
| "Class wise outstanding amount" | **The full correct pattern:** `Amount - ISNULL(Concession_Amt,0) - ISNULL(Paid_Amt,0) - ISNULL(Lien_Amount,0)` + `IsIncludedInLumpSum <> 1` + `Structure_Type IN ('Academic','Optional')` + `IsDonation = 0` + `AcademicYearID via Branch_Academic_Details`. This is the exact pattern the semantic engine enforces. |
| "Class wise fee paid amount" | `FeesCollection.Receipt_Amt` (not `Amt`) + `ChequeStatus_ID NOT IN (3,4)` + academic-year filter. Correct. |
| "Student strength + new admission" | `StudentAcademicDetail` + `SectionMaster` + `IsActive = 1` + `AcademicYearID`. Correct. |
| "Class wise breakup count" | `IsActive = 1` + `(IsTCIssued = 0 OR IsTCIssued IS NULL)` + academic year. Correct, with the TC filter. |
| "Attendance present %" | `Attendance_Status_ID = 1` / total with `NULLIF`. Correct. |
| "Attendance status counts (present/absent/late/other)" | SUM(CASE WHEN ...) pivot. Correct. |

**The fee-outstanding query (Q7) is the model's best work** — it hits every semantic rule (Lien, Structure_Type, LumpSum, IsDonation, AcademicYearID). This is the pattern the v28 retrain should generalize across all fee questions.

---

## 4. The schema-catalog drift finding

Two traces (Q4 "Bonafide" + Q5 "Staff type wise") passed the guardrail (the columns/tables are in the 475-table catalog) but failed at execute time. The most likely explanation: **the schema catalog has drifted from the live DB** — it has tables/columns that the live DB doesn't.

This is a new finding. The schema catalog (`schema_catalog.json`) was generated from a schema dump; the live DB may have been altered since (columns renamed, tables dropped, etc.).

**Implied action (new dev team ask 3.4):** re-export the schema from the live DB and diff against `schema_catalog.json`. If there's drift, update the catalog. This prevents the guardrail from passing queries that will fail at execution.

---

## 5. The semantic-mismatch rate (the headline finding)

**6 of 14 "successful" answers (43%) have semantic mismatches** — the SQL executed and returned rows, but the answer doesn't match what the user asked. This is far more dangerous than a refusal: the user gets a confident wrong answer.

| # | Question | Returned | Should have returned |
|---|---|---|---|
| 6 | Fee head wise paid | Fee GROUP names | Fee HEAD names |
| 11 | Concession type wise | 0 rows (wrong table?) | Applied concessions (may need `Concession_Details` not `Concession_Master`) |
| 12 | Fee head wise concession | Numeric `Fees_Head_ID` (1, 2, 3...) | Fee head NAMES |
| 17 | Messages sent | 13 (count of enquiries) | SMS count from `SMSAuditTrail` |
| 20 | Attendance not entered | 37 absent students | Students with NO attendance record |
| 23 | Compare with yesterday | 2 rows (today+yesterday combined) | Today vs yesterday separated |

**The semantic engine's current 32 rules catch structural/syntactic semantic bugs (wrong term master, missing Lien, missing Structure_Type). They do NOT catch intent-level mismatches** (fee group vs fee head; absent vs not entered; enquiries vs messages; combine vs compare).

**This is the next frontier for the semantic engine: intent-level rules.** The v1.1 engine needs rules that understand:
- The requested dimension (fee head vs fee group vs fee category) and check the GROUP BY matches it.
- The requested data source (messages vs enquiries vs calls) and check the table matches it.
- The requested operation (compare vs list vs count) and check the SQL shape matches it.
- The "not entered" / "not exists" concept (needs a LEFT JOIN ... IS NULL or NOT EXISTS pattern, not a status filter).

These are harder to write (they require understanding the question's intent, not just the SQL's structure) but they're the highest-leverage addition for v1.1.

---

## 6. What this batch tells us about the v28 retrain

The 18 traces reveal the training-data coverage gaps:

| Concept | Coverage in v27 | Needs |
|---|---|---|
| Bonafide certificates | ~0 | 5-10 examples (find the right table first) |
| Pre-admission fees | ~0 | 5-10 examples using `ProspectusFeesCollection` |
| Report card publication | ~0 | 5-10 examples (find the right table) |
| Exam mark entry status | ~0 | 5-10 examples (the "not entered" pattern) |
| Rank generation status | ~0 | 5-10 examples (find the right table) |
| Fee head vs fee group distinction | thin | 10-15 examples that JOIN to `Fees_Master` for the name |
| Messages (SMS/WhatsApp) | ~0 | 5-10 examples using `SMSAuditTrail` |
| "Not entered" / "not exists" patterns | ~0 | 10-15 examples with `NOT EXISTS` / `LEFT JOIN ... IS NULL` |
| "Compare X vs Y" patterns | ~0 | 10-15 examples with CASE pivot or UNION with labels |
| Concession (applied vs requested) | thin | 5-10 examples using `Concession_Details` not `Concession_Master` |

**Total: ~60-100 new training examples** to close the gaps this batch revealed.

---

## 7. The new semantic rules suggested by this batch

For the v1.1 semantic engine, based on these 18 traces:

| Rule ID | What it catches | Example |
|---|---|---|
| STAFF-004 | Staff queries using `EmployeeMaster` instead of `Staff_Master` | Q5 |
| FEEDBACK-001 | Feedback queries using `GeneralFeedback` (doesn't exist) instead of `FeedbackTicket` | Q24 |
| FEE-023 | `IsIncludedInLumpSum` referenced on `FeesCollection_Details` (it's on `FeesInformationStudentDetail`) | Q10 |
| FEE-024 | Fee-head-wise queries grouping by `FeesGroup_Name` (fee group, not fee head) | Q6 |
| FEE-025 | Queries returning `Fees_Head_ID` (numeric) without joining `Fees_Master` for the name | Q12 |
| COMM-001 | "Messages sent" queries using `GeneralCallRegister` (enquiries) instead of `SMSAuditTrail` | Q17 |
| ATT-001 | "Not entered" / "not marked" attendance queries using a status filter instead of `NOT EXISTS` / `LEFT JOIN ... IS NULL` | Q20 |
| COMPARE-001 | "Compare X vs Y" queries that combine the two into one row instead of separating them | Q23 |
| CLASSNAME-001 | `ClassMaster.ClassName` referenced (it's `Name`) | Q10 |
| BONAFIDE-001 | `StudentAcademicDetail.IsBonafide` referenced (needs schema confirmation — may not exist) | Q4 |
| PREADM-001 | `FeesCollection.IsPreAdmissionFee` referenced (pre-admission fees are in `ProspectusFeesCollection`) | Q13 |
| REPORTCARD-001 | `StudentAcademicDetail.IsReportSubmitted` referenced (needs schema confirmation) | Q16 |

12 new rules — would bring the engine from 32 to 44 rules. The intent-level ones (FEE-024, FEE-025, COMM-001, ATT-001, COMPARE-001) are the hardest to write but the highest-value.

---

## 8. The retry-prompt improvement

The retry prompt currently says "a previous attempt used a column that doesn't exist; write the correct T-SQL." It should say "a previous attempt used column X on table Y; it doesn't exist. The correct approach is <hint>."

This needs a **hint map** — a lookup from (hallucinated column, table) → correct approach. For the 12 cases above, the hint map would be:

```python
HINT_MAP = {
    ("FeesCollection", "IsPreAdmissionFee"): "Pre-admission fees are in ProspectusFeesCollection, not in FeesCollection. Use ProspectusFeesCollection with ApplicationNo.",
    ("ClassMaster", "ClassName"): "ClassMaster.Name is the column (not ClassName).",
    ("FeesCollection_Details", "IsIncludedInLumpSum"): "IsIncludedInLumpSum is on FeesInformationStudentDetail, not on FeesCollection_Details.",
    ("StudentMarkDetails", "MinMark"): "MinMark is on ExamConfigurationEvaluationDetails (the exam-config table). JOIN it.",
    ("StudentAcademicDetail", "IsReportSubmitted"): "Report card status is in ExamProgressCardModel or a report-card-specific table. Confirm with the dev team.",
    ("Subject_Master", "ExamTypeID"): "Subject_Master has no ExamTypeID. The subject-exam link is via SubjectAllocation_Master.",
    ("GeneralFeedback", None): "GeneralFeedback doesn't exist. Use FeedbackTicket for feedback queries.",
    ("EmployeeMaster", None): "EmployeeMaster is deprecated. Use Staff_Master for staff queries.",
}
```

The retry prompt includes the hint: "Column `IsPreAdmissionFee` does not exist on `FeesCollection`. Pre-admission fees are in `ProspectusFeesCollection`. Use that table with `ApplicationNo`." This gives the model the correct path instead of asking it to guess again.

---

## 9. What I'm recording for future action (the memory)

This section is the actionable memory — what we should do, when, in what order.

**For the v1.1 semantic engine (next batch of rule additions):**
1. Write the 12 new rules in §7 (STAFF-004, FEEDBACK-001, FEE-023/024/025, COMM-001, ATT-001, COMPARE-001, CLASSNAME-001, BONAFIDE-001, PREADM-001, REPORTCARD-001). The intent-level ones (FEE-024, FEE-025, COMM-001, ATT-001, COMPARE-001) are the highest-value.
2. Build the hint map (§8) and wire it into the retry prompt.

**For the v28 training data:**
3. Add ~60-100 new training examples covering the gaps in §6 (bonafide, pre-admission, report cards, exam mark entry, rank generation, fee head vs group, messages, not-entered patterns, compare patterns, applied vs requested concessions).

**For the dev team asks:**
4. Add ask 3.4: re-export the schema from the live DB and diff against `schema_catalog.json` (the catalog drift finding).
5. Add ask 3.5: confirm the correct table/column for bonafide certificates, report card publication, rank generation status, exam mark entry status (the model is guessing because the training data doesn't cover them and the schema audit didn't find them).

**For the backend:**
6. Improve the execute-error surface: when execute fails, include the actual SQL Server error message (the `ErrorMessage` from the ExecuteQuery response) in the `detail` field, not just "A database error occurred." This is essential for diagnosing the 4 execute-failed cases.

**For the accuracy harness:**
7. Add 6 new golden questions based on the semantic-mismatch cases (Q6, Q12, Q17, Q20, Q23) — these are the intent-level checks the harness should score.

---

## 10. The bottom line

This batch of 18 traces is the most valuable production data we've received. It reveals:

- **The pipeline's structural safety works** — all 6 hallucinated-column cases were caught by the guardrail; the alias-scope case was caught; the branch-scoping passed everywhere.
- **The 43% semantic-mismatch rate among "successful" answers is the headline finding.** The current semantic engine catches structural/syntactic bugs but NOT intent-level mismatches. This is the v1.1 frontier.
- **The retry doesn't help for coverage-gap hallucinations** — the model re-hallucinates because it has no training examples for the concept. The hint map (§8) is the fix.
- **Schema-catalog drift is a new finding** — 2 cases passed the guardrail but failed at execute. The catalog needs a re-sync.
- **The v28 retrain needs ~60-100 new examples** to close the coverage gaps this batch revealed.

The user said "just observe and put this in your memory for our future action." This doc IS that memory. When we start the v1.1 work, this is the first thing to read.

---

## UPDATE — Source clarification

**Correction:** the 18 traces in this document were drawn from the project owner's **existing Streamlit app (`ui_app.py`)**, NOT from the FastAPI backend I built in `chalo_chatbot/backend/main.py`. The findings below still hold for the *pipeline behavior* (the semantic engine, the guardrail, the branch-scoping, the validate-and-substitute path — all of which are shared between the two frontends because they live in `pipeline/`), but the *frontend-specific* observations are about the Streamlit app's behavior, not mine.

### What this means for the findings

**Still valid (these are pipeline-level, shared):**
- The 43% semantic-mismatch rate — the SQL is generated by the same model + same pipeline stages, regardless of which frontend called it. The semantic engine's gaps (intent-level rules) are the same.
- The 6 hallucinated-column guardrail failures — the guardrail is the same `pipeline/guardrail.py` in both apps.
- The 4 execute: api FAILED — the `api_executor.py` is shared.
- The retry-doesn't-help pattern — the retry logic is in `orchestrator.py`, shared.
- The schema-catalog drift finding — the catalog is shared.
- The 12 suggested new semantic rules — all pipeline-level.
- The ~60-100 new training examples needed — training-data-level, independent of frontend.
- The 2 new dev team asks (3.4 schema re-sync, 3.5 confirm tables/columns) — independent of frontend.

**Applies to the Streamlit app, NOT my backend (but the fix is the same):**
- The "execute: api FAILED — A database error occurred" surface — this is the Streamlit app's error display. My FastAPI backend returns the error in `detail` (the `ErrorMessage` from ExecuteQuery) in the JSON response — but the Streamlit app may not surface it. **Action: confirm my backend surfaces the real SQL Server error in `detail`.** (It should — `api_executor.py` returns `raw.get("ErrorMessage")` — but I should verify the backend's `main.py` passes it through to the response.)
- The "Filtered by: absent" / "Filtered by: currently active students only" annotations — these are Streamlit-app UI text added on top of the pipeline result. My Next.js UI doesn't add these (it shows the raw `message` field). Not a bug; a UX difference.

**Does NOT apply to my backend (Streamlit-specific behavior):**
- The Streamlit app's audit_trail.db logging — my backend doesn't have audit logging yet (ask 3.1, pending).
- The Streamlit app's "Health Check" / "Configuration Help" views — my backend has `/api/health` only; the local-test Next.js UI has a settings drawer.
- The Streamlit app's logo rendering, sidebar, etc. — purely frontend.

### What this means for the v1.1 work

The 12 new semantic rules + the hint map + the ~60-100 training examples + the intent-level rules are all **pipeline-level work** — they apply to whichever frontend calls the pipeline. The work is the same whether you keep the Streamlit app, switch to my FastAPI backend, or run both.

The one Streamlit-specific finding to carry forward: **the error surface when execute fails.** The Streamlit app shows "A database error occurred" (no detail). My FastAPI backend should show the actual SQL Server error. I'll verify this in `backend/main.py` + `api_executor.py` and confirm it surfaces the real `ErrorMessage`.

### Action taken

- Updated this doc with the source clarification (this section).
- Updated `SESSION_HANDOFF.md` to note the traces came from the Streamlit app.
- Added a verification task to the v1.1 list: confirm `backend/main.py` surfaces the real SQL Server error in the `detail` field when execute fails (it should, but verify).

### The bottom line

The findings are real and the v1.1 work is the same. The source clarification matters for accuracy (I shouldn't claim my backend produced these traces — it didn't) and for one specific action (verify my backend's error surface). The pipeline is shared; the frontend is not.

### Verification: my backend surfaces the real SQL Server error

Traced the error path end-to-end (confirmed 2026-08-27):

1. **`pipeline/parameter_binder.py` line 517:** `error=raw.get("ErrorMessage") or "Query failed on the server."` — extracts the actual SQL Server error message from the ExecuteQuery API response.
2. **`pipeline/orchestrator.py` line ~649 (api-failed path):** `detail=getattr(ex, "error", "execution failed")` — passes the executor's error into the `PipelineResult.detail` field.
3. **`backend/main.py` line 258:** `detail=result.detail` — maps it into the `ChatResponse.detail` field of the JSON response.

**Conclusion:** the FastAPI backend I built already surfaces the real SQL Server error in the `detail` field. The Streamlit app's "A database error occurred" (no detail) is a UI choice in the Streamlit app, not a pipeline limitation. **No code change needed in my backend** — the error already flows through. The mobile app (per `API_CONTRACT.md`) should display `detail` when `outcome == "ERROR"` and `stage == "execute"`, so the user sees the real SQL Server error (or the dev team sees it in the logs).

This is a Streamlit-app-specific finding, not a pipeline finding. The pipeline + my backend handle it correctly.

---

## Batch 2 — 25 more production traces (2026-08-28)

**Source:** the existing Streamlit app (`ui_app.py`), `api_wrapper` mode, user 116, branch 1. Same source as batch 1.

### Tally

| Outcome | Count | % |
|---|---|---|
| ANSWER (returned rows, including None/0) | 17 | 68% |
| execute: api FAILED | 4 | 16% |
| guardrail FAILED (hallucinated tables/columns) | 5 | 20% |
| Retry succeeded (after initial timeout) | 1 | — |

(Note: one question hit two categories — Q13 timed out then retried successfully.)

### Semantic mismatches among ANSWERs: 3 of 17 (18%)

Lower than batch 1's 43%, but still present:

| # | Question | What it returned | What was wanted | The gap |
|---|---|---|---|---|
| Q6 | "How many new admissions this week?" | 22 (all new admissions this AY) | New admissions THIS WEEK only | No `DATEADD(week,-1)` or `DATEDIFF(week)` filter. Used `IsNewAdmission=1` + current AY. Returns the year's total, not the week's. |
| Q19 | "Staff not marked attendance this week" | 50 staff who were present < 5 times | Staff with NO attendance record this week | Used `Attendance_Status_ID = 1` + `HAVING COUNT(*) < 5` — finds partially-marked staff, not unmarked. Same "not entered" bug from batch 1 Q20. Needs `NOT EXISTS` / `LEFT JOIN ... IS NULL`. |
| Q25 | "Compare Main Campus and North Campus" | 0 rows (searched ClassMaster.Name LIKE '%Main%'/'%North%') | Branch-level comparison (BranchMaster.Name) | Campuses are BRANCHES, not classes. The model searched class names for "Main"/"North" — wrong table. The multi-school-benchmark concept (brainstorm 7.1). |

### New patterns (not seen in batch 1)

#### Pattern 6 — The "compare X vs Y" query fails the ExecuteQuery API (confirmed, 2 more cases)

Q4 ("this month vs last month") and Q9 ("this year vs last year") both use `UNION ALL` with the full branch-scoping subquery repeated in each branch. Both hit `execute: api FAILED`. This is the **same confirmed ExecuteQuery bug** from batch 1 Q1 — repeated `@UserId`/`@SelectedBranchId` placeholders in a UNION ALL. Three total confirmed cases now.

**The fix is the CTE-form scoping** (§22 in GUIDELINES.md) — declare `WITH AllowedBranches AS (...)` once, reference it in both UNION branches. This avoids repeating the placeholders. Also ask 2.1 (dev team fixes the API bug).

#### Pattern 7 — Comment-prefixed SQL confuses the binder (1 case)

Q24 ("morning briefing") — the model produced a SQL starting with `-- This question asks for a broad overview...` then a complex multi-subquery SELECT. The binder rejected it: "Only SELECT queries and CTEs (WITH...SELECT) are permitted."

The model is trained to write refusal messages with a `--` comment prefix (the 11 refusal examples in v27). But here it tried a hybrid: a comment explaining the approach, then a real query. The binder's `_assert_read_only` in `parameter_binder.py` strips leading comments — but the Streamlit app's version may not have this fix, OR the comment is followed by a query that's too complex for the binder to parse as a single SELECT.

**Action:** verify the reconstructed `parameter_binder.py` strips leading comments before the first-verb check. (It should — I included the `re.sub(r"^\s*(--[^\n]*\n|/\*.*?\*/)\s*", "", stripped, flags=re.DOTALL)` in `_assert_read_only`.)

#### Pattern 8 — The fast-path cache works (1 case)

Q12 ("lowest attendance today") shows `generate: skipped -- exact dataset match found`. The Streamlit app has fast-paths **enabled**. My backend has them **disabled by default** (D1.9). This is a config difference — the Streamlit app uses the original `config.yaml` which has the fast-path path set (even though it's stale at v25).

**Observation:** the fast-path served the correct SQL for this question (the trace shows the same SQL as the training set). But 12.4% of v27 training SQL is semantically buggy. The fast-path is a **lottery** — correct for ~88% of cached questions, wrong for ~12%. My D1.9 default (OFF) is the safe choice until the labels are cleaned.

#### Pattern 9 — The retry mechanism works (1 case)

Q13 ("staff absent today") — first execute FAILED with a timeout (`WinError 10060`), then the retry produced the same SQL and it succeeded. The retry path is functional in the original pipeline. Good evidence D1.5 (retry re-check) is needed — the retried SQL should re-run the branch-scoping gate (it does in my backend).

#### Pattern 10 — Pagination cap is visible to the user (2 cases)

Q7 ("classes with seats available") returned 50 rows across 5 pages, "capped at 5 pages, 63 row(s) not fetched." Q19 ("staff not marked") same: "50 rows across 5 pages, capped, 63 not fetched."

The `max_auto_pages: 5` (from config.yaml) is working — the backend auto-fetches up to 5 pages (50 rows). But the user sees incomplete results. For management questions, 50 rows may not be enough (e.g. a 113-row staff list).

**Action:** consider raising `max_auto_pages` to 10-20 for management-facing queries (the latency cost is sequential HTTP calls — ~2-5s per page). OR: the mobile app should show "50 of 113 rows shown — Load more" and fetch additional pages on demand via the `page_number` parameter. The latter is the better UX (the `API_CONTRACT.md` §7 already documents this pattern).

### Hallucinated tables/columns (5 new cases, same pattern as batch 1)

| # | Question | Hallucinated | Correct location (needs dev team confirmation) |
|---|---|---|---|
| Q16 | "Teaching positions vacant" | `PositionOpening`, `PositionType_Master` (tables don't exist) | Likely `StaffResignationRequest` or a vacancy-tracking table; confirm with dev team (ask 3.5) |
| Q21 | "Parent complaints" | `FeedbackTicket.ParentChildIndicator` (column doesn't exist) | The parent-vs-student indicator may be `FeedbackTicket.FeedbackType` or a similar column; confirm with dev team |
| Q22 | "Transport routes late" | `Route_MasterDetails.Vehicle_ID`, `VehicleMaster.Registration_No` (columns don't exist) | Real-time route tracking likely doesn't exist in the schema (no GPS table); the "running late" concept may not be supportable |
| Q23 | "Inventory items low" | `InventoryItem_Master.MinStockLevel` (column doesn't exist) | The low-stock indicator may be a `ReorderLevel` column or derived from `GoodsReceiptInfo` vs `StockAdjustmentDetails`; confirm with dev team |
| Q24 | "Morning briefing" | No hallucinated columns — but the multi-subquery SELECT was too complex for the binder | The "morning briefing" is a brainstorm feature (2.1) that requires a scheduled backend job, not a single LLM-generated query |

### What worked well (the brightest spots)

| # | Question | Why it's good |
|---|---|---|
| Q1 | "Today's total fee collection across all branches" | Perfect: `SUM(Receipt_Amt)` + `ChequeStatus_ID NOT IN (3,4)` + `CAST(Bill_Date AS DATE) = CAST(GETDATE() AS DATE)` + branch scoping + `GROUP BY BranchMaster.Name`. Every filter correct. |
| Q2 | "Fees pending for Class 10" | The full outstanding pattern: `Amount - Concession - Paid - Lien` + `Structure_Type IN ('Academic','Optional')` + `IsIncludedInLumpSum <> 1` + `IsDonation = 0` + `AcademicYearID` + `IsActive` + `IsTCIssued` + `ClassName = 'Class 10'`. Every semantic rule satisfied. (Returned None — likely no Class 10 outstanding at this branch.) |
| Q5 | "Total revenue this AY" | `SUM(Receipt_Amt)` + `ChequeStatus_ID` + `AcademicYearID via Branch_Academic_Details`. Correct. Returned 803,975. |
| Q8 | "Admission conversion rate" | `COUNT(CASE WHEN asm.Name = 'Admitted') * 100.0 / NULLIF(COUNT(*), 0)`. Correct. Returned 61.36%. |
| Q11 | "Today's attendance %" | `COUNT(CASE WHEN = 1) * 100.0 / NULLIF(COUNT(*), 0)`. Correct. Returned 41.67%. |
| Q15 | "Attendance below 75% this term" | `HAVING CAST(count... * 100.0 / NULLIF(count,0) AS DECIMAL(5,2)) < 75`. Correct HAVING-clause pattern. |
| Q17 | "Who is on leave today" | `LeaveEntryMaster` + `LeaveStatus.Name = 'Approved'` + `CAST(GETDATE() AS DATE) BETWEEN LeaveFromDate AND LeaveToDate`. Correct. (Guardrail failed first, retry passed.) |

### The new semantic rules suggested by this batch

| Rule ID | What it catches | From |
|---|---|---|
| FEE-026 | "This week" queries missing a week/date-range filter (only using AY filter) | Q6 |
| STAFF-005 | "Not marked attendance" queries using a status filter + HAVING COUNT < N instead of NOT EXISTS | Q19 |
| CAMPUS-001 | "Campus" queries searching ClassMaster instead of BranchMaster | Q25 |
| POSITION-001 | `PositionOpening` table (doesn't exist — hallucinated) | Q16 |
| FEEDBACK-002 | `FeedbackTicket.ParentChildIndicator` (doesn't exist — hallucinated column) | Q21 |
| TRANSPORT-002 | `Route_MasterDetails.Vehicle_ID` / `VehicleMaster.Registration_No` (hallucinated columns) | Q22 |
| INVENTORY-001 | `InventoryItem_Master.MinStockLevel` (hallucinated column) | Q23 |
| COMMENT-001 | SQL starting with `--` comment + SELECT (the binder should strip comments before the first-verb check) | Q24 |

8 new rules — would bring the engine from 32 to 40 rules.

### Updated training-data gaps (additions from this batch)

| Concept | Gap | Examples needed |
|---|---|---|
| "This week" / "this month" date-range filters | Model omits them when an AY filter is present | 10-15 examples with `DATEADD(week,-1)` / `DATEADD(month,-1)` + the AY filter |
| "Not marked" / "not entered" (confirmed — batch 1 Q20 + batch 2 Q19) | Model uses status filter + HAVING instead of NOT EXISTS | 10-15 examples with `NOT EXISTS` / `LEFT JOIN ... IS NULL` |
| "Campus" = branch (not class) | Model searches ClassMaster for campus names | 5-10 examples using BranchMaster.Name for campus/branch comparison |
| Teaching position vacancies | Model hallucinates `PositionOpening` | 5-10 examples (needs the right table from the dev team) |
| Parent complaints/tickets | Model hallucinates `ParentChildIndicator` | 5-10 examples with the correct FeedbackTicket columns |
| Transport route tracking | Model hallucinates real-time tracking columns | May not be supportable (no GPS table) — refuse instead |
| Inventory low-stock | Model hallucinates `MinStockLevel` | 5-10 examples with the correct low-stock indicator |
| Morning briefing (multi-metric summary) | Too complex for a single query | This is a brainstorm feature (2.1) — needs a scheduled backend job, not a single LLM query |

**Total additional: ~40-65 new training examples** from this batch. Combined with batch 1's ~60-100: **~100-165 total new examples** for v28.

### The "compare X vs Y" pattern — now 4 confirmed failures

Batch 1 Q23 + batch 2 Q4 + Q9 + (the "compare with yesterday" from batch 1 Q23). All use `UNION ALL` with repeated placeholders. All fail the ExecuteQuery API.

**This is the #1 infrastructure fix** — the CTE-form scoping (§22) eliminates the repeated placeholders AND cuts query length 30-50%. It's both a correctness fix (avoids the API bug) and a latency fix (shorter SQL → faster LLM). The v28 retrain should use CTE-form scoping in every training example.

### Updated bottom line (batch 1 + batch 2 combined)

| Metric | Batch 1 (18 Qs) | Batch 2 (25 Qs) | Combined (43 Qs) |
|---|---|---|---|
| ANSWER (returned rows) | 14 (78%) | 17 (68%) | 31 (72%) |
| Semantic mismatches among ANSWERs | 6 (43%) | 3 (18%) | 9 (29%) |
| execute: api FAILED | 4 (22%) | 4 (16%) | 8 (19%) |
| guardrail FAILED | 6 (33%) | 5 (20%) | 11 (26%) |
| Total failures | 10 (56%) | 9 (36%) | 19 (44%) |

The semantic-mismatch rate dropped from 43% to 18% — batch 2's questions were more "standard" (fee collection, attendance counts, admission stats) while batch 1 had more edge cases (bonafide, report cards, exam mark entry, rank generation). The combined 29% rate is the real production number.

**The v1.1 work is now clearer:**
- 40 total semantic rules (32 + 8 new from batch 2).
- ~100-165 new training examples for v28.
- The CTE-form scoping is the #1 infrastructure fix (eliminates 4 of 8 execute failures).
- The "not entered" / "not marked" pattern is confirmed (2 cases) — needs NOT EXISTS training examples.
- The "compare" pattern is confirmed (4 cases) — needs the CTE-form fix + compare training examples.

---

## CRITICAL CORRECTION — All traces were from the v25 model (not v27)

**Date discovered:** 2026-08-28
**Source:** the project owner's direct disclosure.

### What happened

The 43 production traces (batch 1: 18 traces + batch 2: 25 traces) were generated by the **v25 model**, not v27. The project owner was running v25 in production when they collected the traces.

### What v25→v27 changed (631 examples, precisely categorized)

| Change | Count | What happened |
|---|---|---|
| Structure_Type filter removed | 524 | Real SP evidence showed it was silently excluding Hostel/Bus/Misc/Others fees from every "outstanding" total |
| StaffStatus_ID = 1 added | 82 | Missing filter for current-staff questions |
| Rewritten to FeesInformationStudentDetail | 18 | Was using wrong table (FeesCollection_Details) for pending-fee calculations |
| Duplicate questions deduplicated | 10 | Conflicting SQL for same question, one kept |
| Real SSMS syntax bugs fixed | 5 | 3 from fix logic bug, 2 pre-existing (AS alias inside ORDER BY) |

**3,236 examples are byte-for-byte identical to v25** — the majority was never touched.

### What this means for the analysis

1. **The 29% semantic-mismatch rate is the v25 rate, not v27.** v27 should be better — the 524 Structure_Type removals + 82 StaffStatus_ID additions + 18 table rewrites are real improvements. The v27 semantic-mismatch rate should be lower (estimated ~15-20% based on the types of fixes applied).

2. **FEE-005 semantic rule needs refinement.** v27 deliberately REMOVED the Structure_Type filter from 524 "outstanding" examples. My FEE-005 rule flags queries that OMIT Structure_Type on outstanding queries — but v27 intentionally removed it because the filter was silently excluding hostel/bus/misc fees. **The rule needs to distinguish:**
   - "Outstanding total" (user wants the TOTAL including all fee types → no Structure_Type filter needed)
   - "Academic fee outstanding" (user specifically asks about academic fees → Structure_Type IN ('Academic','Optional') IS needed)

3. **ChequeStatus_ID NOT IN (3,4) confirmed correct** — the dev team confirmed 3=bounced, 4=cancelled. The user initially tried IN(1,2) based on frequency in real code, then reverted once the dev team gave the actual meaning. My FEE-011 rule already enforces NOT IN (3,4). **No change needed.**

4. **FeesInformationStudentDetail confirmed as the correct table** for pending-fee queries. The real formula: `Amount - Concession_Amt - Paid_Amt` (joined to TermMaster for term-specific). My semantic rules already reference this table. **No change needed.**

5. **StaffStatus_ID = 1 confirmed** — an existing rule since v22. v27 enforces it more consistently. My STAFF-003 rule already checks this. **No change needed.**

6. **The 12 new semantic rules from the production traces still apply** — the hallucinated columns (PositionOpening, MinMark, etc.), the intent-level mismatches (fee group vs fee head, absent vs not entered), and the compare failures are all v25 AND v27 problems (they weren't fixed in v27).

### Knowledge gained from the v25→v27 diff (recorded for the v28 retrain)

| Knowledge | Source | Status | Impact on semantic rules |
|---|---|---|---|
| Structure_Type has 6 values (Academic, Optional, Hostel, Bus, Misc, Others) | Real production procedure evidence | CONFIRMED | FEE-005 needs refinement: don't require Structure_Type for "total outstanding" queries; DO require it for "academic fee" queries |
| FeesInformationStudentDetail is the correct table for pending fees (not FeesCollection_Details.Remaining_Amt) | GetFeePendingByFeesInformationStudentDetail SP | CONFIRMED | Already in my rules — no change |
| ChequeStatus_ID NOT IN (3,4) is correct (3=bounced, 4=cancelled) | Dev team confirmation | CONFIRMED | Already in my rules (FEE-011) — no change |
| StaffStatus_ID = 1 for active staff | v22 rule, enforced more in v27 | CONFIRMED | Already in my rules (STAFF-003) — no change |
| Frequency in real code ≠ confirmed correctness | The ChequeStatus_ID IN(1,2) detour | LEARNED | A meta-lesson: don't change rules based on frequency; confirm with the dev team first |
| Term/ExamTerm distinction, SL_ tables, RBAC screen-level | DB_DEEP_DIVE_FINDINGS.md | RECORDED, NOT ACTED ON | Waiting on dev-team confirmations — consistent with "record now, act later" |

### Action items from this correction

1. **Refine FEE-005:** split into two rules:
   - FEE-005a: "Total outstanding" queries (user says "outstanding", "pending", "due", "defaulter" without specifying a fee type) → do NOT require Structure_Type (v27 intentionally removed it; the total should include all fee types).
   - FEE-005b: "Academic fee outstanding" queries (user says "academic fee", "tuition fee outstanding") → DO require Structure_Type IN ('Academic','Optional').

2. **Re-run the semantic validator on v27 (not v25)** to get the real v27 flag rate. The v25 flag rate was 548 (14%); v27 should be lower because 631 examples were improved.

3. **Update the estimated semantic-mismatch rate** from 29% (v25) to ~15-20% (v27, estimated). The real number will come from running the 50 questions through the v27 model.

4. **Record the meta-lesson:** "frequency in real code ≠ confirmed correctness" — don't change semantic rules based on what the SPs do most often; confirm with the dev team first. This is a governance principle for the v1.1 rule engine.

5. **The production traces are still valuable** — they reveal v25's behavior, which is close to v27's (3,236 examples unchanged). The 12 new rules + the training gaps are still valid for v28.

---

## Batch 3 — 50 questions run through the v25 model (2026-08-28)

**Source:** the 50-question script (`run_50_questions.py`), run through the Streamlit app (v25 model, api_wrapper mode, user 116, branch 1). First 10 results received.

### Tally (first 10)

| Outcome | Count |
|---|---|
| ANSWER | 8 |
| REFUSED (guardrail) | 1 (Q7: IsHostelFee hallucinated on FeesCollection) |
| Semantic mismatches among ANSWERs | 4 of 8 (50%) |

### New bugs found (not seen in batches 1 or 2)

#### Bug 1 — Structure_Type IN ('Reg', 'Optional') — hallucinated enum value (Q2)

The model wrote `Structure_Type IN ('Reg', 'Optional')` for the "top 10 defaulters" query. **'Reg' is NOT a valid Structure_Type value.** The real values are: Academic, Optional, Hostel, Bus, Misc, Others. The model invented 'Reg' (probably a abbreviation of "Regular" that it learned from training, not from the real schema).

**Impact:** the query returned 2 rows (sanjay, 220; balaji, 30) — but these may be the wrong rows if 'Reg' doesn't match the real data, or if it matches a non-standard value. The answer is potentially wrong.

**New rule needed: FEE-028** — validate that Structure_Type literals in the SQL are from the known enum (Academic, Optional, Hostel, Bus, Misc, Others). If the model writes 'Reg' or any other non-enum value, flag it.

#### Bug 2 — Contradictory filters: Structure_Type IN ('Academic','Optional') AND IsBusFee = 1 (Q6)

The model wrote `Structure_Type IN ('Academic', 'Optional') AND ... AND f.IsBusFee = 1` for the "bus fee outstanding" query. **These filters are contradictory** — bus fees have `Structure_Type = 'Bus'`, not 'Academic' or 'Optional'. The intersection is empty → the query returned NULL.

**This is EXACTLY the bug v27 fixed** by removing the Structure_Type filter from 524 outstanding examples. v25 still has it, so the model applies both the academic-fee filter AND the bus-fee filter, which cancel each other out.

**New rule needed: FEE-029** — when `IsBusFee = 1` is present, `Structure_Type` must NOT be `IN ('Academic', 'Optional')` (or vice versa). When `IsHostelFee = 1` is present, same rule. The IsBusFee/IsHostelFee flags and the Structure_Type filter are redundant + contradictory when combined.

### Confirmed semantic mismatches (from earlier batches, seen again)

| # | Question | What it returned | What was wanted | The gap |
|---|---|---|---|---|
| Q3 | Class 10 and 12 outstanding | 0 rows | Should have outstanding (Q1 returned 17M) | `ClassName IN ('Class 10', 'Class 12')` — may not match if the branch stores 'X'/'XII'. Missing the Roman-numeral hedge (`IN ('Class 10', 'X')`). |
| Q5 | Term-wise collection | Term_IDs: 1, 29, 30, 31 | Term NAMES ("Term 1", "Term 2") | Numeric IDs without JOIN to TermMaster for the name (FEE-025 rule from batch 1). |
| Q8 | Fee head wise concession | Fees_Head_IDs: 181, 182, 183... | Fee head NAMES ("Admission Fee", "Tuition Fee") | Same FEE-025 pattern — numeric ID without JOIN to Fees_Master for the name. |
| Q6 | Bus fee outstanding | NULL (contradictory filters) | The actual bus fee outstanding | Structure_Type IN ('Academic','Optional') + IsBusFee=1 = empty intersection. |

### Confirmed correct (the bright spots)

| # | Question | Why it's good |
|---|---|---|
| Q1 | Fee outstanding current term | The full outstanding pattern: Lien + Structure_Type + IsDonation + LumpSum + TC + IsActive + AcademicYearID. Returned 17,217,268. (Note: v27 would NOT have Structure_Type here — but for this specific "academic fee outstanding" question, having it is correct.) |
| Q4 | Section-wise collection Class 9 | Correct SQL (Receipt_Amt + ChequeStatus + cm.Name IN ('Class 9','IX') hedge). 0 rows is a data issue, not a SQL issue. |
| Q9 | Fees collected today | Perfect: Receipt_Amt + ChequeStatus + CAST(Bill_Date AS DATE) = CAST(GETDATE() AS DATE) + branch scoping. Returned 0.0 (no collection today). |
| Q10 | Total demand vs collected | Correct: SUM(Amount) as demand, SUM(Paid_Amt) as collected. Returned 18M demand, 749K collected. (Note: v27 would remove Structure_Type from this "total" query — debatable but acceptable.) |

### The Q1 observation — important for the FEE-005 refinement

Q1 ("fee outstanding for the current term") uses `Structure_Type IN ('Academic', 'Optional')` — and this is the v25 model. The question says "fee outstanding" (not "academic fee outstanding"), so per my refined FEE-005, this is a "total outstanding" query where Structure_Type should NOT be required. But the model included it anyway (v25 behavior).

**The question is: is Q1's answer correct or wrong?** It returned 17,217,268 — the outstanding for Academic + Optional fees only. If the user meant "ALL fee types including hostel/bus/misc", then 17M is an undercount (v27's fix would include all types). If the user meant "academic fee outstanding", 17M is correct.

**This is the ambiguity v27 resolved by removing the filter.** The semantic engine's refined FEE-005 now aligns with v27: "total outstanding" → no filter; "academic fee outstanding" → filter. The v25 model's behavior (always including the filter) is the old behavior that v27 corrected.

### New rules suggested by this batch

| Rule ID | What it catches | From |
|---|---|---|
| FEE-028 | Structure_Type literal not in the known enum (Academic/Optional/Hostel/Bus/Misc/Others) — catches 'Reg' and other hallucinated values | Q2 |
| FEE-029 | Contradictory filters: IsBusFee=1 AND Structure_Type IN ('Academic','Optional') — mutually exclusive | Q6 |
| FEE-030 | (Refinement of FEE-025) Term_ID/Fees_Head_ID in SELECT without JOIN to the master table for the name — returns numeric IDs instead of human-readable names | Q5, Q8 |
| CLASS-002 | ClassName filter without the Roman-numeral hedge (e.g. 'Class 10' without 'X') — may miss rows at branches that store Roman numerals | Q3 |

4 new rules — would bring the engine from 32 to 36.

### Updated v1.1 work (from all 3 batches combined)

| Item | Count |
|---|---|
| Semantic rules (current) | 32 |
| New rules from batch 1 | 12 |
| New rules from batch 2 | 8 |
| New rules from batch 3 (first 10 Qs) | 4 |
| **Total for v1.1** | **56 rules** |
| New training examples needed (batch 1 + 2 + 3) | ~110-175 |

### The recommendation (repeated)

**Train v27 now (6 hours).** While it trains:
1. We analyze the remaining 40 question results (send them when you have them).
2. I draft the 24 new rules (12 + 8 + 4) + the 4 from this batch.
3. I draft the ~110-175 new training examples.
4. When v27 is done, you run the 50 questions again to get the v27 baseline.
5. Then we build v28 (new rules + new examples + improved instruction) and you train v28.
6. You compare v25 (these traces) vs v27 (the new traces) vs v28 (the final) — three data points on the accuracy curve.

---

## Batch 4 — v27 model, 50 questions (first 20 received, 2026-08-30)

**Source:** the 50-question script, run locally on the user's laptop with the v27-trained model, api_wrapper mode, user 116, branch 1.

### v25 vs v27 comparison (first 10 questions, same questions both models)

| # | Question | v25 outcome | v27 outcome | v27 change | Assessment |
|---|---|---|---|---|---|
| Q1 | Fee outstanding current term | ANSWER (17,217,268) | ANSWER (NULL) | Structure_Type REMOVED (v27 fix ✓). BUT added `Term_Name IN ('Term 1','Term 2')` — hardcoded term names instead of TermMaster date window. Returns NULL. | **REGRESSION** — v25 returned data (wrong filter but data); v27 returns nothing (wrong filter) |
| Q2 | Top 10 defaulters | ANSWER (2 rows) | ANSWER (349 rows, 50 shown) | Structure_Type REMOVED. No 'Reg' hallucination. TOP 10 stripped by API (known bug). | **IMPROVEMENT** — more data, no hallucinated enum |
| Q3 | Class 10 + 12 outstanding | ANSWER (0 rows) | ANSWER (0 rows) | Structure_Type REMOVED. Still no Roman hedge. | **SAME** — 0 rows (data issue: branch may not have 'Class 10'/'Class 12' — it has 'X'/'XII') |
| Q4 | Section-wise collection Class 9 | ANSWER (0 rows) | ANSWER (0 rows) | No change. | **SAME** |
| Q5 | Term-wise collection | ANSWER (4 rows, numeric IDs) | ANSWER (4 rows, numeric IDs + Remaining_Amt) | Added SUM(Remaining_Amt). Still numeric IDs. | **IMPROVEMENT** — more info; FEE-025 still applies |
| Q6 | Bus fee outstanding this term | ANSWER (NULL) | **ANSWER (117,800)** | Structure_Type REMOVED. No contradictory filters. | **MAJOR IMPROVEMENT** — the headline v27 fix works |
| Q7 | Hostel fee collection | REFUSED (IsHostelFee) | REFUSED (FeesType_Name) | Different hallucination, same outcome. | **SAME** — still hallucinating on FeesCollection |
| Q8 | Fee head wise concession | ANSWER (24 rows, numeric IDs) | REFUSED (Fees_Head_Name) | v27 tried to JOIN for the name but hallucinated the column. | **REGRESSION** — v25 returned data; v27 refuses |
| Q9 | Fees collected today | ANSWER (0.0) | ANSWER (0.0) | No change. | **SAME** — perfect both versions |
| Q10 | Total demand vs collected | ANSWER (18,018,031 / 748,797) | ANSWER (18,181,531 / 761,097) | Structure_Type REMOVED → more rows included → higher totals. | **IMPROVEMENT** — v27 numbers are more accurate (include all fee types) |

### v27 results Q11–Q20 (no v25 comparison — different questions)

| # | Question | v27 outcome | Notes |
|---|---|---|---|
| Q11 | Class 10 Section A count | REFUSED (validate: 'A' not recognized) | Correct — branch uses ability-stream sections. Validate works. |
| Q12 | Class-wise student count | ANSWER (18 classes) | Correct. Shows messy data: "KG", "PREKG", "ClassX", "GRADE V" — data quality issue. |
| Q13 | Section-wise strength Class 8 | ANSWER (Section B: 35, A: 17) | Works — no section literal to validate; just groups by whatever exists. |
| Q14 | New admissions this year | ANSWER (22) | Correct. |
| Q15 | Students with TC this AY | ANSWER (6 rows) | Used TCRequest table (not StudentAcademicDetail.IsTCIssued). Both valid. |
| Q16 | Classes with seats available | ANSWER (50 of 113 rows) | Used ClassSectionMaster.AvailableSeats. Correct. |
| Q17 | Attendance below 75% | ANSWER (10 rows) | Correct HAVING pattern. |
| Q18 | Class 10 Section B list | REFUSED (validate: 'B' not recognized) | Same as Q11 — branch doesn't use lettered sections. |
| Q19 | Passed maths in Term 1 | REFUSED (smd.SubjectID doesn't exist) | Model learned to use eced.MinMark (improvement!) but hallucinated smd.SubjectID (regression). |
| Q20 | Topper list Term II | REFUSED (smm.Term_Name doesn't exist) | Model tried to filter by term name on the marks table — wrong; term link is via ExamTypeMaster → ExamTermMaster. |

### Summary: v25 vs v27 (first 10, head-to-head)

| Metric | v25 | v27 | Change |
|---|---|---|---|
| Answered | 8/10 | 8/10 | SAME |
| Refused | 1/10 | 2/10 | +1 (Q8 regressed) |
| Semantic mismatches among ANSWERs | 4/8 (50%) | 1/8 (12.5%) | **-37.5pp (major improvement)** |
| Correct answers | 3/10 | 5/10 | **+2** |
| Partially correct | 1/10 | 2/10 | +1 |
| Wrong but returned data | 4/10 | 1/10 | -3 |
| Refused/errored | 2/10 | 2/10 | SAME |

### The headline result: v27 is better

The semantic-mismatch rate dropped from **50% (v25) to 12.5% (v27)** among the first 10 questions. That's a 37.5 percentage-point improvement — directly attributable to the Structure_Type removal (Q6: NULL→117,800; Q10: more accurate totals).

But v27 introduced 2 regressions:
- **Q1: hardcoded term names** — the model learned to remove Structure_Type but OVERCORRECTED by adding `Term_Name IN ('Term 1', 'Term 2')` which is wrong. "Current term" should be resolved via `TermMaster.StartingDate/EndingDate`, not by hardcoding names.
- **Q8: hallucinated Fees_Head_Name** — the model tried to be more helpful (get the fee head name instead of the numeric ID) but invented a column that doesn't exist.

### New bugs in v27 (not in v25)

| Bug | From | What happened | New rule needed |
|---|---|---|---|
| Hardcoded term names for "current term" | Q1 | Model wrote `f.Term_Name IN ('Term 1', 'Term 2')` instead of joining TermMaster with date window | FEE-030: "current term" must use TermMaster date window, not hardcoded Term_Name |
| Hallucinated Fees_Head_Name | Q8 | Model wrote `fcd.Fees_Head_Name` (doesn't exist; the column is `Fees_Head_ID`) | HINT_MAP: Fees_Head_Name → JOIN Fees_Master for the name |
| Hallucinated smd.SubjectID | Q19 | StudentMarkDetails has no SubjectID; the subject link is via ExamConfigurationEvaluationDetails | HINT_MAP: smd.SubjectID → join via eced.SubjectEvaluationID |
| Hallucinated smm.Term_Name | Q20 | StudentMarkMaster has no Term_Name; the term link is via ExamTypeMaster → ExamTermMaster | HINT_MAP: smm.Term_Name → JOIN ExamTypeMaster etm ON etm.ID = smm.ExamTypeID, then ExamTermMaster |

### The v27 → v28 work (from this comparison)

The v28 retrain needs to fix these 4 new bugs + the existing gaps:
1. **"Current term" resolution:** 10-15 training examples with `JOIN TermMaster tm ON tm.ID = f.Term_ID AND GETDATE() BETWEEN tm.StartingDate AND tm.EndingDate` (the date-window pattern, not hardcoded names).
2. **Fee head name JOIN:** 5-10 examples that `JOIN Fees_Master fm ON fcd.Fees_Head_ID = fm.ID` and `SELECT fm.Name AS FeeHead` (the correct way to get the name).
3. **Subject link in marks:** 5-10 examples showing the correct join path: `StudentMarkDetails → ExamConfigurationEvaluationDetails → Subject_Master` (via EvalHierID, not SubjectID).
4. **Exam term link in marks:** 5-10 examples showing `StudentMarkMaster → ExamTypeMaster → ExamTermMaster` (via ExamTypeID → TermID, not Term_Name).
5. Plus the existing ~110-175 examples from batches 1-3.

Total for v28: ~130-195 new training examples + the improved instruction + the §F parameter changes + the 56 semantic rules.

---

## Batch 4 (complete) — v27 model, all 50 questions (2026-08-30)

**Source:** 50-question script, v27-trained model, api_wrapper mode, user 116, branch 1, local laptop.

### Final v27 tally (all 50 questions)

| Outcome | Count | % |
|---|---|---|
| ANSWER | 28 | 56% |
| REFUSED (guardrail) | 12 | 24% |
| REFUSED (validate — section 'A'/'B') | 3 | 6% |
| REFUSED (branch_scoping) | 1 | 2% |
| ERROR (execute: api FAILED) | 6 | 12% |

### Semantic correctness among the 28 ANSWERs

| Assessment | Count | Questions |
|---|---|---|
| **Correct** | 18 | Q2, Q5(partial), Q6, Q9, Q10, Q12, Q13, Q14, Q15, Q16, Q17, Q29, Q34, Q35, Q37, Q38, Q40, Q41, Q46, Q50 |
| **Wrong (semantic mismatch)** | 5 | Q1 (hardcoded Term_Name → NULL), Q22 (cartesian subject join → all 46.11), Q24 (counts marks not "report cards"), Q25 (cartesian subject join → 1039 rows), Q48 (counts students not notifications) |
| **Partially correct** | 5 | Q3 (0 rows, missing Roman hedge), Q4 (0 rows, data issue), Q5 (numeric IDs no name), Q38 (missing boarding point names), Q42 (0 rows, correct SQL) |

**Semantic mismatch rate: 5/28 = 18%** (down from v25's estimated ~50% on the first 10).

### v25 vs v27 head-to-head (first 10 questions, same questions both models)

| Metric | v25 | v27 | Change |
|---|---|---|---|
| Answered | 8/10 | 8/10 | Same |
| Refused | 1/10 | 2/10 | +1 (Q8 regressed) |
| Semantic mismatches | 4/8 (50%) | 1/8 (12.5%) | **-37.5pp** |
| Bus fee outstanding (Q6) | NULL | 117,800 | **FIXED** |
| Structure_Type removal | Not done | Done | **v27 fix works** |
| 'Reg' enum hallucination (Q2) | Present | Gone | **FIXED** |

### The 5 semantic mismatches (the v28 targets)

| # | Question | What it returned | What was wanted | Root cause | v28 fix |
|---|---|---|---|---|---|
| Q1 | Fee outstanding current term | NULL | A number | Model wrote `f.Term_Name IN ('Term 1', 'Term 2')` instead of `JOIN TermMaster tm ON tm.ID = f.Term_ID AND GETDATE() BETWEEN tm.StartingDate AND tm.EndingDate` | 10-15 training examples with the TermMaster date-window pattern |
| Q22 | Subject-wise average marks | All subjects = 46.11 | Per-subject averages | `JOIN Subject_Master s ON s.BranchID = smd.BranchID` — cartesian join (every subject matches every mark). No subject link between StudentMarkDetails and Subject_Master (the link is via ExamConfigurationEvaluationDetails) | 10-15 training examples with the correct subject join path via EvalHierID |
| Q24 | Report card published count | 580 rows of marks counts | Count of published report cards | Model queried StudentMarkDetails (marks exist) instead of a report-card-status table | 5-10 training examples with the correct report-card-status table (dev team ask 3.5) |
| Q25 | Top 5 in Physics | 1039 rows (all subjects) | 5 students | Same cartesian join as Q22 + no subject filter link | Same as Q22 + 5-10 examples with the correct subject→marks path |
| Q48 | Total notifications this AY | 923 (student count) | Notification count | Model queried StudentAcademicDetail instead of SMSAuditTrail/NotificationOptIn | 5-10 training examples with the correct notification/SMS table |

### The 6 execute: api FAILED cases

| # | Question | SQL shape | Likely cause |
|---|---|---|---|
| Q21 | Failed any subject | Multi-join with eced.MinMark | DB error (possibly the inline-params + multiple @UserId placeholders in nested subqueries) |
| Q23 | Mark entry pending | ProgressCardDataRetrieval | DB error (the table may be a view or function, not a direct table) |
| Q30 | Staff type wise count | EmployeeMaster | Schema drift — EmployeeMaster may not exist in the live DB |
| Q32 | Enquiries received | CTE (WITH AllowedBranches) | **Confirmed CTE + ExecuteQuery API bug** (repeated placeholders) |
| Q36 | Class-wise enquiry this week | CTE (WITH AllowedBranches) | Same CTE + API bug |

### The 12 guardrail failures (hallucinated tables/columns)

| # | Question | Hallucinated | Correct path (needs dev team or training) |
|---|---|---|---|
| Q7 | Hostel fee collection | `FeesCollection.FeesType_Name` | No such column. Hostel fees are identified via FeesInformationStudentDetail.IsHostelFee or Structure_Type = 'Hostel' |
| Q8 | Fee head concession | `FeesCollection_Details.Fees_Head_Name` | Column is `Fees_Head_ID` (numeric). JOIN Fees_Master for the name. |
| Q19 | Passed maths Term 1 | `StudentMarkDetails.SubjectID` | No such column. Subject link is via ExamConfigurationEvaluationDetails (EvalHierID) |
| Q20 | Topper list Term II | `StudentMarkMaster.Term_Name` | No such column. Term link is via ExamTypeMaster → ExamTermMaster |
| Q26 | Who is the principal | `StaffDesignationMaster.StaffID`, `StaffDesignationMaster.DesignationName` | Neither column exists. Use `BranchMaster.Principal` (denormalized). |
| Q31 | Staff turnover | `EmployeeMaster.IsTCIssued`, `EmployeeMaster.IsNewJoiner` | Use Staff_Master + StaffResignationRequest (IsTCIssued is on StudentAcademicDetail, not staff) |
| Q39 | Bus fee by route | `Route_MasterStudentMapping` | Table doesn't exist. Route-student link may be via BusFeeStrucure.Student_ID → Student_Master + Route_Master |
| Q43 | Credit notes this year | `FeesCollection.IsCreditNote` | No such column. Credit notes likely in CreditNoteMaster (a separate table) |
| Q44 | Inventory low stock | `InventoryItem_Master.MinStockLevel` | No such column. Low-stock indicator TBC (dev team ask 3.5) |
| Q45 | List all suppliers | `SupplierMaster` (table doesn't exist) | The real table name is TBC (dev team ask 3.5) |
| Q47 | SMS sent today | `SMSLog` (table doesn't exist) | Use `SMSAuditTrail` (confirmed in schema) |
| Q49 | Unresolved complaints | `FeedbackParentStudent` (table doesn't exist) | Use `FeedbackTicket` (confirmed in schema) |

### The 3 section-validate refusals (the ability-stream section issue)

Q11, Q18, Q27 — all refused because 'A'/'B' is not in the branch's section vocab (the branch uses BRAINY/EXPERT/FOUNDATION/INTELLIGENT/TALENTED). BUT Q13 ("section-wise strength for Class 8") returned A:17, B:35 — meaning Class 8 at this branch DOES have A/B sections. **The branch has mixed sections across classes.** The Context JSON's flat Sections list doesn't capture this per-class distinction. This is the Option A retrain target.

### The 1 branch-scoping failure (new failure mode)

Q33 — the model emitted a `DECLARE @StatusConverted bigint = (...)` statement (procedural SQL), not a single SELECT. The branch-scoping gate correctly rejected it (no `UserAccountRoleDetails WHERE UserID = @UserId` linkage in a DECLARE). **The model tried to use procedural SQL for a complex query** — this needs a training example showing how to do the conversion rate in a single SELECT (using a CTE or subquery, not DECLARE).

### New patterns confirmed in v27

1. **The CTE-form scoping is being used** (Q32, Q36) — the model learned the CTE pattern. But it FAILS the ExecuteQuery API (confirmed bug). **The CTE recommendation for v28 training data is correct — but the API bug must be fixed first** (ask 2.1).

2. **The Structure_Type removal works** (Q2: 349 rows vs v25's 2; Q6: 117,800 vs v25's NULL; Q10: more accurate totals). **This is the headline v27 improvement.**

3. **The 'Reg' hallucination is gone** (Q2) — v25 wrote `Structure_Type IN ('Reg', 'Optional')`; v27 removed Structure_Type entirely. **Fixed.**

4. **The Subject cartesian join persists** (Q22, Q25) — v27 still uses `s.BranchID = smd.BranchID` instead of the correct EvalHierID path. **This is the STUD-006 rule's target — confirmed in v27.**

5. **The "who is the principal" question still fails** (Q26) — v27 tried StaffDesignationMaster (different from v25's Branch_Academic_Details.Principal_ID, but still hallucinated columns). **Both versions fail; the answer is `BranchMaster.Principal` (denormalized). Training coverage needed.**

6. **The EmployeeMaster schema drift persists** (Q30, Q31) — EmployeeMaster passes the guardrail (it's in the catalog) but fails at execute. **The catalog needs re-syncing** (ask 3.4).

### v27 full-run module summary

| Module | Total | Answered | Refused | Error | Answer rate |
|---|---|---|---|---|---|
| Fees | 10 | 8 | 2 | 0 | 80% |
| Students | 8 | 6 | 2 | 0 | 75% |
| Exams | 7 | 3 | 4 | 0 | 43% |
| Staff | 6 | 1 | 5 | 0 | 17% |
| Admissions | 5 | 2 | 3 | 0 | 40% |
| Transport | 4 | 3 | 1 | 0 | 75% |
| Payroll | 3 | 2 | 1 | 0 | 67% |
| Inventory | 3 | 1 | 2 | 0 | 33% |
| Communication | 2 | 1 | 1 | 0 | 50% |
| Parent Feedback | 2 | 1 | 1 | 0 | 50% |

**Weakest modules:** Staff (17% answer rate — principal, class teacher, turnover all fail), Exams (43% — marks queries fail on the SubjectID/Term_Name hallucinations), Inventory (33% — thin training data + hallucinated tables).

**Strongest modules:** Fees (80% — the v27 Structure_Type fix + the outstanding formula work well), Students (75% — class/section/attendance queries work), Transport (75% — route/vehicle queries work).

### The v28 training data needs (consolidated from all 4 batches)

| Category | Examples needed | From |
|---|---|---|
| "Current term" via TermMaster date window (not hardcoded names) | 10-15 | Batch 4 Q1 |
| Subject join via EvalHierID (not BranchID cartesian) | 10-15 | Batch 4 Q22, Q25 + Batch 1 STUD-006 |
| Fee head name JOIN (Fees_Head_ID → Fees_Master.Name) | 5-10 | Batch 4 Q8 + Batch 1 FEE-025 |
| "Who is the principal" → BranchMaster.Principal | 5-10 | Batch 4 Q26 + Batch 1 §27 |
| Report card status (correct table) | 5-10 | Batch 4 Q24 (dev team ask 3.5) |
| Notifications/SMS → SMSAuditTrail | 5-10 | Batch 4 Q47, Q48 + Batch 1 COMM-001 |
| Feedback → FeedbackTicket (not FeedbackParentStudent/GeneralFeedback) | 5-10 | Batch 4 Q49 + Batch 1 FEEDBACK-001 |
| EmployeeMaster → Staff_Master | 5-10 | Batch 4 Q30, Q31 + Batch 1 STAFF-004 |
| SupplierMaster → correct table name | 3-5 | Batch 4 Q45 (dev team ask 3.5) |
| Inventory MinStockLevel → correct column | 3-5 | Batch 4 Q44 (dev team ask 3.5) |
| CreditNoteMaster (correct table/columns) | 3-5 | Batch 4 Q43 |
| CTE-form scoping (all queries) | 50-100 (rewrite existing) | §22 recommendation |
| Compare X vs Y (CASE pivot or UNION+label) | 10-15 | Batch 1 Q23 + Batch 2 Q4, Q9 |
| "Not entered"/"not marked" (NOT EXISTS) | 10-15 | Batch 1 Q20 + Batch 2 Q19 |
| Bus fee by route (correct student-route link) | 3-5 | Batch 4 Q39 |
| DECLARE → single SELECT (conversion rate) | 3-5 | Batch 4 Q33 |
| **Total new examples** | **~130-220** | |

### The bottom line for v27

**v27 is a real improvement over v25.** The semantic-mismatch rate dropped from ~50% (v25 first 10) to ~18% (v27 all 50). The Structure_Type removal fix works (Q6: NULL→117,800; Q2: 2→349 rows; Q10: more accurate). The 'Reg' hallucination is gone.

**But v27 still has 5 semantic mismatches, 12 guardrail failures, and 6 execute failures per 50 questions.** The v28 retrain needs ~130-220 new training examples to close these gaps, plus the improved instruction, the §F parameters, and the CTE-form scoping (once the API bug is fixed).

The weakest modules (Staff 17%, Exams 43%, Inventory 33%) are where the most training examples are needed. The strongest modules (Fees 80%, Students 75%) confirm the v27 fixes work.

**v27 is the new baseline. v28 is the target. The 50 questions are the benchmark.**

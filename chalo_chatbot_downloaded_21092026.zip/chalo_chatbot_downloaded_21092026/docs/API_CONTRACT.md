# API Contract — ChaloSchools AI Secretary Mobile App Integration

**For:** the mobile-app team integrating the chatbot as a menu item.
**Service:** the ChaloSchools AI Secretary API (FastAPI backend).
**Base URL (production):** `https://<your-domain>/api`
**Base URL (staging):** `https://<staging-domain>/api`
**Base URL (local dev):** `http://10.0.2.2:8000/api` (Android emulator) or `http://localhost:8000/api` (iOS simulator / physical device on same network)

This document is the single source of truth for the mobile-app integration. It defines every endpoint, the auth model, the request/response shapes, the error model, and the recommended mobile UX flow. The local-test Next.js web UI is separate and NOT part of the production deployment.

---

## 1. Auth model

All endpoints except `/api/health` require a Bearer token in the `Authorization` header:

```
Authorization: Bearer <token>
```

The token is issued by the school's auth system (the same system that issues the Context JSON). The mobile app obtains it at login and includes it on every chatbot request. The backend validates it against a configured allowlist (`AI_SECRETARY_AUTH_TOKENS` env var on the server).

**Token lifetime:** tied to the user's session. Refresh it the same way you refresh the school's main auth token.
**Token scope:** per-school (the same token works for all branches the user can access). The token itself doesn't carry the user's branch permissions — those come from the Context JSON the mobile app sends in the request body.

**401 response shape:**
```json
{"detail": "Missing Authorization header. Expected: Bearer <token>"}
// or
{"detail": "Invalid auth token"}
```

The mobile app should treat a 401 as a session-expired signal and re-authenticate.

---

## 2. Endpoints

### 2.1 `GET /api/health` — health check (no auth)

Used by the mobile app on startup to confirm the chatbot service is reachable. Also used by load balancers / monitoring.

**Request:** no body, no auth.

**Response (200):**
```json
{
  "status": "ok",
  "pipeline_loaded": true,
  "rules_count": 32,
  "version": "1.0.0"
}
```

**If `status: "degraded"`:** the pipeline failed to load (a Python import error on the server). The mobile app should show a "chatbot temporarily unavailable" message.

---

### 2.2 `POST /api/chat` — the main endpoint

The mobile app calls this when the user sends a question. Returns the full pipeline result.

**Headers:**
```
Authorization: Bearer <token>
Content-Type: application/json
```

**Request body:**
```json
{
  "question": "What is the fee outstanding for the current term?",
  "context_json": { ... the user's Context JSON from GetUserContext ... },
  "branch_id": 1,
  "mode": "api_wrapper",
  "api_wrapper_url": "https://chaloschools.in/testv4service/DigitalSecretary/AISecretary.asmx/ExecuteQuery",
  "target_database": "V3_TestDatabase",
  "page_number": 1,
  "page_size": 10
}
```

> **Note on `api_key`:** the mobile app does NOT send `api_key` in the request body.
> The backend looks up the tenant ExecuteQuery API key server-side from the user's
> `target_database` (DBPrefix) via the `AI_SECRETARY_TENANT_KEYS` env var. This is
> the V4 security fix — the mobile app never sees the ExecuteQuery key.

**Required fields:**
| Field | Type | Description |
|---|---|---|
| `question` | string (1-1000 chars) | The user's natural-language question. |
| `context_json` | object | The user's Context JSON from the school's `GetUserContext` API. Contains `UserMasterDetails` + `UserBranchDetails` (branches, academic years, Classes/Sections/Subjects/FeeHeads/ExamTerms vocab per branch). |
| `mode` | string | `dry_run` (preview SQL, no execution) / `local_db` (direct MS SQL) / `api_wrapper` (via ExecuteQuery ASMX). **Production = `api_wrapper`.** |
| `api_wrapper_url` | string | The ExecuteQuery endpoint (api_wrapper mode only). |
| `target_database` | string | The user's DBPrefix, e.g. `V3_TestDatabase` (api_wrapper mode only). The backend uses this to look up the tenant API key server-side (V4 fix). |

**Optional fields (with sensible defaults):**
| Field | Default | Description |
|---|---|---|
| `branch_id` | null | Selected branch. Null = all authorized branches (super-user only). Single-branch users: set to their primary branch. |
| `inject_vocab` | false | Inject branch vocab into the prompt. **Leave false** (STOPGAP mode works with the current v27 model; full mode needs the v28 retrain). |
| `fast_paths` | false | Enable cached fast-paths. **Leave false** (off until training labels are cleaned). |
| `temperature` | 0.0 | LLM temperature. 0 = deterministic. Keep 0. |
| `max_tokens` | 512 | LLM max output tokens. Keep 512 (raising it increases CPU latency). |
| `page_number` | 1 | Result page (1-indexed). |
| `page_size` | 10 | Rows per page. Max 100. |
| `model_url` | `http://localhost:8080/v1/chat/completions` | llama.cpp endpoint. The mobile app usually doesn't set this — the server default is correct. |

**Response (200) — `outcome: "ANSWER"`:**
```json
{
  "outcome": "ANSWER",
  "stage": "execute",
  "sql": "SELECT SUM(...) AS Outstanding FROM FeesInformationStudentDetail ...",
  "sql_source": "llm",
  "bound_request": { ... the actual request sent to ExecuteQuery ... },
  "columns": ["Outstanding"],
  "rows": [[125000.00]],
  "total_row_count": 1,
  "total_pages": 1,
  "disambiguation": null,
  "message": null,
  "detail": null,
  "trace": [
    "context: user=116 branch=1",
    "inject: vocab_block=no (off — model trained without it; VALIDATE stage enforces values)",
    "generate: sql produced",
    "guardrail: passed",
    "alias_scope: passed",
    "branch_scoping: passed (direct-or-indirect)",
    "validate: all values ok",
    "semantic: passed (32 rules)",
    "bind: ok",
    "execute: api ok (1 row(s) across 1 page(s))"
  ],
  "semantic_violations": [],
  "latency_ms": 8450.2
}
```

**Response (200) — `outcome: "REFUSED"`:**
```json
{
  "outcome": "REFUSED",
  "stage": "semantic",
  "sql": "SELECT SUM(Amount-Paid_Amt) FROM FeesInformationStudentDetail f JOIN ExamTermMaster e ...",
  "sql_source": "llm",
  "bound_request": null,
  "columns": [],
  "rows": [],
  "total_row_count": null,
  "total_pages": null,
  "disambiguation": null,
  "message": "Fee query joins ExamTermMaster — fee Term_ID must join TermMaster.",
  "detail": "[HIGH] FEE-006: Fee query joins ExamTermMaster — fee Term_ID must join TermMaster. ...",
  "trace": [...],
  "semantic_violations": [
    {
      "rule_id": "FEE-006",
      "severity": "HIGH",
      "message": "Fee query joins ExamTermMaster — fee Term_ID must join TermMaster.",
      "suggested_fix": "Change JOIN ExamTermMaster to JOIN TermMaster tm ON tm.ID = <fee>.Term_ID.",
      "module": "Fees"
    }
  ],
  "latency_ms": 8450.2
}
```

**Response (200) — `outcome: "NEEDS_DISAMBIGUATION"`:**
```json
{
  "outcome": "NEEDS_DISAMBIGUATION",
  "stage": "validate",
  "sql": "... WHERE secm.Name = 'A' ...",
  "sql_source": "llm",
  "disambiguation": {
    "concept_type": "SECTION",
    "user_value": "A",
    "candidates": ["All", "BRAINY", "EXPERT", "FOUNDATION", "INTELLIGENT", "TALENTED"],
    "reason": "not_recognized"
  },
  "message": "Which section did you mean?",
  ...
}
```

**Response (200) — `outcome: "ERROR"`:**
```json
{
  "outcome": "ERROR",
  "stage": "generate",
  "sql": null,
  "message": null,
  "detail": "LLM generation failed: <urlopen error [Errno 111] Connection refused>",
  "trace": [
    "context: user=116 branch=1",
    "inject: vocab_block=no",
    "generate: fast-paths disabled (D1.9), calling LLM directly"
  ],
  "semantic_violations": [],
  "latency_ms": 6.7
}
```

---

### 2.3 `POST /api/branches` — list the user's branches

Used by the mobile app to populate the branch picker (when the user has 2+ branches).

**Request body:** the user's Context JSON (same shape as `/api/chat`).

**Response (200):**
```json
{
  "branches": [
    {"id": 1, "name": "CHALO INTERNATIONAL SCHOOL", "is_primary": true},
    {"id": 2, "name": "CHALO BESANT NAGAR", "is_primary": false}
  ],
  "user_id": 116,
  "username": "abav",
  "is_super_user": false
}
```

---

### 2.4 `POST /api/validate` — debug a SQL query

For the mobile-app team to test what the semantic engine catches on a given SQL. Not used in the normal chat flow.

**Request body:**
```json
{"sql": "SELECT Password FROM UserAccountMaster", "question": "show passwords"}
```

**Response (200):**
```json
{
  "violations": [
    {
      "rule_id": "SENSITIVE-COL",
      "severity": "HIGH",
      "message": "Sensitive column Password must never be selected.",
      "suggested_fix": "Remove Password from the SELECT list. Must never be queried.",
      "module": "Security"
    }
  ],
  "violation_count": 1,
  "high_count": 1,
  "medium_count": 0
}
```

---

### 2.5 Admin/audit endpoints (admin token required)

These are NOT called by the mobile app — they're for the admin (the school's project owner) and the audit-trail viewer (`frontend/audit.html`). They use a separate `AI_SECRETARY_ADMIN_TOKENS` env var, not the user token.

| Endpoint | Method | Purpose |
|---|---|---|
| `GET /api/admin/features` | GET | View the 24 feature flags (governance layer for v1.1+ features) |
| `PUT /api/admin/features` | PUT | Update the feature flags (partial update; persists to `feature_overrides.json`) |
| `GET /api/audit` | GET | Fetch audit-trail rows (paginated, optional `outcome` filter). Query params: `limit` (default 100, max 100000), `offset`, `outcome` (`ANSWER`/`REFUSED`/`ERROR`/etc.) |
| `GET /api/audit/stats` | GET | Aggregate audit stats: total, outcome counts, avg latency, last-7-days count, refused-by-stage breakdown |
| `DELETE /api/audit` | DELETE | Clear ALL audit-trail rows. **Cannot be undone.** Returns `{"status":"ok","message":"Audit trail cleared. N row(s) remaining.","remaining":0}` |

**Audit export note:** the `frontend/audit.html` **Export XLSX** button uses the existing `GET /api/audit` endpoint with a large `limit` (100,000) to fetch all rows, then converts them to `.xlsx` client-side via SheetJS (CDN). There is **no dedicated export endpoint** — it reuses `GET /api/audit`. Falls back to CSV if SheetJS isn't loaded (offline).

**Total endpoint count:** 9 (4 user + 5 admin/audit).

---

## 3. The recommended mobile UX flow

1. **User opens the chatbot menu item.** The mobile app:
   - Calls `GET /api/health`. If `status != "ok"`, show "chatbot temporarily unavailable" and stop.
   - If the user has no Context JSON cached, fetch it from the school's `GetUserContext` API (using the school's auth token).
   - Calls `POST /api/branches` with the Context JSON. If the user has 1 branch, set `branch_id` to it. If 2+, show a branch picker.

2. **User types a question and taps Send.** The mobile app:
   - Calls `POST /api/chat` with `{question, context_json, branch_id, mode: "api_wrapper", api_wrapper_url, target_database}`. The backend looks up the tenant `api_key` server-side (V4 fix).
   - Shows a loading indicator (the LLM is on CPU; expect 5-30s latency).

3. **The response arrives.** The mobile app branches on `outcome`:
   - **`ANSWER`:** Show the result. If `rows` is non-empty, render as a table. If empty, show "No data found." Optionally show the SQL (`sql` field) in a collapsible "View query" section for transparency.
   - **`REFUSED`:** Show the `message` in a friendly tone ("I couldn't answer that because..."). If `semantic_violations` is non-empty, show the first violation's `suggested_fix` as a hint ("Try asking...").
   - **`NEEDS_DISAMBIGUATION`:** Show the `disambiguation.candidates` as a selectable list. When the user picks one, re-send the original question with the chosen value substituted into the question text (or as a follow-up).
   - **`NEEDS_BRANCH_SELECTION`:** Show the branch picker (shouldn't happen if step 1 handled it, but defensive).
   - **`ERROR`:** Show "Something went wrong. Please try again." Log the `detail` for debugging (don't show it to the user).

4. **User asks a follow-up.** Same flow — send the new question to `/api/chat`. Conversations are stateless from the backend's perspective; the mobile app maintains the chat history locally.

---

## 4. Error model

The backend returns HTTP 200 for all pipeline outcomes (ANSWER, REFUSED, NEEDS_DISAMBIGUATION, ERROR). The `outcome` field in the response body is the discriminator. The mobile app should branch on `outcome`, not on HTTP status.

HTTP status codes are reserved for transport-level errors:
- **200:** the pipeline ran (check `outcome` for the result).
- **400:** malformed request (missing required field, invalid Context JSON).
- **401:** missing/invalid auth token.
- **422:** Pydantic validation error (e.g. `question` over 1000 chars).
- **500:** unexpected server error (check `detail` in the body).
- **502/503:** the backend is down or the LLM is unreachable (the mobile app should retry with backoff).

---

## 5. Context JSON shape (what the mobile app sends)

The `context_json` field is the output of the school's `GetUserContext` API. The mobile app passes it through unchanged. The shape:

```json
{
  "UserMasterDetails": {
    "Id": 116,
    "UserName": "abav",
    "StaffName": "ABAVITHRA NN",
    "IsSuperUser": false,
    "DBPrefix": "V3_TestDatabase",
    "ShortName": "inspace",
    "UserBranchDetails": [
      {
        "ID": 1,
        "Name": "CHALO INTERNATIONAL SCHOOL",
        "IsPrimary": true,
        "AcademicYears": [
          {"Id": 6, "Name": "2026-2027", "IsCurrentYear": true, "PreviousAcademicYearID": 5}
        ],
        "Classes": [{"Name": "I", "DisplayOrder": 4}, ...],
        "Sections": ["All", "BRAINY", "EXPERT", ...],
        "Subjects": ["MATHS", "ENGLISH", "SCIENCE", ...],
        "EnquiryStatuses": ["Initiated", "Updated", "Completed", "Dropped"],
        "FeeHeads": ["Admission Fee", "Tuition Fees", "Transport Fee"],
        "ExamTerms": ["Term I", "Term II", "EoY"],
        "FeeTerms": ["Term 1", "Term 2", "Term 3"]
      }
    ]
  }
}
```

**The mobile app does NOT need to understand the Context JSON.** It just fetches it from `GetUserContext` and passes it to `/api/chat` as-is. The backend parses it.

**Caching:** the Context JSON is valid for the user's session. The mobile app should cache it (after login) and reuse it for every chatbot request. Refresh it when the school's auth token refreshes.

---

## 6. Latency expectations

The LLM runs on CPU (Qwen 2.5 Coder 7B). Expected latency:
- **Simple query** ("how many students in class 10"): 3-8 seconds
- **Complex query** ("current term fee outstanding with full scoping"): 8-20 seconds
- **Retry after guardrail failure** (adds one more LLM call): 2x the above
- **Pagination** (each page is a sequential HTTP call): +2-5s per page

**Mobile UX recommendation:**
- Show a loading indicator immediately.
- If latency exceeds 15s, show "This is taking longer than usual..." (don't cancel — the query is still running).
- Stream the response if you can (the backend doesn't stream today; a future enhancement).

---

## 7. Pagination

The `rows` field contains one page of results (`page_size` rows, default 10). `total_row_count` is the total. `total_pages` is the page count.

The mobile app should:
- Render the first page.
- If `total_row_count > page_size`, show "Load more" / infinite scroll.
- Each "Load more" calls `/api/chat` again with `page_number` incremented by 1 (same `question`, same `context_json`).

**Note:** the backend auto-fetches up to `max_auto_pages` (default 5) pages per request, so a single `/api/chat` call may return up to 50 rows. For larger result sets, the mobile app should use explicit pagination.

---

## 8. Rate limiting (recommended)

The backend doesn't implement rate limiting today (the FastAPI app is single-worker in dev). For production, put it behind a reverse proxy (nginx/Caddy) with rate limiting:
- Per-user: 20 requests/minute (the LLM is CPU-bound; concurrent requests queue).
- Per-IP: 100 requests/minute (defense against abuse).

The mobile app should also debounce the Send button (disable it while a request is in flight) to prevent accidental spam.

---

## 9. Security notes for the mobile app

- **Never embed the `api_key` in the mobile app binary.** The mobile app sends only the user's auth token (from the school's login). The backend looks up the `api_key` for the user's school from the `AI_SECRETARY_TENANT_KEYS` env var (server-side, V4 fix). The mobile app never sees the ExecuteQuery key.
- **The Context JSON contains the user's branch permissions.** Treat it as sensitive — don't log it, don't cache it to disk unencrypted.
- **The generated SQL is shown in the response.** For transparency, the mobile app may display it. But don't let the user edit and re-send it — that bypasses the pipeline.

---

## 10. OpenAPI / Swagger

The backend auto-generates an OpenAPI spec at `http://<host>:8000/openapi.json` and an interactive docs page at `http://<host>:8000/docs`. The mobile-app team can use these to generate client code (e.g. via `openapi-generator` for Swift/Kotlin).

---

## 11. Recommended next steps (for the backend team)

These are improvements I'd recommend but didn't implement in this delivery:

1. **Move `api_key` server-side (DONE — V4 fix).** The backend now looks up the `api_key` from the user's `DBPrefix` via the `AI_SECRETARY_TENANT_KEYS` env var. The mobile app never sends `api_key` in the request body. The `ChatRequest` Pydantic model in `backend/main.py` does NOT have an `api_key` field (any value sent is silently dropped by Pydantic).
2. **Add rate limiting** at the FastAPI layer (slowapi) or the reverse proxy.
3. **Add request logging** (audit trail) — every chat request + outcome, for the audit_trail.db the original Streamlit app used.
4. **Add streaming** — stream the SQL generation token-by-token so the mobile app can show a typing indicator.
5. **Add a `/api/conversations` endpoint** — server-side conversation persistence (today the mobile app stores conversations locally; a server-side store enables cross-device sync).

---

## 12. Changelog

- **v1.0.0** (initial): 4 endpoints (`/api/health`, `/api/chat`, `/api/validate`, `/api/branches`), Bearer auth, 32-rule semantic engine, validate-and-substitute, @AcademicYearID injection, truncation guard, fast-path gating, sensitive blocklist, connection pool, retry re-check, 9-concept-type vocab engine.
- **v1.1.0** (VAPT hardening + admin config): 6 endpoints (4 user + 2 admin). Added `GET/PUT /api/admin/features` (24 feature flags, admin-only). VAPT code-side fixes: V4 (server-side tenant API key lookup — mobile app no longer sends `api_key`), V5 (audit logging to `audit_trail.db`), V7 (prompt-injection defense), V9 (input sanitization), V10 (generic prod error), V11 (LLM timeout).
- **v1.1.0+audit** (2026-08-31): **9 endpoints** (4 user + 5 admin/audit). Added `GET /api/audit` (paginated, optional `outcome` filter), `GET /api/audit/stats` (aggregate stats), `DELETE /api/audit` (clears all audit rows — admin-only). Backend bug fixes: (1) silent drop of unused SECURITY placeholders in the bind stage, (2) school's ExecuteQuery API error surfaced in chat-UI `message` field, (3) early 400 validation if `api_wrapper_url`/`target_database` empty in `api_wrapper` mode, (4) `use_inline_params=True` hardcoded (works around the school's repeated-placeholder API bug), (5) auto-load `backend/.env` via python-dotenv on startup. **End-to-end verified on Windows**: query "how many students are there in 10 a?" → `StudentCount = 32` from `V3_TestDatabase`.
- **v1.1.3** (2026-09-03, DOC-UPDATE-5 — documentation-only update; **no API surface changes**; endpoint count still **9**): 4 new pending UI/UX features identified for future implementation (none implemented yet, none change the API contract today):
  1. **AI disclaimer in `chat.html`** — frontend-only; no API impact.
  2. **LLM model selector dropdown** in `chat.html` → Settings — three options: **Chalo Language Model 1.0** (current, default), **CLM 2.0** (disabled — coming soon), **CLM 3.0** (disabled — coming soon). Will reuse the existing `model_url` request field (already supported by `/api/chat` — see §2.2 Optional fields). **No new endpoint needed.**
  3. **Configurable "show thinking process" toggle** — when implemented, will require a streaming variant of `/api/chat` (SSE or WebSocket) to emit stage events progressively. **Future API change:** likely a new `GET /api/chat/stream` endpoint OR an `Accept: text/event-stream` mode on `POST /api/chat`. **Not yet designed.**
  4. **Standard reply for unanswerable questions (configurable)** — backend reads `AI_SECRETARY_FALLBACK_MESSAGE` env var (or a new `fallback_message` key in `backend/feature_overrides.json`) and replaces the user-facing `message` field when `outcome ∈ {REFUSED, ERROR, NEEDS_DISAMBIGUATION}`. **Backward-compatible:** the raw `detail` + `semantic_violations` stay in the response body unchanged; only the user-facing `message` is replaced. For `NEEDS_DISAMBIGUATION`, the `disambiguation.candidates` array is preserved unchanged. **No new endpoint needed; small change to the `/api/chat` response construction.**

  Also documented: the **CTX_SIZE training-vs-inference distinction** (the `CTX_SIZE=2560` in `scripts/start_llm.bat` is a TRAINING constraint; at inference, the context window is independent and Qwen 2.5 Coder 7B natively supports 32K — pending decision: bump inference `--ctx-size` to 4096 to unlock a 2-page system prompt); the **system prompt expansion plan** (the #1 accuracy lever without retraining — pending the user pasting 4 small extracts from the codebase-analysis toolkit); the **3B vs 7B decision** (keep the 7B; get a GPU if latency is the problem — fine-tuning adds knowledge, not reasoning); the **`chalo-chatbot-persona` skill** and **`SESSION_RECORD.md`** project artifacts (no API impact).

  See `docs/PROJECT_STATUS.md` §4.6 + the 2026-09-03 update, `docs/SESSION_HANDOFF.md` (2026-09-03 update), `docs/INSTRUCTION_MANUAL.md` §2.8-2.9, `docs/COMPLETE_GUIDE.md` §4.7-4.8, `docs/HOW_IT_WORKS.md` §11, and `README.md` "Planned features / Roadmap" for full details.

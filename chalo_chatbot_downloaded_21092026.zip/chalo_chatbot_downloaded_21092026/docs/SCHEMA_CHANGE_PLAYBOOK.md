# Schema Change Playbook — How to Extend the DB Without External Help

**For:** the dev team.
**Purpose:** when the school adds new DB tables, columns, or business rules, this is the step-by-step guide to update the chatbot codebase + retrain the model — without any external assistance.

---

## 1. The decision tree — which steps you need

```
Schema change?
├── New table added?
│   ├── Step 1: add to schema_catalog.json
│   ├── Step 2: add 5-15 training examples
│   └── Steps 3-7: validate → gate → retrain → evaluate → deploy
│
├── New column on existing table?
│   ├── Step 1: add the column to schema_catalog.json
│   ├── Step 2: add 3-5 training examples using the new column
│   └── Steps 3-7: validate → gate → retrain → evaluate → deploy
│
├── Table renamed or deprecated?
│   ├── Step 1: update schema_catalog.json (remove old, add new)
│   ├── Step 2: add a DEPRECATED rule in semantic_rules.py
│   ├── Step 3: rewrite training examples to use the new table
│   └── Steps 4-7: validate → gate → retrain → evaluate → deploy
│
└── New business rule (no schema change)?
    ├── Step 1: write a new rule function in semantic_rules.py
    ├── Step 2: update training examples to follow the new rule
    └── Steps 3-7: validate → gate → retrain → evaluate → deploy
```

---

## 2. The 7 files that can change (and the ones that never do)

### Files you DO touch (schema-specific)

| File | When | What to change |
|---|---|---|
| `schema_catalog.json` | ANY schema change | Add/remove/update the table + columns entry |
| `pipeline/semantic_rules.py` | New business rule OR deprecated table | Add the rule function + RULES entry + RULE_META; OR add to DEPRECATED dict |
| `semantic_validation/semantic_rules.py` | Same — keep in sync | Copy the same changes |
| `vocab/synonyms.json` | New concept type | Add the concept type + synonyms |
| `pipeline/entity_extractor.py` | New alias pattern (e.g. `hr.Name=` for a new table) | Add the regex pattern |
| `evaluation/golden_questions.json` | Any schema change | Add 3-5 golden questions for the new table/column |
| `training_dataset_final_v28.jsonl` | Any schema change | Add the 5-15 training examples |

### Files you do NOT touch (schema-agnostic)

- `pipeline/orchestrator.py` — the 11-stage pipeline; no table names hardcoded.
- `pipeline/branch_scoping_gate.py` — checks for `UserAccountRoleDetails` linkage, not specific tables.
- `pipeline/alias_scope_check.py` — schema-agnostic.
- `pipeline/llm_client.py` — schema-agnostic.
- `pipeline/parameter_binder.py` — binds `@UserId` etc., not table-specific.
- `backend/main.py` — the API endpoints don't change.
- `backend/security.py` — unless a new sensitive table is added → add to `SENSITIVE_TABLES`.
- `vocab/inject.py` — reads the Context JSON's vocab, not hardcoded tables.

**Only 7 files change. Only 2 of them (the catalog + the training data) change for every schema change.**

---

## 3. Scenario A — A new table (e.g. `StudentHealthRecord`)

### Step 1: Update the schema catalog

The guardrail checks every table/column the model writes against `schema_catalog.json`. If a new table isn't in the catalog, the guardrail refuses any query referencing it.

```bash
# Option 1: re-export from the DB (the clean way)
sqlcmd -S <server> -d <database> -E -Q "
SELECT t.name AS TableName, c.name AS ColumnName
FROM sys.tables t JOIN sys.columns c ON t.object_id = c.object_id
ORDER BY t.name, c.column_id" -o schema_export.csv
# Convert to JSON format and merge into schema_catalog.json

# Option 2: manually add the new table (if you know its columns)
# In schema_catalog.json, add:
"StudentHealthRecord": ["ID", "StudentID", "Height", "Weight", "BMI", "CheckupDate", "BranchID", "AcademicYearID", "IsDeleted", "Created_Date", "Updated_Date"]
```

### Step 2: Add training examples (5-15 pairs)

Write question/SQL pairs. The rules:
1. Always include the full branch-scoping subquery (`UserAccountRoleDetails` UNION `BranchMaster` pattern).
2. Always include `AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date)` if the table has `AcademicYearID`.
3. Always include `(IsDeleted IS NULL OR IsDeleted = 0)` if the table has `IsDeleted`.
4. Vary the phrasing (3-5 different ways per question shape).
5. Cover different shapes: count, list, filter, group-by, top-N.
6. Include join examples if the table joins to existing tables.

```jsonl
{"input": "Show the latest health checkup for each student in Class 10", "output": "SELECT sm.FirstName + ' ' + sm.LastName AS StudentName, shr.CheckupDate, shr.Height, shr.Weight FROM StudentHealthRecord shr INNER JOIN Student_Master sm ON shr.StudentID = sm.ID INNER JOIN StudentAcademicDetail sad ON sad.StudentID = sm.ID WHERE sad.ClassID = (SELECT ID FROM ClassMaster WHERE Name = 'Class 10') AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date) AND shr.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (shr.IsDeleted IS NULL OR shr.IsDeleted = 0)"}
{"input": "How many students have BMI above 30?", "output": "..."}
{"input": "Class-wise average BMI", "output": "..."}
{"input": "Students who haven't had a health checkup this year", "output": "..."}
```

### Steps 3-7: Validate → Gate → Retrain → Evaluate → Deploy

```bash
# Step 3: Validate the new examples
cd chalo_chatbot/semantic_validation
python3 validate_dataset.py --dataset /path/to/updated_dataset.jsonl
# → Verify no HIGH violations on the new examples

# Step 4: Run the gate
python3 prepare_data.py
# → If HIGH = 0: produces train.jsonl + val.jsonl
# → If HIGH > 0: fix the examples and re-run

# Step 5: Retrain (same parameters as v28)
# Use the training notebook: r=16, dropout=0.05, lr=1e-4, warmup=35, MAX_SEQ_LENGTH=2560, epochs=2

# Step 6: Evaluate
cd chalo_chatbot/evaluation
python3 evaluate.py --model-url http://localhost:8080/v1/chat/completions --context-json sample_context.json --branch 1
# → Verify the new golden questions pass + no regressions

# Step 7: Deploy
# Upload the new GGUF to the LLM server → restart llama-cpp
# Verify: curl https://chatbot.chaloschools.in/api/health → status: "ok"
# Test a few questions about the new table via the mobile app
```

---

## 4. Scenario B — A new column on an existing table

### Step 1: Update the schema catalog

```json
// In schema_catalog.json, add the column to the existing table's entry:
"StudentAcademicDetail": ["ID", "StudentID", "ClassID", ..., "IsSportsEligible"]
```

### Step 2: Add 3-5 training examples using the new column

```jsonl
{"input": "List students eligible for sports", "output": "SELECT ... WHERE sad.IsSportsEligible = 1 AND ..."}
{"input": "How many students are not eligible for sports?", "output": "..."}
{"input": "Class-wise sports eligibility count", "output": "..."}
```

### Steps 3-7: same as Scenario A.

---

## 5. Scenario C — Table renamed or deprecated

### Step 1: Update the schema catalog

Remove the old table (or keep it if it still exists in the DB), add the new one.

### Step 2: Add a DEPRECATED rule

In `pipeline/semantic_rules.py`:
```python
DEPRECATED = {
    "EnquiryMaster": "GeneralCallRegister",
    "OldTableName": "NewTableName",  # add the new mapping
}
```

### Step 3: Rewrite training examples

Find all examples using the old table → rewrite to the new table. Run `validate_dataset.py` → the deprecated rule should fire on any examples you missed.

### Steps 4-7: same as above.

---

## 6. Scenario D — A new business rule (no schema change)

### Step 1: Write the rule

In `pipeline/semantic_rules.py`:
```python
def r_fee027(sql, q, tables):
    if "BusFeeStrucure" not in tables: return None
    if not _has(sql, r"Route_ID"):
        return Violation("FEE-027", "HIGH",
            "Bus-fee query omits Route_ID filter.",
            "Add AND bfs.Route_ID = @RouteID or JOIN Route_Master.", "Fees")
    return None
```

Add to `RULES` + `RULE_META`. Run `python3 semantic_rules.py` → verify the self-test. Sync to `semantic_validation/semantic_rules.py`.

### Step 2: Update training examples to follow the new rule.

### Steps 3-7: same as above.

---

## 7. When you do NOT need to retrain

| Change | Retrain? | Why |
|---|---|---|
| New optional column | No | The guardrail's updated catalog lets queries through; the model can query it but doesn't have to |
| Deprecated table + rule | No (but recommended) | The rule blocks the old table; the retry may find the new one — not ideal, but works |
| New synonym | No | The validate-and-substitute path handles it at runtime |
| New sensitive table | No | Add to `SENSITIVE_TABLES` in `security.py`; the guardrail + semantic engine block it at runtime |
| New table (the model must query it) | **Yes** | The model has never seen it |
| Renamed table | **Yes** | The model must learn the new name |
| New mandatory filter (business rule) | **Yes** | The model must learn to include the filter |

---

## 8. The retrain decision (do you actually need it?)

**Must retrain:**
- New table the model should query.
- Renamed table.
- New business rule that changes the SQL shape.

**Don't need to retrain:**
- New optional column (catalog update is enough).
- Deprecated table (the rule blocks it at runtime).
- New synonym (runtime substitution handles it).
- New sensitive table (add to the blocklist; runtime blocks it).

---

## 9. Estimated effort per change

| Change type | Code changes | Training examples | Retrain? | Total effort |
|---|---|---|---|---|
| New column (optional) | 30 min (catalog) | 3-5 examples | No | 1 hour |
| New table | 30 min (catalog) | 5-15 examples | Yes | 2-4 hours + retrain time |
| Deprecated table | 1 hour (catalog + rule) | Rewrite examples | Yes | 2-4 hours + retrain time |
| New business rule | 1 hour (rule) | Update examples | Yes | 1-2 hours + retrain time |
| New sensitive table | 15 min (blocklist) | None | No | 15 min |

Retrain time: 1-2 hours on GPU; 4-8 hours on CPU (8 OCPU).

---

## 10. The self-sufficiency checklist

Before doing your first schema change without external help, verify you can:

- [ ] Locate and edit `schema_catalog.json` (add a new table's columns).
- [ ] Write a training example in JSONL format with the full branch-scoping pattern.
- [ ] Run `validate_dataset.py` and read the HTML report.
- [ ] Run `prepare_data.py` and understand the gate (HIGH = 0 to proceed).
- [ ] Add a semantic rule to `semantic_rules.py` and run the self-test.
- [ ] Run the accuracy harness (`evaluate.py`) and read the scores.
- [ ] Deploy a new GGUF to the LLM server and restart llama-cpp.

If you can do all 7, you're self-sufficient for schema changes. This playbook is your reference; the 7 files in §2 are your surface area; the pipeline + backend don't change.

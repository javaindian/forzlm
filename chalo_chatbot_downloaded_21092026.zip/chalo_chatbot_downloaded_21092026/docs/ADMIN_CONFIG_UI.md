# Admin Config UI — Feature Flag Governance

**For:** the project owner (the admin) + the mobile-app team.
**Goal:** a single admin-only config page where the admin flips the 23 brainstorm ideas (and future features) on/off. The mobile app reads the enabled flags from the backend; the backend enforces them.

---

## 1. The principle

Every feature is **off by default**. The admin flips on the ones they want. The backend reads the flags at startup + persists admin overrides to `feature_overrides.json`. The mobile app receives the list of enabled flags in every `/api/chat` response (`features_enabled` field) and renders accordingly.

**A flag is a governance layer, not an implementation.** Flipping `insight_cards: true` doesn't build the insight-cards feature; it tells the backend "this feature is allowed." The feature's code lands in v1.1+. Until then, the flag is on but the feature does nothing (the backend doesn't run the insight generator; the mobile app doesn't render the cards). When the feature's code lands, it activates for every admin who has the flag on.

---

## 2. The backend endpoints

### 2.1 `GET /api/admin/features` — list the flags

**Auth:** admin Bearer token (a separate `AI_SECRETARY_ADMIN_TOKENS` env var).

**Response (200):**
```json
{
  "flags": {
    "auto_chart": false,
    "insight_cards": false,
    "trend_comparison": false,
    "drill_down": false,
    "morning_briefing": false,
    "anomaly_alerts": false,
    "you_might_also_ask": false,
    "hinglish_tamil": false,
    "school_jargon": false,
    "voice_input": false,
    "why_this_answer": false,
    "capability_card": false,
    "share_qa": false,
    "pin_questions": false,
    "schedule_questions": false,
    "feedback_loop": false,
    "question_clustering": false,
    "active_learning": false,
    "multi_school_benchmark": false,
    "parent_mode": false,
    "teacher_mode": false,
    "confidence_score": false,
    "source_sp": false,
    "audit_trail": false
  },
  "descriptions": {
    "auto_chart": "Auto-chart result tables (mobile-app rendering)",
    "insight_cards": "1-3 auto-generated insight cards on top of the answer",
    ...
  }
}
```

### 2.2 `PUT /api/admin/features` — update the flags

**Auth:** admin Bearer token.

**Request body:**
```json
{"flags": {"feedback_loop": true, "auto_chart": true}}
```

(Partial update — only the flags in the request body are changed; the rest stay as-is.)

**Response (200):** the full updated flags + descriptions (same shape as `GET`).

**Persistence:** the flags are written to `feature_overrides.json` in the backend directory. On restart, the backend loads the overrides. So changes persist across restarts.

### 2.3 The auth model

- **User tokens** (`AI_SECRETARY_AUTH_TOKENS`): for the mobile app to call `/api/chat`, `/api/branches`, `/api/validate`.
- **Admin tokens** (`AI_SECRETARY_ADMIN_TOKENS`): for the admin to call `/api/admin/*` endpoints. A separate token, so the mobile app can't flip features.
- In production, the admin token is stored in OCI Vault (per `docs/OCI_DEPLOYMENT.md` §4). The admin uses it from a separate admin mobile-app build OR a simple web UI (the local-test Next.js UI could be extended with an admin page).

---

## 3. The mobile-app admin UI

The admin's mobile app (a separate build from the user-facing app, OR a hidden "admin mode" in the same app gated by the admin token) has a "Features" screen:

- **A list of 24 toggles** (one per feature flag), each with:
  - The feature name (e.g. "Auto-chart results").
  - The description (from the `descriptions` field).
  - A switch (on/off).
- **A "Save" button** that calls `PUT /api/admin/features` with the changed flags.
- **A "Refresh" button** that calls `GET /api/admin/features` to reload the current state.

The toggles read from `GET /api/admin/features`; the save writes to `PUT /api/admin/features`. No local state — the backend is the source of truth.

---

## 4. How the flags affect the chat response

Every `/api/chat` response includes a `features_enabled` field — a list of the flags that are currently on AND apply to this request (per-role filtering, if a feature has role restrictions):

```json
{
  "outcome": "ANSWER",
  "sql": "...",
  "rows": [...],
  "features_enabled": ["feedback_loop", "auto_chart"],
  ...
}
```

The mobile app reads `features_enabled` and renders:
- If `feedback_loop` is in the list → show the 👍/👎 buttons under the answer.
- If `auto_chart` is in the list → render the result as a chart instead of (or alongside) the table.
- If `insight_cards` is in the list → fetch the insight cards (a separate endpoint, OR included in the response if the backend generated them).

The mobile app never hard-codes which features exist — it reads them from the backend. So when a new feature is added in v1.1, the mobile app doesn't need an update to know about it (only to render it, which is a UI change).

---

## 5. The feature-flag list (the 24 flags)

| Flag | Description | Status | Implementation phase |
|---|---|---|---|
| `auto_chart` | Auto-chart result tables | Off | v1.1 (mobile-app rendering) |
| `insight_cards` | 1-3 auto-generated insight cards | Off | v1.2 (a second LLM call) |
| `trend_comparison` | This-year-vs-last-year auto-add | Off | v1.1 |
| `drill_down` | Tappable rows → follow-ups | Off | v1.1 (mobile-app + the conversational resolver) |
| `morning_briefing` | Scheduled 6am insights + push | Off | v1.3 (scheduler + push infra) |
| `anomaly_alerts` | Nightly anomaly detection + push | Off | v1.3 |
| `you_might_also_ask` | 3 follow-up suggestions | Off | v1.1 (rule-based first) |
| `hinglish_tamil` | Bilingual mode | Off | v28 retrain |
| `school_jargon` | Jargon glossary in the prompt | Off | v28 (add to the instruction) |
| `voice_input` | STT integration | Off | v1.2 (mobile-app) |
| `why_this_answer` | "Why this answer?" expandable | Off | v1.1 (SQL explanation LLM call) |
| `capability_card` | "What I can/can't answer" page | Off | v1.0 (static content, easy) |
| `share_qa` | Deep-link sharing | Off | v1.2 (mobile-app) |
| `pin_questions` | Pin frequent questions | Off | v1.1 (mobile-app local storage) |
| `schedule_questions` | Scheduled queries + push | Off | v1.3 (scheduler) |
| `feedback_loop` | Thumbs up/down | **On** (admin set it on during testing) | v1.1 (the backend logging is ready; the UI is the work) |
| `question_clustering` | Weekly clustering report | Off | v1.3 (backend job) |
| `active_learning` | Chatbot asks admin for help | Off | v2.0 |
| `multi_school_benchmark` | Cross-branch comparison | Off | v1.1 (mobile-app, super-user) |
| `parent_mode` | Parent-facing | Off | v2.0 (parent RBAC) |
| `teacher_mode` | Teacher-facing | Off | v1.2 (class-teacher RBAC) |
| `confidence_score` | Green/amber dot | Off | v1.1 (the backend has the data; the UI is the work) |
| `source_sp` | Show the SP the query is based on | Off | v1.2 (similarity matching) |
| `audit_trail` | Show the audit trail in the admin UI | Off | v1.1 (the table is always logged; this flag controls UI visibility) |

---

## 6. The per-role filtering (future)

Some features should only apply to certain roles (e.g. `morning_briefing` is for principals only; `teacher_mode` is for teachers). The v1.1 implementation adds an `allowed_roles` map:

```python
FEATURE_ALLOWED_ROLES = {
    "morning_briefing": ["Principal", "Admin", "SuperUser"],
    "teacher_mode": ["Teacher", "ClassTeacher"],
    "multi_school_benchmark": ["SuperUser"],
    ...
}
```

The `/api/chat` response's `features_enabled` list only includes a flag if it's on AND the user's role (from the Context JSON) is in the `allowed_roles` list. This is v1.1 (after the role→screen→table RBAC ask 1.3 is resolved).

---

## 7. The implementation status

- **The backend endpoints are built and tested** (`GET` and `PUT /api/admin/features`, admin-only, persist to `feature_overrides.json`).
- **The flags are read into every `/api/chat` response** (`features_enabled` field).
- **The mobile-app admin UI is NOT built** (the project owner's mobile-app team will build the "Features" screen per §3).
- **The feature implementations are NOT built** (each flag is a governance layer; the actual feature code lands in v1.1+ per §5).
- **Per-role filtering is NOT built** (v1.1, after ask 1.3).

So today: the admin can flip flags on/off via the API, and the mobile app receives the list — but flipping a flag on doesn't change the chatbot's behavior yet (the feature code isn't there). This is intentional: the governance layer is in place before the features, so when the features land, they activate for admins who have the flag on, without a re-deploy.

---

## 8. How to use it (the admin)

1. Get the admin token: from `.env` on your LOCAL laptop (dev/testing), or from OCI Vault on the PRODUCTION server.
2. Call `GET /api/admin/features` to see the current state.
3. Call `PUT /api/admin/features` with the flags you want to change.
4. The changes take effect immediately (no backend restart needed — the flags are in memory).
5. The changes persist across restarts (saved to `feature_overrides.json`).

For the mobile-app admin UI: the mobile-app team builds a "Features" screen (per §3) that calls these endpoints. The admin taps toggles + saves. The flags update on the backend. The next user `/api/chat` call reflects the new flags in `features_enabled`.

---

## 8a. The audit trail viewer (`frontend/audit.html`) — admin-only

The audit-trail viewer is a standalone HTML page (`frontend/audit.html`, no build step). It uses the admin token (the same `AI_SECRETARY_ADMIN_TOKENS` used for `/api/admin/features`). It talks to three backend endpoints:

| Endpoint | Used for |
|---|---|
| `GET /api/audit?limit=N&offset=0&outcome=...` | Fetch a page of audit rows (paginated, optional `outcome` filter) |
| `GET /api/audit/stats` | Fetch the dashboard stats (total, outcome counts, avg latency, last-7-days count, refused-by-stage breakdown) |
| `DELETE /api/audit` | Clear ALL audit rows (used by the **Reset** button) |

### The UI shows

- A **dashboard** at the top: total queries, answered/refused/error counts + percentages, avg latency, last-7-days count, refused-by-stage breakdown.
- A **filter dropdown** (all / answered / refused / error) and pagination (50 rows per page).
- A **table** with: id, timestamp, user_id, branch_id, question, outcome badge, stage badge, SQL preview, violation count, latency, IP.
- Two **admin buttons** at the top right (NEW, 2026-08-31):

### Export XLSX (green button)

1. Click the green **Export XLSX** button.
2. The page fetches ALL audit rows (respecting the current `outcome` filter, up to 100,000) via `GET /api/audit?limit=100000`.
3. It downloads them as an Excel `.xlsx` file via **SheetJS** (loaded from the CDN at page-load time). Filename includes the date + row count (e.g. `audit_trail_2026-08-31_482rows.xlsx`).
4. **Falls back to CSV** if SheetJS isn't loaded (offline) — the CSV still opens in Excel.

This is the easiest way to share a month's worth of audit data with the dev team (for v28 training-data triage) or the compliance team.

### Reset (red button)

1. Click the red **Reset** button.
2. The page shows a confirmation dialog telling you how many rows will be deleted + a reminder to "Export XLSX first if you want a copy."
3. If you confirm, it calls `DELETE /api/audit` (admin-only).
4. The backend responds with `{"status":"ok","message":"Audit trail cleared. 0 row(s) remaining.","remaining":0}`.
5. The page reloads to show the now-empty audit trail.

This is useful for resetting the audit trail after a long testing session (so the next batch of user questions starts from a clean slate) or for clearing out stale data from a previous model version. **Cannot be undone — export first if you want a copy.**

---

## 9. The bottom line

The admin config UI is **an API today** (`GET`/`PUT /api/admin/features`, admin-only, tested). The **mobile-app admin UI** is the mobile-app team's work (a "Features" screen with toggles). The **feature implementations** are v1.1+ (each flag is governance; the code lands incrementally). The principle: **off by default, admin-controlled, mobile-app reads, backend enforces.**

# What I Improved vs. the Original `aisec.zip`

The original `aisec.zip` contained the `app_layer/` inference pipeline (~4,600 LOC across 20 Python files). I reconstructed it faithfully and extended it with the fixes from the 5-round audit. This document is the honest, file-by-file diff.

**The one-line summary:** the original pipeline had solid **structural** safety (schema existence, alias scope, branch scoping, value membership) but **no semantic verification**, **no vocab engine for 6 of 7 concept types**, **no accuracy measurement**, **no training-data gate**, and **no web UI**. I added all five, plus 8 specific fixes to existing stages.

---

## 1. The five new layers (didn't exist in aisec)

| New layer | What it does | Why the original didn't have it |
|---|---|---|
| **32-rule semantic engine** (`semantic_rules.py`) | Catches wrong term-master joins, missing Lien_Amount, missing Structure_Type, deprecated tables, sensitive columns, RBAC bypasses, cartesian subject joins, MinMark hallucination — 32 deterministic rules mined from the 1,095 SPs. | The original only had structural checks. 12.4% of v27 training labels contain semantic bugs that pass every original gate and execute as confident wrong answers. |
| **Vocab engine** (`vocab/inject.py` + `synonyms.json`) | Maps user phrasings → canonical concept keys → branch real literals. 9 concept types (the original's `concept_store.db` only had CLASS). Two modes: STOPGAP (validate-and-substitute, works with v27) and FULL (inject vocab, for v28 retrain). | The original `concept_store.db` had 86 CLASS synonyms only. Zero for SUBJECT/SECTION/ENQUIRY_STATUS/FEE_HEAD/EXAM_TERM. No FEE_TERM concept type at all. So "maths" → "MATHS" had no path — it went straight to a case-sensitive check and routed to disambiguation. |
| **Accuracy harness** (`evaluation/`) | 50 hand-written golden questions (20 truly novel, held out from training) + 4-axis scoring (structural/semantic/outcome/latency) + a runner that measures v27 vs v28 objectively. | The original had no evaluation harness. You couldn't measure whether a change improved or regressed the model. |
| **Training-data gate** (`semantic_validation/prepare_data.py`) | Refuses to produce train/val splits if HIGH-severity violations exceed threshold (default 0). Adds the `instruction` field the original sample prepare_data.py was missing. | The original `prepare_data.py` (v25 sample) passed labels through unchanged. No gate. You could train on the 12.4% buggy labels without knowing. |
| **Claude.ai-style web UI** (`src/app/page.tsx` + FastAPI backend) | A proper chat interface with conversation history, rich result rendering (SQL + rows + violations + trace), settings drawer, branch picker. | The original was a Streamlit app (`ui_app.py`) — single-file, less rich. (I didn't replace it; I built a fresh Next.js + FastAPI stack per your request.) |

---

## 2. The 8 fixes to existing pipeline stages

These are changes to files that existed in the original. I reconstructed the original logic faithfully, then applied the specific fix.

| Fix | File | What the original did | What I changed | The bug it fixes |
|---|---|---|---|---|
| **F6: validate-and-substitute** | `value_resolver.py` + `parameter_binder.py` + `orchestrator.py` | VALIDATE checked if the model's literal was a real branch value, but did NOT rewrite the SQL. So `CM.Name = 'Class 8'` with branch storing `'VIII'` → VALIDATED, but SQL still says `'Class 8'` → executes → returns zero rows as a confident ANSWER. | VALIDATE now returns `should_substitute=True` + `database_value`. The orchestrator calls `substitute_validated_values()` to rewrite the literal BEFORE the semantic check. | The round-2 §14b bug — a query that would be correct after substitution instead executed incorrectly and returned empty answers as confident ANSWERs. |
| **D1.3: @AcademicYearID injection** | `context.py` + `parameter_binder.py` | The binder only injected `@UserId` and `@SelectedBranchId`. The model had to guess or hardcode the academic year. | The Context JSON's `IsCurrentYear` academic year is now resolved and injected as `@AcademicYearID` — a trusted parameter like `@UserId`. | 149 v27 fee queries omit the academic-year filter (return all-time data); the model had no way to know the current year. |
| **D1.5: retry re-check** | `orchestrator.py` | On execute-error retry, the orchestrator re-ran guardrail + bind but NOT `check_branch_scoping`. A retry that dropped the `@UserId` scoping could execute unscoped. | The retry path now re-runs `check_branch_scoping` on the retried SQL before re-executing. | A real privilege-escalation path under failure conditions (round-2 §3 R2). |
| **D1.8: truncation guard** | `llm_client.py` + `orchestrator.py` | The client ignored `finish_reason`. A truncated SQL (over 512 tokens) was passed downstream, broke, and triggered a retry loop. | The client now raises `TruncationError` on `finish_reason='length'`. The orchestrator refuses with "the query is too complex; please ask a more specific question." | 110 v27 examples are near the 512-token limit. On CPU, complex queries can truncate and loop. |
| **D1.9: fast-path gating** | `orchestrator.py` + `dataset_lookup.py` + `template_lookups.py` | The fast-paths replay training SQL verbatim with no gate. Since 12.4% of v27 is semantically wrong, the cache silently served wrong answers. | Fast-paths are now config-gated (`fast_paths_enabled`, default OFF). | The fast-path was a semantic-error amplifier (round-1 §4 H5). |
| **D1.11: connection pool** | `local_executor.py` | Opened a fresh pyodbc connection per query (100-500ms handshake each). | A module-level single-connection pool per (driver, server, port, username, database) guarded by a threading.Lock. | Latency — every query paid the connection setup cost. |
| **D1.2/D1.6: sensitive blocklist in guardrail** | `guardrail.py` | The original only checked schema existence. `SELECT Password FROM UserAccountMaster` passed (the column exists). | The extended guardrail blocks SENSITIVE_TABLES (StorageConfiguration, SMS_ConfigurationSettings, etc.) and SENSITIVE_COLUMN_OWNERS (Password, Token, SGC_Password, etc.) at the schema layer. | Defense-in-depth — v27 training is clean on this, but the guardrail must still block it. (Note: your `config.yaml` has `blocked_columns` but I didn't find where it's enforced — open question Q12.) |
| **D1.13: synonyms for all concept types + FEE_TERM** | `vocab/synonyms.json` + `entity_extractor.py` + `context_vocab.py` | The original `concept_store.db` had 86 CLASS synonyms only. The entity_extractor only extracted EXAM_TERM (via `etm.Name=`), not FEE_TERM. The Context JSON had no FeeTerms key. | Hand-curated synonyms for all 9 concept types. Added `tm.Name=` extraction for FEE_TERM. Added `FeeTerms` to the Context JSON contract + a fallback that queries `TermMaster` when the API doesn't return it. | The headline fee/exam-term bug — the model had no FEE_TERM concept and only EXAM_TERM was validated. |

---

## 3. The 3 new semantic rules from your live traces

These came directly from the failing examples you reported. They didn't exist in the original (the original had no semantic engine at all).

| Rule | From your trace | What it catches |
|---|---|---|
| **EXAM-006** | "How many students passed maths in term 1?" — model hallucinated `smd.MinMark` | `MinMark` hallucinated on `StudentMarkDetails`/`StudentMarkMaster` — it lives on exam-config tables. |
| **EXAM-007** | Same trace — model had no exam-term filter | Marks queries about "passed/failed in term N" with no `ExamTypeMaster`/`ExamTermMaster` join. |
| **STUD-006** | Same trace — model joined `Subject_Master` on `BranchID` | Subject joins on `BranchID` (cartesian product — every subject matches every mark row). Caught **25 real bugs in v27**. |

---

## 4. What's the SAME (I didn't change these)

To be honest about what I did NOT improve:

- **The branch-scoping gate** (`branch_scoping_gate.py`) — unchanged. The round-2 F1 finding (too strict for BranchMaster-as-target) is documented but the fix is in the orchestrator's intent-classifier, not the gate. Left alone.
- **The alias-scope check** — unchanged. It was already correct.
- **The DB-query fallback in context.py** (`ContextManager`) — unchanged. The primary path is now `build_context_from_json`; the DB fallback is retained for compat.
- **The `concept_store.py`** — kept as a legacy compat layer. The new vocab engine supersedes it, but the original code paths still reference it.
- **The frozen system prompt** — unchanged. It must match training verbatim. For v28, you change it in `prepare_data.py` and regenerate.
- **The fast-path logic** (dataset_lookup, template_lookups) — the logic is the same; I only added the `enabled` flag (D1.9).

---

## 5. What I couldn't improve (open questions)

These are gaps I found but couldn't close without your input:

| Open question | Why it's still open |
|---|---|
| **School routing** (Q11) — the `databases`/`school_mappings` layer in `config.yaml` | I didn't find this code in `app_layer/`. It may live in `ui_app.py` (which I only saw Part 1 of) or a separate module. |
| **Table/column blocklist enforcement** (Q12) — `allowed_tables`, `blocked_columns`, `max_joins` in `config.yaml` | The `sql_guardrail.py` I read doesn't enforce these. I added sensitive-column blocking to the guardrail (D1.2), but the 16-table whitelist + join limit aren't enforced anywhere I could find. |
| **The v28 retrain** | I delivered `prepare_data.py` (gated, instruction-field, vocab-aware option) + the 50 new training examples. The actual retrain is yours to run. |
| **Class-teacher row-level RBAC** (D5) | Designed but not implemented. Needs `UserRoleClassMapping` integration + an intent classifier to decide when to apply it. |

---

## 6. The documentation (didn't exist in aisec)

| Document | What it's for |
|---|---|
| `docs/HOW_IT_WORKS.md` | The plain-language guide — layers, journey of a question, each file's job, health checks, troubleshooting matrix |
| `docs/GUIDELINES.md` | The single source of truth — every problem, impact, mitigation (735 lines) |
| `docs/BLINDSPOT_AUDIT.md` | The round-by-round findings with root-cause proofs |
| `semantic_validation/README.md` | How to use the semantic validation suite |
| `semantic_validation/semantic_rules_catalog.md` | The full 78-rule catalog mined from the 1,095 SPs |

The original `aisec.zip` had inline code comments (good ones) but no standalone documentation. You now have 5 docs covering the system from entry-level to deep-dive.

---

## 7. The measurable difference

| Metric | Original aisec | After my work |
|---|---|---|
| Semantic rules engine | 0 rules (no engine) | 32 rules (29 base + 3 from your live traces) |
| Semantic bugs caught at runtime | 0 (all passed structural gates) | 688 HIGH violations caught on v27 (12.4% of labels) |
| Concept types with synonyms | 1 (CLASS only) | 9 (CLASS, SECTION, SUBJECT, ENQUIRY_STATUS, FEE_HEAD, EXAM_TERM, FEE_TERM, DESIGNATION, ROLE) |
| Validate-and-substitute | No (validated but didn't rewrite) | Yes (F6 fix — rewrites "maths" → "MATHS" before semantic check) |
| @AcademicYearID injection | No (model guessed) | Yes (trusted parameter from Context JSON) |
| Truncation detection | No (truncated SQL broke downstream) | Yes (TruncationError → REFUSED) |
| Fast-path gating | Always on (replayed buggy SQL) | Config-gated, default OFF until labels cleaned |
| Training-data gate | None (trained on buggy labels) | prepare_data.py refuses if HIGH violations > 0 |
| Accuracy harness | None | 50 golden questions + 4-axis scoring + runner |
| Sensitive-table blocklist | Not enforced (column exists → passes) | Enforced at guardrail + semantic layers |
| Connection pool | None (fresh connection per query) | Module-level pool (D1.11) |
| Retry re-check | Skipped branch-scoping on retry | Re-runs branch-scoping on retried SQL (D1.5) |
| Web UI | Streamlit (single-file) | Claude.ai-style Next.js + FastAPI |
| Documentation | Inline comments only | 5 standalone docs (HOW_IT_WORKS, GUIDELINES, BLINDSPOT_AUDIT, 2 catalog READMEs) |

---

## 8. The honest caveat

I reconstructed the pipeline from my conversation context (I read every `app_layer/*.py` file before the upload folder was cleared). There may be small drift from your real files — whitespace, comment edits, a line I misremembered. The files most at risk of drift are the ones with complex logic I reconstructed from memory rather than re-reading:

- `orchestrator.py` (715 LOC — the most complex)
- `value_resolver.py` (499 LOC)
- `parameter_binder.py` (579 LOC)
- `guardrail.py` (462 LOC)

**Before deploying, diff these against your real `aisec.zip` files and tell me what differs.** I'll fix the diffs. The extensions (the 8 fixes + 5 new layers) are the value-add; the reconstruction is meant to be faithful but may have minor drift.

The new layers (semantic engine, vocab engine, accuracy harness, training-data gate, web UI) are entirely new code — no drift risk there.

---

## 9. The bottom line

The original aisec was a **structurally safe** pipeline that could not verify semantic correctness. It would execute a query that joined fee tables to `ExamTermMaster` and return wrong data as a confident answer. It had no way to measure accuracy. It had no way to stop you training on buggy labels. It had no vocab engine for 6 of 7 concept types. It had no web UI you'd want to ship.

I added a semantic layer that catches 12.4% of v27 as buggy, a vocab engine that fixes the casing/term confusion, an accuracy harness that measures the model objectively, a training-data gate that stops you shipping broken labels, and a Claude.ai-style chat UI. Plus 8 targeted fixes to existing stages.

The architecture is the same. The stages are the same. The extensions are what make it production-grade.

@echo off
REM ============================================================
REM package.bat — Create a clean, downloadable zip of the project
REM ============================================================
REM
REM WHAT THIS DOES:
REM   Creates chalo_chatbot.zip with everything you need to run
REM   the AI Secretary, EXCLUDING junk (node_modules, __pycache__,
REM   .next build cache, .pyc files, audit_trail.db runtime data).
REM
REM USAGE (Windows):
REM   Double-click this file, OR run from cmd:
REM   cd chalo_chatbot
REM   package.bat
REM
REM PREREQUISITES:
REM   - PowerShell 5+ (built into Windows 10/11) — uses Compress-Archive
REM
REM OUTPUT:
REM   chalo_chatbot.zip  (in this folder)
REM
REM THEN:
REM   Download chalo_chatbot.zip, unzip on any machine,
REM   read README.md -> STRUCTURE.md -> follow Quick Start.
REM ============================================================

setlocal enabledelayedexpansion
cd /d "%~dp0"

echo ============================================================
echo  Packaging chalo_chatbot for clean download
echo ============================================================
echo.

REM Delete any previous zip
if exist chalo_chatbot.zip del chalo_chatbot.zip

REM Use PowerShell to create the zip, excluding junk
REM Compress-Archive doesn't support excludes natively, so we
REM copy to a temp folder first, clean it, then zip.
set TEMP_STAGE=%TEMP%\chalo_package_stage
if exist "%TEMP_STAGE%" rmdir /s /q "%TEMP_STAGE%"
mkdir "%TEMP_STAGE%"

echo  Copying files to staging area (excluding junk)...
echo.

REM Use robocopy to copy everything EXCEPT junk folders
REM /E = copy subdirs including empty ones
REM /XD = exclude directories
REM /XF = exclude files
robocopy "%~dp0" "%TEMP_STAGE%\chalo_chatbot" /E ^
    /XD node_modules __pycache__ .next .venv venv .git ^
    /XF *.pyc .DS_Store Thumbs.db audit_trail.db audit_trail.db-journal .env ^
    /XF package.bat chalo_chatbot.zip ^
    /NFL /NDL /NJH /NJS /NC /NS /NP >nul 2>&1

echo  Creating zip...
powershell -NoProfile -Command "Compress-Archive -Path '%TEMP_STAGE%\chalo_chatbot' -DestinationPath '%~dp0chalo_chatbot.zip' -Force"

REM Clean up staging
rmdir /s /q "%TEMP_STAGE%"

echo.
echo ============================================================
echo  DONE!
echo ============================================================
echo.
echo  Output: %~dp0chalo_chatbot.zip
for %%I in (chalo_chatbot.zip) do echo  Size:   %%~zI bytes
echo.
echo  To use:
echo    1. Download chalo_chatbot.zip
echo    2. Unzip it on any machine
echo    3. Open README.md -^> follow Quick Start
echo.
pause

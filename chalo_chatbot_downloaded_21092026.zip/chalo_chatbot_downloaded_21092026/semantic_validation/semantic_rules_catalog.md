# ChaloSchools (V3_CHALO) — Semantic Rules Catalog

**Task ID:** SP-MINE
**Agent:** sp-miner
**Source:** `/home/z/my-project/upload/aisec_extracted/aisec/all SPs.xlsx` — 1,095 stored procedures (1,092 with non-null names).
**Purpose:** A deterministic semantic-verification catalog that Text-to-SQL training labels should obey. Each rule is grounded in an actual SP body; quoted SQL fragments are real.

Rules are organized by module. Each rule has a stable RULE_ID, a precise RULE statement, an EVIDENCE block naming the actual SP(s) and quoting the SQL fragment, a CHECK (machine-checkable predicate), and a SEVERITY.

Severity scale:
- **HIGH** — silent wrong-answer risk (model produces syntactically-valid SQL that returns the wrong numbers).
- **MEDIUM** — plausible mistake that may pass review but breaks downstream logic.
- **LOW** — stylistic / naming-only.

---

## 1. MODULE: Fees

### FEE-001
**RULE:** Any query reading `FeesInformationStudentDetail` to compute an "outstanding / pending / due / defaulter / balance / remaining" amount MUST subtract `Lien_Amount` in the outstanding expression.
**EVIDENCE:** `GetFeePendingByFeesInformationStudentDetail` defines `(Amount-ISNULL(Concession_Amt,0)-Paid_Amt-Lien_Amount) Remaining_Amt` and applies the filter `(Amount-ISNULL(FI.Concession_Amt,0)-FI.Paid_Amt-FI.Lien_Amount) > 0` in all four payment-mode branches. `SP_AbstractFeesReport` uses `sum((ISnull(Amount,0)-Isnull(Concession_Amt,0)-Isnull(Paid_Amt,0)-Isnull(Lien_Amount,0))) as Amount1`. `GetPreviousYearFeePendingByCompanywise` uses `Sum(... - Paid_Amt-Lien_Amount) Remaining_Amt`. `sp_TransportFeeNonPaidReport` uses `sum((ISnull(Amount,0)-Isnull(Concession_Amt,0)-Isnull(Paid_Amt,0)-Isnull(Lien_Amount,0)))`.
**CHECK:** When the query touches `FeesInformationStudentDetail` AND the SELECT/HAVING/column-alias text matches `outstanding|pending|due|defaulter|owe|balance|remaining` (case-insensitive), the outstanding expression MUST contain `Lien_Amount` with a minus sign. Python regex: `r'(?i)lien_amount'` must appear in the same expression that computes outstanding.
**SEVERITY:** HIGH

### FEE-002
**RULE:** The outstanding formula MUST subtract `ISNULL(Concession_Amt,0)` (never `Concession_Amt` directly — NULL concessions must be coerced to 0).
**EVIDENCE:** Every canonical fee-pending SP wraps concession in ISNULL: `GetFeePendingByFeesInformationStudentDetail`, `SP_AbstractFeesReport`, `Sp_Chalo_ReportFeeOustanding` (`SUM(Amount-ISNULL(Concession_Amt,0))`), `Sp_Chalo_ReportFeeOustandingTermwise`, `Sp_Chalo_ReportFeePendencyStudent`, `sp_TransportFeeNonPaidReport`.
**CHECK:** Outstanding expression must contain `ISNULL(Concession_Amt,0)` or `ISNULL(Concession_Amt, 0)`. Regex: `r'(?i)isnull\s*\(\s*concession_amt\s*,\s*0\s*\)'`.
**SEVERITY:** HIGH

### FEE-003
**RULE:** The outstanding formula MUST subtract `Paid_Amt` (not `Receipt_Amt` — `Receipt_Amt` is the FeesCollection header total, not the per-row paid amount).
**EVIDENCE:** Every FeesInformationStudentDetail outstanding SP uses `Paid_Amt`. `FeesCollection.Receipt_Amt` is read in receipt-style SPs (`sp_FeesCollection_SelectRecord`, `sp_SelectFeeCollectionList`, `SP_GetChequeBounceHistory`) — it is the bill receipt total, NOT the row-level applied amount.
**CHECK:** Outstanding expression must NOT contain `Receipt_Amt`. Regex: `r'(?i)receipt_amt'` must NOT appear in any expression aliased as outstanding/balance/remaining/due/pending.
**SEVERITY:** HIGH

### FEE-004
**RULE:** Outstanding / pending queries on `FeesInformationStudentDetail` MUST filter `IsIncludedInLumpSum = 0` (or `!= 1`) — lump-sum-included rows are NOT demand rows.
**EVIDENCE:** `GetFeePendingByFeesInformationStudentDetail` (`FI.IsIncludedInLumpSum != 1`); `Sp_Chalo_ReportFeeOustanding` (`FS.IsIncludedInLumpSum=0`); `Sp_Chalo_ReportFeeOustandingTermwise`; `Sp_Chalo_ReportFeeOustandingClassSectionTermwise`; `SP_Fees_RPT_GetAcademicFessOutstanding`; `SP_Fees_RPT_GetFessSummary`; `SP_Fees_RPT_GetFessSummaryHeadWise`; `Sp_Chalo_ReportFeePendencyStudent`; `Sp_Chalo_ReportFeePendencySMSStudentMonth`; `Sp_Chalo_ReportFeeOustandingBusFeeTermwise`; `Sp_Fees_RPT_BusFeeOustanding`; `Sp_Fees_RPT_BusFeeOustandingByClassSection`; `Sp_Chalo_ReportFeeOustandingCategoryWise` (implicit via `IsIncludedInLumpSum=0`); `sp_TransportFeeNonPaidReport`; `SP_AbstractFeesReport` (via inner-join chain).
**CHECK:** When the FROM/JOIN touches `FeesInformationStudentDetail`, the WHERE clause must contain `IsIncludedInLumpSum = 0` or `IsIncludedInLumpSum != 1`. Regex: `r'(?i)isincludedinlumpsum\s*(=|!=|<>)\s*(0|1\b)'`.
**SEVERITY:** HIGH

### FEE-005
**RULE:** Outstanding / pending / summary queries on `FeesInformationStudentDetail` for ACADEMIC fees MUST filter `Structure_Type IN ('Academic','Optional')` (and the value list never includes 'Bus','Hostel','LumpSum','Donation','Misc').
**EVIDENCE:** `Sp_Chalo_ReportFeeOustandingTermwise`, `Sp_Chalo_ReportFeeOustandingClassSectionTermwise`, `SP_Fees_RPT_GetAcademicFessOutstanding` all use `Structure_Type IN ('Academic','Optional')`. `GetFeePendingByFeesInformationStudentDetail` selects each branch separately with literal `'Academic'` and `'Optional'` (and other branches for Bus/Hostel via UNION, but each branch is gated by Structure_Type).
**CHECK:** For an academic-fee outstanding query, the WHERE clause must contain `Structure_Type IN ('Academic','Optional')` (case-insensitive, order-independent). Regex: `r'(?i)structure_type\s+in\s*\(\s*[\'\"]academic[\'\"]\s*,\s*[\'\"]optional[\'"]\s*\)'` (also accept reversed order).
**SEVERITY:** HIGH

### FEE-006
**RULE:** Any fee query joining on `Term_ID` from a fee table MUST join to `TermMaster` (the fee-term master). Joining `FeesInformationStudentDetail.Term_ID` to `ExamTermMaster.ID` is wrong because the two sequences are independent.
**EVIDENCE:** `GetFeePendingByFeesInformationStudentDetail` (`JOIN TermMaster T on T.ID=FI.Term_ID`); `Sp_Chalo_ReportFeeOustandingCategoryWise` (`join TermMaster tm on tm.ID = fisd.Term_ID`); `SP_Fees_RPT_GetAcademicFessOutstanding` (implicit); `sp_ClasswiseOutstandingCountReport` (`join TermMaster TM on TM.ID = A.Term_ID`); `Sp_Chalo_GetStudentApplicableFees` (`JOIN TermMaster tm on tm.ID=fsm.Term_ID`); `Sp_Chalo_GetStudentApplicableConcession` (same). NO fee-outstanding SP joins `ExamTermMaster` — `ExamTermMaster` appears only in exam/mark/progress-card SPs.
**CHECK:** If the FROM list contains a fee table (`FeesInformationStudentDetail`, `FeeStructureMonth`, `FeesCollection_Details`, `BusFeeStrucure`, `HostelFeeStructure`, `LateFeeMaster`) AND the query joins a "term" master, the master MUST be `TermMaster`, not `ExamTermMaster`. Regex: `r'(?i)join\s+(dbo\.)?ExamTermMaster\b'` must NOT appear when any fee table is in the FROM list.
**SEVERITY:** HIGH

### FEE-007
**RULE:** Fee-outstanding / collection / summary queries MUST filter by `AcademicYearID` (every canonical fee SP takes `@AcademicYearID` and applies it). Resolving the academic year via `YEAR(GETDATE())` is forbidden.
**EVIDENCE:** `Sp_Chalo_ReportFeeOustanding` (`AcademicYearID=@AcademicYearID`); `Sp_Chalo_ReportFeeOustandingTermwise`; `SP_Fees_RPT_GetAcademicFessOutstanding`; `Sp_Chalo_ReportFeePendencyStudent`; `GetFeePendingByFeesInformationStudentDetail`; `sp_ClasswiseOutstandingCountReport` (joins `Branch_Academic_Details` on `A.AcademicYearID`). `YEAR(GETDATE())` returns zero matches across all 1,092 SPs.
**CHECK:** For any fee-table SELECT, the WHERE clause must contain `AcademicYearID = @AcademicYearID` (or join `Branch_Academic_Details BAD on BAD.ID = ...AcademicYearID`). Regex: `r'(?i)academicyearid\s*=\s*@academicyearid'`.
**SEVERITY:** HIGH

### FEE-008
**RULE:** Fee queries MUST filter by `BranchID`. Multi-branch scoping uses the RBAC pattern (see RBAC-002). A "default to BranchMaster.ID" implicit filter is NOT acceptable.
**EVIDENCE:** Every fee SP takes `@BranchID` and applies `BranchID=@BranchID` (or, in dashboards, `BranchID in (select * from @branches)`).
**CHECK:** WHERE clause must contain `BranchID = @BranchID` or `BranchID in (...)` from a scoping subquery. Regex: `r'(?i)branchid\s*=\s*@branchid'` OR `r'(?i)branchid\s+in\s*\('`.
**SEVERITY:** HIGH

### FEE-009
**RULE:** When joining `StudentAcademicDetail` for an outstanding/pending/summary report, the query MUST filter `(IsTCIssued = 0 OR IsTCIssued IS NULL)` to exclude TC-issued students.
**EVIDENCE:** `Sp_Chalo_ReportFeeOustanding`, `Sp_Chalo_ReportFeeOustandingTermwise`, `Sp_Chalo_ReportFeeOustandingClassSectionTermwise`, `SP_Fees_RPT_GetAcademicFessOutstanding`, `SP_Fees_RPT_GetFessSummary`, `SP_Fees_RPT_GetFessSummaryHeadWise`, `Sp_Chalo_ReportFeePendencyStudent`, `Sp_Chalo_ReportFeePendencySMSStudentMonth`, `Sp_Fees_RPT_BusFeeOustanding`, `Sp_Fees_RPT_BusFeeOustandingByClassSection`, `Sp_Chalo_ReportFeeOustandingCategoryWise` (more sophisticated: `IsTCIssued = 1 and cast(sad.TCIssuedDate as date) < @tStartDate` to exclude only students whose TC was issued BEFORE the term started), `sp_TransportFeeNonPaidReport`, `sp_TransportFeePaidReport`.
**CHECK:** When the FROM/JOIN contains `StudentAcademicDetail`, the WHERE must contain `IsTCIssued = 0` or `IsTCIssued IS NULL` (or the sophisticated variant: `cast(TCIssuedDate as date) < @tStartDate`). Regex: `r'(?i)istcissued\s*=\s*0|istcissued\s+is\s+null'`.
**SEVERITY:** HIGH

### FEE-010
**RULE:** Late-fee pending queries MUST UNION the late-fee demand computed from `LateFeeMaster` JOIN `LateFeeDetails` JOIN `LateFee_Concession` with the regular fee demand. The late-fee amount formula is `(lfd.Amount - ISNULL(lfc.Concession_Amount, 0))`.
**EVIDENCE:** `GetFeePendingByFeesInformationStudentDetail` — main branch UNIONs a late-fee subquery joining `LateFeeMaster lfm ON lfm.TermId = FI.Term_ID AND lfm.IsActive = 1 AND CAST(GETDATE() as date) <= lfm.ValidityDate AND CAST(GETDATE() as date) >= lfm.LastDate` and `LateFeeDetails lfd ON lfm.ID = lfd.LateFeeID AND (lfd.ClassId = FI.ClassID or lfd.ClassId = 0) AND CAST(GETDATE() as date) between lfd.FromDate and lfd.ToDate` and `LEFT JOIN LateFee_Concession lfc ON lfc.Student_ID = FI.Student_ID AND lfc.LateFeeHeadId = lfm.LateFeeHeadId AND lfc.Term_ID = FI.Term_ID AND lfc.AcademicYearID = FI.AcademicYearID AND lfc.BranchID = FI.BranchID AND ISNULL(lfc.IsDeleted, 0) = 0`. `GetAllStudentsWithPendingLateFees` follows the same pattern.
**CHECK:** When the SP/intent mentions "late fee pending/defaulter", the query MUST contain `LateFeeMaster`, `LateFeeDetails`, and `LateFee_Concession` (all three) AND a CAST(GETDATE()...) date-window predicate. Regex: `r'(?i)LateFeeMaster'`, `r'(?i)LateFeeDetails'`, `r'(?i)LateFee_Concession'`.
**SEVERITY:** HIGH

### FEE-011
**RULE:** Aggregate fee-collection amount queries MUST filter `FeesCollection.ChequeStatus_ID IN (1, 2)` (Cleared + Pending) OR `ChequeStatus_ID NOT IN (3, 4)` (NOT bounced, NOT cancelled). The two forms are equivalent.
**EVIDENCE:** `GetCompanywiseFeesOutstanding` (`F.ChequeStatus_Id IN(1,2)`); `sp_SelectFeeCollectionList` (`(FC.ChequeStatus_ID=1 or FC.ChequeStatus_ID=2)`); `sp_ProspectusFeesCollection` (`(PFC.ChequeStatus_ID =1 or PFC.ChequeStatus_ID=2)`); `sp_ProspectusFeesCollectionList_Search` (`(PFC.ChequeStatus_ID =1 or PFC.ChequeStatus_ID=2)`); `sp_SelectDonationFeeCollectionList` (`(FC.ChequeStatus_ID=1 or FC.ChequeStatus_ID=2)`); `sp_TransportFeePaidReport` (`A.ChequeStatus_ID in (1,2)`); `Sp_Chalo_ReportFeeOustandingCategoryWise` (uses both `ChequeStatus_ID in (1, 2)` for prior-term outstanding AND `ChequeStatus_ID in (1,2,5)` in `SP_GetCollectionModeDayClosureData`).
**CHECK:** For any `FeesCollection` SELECT summing `Paid_Amt` or `Receipt_Amt` as "collected", the WHERE must contain `ChequeStatus_ID IN (1, 2)` or `ChequeStatus_ID NOT IN (3, 4)` or `(ChequeStatus_ID=1 OR ChequeStatus_ID=2)`. Regex: `r'(?i)chequestatus_id\s+in\s*\(\s*1\s*,\s*2\s*\)|chequestatus_id\s+not\s+in\s*\(\s*3\s*,\s*4\s*\)|chequestatus_id\s*=\s*1\s*or\s*chequestatus_id\s*=\s*2'`.
**SEVERITY:** HIGH

### FEE-012
**RULE:** Cheque-bounce queries use `ChequeStatus_ID = 3`. Cheque-cancelled queries use `ChequeStatus_ID = 4`.
**EVIDENCE:** `SP_GetChequeBounceHistory` (`FC.ChequeStatus_ID=3`); `ReportFeeCancellationStudent` (`FC.ChequeStatus_ID IN (4)`); `sp_ProspectusFeeCollectionReport` (`PFC.ChequeStatus_ID <> 4` to exclude cancelled).
**CHECK:** Bounce intent → `ChequeStatus_ID = 3`. Cancelled intent → `ChequeStatus_ID = 4`. Regex: `r'(?i)chequestatus_id\s*=\s*3'` for bounce, `r'(?i)chequestatus_id\s*(=|in\s*\()\s*4'` for cancelled.
**SEVERITY:** MEDIUM

### FEE-013
**RULE:** Current-term resolution MUST use `CAST(GETDATE() AS date) BETWEEN TermMaster.StartingDate AND TermMaster.EndingDate` (the fee-term master, `TermMaster`, columns are `StartingDate date` and `EndingDate date`). Never use `ExamTermMaster.StartDate/EndDate` for fee current-term.
**EVIDENCE:** `SP_GetFeesEffectiveAdmissionDate` (`select ISNULL(tm.StartingDate, ...) from dbo.TermMaster tm where @AdmissionDate >= tm.StartingDate AND @AdmissionDate <= tm.EndingDate and tm.AcademicYearID=@ACYID and tm.BranchID=@BranchId`). `SP_GetTerm_ID` resolves the current TermMaster.ID by `CROSS JOIN @Act_Date` where `StartingDate <=ad.Actual_Date AND EndingDate >= ad.Actual_Date`. `Sp_Chalo_ReportFeeOustandingCategoryWise` resolves `@tStartDate = (select StartingDate FROM TermMaster where ID = @TermID)`.
**CHECK:** For "current fee term" intent, the query must (a) read from `TermMaster` (not ExamTermMaster), (b) compare a date (GETDATE() or input) to `StartingDate`/`EndingDate` columns. Regex: `r'(?i)TermMaster'` AND `r'(?i)startingdate'` AND `r'(?i)endingdate'` AND NOT `r'(?i)ExamTermMaster'`.
**SEVERITY:** HIGH

### FEE-014
**RULE:** Bus-fee outstanding queries MUST filter `FeesInformationStudentDetail.IsBusFee = 1`.
**EVIDENCE:** `Sp_Chalo_ReportFeeOustandingBusFeeTermwise` (`FS.IsBusFee=1`); `Sp_Fees_RPT_BusFeeOustanding` (`FS.IsBusFee=1`); `Sp_Fees_RPT_BusFeeOustandingByClassSection` (`FS.IsBusFee=1`); `Sp_Fees_RPT_TransportFeeList` (`FS.IsBusFee=1`); `sp_TransportFeeNonPaidReport` (`A.IsBusFee=1`).
**CHECK:** When the query reads `FeesInformationStudentDetail` for a bus-fee intent, the WHERE must contain `IsBusFee = 1`. Regex: `r'(?i)isbusfee\s*=\s*1'`.
**SEVERITY:** HIGH

### FEE-015
**RULE:** `FeesInformationStudentDetail` has NO `IsDeleted` column — soft-delete is enforced via the `Paid_Amt=0` projection (`SP_Update_OutstandingAmount` re-derives `Paid_Amt` and `Lien_Amount` from `FeesCollection`); the row is "live" if it appears in the table.
**EVIDENCE:** `SP_Update_OutstandingAmount` re-writes `Paid_Amt` and `Lien_Amount` via `dbo.GetPaidAmtForStudent(...)`; the table is treated as fully materialised. `sp_StudentMaster_SelectRecord` joins a sub-query on `BusFeeStrucure WHERE IsDeleted = 0` and `HostelFeeStructure WHERE IsDeleted = 0` — those tables DO have `IsDeleted`. But `FeesInformationStudentDetail` itself is never filtered by IsDeleted in any SP (search confirms 0 occurrences of `FeesInformationStudentDetail.*IsDeleted` as a predicate).
**CHECK:** Do NOT add `FeesInformationStudentDetail.IsDeleted = 0` to a fee query (it's a non-existent column). Regex: `r'(?i)FeesInformationStudentDetail.*\.IsDeleted'` must NOT appear in WHERE.
**SEVERITY:** MEDIUM

### FEE-016
**RULE:** `DonationFeesCollection` has NO `IsDeleted` filter in its live SPs — soft-delete is encoded via `ChequeStatus_ID` (4 = cancelled). Apply `(ChequeStatus_ID=1 or ChequeStatus_ID=2)` for "active donations" and `ChequeStatus_ID <> 4` for "non-cancelled".
**EVIDENCE:** `sp_SelectDonationFeeCollectionList` (`(FC.ChequeStatus_ID=1 or FC.ChequeStatus_ID=2)`); `sp_Donation_FeesCollection_SelectRecord` (no IsDeleted filter — only `FC.ID=@ID AND FC.BranchID=@BranchID AND FC.AcademicYearID=@ACD`).
**CHECK:** Donation-collection queries MUST NOT use `DonationFeesCollection.IsDeleted = ...`. Use `ChequeStatus_ID` predicates only. Regex: `r'(?i)DonationFeesCollection.*IsDeleted|DonationFeesCollection\s+\w+\s+WHERE.*IsDeleted'` must NOT match.
**SEVERITY:** MEDIUM

### FEE-017
**RULE:** Prior-term outstanding carry-over MUST compute from `FeesCollection_Details` joined to `FeesCollection` (not from `FeesInformationStudentDetail.Paid_Amt` alone) AND filter `ChequeStatus_ID IN (1, 2)` AND `cast(Bill_Date as date) < @tStartDate`.
**EVIDENCE:** `Sp_Chalo_ReportFeeOustandingCategoryWise` — declares `@TermOutstanding table (StudentId bigint, Amount numeric)` and inserts `select fc.Student_ID, ISNULL(sum(fcd.Paid_Amt),0) from FeesCollection fc join FeesCollection_Details fcd on fc.Id = fcd.Fees_Collection_ID and fcd.Term_ID < @TermId where fc.AcademicYearID = @AcademicYearId and fc.ChequeStatus_ID in (1, 2) and cast(fc.Bill_Date as date) < @tStartDate ...`.
**CHECK:** For "previous term outstanding" intent, the query must contain `FeesCollection_Details`, `ChequeStatus_ID in (1, 2)`, and `Bill_Date <` (some term start date).
**SEVERITY:** HIGH

### FEE-018
**RULE:** `FeesCollection_Details.Term_ID` references `TermMaster.ID` (NOT `ExamTermMaster.ID`). Same convention as `FeesInformationStudentDetail.Term_ID` and `BusFeeStrucure.Term_ID` and `HostelFeeStructure.Term_ID` and `LateFeeMaster.TermId`.
**EVIDENCE:** `Sp_Chalo_ReportFeeOustandingCategoryWise` — `fcd.Term_ID in (select ID from TermMaster where AcademicYearID = @AcademicYearID and DisplayOrder > @DisplayOrder)`. `SP_GetCollectionModeDayClosureData` (joins FeesCollection → FeesCollection_Details → TermMaster path via FeesCollection_Details). `sp_LateFeeMaster_SelectAll` — `join TermMaster tm on Lfm.TermId = tm.ID`.
**CHECK:** When joining `FeesCollection_Details.Term_ID` (or `LateFeeMaster.TermId`, `BusFeeStrucure.Term_ID`, `HostelFeeStructure.Term_ID`, `FeeStructureMonth.Term_ID`) to a "term" master, the master MUST be `TermMaster`. Regex: `r'(?i)join\s+(dbo\.)?ExamTermMaster'` must NOT appear in any fee-table query.
**SEVERITY:** HIGH

### FEE-019
**RULE:** `FeesCollection.Receipt_Amt` is the column to use for the bill total of a fee receipt (not `Amount` and not `Amt`).
**EVIDENCE:** `sp_FeesCollection_SelectRecord` (`FC.Receipt_Amt`); `sp_SelectFeeCollectionList` (`FC.Receipt_Amt`); `SP_GetChequeBounceHistory` (`Receipt_Amt`); `sp_ProspectusFeesCollection` (`PFC.Receipt_Amt`); `GetStudentProspectusFeeCollectionReceipt` (`FC.Receipt_Amt` aliased `Total_ReceiptAmt`).
**CHECK:** When the intent is "fee receipt total", use `Receipt_Amt` on the `FeesCollection` (or `ProspectusFeesCollection`, `DonationFeesCollection`) row. Regex: `r'(?i)receipt_amt'` must appear in the SELECT for receipt-total intents.
**SEVERITY:** MEDIUM

### FEE-020
**RULE:** The sophisticated TC-issued-mid-term filter `NOT (IsTCIssued=1 AND cast(TCIssuedDate as date) < @tStartDate)` must be applied when the report wants to retain students whose TC was issued AFTER the term began (they still owe for the term that already started).
**EVIDENCE:** `Sp_Chalo_ReportFeeOustandingCategoryWise` — `set @tStartDate = (select StartingDate FROM TermMaster where ID = @TermID); insert into @TCIssuedStudents select sad.StudentID from StudentAcademicDetail sad where ... and sad.IsTCIssued = 1 and cast(sad.TCIssuedDate as date) < @tStartDate` and then `fisd.Student_ID not in (select * from @TCIssuedStudents)`. `GetCompanywiseFeesOutstanding` — `((SAM.IsTCIssued = 1 AND SAM.TCIssuedDate >=FSM.FeeApplicableDate) OR SAM.IsTCIssued = 0)`.
**CHECK:** For per-term outstanding with mid-term-TC retention, the SP must NOT exclude IsTCIssued=1 unconditionally; it must compare TCIssuedDate to the term-start.
**SEVERITY:** MEDIUM

### FEE-021
**RULE:** The `Sp_Chalo_ReportFeePendencySMSStudentMonth` outstanding predicate is `HAVING SUM(Amount-ISNULL(Concession_Amt,0)) > SUM(Paid_Amt+Lien_Amount)` — the strict-greater-than is required so that fully-paid rows are excluded from pendency.
**EVIDENCE:** `Sp_Chalo_ReportFeePendencySMSStudentMonth` (`HAVING SUM(Amount-ISNULL(Concession_Amt,0)) > SUM(Paid_Amt+Lien_Amount)`).
**CHECK:** For "pendency" (not "summary") intents on `FeesInformationStudentDetail`, the query must have a HAVING clause with `>` (not `>=`) comparing demand to paid.
**SEVERITY:** MEDIUM

### FEE-022
**RULE:** `FeesInformationStudentDetail.IsDonation` must be filtered (=0 for academic, =1 for donation) — `GetFeePendingByFeesInformationStudentDetail` accepts `@Flag` to switch.
**EVIDENCE:** `GetFeePendingByFeesInformationStudentDetail` (`FI.IsDonation = @Flag`); `SP_AbstractFeesReport` (`(CS.IsDonation=0 OR CS.IsDonation is null)`); `GetFeePendingByCompanywise` (`IsDonation = @Flag`); `GetPreviousYearFeePendingByCompanywise` (`IsDonation = @Flag`); `GetAllStudentsWithPendingLateFees` (`FI.IsDonation = 0`).
**CHECK:** For an academic-fee query on `FeesInformationStudentDetail`, the WHERE must contain `IsDonation = 0` (or `IsDonation = @Flag`). Regex: `r'(?i)isdonation\s*=\s*0|isdonation\s*=\s*@flag'`.
**SEVERITY:** MEDIUM

---

## 2. MODULE: Examinations

### EXAM-001
**RULE:** `ExamTypeMaster.TermID` is an FK to `ExamTermMaster.ID` (the EXAM-term master). NEVER join `ExamTypeMaster.TermID` to `TermMaster.ID` (the fee-term master) — the two ID sequences are independent and produce wrong exam-type-to-term mappings.
**EVIDENCE:** `SP_Exam_GetExamType` (`left join [examtermmaster] As T On T.ID=ET.TermID`); `Sp_ExamEntryMarkDetails` (`INNER JOIN ExamTermMaster ET ON ET.ID = ETM.TermId`); `sp_Examination_MarkEntry_GetExamTypeList` (`INNER JOIN ExamTermMaster ET ON E.TermID = ET.ID`); `Sp_Chalo_LoadDataToGenerateRank` (`JOIN ExamTermMaster TM ON TM.ID=ET.TermID`); `SP_Exam_GetALLPublishedExamTerm` (`select termid from examtypemaster E JOIN ...`).
**CHECK:** When joining `ExamTypeMaster.TermID` to a term master, the master MUST be `ExamTermMaster`. Regex: `r'(?i)ExamTypeMaster\b.*\bTermID\b'` query must contain `r'(?i)join\s+(dbo\.)?ExamTermMaster\b'` and must NOT contain `r'(?i)join\s+(dbo\.)?TermMaster\b\s+\w+\s+on\s+\w+\.ID\s*=\s*\w+\.TermID'`.
**SEVERITY:** HIGH

### EXAM-002
**RULE:** `ExamTermMaster` soft-delete column is `Deleted` (NOT `IsDeleted`). However, NO live SP filters it (this is a known gap; the column exists in the schema but SPs do not apply it).
**EVIDENCE:** Schema (`Chalo Table Schema.txt`) confirms `ExamTermMaster` has `Deleted bit`. None of `SP_Exam_GetALLExamTerm`, `SP_Exam_GetExamTerm`, `SP_Exam_GetALLPublishedExamTerm`, `Get_TermList` apply a `Deleted=0` filter — they read ExamTermMaster raw by `BranchID` and `AcademicYearID` only. `StudentRemarksTypeMaster.deleted = 0` is also lowercase (verified in `SP_GetStudentRemarksForProgressReport`).
**CHECK:** If a query is authored to filter ExamTermMaster soft-delete, the column name MUST be `Deleted`, NOT `IsDeleted`. Regex: `r'(?i)ExamTermMaster.*\.IsDeleted|examtermmaster.*\.IsDeleted'` must NOT match. The correct predicate is `r'(?i)examtermmaster.*\.deleted\s*=\s*0'`.
**SEVERITY:** HIGH

### EXAM-003
**RULE:** `ExamTermMaster` date columns are `StartDate datetime` and `EndDate datetime` (NOT `StartingDate date` / `EndingDate date` as on `TermMaster`).
**EVIDENCE:** `SP_Exam_GetALLExamTerm` (`convert(varchar,StartDate,105) AS StartDate, convert(varchar,EndDate,105) AS EndDate FROM ExamTermMaster`); `SP_Exam_GetExamTerm` (same); `SP_Exam_GetALLPublishedExamTerm` (same).
**CHECK:** When reading `ExamTermMaster` dates, columns must be `StartDate`/`EndDate`. Regex: `r'(?i)examtermmaster'` must NOT be paired with `r'(?i)startingdate|endingdate'` columns.
**SEVERITY:** HIGH

### EXAM-004
**RULE:** The SP `Get_TermList` reads from `ExamTermMaster` despite its generic name ("Get Term List"). Calling it for a fee-term question returns exam-term IDs that won't match fee-demand rows. **Text-to-SQL MUST NEVER call or emulate `Get_TermList` for fee intents.**
**EVIDENCE:** `Get_TermList` body — `SELECT etm.id, etm.Name AS Termname FROM dbo.ExamTermMaster etm WHERE etm.AcademicYearID = @AcademicYear AND etm.BranchID = @BranchID`.
**CHECK:** For fee-term intents, the query must read `TermMaster` (not `Get_TermList` pattern that reads `ExamTermMaster`). The presence of `ExamTermMaster` in a fee query is a violation.
**SEVERITY:** HIGH

### EXAM-005
**RULE:** Exam-term ID values live in `ExamTermMaster.ID`. `ExamConfigurationExamTypeDetails.TermID`, `StudentTermRemarks.TermID`, `StudentTermAttendance.TermID`, `ClassTermDetails.TermID`, `ClassTermMasterMapping.TermID` all reference `ExamTermMaster.ID`. NEVER join these to `TermMaster.ID`.
**EVIDENCE:** `SP_Exam_GetALLPublishedExamTerm` (`select termid from examtypemaster E JOIN StudentMarkEntrySettings ES ON ExamTypeID=E.ID where PublishStatus=1`); `Sp_ExamEntryMarkDetails` (`INNER JOIN ExamTermMaster ET ON ET.ID = ETM.TermId`). `ExamTypeMaster.TermID → ExamTermMaster.ID` is the canonical exam-term FK chain.
**CHECK:** When the query touches `ExamTypeMaster`, `ExamConfigurationExamTypeDetails`, `StudentTermRemarks`, `StudentTermAttendance`, `ClassTermDetails`, or `ClassTermMasterMapping`, any join to a "term master" must use `ExamTermMaster`, never `TermMaster`.
**SEVERITY:** HIGH

---

## 3. MODULE: Students

### STUD-001
**RULE:** `Student_Master` has NO `ClassID`, `SectionID`, or `AcademicYearID` columns. To read a student's CURRENT class/section/academic year, the query MUST join `StudentAcademicDetail` on `StudentAcademicDetail.StudentID = Student_Master.ID` and read `StudentAcademicDetail.ClassID / SectionID / AcademicYearID`. (`Student_Master.StudentClass_ID` exists but is the ADMITTED class snapshot, not current.)
**EVIDENCE:** `sp_StudentMaster_SelectRecord` — `SELECT ..., sad.ClassID CurrentClass_ID, sad.SectionID CurrentSection_ID, ..., sm.StudentClass_ID, ... FROM dbo.Student_Master sm join StudentAcademicDetail sad on sad.StudentID=sm.ID ... and sad.academicyearID=@AcademicyearID`. Every fee/attendance/exam SP joins `StudentAcademicDetail` to get class/section — none reads `Student_Master.ClassID` (the column does not exist). A grep for `Student_Master.ClassID|Student_Master.SectionID|Student_Master.AcademicYearID` returns ZERO matches across all 1,092 SPs.
**CHECK:** A query touching `Student_Master` for class/section/academic-year data MUST join `StudentAcademicDetail`. Regex: `r'(?i)Student_Master\s+\w+\s+.*\bClassID\b'` without an accompanying `r'(?i)StudentAcademicDetail'` is a violation. Direct column references `Student_Master.ClassID|Student_Master.SectionID|Student_Master.AcademicYearID` (or `sm.ClassID|sm.SectionID|sm.AcademicYearID` where `sm` aliases `Student_Master`) must NOT appear.
**SEVERITY:** HIGH

### STUD-002
**RULE:** `StudentAcademicDetail.IsActive` semantics: `1 = active`, `0 = inactive (e.g. graduated/left)`. `SP_Fees_RPT_GetAcademicFessOutstanding` exposes `@StatusId` with three values: `0 = IsActive 0`, `1 = IsActive 1`, `2 = either`.
**EVIDENCE:** `SP_Fees_RPT_GetAcademicFessOutstanding` — `((@StatusId = 0 and SAD.IsActive = 0) or (@StatusId = 1 and SAD.IsActive = 1) or @StatusId = 2)`; `SP_Fees_RPT_GetFessSummary` (same).
**CHECK:** When filtering student-active status, use `IsActive = 1` for active, `IsActive = 0` for inactive. The "either" branch must explicitly use a `@StatusId = 2` OR list.
**SEVERITY:** MEDIUM

### STUD-003
**RULE:** `StudentAcademicDetail.IsPromoted` and `StudentAcademicDetail.IsNewAdmission` are flags used to switch fee applicability and exam/class assignment. `FeeStructureDetail.Applicable_For = 1` means new admissions, `= 2` means old students, `= 3` means both.
**EVIDENCE:** `Sp_Chalo_GetStudentApplicableConcession` — `AND (FSD.Applicable_For = 3 OR (FSD.Applicable_For =1 AND SAD.IsNewAdmission=1) OR (FSD.Applicable_For =2 AND (SAD.IsNewAdmission!=1 OR SAD.IsNewAdmission IS NULL)))`. `Sp_Chalo_GetStudentApplicableFees` (same); `GetCompanywiseFeesOutstanding` (`AND (FSD.Applicable_For = 3 OR (FSD.Applicable_For=1 AND SAM.IsNewAdmission =1) OR (FSD.Applicable_For=2 AND SAM.IsNewAdmission =0))`); `sp_NonPromoted_StudentList`; `sp_StudentMaster_StudentPromotionListByClassAndSection`.
**CHECK:** When applying `FeeStructureDetail.Applicable_For`, the query must branch on `StudentAcademicDetail.IsNewAdmission` (=1 for new, !=1 OR NULL for old). Regex: `r'(?i)applicable_for\s*=\s*1.*\bisnewadmission\s*=\s*1|applicable_for\s*=\s*2.*\bisnewadmission'`.
**SEVERITY:** MEDIUM

### STUD-004
**RULE:** Current academic-year resolution MUST go through `Branch_Academic_Details` (taking the row with `Branch_Id = @BranchID` and the highest `DisplayOrder`, OR a `Name`-match across branches). NEVER use `YEAR(GETDATE())` — the academic year may start in April/June and span two calendar years.
**EVIDENCE:** `sp_UserMaster_GetAcademicYearByBranch` — `SELECT bad.Id, bad.Name, ... FROM dbo.Branch_Academic_Details bad WHERE bad.Branch_Id = @branchID order by bad.DisplayOrder desc`. `GetPreviousAcademicYearId` — `select Id from branch_Academic_Details where start_Date < (@Academic_StartingYear) and branch_id=@BranchID`. `SP_DashboardBranchwiseStatistics` — `insert into @academicYears select bad.Id from Branch_Academic_Details bad where bad.Name = (select bad1.Name from Branch_Academic_Details bad1 where bad1.Id = @AcademicYearID) and bad.Branch_Id in (select * from @branches)`. A grep for `YEAR(GETDATE())|YEAR(getdate())` returns ZERO matches across all 1,092 SPs.
**CHECK:** Academic-year resolution queries MUST reference `Branch_Academic_Details`. Regex: `r'(?i)Branch_Academic_Details'` must appear; `r'(?i)year\s*\(\s*getdate\s*\(\s*\)\s*\)'` must NOT appear.
**SEVERITY:** HIGH

### STUD-005
**RULE:** When listing students for the current academic year, filter `StudentAcademicDetail.AcademicYearID = @AcademicYearID` AND `StudentAcademicDetail.BranchID = @BranchID` (NOT `Student_Master.AcademicYearID` — that column does not exist on Student_Master).
**EVIDENCE:** Every canonical student-listing SP (`sp_TransportStudentDetails`, `sp_StudentMaster_SelectRecord`, `Sp_Chalo_ReportFeeOustanding`, all exam SPs) applies `SAD.AcademicYearID = @AcademicYearID`.
**CHECK:** `r'(?i)Student_Master.*AcademicYearID|sm\.AcademicYearID|SM\.AcademicYearID'` must NOT appear; `r'(?i)StudentAcademicDetail.*AcademicYearID\s*=\s*@AcademicYearID|sad\.AcademicYearID\s*=\s*@AcademicYearID'` must appear.
**SEVERITY:** HIGH

### STUD-006
**RULE:** Student full-name concatenation follows the convention `FirstName + ' ' + ISNULL(MiddleName,'') + ' ' + ISNULL(LastName,'')` (Student_Master columns are `FirstName`, `MiddleName`, `LastName` — NOT `Student_FirstName` which is the Staff column).
**EVIDENCE:** `Sp_Chalo_ReportFeeOustanding` (`SM.FirstName+' '+ISNULL(SM.MiddleName,'')+' '+ISNULL(SM.LastName,'') Student_Name`); `SP_Fees_RPT_GetAcademicFessOutstanding` (`isnull(SM.FirstName,'')+''+isnull(SM.MiddleName,'')+' '+isnull(SM.LastName,'') Student_Name`); `Sp_Chalo_ReportFeePendencyStudent` (same); `sp_StudentMaster_SelectRecord` (`sm.FirstName + ' ' + isnull(sm.MiddleName,'') +' ' + isnull(sm.LastName,'') StudentName`).
**CHECK:** When concatenating a student name, the columns must be `FirstName|MiddleName|LastName` (NOT `Staff_FirstName|Staff_MiddleName|Staff_LastName` which belong to Staff_Master). Regex: `r'(?i)Student_Master.*FirstName|sm\.FirstName'` for student; `r'(?i)Staff_FirstName'` for staff.
**SEVERITY:** MEDIUM

---

## 4. MODULE: Staff

### STAFF-001
**RULE:** `StaffDepartmentMaster` is the LIVE department table for staff. `Department_Master` is DEPRECATED (only referenced by the deprecated `PurchaseRequest` table; zero staff SPs use it). Always read from `StaffDepartmentMaster`.
**EVIDENCE:** `sp_StaffDepartment_SelectAll` (`SELECT Id, Name, Description FROM dbo.StaffDepartmentMaster WHERE BranchID = @BranchID AND IsDeleted = 0`); `sp_StaffDepartment_SelectRecord` (same); `sp_StaffDepartmentMapping_SelectAll` (`INNER JOIN dbo.StaffDepartmentMaster d ON m.DepartmentID = d.Id`). A grep for `Department_Master` (exact word boundary) returns ZERO matches across all 1,092 SPs.
**CHECK:** Staff-department queries MUST use `StaffDepartmentMaster`, not `Department_Master`. Regex: `r'(?i)\bDepartment_Master\b'` must NOT appear in any staff query.
**SEVERITY:** HIGH

### STAFF-002
**RULE:** `Staff_Master` naming columns are `Staff_FirstName`, `Staff_MiddleName`, `Staff_LastName` (NOT `FirstName`, which is the `Student_Master` column). The PK is `Staff_ID` (NOT `ID`).
**EVIDENCE:** `Get_StaffNameByID` (`SELECT sam.Staff_ID, sm.Staff_FirstName, sm.Staff_MiddleName, sm.Staff_LastName FROM dbo.SubjectAllocation_Master sam JOIN dbo.Staff_Master sm ON sam.Staff_ID = sm.Staff_ID`); `GetStaffDataByID` (`SELECT sm.Staff_ID, sm.Staff_FirstName, sm.Staff_MiddleName, sm.Staff_LastName, ... FROM Staff_Master sm`); `Sp_SelectStaffNameByRoleID` (`ISNULL(SM.Staff_FirstName,'') + ' ' + ISNULL(SM.Staff_MiddleName,'') + ' ' +ISNULL(SM.Staff_LastName,'') StaffName`).
**CHECK:** For Staff_Master name columns, use `Staff_FirstName|Staff_MiddleName|Staff_LastName` and PK `Staff_ID`. Regex: `r'(?i)Staff_Master.*\.FirstName|Staff_Master.*\.MiddleName|Staff_Master.*\.LastName'` (without `Staff_` prefix) is a violation. `r'(?i)Staff_Master.*\bStaff_ID\b|Staff_Master.*\bStaff_FirstName\b'` must appear.
**SEVERITY:** HIGH

### STAFF-003
**RULE:** Active staff filter is `Staff_Master.StaffStatus_ID = 1`.
**EVIDENCE:** `Sp_Chalo_GetStaffStrengthForDashboard` (`where StaffStatus_ID=1 and SM.BranchID in (select * from @branches)`); `Sp_Chalo_GetStaffAttendanceForDashboard` (same); `sp_CommonMaster_GetCodeByStaffName` (`sm.StaffStatus_ID = 1 AND sm.Staff_ID = @StaffID`); `Sp_SelectStaffNameByRoleID` (`SM.StaffStatus_ID = 1`). 44 SPs reference `StaffStatus_ID`.
**CHECK:** When filtering active staff, the WHERE must contain `StaffStatus_ID = 1`. Regex: `r'(?i)staffstatus_id\s*=\s*1'`.
**SEVERITY:** HIGH

### STAFF-004
**RULE:** `Staff_Master.AcademicYearID` column exists and is used in some SPs (mostly as a denormalised current-year marker), but the canonical staff-class/subject scoping comes via `SubjectAllocation_Master.AcademicYearID`. The `StaffType_ID` filter selects teaching/non-teaching.
**EVIDENCE:** `GetStaffDataByID` (`sm.AcademicYearID=@Academicyear_Id`); `Sp_GetStaffSalaryByStaffType` (`(@StaffTypeID = 0 OR sm.StaffType_ID = @StaffTypeID)`); `Sp_Chalo_GetStaffStrengthForDashboard` (`JOIN StaffType_Master CM ON CM.ID=SM.StaffType_ID`).
**CHECK:** For staff scoping, prefer `SubjectAllocation_Master.AcademicYearID` (matches actual year); fall back to `Staff_Master.AcademicYearID` only if the SP doesn't allocate subjects.
**SEVERITY:** MEDIUM

---

## 5. MODULE: Admissions

### ADM-001
**RULE:** `ProspectusFeesCollection` is the prospectus/applicant fee receipt table. It links applicants via `ApplicationNo` (string), NOT via `Student_ID` (the column does NOT exist on `ProspectusFeesCollection`). Joining `ProspectusFeesCollection.Student_ID` is wrong.
**EVIDENCE:** `GetStudentProspectusFeeCollectionReceipt` — selects `FC.ApplicationNo, FC.FatherContactNo, FC.FatherName, FC.Student_Name` from `ProspectusFeesCollection FC` (NO `Student_ID` column referenced). `sp_ProspectusFeesCollection` (same — only `PFC.Student_Name`, `PFC.Mobile`, `PFC.ApplicationNo`). `sp_ProspectusFeesCollectionList_Search` (same). `sp_ProspectusFeeCollectionReport` (uses `PFC.ApplicationNo`, `PFC.FatherName`, `PFC.Student_Name`). A grep for `ProspectusFeesCollection\.Student_ID` returns ZERO matches.
**CHECK:** When reading `ProspectusFeesCollection`, do NOT reference a `Student_ID` column. Use `ApplicationNo` for applicant linkage and `Student_Name`/`FatherName`/`FatherContactNo` for human-readable identity. Regex: `r'(?i)ProspectusFeesCollection.*\.Student_ID|PFC\.Student_ID'` must NOT match.
**SEVERITY:** HIGH

### ADM-002
**RULE:** `EnquiryMaster` is DEPRECATED. Use `GeneralCallRegister` for all admission-enquiry queries. The `CallStatus_ID` FK on `GeneralCallRegister` joins `Enquiry_Status_Master` (NOT `CallStatus_Master`).
**EVIDENCE:** `sp_EnquiryListReport` (`FROM dbo.GeneralCallRegister gcr LEFT JOIN dbo.Enquiry_Status_Master esm ON gcr.CallStatus_ID = esm.ID`); `sp_GeneralCallRegister_SearchCallRegisterData` (same); `sp_GeneralCallRegister_SelectRecord` (same); `SP_SearchEnquiryListData` (`from GeneralCallRegister gcr JOIN dbo.Enquiry_Status_Master esm ON gcr.CallStatus_ID = esm.ID`); `Sp_ReportEnquiryAndApplicationStatus` (`FROM GeneralCallRegister GC JOIN Enquiry_Status_Master Es on Es.ID=Gc.CallStatus_ID`). A grep for `EnquiryMaster` (exact table) returns ZERO matches across all 1,092 SPs.
**CHECK:** Blocklist `EnquiryMaster` from FROM/JOIN. Regex: `r'(?i)\bEnquiryMaster\b'` must NOT appear in any FROM or JOIN. `r'(?i)GeneralCallRegister'` must appear in any enquiry-intent query.
**SEVERITY:** HIGH

### ADM-003
**RULE:** Admission/enquiry module SPs use CTE-form branch scoping with `UserAccountRoleDetails` and `BlockStaffDetail` (for block-level filtering). The pattern is: `INNER JOIN @BlockStaffIDs bsi ON gcr.HandledBy_ID = bsi.ID` where `@BlockStaffIDs` is populated from `BlockStaffDetail bcd WHERE bcd.BranchID = @BranchID AND bcd.Block_ID IN (SELECT Value from dbo.SplitDelimited(@BlockIDs, ','))`.
**EVIDENCE:** `sp_GeneralCallRegister_SearchCallRegisterData` (`DECLARE @BlockStaffIDs AS TABLE(ID bigint); INSERT INTO @BlockStaffIDs SELECT DISTINCT Staff_ID from dbo.BlockStaffDetail bcd WHERE bcd.BranchID = @BranchID AND bcd.Block_ID IN (SELECT Value from dbo.SplitDelimited(@BlockIDs, ',')); ... INNER JOIN @BlockStaffIDs bsi ON gcr.HandledBy_ID = bsi.ID`); `sp_CallFollowUp_SelectAllByBlock` (same pattern).
**CHECK:** For block-aware enquiry queries, the SP must populate a `@BlockStaffIDs` table from `BlockStaffDetail` and INNER JOIN on it. Regex: `r'(?i)BlockStaffDetail'` AND `r'(?i)@BlockStaffIDs'` AND `r'(?i)SplitDelimited\s*\(\s*@BlockIDs'`.
**SEVERITY:** MEDIUM

### ADM-004
**RULE:** `ProspectusFeesCollection` collection queries MUST filter `(ChequeStatus_ID = 1 OR ChequeStatus_ID = 2)` for "active receipts" or `ChequeStatus_ID <> 4` for "non-cancelled" (the report variant).
**EVIDENCE:** `sp_ProspectusFeesCollection` (`(PFC.ChequeStatus_ID =1 or PFC.ChequeStatus_ID=2)`); `sp_ProspectusFeesCollectionList_Search` (same); `sp_ProspectusFeeCollectionReport` (`PFC.ChequeStatus_ID <> 4`); `sp_ProspectusFeesCollectionDetails_SelectAll` (`PFC.ChequeStatus_ID=2` — Cleared only).
**CHECK:** Prospectus fee-collection queries MUST filter ChequeStatus_ID using one of the canonical predicates (NOT unfiltered). Regex: `r'(?i)chequestatus_id\s*=\s*1\s*or\s*PFC\.chequestatus_id\s*=\s*2|chequestatus_id\s*<>\s*4'`.
**SEVERITY:** HIGH

### ADM-005
**RULE:** `ApplicationEntry` (the admission application table) tracks `ApplicationStatus_ID` joined to `ApplicationStatus_Master`. The status names are literal strings: 'Application Submitted', 'Called For Interview', 'Selection letter Sent', 'Interview Completed', 'Admitted', 'Shortlisted', 'Rejected'.
**EVIDENCE:** `Sp_ReportEnquiryAndApplicationStatus` — `CAST(SUM(CASE WHEN T1.ApplicationStatusName IN ('Application Submitted','Called For Interview','Selection letter Sent','Interview Completed','Admitted','Shortlisted','Rejected') THEN 1 ELSE 0 END) as bigint) Total_Application_Received`.
**CHECK:** When computing application-status counts, the CASE must use the canonical status-name literals above. Regex: `r'(?i)Application Submitted.*Called For Interview.*Selection letter Sent.*Interview Completed.*Admitted.*Shortlisted.*Rejected'`.
**SEVERITY:** MEDIUM

---

## 6. MODULE: Transport

### TRANS-001
**RULE:** The transport fee-structure table is `BusFeeStrucure` — MISSPELLED (missing the second 't'). All 32 SPs that reference the bus-fee table use the misspelled form; ZERO use `BusFeeStructure`. Text-to-SQL MUST use the misspelled form to avoid a "table not found" error.
**EVIDENCE:** `Sp_Chalo_GetStudentTransportDetails` (`LEFT JOIN BusFeeStrucure BS ON ...`); `Sp_Chalo_ReportFeeOustandingBusFeeTermwise` (`JOIN BusFeeStrucure BS ON ...`); `Sp_Fees_RPT_BusFeeOustanding` (`JOIN BusFeeStrucure BS ON ...`); `Sp_Fees_RPT_BusFeeOustandingByClassSection` (`JOIN BusFeeStrucure BS ON ...`); `Sp_Fees_RPT_TransportFeeList` (`JOIN BusFeeStrucure BS ON ...`); `sp_TransportFeeNonPaidReport` (`from BusFeeStrucure BFS`); `Sp_Chalo_GetStudentApplicableFees` (`JOIN dbo.BusFeeStrucure FS`); `Sp_Chalo_GetStudentApplicableConcession` (`JOIN dbo.BusFeeStrucure FS`); `sp_BoardingPointMaster_SearchBoardingPointData` (`inner join BoardingMonthDetails B`); `Sp_GetStudentRouteDetails` (`FROM BusFeeStrucure bfs`). 32 SP files mention `BusFeeStrucure`; ZERO mention `BusFeeStructure`.
**CHECK:** FROM/JOIN on the bus-fee table must use the literal `BusFeeStrucure`. Regex: `r'(?i)\bBusFeeStrucure\b'` must appear for bus-fee intents; `r'(?i)\bBusFeeStructure\b'` must NEVER appear.
**SEVERITY:** HIGH

### TRANS-002
**RULE:** `BusFeeStrucure.Term_ID` references `TermMaster.ID` (the fee-term master, NOT `ExamTermMaster.ID`).
**EVIDENCE:** `Sp_Chalo_GetStudentTransportDetails` (`LEFT JOIN TermMaster T ON T.AcademicYearID=@AcademicID AND T.BranchID=@BranchID AND M.StartDate>=T.StartingDate AND M.StartDate<=T.EndingDate AND BS.Term_ID = T.ID`); `Sp_Chalo_GetStudentApplicableFees` (`JOIN TermMaster tm on tm.ID=fs.Term_ID` where `fs` is `BusFeeStrucure`).
**CHECK:** A query reading `BusFeeStrucure.Term_ID` joining to a "term master" must use `TermMaster`. Regex: `r'(?i)BusFeeStrucure'` AND `r'(?i)join\s+(dbo\.)?TermMaster'` AND NOT `r'(?i)join\s+(dbo\.)?ExamTermMaster'`.
**SEVERITY:** HIGH

### TRANS-003
**RULE:** `BusFeeStrucure.TripID` is an FK to `Transport_TripDetails.ID` (a real row in the trip-details table). It is NOT an enum (1/2 = onward/return). Joining to enum literals is wrong.
**EVIDENCE:** `Sp_GetStudentRouteDetails` (`LEFT JOIN Transport_TripDetails td on td.RouteID = rm.ID and td.ID = bfs.TripID`). The query resolves the live trip row to get `TransportSessionID`, `TransportStartTime`, `TransportEndTime`.
**CHECK:** When the query reads `BusFeeStrucure.TripID`, it MUST join `Transport_TripDetails` on `td.ID = bfs.TripID`. Regex: `r'(?i)Transport_TripDetails'` AND `r'(?i)\.TripID\s*=\s*Transport_TripDetails\.ID|Transport_TripDetails\.ID\s*=\s*\w+\.TripID'`. Enum-style `WHERE TripID = 1 OR TripID = 2` is a violation.
**SEVERITY:** HIGH

### TRANS-004
**RULE:** `BoardingPoint_Master.Amount` is the boarding-point charge column. The boarding-month variant is `BoardingMonthDetails.Amount` keyed by `Boarding_ID` and `Month_No`.
**EVIDENCE:** `sp_BoardingPointMaster_SearchBoardingPointData` — `select A.Id as ID, A.Name, A.Description from BoardingPoint_Master A where A.BranchID = @BranchID; select B.ID, B.Boarding_ID, B.Month_Name, convert(int,B.Month_No) as MonthNo, B.Amount from BoardingPoint_Master A inner join BoardingMonthDetails B on A.Id=B.Boarding_ID where A.BranchID = @BranchID`.
**CHECK:** For boarding-point charge queries, the column is `Amount` on `BoardingPoint_Master` (or `BoardingMonthDetails` for the per-month variant). Regex: `r'(?i)BoardingPoint_Master.*\.Amount'` or `r'(?i)BoardingMonthDetails.*\.Amount'`.
**SEVERITY:** MEDIUM

### TRANS-005
**RULE:** Bus-student filtering uses `StudentAcademicDetail.TransportRequired = 'True'` (string) — NOT `= 1` (bit) and NOT `= '1'`.
**EVIDENCE:** `Sp_Chalo_GetStudentTransportDetails` (`AND SAD.TransportRequired='True'`); `sp_TransportStudentDetails` (`And SAM.TransportRequired = 1` — note: this is one SP using `= 1`, an inconsistency — see INCONSISTENT-006); `Sp_Chalo_GetStudentApplicableFees` (`AND SAD.TransportRequired=1` — also inconsistent). The schema audit confirms `TransportRequired` is `nvarchar` so the canonical form is `'True'`.
**CHECK:** For "students who use transport" intent, the WHERE must contain `TransportRequired = 'True'` (canonical) OR `TransportRequired = 1` (also accepted because some SPs use it). Regex: `r'(?i)transportrequired\s*=\s*[\'\"]?true[\'\"]?|transportrequired\s*=\s*1'`.
**SEVERITY:** MEDIUM

### TRANS-006
**RULE:** `BusFeeStrucure.Route_ID` joins to `Route_Master.ID`; `BusFeeStrucure.BoardingPoint_ID` joins to `BoardingPoint_Master.ID`.
**EVIDENCE:** `Sp_Chalo_ReportFeeOustandingBusFeeTermwise` (`JOIN Route_Master RM ON RM.ID=BS.Route_ID`); `Sp_Fees_RPT_BusFeeOustanding` (`JOIN Route_Master RM ON RM.ID=BS.Route_ID JOIN BoardingPoint_Master As BPM ON BPM.ID=BS.BoardingPoint_ID`); `Sp_GetStudentRouteDetails` (`JOIN Route_Master rm on bfs.Route_ID = rm.ID`).
**CHECK:** When reading bus-fee routes/boarding points, join `Route_Master` on `Route_ID` and `BoardingPoint_Master` on `BoardingPoint_ID`. Regex: `r'(?i)Route_Master.*\.ID\s*=\s*\w+\.Route_ID|BoardingPoint_Master.*\.ID\s*=\s*\w+\.BoardingPoint_ID'`.
**SEVERITY:** MEDIUM

---

## 7. MODULE: Inventory

### INV-001
**RULE:** `IPurchaseRequest` is the LIVE purchase-request table. `PurchaseRequest` (without the `I` prefix) is DEPRECATED (it has a misspelled `ApprovaStatus` column and no live SP references it). Use `IPurchaseRequest` for all purchase queries.
**EVIDENCE:** `SP_InPurchaseRequest_SelectAll` (`From IPurchaseRequest A INNER JOIN InventorySupplierMaster B ON A.SupplierID = b.ID WHERE A.BranchID = @BranchID and A.AcademicYearID = @AcademicYearID`); `SP_InPurchaseRequest_SelectRecord` (same); `SP_PurchaseRequest` (`FROM IPurchaseRequest ipr`); `SP_PurchaseRequestReceipt` (`FROM IPurchaseRequest ipr`); `SP_InventoryStockReport` (`JOIN IPurchaseRequest ipr ON pid.Product_ItemID = ipr.ID`); `SP_GoodsIssueReceipt`, `SP_GoodsReceiptInfo_`, `sp_IGoodsReceipt_Search`, `sp_IGoodsReceipt_SelectAll`, `sp_IGoodsReceipt_SelectRecord`. A grep for `\bPurchaseRequest\b` (exact table, no prefix) returns ZERO matches in FROM clauses.
**CHECK:** Purchase queries MUST use `IPurchaseRequest`, not `PurchaseRequest`. Regex: `r'(?i)\bIPurchaseRequest\b'` must appear; `r'(?i)from\s+(dbo\.)?\bPurchaseRequest\b'` (without `I` prefix) must NEVER appear.
**SEVERITY:** HIGH

### INV-002
**RULE:** `InventoryItem_Master.StockInHand` is the materialised stock-on-hand column. The dynamic stock formula (in `SP_InventoryStockReport`) is `Opening_Stock + ReceivedQuantity - (IssuedQty_Direct + IssuedQty_Fees) - PurchaseReturn`.
**EVIDENCE:** `sp_InItemMaster_SelectAll` (`A.StockInHand`); `SP_InventoryStockReport` (`(ISNULL(os.Opening_Stock, 0) + isnull(pid.ReceivedQuantity, 0) - (ISNULL(ired.[Issued Qty(Direct)], 0) + ISNULL(ired.[Issued Qty(Fees)], 0))- ISNULL(prReturn.TotalReturnedQty,0) ) as StockInHand`).
**CHECK:** For stock-on-hand intents, prefer the dynamic formula; the `InventoryItem_Master.StockInHand` column is a denormalised snapshot.
**SEVERITY:** MEDIUM

### INV-003
**RULE:** `InventoryItem_Master.ItemStatus` takes string values `'Active'` / `'Inactive'`. NOT 0/1.
**EVIDENCE:** `sp_InItemMaster_SelectAll` (selects `A.ItemStatus` as a string); schema audit confirms `ItemStatus nvarchar`.
**CHECK:** When filtering inventory-item status, use string literals: `ItemStatus = 'Active'`. Regex: `r'(?i)itemstatus\s*=\s*[\'\"]active[\'\"]|itemstatus\s*=\s*[\'\"]inactive[\'\"]'`.
**SEVERITY:** MEDIUM

### INV-004
**RULE:** `IPurchaseReturnRequest.IsDeleted = 0` AND `IPurchaseReturnRequest.ApprovalStatusID = 2` are BOTH required to count "approved, non-deleted" purchase returns (and similarly for `SalesReturnRequest`).
**EVIDENCE:** `SP_InventoryStockReport` (`WHERE pr.IsDeleted = 0 AND pr.ApprovalStatusID = 2 AND prd.AcademicYearID = @AcademicYearID AND prd.BranchID = @BranchID` for `IPurchaseReturnRequest`; `WHERE sr.IsDeleted = 0 AND sr.ApprovalStatusID = 2 AND sr.BranchID = @BranchID AND sr.AcademicYearID = @AcademicYearID` for `SalesReturnRequest`).
**CHECK:** Purchase-return / sales-return inclusion in stock must filter `IsDeleted = 0 AND ApprovalStatusID = 2`. Regex: `r'(?i)IsDeleted\s*=\s*0.*ApprovalStatusID\s*=\s*2|ApprovalStatusID\s*=\s*2.*IsDeleted\s*=\s*0'`.
**SEVERITY:** MEDIUM

### INV-005
**RULE:** Approval-status workflow values: `ApprovalStatusID = 1` (Pending), `ApprovalStatusID = 2` (Approved), `ApprovalStatusID = 3` (Rejected). `WorkFlow_Details.ApprovalStatus = 1` means "approved at this stage".
**EVIDENCE:** `Sp_GetAllSalesReturnRequestforApproval` (`CASE WHEN sr.ApprovalStatusID=1 THEN 'Pending' WHEN sr.ApprovalStatusID=2 THEN 'Approved' WHEN sr.ApprovalStatusID=3 THEN 'Rejected' END`).
**CHECK:** When interpreting ApprovalStatusID, use the literal mapping above.
**SEVERITY:** MEDIUM

---

## 8. MODULE: Payroll

### PAY-001
**RULE:** `GenerateSalaryEmployee_Details` has DUAL foreign keys — both `HeaderID` (→ `GenerateSalaryEmployee_Master.ID`) AND `MasterID` (→ `GenerateSalary_Master.ID`). Both must be used when joining to traverse the full denormalised hierarchy: `GenerateSalaryEmployee_Details.HeaderID → GenerateSalaryEmployee_Master.ID; GenerateSalaryEmployee_Master.HeaderID → GenerateSalary_Master.ID; GenerateSalaryEmployee_Details.MasterID → GenerateSalary_Master.ID` (denormalised shortcut).
**EVIDENCE:** `sp_GenerateSalaryPayslip` — `FROM [GenerateSalaryEmployee_Details] ED JOIN [GenerateSalaryEmployee_Master] GSEM ON GSEM.ID = ED.HeaderID JOIN GenerateSalary_Master GSM ON GSM.ID = GSEM.HeaderID`. Also `SP_EmployeeSalaryReport` — `JOIN GenerateSalaryEmployee_Details gsed on gsed.EmployeeID=gsem.EmployeeID and gsm.ID=gsed.MasterID` (uses MasterID as the shortcut). `sp_GenerateSalaryPayslipNew` uses both joins.
**CHECK:** When the query touches `GenerateSalaryEmployee_Details`, it MUST either (a) join `GenerateSalaryEmployee_Details.HeaderID → GenerateSalaryEmployee_Master.ID` AND `GenerateSalaryEmployee_Master.HeaderID → GenerateSalary_Master.ID`, OR (b) use the denormalised `GenerateSalaryEmployee_Details.MasterID → GenerateSalary_Master.ID` shortcut. Both are valid; omitting both is a violation. Regex: `r'(?i)GenerateSalaryEmployee_Details'` must be accompanied by `r'(?i)HeaderID|MasterID'`.
**SEVERITY:** HIGH

### PAY-002
**RULE:** `GenerateSalaryEmployee_Details.TypeID` and `EmployeeSalaryDetails.TypeID`: `1 = Earning (allowance)`, `2 = Deduction`. The two SELECT branches in payslip SPs are gated by `WHERE ED.TypeID = 1` (earnings) and `WHERE ED.TypeID = 2` (deductions).
**EVIDENCE:** `sp_GenerateSalaryPayslip` — first detail SELECT `WHERE ED.TypeID = 1` (earnings), second `WHERE ED.TypeID = 2` (deductions). `sp_GenerateSalaryPayslipNew` (same). `SP_EmployeeSalaryReport` selects `gsed.TypeID` and joins `AllowanceDeductionMaster ad on ad.ID = gsed.ParticularsID`.
**CHECK:** For earnings rows: `TypeID = 1`. For deductions: `TypeID = 2`. Regex: `r'(?i)typeid\s*=\s*1'` for earnings, `r'(?i)typeid\s*=\s*2'` for deductions. A single query reading both must use CASE/UNION, not a single TypeID=1 OR 2 filter (unless explicitly listing both).
**SEVERITY:** HIGH

### PAY-003
**RULE:** `EmployeeMaster.StaffID` joins to `Staff_Master.Staff_ID` (NOT `Staff_Master.ID` — Staff_Master has `Staff_ID` as its PK column).
**EVIDENCE:** `sp_GenerateSalaryEmployee_MasterData` (`JOIN Staff_Master SM ON SM.Staff_ID = EM.StaffID`); `sp_GenerateSalaryPayslip` (`JOIN Staff_Master SM ON SM.Staff_ID = EM.StaffID`); `Sp_GetStaffSalaryByStaffType` (`JOIN Staff_Master sm on sm.Staff_ID = em.StaffID`).
**CHECK:** When joining `EmployeeMaster` to `Staff_Master`, the join key is `StaffID ↔ Staff_ID` (not `ID`). Regex: `r'(?i)Staff_Master.*Staff_ID\s*=\s*\w*EmployeeMaster.*StaffID|EmployeeMaster.*StaffID\s*=\s*\w*Staff_Master.*Staff_ID'`.
**SEVERITY:** HIGH

### PAY-004
**RULE:** `EmployeeSalaryDetails.EffectiveDate` selection MUST pick the row with the MAX EffectiveDate for the employee (salary structures change over time).
**EVIDENCE:** `sp_GetEmployeeMasterByStaffID` — `WHERE em.StaffID = @StaffID and esd.EffectiveDate = (SELECT MAX(esd2.EffectiveDate) FROM EmployeeSalaryDetails esd2 WHERE esd2.EmployeeID = esd.EmployeeID)`.
**CHECK:** When reading `EmployeeSalaryDetails`, the query MUST restrict to the latest EffectiveDate (sub-query or window function).
**SEVERITY:** MEDIUM

### PAY-005
**RULE:** `GenerateSalaryEmployee_Leave_Details` is denormalised: `MasterID` → `GenerateSalary_Master.ID` (same as PAY-001 pattern). The leave-count query aggregates by `LeaveTypeID` and uses cross-join multipliers to expand Entitled / Opening-Balance / Used-this-Month / Closing-Balance (4 rows per leave type).
**EVIDENCE:** `sp_GenerateSalaryPayslip` (`FROM [GenerateSalaryEmployee_Leave_Details] C JOIN GenerateSalary_Master D on C.MasterID = D.ID`).
**CHECK:** When reading `GenerateSalaryEmployee_Leave_Details`, join via `MasterID` to `GenerateSalary_Master.ID`.
**SEVERITY:** MEDIUM

---

## 9. MODULE: RBAC / Cross-cutting

### RBAC-001
**RULE:** The canonical branch-scoping pattern is: `IF (@IsSuperUser = 1) BEGIN SELECT ID FROM BranchMaster END ELSE BEGIN SELECT BranchID FROM UserAccountRoleDetails WHERE UserID=@UserId AND (@SelectedBranchId IS NULL OR BranchID=@SelectedBranchId) END`. The super-user check is `UserAccountMaster.IsSuperUser = 1` against the user ID.
**EVIDENCE:** `GetBranchByUserRole` (`IF @isSuper=1 BEGIN SELECT DISTINCT BM.ID, bm.Name FROM BranchMaster BM END ELSE BEGIN SELECT DISTINCT BM.ID, bm.Name FROM BranchMaster BM JOIN UserAccountRoleDetails UARD ON UARD.BranchID=BM.ID AND UARD.UserID=@Sid END`); `Sp_Chalo_GetUserDetailsForLogin` (same pattern with academic-year); `Sp_Chalo_GetStaffStrengthForDashboard` (`IF (@IsSuperUser = 1) BEGIN INSERT INTO @branches SELECT DISTINCT ID FROM BranchMaster END ELSE BEGIN INSERT INTO @branches SELECT DISTINCT BranchID FROM UserAccountRoleDetails uard WHERE uard.StaffID = @StaffId END`); `SP_DashboardBranchwiseStatistics` (same); `Sp_ExamEntryMarkDetails` (`IF EXISTS (SELECT 1 FROM UserAccountMaster WHERE StaffID = @StaffID AND (IsSuperUser = 1 OR IsBranchAdmin = 1)) BEGIN SET @IsSuperUserOrAdmin = 1 END`).
**CHECK:** For multi-branch queries, the SP MUST apply the IsSuperUser=1 branch-scoping pattern. Regex: `r'(?i)IsSuperUser\s*=\s*1'` AND (`r'(?i)BranchMaster'` OR `r'(?i)UserAccountRoleDetails'`).
**SEVERITY:** HIGH

### RBAC-002
**RULE:** The super-user grant subquery `SELECT ID FROM BranchMaster` does NOT filter by `IsDeleted` on `BranchMaster` itself (the known security gap noted in the schema audit). Text-to-SQL should NOT add `IsDeleted=0` to this subquery (the production code omits it; matching production is the rule).
**EVIDENCE:** `Sp_Chalo_GetStaffStrengthForDashboard`, `Sp_Chalo_GetStudentStrengthForDashboard`, `Sp_Chalo_GetStaffAttendanceForDashboard`, `SP_DashboardBranchwiseStatistics` all use `SELECT DISTINCT ID FROM BranchMaster` without `IsDeleted` filter when `@IsSuperUser=1`. The non-super path joins `UserAccountRoleDetails` on `BranchID` (also without `IsDeleted` filter on `BranchMaster`).
**CHECK:** The super-user branch subquery should be `SELECT ID FROM BranchMaster` (no IsDeleted filter). Adding `WHERE IsDeleted=0` to this subquery is a divergence from production.
**SEVERITY:** MEDIUM

### RBAC-003
**RULE:** Parameter convention: `@UserId` (camel-case) for the logged-in user, `@SelectedBranchId` for optional branch override, `@AcademicYearID` (Pascal-case) for the academic year, `@BranchID` for the branch.
**EVIDENCE:** `SP_DashboardBranchwiseStatistics` (`@BranchID [bigint] = 0, @AcademicYearID [bigint] = 0, @AttendanceDate date = NULL, @UserId bigint`); `Sp_Chalo_GetStaffStrengthForDashboard` (`@BranchID bigint, @TypeID bigint, @IsSuperUser bit, @StaffId bigint, @Flag bigint`); `Sp_ExamEntryMarkDetails` (`@BranchID bigint, @AcademicYearID bigint, @StaffID bigint`).
**CHECK:** Parameter names should match the convention. Regex: `r'@UserId|@SelectedBranchId|@AcademicYearID|@BranchID'`.
**SEVERITY:** MEDIUM

### RBAC-004
**RULE:** SENSITIVE TABLES BLOCKLIST — Text-to-SQL MUST NEVER generate SELECTs against: `StorageConfiguration` (contains UserName/Password/AccessToken), `WhatsAppConfiguration` (contains UserName/Password), `SMS_ConfigurationSettings`, `Student_Master_Draft` (unverified draft data), `PasswordRecovery`, payment-gateway tables (`GQPaymentTXNTable` is read-only internally but exposed via Pendency SP only for EMI flag), and any `*Password*` / `*Token*` / `*Secret*` table.
**EVIDENCE:** `Sp_StorageConfiguration_SelectAll` (selects `Sc.UserName, Sc.Password, Sc.AccessToken`); `GetAllWhatsAppConfiguration` (selects `UserName, Password`); `Sp_Chalo_GetUserDetailsForLogin` (selects `ScreenName,StorageTypeName,AccessToken,UserName,Password,FTPName,FileLocation, Port,BranchID From StorageConfiguration`); `Sp_Chalo_GetUserDetailsForLogin` reads `UserAccountMaster` including the `Password` column (the SP itself gates this behind a successful login, but Text-to-SQL must never expose it).
**CHECK:** Blocklist regex (case-insensitive): `r'(?i)\b(StorageConfiguration|WhatsAppConfiguration|SMS_ConfigurationSettings|Student_Master_Draft|PasswordRecovery|UserAccountMaster.*Password)\b'`. Any FROM or JOIN containing one of these is rejected.
**SEVERITY:** HIGH

### RBAC-005
**RULE:** `BranchMaster.Principal` is a denormalised principal-name column on `BranchMaster`. Use it only when explicitly asked for "school principal name" — do not join to Staff_Master for principal lookup (no SP does that; the column is the source of truth).
**EVIDENCE:** The schema audit confirms `BranchMaster.Principal` exists. (Grep across SPs for `BranchMaster.Principal` returns zero hits, meaning the column is rarely accessed via SPs — but it IS the principal column. EVIDENCE: none (no SP reads it; rule is "common-sense" with schema confirmation only).)
**CHECK:** For "principal of school X" intent, the column is `BranchMaster.Principal` (no join needed). Regex: `r'(?i)BranchMaster.*\.Principal'`.
**SEVERITY:** MEDIUM

### RBAC-006
**RULE:** `SubjectAllocation_Master` is the canonical teacher→subject→class→section mapping. Columns: `Staff_ID`, `Subject_ID`, `Class_ID`, `Section_ID`, `IsClassTeacher` (bit), `AcademicYearID`, `BranchID`. To find a class's teachers, join `SubjectAllocation_Master.Staff_ID` to `Staff_Master.Staff_ID`.
**EVIDENCE:** `Get_StaffNameByID` (`SELECT sam.Staff_ID, sm.Staff_FirstName, sm.Staff_MiddleName, sm.Staff_LastName FROM dbo.SubjectAllocation_Master sam JOIN dbo.Staff_Master sm ON sam.Staff_ID = sm.Staff_ID WHERE sam.Subject_ID = @SubjectID AND sam.Class_ID = @ClassID AND sam.Section_ID = @SectionID AND sam.AcademicYearID = @AcademicYearID AND sam.BranchID = @BranchID`); `Sp_ExamEntryMarkDetails` (uses `SubjectAllocation_Master.IsClassTeacher = 1` for class-teacher scoping); `sp_StaffPortal_GetClassSectionByStaffID` (same pattern).
**CHECK:** For "who teaches class X subject Y" or "which classes does teacher Z take" intents, the join table MUST be `SubjectAllocation_Master`, NOT a guess. Regex: `r'(?i)SubjectAllocation_Master'` AND `r'(?i)Staff_ID|Subject_ID|Class_ID|Section_ID'`.
**SEVERITY:** HIGH

### RBAC-007
**RULE:** `UserAccountRoleDetails` join convention: `UserAccountRoleDetails.UserID` → `UserAccountMaster.ID` (NOT `Staff_ID`); `UserAccountRoleDetails.RoleID` → `UserAccountRoleMaster.ID`; `UserAccountRoleDetails.BranchID` → `BranchMaster.ID`; `UserAccountRoleDetails.StaffID` (also exists) → `Staff_Master.Staff_ID`. The two paths (`UserID` and `StaffID`) are both valid but for branch scoping the canonical key is `UserID=@UserId`.
**EVIDENCE:** `Sp_Chalo_GetUserDetailsForLogin` (`JOIN UserAccountRoleDetails UARD ON UARD.BranchID=BM.ID AND UARD.UserID=@Sid`); `Sp_SelectStaffNameByRoleID` (`UserAccountRoleMaster UM JOIN UserAccountRoleDetails URD ON UM.ID = URD.RoleID`); `SP_DashboardBranchwiseStatistics` (`UserAccountRoleDetails uard WHERE uard.StaffID = @StaffId` — alternate form, used in dashboards); `Sp_ExamEntryMarkDetails` (uses `@StaffID` to gate).
**CHECK:** When branch-scoping via `UserAccountRoleDetails`, the filter key is `UserID=@UserId` (or `StaffID=@StaffId` if a staff-id was resolved from `UserAccountMaster.StaffID`). Regex: `r'(?i)UserAccountRoleDetails.*UserID\s*=\s*@UserId|UserAccountRoleDetails.*StaffID\s*=\s*@StaffId'`.
**SEVERITY:** MEDIUM

### RBAC-008
**RULE:** Academic-year resolution pattern: `SET @AcademicYearID = (SELECT TOP 1 ID FROM Branch_Academic_Details WHERE Branch_Id = @BranchID ORDER BY DisplayOrder DESC)` for "current academic year". For "previous academic year": `SELECT Id FROM Branch_Academic_Details WHERE Start_Date < (SELECT Start_Date FROM Branch_Academic_Details WHERE Id = @ACD) AND Branch_Id = @BranchID`.
**EVIDENCE:** `sp_UserMaster_GetAcademicYearByBranch` (`SELECT bad.Id, bad.Name ... FROM dbo.Branch_Academic_Details bad WHERE bad.Branch_Id = @branchID order by bad.DisplayOrder desc`); `GetPreviousAcademicYearId` (`select Id from branch_Academic_Details where start_Date < (@Academic_StartingYear) and branch_id=@BranchID`).
**CHECK:** Academic-year resolution MUST use `Branch_Academic_Details` (never `YEAR(GETDATE())`). For "current", use `ORDER BY DisplayOrder DESC` (or compare `GETDATE()` against `Start_Date/End_Date`). For "previous", compare `Start_Date` against the current AY's Start_Date.
**SEVERITY:** HIGH

---

## 10. MODULE: Deprecated / Live Twin Pairs

### DEPRECATED-001
**RULE:** Do NOT use `EnquiryMaster` — use `GeneralCallRegister`.
**EVIDENCE:** 134+ enquiry-related SPs use `GeneralCallRegister` (`sp_EnquiryListReport`, `sp_GeneralCallRegister_SearchCallRegisterData`, `sp_GeneralCallRegister_SelectRecord`, `SP_SearchEnquiryListData`, `Sp_ReportEnquiryAndApplicationStatus`). Zero SPs reference `EnquiryMaster` (grep across 1,092 SPs returns 0 matches).
**CHECK:** Blocklist `r'(?i)\bEnquiryMaster\b'` from FROM/JOIN.
**SEVERITY:** HIGH

### DEPRECATED-002
**RULE:** Do NOT use `PurchaseRequest` (no `I` prefix) — use `IPurchaseRequest`.
**EVIDENCE:** 9+ inventory SPs use `IPurchaseRequest` (`SP_InPurchaseRequest_SelectAll`, `SP_InPurchaseRequest_SelectRecord`, `SP_PurchaseRequest`, `SP_PurchaseRequestReceipt`, `SP_InventoryStockReport`, `SP_GoodsIssueReceipt`, `SP_GoodsReceiptInfo_`, `sp_IGoodsReceipt_*`). Zero SPs use `PurchaseRequest` (the deprecated table). The deprecated table has a misspelled `ApprovaStatus` column (confirmed by schema).
**CHECK:** Blocklist `r'(?i)from\s+(dbo\.)?PurchaseRequest\b'` (without `I` prefix). Allow `r'(?i)from\s+(dbo\.)?IPurchaseRequest\b'`.
**SEVERITY:** HIGH

### DEPRECATED-003
**RULE:** Do NOT use `Department_Master` (only referenced by deprecated `PurchaseRequest`). Use `StaffDepartmentMaster` for staff-department queries.
**EVIDENCE:** 3 staff-department SPs use `StaffDepartmentMaster` (`sp_StaffDepartment_SelectAll`, `sp_StaffDepartment_SelectRecord`, `sp_StaffDepartmentMapping_SelectAll`). The schema confirms `Department_Master` exists but has the only FK from the deprecated `PurchaseRequest.Department` column.
**CHECK:** Blocklist `r'(?i)\bDepartment_Master\b'` from staff queries.
**SEVERITY:** HIGH

### DEPRECATED-004
**RULE:** Do NOT use `BusFeeStructure` (correctly spelled) — the LIVE table is `BusFeeStrucure` (MISSPELLED, no second 't').
**EVIDENCE:** 32 SPs reference `BusFeeStrucure`; ZERO SPs reference `BusFeeStructure`. The schema confirms the table is created as `BusFeeStrucure`.
**CHECK:** Blocklist `r'(?i)\bBusFeeStructure\b'` (correctly spelled). Use `r'(?i)\bBusFeeStrucure\b'`.
**SEVERITY:** HIGH

### DEPRECATED-005
**RULE:** Do NOT use `PurchaseRequest.ApprovaStatus` (misspelled) — use `IPurchaseRequest.ApprovalStatus` (correctly spelled).
**EVIDENCE:** Schema confirms `PurchaseRequest` has `[ApprovaStatus] [nvarchar](500)` (missing the 'l'); `IPurchaseRequest` has `ApprovalStatus` correctly spelled.
**CHECK:** The column name `ApprovaStatus` (misspelled) is a red flag for using the deprecated table. Blocklist `r'(?i)\bApprovaStatus\b'`.
**SEVERITY:** MEDIUM

### DEPRECATED-006
**RULE:** Do NOT use `CallStatus_Master` for admission-enquiry call-status lookups. Use `Enquiry_Status_Master` (joined via `GeneralCallRegister.CallStatus_ID`).
**EVIDENCE:** `sp_EnquiryListReport`, `sp_GeneralCallRegister_SearchCallRegisterData`, `sp_GeneralCallRegister_SelectRecord`, `SP_SearchEnquiryListData`, `Sp_ReportEnquiryAndApplicationStatus` all JOIN `Enquiry_Status_Master esm ON gcr.CallStatus_ID = esm.ID`. `CallRegister` (the internal non-admission call-tracking table) does use `CallStatus_Master` — but admission-enquiry uses `Enquiry_Status_Master`.
**CHECK:** For admission-enquiry call-status, the join MUST be `Enquiry_Status_Master`, not `CallStatus_Master`. Regex: `r'(?i)GeneralCallRegister.*Enquiry_Status_Master|Enquiry_Status_Master.*GeneralCallRegister'` for admission-enquiry.
**SEVERITY:** MEDIUM

---

## 11. MODULE: Inconsistencies (SPs that violate their own module's rules)

These are GROUND-TRUTH INCONSISTENCIES — the SP body itself violates the canonical pattern documented in this catalog. A Text-to-SQL verifier should treat the CANONICAL rule as authoritative (per the catalog) and flag these SPs as buggy ground truth.

### INCONSISTENT-001
**RULE:** `sp_ClasswiseOutstandingCountReport` OMITS `Lien_Amount` from the outstanding formula. The canonical formula (per FEE-001) requires subtracting Lien_Amount.
**EVIDENCE:** `sp_ClasswiseOutstandingCountReport` — `SUM(Amount-isnull(Concession_Amt,0)-isnull(Paid_Amt,0)) as TotalAmount` and `having SUM(Amount-isnull(Concession_Amt,0)-isnull(Paid_Amt,0)) > 0`. No `Lien_Amount` in either expression. Compare to `GetFeePendingByFeesInformationStudentDetail` (`(Amount-ISNULL(Concession_Amt,0)-Paid_Amt-Lien_Amount) >0`) — the canonical form.
**CHECK:** This SP is buggy. The verifier should ACCEPT the canonical (with Lien_Amount) form as correct and REJECT the sp_ClasswiseOutstandingCountReport form. (The catalog rule FEE-001 is authoritative.)
**SEVERITY:** HIGH (this is a real bug in the ground truth)

### INCONSISTENT-002
**RULE:** `Sp_Chalo_ReportFeeOustandingClassSectionTermwise` uses `SUM(Paid_Amt)` (no Lien) for `Collected_Amount` while `Sp_Chalo_ReportFeeOustanding` (the sibling SP) uses `SUM(Paid_Amt+isnull(Lien_amount,0))`. Same family of SPs, inconsistent Lien handling.
**EVIDENCE:** `Sp_Chalo_ReportFeeOustandingClassSectionTermwise` — `SUM(Paid_Amt) as Collected_Amount` (no Lien). `Sp_Chalo_ReportFeeOustanding` — `SUM(Paid_Amt+isnull(Lien_amount,0)) as Collected_Amount` (with Lien). `Sp_Chalo_ReportFeeOustandingTermwise` — `SUM(Paid_Amt+isnull(Lien_amount,0)) as Collected_Amount` (with Lien).
**CHECK:** The canonical "Collected_Amount" definition includes Lien (`SUM(Paid_Amt + ISNULL(Lien_Amount,0))`). The ClassSection variant's omission is a bug.
**SEVERITY:** MEDIUM

### INCONSISTENT-003
**RULE:** NO exam-term SP filters `ExamTermMaster.Deleted = 0` — the soft-delete column exists in the schema but SPs ignore it. This means deleted exam terms can appear in dropdowns.
**EVIDENCE:** `SP_Exam_GetALLExamTerm`, `SP_Exam_GetExamTerm`, `SP_Exam_GetALLPublishedExamTerm`, `Get_TermList`, `SP_Exam_GetExamType` all read `ExamTermMaster` by `BranchID/AcademicYearID` only, without `Deleted=0`. The schema confirms `ExamTermMaster.Deleted bit` exists.
**CHECK:** This is a documentation gap, not a model bug. The verifier should NOT add `Deleted=0` to ExamTermMaster queries (the production SPs don't), but should be AWARE of the inconsistency. If a future SP starts applying `Deleted=0`, the column name MUST be `Deleted`, not `IsDeleted`.
**SEVERITY:** MEDIUM

### INCONSISTENT-004
**RULE:** `Get_TermList` SP NAME implies "get list of terms" generically, but its body reads from `ExamTermMaster`. This is the smoking-gun example of the fee/exam term confusion: a model that calls `Get_TermList` for a fee-term question receives exam-term IDs that will not match fee-demand rows.
**EVIDENCE:** `Get_TermList` — `SELECT etm.id, etm.Name AS Termname FROM dbo.ExamTermMaster etm WHERE etm.AcademicYearID = @AcademicYear AND etm.BranchID = @BranchID`.
**CHECK:** This is a documentation/training bug. The catalog rule FEE-006 (TermMaster for fees, ExamTermMaster for exams) is authoritative. `Get_TermList` should be treated as an exam-term SP despite its name.
**SEVERITY:** HIGH

### INCONSISTENT-005
**RULE:** `Sp_Chalo_ReportFeeOustanding` (the main outstanding SP) does NOT filter `Structure_Type IN ('Academic','Optional')` — but its sibling `Sp_Chalo_ReportFeeOustandingTermwise` and `Sp_Chalo_ReportFeeOustandingClassSectionTermwise` DO filter it.
**EVIDENCE:** `Sp_Chalo_ReportFeeOustanding` (TypeID=1 and TypeID=2 branches) — WHERE clause has `FS.IsIncludedInLumpSum=0` but no `Structure_Type` filter. `Sp_Chalo_ReportFeeOustandingTermwise` — WHERE clause has `FS.IsIncludedInLumpSum=0` AND `FS.Structure_Type IN ('Academic','Optional')`. `Sp_Chalo_ReportFeeOustandingClassSectionTermwise` — same.
**CHECK:** The canonical rule FEE-005 (filter Structure_Type IN ('Academic','Optional')) is authoritative. The main SP's omission is a bug.
**SEVERITY:** MEDIUM

### INCONSISTENT-006
**RULE:** `Sp_Chalo_GetStudentTransportDetails` uses `SAD.TransportRequired='True'` (string), but `sp_TransportStudentDetails` and `Sp_Chalo_GetStudentApplicableFees` use `TransportRequired = 1` (numeric). The schema audit confirms `TransportRequired` is `nvarchar(10)` so the canonical form is `'True'`.
**EVIDENCE:** `Sp_Chalo_GetStudentTransportDetails` (`AND SAD.TransportRequired='True'`); `sp_TransportStudentDetails` (`And SAM.TransportRequired = 1`); `Sp_Chalo_GetStudentApplicableFees` (`AND SAD.TransportRequired=1`).
**CHECK:** Both forms appear in production. The verifier should accept both, but prefer `'True'` for new queries.
**SEVERITY:** MEDIUM

---

## 12. Summary

Total rules: **78** (22 Fees + 5 Examinations + 6 Students + 4 Staff + 5 Admissions + 6 Transport + 5 Inventory + 5 Payroll + 8 RBAC + 6 Deprecated-twin + 6 Inconsistency = 78).

### Per-module rule count:
| Module | Rules | IDs |
|---|---|---|
| Fees | 22 | FEE-001 … FEE-022 |
| Examinations | 5 | EXAM-001 … EXAM-005 |
| Students | 6 | STUD-001 … STUD-006 |
| Staff | 4 | STAFF-001 … STAFF-004 |
| Admissions | 5 | ADM-001 … ADM-005 |
| Transport | 6 | TRANS-001 … TRANS-006 |
| Inventory | 5 | INV-001 … INV-005 |
| Payroll | 5 | PAY-001 … PAY-005 |
| RBAC / cross-cutting | 8 | RBAC-001 … RBAC-008 |
| Deprecated twins | 6 | DEPRECATED-001 … DEPRECATED-006 |
| Inconsistencies | 6 | INCONSISTENT-001 … INCONSISTENT-006 |

### Severity breakdown:
- **HIGH**: 46 rules (silent wrong-answer risk)
- **MEDIUM**: 32 rules (plausible mistake breaking downstream)
- **LOW**: 0 rules

### Top-10 highest-severity rules (inline):
1. **FEE-001** — Outstanding formula MUST subtract `Lien_Amount`. (`sp_ClasswiseOutstandingCountReport` violates — see INCONSISTENT-001.)
2. **FEE-006** — Fee `Term_ID` joins `TermMaster` (NOT `ExamTermMaster`).
3. **FEE-011** — Fee-collection sums filter `ChequeStatus_ID IN (1,2)` (or `NOT IN (3,4)`).
4. **FEE-013** — Current fee-term resolution uses `TermMaster.StartingDate/EndingDate` with `CAST(GETDATE() AS date)`.
5. **EXAM-001** — `ExamTypeMaster.TermID` joins `ExamTermMaster` (NOT `TermMaster`).
6. **EXAM-002** — `ExamTermMaster` soft-delete column is `Deleted`, not `IsDeleted`.
7. **STUD-001** — `Student_Master` has NO `ClassID/SectionID/AcademicYearID` — must join `StudentAcademicDetail`.
8. **STUD-004** — Academic-year resolution via `Branch_Academic_Details` (never `YEAR(GETDATE())`).
9. **DEPRECATED-001** — Use `GeneralCallRegister`, not `EnquiryMaster`.
10. **DEPRECATED-004** — Use `BusFeeStrucure` (MISSPELLED), not `BusFeeStructure`.

### Files saved:
- `/home/z/my-project/semantic_rules_catalog.md` (this file)
- `/home/z/my-project/semantic_rules.json` (machine-readable version with check_regex_or_pattern and tables_involved)

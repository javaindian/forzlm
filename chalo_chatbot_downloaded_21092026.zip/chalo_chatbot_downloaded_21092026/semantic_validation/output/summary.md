# Semantic Validation Summary

**Dataset:** `/home/z/my-project/semantic_validation/reference_inputs/training_dataset_final_v27.jsonl`

**Generated:** 2026-08-29T08:25:16

**Rules:** 32

---

## Stats

- Total examples: **3867**
- Flagged: **347** (9.0%)
- Clean: **3520** (91.0%)
- Total violations: **421**
- HIGH severity: **403**
- MEDIUM severity: **18**

## Rule hit counts

| Rule ID | Count | % | Title |
|---|---:|---:|---|
| `FEE-007` | 146 | 3.78% | Missing or hardcoded AcademicYearID filter |
| `FEE-005` | 62 | 1.60% | Missing Structure_Type filter |
| `STUD-005` | 42 | 1.09% | Student query missing AcademicYearID filter |
| `MULTI-STMT` | 36 | 0.93% | Multiple SQL statements |
| `WRITE-VERB` | 36 | 0.93% | Write verb in read-only service |
| `STUD-006` | 25 | 0.65% | Subject_Master joined on BranchID (cartesian product) |
| `FEE-009` | 22 | 0.57% | Missing TC-issued student filter |
| `FEE-004` | 18 | 0.47% | Missing IsIncludedInLumpSum filter |
| `FEE-022` | 18 | 0.47% | Missing IsDonation=0 filter for academic fees |
| `EXAM-007` | 10 | 0.26% | Marks query missing exam-term filter (ExamTypeMaster→ExamTermMaster) |
| `FEE-011` | 3 | 0.08% | Missing ChequeStatus_ID filter on FeesCollection |
| `FEE-013` | 2 | 0.05% | Wrong date window for current-term fee |
| `RBAC-SALARY` | 1 | 0.03% | Salary query missing branch scoping |

## Module breakdown

| Module | Total | Flagged | Flagged % |
|---|---:|---:|---:|
| Fees | 1245 | 217 | 17.4% |
| Students | 1054 | 71 | 6.7% |
| Other | 441 | 32 | 7.3% |
| Admissions | 204 | 17 | 8.3% |
| Administration | 105 | 7 | 6.7% |
| Examinations | 68 | 2 | 2.9% |
| Payroll | 89 | 1 | 1.1% |
| Staff | 350 | 0 | 0.0% |
| Transport | 170 | 0 | 0.0% |
| Home Works | 30 | 0 | 0.0% |
| Parent Feedback | 56 | 0 | 0.0% |
| Circulars | 41 | 0 | 0.0% |
| Inventory | 6 | 0 | 0.0% |
| Communication | 8 | 0 | 0.0% |

## Artifacts

- `report.html` — interactive triage report (open in a browser)
- `violations.csv` — machine-readable, one row per violation (421 rows)
- `summary.md` — this file
- `dataset_version.txt` — provenance

# v28 validation report — v27 base (carried into v28)

**Examples:** 3867
**Flagged:** 429 (11.1%)
**HIGH:** 476
**Violations:** 509

| Rule | Count |
|---|---:|
| `FEE-007` | 146 |
| `FEE-005` | 62 |
| `STUD-005` | 42 |
| `MULTI-STMT` | 36 |
| `WRITE-VERB` | 36 |
| `STUD-007` | 30 |
| `STUD-006` | 25 |
| `FEE-009` | 22 |
| `FEE-004` | 18 |
| `FEE-022` | 18 |
| `FEE-025` | 15 |
| `STAFF-004` | 14 |
| `STAFF-005` | 13 |
| `LEAVE-001` | 10 |
| `EXAM-007` | 10 |
| `FEE-024` | 6 |
| `FEE-011` | 3 |
| `FEE-013` | 2 |
| `RBAC-SALARY` | 1 |

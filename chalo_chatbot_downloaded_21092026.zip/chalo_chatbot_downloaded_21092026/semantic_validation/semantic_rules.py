"""
semantic_rules.py — ChaloSchools Text-to-SQL Semantic Verification Engine
=========================================================================

54 deterministic rules:
  - Rules 1-32: mined from the 1,095 reference stored procedures.
  - Rules 33-54 (2026-09-04): incorporated from the ERP CODEBASE ANALYSIS
    (codebase_analysis/extracted/MANDATORY_FILTERS_REFERENCE.md — 11,148
    WHERE clauses scanned in the school ERP's own C# LINQ code) and the
    production-trace rule proposals (docs/PRODUCTION_TRACE_OBSERVATIONS.md §7).

This is the layer that catches semantic errors that pass every structural
gate (schema existence, alias scope, branch scoping, value validation) but
return wrong or empty data.

Usage:
    from semantic_rules import check_sql
    violations = check_sql(sql, question)
    if violations:
        # refuse / disambiguate / log

Each rule returns a Violation(rule_id, severity, message, suggested_fix, module) or None.
The engine wraps each rule in try/except so a buggy rule never crashes the pipeline.

HINT_MAP + lookup_hints() provide retry-prompt hints (hallucinated column →
correct approach) for the orchestrator's bounded-retry path.
"""
from __future__ import annotations
import re
from dataclasses import dataclass
from typing import List, Optional, Callable, Dict, Any

# ── Helpers ─────────────────────────────────────────────────────────────────

_FROM_JOIN = re.compile(r"\b(?:FROM|JOIN)\s+(?:\[?dbo\]?\.)?\[?(\w+)\]?", re.IGNORECASE)

def _tables(sql: str) -> set:
    return {m.group(1) for m in _FROM_JOIN.finditer(sql)}

def _has(sql: str, pattern: str, flags=re.IGNORECASE) -> bool:
    return bool(re.search(pattern, sql, flags))

# Fee tables (Term_ID → TermMaster.ID)
FEE_TERM_FK_TABLES = {
    "FeesInformationStudentDetail", "FeesCollection_Details", "FeeStructureMonth",
    "HostelFeeStructure", "BusFeeStrucure", "LateFeeMaster", "LateFee_Concession",
    "FeesCollectionPriority_Details", "FeesCollection_MiscellaneousDetails",
    "Fees_Data_Import", "OptionalFeeMapping_StudentMonths", "Fees_Invoice_Generation",
}
ALL_FEE_TABLES = FEE_TERM_FK_TABLES | {
    "FeesCollection", "FeeStructure", "FeeStructureDetail",
    "Fees_Master", "FeesGroup_Master", "DonationFeesCollection",
    "ProspectusFeesCollection", "Concession_Master", "LumpSum_Fees",
}

# Marks tables (exam-term domain)
MARKS_TABLES = {"StudentMarkDetails", "StudentMarkMaster", "OtherExamMarkDetails",
                "OtherExam_StudentMarkMaster", "OtherExam_StudentMarkDetails"}

# Exam-config tables that hold MinMark (the pass threshold)
EXAM_CONFIG_TABLES_WITH_MINMARK = {
    "ExamConfigurationEvaluationDetails", "ConsolidatedExamConfigurationExamTypeDetails",
    "Grade_Details", "OtherExamConfigurationEvaluationDetails",
    "ProgressCardDataRetrieval",
}

# Sensitive tables/columns that must NEVER appear (defense in depth)
SENSITIVE_TABLES = {
    "StorageConfiguration", "SMS_ConfigurationSettings", "WhatsAppConfiguration",
    "Student_Master_Draft", "PasswordRecovery", "PaymentConfiguration",
    "PaymentConfiguration_Details", "AirpayTXNDataTable",
}
SENSITIVE_COLUMN_OWNERS = {
    "Password": {"UserAccountMaster", "Student_Master_Draft"},
    "Token": {"UserAccountMaster", "Student_Master_Draft"},
    "SGC_Password": {"BranchMaster"},
    "SGC_UserId": {"BranchMaster"},
    "APIKey": {"BranchMaster"},
}

# Deprecated / live twin tables
DEPRECATED = {
    "EnquiryMaster": "GeneralCallRegister",
    "Department_Master": "StaffDepartmentMaster",
    "PurchaseRequest": "IPurchaseRequest",
    "Academic_Month_Master": "Month_Master",
    "BusFeeStructure": "BusFeeStrucure",  # misspelled live table
}

@dataclass
class Violation:
    rule_id: str
    severity: str  # HIGH | MEDIUM
    message: str
    suggested_fix: str = ""
    module: str = ""

    def __str__(self):
        return f"[{self.severity}] {self.rule_id}: {self.message}"

# ── Intent classifiers ──────────────────────────────────────────────────────

def _outstanding_intent(q: str) -> bool:
    q = q.lower()
    return any(k in q for k in (
        "outstanding", "pending", "due", "defaulter", "owe", "balance",
        "remaining", "not paid", "unpaid", "fees due", "fee due",
    ))

def _collected_intent(q: str) -> bool:
    q = q.lower()
    return any(k in q for k in (
        "collected", "collection", "total fees", "fees collected",
        "sum of fees", "fee collection", "received",
    ))

def _is_date_scoped(q: str) -> bool:
    q = q.lower()
    return any(k in q for k in (
        "today", "this month", "yesterday", "last 7 days", "last week",
        "this week", "on 15th", "in january", "in february", "in march",
        "in april", "in may", "in june", "in july", "in august",
        "in september", "in october", "in november", "in december",
        "between", "since", "last month", "last year",
    ))

# ── FEE rules (11) ───────────────────────────────────────────────────────────

def r_fee001(sql, q, tables):
    if "FeesInformationStudentDetail" not in tables: return None
    if not _outstanding_intent(q): return None
    has_amount_expr = _has(sql, r"Amount\s*-\s*ISNULL\s*\(\s*Concession_Amt") or \
                      _has(sql, r"Amount\s*-\s*Concession_Amt") or \
                      _has(sql, r"Amount\s*-\s*Paid_Amt") or \
                      _has(sql, r"Amount\s*-\s*ISNULL\s*\(\s*Paid_Amt")
    if not has_amount_expr: return None
    if not _has(sql, r"\bLien_Amount\b") and not _has(sql, r"\bLien_amount\b"):
        return Violation("FEE-001", "HIGH",
            "Outstanding query on FeesInformationStudentDetail omits Lien_Amount.",
            "Add ISNULL(Lien_Amount,0) to the outstanding expression: "
            "Amount - ISNULL(Concession_Amt,0) - Paid_Amt - ISNULL(Lien_Amount,0).", "Fees")
    return None

def r_fee004(sql, q, tables):
    if "FeesInformationStudentDetail" not in tables: return None
    if not _outstanding_intent(q): return None
    if not _has(sql, r"IsIncludedInLumpSum\s*(=|<>|!=)\s*(0|1)"):
        return Violation("FEE-004", "HIGH",
            "Outstanding query omits IsIncludedInLumpSum filter (risks double-counting).",
            "Add AND IsIncludedInLumpSum = 0 to the WHERE clause.", "Fees")
    return None

def r_fee005(sql, q, tables):
    """FEE-005: Structure_Type filter check.
    REFINED after the v25→v27 correction (2026-08-28):
    - v27 deliberately REMOVED Structure_Type from 524 'outstanding' examples because
      the filter was silently excluding Hostel/Bus/Misc/Others fees from the total.
    - For 'total outstanding/pending/due' queries (user wants the GRAND TOTAL): do NOT
      require Structure_Type — the total should include all fee types. This matches v27.
    - For 'academic fee' / 'tuition fee' queries (user specifically asks about academic
      fees): DO require Structure_Type IN ('Academic','Optional').
    - For 'demand' / 'fee summary' queries: require Structure_Type (these are typically
      academic-fee-specific reports).
    """
    if "FeesInformationStudentDetail" not in tables: return None
    ql = q.lower()
    # Skip bus/hostel/donation/misc-specific queries (they have their own filters)
    if any(k in ql for k in ("bus fee", "hostel fee", "donation", "transport fee", "misc")):
        return None
    # Check if the user is asking for a TOTAL (outstanding/pending/due/defaulter/balance/owe)
    is_total_outstanding = _outstanding_intent(q)
    # Check if the user is specifically asking about academic/tuition fees
    is_academic_specific = any(k in ql for k in ("academic fee", "tuition fee", "academic outstanding", "tuition outstanding", "academic outstanding"))
    # Check if this is a demand/summary report (typically academic-fee-specific)
    is_demand_report = "demand" in ql or "fee summary" in ql or "fee type" in ql

    # If it's a TOTAL outstanding query and NOT academic-specific: do NOT require Structure_Type
    # (v27 intentionally removed it — the total should include all fee types)
    if is_total_outstanding and not is_academic_specific:
        return None  # v27's intentional behavior — don't flag

    # If it's academic-specific or a demand report: DO require Structure_Type
    if is_academic_specific or is_demand_report:
        if not _has(sql, r"Structure_Type\s+IN\s*\(\s*'[^']*'\s*,\s*'[^']*'\s*\)"):
            if not _has(sql, r"Structure_Type\s*=\s*'"):
                return Violation("FEE-005", "HIGH",
                    "Academic-fee query omits Structure_Type filter.",
                    "Add AND Structure_Type IN ('Academic','Optional') for academic-fee queries. "
                    "For total outstanding (all fee types), Structure_Type is not needed.", "Fees")
    return None

def r_fee006(sql, q, tables):
    if not (tables & FEE_TERM_FK_TABLES): return None
    if _has(sql, r"JOIN\s+(?:\[?dbo\]?\.)?\[?ExamTermMaster\]?"):
        return Violation("FEE-006", "HIGH",
            "Fee query joins ExamTermMaster — fee Term_ID must join TermMaster.",
            "Change JOIN ExamTermMaster to JOIN TermMaster tm ON tm.ID = <fee>.Term_ID. "
            "The two ID sequences are independent; joining ExamTermMaster returns wrong/empty data.", "Fees")
    return None

def r_fee007(sql, q, tables):
    if not (tables & ALL_FEE_TABLES): return None
    if _is_date_scoped(q): return None
    if not _has(sql, r"AcademicYearID") and not _has(sql, r"Branch_Academic_Details"):
        return Violation("FEE-007", "HIGH",
            "Fee query omits AcademicYearID filter (returns all-time data).",
            "Add AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details "
            "WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (<scoping>)).", "Fees")
    if _has(sql, r"AcademicYearID\s*=\s*'20\d{2}"):
        return Violation("FEE-007", "HIGH",
            "Fee query hardcodes the academic year as a string literal.",
            "Resolve via Branch_Academic_Details: AND AcademicYearID IN (SELECT Id FROM "
            "Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date).", "Fees")
    return None

def r_fee009(sql, q, tables):
    if "FeesInformationStudentDetail" not in tables: return None
    if not _outstanding_intent(q): return None
    if "StudentAcademicDetail" not in tables: return None
    if not _has(sql, r"IsTCIssued"):
        return Violation("FEE-009", "HIGH",
            "Outstanding query joins StudentAcademicDetail but omits the TC-issued filter.",
            "Add AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) to exclude "
            "students who have left the school (TC = Transfer Certificate).", "Fees")
    return None

def r_fee011(sql, q, tables):
    if "FeesCollection" not in tables: return None
    if "FeesCollection_Details" in tables: return None
    if not _collected_intent(q): return None
    if not _has(sql, r"ChequeStatus_ID\s+NOT\s+IN\s*\(\s*3\s*,\s*4\s*\)") and \
       not _has(sql, r"ChequeStatus_ID\s+IN\s*\(\s*1\s*,\s*2\s*\)") and \
       not _has(sql, r"ChequeStatus_ID\s*=\s*[12]"):
        return Violation("FEE-011", "HIGH",
            "FeesCollection collection query omits ChequeStatus_ID filter.",
            "Add AND ChequeStatus_ID NOT IN (3,4) — 3=Bounced, 4=Cancelled. "
            "Without this, bounced/cancelled cheques are counted as collected.", "Fees")
    return None

def r_fee013(sql, q, tables):
    if not (tables & ALL_FEE_TABLES): return None
    ql = q.lower()
    if not any(k in ql for k in ("current term", "this term")): return None
    if not _has(sql, r"GETDATE\(\)\s*BETWEEN\s+\w+\.?StartingDate\s+AND\s+\w+\.?EndingDate"):
        if _has(sql, r"GETDATE\(\)\s*BETWEEN\s+\w+\.?StartDate\s+AND\s+\w+\.?EndDate"):
            return Violation("FEE-013", "HIGH",
                "Current-term fee query uses the wrong date window.",
                "Fee terms use TermMaster.StartingDate/EndingDate (date type). "
                "ExamTermMaster.StartDate/EndDate (datetime) is the EXAM-term window. "
                "Change to JOIN TermMaster tm ON tm.ID = f.Term_ID AND GETDATE() BETWEEN tm.StartingDate AND tm.EndingDate.", "Fees")
        return Violation("FEE-013", "HIGH",
            "Current-term fee query has no date window on TermMaster.",
            "Add JOIN TermMaster tm ON tm.ID = f.Term_ID AND GETDATE() BETWEEN tm.StartingDate AND tm.EndingDate.", "Fees")
    return None

def r_fee014(sql, q, tables):
    if "FeesInformationStudentDetail" not in tables: return None
    if "bus fee" not in q.lower(): return None
    if not _has(sql, r"IsBusFee\s*=\s*1"):
        return Violation("FEE-014", "HIGH",
            "Bus-fee query omits IsBusFee = 1 filter.",
            "Add AND f.IsBusFee = 1 to restrict to bus-fee rows only.", "Fees")
    return None

def r_fee019(sql, q, tables):
    if "FeesCollection" not in tables: return None
    if _has(sql, r"(?:fc|fcm|FeesCollection)\.Amt\b"):
        return Violation("FEE-019", "MEDIUM",
            "FeesCollection has no 'Amt' column.",
            "Use fc.Receipt_Amt (the real amount column). 'Amt' does not exist on FeesCollection.", "Fees")
    return None

def r_fee022(sql, q, tables):
    if "FeesInformationStudentDetail" not in tables: return None
    if "donation" in q.lower(): return None
    if _outstanding_intent(q) or "demand" in q.lower():
        if not _has(sql, r"IsDonation\s*=\s*0"):
            return Violation("FEE-022", "MEDIUM",
                "Academic-fee query omits IsDonation = 0 filter.",
                "Add AND f.IsDonation = 0 to exclude donation rows from academic-fee totals.", "Fees")
    return None

# ── EXAM rules (5) ───────────────────────────────────────────────────────────

def r_exam001(sql, q, tables):
    if "ExamTypeMaster" not in tables: return None
    if _has(sql, r"JOIN\s+(?:\[?dbo\]?\.)?\[?TermMaster\]?") and _has(sql, r"ExamTypeMaster.*TermID|TermID.*ExamTypeMaster"):
        return Violation("EXAM-001", "HIGH",
            "ExamTypeMaster.TermID is an FK to ExamTermMaster.ID, NOT TermMaster.ID.",
            "Change JOIN TermMaster to JOIN ExamTermMaster etm ON etm.ID = et.TermID. "
            "Joining to TermMaster mixes exam types with fee terms.", "Examinations")
    return None

def r_exam002(sql, q, tables):
    if "ExamTermMaster" not in tables: return None
    etm_alias = re.search(r"ExamTermMaster\s+(?:AS\s+)?(\w+)", sql, re.IGNORECASE)
    if etm_alias:
        alias = etm_alias.group(1)
        if _has(sql, rf"\b{re.escape(alias)}\.IsDeleted\b"):
            return Violation("EXAM-002", "HIGH",
                f"ExamTermMaster (alias {alias}) uses IsDeleted — should be Deleted.",
                f"Change {alias}.IsDeleted to {alias}.Deleted. ExamTermMaster's soft-delete column is non-standard.",
                "Examinations")
    return None

def r_exam003(sql, q, tables):
    if "ExamTermMaster" not in tables: return None
    etm_alias = re.search(r"ExamTermMaster\s+(?:AS\s+)?(\w+)", sql, re.IGNORECASE)
    if etm_alias:
        alias = etm_alias.group(1)
        if _has(sql, rf"\b{re.escape(alias)}\.StartingDate\b") or _has(sql, rf"\b{re.escape(alias)}\.EndingDate\b"):
            return Violation("EXAM-003", "HIGH",
                f"ExamTermMaster (alias {alias}) uses StartingDate/EndingDate — wrong columns.",
                f"Use {alias}.StartDate and {alias}.EndDate (datetime type). "
                "StartingDate/EndingDate are on TermMaster (the fee-term table, date type).", "Examinations")
    return None

def r_exam004(sql, q, tables):
    if _has(sql, r"\bEXEC\s+Get_TermList\b") or _has(sql, r"\bEXECUTE\s+Get_TermList\b"):
        ql = q.lower()
        if any(k in ql for k in ("fee", "outstanding", "collection", "default", "pending", "term fee")):
            return Violation("EXAM-004", "HIGH",
                "Get_TermList reads from ExamTermMaster despite its generic name.",
                "Do not call Get_TermList for fee-term lookups. Use sp_TermMaster_SelectAll "
                "or JOIN TermMaster directly.", "Examinations")
    return None

# EXAM-006 (new): MinMark hallucination — pass/fail threshold must come from exam-config tables
_EXAM006_MARKS_ALIASES = ("smd", "smm", "StudentMarkDetails", "StudentMarkMaster")
def r_exam006(sql, q, tables):
    if not (tables & MARKS_TABLES): return None
    # Detect <marksalias>.MinMark
    for alias in _EXAM006_MARKS_ALIASES:
        if re.search(rf"\b{re.escape(alias)}\.MinMark\b", sql, re.IGNORECASE):
            return Violation("EXAM-006", "HIGH",
                f"MinMark does not exist on StudentMarkDetails/StudentMarkMaster (alias {alias}).",
                "MinMark lives on exam-config tables (ExamConfigurationEvaluationDetails, "
                "ConsolidatedExamConfigurationExamTypeDetails, Grade_Details). "
                "JOIN one of those tables and use its MinMark column as the pass threshold. "
                "Example: JOIN ExamConfigurationEvaluationDetails eced ON eced.ID = smd.EvalHierID AND eced.MinMark IS NOT NULL, "
                "then use eced.MinMark.", "Examinations")
    return None

# EXAM-007 (new): "passed/failed in term N" marks queries must filter via exam term
_EXAM007_Q_KW = ("passed", "failed", "marks in term", "marks for term",
                  "mark in term", "toppers in", "topper in")
def r_exam007(sql, q, tables):
    if not (tables & MARKS_TABLES): return None
    ql = q.lower()
    if not any(k in ql for k in _EXAM007_Q_KW): return None
    # Does it already reference exam-term machinery?
    if _has(sql, r"\bExamTypeMaster\b") or _has(sql, r"\bExamTermMaster\b"):
        return None  # already handling exam term correctly
    # Does it wrongly reference fee-term (TermMaster)?
    wrong_term = _has(sql, r"\bTermMaster\b")
    msg = ("Marks query about exam-term results has no ExamTypeMaster/ExamTermMaster join. "
           "Marks filter by EXAM term via ExamTypeMaster.TermID → ExamTermMaster.ID.")
    fix = ("Add JOIN ExamTypeMaster etm ON etm.ID = smm.ExamTypeID AND JOIN ExamTermMaster et "
           "ON et.ID = etm.TermID AND et.Name LIKE '%Term 1%' (or filter by TermID directly). "
           "Do NOT use TermMaster (fee terms) for exam marks.")
    if wrong_term:
        msg = "Marks query uses TermMaster (fee terms) instead of ExamTermMaster (exam terms). " + msg
        fix = "Change JOIN TermMaster to JOIN ExamTermMaster via ExamTypeMaster.TermID. " + fix
    return Violation("EXAM-007", "HIGH", msg, fix, "Examinations")

# ── STUD rules (6) ───────────────────────────────────────────────────────────

def r_stud001(sql, q, tables):
    if "Student_Master" not in tables: return None
    sm_alias = re.search(r"Student_Master\s+(?:AS\s+)?(\w+)", sql, re.IGNORECASE)
    if not sm_alias: return None
    alias = sm_alias.group(1)
    for col in ("ClassID", "SectionID", "AcademicYearID"):
        if _has(sql, rf"\b{re.escape(alias)}\.{col}\b"):
            return Violation("STUD-001", "HIGH",
                f"Student_Master.{col} referenced — this column does not exist.",
                f"Join StudentAcademicDetail sad ON sad.StudentID = {alias}.ID "
                f"and use sad.{col} instead. Student_Master only holds the static profile.", "Students")
    return None

def r_stud004(sql, q, tables):
    if not _has(sql, r"AcademicYearID\s*=\s*YEAR\s*\(\s*GETDATE") and \
       not _has(sql, r"AcademicYearID\s*=\s*DATEPART\s*\(\s*year\s*,\s*GETDATE"):
        return None
    return Violation("STUD-004", "HIGH",
        "Academic year resolved via YEAR(GETDATE()) — academic year crosses calendar-year boundary.",
        "Resolve via Branch_Academic_Details: AND AcademicYearID IN (SELECT Id FROM "
        "Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date).", "Students")

def r_stud005(sql, q, tables):
    if "StudentAcademicDetail" not in tables: return None
    if _is_date_scoped(q): return None
    ql = q.lower()
    if any(k in ql for k in ("student id", "admission no", "admission number", "roll no")):
        return None
    if not any(k in ql for k in ("students", "enrolled", "class", "section", "how many students")):
        return None
    if not _has(sql, r"AcademicYearID") and not _has(sql, r"Branch_Academic_Details"):
        return Violation("STUD-005", "HIGH",
            "Student query joins StudentAcademicDetail but omits AcademicYearID filter.",
            "Add AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details "
            "WHERE GETDATE() BETWEEN Start_Date AND End_Date). Without this, students "
            "from all academic years are returned.", "Students")
    return None

# STUD-006 (new): Subject joins must use SubjectID, not BranchID (cartesian-join bug)
def r_stud006(sql, q, tables):
    if "Subject_Master" not in tables: return None
    # Find the alias used for Subject_Master
    sub_alias = re.search(r"Subject_Master\s+(?:AS\s+)?(\w+)", sql, re.IGNORECASE)
    if not sub_alias: return None
    alias = sub_alias.group(1)
    # Detect JOIN Subject_Master ... ON <alias>.BranchID = <other>.BranchID
    # (the cartesian-join pattern)
    pattern = rf"JOIN\s+Subject_Master\s+(?:AS\s+)?{re.escape(alias)}\s+ON\s+{re.escape(alias)}\.BranchID\s*=\s*\w+\.BranchID"
    if re.search(pattern, sql, re.IGNORECASE):
        return Violation("STUD-006", "HIGH",
            f"Subject_Master (alias {alias}) joined on BranchID — cartesian product.",
            "Subject joins must use the SubjectID FK. Join via Subject_Master.Id = "
            "<marktable>.SubjectID (or via the exam-config table's SubjectID). "
            "Joining on BranchID is a cartesian product — every subject matches every mark row.", "Students")
    return None

# ── STAFF rules (2) ──────────────────────────────────────────────────────────

def r_staff002(sql, q, tables):
    if "Staff_Master" not in tables: return None
    sm_alias = re.search(r"Staff_Master\s+(?:AS\s+)?(\w+)", sql, re.IGNORECASE)
    if not sm_alias: return None
    alias = sm_alias.group(1)
    for col in ("FirstName", "MiddleName", "LastName"):
        if _has(sql, rf"\b{re.escape(alias)}\.{col}\b"):
            return Violation("STAFF-002", "HIGH",
                f"Staff_Master.{col} referenced — columns are Staff_-prefixed.",
                f"Use {alias}.Staff_FirstName, {alias}.Staff_MiddleName, {alias}.Staff_LastName. "
                "Student_Master uses FirstName/MiddleName/LastName; Staff_Master uses Staff_FirstName etc.", "Staff")
    return None

def r_staff003(sql, q, tables):
    if "Staff_Master" not in tables: return None
    ql = q.lower()
    if not any(k in ql for k in ("active staff", "currently teaching", "present staff")):
        return None
    if not _has(sql, r"StaffStatus_ID"):
        return Violation("STAFF-003", "MEDIUM",
            "Active-staff query omits StaffStatus_ID = 1 filter.",
            "Add AND sm.StaffStatus_ID = 1 to exclude inactive/resigned staff.", "Staff")
    return None

# ── ADM rules (2) ────────────────────────────────────────────────────────────

def r_adm001(sql, q, tables):
    if "ProspectusFeesCollection" not in tables: return None
    if _has(sql, r"ProspectusFeesCollection\.\w*Student_ID|pfc\.Student_ID|pfc\.StudentID"):
        return Violation("ADM-001", "HIGH",
            "ProspectusFeesCollection links applicants via ApplicationNo, not Student_ID.",
            "Use pfc.ApplicationNo (the prospectus/applicant identifier). Student_ID is "
            "null for pre-admission applicants — they don't have a student record yet.", "Admissions")
    return None

def r_adm002(sql, q, tables):
    if "EnquiryMaster" not in tables: return None
    return Violation("ADM-002", "HIGH",
        "EnquiryMaster is deprecated.",
        "Use GeneralCallRegister for all admission-enquiry queries. EnquiryMaster "
        "has zero live SP references; GeneralCallRegister is used by 10+ SPs.", "Admissions")

# ── Cross-cutting rules ──────────────────────────────────────────────────────

def r_deprecated(sql, q, tables):
    for dep, live in DEPRECATED.items():
        if dep in tables:
            if dep == "BusFeeStructure":
                return Violation("DEPRECATED-004", "HIGH",
                    "BusFeeStructure (correctly spelled) does not exist.",
                    "Use BusFeeStrucure (production table is MISSPELLED — no second 't').", "Transport")
            if dep == "EnquiryMaster":
                return None  # handled by r_adm002
            return Violation(f"DEPRECATED", "HIGH",
                f"{dep} is deprecated.", f"Use {live}.", "Deprecated")
    return None

def r_sensitive(sql, q, tables):
    for t in tables & SENSITIVE_TABLES:
        return Violation("SENSITIVE-TABLE", "HIGH",
            f"Sensitive table {t} must never be queried by the chatbot.",
            f"Remove all references to {t}. This table contains credentials/PII "
            "and is blocked per the security policy.", "Security")
    for m in re.finditer(r"\b(\w+)\.(Password|Token|SGC_Password|SGC_UserId|APIKey)\b", sql, re.IGNORECASE):
        return Violation("SENSITIVE-COL", "HIGH",
            f"Sensitive column {m.group(0)} must never be selected.",
            f"Remove {m.group(0)} from the SELECT list. This column contains credentials.", "Security")
    sel_match = re.search(r"SELECT\s+(.*?)\s+FROM", sql, re.IGNORECASE | re.DOTALL)
    if sel_match:
        sel = sel_match.group(1)
        for col, owners in SENSITIVE_COLUMN_OWNERS.items():
            if tables & owners:
                if re.search(r"(?<![\w.])(?<!\w)" + re.escape(col) + r"\b", sel, re.IGNORECASE):
                    return Violation("SENSITIVE-COL", "HIGH",
                        f"Bare sensitive column '{col}' selected from {next(iter(tables & owners))}.",
                        f"Remove '{col}' from the SELECT list. Must never be queried.", "Security")
    return None

def r_rbac001(sql, q, tables):
    if not _has(sql, r"UserAccountRoleDetails\s+WHERE\s+UserID\s*=\s*@UserId"):
        return None
    if not _has(sql, r"SELECT\s+ID\s+FROM\s+BranchMaster\s+WHERE\s+EXISTS\s*\(\s*SELECT\s+1\s+FROM\s+UserAccountMaster\s+WHERE\s+ID\s*=\s*@UserId\s+AND\s+IsSuperUser\s*=\s*1"):
        return Violation("RBAC-001", "MEDIUM",
            "Branch scoping present but super-user UNION is missing.",
            "Add UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM "
            "UserAccountMaster WHERE ID=@UserId AND IsSuperUser=1) AND "
            "(@SelectedBranchId IS NULL OR ID=@SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted=0). "
            "Without this, super-users see zero branches.", "RBAC")
    return None

def r_rbac_salary(sql, q, tables):
    if "EmployeeSalaryDetails" not in tables: return None
    if not _has(sql, r"UserAccountRoleDetails") and not _has(sql, r"BranchID\s*=\s*@") \
       and not _has(sql, r"BranchID\s+IN\s*\("):
        return Violation("RBAC-SALARY", "HIGH",
            "Salary query has no branch scoping.",
            "Add AND esd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails "
            "WHERE UserID=@UserId ...). Cross-branch salary disclosure is an RBAC violation.", "RBAC")
    return None

def r_trans001(sql, q, tables):
    if "BusFeeStructure" in tables and "BusFeeStrucure" not in tables:
        return Violation("TRANS-001", "HIGH",
            "BusFeeStructure (correct spelling) does not exist.",
            "Use BusFeeStrucure (production table is MISSPELLED — no second 't'). "
            "32 SPs reference BusFeeStrucure; zero reference BusFeeStructure.", "Transport")
    return None

def r_multistmt(sql, q, tables):
    clean = re.sub(r"'(?:[^']|'')*'", "''", sql)
    clean = clean.rstrip().rstrip(";")
    if clean.count(";") >= 1:
        return Violation("MULTI-STMT", "HIGH",
            "Multiple statements detected.",
            "Only a single SELECT is permitted. Remove the extra semicolon(s) or "
            "split into separate queries.", "Structure")
    return None

def r_writeverb(sql, q, tables):
    clean = re.sub(r"^\s*(--[^\n]*\n|/\*.*?\*/)\s*", "", sql.strip(), flags=re.DOTALL)
    if sql.strip().startswith("--"): return None
    first = re.match(r"\s*(\w+)", clean)
    if first and first.group(1).upper() not in {"SELECT", "WITH"}:
        return Violation("WRITE-VERB", "HIGH",
            f"First verb is {first.group(1)} — only SELECT/WITH permitted.",
            "The chatbot is read-only. Rewrite as a SELECT query.", "Structure")
    upper = re.sub(r"'(?:[^']|'')*'", "''", sql).upper()
    if not sql.strip().startswith("--"):
        for kw in ("DROP", "DELETE", "UPDATE", "INSERT", "ALTER", "CREATE",
                  "TRUNCATE", "EXEC", "EXECUTE", "MERGE", "GRANT", "REVOKE"):
            if re.search(rf"\b{kw}\b", upper):
                return Violation("WRITE-VERB", "HIGH",
                    f"Blocked keyword '{kw}' present.",
                    f"Remove {kw}. The chatbot is read-only (SELECT only).", "Structure")
    return None

# ═════════════════════════════════════════════════════════════════════════════
# RULES 33-54 (added 2026-09-04) — ERP CODEBASE ANALYSIS INCORPORATION
#
# Sources (both uploaded with this session):
#   1. codebase_analysis/extracted/MANDATORY_FILTERS_REFERENCE.md
#      (11,148 WHERE clauses from the ERP's own C# LINQ code; 4,882 constant
#      filters; usage percentages quoted below are the ERP's own counts).
#   2. docs/PRODUCTION_TRACE_OBSERVATIONS.md §7 — the 12 trace-derived rules
#      (STAFF-004, FEEDBACK-001, FEE-023/024/025, COMM-001, ATT-001,
#      COMPARE-001, CLASSNAME-001, BONAFIDE-001, PREADM-001, REPORTCARD-001).
#
# Severity policy: HIGH = refuse at the semantic gate (evidence ~100% or a
# confirmed hallucination). MEDIUM = warn only (evidence 60-90% or the intent
# signal is fuzzy). This keeps false-refusal risk low while still surfacing
# the blindspots in the audit trail.
# ═════════════════════════════════════════════════════════════════════════════

# ── Trace-derived rules (12) ─────────────────────────────────────────────────

def r_staff004(sql, q, tables):
    """STAFF-004: staff/teacher questions must use Staff_Master.
    EmployeeMaster is the payroll twin (legitimately joined by salary
    queries — exempted below); using it for staff lists returns empty
    (live trace Q5, benchmark Q30/Q31)."""
    if not (tables & {"EmployeeMaster", "EmployeeMasters"}): return None
    ql = q.lower()
    if any(k in ql for k in ("salary", "payroll", "payslip", "pay slip",
                             "earnings", "deduction", "allowance", "bank",
                             "account no", "account number")):
        # payroll/bank queries legitimately join EmployeeMaster — the bank
        # and salary columns live there (confirmed by the v27 labels)
        return None
    if not any(k in ql for k in ("staff", "teacher", "principal", "faculty")):
        return None
    if "Staff_Master" in tables: return None
    return Violation("STAFF-004", "HIGH",
        "Staff question uses EmployeeMaster — the payroll twin, not the staff table.",
        "Use Staff_Master for staff/teacher questions (Staff_FirstName, "
        "Staff_LastName, StaffStatus_ID). EmployeeMaster is only used by "
        "payroll queries.", "Staff")

def r_feedback001(sql, q, tables):
    """FEEDBACK-001: feedback questions must use the live feedback table.
    GeneralFeedback does not exist; FeedbackParentStudent was the v27
    hallucination (benchmark Q49). The live table is FeedbackTicket."""
    ql = q.lower()
    if "feedback" not in ql: return None
    bad = tables & {"GeneralFeedback", "FeedbackParentStudent",
                    "FeedbackParentStudentDetail", "FeedbackParentStudentDetails"}
    if not bad: return None
    return Violation("FEEDBACK-001", "HIGH",
        f"Feedback question uses {sorted(bad)[0]} — not the live feedback table.",
        "Use FeedbackTicket for parent/student feedback queries "
        "(FeedbackCategories for the category list).", "Communication")

def r_fee023(sql, q, tables):
    """FEE-023: IsIncludedInLumpSum lives on FeesInformationStudentDetail,
    NOT on FeesCollection_Details (trace Q10)."""
    if "FeesCollection_Details" not in tables: return None
    if "FeesInformationStudentDetail" in tables: return None
    alias_m = re.search(r"FeesCollection_Details\s+(?:AS\s+)?(\w+)", sql, re.IGNORECASE)
    if alias_m and _has(sql, rf"\b{re.escape(alias_m.group(1))}\.IsIncludedInLumpSum\b"):
        return Violation("FEE-023", "HIGH",
            "IsIncludedInLumpSum referenced on FeesCollection_Details — column is on FeesInformationStudentDetail.",
            "IsIncludedInLumpSum exists only on FeesInformationStudentDetail. Either "
            "query that table, or remove the filter from FeesCollection_Details.", "Fees")
    return None

def r_fee024(sql, q, tables):
    """FEE-024: 'fee head' questions must not group by FeesGroup_Name —
    a fee GROUP is a bundle of fee HEADS (trace Q6)."""
    ql = q.lower()
    if not any(k in ql for k in ("fee head", "fee-head", "head wise", "head-wise")):
        return None
    if not _has(sql, r"FeesGroup_Name|FeesGroup_Master|FeesGroupMaster"): return None
    if "Fees_Master" in tables or _has(sql, r"Fees_Head_ID\s*=\s*\w+\.ID"):
        return None  # correctly joined to the head master
    return Violation("FEE-024", "HIGH",
        "Fee-HEAD question grouped by fee GROUP (FeesGroup_Name).",
        "A fee group is a bundle of fee heads. Join FeesCollection_Details.Fees_Head_ID "
        "= Fees_Master.ID and GROUP BY Fees_Master.Name for fee-head-wise answers.", "Fees")

def r_fee025(sql, q, tables):
    """FEE-025/FEE-030: fee-head or term-wise answers must JOIN the master
    table for the human-readable name, not return raw numeric IDs
    (trace Q5/Q8: answers came back as '181, 182, 183')."""
    ql = q.lower()
    fee_head_q = any(k in ql for k in ("fee head", "fee-head", "head wise", "head-wise"))
    term_wise_q = any(k in ql for k in ("term wise", "term-wise", "by term", "term-wise collection"))
    if fee_head_q and _has(sql, r"\bFees_Head_ID\b") and "Fees_Master" not in tables:
        return Violation("FEE-025", "MEDIUM",
            "Fee-head answer returns Fees_Head_ID (a numeric ID) without joining Fees_Master.",
            "JOIN Fees_Master fm ON fcd.Fees_Head_ID = fm.ID and SELECT fm.Name so the "
            "answer shows 'Tuition Fee' instead of '181'.", "Fees")
    if term_wise_q and _has(sql, r"\bTerm_ID\b") and "TermMaster" not in tables \
       and "ExamTermMaster" not in tables:
        return Violation("FEE-025", "MEDIUM",
            "Term-wise answer returns Term_ID (a numeric ID) without joining TermMaster.",
            "JOIN TermMaster tm ON f.Term_ID = tm.ID and SELECT tm.Name (or tm.Term_Name "
            "per your schema) so the answer shows 'Term 1' instead of '29'.", "Fees")
    return None

def r_comm001(sql, q, tables):
    """COMM-001: 'messages sent' questions must use SMSAuditTrail.
    GeneralCallRegister holds admission ENQUIRIES, not messages
    (trace Q17, benchmark Q47/Q48)."""
    ql = q.lower()
    if not any(k in ql for k in ("sms", "message", "messages", "notification",
                                 "notifications", "sent to parents", "communication")):
        return None
    if "GeneralCallRegister" not in tables: return None
    return Violation("COMM-001", "HIGH",
        "Message/SMS question uses GeneralCallRegister — that table holds admission enquiries.",
        "Use SMSAuditTrail for messages sent (SMS/email audit). GeneralCallRegister is "
        "for admission enquiries only.", "Communication")

def r_att001(sql, q, tables):
    """ATT-001: 'attendance not marked/entered' must be detected via
    NOT EXISTS / LEFT JOIN ... IS NULL, not a status filter (trace Q20).
    'Not marked' means NO ROW EXISTS for that class-section-day."""
    ql = q.lower()
    if not any(k in ql for k in ("not marked", "not entered", "not taken",
                                 "missing attendance", "attendance not",
                                 "not submitted", "not updated")): return None
    if not (tables & {"StudentAttendance", "StudentAttendanceDetail",
                      "ClassSectionMaster", "ClassSection"}): return None
    if _has(sql, r"NOT\s+EXISTS") or _has(sql, r"NOT\s+IN\s*\(\s*SELECT") \
       or _has(sql, r"IS\s+NULL"):
        return None
    return Violation("ATT-001", "HIGH",
        "'Not marked' attendance question answered with a status filter.",
        "'Not marked' means NO attendance row exists. Use NOT EXISTS (SELECT 1 "
        "FROM StudentAttendance sa WHERE sa.Class_ID = cm.ID AND sa.Section_ID = "
        "secm.ID AND sa.Attendance_Date = <date> AND ...) or LEFT JOIN ... IS NULL. "
        "A status filter can never find rows that do not exist.", "Attendance")

def r_compare001(sql, q, tables):
    """COMPARE-001: 'compare X vs Y' questions must return two labelled
    rows (UNION) or a pivoted single row (CASE), not one merged value
    (trace Q23, batch 2 Q4/Q9)."""
    ql = q.lower()
    if "compare" not in ql and " vs " not in ql and " versus " not in ql: return None
    if _has(sql, r"\bUNION\b") or _has(sql, r"CASE\s+WHEN"): return None
    return Violation("COMPARE-001", "MEDIUM",
        "'Compare X vs Y' question returns a single merged result.",
        "Return two labelled rows via UNION ALL (SELECT 'X' AS Label, ... UNION ALL "
        "SELECT 'Y', ...) or a CASE-based pivot so the user can see both sides.", "Structure")

def r_classname001(sql, q, tables):
    """CLASSNAME-001: ClassMaster's name column is Name, not ClassName
    (trace Q10). ClassName only exists as denormalized display columns on
    other tables (StudentAcademicDetail, FeesInformationStudentDetail)."""
    if "ClassMaster" not in tables: return None
    alias_m = re.search(r"ClassMaster\s+(?:AS\s+)?(\w+)", sql, re.IGNORECASE)
    if alias_m:
        a = re.escape(alias_m.group(1))
        if _has(sql, rf"\b{a}\.ClassName\b"):
            return Violation("CLASSNAME-001", "HIGH",
                f"ClassMaster (alias {alias_m.group(1)}) uses ClassName — the column is Name.",
                f"Change {alias_m.group(1)}.ClassName to {alias_m.group(1)}.Name.", "Students")
    if _has(sql, r"\bClassMaster\.ClassName\b"):
        return Violation("CLASSNAME-001", "HIGH",
            "ClassMaster.ClassName referenced — the column is Name.",
            "Use ClassMaster.Name. ClassName exists only as a denormalized column "
            "on StudentAcademicDetail / fee tables.", "Students")
    return None

def r_bonafide001(sql, q, tables):
    """BONAFIDE-001: IsBonafide is a hallucinated column (trace Q4).
    Bonafide certificates are generated per-request; there is no confirmed
    flag column (dev-team ask 3.5, still pending)."""
    if _has(sql, r"\bIsBonafide\b"):
        return Violation("BONAFIDE-001", "HIGH",
            "IsBonafide column referenced — it does not exist on any confirmed table.",
            "There is no bonafide flag column (dev-team ask 3.5 pending). Ask the "
            "user to rephrase, or query the request/approval workflow tables if "
            "confirmed by the dev team.", "Students")
    return None

def r_preadm001(sql, q, tables):
    """PREADM-001: FeesCollection has no IsPreAdmissionFee column (trace Q13).
    Pre-admission/prospectus fees live in ProspectusFeesCollection (linked
    by ApplicationNo — see ADM-001)."""
    if _has(sql, r"\bIsPreAdmissionFee\b"):
        return Violation("PREADM-001", "HIGH",
            "IsPreAdmissionFee referenced — it does not exist on FeesCollection.",
            "Pre-admission (prospectus) fees live in ProspectusFeesCollection, linked "
            "by ApplicationNo. FeesCollection holds post-admission receipts only.", "Admissions")
    return None

def r_reportcard001(sql, q, tables):
    """REPORTCARD-001: IsReportSubmitted on StudentAcademicDetail is a
    hallucination (trace Q16, dev-team ask 3.5 pending)."""
    if _has(sql, r"\bIsReportSubmitted\b") or _has(sql, r"\bIs_Report_Submitted\b"):
        return Violation("REPORTCARD-001", "HIGH",
            "IsReportSubmitted referenced — no confirmed column of this name.",
            "Report-card status is not on StudentAcademicDetail (dev-team ask 3.5 "
            "pending). Use the progress-card / report-card tables once confirmed.", "Examinations")
    return None

# ── Mandatory-filter rules from the ERP LINQ analysis (10) ──────────────────
# Evidence: MANDATORY_FILTERS_REFERENCE.md — 11,148 WHERE clauses scanned in
# the ERP's own C# code. A filter the ERP applies ~always is a filter the
# chatbot must apply too, or the answer silently includes dead rows.

# Tables the ERP filters with IsDeleted=0 in 100% of its own queries
_ALWAYS_SOFTDELETED = {
    "WorkFlow_Details", "WorkFlowMasters", "FeesCollectionPriorities",
    "StaffDepartmentMappings", "tblProgressCardModelTypeMasters",
}

def r_softdel101(sql, q, tables):
    """SOFTDEL-101: tables the ERP itself ALWAYS filters (100% of queries)."""
    hit = tables & _ALWAYS_SOFTDELETED
    if not hit: return None
    if _has(sql, r"\bIsDeleted\b"): return None
    t = sorted(hit)[0]
    return Violation("SOFTDEL-101", "HIGH",
        f"{t} queried without an IsDeleted filter — the ERP filters it in 100% of its own queries.",
        f"Add AND ({t[0].lower() + t[1:] if t[1:2].isupper() else t}.IsDeleted = 0 "
        f"OR {t}.IsDeleted IS NULL) — soft-deleted rows would otherwise be returned.", "SoftDeletes")

def r_softdel102(sql, q, tables):
    """SOFTDEL-102: HolidayMasters — 77.4% of ERP queries filter IsDeleted=0.
    Holiday lists are the canonical use (template T-147)."""
    if "HolidayMaster" not in tables and "HolidayMasters" not in tables: return None
    ql = q.lower()
    if not any(k in ql for k in ("holiday", "holidays", "day off", "days off",
                                 "calendar", "vacation")): return None
    if _has(sql, r"\bIsDeleted\b"): return None
    return Violation("SOFTDEL-102", "HIGH",
        "Holiday query omits the IsDeleted filter (77% of the ERP's own holiday queries include it).",
        "Add AND (hm.IsDeleted = 0 OR hm.IsDeleted IS NULL) so deleted holidays "
        "are not listed.", "SoftDeletes")

def r_stud007(sql, q, tables):
    """STUD-007 (codebase STUDENT-002): active-student counts must exclude
    TC-issued students. (IsTCIssued = 0 OR IsTCIssued IS NULL) — 45% of the
    ERP's StudentAcademicDetail queries; 93% of v27's own count examples.
    The canonical student chain always carries it (template T-001/T-008)."""
    if not (tables & {"StudentAcademicDetail", "StudentAcademicDetails"}): return None
    ql = q.lower()
    # opposite intent: user WANTS the leavers
    if any(k in ql for k in ("left", " tc", "tc ", "tc.", "transfer certificate",
                             "alumni", "issued")): return None
    # money questions: the TC filter affects student COUNTS, not fee SUMS —
    # fees received from a student who later left were still received.
    if any(k in ql for k in ("fee", "fees", "amount", "collected", "paid",
                             "payment", "receipt", "outstanding", "due")): return None
    if not any(k in ql for k in ("how many students", "student count", "count of students",
                                 "students in", "students are", "total students", "strength",
                                 "list students", "students list", "show students",
                                 "boys", "girls", "new admission", "enrolled")): return None
    if _has(sql, r"\bIsTCIssued\b"): return None
    return Violation("STUD-007", "HIGH",
        "Student-count query omits the TC-issued filter — students who left are counted.",
        "Add AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) to exclude "
        "students who have taken their Transfer Certificate and left.", "Students")

def r_staff005(sql, q, tables):
    """STAFF-005 (codebase STAFF-001/003): salary/attendance staff queries
    must filter StaffStatus_ID = 1 (Active) — 100% of the ERP's salary and
    staff-attendance queries do (16/95 overall, 1=Active, 2=Resigned/Terminated)."""
    if not (tables & {"Staff_Master", "EmployeeMaster", "EmployeeMasters",
                      "SubjectAllocation_Master", "StaffDepartmentMappings"}): return None
    ql = q.lower()
    if not any(k in ql for k in ("salary", "payroll", "staff attendance", "present staff",
                                 "active staff", "currently teaching", "working staff",
                                 "on duty", "staff present", "teacher present")): return None
    if _has(sql, r"\bStaffStatus_ID\b"): return None
    return Violation("STAFF-005", "HIGH",
        "Salary/attendance staff query omits StaffStatus_ID = 1 — resigned staff included.",
        "Add AND sm.StaffStatus_ID = 1 (1=Active, 2=Inactive/Resigned/Terminated). "
        "The ERP filters this in 100% of its salary and staff-attendance queries.", "Staff")

def r_fee026(sql, q, tables):
    """FEE-026 (codebase FEES-002/003): FeesCollectionData / MiscDetails
    paid queries must exclude zero-paid rows (Paid_Amt != 0; 83% / 21.5% of
    ERP queries respectively). Zero rows are placeholders, not payments."""
    if not (tables & {"FeesCollectionData", "FeesCollection_MiscDetails",
                      "FeesCollection_MiscellaneousDetails"}): return None
    ql = q.lower()
    if not any(k in ql for k in ("paid", "collected", "payment", "collection")): return None
    if _has(sql, r"Paid_Amt\s*(?:!=|<>)\s*0") or _has(sql, r"Paid_Amt\s*>\s*0"): return None
    return Violation("FEE-026", "MEDIUM",
        "Paid-amount query on collection details omits the zero-payment filter.",
        "Add AND Paid_Amt != 0 (or > 0) — zero-paid rows are placeholders and "
        "inflate row counts.", "Fees")

def r_leave001(sql, q, tables):
    """LEAVE-001 (codebase APPROVAL-002/003): leave queries must respect the
    approval status. LeaveApplicationStatusID: 2=Approved, 3=Cancelled/Rejected
    (67% of ERP queries); LeaveEntryMasters.LeaveStatus_ID = 1 (75%)."""
    ql = q.lower()
    if "leave" not in ql: return None
    if tables & {"LeaveApplicationEntries", "LeaveApplicationEntry"}:
        if not _has(sql, r"\bLeaveApplicationStatusID\b"):
            return Violation("LEAVE-001", "HIGH",
                "Leave query omits the application-status filter — cancelled/rejected leave included.",
                "Add AND LeaveApplicationStatusID = 2 for approved leave "
                "(2=Approved, 3=Cancelled/Rejected), or != 3 to exclude only cancelled.", "Staff")
    if tables & {"LeaveEntryMasters", "LeaveEntryMaster"}:
        if not _has(sql, r"\bLeaveStatus_ID\b"):
            return Violation("LEAVE-001", "HIGH",
                "Leave query omits the leave-status filter — inactive leave entries included.",
                "Add AND LeaveStatus_ID = 1 (Active/Approved) — 75% of the ERP's "
                "own leave queries filter this.", "Staff")
    return None

def r_vis001(sql, q, tables):
    """VIS-001 (codebase VISIBILITY-001): SubjectWiseHierarchyList rows the
    school has hidden must be excluded — Visibility = 1 in 86% of ERP queries."""
    if "SubjectWiseHierarchyList" not in tables: return None
    if _has(sql, r"\bVisibility\s*=\s*1\b"): return None
    return Violation("VIS-001", "MEDIUM",
        "Evaluation-item query omits the Visibility = 1 filter (86% of ERP queries include it).",
        "Add AND swhl.Visibility = 1 so hidden evaluation items are not shown "
        "or counted.", "Examinations")

def r_hier001(sql, q, tables):
    """HIER-001 (codebase HIERARCHY-001): root-level evaluation queries must
    filter MasterRefID = 0 (31% of ERP queries — used whenever roots, not
    child nodes, are wanted)."""
    if "EvaluationHierarchyList" not in tables: return None
    ql = q.lower()
    if not any(k in ql for k in ("root", "top level", "top-level", "top level",
                                 "main evaluation", "parent evaluation")): return None
    if _has(sql, r"\bMasterRefID\s*=\s*0\b"): return None
    return Violation("HIER-001", "MEDIUM",
        "Root-node evaluation query omits MasterRefID = 0 — child nodes returned as roots.",
        "Add AND ehl.MasterRefID = 0 to select only root evaluation nodes "
        "(child nodes reference their parent via MasterRefID).", "Examinations")

def r_pc001(sql, q, tables):
    """PC-001 (codebase HIERARCHY-002): subject-wise progress-card totals
    must filter ParentSubjectID = 0 — 35% of ERP queries; without it,
    sub-subjects are double-counted in totals."""
    if "ProgressCardMarksDetails" not in tables: return None
    ql = q.lower()
    if not any(k in ql for k in ("subject wise", "subject-wise", "per subject",
                                 "subject totals", "total marks per subject")): return None
    if _has(sql, r"\bParentSubjectID\s*=\s*0\b"): return None
    return Violation("PC-001", "MEDIUM",
        "Subject-wise totals omit ParentSubjectID = 0 — sub-subjects double-counted.",
        "Add AND pcmd.ParentSubjectID = 0 (35% of the ERP's own progress-card "
        "queries filter this) so sub-subject rows are not double-counted.", "Examinations")

def r_staff006(sql, q, tables):
    """STAFF-006 (codebase class-teacher filter): 'class teacher' questions
    must use SubjectAllocation_Master.IsClassTeacher = 1 — 46% of ERP queries;
    the canonical class-teacher template (T-103)."""
    ql = q.lower()
    if not any(k in ql for k in ("class teacher", "class teachers", "class-teacher")):
        return None
    if not (tables & {"SubjectAllocation_Master", "SubjectAllocationMaster"}): return None
    if _has(sql, r"\bIsClassTeacher\s*=\s*1\b"): return None
    return Violation("STAFF-006", "HIGH",
        "Class-teacher query omits IsClassTeacher = 1 — every subject teacher returned.",
        "Add AND sam.IsClassTeacher = 1 on SubjectAllocation_Master — that flag "
        "marks the class teacher (46% of the ERP's own queries filter it).", "Staff")

# ── HINT MAP (for retry prompts) ─────────────────────────────────────────────
# Lookup: (hallucinated table or column, optional owning table) → the correct
# approach. Used by the orchestrator's retry path so the model gets the RIGHT
# path instead of guessing again (PRODUCTION_TRACE_OBSERVATIONS §8).

HINT_MAP: Dict[tuple, str] = {
    ("FeesCollection", "IsPreAdmissionFee"):
        "Pre-admission fees are in ProspectusFeesCollection, not FeesCollection. "
        "Use ProspectusFeesCollection with ApplicationNo.",
    ("ClassMaster", "ClassName"):
        "ClassMaster.Name is the class-name column (not ClassName).",
    ("FeesCollection_Details", "IsIncludedInLumpSum"):
        "IsIncludedInLumpSum is on FeesInformationStudentDetail, not FeesCollection_Details.",
    ("StudentMarkDetails", "MinMark"):
        "MinMark is on ExamConfigurationEvaluationDetails (the exam-config table). JOIN it.",
    ("StudentMarkDetails", "SubjectID"):
        "StudentMarkDetails has no SubjectID. Join via ExamConfigurationEvaluationDetails "
        "(EvalHierID) to reach the subject.",
    ("StudentMarkMaster", "Term_Name"):
        "StudentMarkMaster has no Term_Name. JOIN ExamTypeMaster etm ON etm.ID = "
        "smm.ExamTypeID, then ExamTermMaster et ON et.ID = etm.TermID.",
    ("StudentAcademicDetail", "IsReportSubmitted"):
        "Report-card status is not on StudentAcademicDetail. Use the progress-card / "
        "report-card tables (dev-team ask 3.5 pending).",
    ("Subject_Master", "ExamTypeID"):
        "Subject_Master has no ExamTypeID. The subject-exam link is via "
        "SubjectAllocation_Master / exam-config tables.",
    ("FeesCollection_Details", "Fees_Head_Name"):
        "FeesCollection_Details has Fees_Head_ID (numeric). JOIN Fees_Master fm ON "
        "fcd.Fees_Head_ID = fm.ID and SELECT fm.Name.",
    ("GeneralFeedback", None):
        "GeneralFeedback does not exist. Use FeedbackTicket for feedback queries.",
    ("EmployeeMaster", None):
        "For staff questions use Staff_Master (EmployeeMaster is the payroll twin).",
    ("FeedbackParentStudent", None):
        "FeedbackParentStudent is not the live table. Use FeedbackTicket.",
    ("StudentAcademicDetail", "IsBonafide"):
        "There is no IsBonafide column (dev-team ask 3.5 pending).",
}

def lookup_hints(sql: str) -> List[str]:
    """Return every hint whose (table, column) pair appears in the SQL.
    Used to enrich retry prompts with the CORRECT approach."""
    hints = []
    for (tbl, col), text in HINT_MAP.items():
        if col is None:
            if re.search(rf"\b{re.escape(tbl)}\b", sql, re.IGNORECASE):
                hints.append(text)
        else:
            if re.search(rf"\b{re.escape(tbl)}\b", sql, re.IGNORECASE) and \
               re.search(rf"\b{re.escape(col)}\b", sql, re.IGNORECASE):
                hints.append(text)
    return hints

# ── Registry ─────────────────────────────────────────────────────────────────

RULES: List[Callable] = [
    r_fee001, r_fee004, r_fee005, r_fee006, r_fee007, r_fee009, r_fee011,
    r_fee013, r_fee014, r_fee019, r_fee022,
    r_exam001, r_exam002, r_exam003, r_exam004, r_exam006, r_exam007,
    r_stud001, r_stud004, r_stud005, r_stud006,
    r_staff002, r_staff003,
    r_adm001, r_adm002,
    r_deprecated, r_sensitive, r_rbac001, r_rbac_salary, r_trans001,
    r_multistmt, r_writeverb,
    # ── 2026-09-04: ERP codebase-analysis incorporation (rules 33-54) ──
    r_staff004, r_feedback001, r_fee023, r_fee024, r_fee025,
    r_comm001, r_att001, r_compare001, r_classname001,
    r_bonafide001, r_preadm001, r_reportcard001,
    r_softdel101, r_softdel102, r_stud007, r_staff005, r_fee026,
    r_leave001, r_vis001, r_hier001, r_pc001, r_staff006,
]

RULE_META: Dict[str, Dict[str, str]] = {
    "FEE-001": {"title": "Missing Lien_Amount in outstanding formula", "catalog_ref": "FEE-001"},
    "FEE-004": {"title": "Missing IsIncludedInLumpSum filter", "catalog_ref": "FEE-004"},
    "FEE-005": {"title": "Missing Structure_Type filter", "catalog_ref": "FEE-005"},
    "FEE-006": {"title": "Fee query joins ExamTermMaster (wrong term master)", "catalog_ref": "FEE-006"},
    "FEE-007": {"title": "Missing or hardcoded AcademicYearID filter", "catalog_ref": "FEE-007"},
    "FEE-009": {"title": "Missing TC-issued student filter", "catalog_ref": "FEE-009"},
    "FEE-011": {"title": "Missing ChequeStatus_ID filter on FeesCollection", "catalog_ref": "FEE-011"},
    "FEE-013": {"title": "Wrong date window for current-term fee", "catalog_ref": "FEE-013"},
    "FEE-014": {"title": "Missing IsBusFee=1 filter for bus-fee queries", "catalog_ref": "FEE-014"},
    "FEE-019": {"title": "Nonexistent 'Amt' column on FeesCollection", "catalog_ref": "FEE-019"},
    "FEE-022": {"title": "Missing IsDonation=0 filter for academic fees", "catalog_ref": "FEE-022"},
    "EXAM-001": {"title": "ExamTypeMaster.TermID joined to TermMaster (wrong)", "catalog_ref": "EXAM-001"},
    "EXAM-002": {"title": "ExamTermMaster uses IsDeleted (should be Deleted)", "catalog_ref": "EXAM-002"},
    "EXAM-003": {"title": "ExamTermMaster uses StartingDate/EndingDate (wrong)", "catalog_ref": "EXAM-003"},
    "EXAM-004": {"title": "Get_TermList called for fee-term lookup (name trap)", "catalog_ref": "EXAM-004"},
    "EXAM-006": {"title": "MinMark hallucinated on marks table (lives on exam-config)", "catalog_ref": "EXAM-006"},
    "EXAM-007": {"title": "Marks query missing exam-term filter (ExamTypeMaster→ExamTermMaster)", "catalog_ref": "EXAM-007"},
    "STUD-001": {"title": "Student_Master.ClassID/SectionID/AcademicYearID (nonexistent)", "catalog_ref": "STUD-001"},
    "STUD-004": {"title": "Academic year via YEAR(GETDATE()) (crosses calendar boundary)", "catalog_ref": "STUD-004"},
    "STUD-005": {"title": "Student query missing AcademicYearID filter", "catalog_ref": "STUD-005"},
    "STUD-006": {"title": "Subject_Master joined on BranchID (cartesian product)", "catalog_ref": "STUD-006"},
    "STAFF-002": {"title": "Staff_Master.FirstName (should be Staff_FirstName)", "catalog_ref": "STAFF-002"},
    "STAFF-003": {"title": "Active-staff query missing StaffStatus_ID=1", "catalog_ref": "STAFF-003"},
    "ADM-001": {"title": "ProspectusFeesCollection linked via Student_ID (wrong)", "catalog_ref": "ADM-001"},
    "ADM-002": {"title": "EnquiryMaster is deprecated", "catalog_ref": "ADM-002"},
    "DEPRECATED": {"title": "Deprecated table used", "catalog_ref": "DEPRECATED-*"},
    "DEPRECATED-004": {"title": "BusFeeStructure (wrong spelling)", "catalog_ref": "DEPRECATED-004"},
    "SENSITIVE-TABLE": {"title": "Sensitive table queried", "catalog_ref": "RBAC sensitive"},
    "SENSITIVE-COL": {"title": "Sensitive column selected", "catalog_ref": "RBAC sensitive"},
    "RBAC-001": {"title": "Branch scoping missing super-user UNION", "catalog_ref": "RBAC-001"},
    "RBAC-SALARY": {"title": "Salary query missing branch scoping", "catalog_ref": "RBAC salary"},
    "TRANS-001": {"title": "BusFeeStructure (wrong spelling)", "catalog_ref": "TRANS-001"},
    "MULTI-STMT": {"title": "Multiple SQL statements", "catalog_ref": "Structure"},
    "WRITE-VERB": {"title": "Write verb in read-only service", "catalog_ref": "Structure"},
    # ── 2026-09-04 additions (ERP codebase analysis + production trace) ──
    "STAFF-004": {"title": "Staff question on EmployeeMaster (payroll twin)", "catalog_ref": "Trace §7"},
    "FEEDBACK-001": {"title": "Feedback question on a non-live table", "catalog_ref": "Trace §7"},
    "FEE-023": {"title": "IsIncludedInLumpSum on FeesCollection_Details (wrong table)", "catalog_ref": "Trace §7"},
    "FEE-024": {"title": "Fee-head question grouped by fee GROUP", "catalog_ref": "Trace §7"},
    "FEE-025": {"title": "Numeric ID returned without master-table name JOIN", "catalog_ref": "Trace §7/§22"},
    "COMM-001": {"title": "Message query on GeneralCallRegister (enquiries)", "catalog_ref": "Trace §7"},
    "ATT-001": {"title": "'Not marked' attendance via status filter (needs NOT EXISTS)", "catalog_ref": "Trace §7"},
    "COMPARE-001": {"title": "Compare X vs Y returned as one merged result", "catalog_ref": "Trace §7"},
    "CLASSNAME-001": {"title": "ClassMaster.ClassName (should be Name)", "catalog_ref": "Trace §7"},
    "BONAFIDE-001": {"title": "Hallucinated IsBonafide column", "catalog_ref": "Trace §7 / ask 3.5"},
    "PREADM-001": {"title": "Hallucinated IsPreAdmissionFee (use ProspectusFeesCollection)", "catalog_ref": "Trace §7"},
    "REPORTCARD-001": {"title": "Hallucinated IsReportSubmitted column", "catalog_ref": "Trace §7 / ask 3.5"},
    "SOFTDEL-101": {"title": "Always-filtered table queried without IsDeleted", "catalog_ref": "Filters A"},
    "SOFTDEL-102": {"title": "Holiday query omits IsDeleted", "catalog_ref": "Filters A"},
    "STUD-007": {"title": "Student count omits TC-issued filter", "catalog_ref": "Filters B"},
    "STAFF-005": {"title": "Salary/attendance query omits StaffStatus_ID=1", "catalog_ref": "Filters D"},
    "FEE-026": {"title": "Paid query omits zero-payment filter", "catalog_ref": "Filters E"},
    "LEAVE-001": {"title": "Leave query omits approval status", "catalog_ref": "Filters F"},
    "VIS-001": {"title": "Evaluation items omit Visibility=1", "catalog_ref": "Filters G"},
    "HIER-001": {"title": "Root-node query omits MasterRefID=0", "catalog_ref": "Filters G"},
    "PC-001": {"title": "Subject-wise totals omit ParentSubjectID=0", "catalog_ref": "Filters G"},
    "STAFF-006": {"title": "Class-teacher query omits IsClassTeacher=1", "catalog_ref": "Filters D"},
}

def check_sql(sql: str, question: str = "") -> List[Violation]:
    if not sql or not sql.strip():
        return [Violation("EMPTY", "HIGH", "No SQL generated.",
                         "The model produced no output.", "Structure")]
    tables = _tables(sql)
    violations = []
    for rule_fn in RULES:
        try:
            v = rule_fn(sql, question, tables)
            if v: violations.append(v)
        except Exception as e:
            violations.append(Violation("ENGINE-ERR", "MEDIUM",
                f"Rule {rule_fn.__name__} crashed: {e}",
                "Report this to the rules engine maintainer.", "Engine"))
    return violations

def rule_count() -> int:
    return len(RULES)

if __name__ == "__main__":
    tests = [
        ("LIVE TRACE: passed maths term 1 (5 bugs)",
         "SELECT COUNT(DISTINCT smd.StudentID) AS PassedStudents FROM StudentMarkDetails smd "
         "INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID "
         "INNER JOIN Subject_Master s ON s.BranchID = smd.BranchID "
         "WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID=@UserId) "
         "AND smd.Deleted = 0 AND smm.Deleted = 0 AND s.Name = 'Maths' AND s.IsDeleted = 0 "
         "AND smd.Marks >= smd.MinMark",
         "how many students passed maths in term 1?"),
        ("CORRECTED marks query (should pass)",
         "SELECT COUNT(DISTINCT smd.StudentID) AS PassedStudents FROM StudentMarkDetails smd "
         "INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID "
         "INNER JOIN ExamTypeMaster etm ON etm.ID = smm.ExamTypeID "
         "INNER JOIN ExamTermMaster et ON et.ID = etm.TermID AND et.Name LIKE '%Term 1%' "
         "INNER JOIN ExamConfigurationEvaluationDetails eced ON eced.ID = smd.EvalHierID "
         "INNER JOIN Subject_Master s ON s.Id = eced.SubjectID "
         "WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID=@UserId "
         "UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID=@UserId AND IsSuperUser=1)) "
         "AND smd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date) "
         "AND smd.Deleted = 0 AND smm.Deleted = 0 AND s.Name = 'Maths' AND s.IsDeleted = 0 "
         "AND smd.Marks >= eced.MinMark",
         "how many students passed maths in term 1?"),
        ("Fee query using TermMaster correctly (should NOT fire EXAM-007)",
         "SELECT SUM(Paid_Amt) FROM FeesCollection_Details fcd "
         "JOIN TermMaster tm ON tm.ID = fcd.Term_ID WHERE tm.Name LIKE '%Term 1%' "
         "AND fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID=@UserId)",
         "paid fees for term 1"),
        # ── 2026-09-04: new-rule tests (rules 33-54) ─────────────────────
        ("NEW: staff query on EmployeeMaster (STAFF-004 should fire)",
         "SELECT COUNT(*) FROM EmployeeMaster em WHERE em.BranchID IN "
         "(SELECT BranchID FROM UserAccountRoleDetails WHERE UserID=@UserId)",
         "how many teachers are there"),
        ("NEW: feedback on GeneralFeedback (FEEDBACK-001 should fire)",
         "SELECT COUNT(*) FROM GeneralFeedback gf WHERE gf.BranchID IN "
         "(SELECT BranchID FROM UserAccountRoleDetails WHERE UserID=@UserId)",
         "how many feedback tickets from parents"),
        ("NEW: count without TC filter (STUD-007 should fire)",
         "SELECT COUNT(DISTINCT sad.StudentID) AS Cnt FROM StudentAcademicDetail sad "
         "JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE cm.Name = '10' "
         "AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date) "
         "AND sad.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID=@UserId)",
         "how many students are there in class 10"),
        ("NEW: count WITH TC filter (STUD-007 should pass)",
         "SELECT COUNT(DISTINCT sad.StudentID) AS Cnt FROM StudentAcademicDetail sad "
         "JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE cm.Name = '10' "
         "AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) "
         "AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date) "
         "AND sad.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID=@UserId)",
         "how many students are there in class 10"),
        ("NEW: holiday list without IsDeleted (SOFTDEL-102 should fire)",
         "SELECT hm.Name, hm.From_Date, hm.To_Date FROM HolidayMaster hm "
         "WHERE hm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID=@UserId)",
         "list all holidays this year"),
        ("NEW: class teacher without flag (STAFF-006 should fire)",
         "SELECT sm.Staff_FirstName, sm.Staff_LastName FROM SubjectAllocation_Master sam "
         "JOIN Staff_Master sm ON sam.Staff_ID = sm.Staff_ID "
         "WHERE sam.Class_ID = 10 AND sam.BranchID IN "
         "(SELECT BranchID FROM UserAccountRoleDetails WHERE UserID=@UserId)",
         "who is the class teacher of 10 A"),
        ("NEW: salary without StaffStatus (STAFF-005 should fire)",
         "SELECT COUNT(*) FROM Staff_Master sm WHERE sm.BranchID IN "
         "(SELECT BranchID FROM UserAccountRoleDetails WHERE UserID=@UserId)",
         "how many staff are on the payroll this month"),
        ("NEW: ClassMaster.ClassName (CLASSNAME-001 should fire)",
         "SELECT cm.ClassName, COUNT(DISTINCT sad.StudentID) AS Cnt FROM StudentAcademicDetail sad "
         "JOIN ClassMaster cm ON sad.ClassID = cm.ID "
         "WHERE (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) "
         "AND sad.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID=@UserId) "
         "GROUP BY cm.ClassName",
         "class-wise student count"),
        ("NEW: messages via GeneralCallRegister (COMM-001 should fire)",
         "SELECT COUNT(*) FROM GeneralCallRegister gcr "
         "WHERE gcr.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID=@UserId)",
         "how many messages were sent to parents this week"),
        ("NEW: not-marked via status filter (ATT-001 should fire)",
         "SELECT COUNT(*) FROM StudentAttendance sa "
         "WHERE sa.Attendance_Status_ID = 9 AND sa.Attendance_Date = GETDATE() "
         "AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID=@UserId)",
         "which classes have attendance not marked today"),
        ("NEW: IsPreAdmissionFee hallucination (PREADM-001 should fire)",
         "SELECT SUM(fc.Receipt_Amt) FROM FeesCollection fc "
         "WHERE fc.IsPreAdmissionFee = 1 AND fc.ChequeStatus_ID NOT IN (3,4) "
         "AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID=@UserId)",
         "how much pre admission fee did we collect"),
    ]
    for label, sql, q in tests:
        print(f"\n=== {label} ===")
        vs = check_sql(sql, q)
        if not vs:
            print("  PASS (no violations)")
        else:
            for v in vs:
                print(f"  {v}")
                if v.suggested_fix:
                    print(f"    FIX: {v.suggested_fix[:150]}")
    print(f"\nrule_count() = {rule_count()}")

"""
Schema-validation guardrail for the ChaloSchools AI Secretary.

Parses a generated T-SQL query, extracts every table/alias and every
alias.column reference, and checks each against the real schema catalog.
Catches hallucinated tables and columns deterministically — independent of
model quality — before the query ever reaches the database.

Known limitations (by design, not oversights — see README notes at bottom):
  - Does not validate columns inside CTEs' own SELECT lists against their
    source tables recursively; it treats a CTE name as a valid pseudo-table
    once declared, but doesn't verify the CTE's own body.
  - Does not resolve bare (unqualified) column references — those are
    skipped rather than guessed at, to avoid false positives in multi-table
    queries where a bare column could belong to any joined table.
  - Does not evaluate subquery-local aliases separately from the outer
    query's alias scope in deeply nested queries (single flat scope is
    used) — sufficient for the query patterns seen in this project so far,
    but not a full SQL scope resolver.
  - Handles multi-CTE WITH clauses (WITH a AS (...), b AS (...), c AS (...))
    and SQL Server system objects (master.dbo.spt_values, sys.*,
    INFORMATION_SCHEMA.*) as of the second validation round against the
    full v5 dataset — both were found as false-positive sources and fixed.
  - KNOWN BLIND SPOT: the bare-column check allows any column name that
    exists on UserAccountRoleDetails or Branch_Academic_Details (the
    near-universal branch/year-scoping subquery tables) even when the bare
    reference is actually in the OUTER table's scope, not the subquery's.
    Confirmed concretely: UserAccountRoleDetails has its own real StaffID
    column, so a query wrongly referencing bare "StaffID" against, say,
    StaffDepartmentMaster (which has no such column) will NOT be flagged,
    because StaffID is valid somewhere in the query overall. This is a
    narrow, specific gap (only affects names colliding with
    branchid/userid/roleid/isprimary/id/staffid), not a general failure —
    fixing it properly requires real paren-depth scope tracking, which is
    out of scope for a regex-based approach. Flagging honestly rather than
    claiming full coverage.
"""

import re
import json
from dataclasses import dataclass, field


with open('schema_catalog.json', encoding='utf-8') as f:
    SCHEMA_CATALOG = json.load(f)

# case-insensitive lookup: lowercase table name -> (real name, columns set)
_CATALOG_CI = {name.lower(): (name, set(c.lower() for c in cols)) for name, cols in SCHEMA_CATALOG.items()}


@dataclass
class ValidationIssue:
    kind: str          # "unknown_table" | "unknown_column"
    detail: str         # human-readable description


@dataclass
class ValidationResult:
    is_valid: bool
    issues: list = field(default_factory=list)
    tables_found: dict = field(default_factory=dict)   # alias -> real table name

    def summary(self):
        if self.is_valid:
            return "PASS — no unknown tables or columns detected."
        lines = [f"FAIL — {len(self.issues)} issue(s) found:"]
        for i in self.issues:
            lines.append(f"  [{i.kind}] {i.detail}")
        return "\n".join(lines)


# CTE names get treated as valid pseudo-tables once declared (their own
# body isn't recursively checked — see module docstring).
_CTE_PATTERN = re.compile(r"(?:\bWITH\s+|,\s*)(\w+)\s+AS\s*\(", re.IGNORECASE)

# FROM/JOIN TableName [AS] alias — alias is optional; if omitted, the alias
# IS the table name (SQL allows referencing sm.Col even when FROM sm has no
# explicit AS, as long as "sm" was itself the table name... but T-SQL
# actually requires either using the real table name or the given alias,
# not both once an alias exists. We handle both cases: explicit alias, or
# no alias at all (bare table name usable as its own qualifier).
_FROM_JOIN_PATTERN = re.compile(
    r"\b(?:FROM|JOIN)\s+(?:\[?dbo\]?\.)?\[?(\w+)\]?\s*(?:AS\s+)?(\w+)?",
    re.IGNORECASE
)

# alias.Column or TableName.Column references anywhere in the query.
# Deliberately excludes anything immediately followed by "(" (function
# calls like dbo.SomeFunction(...) aren't column references).
_ALIAS_COLUMN_PATTERN = re.compile(r"\b(\w+)\.(\w+)\b(?!\s*\()")

# SQL keywords/functions that can precede a dot-like pattern but aren't
# real table aliases (e.g. "GETDATE()" isn't matched by the pattern above
# since it requires a dot, but guard against reserved words appearing as
# a false "alias" in edge cases)
_RESERVED_NOT_ALIASES = {
    "select", "from", "where", "group", "order", "having", "and", "or",
    "not", "in", "is", "null", "as", "on", "join", "inner", "left",
    "right", "outer", "cross", "apply", "case", "when", "then", "else",
    "end", "top", "distinct", "union", "all", "with", "cast", "sum",
    "count", "avg", "min", "max", "isnull", "getdate", "dateadd",
    "datediff", "datepart", "datename", "cast", "convert", "over",
    "partition", "by", "format", "month", "year", "day",
}


def _strip_cte_headers(sql: str):
    """Returns the set of CTE names declared via WITH ... AS (...)."""
    return set(m.group(1).lower() for m in _CTE_PATTERN.finditer(sql))


def validate_sql(sql: str) -> ValidationResult:
    issues = []
    cte_names = _strip_cte_headers(sql)

    # SQL Server system objects (master.dbo.spt_values, sys.*, etc.) are
    # legitimately outside the V3_CHALO schema catalog — they're built-in
    # engine objects, not application tables. Register any such reference
    # (and its alias, if given) as known/skip-validated before the main
    # FROM/JOIN parsing loop, so they're never flagged as unknown.
    system_object_pattern = re.compile(
        r"\b(?:FROM|JOIN)\s+(master\.dbo\.\w+|sys\.\w+|INFORMATION_SCHEMA\.\w+)\s*(?:AS\s+)?(\w+)?",
        re.IGNORECASE
    )
    system_aliases = {}
    for m in system_object_pattern.finditer(sql):
        full_ref, alias = m.group(1), m.group(2)
        # register every segment (e.g. "master", "dbo", "spt_values" for
        # master.dbo.spt_values) since the generic FROM/JOIN pattern used
        # below may only capture the first segment (stops at the first dot)
        for segment in full_ref.lower().split('.'):
            system_aliases[segment] = None
        if alias and alias.lower() not in _RESERVED_NOT_ALIASES:
            system_aliases[alias.lower()] = None

    # Build alias -> real_table map from every FROM/JOIN in the query
    alias_map = dict(system_aliases)
    for m in _FROM_JOIN_PATTERN.finditer(sql):
        table_name, alias = m.group(1), m.group(2)
        table_lower = table_name.lower()

        if table_lower in system_aliases or (alias and alias.lower() in system_aliases):
            continue  # already handled above as a system object

        if table_lower in cte_names:
            # It's a CTE reference, not a real schema table — register
            # the CTE name (and its alias, if any) as "known", but skip
            # column validation for it (see module docstring).
            alias_map[table_lower] = None
            if alias and alias.lower() not in _RESERVED_NOT_ALIASES:
                alias_map[alias.lower()] = None
            continue

        if table_lower not in _CATALOG_CI:
            issues.append(ValidationIssue(
                "unknown_table",
                f"Table '{table_name}' does not exist in the schema."
            ))
            continue

        real_name, _cols = _CATALOG_CI[table_lower]
        # register both the alias (if given) and the table's own name as
        # valid qualifiers, matching how SQL Server actually resolves this
        alias_map[table_lower] = real_name
        if alias and alias.lower() not in _RESERVED_NOT_ALIASES:
            alias_map[alias.lower()] = real_name

    # Now check every alias.column reference against the resolved table
    for m in _ALIAS_COLUMN_PATTERN.finditer(sql):
        qualifier, column = m.group(1), m.group(2)
        qualifier_lower = qualifier.lower()

        if qualifier_lower in _RESERVED_NOT_ALIASES:
            continue
        if qualifier.startswith('@'):
            continue  # parameter, not a table qualifier
        if qualifier_lower not in alias_map:
            # Not a table/alias we recognized from FROM/JOIN in this query
            # — could be a schema prefix like "dbo" used oddly, or a false
            # positive from the regex. Skip rather than false-flag.
            continue

        real_table = alias_map[qualifier_lower]
        if real_table is None:
            continue  # CTE — not validated (see module docstring)

        _real_name, cols = _CATALOG_CI[real_table.lower()]
        if column.lower() not in cols:
            issues.append(ValidationIssue(
                "unknown_column",
                f"Column '{column}' does not exist on table '{real_table}' (referenced as '{qualifier}.{column}')."
            ))

    # Bare (unqualified) column check — only attempted when the query
    # references exactly ONE real schema table (excluding CTEs), since a
    # bare column in a multi-table query is genuinely ambiguous and
    # guessing which table it belongs to risks false positives. This
    # covers a real, common case from this project's findings (e.g.
    # "SELECT StaffID FROM StaffDepartmentMaster WHERE DepartmentName = ...").
    # UserAccountRoleDetails and Branch_Academic_Details appear as nested
    # branch/year-scoping subqueries in nearly every query in this project
    # — they're structural boilerplate, not part of what the user actually
    # asked about, so they're excluded when deciding if a query is
    # "single-table" for the purpose of safely checking bare columns.
    _SCOPING_BOILERPLATE = {"useraccountroledetails", "branch_academic_details"}
    real_tables_referenced = set(
        v for v in alias_map.values()
        if v is not None and v.lower() not in _SCOPING_BOILERPLATE
    )
    if len(real_tables_referenced) == 1 and not system_aliases:
        # system_aliases non-empty means a SQL Server system object
        # (master.dbo.spt_values etc.) is present — that's a signal this
        # query has a genuinely different, unresolvable inner scope (e.g. a
        # derived table), which the simple bare-column heuristic below
        # isn't equipped to reason about (see module docstring on subquery
        # scope). Skip rather than risk checking a bare column against the
        # wrong table's columns.
        only_table = next(iter(real_tables_referenced))
        _real_name, cols = _CATALOG_CI[only_table.lower()]
        # Also allow columns belonging to the excluded boilerplate tables —
        # our simple regex isn't scope-aware, so a bare column appearing
        # inside e.g. "(SELECT BranchID FROM UserAccountRoleDetails WHERE
        # UserID = @UserId)" would otherwise be wrongly checked against the
        # OUTER table instead of the subquery's own table.
        for boilerplate_table in _SCOPING_BOILERPLATE:
            if boilerplate_table in _CATALOG_CI:
                _bp_name, bp_cols = _CATALOG_CI[boilerplate_table]
                cols = cols | bp_cols
        known_aliases = set(alias_map.keys())

        # Output aliases (from "... AS SomeAlias" anywhere in the SELECT
        # list) are valid to reference in ORDER BY / GROUP BY even though
        # they're not real table columns — collect them so they're not
        # wrongly flagged.
        output_aliases = set(
            a.lower() for a in re.findall(r"\bAS\s+(\w+)", sql, re.IGNORECASE)
        )

        bare_col_pattern = re.compile(
            r"(?:SELECT|WHERE|AND|OR|,|\bBY\b)\s+(\w+)\s*(?:=|,|>|<|\bIS\b|\bIN\b|\bLIKE\b|\bASC\b|\bDESC\b|\bFROM\b|$)",
            re.IGNORECASE
        )
        for m in bare_col_pattern.finditer(sql):
            candidate = m.group(1)
            candidate_lower = candidate.lower()
            if candidate_lower in _RESERVED_NOT_ALIASES or candidate_lower in known_aliases:
                continue
            if candidate_lower in output_aliases:
                continue
            if candidate.startswith('@'):
                continue
            if candidate.isdigit():
                continue  # numeric literal (e.g. inside DATEADD(HOUR, 4, ...)), not a column
            if candidate_lower not in cols:
                issues.append(ValidationIssue(
                    "unknown_column",
                    f"Column '{candidate}' does not exist on table '{only_table}' (unqualified reference, single-table query)."
                ))

    return ValidationResult(is_valid=(len(issues) == 0), issues=issues, tables_found=alias_map)

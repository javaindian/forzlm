"""
prepare_data.py — Prepare the AI Secretary training data for fine-tuning.

What it does:
  1. Reads data/training_dataset_final_v8.jsonl  (instruction / input / output)
  2. Shuffles (seeded) and splits into train / validation (default 92% / 8%)
  3. Writes train.jsonl and val.jsonl into the finetune/ folder
  4. Writes a DATASET_VERSION.txt alongside them, recording which dataset
     version produced this train/val split — so any trained checkpoint can
     always be traced back to the exact dataset it came from.

The validation set is your quality gate — after training, the model is checked
against it so you can measure accuracy before deploying (see MODEL_UPDATE_WORKFLOW.md
"Golden Test Set").

Run:  python prepare_data.py
"""
import json
import os
import random

# ── Version — update this each time you point SOURCE at a new dataset ───────
DATASET_VERSION = "v25"

# ── Paths (relative to project root D:\AI Secretary) ────────────────────────
HERE = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(HERE)
SOURCE = os.path.join(PROJECT_ROOT, "data", f"training_dataset_final_{DATASET_VERSION}.jsonl")
TRAIN_OUT = os.path.join(HERE, "train_v25.jsonl")
VAL_OUT = os.path.join(HERE, "val_v25.jsonl")
VERSION_OUT = os.path.join(HERE, "DATASET_VERSION.txt")

VAL_FRACTION = 0.08     # 8% held out for validation
SEED = 42               # reproducible split


def main():
    if not os.path.exists(SOURCE):
        raise FileNotFoundError(
            f"Can't find {SOURCE} — place the dataset there, or update "
            f"DATASET_VERSION at the top of this script to match the file "
            f"you actually have."
        )

    with open(SOURCE, encoding="utf-8") as f:
        pairs = [json.loads(line) for line in f if line.strip()]

    print(f"Dataset version: {DATASET_VERSION}")
    print(f"Loaded {len(pairs)} pairs from {SOURCE}")

    random.seed(SEED)
    random.shuffle(pairs)

    n_val = max(1, int(len(pairs) * VAL_FRACTION))
    val = pairs[:n_val]
    train = pairs[n_val:]

    with open(TRAIN_OUT, "w", encoding="utf-8") as f:
        for p in train:
            f.write(json.dumps(p, ensure_ascii=False) + "\n")
    with open(VAL_OUT, "w", encoding="utf-8") as f:
        for p in val:
            f.write(json.dumps(p, ensure_ascii=False) + "\n")

    # Traceability: record exactly which dataset version this train/val
    # split came from, so a trained checkpoint's origin is never ambiguous.
    with open(VERSION_OUT, "w", encoding="utf-8") as f:
        f.write(f"DATASET_VERSION={DATASET_VERSION}\n")
        f.write(f"SOURCE={SOURCE}\n")
        f.write(f"TOTAL_PAIRS={len(pairs)}\n")
        f.write(f"TRAIN_PAIRS={len(train)}\n")
        f.write(f"VAL_PAIRS={len(val)}\n")
        f.write(f"SEED={SEED}\n")

    print(f"Train: {len(train)} pairs -> {TRAIN_OUT}")
    print(f"Val:   {len(val)} pairs -> {VAL_OUT}")
    print(f"Version record -> {VERSION_OUT}")


if __name__ == "__main__":
    main()

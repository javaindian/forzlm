#!/usr/bin/env python3
"""
validate_dataset.py — Run the semantic rules engine against a training dataset
and produce a full validation report (HTML + CSV + Markdown summary).

Usage:
    python validate_dataset.py [--dataset PATH] [--out-dir DIR]

Defaults:
    --dataset  /home/z/my-project/semantic_validation/reference_inputs/training_dataset_final_v27.jsonl
    --out-dir  /home/z/my-project/semantic_validation/output

Produces:
    {out-dir}/report.html          — interactive triage report (open in a browser)
    {out-dir}/violations.csv       — machine-readable, one row per violation
    {out-dir}/summary.md           — aggregate summary
    {out-dir}/dataset_version.txt  — provenance record
"""
from __future__ import annotations
import json, csv, os, sys, argparse, html
from collections import Counter, defaultdict
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from semantic_rules import check_sql, rule_count, RULE_META

# ── Module classifier (same as the audit script) ─────────────────────────────

MOD_KW = {
    "Fees": ["fee", "outstanding", "defaulters", "concession", "late fee", "lumpsum",
             "receipt", "invoice", "refund", "collection", "demand", "pending", "due"],
    "Students": ["student", "class ", "section", "roll no", "attendance", "tc",
                 "transfer certificate", "house", "id card", "promotion", "enrolled"],
    "Staff": ["staff", "teacher", "designation", "department", "observation",
              "principal", "class teacher"],
    "Admissions": ["admission", "prospectus", "application", "applicant", "enquiry",
                    "enquired", "call register", "lead", "follow up"],
    "Examinations": ["exam", "mark", "grade", "progress card", "rank", "result",
                     "hall ticket", "report card", "term test"],
    "Transport": ["transport", "bus", "route", "vehicle", "driver", "boarding point", "trip"],
    "Payroll": ["salary", "payroll", "pay slip", "payslip", "earning", "deduction",
                "allowance", "ad hoc"],
    "Inventory": ["inventory", "stock", "supplier", "goods receipt", "purchase request",
                  "item"],
    "Parent Feedback": ["feedback", "ticket", "complaint", "escalat", "parent portal"],
    "Circulars": ["circular"],
    "Home Works": ["homework", "home work", "assignment", "notes of lesson"],
    "Communication": ["sms", "whatsapp", "email", "notification", "message", "communication"],
    "Administration": ["branch", "school", "academic year", "holiday", "block",
                       "settings", "facility", "management app"],
}

def classify(q: str) -> str:
    ql = q.lower()
    scores = {m: sum(1 for k in kws if k in ql) for m, kws in MOD_KW.items()}
    best = max(scores.items(), key=lambda x: x[1])
    return best[0] if best[1] > 0 else "Other"

# ── HTML report template ────────────────────────────────────────────────────

def build_html(report: dict, examples: list) -> str:
    """Build a self-contained interactive HTML report."""
    total = report["total"]
    flagged = report["flagged"]
    clean = report["clean"]
    rule_counts = report["rule_counts"]
    module_breakdown = report["module_breakdown"]
    rule_by_module = report["rule_by_module"]

    # CSS
    css = """
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
           background: #f5f5f5; color: #222; line-height: 1.5; }
    .container { max-width: 1400px; margin: 0 auto; padding: 20px; }
    h1 { color: #1a1a1a; margin-bottom: 8px; }
    h2 { color: #333; margin: 24px 0 12px; border-bottom: 2px solid #ddd; padding-bottom: 6px; }
    .meta { color: #666; font-size: 14px; margin-bottom: 20px; }
    .summary-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
                    gap: 12px; margin-bottom: 24px; }
    .stat-card { background: white; padding: 16px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    .stat-card .num { font-size: 28px; font-weight: 700; }
    .stat-card .label { font-size: 13px; color: #666; margin-top: 4px; }
    .stat-card.high { border-left: 4px solid #dc2626; }
    .stat-card.medium { border-left: 4px solid #f59e0b; }
    .stat-card.clean { border-left: 4px solid #16a34a; }
    table { width: 100%; border-collapse: collapse; background: white; border-radius: 8px;
            overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    th { background: #1f2937; color: white; padding: 10px 12px; text-align: left; font-size: 13px;
         cursor: pointer; user-select: none; }
    th:hover { background: #374151; }
    td { padding: 10px 12px; border-bottom: 1px solid #eee; font-size: 13px; vertical-align: top; }
    tr:hover { background: #f9fafb; }
    .badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 11px;
             font-weight: 600; text-transform: uppercase; }
    .badge-high { background: #fee2e2; color: #991b1b; }
    .badge-medium { background: #fef3c7; color: #92400e; }
    .badge-clean { background: #d1fae5; color: #065f46; }
    .sql { font-family: 'SF Mono', Monaco, Consolas, monospace; font-size: 12px;
           background: #1e293b; color: #e2e8f0; padding: 12px; border-radius: 4px;
           white-space: pre-wrap; word-break: break-all; max-height: 200px; overflow-y: auto; }
    .fix { background: #ecfdf5; border-left: 3px solid #16a34a; padding: 8px 12px;
           margin-top: 6px; font-size: 12px; color: #065f46; }
    .question { font-weight: 500; color: #1e40af; }
    .filters { display: flex; gap: 12px; margin-bottom: 16px; flex-wrap: wrap; align-items: center; }
    .filters label { font-size: 13px; color: #555; }
    .filters select, .filters input { padding: 6px 10px; border: 1px solid #ccc; border-radius: 4px; font-size: 13px; }
    .row-detail { display: none; }
    .row-detail.show { display: table-row; }
    .toggle { cursor: pointer; color: #2563eb; font-size: 12px; user-select: none; }
    .toggle:hover { text-decoration: underline; }
    .footer { margin-top: 30px; padding: 16px; background: #1f2937; color: #9ca3af;
              border-radius: 8px; font-size: 12px; text-align: center; }
    .pct { color: #666; font-size: 12px; }
    """

    # JS for interactivity
    js = """
    function toggleRow(id) {
        const el = document.getElementById(id);
        el.classList.toggle('show');
    }
    function filterTable() {
        const module = document.getElementById('f-module').value;
        const rule = document.getElementById('f-rule').value;
        const sev = document.getElementById('f-sev').value;
        const search = document.getElementById('f-search').value.toLowerCase();
        const rows = document.querySelectorAll('tr.example-row');
        let visible = 0;
        rows.forEach(r => {
            const rm = r.dataset.module, rr = r.dataset.rule, rs = r.dataset.severity,
                  rq = r.dataset.question;
            const matchM = !module || rm === module;
            const matchR = !rule || rr === rule;
            const matchS = !sev || rs === sev;
            const matchQ = !search || rq.includes(search);
            if (matchM && matchR && matchS && matchQ) {
                r.style.display = ''; visible++;
            } else {
                r.style.display = 'none';
                // hide detail too
                const detail = document.getElementById('detail-' + r.id.replace('row-',''));
                if (detail) detail.classList.remove('show');
            }
        });
        document.getElementById('visible-count').textContent = visible + ' of ' + rows.length + ' shown';
    }
    """

    # Build rule filter options
    rule_options = "<option value=''>All rules</option>" + "".join(
        f"<option value='{rid}'>{rid}</option>" for rid, _ in sorted(rule_counts.items())
    )
    module_options = "<option value=''>All modules</option>" + "".join(
        f"<option value='{m}'>{m}</option>" for m in sorted(module_breakdown.keys())
    )
    sev_options = "<option value=''>All severities</option>" \
                  "<option value='HIGH'>HIGH</option><option value='MEDIUM'>MEDIUM</option>"

    # Build example rows
    rows_html = ""
    for ex in examples:
        rid = ex["line"]
        row_id = f"row-{rid}"
        detail_id = f"detail-{rid}"
        sev_badge = "badge-high" if ex["severity"] == "HIGH" else "badge-medium"
        violations_html = "<br>".join(
            f"<span class='badge {('badge-high' if v['severity']=='HIGH' else 'badge-medium')}'>{v['rule_id']}</span> "
            f"{html.escape(v['message'])}"
            for v in ex["violations"]
        )
        fixes_html = "".join(
            f"<div class='fix'><strong>{v['rule_id']} fix:</strong> {html.escape(v['suggested_fix'])}</div>"
            for v in ex["violations"] if v.get("suggested_fix")
        )
        rows_html += f"""
        <tr class="example-row" id="{row_id}" data-module="{html.escape(ex['module'])}"
            data-rule="{html.escape(ex['violations'][0]['rule_id'])}"
            data-severity="{html.escape(ex['severity'])}"
            data-question="{html.escape(ex['question'].lower())}">
          <td>{rid}</td>
          <td><div class="question">{html.escape(ex['question'])}</div></td>
          <td><span class="badge {sev_badge}">{ex['severity']}</span></td>
          <td>{html.escape(ex['module'])}</td>
          <td>{violations_html}</td>
          <td><span class="toggle" onclick="toggleRow('{detail_id}')">Show SQL</span></td>
        </tr>
        <tr class="row-detail" id="{detail_id}">
          <td colspan="6">
            <div class="sql">{html.escape(ex['sql'])}</div>
            {fixes_html}
          </td>
        </tr>
        """

    # Module breakdown table
    module_rows = "".join(
        f"<tr><td>{m}</td><td>{d['total']}</td><td>{d['flagged']}</td>"
        f"<td>{d['flagged']*100/d['total']:.1f}%</td></tr>"
        for m, d in sorted(module_breakdown.items(), key=lambda x: -x[1]["flagged"])
    )

    # Rule hit table
    rule_rows = "".join(
        f"<tr><td><code>{rid}</code></td><td>{n}</td>"
        f"<td>{n*100/total:.2f}%</td>"
        f"<td>{html.escape(RULE_META.get(rid, {}).get('title', ''))}</td></tr>"
        for rid, n in sorted(rule_counts.items(), key=lambda x: -x[1])
    )

    html_doc = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ChaloSchools Semantic Validation Report — {report['dataset']}</title>
<style>{css}</style>
</head>
<body>
<div class="container">
  <h1>ChaloSchools Semantic Validation Report</h1>
  <div class="meta">
    Dataset: <code>{html.escape(report['dataset'])}</code> &middot;
    {total} examples &middot; {rule_count()} rules &middot;
    Generated {report['generated_at']}
  </div>

  <div class="summary-grid">
    <div class="stat-card"><div class="num">{total}</div><div class="label">Total examples</div></div>
    <div class="stat-card high"><div class="num">{flagged}</div><div class="label">Flagged ({flagged*100/total:.1f}%)</div></div>
    <div class="stat-card clean"><div class="num">{clean}</div><div class="label">Clean ({clean*100/total:.1f}%)</div></div>
    <div class="stat-card medium"><div class="num">{report['total_violations']}</div><div class="label">Total violations</div></div>
    <div class="stat-card"><div class="num">{report['high_count']}</div><div class="label">HIGH severity</div></div>
    <div class="stat-card"><div class="num">{report['medium_count']}</div><div class="label">MEDIUM severity</div></div>
  </div>

  <h2>Module breakdown</h2>
  <table>
    <tr><th>Module</th><th>Total</th><th>Flagged</th><th>Flagged %</th></tr>
    {module_rows}
  </table>

  <h2>Rule hit counts</h2>
  <table>
    <tr><th>Rule ID</th><th>Count</th><th>% of all</th><th>Title</th></tr>
    {rule_rows}
  </table>

  <h2>Flagged examples ({len(examples)} shown)</h2>
  <div class="filters">
    <label>Module: <select id="f-module" onchange="filterTable()">{module_options}</select></label>
    <label>Rule: <select id="f-rule" onchange="filterTable()">{rule_options}</select></label>
    <label>Severity: <select id="f-sev" onchange="filterTable()">{sev_options}</select></label>
    <label>Search: <input type="text" id="f-search" oninput="filterTable()" placeholder="question text..."></label>
    <span class="pct" id="visible-count">{len(examples)} of {len(examples)} shown</span>
  </div>
  <table>
    <tr><th>#</th><th>Question</th><th>Sev</th><th>Module</th><th>Violations</th><th></th></tr>
    {rows_html}
  </table>

  <div class="footer">
    Generated by the ChaloSchools Semantic Validation Suite &middot;
    <code>semantic_rules.py</code> ({rule_count()} rules) + <code>validate_dataset.py</code> &middot;
    See <code>summary.md</code> for the markdown version and <code>violations.csv</code> for machine-readable output.
  </div>
</div>
<script>{js}</script>
</body>
</html>"""
    return html_doc

# ── Main ────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(description="Validate a training dataset semantically.")
    ap.add_argument("--dataset", default="/home/z/my-project/semantic_validation/reference_inputs/training_dataset_final_v27.jsonl")
    ap.add_argument("--out-dir", default="/home/z/my-project/semantic_validation/output")
    args = ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)

    examples = []
    rule_counts = Counter()
    rule_by_module = defaultdict(Counter)
    module_totals = Counter()
    module_flagged = Counter()
    total = 0
    flagged = 0
    total_violations = 0
    high_count = 0
    medium_count = 0

    with open(args.dataset, encoding="utf-8") as f:
        for i, line in enumerate(f, 1):
            line = line.strip()
            if not line: continue
            try:
                rec = json.loads(line)
            except Exception:
                continue
            q = rec.get("input", "")
            sql = str(rec.get("output", ""))
            mod = classify(q)
            module_totals[mod] += 1
            total += 1
            vs = check_sql(sql, q)
            if vs:
                flagged += 1
                module_flagged[mod] += 1
                sev = "HIGH" if any(v.severity == "HIGH" for v in vs) else "MEDIUM"
                examples.append({
                    "line": i, "question": q, "sql": sql, "module": mod,
                    "severity": sev,
                    "violations": [
                        {"rule_id": v.rule_id, "severity": v.severity,
                         "message": v.message, "suggested_fix": v.suggested_fix}
                        for v in vs
                    ]
                })
            for v in vs:
                rule_counts[v.rule_id] += 1
                rule_by_module[mod][v.rule_id] += 1
                total_violations += 1
                if v.severity == "HIGH": high_count += 1
                else: medium_count += 1

    clean = total - flagged

    # Build module breakdown
    module_breakdown = {
        m: {"total": module_totals[m], "flagged": module_flagged.get(m, 0)}
        for m in module_totals
    }

    report = {
        "dataset": args.dataset,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "total": total, "flagged": flagged, "clean": clean,
        "total_violations": total_violations,
        "high_count": high_count, "medium_count": medium_count,
        "rule_counts": dict(rule_counts),
        "module_breakdown": module_breakdown,
        "rule_by_module": {m: dict(c) for m, c in rule_by_module.items()},
    }

    # Write HTML
    html_path = os.path.join(args.out_dir, "report.html")
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(build_html(report, examples))

    # Write CSV
    csv_path = os.path.join(args.out_dir, "violations.csv")
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["line", "input", "module", "rule_id", "severity", "message", "suggested_fix"])
        for ex in examples:
            for v in ex["violations"]:
                w.writerow([ex["line"], ex["question"][:120], ex["module"],
                            v["rule_id"], v["severity"], v["message"], v["suggested_fix"]])

    # Write markdown summary
    md_path = os.path.join(args.out_dir, "summary.md")
    L = [
        f"# Semantic Validation Summary\n",
        f"**Dataset:** `{args.dataset}`\n",
        f"**Generated:** {report['generated_at']}\n",
        f"**Rules:** {rule_count()}\n",
        f"---\n",
        f"## Stats\n",
        f"- Total examples: **{total}**",
        f"- Flagged: **{flagged}** ({flagged*100/total:.1f}%)",
        f"- Clean: **{clean}** ({clean*100/total:.1f}%)",
        f"- Total violations: **{total_violations}**",
        f"- HIGH severity: **{high_count}**",
        f"- MEDIUM severity: **{medium_count}**\n",
        f"## Rule hit counts\n",
        "| Rule ID | Count | % | Title |",
        "|---|---:|---:|---|",
    ]
    for rid, n in rule_counts.most_common():
        L.append(f"| `{rid}` | {n} | {n*100/total:.2f}% | {RULE_META.get(rid, {}).get('title', '')} |")
    L.append("\n## Module breakdown\n")
    L.append("| Module | Total | Flagged | Flagged % |")
    L.append("|---|---:|---:|---:|")
    for m, d in sorted(module_breakdown.items(), key=lambda x: -x[1]["flagged"]):
        L.append(f"| {m} | {d['total']} | {d['flagged']} | {d['flagged']*100/d['total']:.1f}% |")
    L.append(f"\n## Artifacts\n")
    L.append(f"- `report.html` — interactive triage report (open in a browser)")
    L.append(f"- `violations.csv` — machine-readable, one row per violation ({total_violations} rows)")
    L.append(f"- `summary.md` — this file")
    L.append(f"- `dataset_version.txt` — provenance\n")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write("\n".join(L))

    # Write provenance
    ver_path = os.path.join(args.out_dir, "dataset_version.txt")
    with open(ver_path, "w", encoding="utf-8") as f:
        f.write(f"DATASET={args.dataset}\n")
        f.write(f"TOTAL_EXAMPLES={total}\n")
        f.write(f"FLAGGED={flagged}\n")
        f.write(f"CLEAN={clean}\n")
        f.write(f"TOTAL_VIOLATIONS={total_violations}\n")
        f.write(f"HIGH={high_count}\n")
        f.write(f"MEDIUM={medium_count}\n")
        f.write(f"RULES_ENGINE=semantic_rules.py ({rule_count()} rules)\n")
        f.write(f"GENERATED_AT={report['generated_at']}\n")

    # Console
    print("="*70)
    print(f"Validated {total} examples with {rule_count()} rules.")
    print(f"Flagged: {flagged} ({flagged*100/total:.1f}%) | Clean: {clean} ({clean*100/total:.1f}%)")
    print(f"Total violations: {total_violations} (HIGH: {high_count}, MEDIUM: {medium_count})")
    print(f"\nArtifacts:")
    print(f"  {html_path}")
    print(f"  {csv_path}")
    print(f"  {md_path}")
    print(f"  {ver_path}")
    print("="*70)
    print("Rule hit counts:")
    for rid, n in rule_counts.most_common():
        print(f"  {rid}: {n}")

if __name__ == "__main__":
    main()

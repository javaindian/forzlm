#!/usr/bin/env python3
"""
prepare_data.py — Prepare the AI Secretary training data for fine-tuning.

What it does:
  1. Reads the source dataset (e.g., data/training_dataset_final_v28.jsonl)
  2. Adds the `instruction` field (the frozen system prompt) to each example,
     so the output matches what the training notebook's formatting_prompts_func
     expects (instruction / input / output).
  3. Runs the semantic validation engine against every example and REFUSES to
     produce train/val if violations are found above a configurable threshold.
     This is the pre-commit check that stops buggy labels from being trained on.
  4. Shuffles (seeded) and splits into train / validation (default 92% / 8%)
  5. Writes train_v{N}.jsonl and val_v{N}.jsonl into the finetune/ folder
  6. Writes a DATASET_VERSION.txt alongside them, recording which dataset
     version produced this split, the validation results, and the rule count.

The validation gate is the single most important safety net: it ensures no
dataset version with semantic bugs above the threshold can be used for training
without an explicit override. This is the "you can't ship broken labels"
mechanism.

Usage:
  python prepare_data.py                    # validates + splits (fails on violations)
  python prepare_data.py --allow-violations # validates + splits (warns but proceeds)
  python prepare_data.py --report-only       # validates + writes report, no split
"""
import json
import os
import random
import argparse
import sys

# ── Configuration — update DATASET_VERSION each time you point SOURCE at a new dataset ──
DATASET_VERSION = "v27"   # <-- UPDATE THIS to match the source file

# ── The frozen system prompt (must match demo_runner._read_base_prompt EXACTLY) ───────
# This is the instruction the model is trained on. Any change here MUST be reflected
# in the runtime prompt (demo_runner._read_base_prompt) or the model derails.
FROZEN_SYSTEM_PROMPT = (
    "You are a T-SQL expert for the ChaloSchools (V3_CHALO) school management "
    "database. Convert the following natural language question into a single, "
    "executable T-SQL query. Use @UserId (bound as a query parameter at runtime "
    "from the logged-in user's session) to scope results to the branches that "
    "user has access to via UserAccountRoleDetails."
)

# ── Paths (relative to project root) ─────────────────────────────────────────
HERE = os.path.dirname(os.path.abspath(__file__))
# When this script lives in finetune/, PROJECT_ROOT is its parent.
# When it lives in semantic_validation/, adjust accordingly.
POSSIBLE_ROOTS = [
    os.path.dirname(HERE),                          # if HERE is finetune/ or semantic_validation/
    os.path.dirname(os.path.dirname(HERE)),         # if HERE is one level deeper
]
PROJECT_ROOT = next((r for r in POSSIBLE_ROOTS if os.path.isdir(os.path.join(r, "data"))), HERE)

# Look for the dataset in reference_inputs/ (this package's self-contained copy)
# or in PROJECT_ROOT/data/ (the original location, if you keep the dataset there).
SOURCE = os.path.join(HERE, "reference_inputs", f"training_dataset_final_{DATASET_VERSION}.jsonl")
if not os.path.exists(SOURCE):
    SOURCE = os.path.join(PROJECT_ROOT, "data", f"training_dataset_final_{DATASET_VERSION}.jsonl")
TRAIN_OUT = os.path.join(HERE, f"train_{DATASET_VERSION}.jsonl")
VAL_OUT = os.path.join(HERE, f"val_{DATASET_VERSION}.jsonl")
VERSION_OUT = os.path.join(HERE, "DATASET_VERSION.txt")
REPORT_DIR = os.path.join(HERE, "validation_reports", DATASET_VERSION)

VAL_FRACTION = 0.08     # 8% held out for validation
SEED = 42               # reproducible split

# ── Validation threshold ─────────────────────────────────────────────────────
# If the dataset has more than this many HIGH-severity violations, prepare_data
# refuses to produce train/val. Set to 0 for strict mode, or a small number
# to allow minor residual bugs while you clean the dataset in batches.
MAX_ALLOWED_HIGH_VIOLATIONS = 0
MAX_ALLOWED_TOTAL_VIOLATIONS = 0


def load_dataset(path):
    """Load the source JSONL. Tolerates {input, output} OR {instruction, input, output}."""
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Can't find {path} — place the dataset there, or update "
            f"DATASET_VERSION at the top of this script."
        )
    pairs = []
    with open(path, encoding="utf-8") as f:
        for i, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError as e:
                raise ValueError(f"Line {i} is not valid JSON: {e}")
            if "input" not in rec or "output" not in rec:
                raise ValueError(
                    f"Line {i} is missing required 'input' or 'output' field. "
                    f"Got keys: {list(rec.keys())}"
                )
            pairs.append(rec)
    return pairs


def add_instruction_field(pairs, system_prompt):
    """
    Ensure every example has an `instruction` field set to the frozen system prompt.

    The training notebook's formatting_prompts_func expects {instruction, input, output}.
    If the source dataset only has {input, output} (as the v27 file does), this adds
    the instruction field. If the source already has instruction, this OVERWRITES it
    with the canonical frozen prompt — so the dataset and the runtime prompt always
    match (the model is brittle to prompt changes; this is the single source of truth).

    For the Option A vocab-aware retrain, replace FROZEN_SYSTEM_PROMPT above with the
    vocab-aware version (frozen prompt + per-branch vocab block). The rest of the
    pipeline stays the same.
    """
    for p in pairs:
        p["instruction"] = system_prompt
    return pairs


def run_validation(pairs):
    """Run the semantic rules engine against every example. Returns (violations_by_example, summary)."""
    # Import the rules engine (lives in semantic_validation/ or finetune/)
    sys.path.insert(0, HERE)
    try:
        from semantic_rules import check_sql, rule_count
    except ImportError:
        try:
            from semantic_validation.semantic_rules import check_sql, rule_count
        except ImportError:
            print("WARNING: semantic_rules.py not found. Skipping validation.")
            return {}, {"skipped": True}

    violations_by_example = {}
    high_count = 0
    total_violations = 0
    rule_counts = {}
    for i, p in enumerate(pairs):
        sql = str(p.get("output", ""))
        question = p.get("input", "")
        vs = check_sql(sql, question)
        if vs:
            violations_by_example[i] = vs
            for v in vs:
                total_violations += 1
                if v.severity == "HIGH":
                    high_count += 1
                rule_counts[v.rule_id] = rule_counts.get(v.rule_id, 0) + 1
    summary = {
        "total": len(pairs),
        "flagged": len(violations_by_example),
        "high_count": high_count,
        "total_violations": total_violations,
        "rule_counts": rule_counts,
        "rule_engine_rules": rule_count(),
    }
    return violations_by_example, summary


def write_validation_report(violations_by_example, pairs, summary, report_dir):
    """Write a per-example violations CSV + a summary markdown to report_dir."""
    os.makedirs(report_dir, exist_ok=True)
    csv_path = os.path.join(report_dir, "violations.csv")
    md_path = os.path.join(report_dir, "summary.md")

    import csv
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["example_index", "input", "rule_id", "severity", "message", "suggested_fix"])
        for idx, vs in violations_by_example.items():
            p = pairs[idx]
            for v in vs:
                w.writerow([idx, p["input"][:120], v.rule_id, v.severity, v.message, v.suggested_fix])

    with open(md_path, "w", encoding="utf-8") as f:
        f.write(f"# Validation Report — {DATASET_VERSION}\n\n")
        f.write(f"**Total examples:** {summary['total']}\n")
        f.write(f"**Flagged:** {summary['flagged']} ({summary['flagged']*100/summary['total']:.1f}%)\n")
        f.write(f"**HIGH severity:** {summary['high_count']}\n")
        f.write(f"**Total violations:** {summary['total_violations']}\n")
        f.write(f"**Rules engine:** {summary['rule_engine_rules']} rules\n\n")
        f.write("## Rule hit counts\n\n| Rule | Count |\n|---|---:|\n")
        for rid, n in sorted(summary["rule_counts"].items(), key=lambda x: -x[1]):
            f.write(f"| `{rid}` | {n} |\n")
        f.write(f"\n## Per-example violations\n\nSee `violations.csv`.\n")

    return csv_path, md_path


def main():
    ap = argparse.ArgumentParser(description="Prepare + validate training data.")
    ap.add_argument("--allow-violations", action="store_true",
                    help="Proceed with the split even if violations exceed the threshold.")
    ap.add_argument("--report-only", action="store_true",
                    help="Run validation + write report, but do NOT produce train/val split.")
    args = ap.parse_args()

    print(f"Dataset version: {DATASET_VERSION}")
    pairs = load_dataset(SOURCE)
    print(f"Loaded {len(pairs)} pairs from {SOURCE}")

    # Step 1: Add the instruction field (the frozen system prompt)
    pairs = add_instruction_field(pairs, FROZEN_SYSTEM_PROMPT)
    print(f"Added/verified 'instruction' field on all {len(pairs)} examples.")

    # Step 2: Run the semantic validation engine
    print(f"\nRunning semantic validation engine...")
    violations_by_example, summary = run_validation(pairs)

    if summary.get("skipped"):
        print("  (skipped — semantic_rules.py not found)")
    else:
        print(f"  Flagged: {summary['flagged']} / {summary['total']} "
              f"({summary['flagged']*100/summary['total']:.1f}%)")
        print(f"  HIGH severity: {summary['high_count']}")
        print(f"  Total violations: {summary['total_violations']}")
        print(f"  Rules engine: {summary['rule_engine_rules']} rules")

        # Write the validation report regardless of pass/fail
        csv_path, md_path = write_validation_report(
            violations_by_example, pairs, summary, REPORT_DIR)
        print(f"\n  Validation report: {csv_path}")
        print(f"  Validation summary: {md_path}")

        # Gate: refuse to produce train/val if violations exceed threshold
        if not args.allow_violations and not args.report_only:
            if summary["high_count"] > MAX_ALLOWED_HIGH_VIOLATIONS or \
               summary["total_violations"] > MAX_ALLOWED_TOTAL_VIOLATIONS:
                print(f"\n  GATE FAILED: {summary['high_count']} HIGH violations "
                      f"(threshold: {MAX_ALLOWED_HIGH_VIOLATIONS}).")
                print(f"  Refusing to produce train/val split.")
                print(f"  Fix the violations in the dataset, or re-run with --allow-violations")
                print(f"  to override (NOT recommended for production training).")
                print(f"  See the validation report above for the full list.")
                sys.exit(1)
            else:
                print(f"  GATE PASSED: within threshold. Proceeding with split.")

    if args.report_only:
        print("\n--report-only: validation report written. Not producing train/val.")
        return

    # Step 3: Shuffle and split
    random.seed(SEED)
    random.shuffle(pairs)
    n_val = max(1, int(len(pairs) * VAL_FRACTION))
    val = pairs[:n_val]
    train = pairs[n_val:]

    # Step 4: Write train/val
    with open(TRAIN_OUT, "w", encoding="utf-8") as f:
        for p in train:
            f.write(json.dumps(p, ensure_ascii=False) + "\n")
    with open(VAL_OUT, "w", encoding="utf-8") as f:
        for p in val:
            f.write(json.dumps(p, ensure_ascii=False) + "\n")

    # Step 5: Write provenance
    with open(VERSION_OUT, "w", encoding="utf-8") as f:
        f.write(f"DATASET_VERSION={DATASET_VERSION}\n")
        f.write(f"SOURCE={SOURCE}\n")
        f.write(f"TOTAL_PAIRS={len(pairs)}\n")
        f.write(f"TRAIN_PAIRS={len(train)}\n")
        f.write(f"VAL_PAIRS={len(val)}\n")
        f.write(f"SEED={SEED}\n")
        if not summary.get("skipped"):
            f.write(f"VALIDATION_FLAGGED={summary['flagged']}\n")
            f.write(f"VALIDATION_HIGH={summary['high_count']}\n")
            f.write(f"VALIDATION_TOTAL_VIOLATIONS={summary['total_violations']}\n")
            f.write(f"VALIDATION_RULES={summary['rule_engine_rules']}\n")
        f.write(f"INSTRUCTION_FIELD={FROZEN_SYSTEM_PROMPT[:60]}...\n")

    print(f"\nTrain: {len(train)} pairs -> {TRAIN_OUT}")
    print(f"Val:   {len(val)} pairs -> {VAL_OUT}")
    print(f"Version record -> {VERSION_OUT}")


if __name__ == "__main__":
    main()

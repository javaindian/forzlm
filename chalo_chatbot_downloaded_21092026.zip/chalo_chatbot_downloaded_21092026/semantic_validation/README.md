# ChaloSchools Semantic Validation Suite

A deterministic rules engine that validates the semantic correctness of T-SQL queries in your ChaloSchools Text-to-SQL training dataset. This is the layer your pipeline currently does NOT have: it catches semantic errors that pass every structural gate (schema existence, alias scope, branch scoping, value validation) but return wrong or empty data.

---

## HOW TO RUN (start here)

You need Python 3.8+ and nothing else — no pip installs, all stdlib. The v27 dataset is bundled inside this package at `reference_inputs/training_dataset_final_v27.jsonl`, so you can run immediately.

### 1. Validate the bundled v27 dataset

From inside this folder:

```bash
python3 validate_dataset.py
```

That's it. It validates all 3,867 examples against 29 rules and writes the report to `output/`.

**Expected output:**
```
======================================================================
Validated 3867 examples with 29 rules.
Flagged: 515 (13.3%) | Clean: 3352 (86.7%)
Total violations: 706 (HIGH: 688, MEDIUM: 18)

Artifacts:
  .../output/report.html
  .../output/violations.csv
  .../output/summary.md
  .../output/dataset_version.txt
======================================================================
```

### 2. Open the report

Open `output/report.html` in any web browser (Chrome, Firefox, Safari, Edge — all work). It's a single self-contained file, no internet needed.

- **Top:** summary cards (total / flagged / clean / violations by severity).
- **Module breakdown table:** flagged % per module.
- **Rule hit table:** count + % + title for every rule.
- **515 example rows:** line #, question, severity badge, module, violations with fix suggestions.
- **Filters (top of the examples section):** by module, by rule, by severity, by question-text search.
- **Click "Show SQL"** on any flagged example to see the full SQL + the specific suggested fix for each violation.

This is your triage worklist.

### 3. Validate a different dataset

```bash
python3 validate_dataset.py --dataset /path/to/your/training_dataset_final_v28.jsonl
# Optional: --out-dir /path/to/output/folder  (default: ./output)
```

### 4. Gate your training pipeline (drop-in `prepare_data.py`)

Copy `prepare_data.py` into your `finetune/` folder (or wherever your existing one lives), edit `DATASET_VERSION` at the top to match your source file, then run:

```bash
python3 prepare_data.py
```

What it does:
1. Loads the source dataset.
2. Adds the `instruction` field (the frozen system prompt) to every example — the training notebook's `formatting_prompts_func` requires this.
3. Runs the semantic validation engine.
4. **GATE:** if HIGH-severity violations exceed the threshold (default 0), it refuses to produce train/val and exits 1.
5. If within threshold: writes `train_v{N}.jsonl`, `val_v{N}.jsonl`, `DATASET_VERSION.txt`.

```bash
python3 prepare_data.py --report-only        # validate, don't split (just writes the report)
python3 prepare_data.py --allow-violations   # override the gate (NOT recommended for production)
```

### 5. Test the rules engine alone (self-test)

```bash
python3 semantic_rules.py
```

Runs 10 built-in test cases (known-wrong and known-correct SQL) and prints what each catches. Use this to verify the engine works after you add or modify a rule.

---

## What this package does

1. **Validates** every training example against 29 deterministic rules mined from the 1,095 reference stored procedures.
2. **Reports** every violation with a specific, actionable suggested fix.
3. **Gates** the training pipeline — `prepare_data.py` refuses to produce train/val splits if violations exceed a threshold, so you can't accidentally train on buggy labels.

On v27: **515 of 3,867 examples flagged (13.3%)** with 706 violations (688 HIGH). The model learns these bugs; fast-paths replay them verbatim; users see wrong answers presented as confident `ANSWER`s. This suite catches them before training and (via the live-pipeline integration below) at runtime.

---

## What's in this package

```
semantic_validation/
├── README.md                  — this file (start here)
├── semantic_rules.py          — the rules engine (29 rules, stdlib-only, <1ms/query)
├── validate_dataset.py        — standalone validator → HTML + CSV + MD report
├── prepare_data.py            — drop-in replacement for your prepare_data.py
│                                (adds instruction field + runs validation GATE)
├── rules_catalog.json         — full 78-rule catalog mined from the 1,095 SPs
│                                (29 are implemented in semantic_rules.py; the rest
│                                are the roadmap)
├── semantic_rules_catalog.md  — human-readable version of the catalog
├── reference_inputs/          — bundled inputs so the package is self-contained
│   ├── training_dataset_final_v27.jsonl   (4.2 MB — the dataset to validate)
│   ├── Chalo_Table_Schema.txt             (1.4 MB — the 475-table schema)
│   ├── all_SPs.xlsx                       (524 KB — the 1,095 stored procedures)
│   ├── schema_catalog.json               (182 KB — guardrail catalog)
│   ├── sql_guardrail.py                   (13 KB — your existing guardrail, reference)
│   ├── ChaloSchools_DB_Deep_Dive_Consolidated.xlsx
│   ├── finetune_qwen25coder_TRAIN_KAGGLE_v16.ipynb   (your training notebook)
│   ├── finetune_qwen25coder_GGUF_EXPORT_COLAB_v17.ipynb (your export notebook)
│   └── prepare_data_v25_SAMPLE.py        (the sample prepare_data.py you provided)
└── output/                    — generated when you run validate_dataset.py
    ├── report.html            — interactive triage report (open in a browser)
    ├── violations.csv         — machine-readable, one row per violation
    ├── summary.md             — aggregate summary
    └── dataset_version.txt    — provenance
```

---

## The 29 implemented rules

| Rule ID | Severity | What it catches |
|---|---|---|
| FEE-001 | HIGH | Outstanding formula missing `Lien_Amount` |
| FEE-004 | HIGH | Outstanding query missing `IsIncludedInLumpSum = 0` |
| FEE-005 | HIGH | Academic-fee query missing `Structure_Type` filter |
| FEE-006 | HIGH | Fee query joins `ExamTermMaster` (should be `TermMaster`) |
| FEE-007 | HIGH | Fee query missing `AcademicYearID` filter or hardcoded year |
| FEE-009 | HIGH | Outstanding query missing TC-issued student filter |
| FEE-011 | HIGH | `FeesCollection` collection query missing `ChequeStatus_ID` filter |
| FEE-013 | HIGH | Current-term fee query wrong date window |
| FEE-014 | HIGH | Bus-fee query missing `IsBusFee = 1` |
| FEE-019 | MEDIUM | Nonexistent `Amt` column on `FeesCollection` |
| FEE-022 | MEDIUM | Academic-fee query missing `IsDonation = 0` |
| EXAM-001 | HIGH | `ExamTypeMaster.TermID` joined to `TermMaster` (wrong) |
| EXAM-002 | HIGH | `ExamTermMaster` uses `IsDeleted` (should be `Deleted`) |
| EXAM-003 | HIGH | `ExamTermMaster` uses `StartingDate/EndingDate` (wrong columns) |
| EXAM-004 | HIGH | `Get_TermList` called for fee-term lookup (name trap) |
| STUD-001 | HIGH | `Student_Master.ClassID/SectionID/AcademicYearID` (nonexistent) |
| STUD-004 | HIGH | Academic year via `YEAR(GETDATE())` (crosses calendar boundary) |
| STUD-005 | HIGH | Student query missing `AcademicYearID` filter |
| STAFF-002 | HIGH | `Staff_Master.FirstName` (should be `Staff_FirstName`) |
| STAFF-003 | MEDIUM | Active-staff query missing `StaffStatus_ID = 1` |
| ADM-001 | HIGH | `ProspectusFeesCollection` linked via `Student_ID` (wrong) |
| ADM-002 | HIGH | `EnquiryMaster` is deprecated (use `GeneralCallRegister`) |
| DEPRECATED | HIGH | Deprecated twin tables (`Department_Master`, `Academic_Month_Master`, etc.) |
| DEPRECATED-004 | HIGH | `BusFeeStructure` (wrong spelling — live table is `BusFeeStrucure`) |
| SENSITIVE-TABLE | HIGH | Sensitive table queried (`StorageConfiguration`, `SMS_ConfigurationSettings`, etc.) |
| SENSITIVE-COL | HIGH | Sensitive column selected (`Password`, `Token`, `SGC_Password`, etc.) |
| RBAC-001 | MEDIUM | Branch scoping missing super-user `UNION` |
| RBAC-SALARY | HIGH | Salary query missing branch scoping |
| TRANS-001 | HIGH | `BusFeeStructure` (wrong spelling) |
| MULTI-STMT | HIGH | Multiple SQL statements |
| WRITE-VERB | HIGH | Write verb in read-only service |

The full 78-rule catalog (with evidence from the 1,095 SPs) is in `rules_catalog.json`. The remaining 49 rules are documented but not yet implemented as deterministic checks (they require more complex logic — e.g., late-fee UNION pattern, prior-term carry-over, dual-FK salary joins). Add them as the engine matures.

---

## How to add a new rule

1. Open `semantic_rules.py`.
2. Write a function `r_yourrule(sql, q, tables) -> Optional[Violation]`. Return `None` if the rule doesn't apply; return a `Violation` if it does. Always include a `suggested_fix`.
3. Add the function to the `RULES` list at the bottom of the file.
4. Add metadata to `RULE_META` (rule_id → {title, catalog_ref}).
5. Run `python3 semantic_rules.py` for the self-test, then `python3 validate_dataset.py` to re-run on the full dataset.

Rules are pure functions (no side effects, no state). The engine wraps each in try/except, so a buggy rule never crashes the validator — it logs as an ENGINE-ERR violation instead.

Example rule (the simplest one in the file):

```python
# FEE-014: bus-fee outstanding must filter IsBusFee = 1
def r_fee014(sql, q, tables):
    if "FeesInformationStudentDetail" not in tables: return None
    ql = q.lower()
    if "bus fee" not in ql: return None
    if not _has(sql, r"IsBusFee\s*=\s*1"):
        return Violation("FEE-014", "HIGH",
            "Bus-fee query omits IsBusFee = 1 filter.",
            "Add AND f.IsBusFee = 1 to restrict to bus-fee rows only.",
            "Fees")
    return None
```

---

## Integration into the live pipeline (runtime, not just training-time)

The same `check_sql()` function drops into `orchestrator.py` between the existing VALIDATE and EXECUTE stages. This catches both model mistakes at runtime and (via `prepare_data.py`) buggy labels before training:

```python
# In orchestrator.py, after the existing VALIDATE stage, before BIND:
from semantic_rules import check_sql
sem_violations = check_sql(sql, question)
if sem_violations:
    return PipelineResult(
        Outcome.REFUSED, Stage.VALIDATE, sql=sql, sql_source=sql_source,
        message='; '.join(str(v) for v in sem_violations[:3]),
        detail='; '.join(str(v) for v in sem_violations),
        trace=trace + [f'semantic_rules: {len(sem_violations)} violation(s)'],
    )
```

The engine is <1ms per query (regex-based), safe to run on every generated SQL including fast-path cache hits.

---

## The `instruction` field fix (important if you use `prepare_data.py`)

The sample `prepare_data.py` reads `{instruction, input, output}` and passes them through — but the v27 JSONL only has `{input, output}`. The training notebook's `formatting_prompts_func` expects all three and would `KeyError` on a two-field dataset.

The `prepare_data.py` in this package fixes this by:
1. Loading the source (tolerates 2-field or 3-field input).
2. **Setting `instruction = FROZEN_SYSTEM_PROMPT` on every example** (overwriting if present, so the dataset and runtime prompt always match — the model is brittle to prompt changes).
3. Running the validation gate.
4. Splitting + writing train/val.

**For the vocab-aware retrain (Option A in your guidelines):** replace `FROZEN_SYSTEM_PROMPT` in `prepare_data.py` with the vocab-aware version (frozen prompt + per-branch vocab block). The rest of the pipeline stays the same.

---

## Triage methodology (after running the validator)

1. **Use `output/violations.csv` or the HTML report as the work list.** Sort by `rule_id`, then by `line`. Triage rule-by-rule (all FEE-005 violations together, then all FEE-007, etc.) — the fix pattern is the same within a rule.

2. **Triage order (by count, highest impact first):**
   - **FEE-005 (382)** — missing `Structure_Type`. Fix: add `AND Structure_Type IN ('Academic','Optional')` to academic-fee queries. **CAUTION:** do NOT add it to bus-fee, hostel-fee, donation, or misc-fee queries — those need different `Structure_Type` values. Check the question intent before fixing.
   - **FEE-007 (146)** — missing academic-year filter. Fix: add the `Branch_Academic_Details` subquery. **Skip** queries that are already date-scoped (today, this month, last 7 days).
   - **STUD-005 (42)** — student query missing academic-year filter. Same fix.
   - **MULTI-STMT (36)** and **WRITE-VERB (36)** — mostly false positives (semicolons in subqueries; write verbs in refusal-message comments). Refine these rules or skip.
   - **FEE-009 (22)** — outstanding query missing TC-issued filter. Fix: add `AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL)`.
   - **FEE-004 (18)** and **FEE-022 (18)** — missing `IsIncludedInLumpSum = 0` and `IsDonation = 0`. Add the filters.
   - **FEE-011 (3), FEE-013 (2), RBAC-SALARY (1)** — small counts, fix each individually.

3. **For each batch of fixes, re-run the validator.** The violation count should drop. If new violations appear (e.g., adding `Structure_Type` revealed a missing `AcademicYearID`), fix those too. Iterate until the flag rate is <5%.

4. **Hand-verify a sample.** After the engine reports zero violations, hand-verify 20 randomly-chosen fixed examples against the SPs (the ground truth). The engine is regex-based and can miss semantic errors the rules don't cover.

5. **Refine the rules based on false positives.** During triage you'll find false positives. Refine the rules to exclude them. Target <5% false-positive rate on the cleaned dataset.

---

## Design principles

1. **Deterministic, not probabilistic.** Regex + structure checks, no ML. A rule either fires or doesn't — no judgment calls at runtime.
2. **Fail closed.** If a rule can't decide (e.g., a table it doesn't recognize), it returns `None` (doesn't fire). Better to miss a bug than to falsely refuse a correct query.
3. **Actionable.** Every violation includes a `suggested_fix` — the specific SQL change to make. The HTML report shows it inline.
4. **Cheap.** <1ms per query. Safe to run on every SQL, including fast-path cache hits.
5. **Maintainable.** Rules are pure functions, one per file section. Adding a rule is a 10-line change. The catalog (`rules_catalog.json`) documents all 78 mined rules, implemented or not.
6. **Self-contained.** stdlib only. No external dependencies. Runs anywhere Python 3.8+ runs. The dataset and reference files are bundled in `reference_inputs/` so you can run immediately without sourcing anything.

---

## Honest limits

- **29 of 78 rules implemented.** The remaining 49 are in the catalog but require more complex logic (late-fee UNION pattern, prior-term carry-over, dual-FK salary joins, etc.). Add them as the engine matures.
- **Regex-based, not a SQL parser.** Rules match patterns, not parsed SQL. A creatively-written query can evade a rule. The rules engine is defense-in-depth, not a substitute for a real SQL analyzer.
- **Intent classification is heuristic.** Rules like "outstanding intent" or "active intent" classify based on keywords in the question. A question phrased unusually may misclassify. The rules are conservative (err toward not firing).
- **False positives.** Some rules (especially FEE-005, FEE-022) can fire on queries where the missing filter is intentional (e.g., a bus-fee query that legitimately omits `Structure_Type`). The suggested fix is still correct; the triage step is to decide whether to apply it or whitelist the example. Target <5% false-positive rate on a cleaned dataset.
- **Does NOT execute SQL.** Static analysis only. No DB connection.
- **Does NOT auto-apply fixes.** Suggested fixes are guidance, not auto-applied — auto-applying SQL rewrites is risky and error-prone; human triage is safer.
- **Does NOT replace the evaluation harness.** It validates labels, not model behavior. You still need golden questions to measure end-to-end correctness.

---

## Maintenance

- **When you add a new semantic rule to the engine:** add it to `semantic_rules.py`, `RULE_META`, and the `RULES` list. Update this README's rule table. Re-run `validate_dataset.py`.
- **When you clean flagged examples in the dataset:** fix the SQL, re-run `validate_dataset.py` to confirm the violations disappear. Iterate until the flag rate is <5%.
- **When you add a new module or table:** check whether existing rules cover it. If not, mine the relevant SPs for new rules (the SP source is in `reference_inputs/all_SPs.xlsx`; the catalog is `rules_catalog.json`).
- **When the schema changes:** update the table sets in `semantic_rules.py` (`FEE_TERM_FK_TABLES`, `ALL_FEE_TABLES`, `SENSITIVE_TABLES`, `DEPRECATED`, etc.).

---

## Troubleshooting

**`python3 validate_dataset.py` says "Can't find ... training_dataset_final_v27.jsonl"**
→ The bundled dataset is at `reference_inputs/training_dataset_final_v27.jsonl`. The default path points there. If you moved the folder, run `python3 validate_dataset.py --dataset /full/path/to/training_dataset_final_v27.jsonl`.

**`prepare_data.py` says "Can't find ... data/training_dataset_final_v27.jsonl"**
→ It looks in `reference_inputs/` first, then `PROJECT_ROOT/data/`. Either place your dataset in `reference_inputs/`, or create a `data/` folder at the project root and put it there. Update `DATASET_VERSION` at the top of `prepare_data.py` to match your filename.

**`prepare_data.py` exits with "GATE FAILED: N HIGH violations"**
→ This is the gate working. Fix the violations in the dataset (use the HTML report as the work list), or re-run with `--allow-violations` to override (NOT recommended for production training).

**The HTML report doesn't render / looks broken**
→ It's a self-contained HTML file with inline CSS and JS. Open it in any modern browser (Chrome, Firefox, Safari, Edge). No internet needed. If it still looks broken, check the file size — it should be ~1.1 MB. If it's much smaller, the run failed; check the console output.

**A rule is firing on a correct query (false positive)**
→ Refine the rule in `semantic_rules.py`. Rules are conservative — if in doubt, return `None` (don't fire). Re-run the self-test (`python3 semantic_rules.py`) and the full validator after changing a rule.

**I want to add a new rule but I'm not sure how**
→ Copy the pattern of an existing rule (e.g., `r_fee014` is the simplest). The function signature is `r_yourrule(sql, q, tables) -> Optional[Violation]`. Return `None` if the rule doesn't apply. Return a `Violation` with a `suggested_fix` if it does. Add it to the `RULES` list and `RULE_META`. Run the self-test.

---

## See also

- `../GUIDELINES.md` — the single source of truth for all problems, mitigations, and decisions (Section G documents this package).
- `../BLINDSPOT_AUDIT.md` — the round-by-round findings history (root-cause proofs for every confirmed failure).
- `../schema_audit_report.md` — the schema/SP evidence base (term tables, fee-outstanding SPs, RBAC tables, 25-risk semantic register, 22 cross-doc inconsistencies).
- `semantic_rules_catalog.md` — the full 78-rule catalog with SP evidence.

@echo off
REM ==========================================================================
REM  ChaloSchools AI Secretary - 50-Question Benchmark
REM  Double-click this file to run 50 sample questions through the backend.
REM ==========================================================================

setlocal enabledelayedexpansion

REM Go to the project root (parent of this scripts/ folder)
cd /d "%~dp0.."

echo ==========================================================================
echo   ChaloSchools AI Secretary - 50-Question Benchmark
echo ==========================================================================
echo.
echo   Project root: %CD%
echo.

REM -- STEP 1: Find Python ---------------------------------------------------
echo   [1/5] Looking for Python...

set "PY="
python --version >nul 2>&1
if %errorlevel%==0 (
    set "PY=python"
    echo     Found: python
    goto :venv
)

py -3 --version >nul 2>&1
if %errorlevel%==0 (
    set "PY=py -3"
    echo     Found: py -3
    goto :venv
)

echo.
echo   ERROR: Python is not installed. See scripts\start_backend.bat for the
echo   full install instructions. Short version:
echo     1. https://www.python.org/downloads/  --  download Python 3.11+
echo     2. In the installer, TICK "Add python.exe to PATH"
echo     3. Come back and double-click this .bat again.
echo.
pause
exit /b 1

:venv
REM -- STEP 2: Create or reuse the .venv folder ------------------------------
echo.
echo   [2/5] Setting up Python virtual environment (.venv)...

if exist ".venv\Scripts\python.exe" (
    echo     .venv already exists - reusing it.
    goto :install
)

echo     Creating .venv for the first time (about 10 seconds)...
%PY% -m venv .venv
if not exist ".venv\Scripts\python.exe" (
    echo.
    echo   ERROR: Could not create .venv. Reinstall Python from
    echo   https://www.python.org/downloads/ - tick "pip" + "py launcher".
    echo.
    pause
    exit /b 1
)

:install
REM -- STEP 3: Activate venv and install deps -------------------------------
echo.
echo   [3/5] Checking Python dependencies...

call ".venv\Scripts\activate.bat"
python -m pip install --quiet --upgrade pip >nul 2>&1
pip install --quiet -r backend\requirements.txt
if errorlevel 1 (
    echo.
    echo   ERROR: Could not install dependencies. Get online, then re-run.
    echo   Corporate firewall? Ask IT to allow pypi.org.
    echo.
    pause
    exit /b 1
)
echo     Dependencies OK.

REM -- STEP 4: Make sure run_50_questions.py exists -------------------------
echo.
echo   [4/5] Looking for run_50_questions.py...

if not exist "run_50_questions.py" (
    echo.
    echo   ERROR: run_50_questions.py is not in the project root:
    echo     %CD%\run_50_questions.py
    echo.
    echo   This is part of the standard package. If it's missing, your
    echo   download may be incomplete - re-download chalo_chatbot.zip.
    echo.
    pause
    exit /b 1
)
echo     Found.

REM -- STEP 5: Make sure context.json exists (fall back to sample) ---------
echo.
echo   [5/5] Looking for context.json...

if exist "context.json" (
    echo     context.json exists - using it.
    goto :run
)

if exist "evaluation\sample_context.json" (
    echo     No context.json found - using the sample from
    echo     evaluation\sample_context.json - for testing only.
    echo     For real testing, replace context.json with the actual Context
    echo     JSON from the school's GetUserContext API.
    copy "evaluation\sample_context.json" "context.json" >nul
    goto :run
)

echo.
echo   ERROR: context.json not found and no sample available.
echo   The sample should be at: evaluation\sample_context.json
echo   Your download may be incomplete - re-download chalo_chatbot.zip.
echo.
pause
exit /b 1

:run
REM -- Run the benchmark ----------------------------------------------------
echo.
echo ==========================================================================
echo   Running the 50-question benchmark...
echo.
echo   This takes about 5-15 minutes on CPU (one question at a time).
echo   Do not close this window until it says "Finished".
echo.
echo   Output will be saved to:
echo     %CD%\output\50_questions_results.md
echo     %CD%\output\50_questions_results.json
echo.
echo   PREREQUISITES (must be running in other windows):
echo     - LLM server  (scripts\start_llm.bat)
echo     - Backend     (scripts\start_backend.bat)
echo ==========================================================================
echo.

REM -- Configuration (edit these if you want to) -----------------------------
REM Auth token (must match AI_SECRETARY_AUTH_TOKENS in backend\.env)
set "AUTH_TOKEN=dev-token-please-change-in-prod"

REM Mode: api_wrapper (execute against the school DB) or dry_run (preview only)
set "MODE=dry_run"

REM Branch ID
set "BRANCH=1"

REM -- Run the script --------------------------------------------------------
python run_50_questions.py --mode %MODE% --branch %BRANCH% --context-json "context.json" --auth-token "%AUTH_TOKEN%"

if errorlevel 1 (
    echo.
    echo ==========================================================================
    echo   The benchmark FAILED. See the error message above.
    echo.
    echo   Common causes:
    echo     - LLM not running        -- start scripts\start_llm.bat first
    echo     - Backend not running    -- start scripts\start_backend.bat next
    echo     - 401 Unauthorized       -- AUTH_TOKEN above doesn't match
    echo                                AI_SECRETARY_AUTH_TOKENS in backend\.env
    echo ==========================================================================
    echo.
    pause
    exit /b 1
)

echo.
echo ==========================================================================
echo   DONE. Output files:
echo     %CD%\output\50_questions_results.md
echo     %CD%\output\50_questions_results.json
echo.
echo   Open the .md file to read the report.
echo ==========================================================================
echo.
pause
endlocal

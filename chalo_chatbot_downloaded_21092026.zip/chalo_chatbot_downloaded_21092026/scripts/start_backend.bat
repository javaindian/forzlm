@echo off
REM ==========================================================================
REM  ChaloSchools AI Secretary - Backend Launcher
REM  Double-click this file to start the backend server.
REM ==========================================================================

setlocal enabledelayedexpansion

REM Go to the project root (parent of this scripts/ folder)
cd /d "%~dp0.."

echo ==========================================================================
echo   ChaloSchools AI Secretary - Backend Launcher
echo ==========================================================================
echo.
echo   Project root: %CD%
echo.

REM -- STEP 1: Find Python (actually run it, don't just check 'where') ------
echo   [1/4] Looking for Python...

set "PY="
python --version >nul 2>&1
if %errorlevel%==0 (
    set "PY=python"
    echo     Found: python
    goto :venv
)

py -3 --version >nul 2>&1
if %errorlevel%==0 (
    set "PY=py -3"
    echo     Found: py -3
    goto :venv
)

echo.
echo   ERROR: Python is not installed (or not on PATH).
echo.
echo   HOW TO FIX:
echo     1. Open https://www.python.org/downloads/ in your browser
echo     2. Download Python 3.11 or newer (the "Windows installer (64-bit)")
echo     3. Run the installer
echo     4. IMPORTANT: tick the box "Add python.exe to PATH"
echo        (it's at the bottom of the first installer screen)
echo     5. After install finishes, double-click this .bat again.
echo.
pause
exit /b 1

:venv
REM -- STEP 2: Create or reuse the .venv folder ------------------------------
echo.
echo   [2/4] Setting up Python virtual environment (.venv)...

if exist ".venv\Scripts\python.exe" (
    echo     .venv already exists - reusing it.
    goto :install
)

echo     First-time setup: creating .venv (about 10 seconds)...
%PY% -m venv .venv
if not exist ".venv\Scripts\python.exe" (
    echo.
    echo   ERROR: Could not create the .venv folder.
    echo   Reinstall Python from https://www.python.org/downloads/
    echo   In the installer choose "Modify" and tick "pip" and "py launcher".
    echo.
    pause
    exit /b 1
)
echo     .venv created.

:install
REM -- STEP 3: Activate venv and install dependencies -----------------------
echo.
echo   [3/4] Checking Python dependencies...
echo     (first run takes ~30 seconds; later runs are ~2 seconds)

call ".venv\Scripts\activate.bat"
if errorlevel 1 (
    echo.
    echo   ERROR: Could not activate the .venv. Delete the .venv folder and
    echo   double-click this .bat again to recreate it.
    echo.
    pause
    exit /b 1
)

python -m pip install --quiet --upgrade pip >nul 2>&1
pip install --quiet -r backend\requirements.txt
if errorlevel 1 (
    echo.
    echo   ERROR: Could not install Python dependencies.
    echo   This usually means no internet, or a corporate firewall blocked pip.
    echo.
    echo   HOW TO FIX:
    echo     - Make sure you are online, then double-click this .bat again.
    echo     - If you are on a corporate network, ask IT to allow:
    echo         pypi.org  and  files.pythonhosted.org
    echo.
    pause
    exit /b 1
)
echo     Dependencies OK.

REM -- STEP 4: Make sure .env exists (optional, use defaults if missing) ----
echo.
echo   [4/4] Checking backend\.env...

if exist "backend\.env" (
    echo     backend\.env exists - using your settings.
    goto :start
)

if exist "backend\.env.example" (
    copy "backend\.env.example" "backend\.env" >nul
    echo     Created backend\.env from .env.example - dev defaults.
    goto :start
)

echo     WARNING: backend\.env.example not found - using built-in defaults.

:start
REM -- Start the server -----------------------------------------------------
echo.
echo ==========================================================================
echo   Starting the backend on http://127.0.0.1:8000
echo.
echo   WHAT TO EXPECT:
echo     Wait until you see a line like:
echo        "Uvicorn running on http://127.0.0.1:8000"
echo     That means the backend is ready.
echo.
echo   THEN:
echo     - Open frontend\chat.html in your browser, OR
echo     - Double-click frontend\start_chat.bat
echo     - OR run scripts\run_50.bat (the 50-question test)
echo.
echo   TO STOP:
echo     Click this window and press Ctrl+C
echo ==========================================================================
echo.

cd /d "%~dp0..\backend"
python -m uvicorn main:app --host 127.0.0.1 --port 8000

echo.
echo ==========================================================================
echo   The backend has stopped.
echo ==========================================================================
echo.
echo   If it crashed, the most common reasons are:
echo     - "Address already in use" : port 8000 is busy. Close the other
echo       program using it, or change the port at the bottom of this .bat.
echo     - "No module named 'X'"    : a dependency did not install. Re-run
echo       this .bat and watch step [3/4] for the error message.
echo.
pause
endlocal

@echo off
REM ==========================================================================
REM  ChaloSchools AI Secretary - LLM Server Launcher
REM  Double-click this file to start the llama.cpp LLM server.
REM ==========================================================================

setlocal enabledelayedexpansion

REM -- YOUR PATHS (already set - no need to edit) ----------------------------
REM (If you move llama-server.exe or your GGUF, edit the two lines below.)
REM
REM NOTE TO AI ASSISTANT: do NOT change these back to placeholder paths.
REM The user has confirmed these are their actual file locations.

REM Path to llama-server.exe (the AI runtime, from llama.cpp)
set "LLAMA_SERVER=D:\llama-b6691\llama-server.exe"

REM Path to your trained GGUF model file (the AI brain, about 4-5 GB)
set "MODEL_PATH=D:\ggufs\AISv27-qwen2.5-coder-7b-instruct.Q4_K_M.gguf"

REM Context size. TRAINING used 2560 (a fine-tuning constraint that prevents
REM silent truncation of examples). INFERENCE can and should use more.
REM 2026-09-04: raised 2560 -> 4096 to fit the expanded system prompt
REM (ERP schema knowledge, ~1300 tokens). The two changes go together
REM (see docs/SESSION_HANDOFF.md, update 2026-09-04).
REM Rollback: set this back to 2560 AND set AI_SECRETARY_PROMPT_PROFILE=legacy
REM in backend\.env (both together, or the prompt may get truncated).
set "CTX_SIZE=4096"

REM ==========================================================================
echo ==========================================================================
echo   ChaloSchools AI Secretary - LLM Server Launcher
echo ==========================================================================
echo.
echo   llama-server.exe : %LLAMA_SERVER%
echo   GGUF model file  : %MODEL_PATH%
echo   Context size      : %CTX_SIZE%
echo   Port              : 8080 (host: 127.0.0.1, localhost only)
echo.

REM -- STEP 1: Check that llama-server.exe exists ----------------------------
if not exist "%LLAMA_SERVER%" goto :no_llama

REM -- STEP 2: Check that the GGUF model file exists -------------------------
if not exist "%MODEL_PATH%" goto :no_model

REM -- Both files exist - start the LLM server --------------------------------
echo   Both files found. Starting llama-server...
echo.
echo ==========================================================================
echo   Wait until you see a line like:
echo      "server listening on 127.0.0.1:8080"
echo   That means the LLM is ready.
echo.
echo   THEN:
echo     In ANOTHER window, double-click scripts\start_backend.bat
echo     Then open frontend\chat.html in your browser.
echo.
echo   TO STOP:
echo     Click this window and press Ctrl+C
echo ==========================================================================
echo.

"%LLAMA_SERVER%" -m "%MODEL_PATH%" --host 127.0.0.1 --port 8080 --ctx-size %CTX_SIZE%

echo.
echo ==========================================================================
echo   The LLM server has stopped.
echo ==========================================================================
echo.
echo   If it crashed, common reasons:
echo     - "out of memory"  : the GGUF is too big for your RAM. Try a smaller
echo                          quantization (Q3_K_S is half the size of Q4_K_M).
echo     - "CUDA error"     : the GPU is not available. llama.cpp will fall
echo                          back to CPU automatically - just wait longer.
echo     - "port in use"    : another llama-server is already running. Close
echo                          it (Ctrl+C in its window) and try again.
echo.
pause
exit /b 0

:no_llama
echo.
echo   ERROR: llama-server.exe was NOT found at:
echo     %LLAMA_SERVER%
echo.
echo   HOW TO GET IT (free, about 5 minutes):
echo     1. Open this URL in your browser:
echo          https://github.com/ggerganov/llama.cpp/releases
echo     2. Find the latest release. Download the Windows asset that looks
echo        like:  llama-bXXXX-bin-win-avx2-x64.zip
echo        (pick "avx2" for a normal modern PC)
echo     3. Unzip it to  D:\llama.cpp\
echo        (you should end up with  D:\llama.cpp\llama-server.exe)
echo     4. If you unzipped it somewhere else, edit the LLAMA_SERVER line
echo        at the top of this .bat to match.
echo     5. Double-click this .bat again.
echo.
pause
exit /b 1

:no_model
echo.
echo   ERROR: the GGUF model file was NOT found at:
echo     %MODEL_PATH%
echo.
echo   HOW TO GET IT (this is the trained "brain" of the AI Secretary):
echo.
echo   OPTION A - you already trained the model:
echo     If you ran the notebooks in the training\ folder, you should have a
echo     file like:  qwen25coder_chaloschools_v27.gguf  (about 4-5 GB)
echo     Put it at the path shown above, OR edit the MODEL_PATH line at the
echo     top of this .bat to point to where it actually is.
echo.
echo   OPTION B - you don't have the GGUF yet:
echo     See docs\diagrams\04-llm-setup.drawio for where the GGUF goes.
echo     To CREATE one, run the two notebooks in training\:
echo       1. finetune_qwen25coder_TRAIN_KAGGLE_v27.ipynb  (Kaggle, about 4h)
echo       2. finetune_qwen25coder_GGUF_EXPORT_COLAB_v27.ipynb (Colab, 30 min)
echo.
echo   OPTION C - quick test with ANY GGUF:
echo     Download any small GGUF from Hugging Face (e.g. "Qwen 2.5 Coder 7B
echo     Instruct Q4_K_M") and point MODEL_PATH to it. SQL quality will be
echo     lower (it's not fine-tuned for your schema), but the UI will work.
echo.
pause
exit /b 1

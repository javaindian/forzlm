"""
main.py — ChaloSchools AI Secretary API Service (VAPT-hardened + admin config + audit)
=====================================================================================
"""
from __future__ import annotations
import os, sys, re, json, time, traceback, secrets, queue, threading
import datetime  # ux-2026-09-10 (date_format): dd-mm-yyyy display rule helpers
from typing import Any, Dict, List, Optional

# Auto-load backend/.env if it exists (so users don't have to set env vars manually).
# Falls back silently if python-dotenv isn't installed or .env is missing.
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))
except ImportError:
    pass  # python-dotenv not installed — env vars must be set in the shell
except Exception:
    pass  # .env file missing or unreadable — fall back to defaults

from pydantic import BaseModel, Field

HERE = os.path.dirname(os.path.abspath(__file__))
PIPELINE = os.path.join(os.path.dirname(HERE), "pipeline")
VOCAB = os.path.join(os.path.dirname(HERE), "vocab")
for p in (PIPELINE, VOCAB, os.path.dirname(HERE)):
    if p not in sys.path:
        sys.path.insert(0, p)

from fastapi import FastAPI, HTTPException, Depends, Header, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

import erp_config  # v97: erp_config.json = the ONE file for ERP URLs/keys/inline-params
from security import (
    get_tenant_api_key, log_audit, detect_prompt_injection,
    reinforce_prompt, sanitize_question, safe_error_message, LLM_TIMEOUT_SECONDS,
)

# ── Config ──────────────────────────────────────────────────────────────────────

# v98: baked-in defaults now MATCH the tokens baked into chat.html v10 / audit.html v2.2.
# If AI_SECRETARY_*_TOKENS is set in the .env, the .env wins — keep them in sync.
AUTH_TOKENS = set(t.strip() for t in os.environ.get("AI_SECRETARY_AUTH_TOKENS", "aisecretary-dev-token").split(",") if t.strip())
ADMIN_TOKENS = set(t.strip() for t in os.environ.get("AI_SECRETARY_ADMIN_TOKENS", "aisecretary-admin-token").split(",") if t.strip())
CORS_ORIGINS = [o.strip() for o in os.environ.get("AI_SECRETARY_CORS_ORIGINS", "*").split(",") if o.strip()]

# ── Rate limiting (V1) ─────────────────────────────────────────────────────────
_RATE_LIMIT_IP: Dict[str, List[float]] = {}
_RATE_LIMIT_TOKEN: Dict[str, List[float]] = {}
RATE_LIMIT_IP_PER_MIN = int(os.environ.get("AI_SECRETARY_RATE_LIMIT_IP", "100"))
RATE_LIMIT_TOKEN_PER_MIN = int(os.environ.get("AI_SECRETARY_RATE_LIMIT_TOKEN", "20"))

def _check_rate_limit(key, store, limit):
    now = time.time()
    store[key] = [t for t in store.get(key, []) if t > now - 60]
    if len(store[key]) >= limit: return False
    store[key].append(now)
    return True

# ── Feature flags (admin config UI) ────────────────────────────────────────────
FEATURE_FLAGS = {
    "auto_chart": False, "insight_cards": False, "trend_comparison": False,
    "drill_down": False, "morning_briefing": False, "anomaly_alerts": False,
    "you_might_also_ask": False, "hinglish_tamil": False, "school_jargon": False,
    "voice_input": False, "why_this_answer": False, "capability_card": False,
    "share_qa": False, "pin_questions": False, "schedule_questions": False,
    "feedback_loop": False, "question_clustering": False, "active_learning": False,
    "multi_school_benchmark": False, "parent_mode": False, "teacher_mode": False,
    "confidence_score": False, "source_sp": False, "audit_trail": False,
}
FEATURE_OVERRIDES_PATH = os.environ.get("AI_SECRETARY_FEATURE_OVERRIDES", os.path.join(HERE, "feature_overrides.json"))
def _load_feature_overrides():
    global FEATURE_FLAGS
    try:
        with open(FEATURE_OVERRIDES_PATH, encoding="utf-8") as f:
            FEATURE_FLAGS.update({k: bool(v) for k, v in json.load(f).items() if k in FEATURE_FLAGS})
    except (FileNotFoundError, json.JSONDecodeError): pass
def _save_feature_overrides():
    try:
        # Read the existing file first so non-flag keys (e.g. "fallback_message")
        # survive admin PUTs that only rewrite FEATURE_FLAGS.
        merged: Dict[str, Any] = {}
        try:
            with open(FEATURE_OVERRIDES_PATH, encoding="utf-8") as f:
                merged = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            pass
        merged.update(FEATURE_FLAGS)
        with open(FEATURE_OVERRIDES_PATH, "w", encoding="utf-8") as f:
            json.dump(merged, f, indent=2)
    except Exception: pass
_load_feature_overrides()

# ── Standard reply for unanswerable questions (UI/UX item 4, 2026-09-04) ───────
# When the outcome is REFUSED / ERROR / NEEDS_DISAMBIGUATION, the user-facing
# `message` is replaced with this standard reply; the original message moves
# into `detail` (and semantic_violations are untouched) so debugging is
# unaffected. Configuration priority:
#   1. AI_SECRETARY_FALLBACK_MESSAGE env var (backend/.env)
#   2. "fallback_message" string key in feature_overrides.json
#   3. DEFAULT_FALLBACK_MESSAGE below
# Set the env var to an EMPTY string to disable replacement (show raw messages).
DEFAULT_FALLBACK_MESSAGE = ("I'm sorry, I couldn't answer that question. "
                            "Please try rephrasing it, or ask a different question.")
def _load_fallback_message() -> str:
    env_val = os.environ.get("AI_SECRETARY_FALLBACK_MESSAGE")
    if env_val is not None:
        return env_val
    try:
        with open(FEATURE_OVERRIDES_PATH, encoding="utf-8") as f:
            v = json.load(f).get("fallback_message")
        if isinstance(v, str):
            return v
    except (FileNotFoundError, json.JSONDecodeError):
        pass
    return DEFAULT_FALLBACK_MESSAGE
FALLBACK_MESSAGE = _load_fallback_message()

# ── UX config (2026-09-09): one editable file for the chat-UI feature set ──────
# ux_config.json lives in the PROJECT ROOT (next to erp_config.json) and is the
# single switchboard for every chat-UI UX feature:
#   features.chat_export           ⬇ Export button under each answer table
#   features.zero_result_guidance  friendly "nothing matched" block + hint text
#   features.thumbs_feedback       👍/👎 under each answer (+ POST /api/feedback)
#   features.suggestions_panel     "What can I ask?" chips above the composer
#   features.typeahead_suggest     as-you-type suggestions from known questions
#   features.refusal_translation   rule codes -> human sentences on refusals
#   features.clarification_chips   tappable options on NEEDS_DISAMBIGUATION
#   features.kpi_delta             ▲/▼ vs previous period on single-value answers
#   features.svg_charts            auto bar-chart for small date/period series
# Apply a change: edit ux_config.json -> sudo systemctl restart chalo-backend.
# Missing file / bad JSON = safe defaults below (feature never breaks the app).
UX_CONFIG_PATH = os.environ.get("AI_SECRETARY_UX_CONFIG", os.path.join(os.path.dirname(HERE), "ux_config.json"))
UX_DEFAULTS: Dict[str, Any] = {
    "features": {
        "chat_export": True, "zero_result_guidance": True, "thumbs_feedback": True,
        "suggestions_panel": True, "typeahead_suggest": True, "refusal_translation": True,
        "clarification_chips": True, "kpi_delta": True, "svg_charts": True,
    },
    "suggested_questions": [
        "How much fee is pending for the whole school?",
        "How many students are there in class 10?",
        "Who are the top 5 students in the latest exam?",
        "How much fee was collected this month?",
        "Which students have the lowest attendance?",
        "How many staff members are there?",
        "Show the fee defaulters list.",
        "What is the pass percentage for class 10?",
    ],
    "feedback_reasons": ["Wrong numbers", "Misunderstood my question", "Outdated data", "Too slow", "Other"],
    "refusal_messages": {},  # rule_id -> custom text (overrides built-ins)
    "zero_result_message": ("No records matched this question for your current filters. "
                            "Try a wider date range, a different class or section, or ask for all terms."),
}
def _load_ux_config() -> Dict[str, Any]:
    cfg = json.loads(json.dumps(UX_DEFAULTS))  # deep copy of defaults
    try:
        with open(UX_CONFIG_PATH, encoding="utf-8") as f:
            disk = json.load(f)
        feats = disk.pop("features", None)
        if isinstance(feats, dict):
            cfg["features"].update({k: bool(v) for k, v in feats.items() if k in cfg["features"]})
        for k, v in disk.items():
            if k in cfg and not k.startswith("_"):
                cfg[k] = v
    except (FileNotFoundError, json.JSONDecodeError, OSError, ValueError):
        pass  # missing/corrupt file -> defaults; the UI never breaks because of config
    return cfg
UX_CONFIG = _load_ux_config()

# Built-in human sentences for the most common rule-code refusals (editable /
# extendable per rule id via ux_config.json "refusal_messages").
RULE_FRIENDLY: Dict[str, str] = {
    "FEE-007": "This fee question needs an academic year to answer safely. Ask it with a year — for example “fee outstanding this academic year”.",
    "FEE-005": "This fee question needs a clearer fee head or structure type. Try naming the specific fee (tuition, transport, exam fee…).",
    "SUBJ-001": "Subjects are shown by name, not by code. Ask the question with a subject name — for example “marks in Mathematics”.",
    "MARKS-001": "Marks answers show scored marks out of the maximum. Ask for a subject or exam to see the scored/max breakdown.",
    "MARKS-002": "A student marked AB (absent) counts as failed in that subject — the answer reflects that rule.",
    "MARKS-003": "Totals and averages leave out NA/NT/OP entries, so the numbers here match the official report cards.",
    "STUD-004": "This student question needs a specific class or section. Try adding it — for example “…in class 8 section B”.",
    "STUD-006": "This question needs a clearer class or student name. Try naming the class and section exactly.",
    "EXAM-007": "This exam question needs a term or exam name. Try adding the term — for example “…in Term 2”.",
    "RBAC-SALARY": "Salary details are restricted. Only authorised roles can ask about staff salary.",
    "PII-001": "I can share contact details for one specific student or staff member — but not as a bulk list. Try asking about a single person (for example, by admission number).",
    "DEFAULT": None,
}

# FAST PATH default (2026-09-05): OR-ed with the frontend's Fast Paths
# checkbox. Default ON (v28 dataset execution-verified). Set
# AI_SECRETARY_FAST_PATHS=0 in backend/.env to force LLM-only.
FAST_PATHS_DEFAULT = os.environ.get("AI_SECRETARY_FAST_PATHS", "1").strip().lower() not in ("0", "false", "no", "off")

# STAGE STREAMING default (2026-09-06): POST /api/chat/stream narrates real
# pipeline progress to the frontend over SSE. Same auth, same rate limits,
# same _chat_core implementation and audit trail as POST /api/chat — only
# the transport differs. Set AI_SECRETARY_STREAM=0 in backend/.env to
# disable (endpoint returns 501; the frontend falls back automatically).
STREAM_DEFAULT = os.environ.get("AI_SECRETARY_STREAM", "1").strip().lower() not in ("0", "false", "no", "off")

FEATURE_DESCRIPTIONS = {
    "auto_chart": "Auto-chart result tables (mobile-app rendering)", "insight_cards": "1-3 auto-generated insight cards",
    "trend_comparison": "This-year-vs-last-year auto-add", "drill_down": "Tappable rows -> follow-ups",
    "morning_briefing": "Scheduled 6am job + push (requires scheduler)", "anomaly_alerts": "Nightly anomaly detection + push",
    "you_might_also_ask": "3 follow-up suggestions after each answer", "hinglish_tamil": "Bilingual mode (needs v28 retrain)",
    "school_jargon": "Jargon glossary in the system prompt", "voice_input": "STT integration (mobile-app)",
    "why_this_answer": "'Why this answer?' expandable (SQL explanation)", "capability_card": "What I can/can't answer page",
    "share_qa": "Deep-link sharing", "pin_questions": "Pin frequent questions to home screen",
    "schedule_questions": "Scheduled queries + push (requires scheduler)", "feedback_loop": "Thumbs up/down on every answer",
    "question_clustering": "Weekly question clustering report", "active_learning": "Chatbot asks admin for help on gaps",
    "multi_school_benchmark": "Cross-branch comparison (super-user)", "parent_mode": "Parent-facing (needs parent RBAC)",
    "teacher_mode": "Teacher-facing (needs class-teacher RBAC)", "confidence_score": "Green/amber dot on every answer",
    "source_sp": "Show the stored procedure the query is based on", "audit_trail": "Show audit trail in admin UI (always logged)",
}

# ── Pipeline imports (lazy) ────────────────────────────────────────────────────
_orchestrator = None
def _load_pipeline():
    global _orchestrator
    if _orchestrator is not None: return _orchestrator
    from orchestrator import Orchestrator
    from context import UserContext, Branch, build_context_from_json
    from vocab.inject import parse_context_json, SynonymStore
    from value_resolver import ValueValidator
    from llm_client import LlamaCppClient
    import entity_extractor
    from parameter_binder import ParameterBinderExecutor

    # FAST PATH (latency, wired 2026-09-05): normalized-exact dataset
    # lookup + 4 template lookups, checked BEFORE the LLM (D1.9 gate).
    # v28 dataset is execution-verified (4,034/0), so the original
    # label-noise caution no longer applies. Fast-path SQL still passes
    # the FULL fail-closed chain — nothing here bypasses any check.
    from dataset_lookup import DatasetLookup
    from template_lookups import (ClassTemplateLookup, TopNTemplateLookup,
                                  SectionTemplateLookup, ClassSectionTemplateLookup)
    from template_lookups import ShorthandClassSectionLookup  # added 2026-09-06
    # 2026-09-04: system prompt now comes from schema_knowledge.py — the
    # single source of truth built from the ERP codebase-analysis extracts.
    # The FROZEN v27 text still leads, byte-for-byte; the knowledge block is
    # appended after it. Profile via env var AI_SECRETARY_PROMPT_PROFILE
    # ("expanded" default | "legacy" rollback), see pipeline/schema_knowledge.py.
    try:
        from schema_knowledge import build_system_prompt, prompt_profile
    except ImportError:
        from pipeline.schema_knowledge import build_system_prompt, prompt_profile
    _orchestrator = {"Orchestrator": Orchestrator, "UserContext": UserContext, "Branch": Branch,
        "build_context_from_json": build_context_from_json, "parse_context_json": parse_context_json,
        "SynonymStore": SynonymStore, "ValueValidator": ValueValidator,
        "LlamaCppClient": LlamaCppClient, "entity_extractor": entity_extractor,
        "ParameterBinderExecutor": ParameterBinderExecutor,
        "build_system_prompt": build_system_prompt, "prompt_profile": prompt_profile}
    # Wire the fast-path lookups (all read the same JSONL,
    # {"input": question, "output": sql} per line; path overridable via
    # AI_SECRETARY_DATASET_JSONL). Load failure = fail-open to LLM-only.
    # 2026-09-10 (alignment audit): the index now prefers the CLEANED v29
    # dataset (3,939 rows, 59-rule verified, bulk-PII-free). The v28 index
    # still contained a bulk parent-contact list (train_v28#2764) and other
    # rows removed during the v29 cleanup — a fast-path hit on those served
    # them verbatim. Falls back to v28 only if the v29 file is missing.
    _train_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "training")
    dataset_jsonl = os.environ.get("AI_SECRETARY_DATASET_JSONL") or (
        os.path.join(_train_dir, "train_v29.jsonl")
        if os.path.isfile(os.path.join(_train_dir, "train_v29.jsonl"))
        else os.path.join(_train_dir, "train_v28.jsonl"))
    try:
        _orchestrator["dataset_lookup"] = DatasetLookup(dataset_jsonl)
        _orchestrator["class_template_lookup"] = ClassTemplateLookup(dataset_jsonl)
        _orchestrator["top_n_template_lookup"] = TopNTemplateLookup(dataset_jsonl)
        _orchestrator["section_template_lookup"] = SectionTemplateLookup(dataset_jsonl)
        _orchestrator["class_section_template_lookup"] = ClassSectionTemplateLookup(dataset_jsonl)
        _orchestrator["shorthand_class_section_lookup"] = ShorthandClassSectionLookup(dataset_jsonl)
        print(f"[fastpath] loaded {len(_orchestrator['dataset_lookup'])} Q->SQL entries "
              f"+ 5 template indexes from {dataset_jsonl}", flush=True)
    except Exception as _e:
        print(f"[fastpath] lookup load FAILED ({_e}) — running LLM-only", flush=True)
        for _k in ("dataset_lookup", "class_template_lookup", "top_n_template_lookup",
                   "section_template_lookup", "class_section_template_lookup",
                   "shorthand_class_section_lookup"):
            _orchestrator.setdefault(_k, None)
    # 2026-09-05 v2 (FIX B): wire the schema guardrail + alias-scope 2nd pass.
    # v1.3.0 left them None (traces showed no guardrail lines). Guardrail
    # checks tables/columns against schema_catalog.json; alias_scope catches
    # Msg 4104/209 out-of-scope aliases BEFORE execution. Kill switch:
    # AI_SECRETARY_GUARDRAIL=0 in backend/.env.
    if os.environ.get("AI_SECRETARY_GUARDRAIL", "1").strip().lower() not in ("0", "false", "no", "off"):
        try:
            from guardrail import validate_sql as _guardrail_validate
            from alias_scope_check import check_alias_scope as _alias_scope_check
            _orchestrator["guardrail_validate"] = _guardrail_validate
            _orchestrator["alias_scope"] = _alias_scope_check
            print("[guardrail] schema guardrail + alias-scope wired", flush=True)
        except Exception as _e:
            print(f"[guardrail] load FAILED ({_e}) — running without schema guardrail", flush=True)
    return _orchestrator

app = FastAPI(title="ChaloSchools AI Secretary API", version="1.3.0",
    description="Production backend (VAPT-hardened) for the ChaloSchools AI Secretary chatbot.")
app.add_middleware(CORSMiddleware, allow_origins=CORS_ORIGINS, allow_credentials=True, allow_methods=["*"], allow_headers=["*"])


# ── LLM warmup (2026-09-06): hides the cold-start prefill after restarts ─────
# Fires ONE max_tokens=1 generation with the real system prompt in a daemon
# thread at startup, so llama.cpp caches the shared prefix and the FIRST real
# question after a restart skips the ~60s cold prefill. Fail-silent by design;
# disable with AI_SECRETARY_LLM_WARMUP=0 in backend/.env.
@app.on_event("startup")
def _llm_warmup() -> None:
    if os.environ.get("AI_SECRETARY_LLM_WARMUP", "1").strip().lower() in ("0", "false", "no", "off"):
        return

    def _warm() -> None:
        import json as _json
        import urllib.request as _urlreq
        import time as _time
        # v98: llama-server takes 20-45s to load the model. The old one-shot
        # warmup fired once during that window, hit ConnectionRefused, printed
        # "skipped", and never tried again — the first real user then ate the
        # whole 30-60s cold start. Now: retry every 5s for up to 12 minutes,
        # stop at the first success. Kill switch: AI_SECRETARY_WARMUP=0.
        if os.environ.get("AI_SECRETARY_WARMUP", "1") == "0":
            return
        _url = os.environ.get("AI_SECRETARY_WARMUP_URL",
                              "http://localhost:8080/v1/chat/completions")
        _deadline = _time.time() + 720  # 12 minutes
        _attempt = 0
        while _time.time() < _deadline:
            _attempt += 1
            try:
                P = _load_pipeline()
                _sp = P["build_system_prompt"]()
                _body = _json.dumps({"messages": [
                    {"role": "system", "content": _sp},
                    {"role": "user", "content": "warmup"}],
                    "max_tokens": 1, "temperature": 0.0}).encode("utf-8")
                _req = _urlreq.Request(_url, data=_body,
                                       headers={"Content-Type": "application/json"})
                _urlreq.urlopen(_req, timeout=300)
                print(f"[warmup] llama.cpp KV prefix warmed after {_attempt} "
                      f"attempt(s) (cold-start prefill hidden)", flush=True)
                return
            except Exception as _e:
                if _attempt == 1:
                    print(f"[warmup] attempt {_attempt} failed ({_e}) — "
                          f"retrying every 5s until llama-server is up", flush=True)
                _time.sleep(5)
        print("[warmup] gave up after 12 minutes — first question may be slow", flush=True)

    import threading as _threading
    _threading.Thread(target=_warm, daemon=True, name="llm-warmup").start()

# ── Auth dependencies ───────────────────────────────────────────────────────────
security = HTTPBearer(auto_error=False)
async def require_auth(credentials: HTTPAuthorizationCredentials = Depends(security)):
    if not credentials: raise HTTPException(401, "Missing Authorization header. Expected: Bearer <token>")
    token = credentials.credentials
    if not any(secrets.compare_digest(token, t) for t in AUTH_TOKENS): raise HTTPException(401, "Invalid auth token")
    return token
async def require_admin(credentials: HTTPAuthorizationCredentials = Depends(security)):
    if not credentials: raise HTTPException(401, "Missing Authorization header. Expected: Bearer <admin-token>")
    token = credentials.credentials
    if not any(secrets.compare_digest(token, t) for t in ADMIN_TOKENS): raise HTTPException(403, "Admin access required")
    return token
async def check_rate_limit(request: Request, token: str = Depends(require_auth)):
    ip = request.client.host if request.client else "unknown"
    if not _check_rate_limit(f"ip:{ip}", _RATE_LIMIT_IP, RATE_LIMIT_IP_PER_MIN): raise HTTPException(429, "Too many requests from this IP.")
    if not _check_rate_limit(f"token:{token}", _RATE_LIMIT_TOKEN, RATE_LIMIT_TOKEN_PER_MIN): raise HTTPException(429, "Too many requests.")
    return token

# ── Models ─────────────────────────────────────────────────────────────────────
class ChatRequest(BaseModel):
    question: str = Field(..., min_length=1, max_length=1000)
    context_json: Dict[str, Any]
    branch_id: Optional[int] = None
    model_url: str = "http://localhost:8080/v1/chat/completions"
    inject_vocab: bool = False
    fast_paths: bool = False
    temperature: float = 0.0
    max_tokens: int = 768  # v63: 512 truncated some complex SQL (D1.8 refusals); 768 cuts "Output truncated" errors. Only caps — normal short answers unaffected
    clm_tier: str = "clm1"  # CLM r1: UI modelSelect (clm1/clm2/clm3); enforced server-side by clm_gate
    mode: str = "dry_run"
    api_wrapper_url: str = ""  # v97: optional legacy fallback; erp_config.json wins
    target_database: str = ""
    page_number: int = Field(1, ge=1)
    page_size: int = Field(10, ge=1, le=100)
class ChatResponse(BaseModel):
    outcome: str; stage: str; sql: Optional[str] = None; sql_source: Optional[str] = None
    bound_request: Optional[Dict] = None; columns: List[str] = Field(default_factory=list)
    rows: List[Any] = Field(default_factory=list); total_row_count: Optional[int] = None
    total_pages: Optional[int] = None; disambiguation: Optional[Dict] = None
    message: Optional[str] = None; detail: Optional[str] = None; fallback_used: Optional[bool] = None
    trace: List[str] = Field(default_factory=list); semantic_violations: List[Dict] = Field(default_factory=list)
    latency_ms: float = 0.0; features_enabled: List[str] = Field(default_factory=list)
    stage_timings: Optional[Dict[str, Dict]] = None   # audit-trace-2026-09-06
    # ux-2026-09-09: clarification chips (missing @AcademicYearID) + KPI trend
    need_params: Optional[Dict] = None
    kpi_delta: Optional[Dict] = None
class FeatureFlagsResponse(BaseModel):
    flags: Dict[str, bool]; descriptions: Dict[str, str]
class FeatureFlagsUpdate(BaseModel):
    flags: Dict[str, bool]

# ── Endpoints ─────────────────────────────────────────────────────────────────
@app.get("/api/health")
def health():
    try:
        P = _load_pipeline(); from semantic_rules import rule_count
        return {"status": "ok", "pipeline_loaded": True, "rules_count": rule_count(),
                "version": "1.3.0", "prompt_profile": P["prompt_profile"](),
                "stream": STREAM_DEFAULT,
                "fallback_message_active": bool(FALLBACK_MESSAGE)}
    except Exception:
        return {"status": "degraded", "pipeline_loaded": False, "rules_count": 0,
                "version": "1.3.0"}

@app.post("/api/chat", response_model=ChatResponse)
def chat(req: ChatRequest, request: Request, token: str = Depends(check_rate_limit)):
    # 2026-09-06 (stream): body moved VERBATIM into _chat_core() below so the
    # SSE endpoint shares ONE implementation — zero drift between the two.
    return _chat_core(req, request.client.host if request.client else "unknown", emit=None)


# ── UX helpers (2026-09-09) ────────────────────────────────────────────────────
_ISO_DATE = re.compile(r"^(\d{4})-(\d{2})-(\d{2})")

def _shift_iso_month(val: str, months: int) -> Optional[str]:
    """Shift an ISO date/datetime string by whole months, clamping the day.
    Returns None when the value is not a shiftable date."""
    m = _ISO_DATE.match(str(val).strip())
    if not m:
        return None
    y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
    try:
        import datetime as _dt
        _dt.date(y, mo, d)  # validate real date
    except ValueError:
        return None
    total = (y * 12 + (mo - 1)) + months
    ny, nmo = divmod(total, 12)
    nmo += 1
    nd = min(d, [31, 29 if (ny % 4 == 0 and (ny % 100 != 0 or ny % 400 == 0)) else 28,
                 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][nmo - 1])
    tail = str(val).strip()[10:]  # keep " HH:MM:SS..." if present
    return f"{ny:04d}-{nmo:02d}-{nd:02d}{tail}"

# ── ux-2026-09-10 (date_format): school rule — dates ALWAYS display dd-mm-yyyy ──
# The dataset teaches native date columns (no CONVERT display styles), so the
# yyyy-mm-dd look came from JSON serialization (pyodbc date objects -> ISO, and
# .NET ERP-API dates arrive as ISO strings). ONE formatting point here fixes
# every path: fastpath, templates, LLM, local_db AND api_wrapper. WHERE-clause
# date literals are deliberately untouched (internal, execution-verified).
_DATE_CELL_ISO = re.compile(
    r"^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}:\d{2})(?::(\d{2}))?(\.\d+)?)?$")

def _fmt_date_cell(v):
    """Render one cell's date value as dd-mm-yyyy (school display rule)."""
    if isinstance(v, datetime.datetime):
        return (v.strftime("%d-%m-%Y %H:%M:%S")
                if (v.hour or v.minute or v.second or v.microsecond)
                else v.strftime("%d-%m-%Y"))
    if isinstance(v, datetime.date):
        return v.strftime("%d-%m-%Y")
    if isinstance(v, str):
        m = _DATE_CELL_ISO.match(v.strip())
        if m:
            y, mo, d = m.group(1), m.group(2), m.group(3)
            t = m.group(4)
            if t and t == "00:00" and m.group(5) in (None, "00"):
                t = None  # midnight: show the plain date (matches native datetime)
            out = f"{d}-{mo}-{y}"
            if t:
                out += " " + t + (":" + m.group(5) if m.group(5) else "")
            return out
    return v

def _fmt_dates_for_display(rows):
    """Apply the dd-mm-yyyy display rule to every cell of a result set."""
    if not rows:
        return rows
    return [[_fmt_date_cell(c) for c in r] for r in rows]

def _kpi_delta(result, binder) -> Optional[Dict[str, Any]]:
    """▲/▼ vs the previous period for single-value answers.

    Fires ONLY when it is provably safe: outcome ANSWER, exactly 1 row × 1
    numeric column, and the bound request carries explicit date-like
    parameters (ISO dates or a plain @Year int). The same SQL re-runs with
    every such parameter shifted back one month (or one year for @Year) and
    the delta is computed client-side by the UI. GETDATE()-style SQL has no
    date params -> no delta (never rewrites SQL text here). ANY failure or
    doubt returns None — the main answer is never affected."""
    try:
        rows = result.rows or []
        cols = result.columns or []
        if len(rows) != 1 or len(cols) != 1:
            return None
        cur = rows[0][0] if rows[0] else None
        if not isinstance(cur, (int, float)) or isinstance(cur, bool):
            try:
                cur = float(cur)
            except (TypeError, ValueError):
                return None
        br = result.bound_request
        params = None
        if br is not None:
            params = br.parameters if hasattr(br, "parameters") else br.get("parameters")
        if not isinstance(params, dict) or not params:
            return None
        shifted: Dict[str, Any] = {}
        n_dates = 0
        label = "vs previous month"
        for k, v in params.items():
            lname = str(k).lower()
            if isinstance(v, str) and _ISO_DATE.match(v.strip()):
                n_dates += 1
                sv = _shift_iso_month(v, -1)
                if sv is None:
                    return None  # unshiftable date present -> no delta at all
                shifted[k] = sv
            elif isinstance(v, int) and 1990 <= v <= 2100 and "year" in lname and not lname.endswith("id"):
                n_dates += 1
                shifted[k] = v - 1
                label = "vs previous year"
            # other params pass through untouched below
        if n_dates == 0:
            return None
        merged = dict(params)
        merged.update(shifted)
        sql = result.sql or (br.sql_query if hasattr(br, "sql_query") else None)
        if not sql:
            return None
        prev_res = binder.execute(sql, merged)
        prev_rows = getattr(prev_res, "rows", None) if getattr(prev_res, "ok", False) else None
        if not prev_rows or len(prev_rows) != 1:
            return None
        prev = prev_rows[0][0] if prev_rows[0] else None
        if isinstance(prev, str):
            try:
                prev = float(prev)
            except (TypeError, ValueError):
                return None
        if not isinstance(prev, (int, float)) or isinstance(prev, bool) or float(prev) == 0:
            return None
        pct = round((float(cur) - float(prev)) / abs(float(prev)) * 100.0, 1)
        if pct != pct:  # NaN guard
            return None
        return {"current": cur, "previous": prev, "pct": pct,
                "direction": "up" if pct >= 0 else "down", "label": label}
    except Exception:
        return None  # delta is decoration — never break the answer

def _academic_year_options(context_json: Any) -> Optional[List[Dict[str, Any]]]:
    """Pull the academic-year list out of the raw Context JSON for chips.
    ERP shape: UserMasterDetails.UserBranchDetails[*].AcademicYears[*]
    {Id, Name, IsCurrentYear}; a root-level AcademicYears list also accepted.
    A wrong/unknown shape simply yields None (no chips)."""
    try:
        lists: List[Any] = []
        if isinstance(context_json, dict):
            if isinstance(context_json.get("AcademicYears"), list):
                lists.append(context_json["AcademicYears"])
            umd = context_json.get("UserMasterDetails") or {}
            for b in (umd.get("UserBranchDetails") or []):
                if isinstance(b, dict) and isinstance(b.get("AcademicYears"), list):
                    lists.append(b["AcademicYears"])
        out: List[Dict[str, Any]] = []
        for years in lists:
            for y in years:
                if not isinstance(y, dict):
                    continue
                yid = y.get("Id", y.get("ID", y.get("id")))
                name = y.get("Name") or y.get("Year") or y.get("name") or (str(yid) if yid else None)
                if yid is None or not name:
                    continue
                entry = {"id": yid, "label": str(name),
                         "is_current": bool(y.get("IsCurrentYear", y.get("isCurrentYear", False)))}
                if not any(o["id"] == yid for o in out):
                    out.append(entry)
        return out or None
    except Exception:
        return None

def _need_params_from_bind_error(exc: Exception, context_json: Any) -> Optional[Dict[str, Any]]:
    """Missing @AcademicYearID in the model SQL -> structured chip payload.
    The year is a SECURITY param resolved from the trusted Context JSON (D1.3),
    so the frontend fixes it by flagging the chosen year in its saved context
    and resending — no free-text injection anywhere. Any other placeholder
    stays a normal error."""
    try:
        if "AcademicYearID" not in str(exc):
            return None
        opts = _academic_year_options(context_json)
        if not opts:
            return None
        return {"param": "AcademicYearID",
                "options": [{"value": o["id"], "label": o["label"]} for o in opts],
                "message": "Which academic year should I use?"}
    except Exception:
        return None

def _friendly_refusal(outcome_str: str, result, sem_violations: List[Dict]) -> Optional[str]:
    """Human sentence for refusals. Priority: ux_config override for the rule id
    > built-in RULE_FRIENDLY > pipeline's own message when it is already
    parent-friendly > None (generic fallback applies)."""
    try:
        overrides = UX_CONFIG.get("refusal_messages") or {}
        if outcome_str == "NEEDS_DISAMBIGUATION":
            d = getattr(result, "disambiguation", None) or {}
            ctype = str(d.get("concept_type") or "value")
            return f"Your question matches more than one {ctype.lower()}. Pick the one you meant:"
        if outcome_str == "REFUSED" and sem_violations:
            rid = str(sem_violations[0].get("rule_id") or "")
            if rid and rid in overrides and isinstance(overrides[rid], str):
                return overrides[rid]
            if rid and RULE_FRIENDLY.get(rid):
                return RULE_FRIENDLY[rid]
            if RULE_FRIENDLY.get("DEFAULT"):
                return RULE_FRIENDLY["DEFAULT"]
            return None
        # REFUSED without rule violations: the pipeline message is already
        # parent-friendly ("I don't recognize “X” as a class at your branch.")
        if outcome_str == "REFUSED" and getattr(result, "message", None):
            return str(result.message)
    except Exception:
        return None
    return None

# ── Typeahead index (2026-09-09): known questions from the training dataset ────
# Same JSONL the fast path uses (env override honoured); falls back to v29 then
# v28. Built lazily on first /api/suggest call — a missing file just means the
# endpoint returns [] and the UI hides the box.
_suggest_index: Optional[List[str]] = None
def _get_suggest_index() -> List[str]:
    global _suggest_index
    if _suggest_index is not None:
        return _suggest_index
    idx: List[str] = []
    root = os.path.dirname(HERE)
    candidates = [os.environ.get("AI_SECRETARY_DATASET_JSONL"),
                  os.path.join(root, "training", "train_v29.jsonl"),
                  os.path.join(root, "training", "train_v28.jsonl")]
    for path in candidates:
        if not path or not os.path.isfile(path):
            continue
        try:
            seen = set()
            with open(path, encoding="utf-8") as f:
                for line in f:
                    try:
                        q = str(json.loads(line).get("input") or "").strip()
                    except Exception:
                        continue
                    if q and len(q) <= 200:
                        key = " ".join(q.lower().split())
                        if key not in seen:
                            seen.add(key)
                            idx.append(q)
                    if len(idx) >= 8000:
                        break
            if idx:
                break
        except Exception:
            continue
    _suggest_index = idx
    return idx

def _suggest_matches(q: str, limit: int = 6) -> List[str]:
    """Cheap ranker: substring (prefix > word-start > mid-string) first; if
    nothing contains the query verbatim, fall back to AND-token matching
    (every word present, any order) so "pending now fee class 5" still finds
    the known question. Ties -> shorter question wins."""
    needle = " ".join((q or "").lower().split())
    if len(needle) < 3:
        return []
    scored: List[tuple] = []
    for cand in _get_suggest_index():
        c = cand.lower()
        pos = c.find(needle)
        if pos >= 0:
            rank = 0 if pos == 0 else (1 if c[pos - 1] == " " else 2)
            scored.append((rank, len(cand), cand))
    if not scored:
        tokens = [t for t in needle.split(" ") if t]
        if tokens:
            for cand in _get_suggest_index():
                c = cand.lower()
                if all(t in c for t in tokens):
                    scored.append((3, len(cand), cand))
    scored.sort(key=lambda t: (t[0], t[1]))
    return [c for _, _, c in scored[:limit]]


def _chat_core(req: ChatRequest, ip: str, emit=None) -> ChatResponse:
    # emit(stage, detail): optional fire-and-forget progress callback.
    # emit=None (plain POST /api/chat) -> the original behavior, byte-for-byte.
    def _emit(stage: str, detail: str = "") -> None:
        if emit is None: return
        try: emit(stage, detail)
        except Exception: pass  # a broken emitter can never affect the result
    t0 = time.time()
    # audit-trace-2026-09-06: per-stage timing collector — same seams as the SSE
    # progress events, so the audit trail can answer "which stage is
    # slow" without touching orchestrator.py.
    timings = {}
    def _add_timing(stage, ms):
        t = timings.setdefault(stage, {"ms": 0.0, "calls": 0})
        t["ms"] += ms; t["calls"] += 1
    try:
        question = sanitize_question(req.question)
    except ValueError as e:
        raise HTTPException(400, str(e))
    injection = detect_prompt_injection(question)
    if injection:
        log_audit(None, req.branch_id, question, None, "REFUSED", "security", f"Prompt injection: {injection}", 0, 0, ip,
                  pipeline_trace=json.dumps({"stages": {"security": {"ms": round((time.time() - t0) * 1000, 1), "calls": 1}},
                                             "trace": ["prompt injection rejected: " + str(injection)]})[:7000])  # audit-trace-2026-09-06
        raise HTTPException(400, "Question rejected: prompt injection detected.")
    try:
        P = _load_pipeline()
        _emit("context", "Resolving your school, role and branch…")
        _t_ctx = time.perf_counter()  # audit-trace-2026-09-06
        ctx = P["build_context_from_json"](req.context_json)
        _add_timing("context", (time.perf_counter() - _t_ctx) * 1000)
        if req.branch_id is not None and req.branch_id != ctx.selected_branch_id:
            if req.branch_id in [b.branch_id for b in ctx.authorized_branches]: ctx.selected_branch_id = req.branch_id
            else: raise HTTPException(400, f"Branch {req.branch_id} not authorized")
        api_key = ""
        if req.mode == "api_wrapper":
            target_db = req.target_database or getattr(ctx.vocab, "target_database", "") or ""
            if not target_db:
                raise HTTPException(400, "Mode is 'api_wrapper' but no target_database set. "
                                          "Set it in the chat UI Settings (e.g. V3_TestDatabase).")
            # v97: erp_config.json's execute_query_url is the live source;
            # the chat-UI-supplied URL is only a fallback for old clients.
            effective_url = erp_config.get_execute_query_url() or req.api_wrapper_url or ""
            if not effective_url:
                raise HTTPException(400, "Mode is 'api_wrapper' but no ExecuteQuery URL. "
                                          "Set execute_query_url in erp_config.json (project root) "
                                          "and restart the backend.")
            api_key = get_tenant_api_key(target_db) or ""
            if not api_key:
                raise HTTPException(500, f"No tenant API key found for '{target_db}'. "
                                          f"Add it to 'tenant_api_keys' in erp_config.json "
                                          f"(project root), then restart the backend.")
        llm = P["LlamaCppClient"](url=req.model_url, temperature=req.temperature, max_tokens=req.max_tokens, timeout_seconds=LLM_TIMEOUT_SECONDS)
        store = P["SynonymStore"](os.path.join(VOCAB, "synonyms.json"))
        # use_inline_params: the school's ExecuteQuery API has a CONFIRMED
        # bug where it fails on repeated @-placeholders inside nested subqueries
        # (the branch-scoping UNION uses @UserId and @SelectedBranchId multiple
        # times). Inline params safely substitutes the values directly into
        # the SQL text — integers like @UserId=116 become "116" (no injection
        # risk), None becomes "NULL", strings are single-quoted + escaped.
        # v97: the switch lives in erp_config.json (use_inline_params).
        # Flip it to false there — no code change — once the school's dev
        # team fixes the repeated-@placeholder bug on their side.
        # v98 fix (audit 2.1): use target_db — it already falls back to the
        # context-derived database when the client omits the root-level
        # target_database field (mobile clients that only send context_json
        # would otherwise bind TargetDatabase: "" and every query would fail).
        binder = P["ParameterBinderExecutor"](endpoint_url=effective_url, target_database=target_db or "", api_key=api_key, dry_run=(req.mode == "dry_run"), use_inline_params=erp_config.use_inline_params())
        # 2026-09-06 (stream): transparent progress proxy — real events when
        # the query is bound and executed (incl. pagination round-trips).
        # audit-trace-2026-09-06: proxy ALWAYS attached — times bind/execute even for
        # plain POST (emit=None → only timing, no SSE events).
        binder = _ProgressBinder(binder, _emit, _add_timing)
        # 2026-09-05 v2 (FIX A): reinforcement moves INSIDE the llm wrapper.
        # The pipeline receives the RAW question, so fast-path lookups match
        # training examples exactly; every LLM call (initial + retries) still
        # gets the identical reinforcement appended.
        _llm_attempts = [0]
        def _llm_generate(system_prompt, _q):
            _llm_attempts[0] += 1
            # v98 UX (2026-09-08): calm, non-technical progress text. Users
            # misread "writing the database query" as the AI MODIFYING the
            # database — keep every user-visible stage string read-only-friendly.
            _emit("generate", "Connecting to Chalo…" if _llm_attempts[0] == 1
                  else "Still connecting — bigger questions take a little longer…")
            _t_gen = time.perf_counter()  # audit-trace-2026-09-06
            try:
                return llm.generate(system_prompt, reinforce_prompt(_q))
            finally:
                _add_timing("generate", (time.perf_counter() - _t_gen) * 1000)
        # audit-trace-2026-09-06: validator proxy ALWAYS attached (times validate()).
        _make_validator = lambda bv: _ProgressValidator(P["ValueValidator"](bv, synonym_store=store), _emit, _add_timing)
        orch = P["Orchestrator"](llm_generate=_llm_generate, binder=binder, mode=req.mode,
            dataset_lookup=P.get("dataset_lookup"), class_template_lookup=P.get("class_template_lookup"),
            top_n_template_lookup=P.get("top_n_template_lookup"), section_template_lookup=P.get("section_template_lookup"),
            class_section_template_lookup=P.get("class_section_template_lookup"),
            shorthand_class_section_lookup=P.get("shorthand_class_section_lookup"),
            guardrail_validate=P.get("guardrail_validate"), alias_scope_check=P.get("alias_scope"),
            fast_paths_enabled=(req.fast_paths or FAST_PATHS_DEFAULT), semantic_rules_enabled=True,
            make_validator=_make_validator,
            extract_values=P["entity_extractor"].extract_values,
            base_system_prompt=P["build_system_prompt"](),
            inject_vocab=req.inject_vocab)
        # 2026-09-05 v2 (FIX A): raw question — no reinforce_prompt() here.
        _emit("lookup", "Checking known questions for an instant match…")
        _t_run = time.perf_counter()  # audit-trace-2026-09-06
        result = orch.run(question, ctx, page_number=req.page_number, page_size=req.page_size,
                          clm_tier=req.clm_tier)  # CLM r1
        _add_timing("pipeline", (time.perf_counter() - _t_run) * 1000)
        # fastpath-humanize (2026-09-14): a fastpath hit answers in ~1s,
        # which can feel pre-scripted to end users. Optional humanizing
        # pause so the answer arrives at a natural pace. Configured via
        # backend/.env: AI_SECRETARY_FASTPATH_DELAY_MS (3000 when absent,
        # 0 disables, capped at 10000). Applies ONLY to fastpath hits
        # (sql_source in the fastpath family) - LLM answers already take
        # their natural time. Edit .env + restart to adjust or disable.
        try:
            _fp_ms = float(os.environ.get("AI_SECRETARY_FASTPATH_DELAY_MS", "3000"))
        except Exception:
            _fp_ms = 3000.0
        if _fp_ms > 0 and getattr(result, "sql_source", "") in (
                "dataset_exact", "class_template", "top_n_template",
                "section_template", "class_section_template",
                "shorthand_class_section"):
            time.sleep(min(_fp_ms, 10000.0) / 1000.0)
        from semantic_rules import check_sql
        sem_violations = [{"rule_id": v.rule_id, "severity": v.severity, "message": v.message, "suggested_fix": v.suggested_fix, "module": v.module} for v in (check_sql(result.sql, question) if result.sql else [])]
        latency = (time.time() - t0) * 1000
        # audit-trace-2026-09-06: full pipeline trace → audit trail
        stage_summary = {k: {"ms": round(v["ms"], 1), "calls": v["calls"]} for k, v in timings.items()}
        stage_summary["total"] = {"ms": round(latency, 1), "calls": 1}
        pipeline_trace = json.dumps({"sql_source": result.sql_source,
                                     "stages": stage_summary,
                                     "trace": list(result.trace)[:40]}, ensure_ascii=False)[:7000]
        log_audit(ctx.user_id, req.branch_id, question, result.sql, str(result.outcome).replace("Outcome.", ""), str(result.stage).replace("Stage.", ""), result.message, len(sem_violations), latency, ip, pipeline_trace=pipeline_trace, sql_source=result.sql_source)  # batch-a-2026-09-10: sql_source as its own column
        detail = result.detail
        if detail and "ERROR" in str(result.outcome): detail = safe_error_message(detail)
        # UI/UX item 4: standard reply for unanswerable outcomes (REFUSED /
        # ERROR / NEEDS_DISAMBIGUATION). The original message moves into
        # `detail` so it stays available for debugging; the frontend renders
        # `message` as-is (no frontend change needed).
        # ux-2026-09-09 (refusal_translation): when enabled, a BETTER human
        # sentence wins — rule-code refusals get their ux_config / built-in
        # text, NEEDS_DISAMBIGUATION gets a pick-one prompt (the UI renders
        # the candidates as tappable chips), and plain REFUSED messages that
        # are already parent-friendly are kept instead of the generic reply.
        outcome_str = str(result.outcome).replace("Outcome.", "")
        message = result.message
        fallback_used = False
        friendly = _friendly_refusal(outcome_str, result, sem_violations) \
            if UX_CONFIG["features"]["refusal_translation"] else None
        if friendly:
            if message != friendly:
                if message:
                    detail = (detail + " | " if detail else "") + f"Original message: {message}"
                message = friendly
                fallback_used = True
        elif FALLBACK_MESSAGE and outcome_str in ("REFUSED", "ERROR", "NEEDS_DISAMBIGUATION"):
            if message != FALLBACK_MESSAGE:
                if message:
                    detail = (detail + " | " if detail else "") + f"Original message: {message}"
                message = FALLBACK_MESSAGE
                fallback_used = True
        # ux-2026-09-09 (kpi_delta): ▲/▼ vs previous period on 1×1 numeric
        # answers with explicit date params. Wrapped, flag-gated, any doubt = None.
        kpi = None
        if UX_CONFIG["features"]["kpi_delta"] and outcome_str == "ANSWER":
            kpi = _kpi_delta(result, binder)
        features_enabled = [k for k, v in FEATURE_FLAGS.items() if v]
        return ChatResponse(outcome=outcome_str, stage=str(result.stage).replace("Stage.", ""),
            sql=result.sql, sql_source=result.sql_source, bound_request=result.bound_request,
            columns=result.columns, rows=_fmt_dates_for_display(result.rows),
            total_row_count=result.total_row_count,
            disambiguation=result.disambiguation, message=message, detail=detail, fallback_used=fallback_used,
            trace=result.trace, semantic_violations=sem_violations, latency_ms=latency, features_enabled=features_enabled,
            stage_timings=stage_summary, kpi_delta=kpi)  # audit-trace-2026-09-06
    except HTTPException: raise
    except Exception as e:
        # ux-2026-09-09 (clarification_chips): a model SQL that wants
        # @AcademicYearID while the Context JSON could not pin one becomes a
        # tappable year choice instead of a dead error. Everything else
        # keeps the normal error path.
        chips = _need_params_from_bind_error(e, req.context_json) \
            if UX_CONFIG["features"]["clarification_chips"] else None
        if chips:
            return ChatResponse(outcome="NEEDS_DISAMBIGUATION", stage="bind",
                message=chips["message"], need_params=chips,
                trace=[f"bind: missing @AcademicYearID -> year chips offered"],
                semantic_violations=[], latency_ms=(time.time() - t0) * 1000, features_enabled=[])
        latency = (time.time() - t0) * 1000
        log_audit(None, req.branch_id, question, None, "ERROR", "execute", str(e)[:500], 0, latency, ip,
                  pipeline_trace=json.dumps({"stages": {k: {"ms": round(v["ms"], 1), "calls": v["calls"]} for k, v in timings.items()},
                                             "trace": ["exception: " + str(e)[:200]]}, ensure_ascii=False)[:7000])  # audit-trace-2026-09-06
        raw_msg = safe_error_message(str(e))
        detail = traceback.format_exc() if os.environ.get("AI_SECRETARY_DEBUG", "false").lower() in ("1","true") else None
        fallback_used = False
        if FALLBACK_MESSAGE:
            detail = (detail + " | " if detail else "") + f"Original message: {raw_msg}"
            raw_msg = FALLBACK_MESSAGE
            fallback_used = True
        return ChatResponse(outcome="ERROR", stage="execute", message=raw_msg, detail=detail, fallback_used=fallback_used,
            trace=[], semantic_violations=[], latency_ms=latency, features_enabled=[])

class _ProgressValidator:
    """Transparent proxy over ValueValidator: one progress event per validate()
    call. Value resolution can hit the user-context API — it is one of the
    genuinely slow stages. Every other attribute passes through untouched."""

    def __init__(self, inner, emit=None, add_timing=None):   # audit-trace-2026-09-06
        self._inner = inner
        self._emit = emit            # may be None (plain POST) — timing still on
        self._add_timing = add_timing

    def validate(self, ctype, val):
        if self._emit is not None:
            self._emit("validate", "Matching names against your school’s real lists…")
        _t = time.perf_counter()
        try:
            return self._inner.validate(ctype, val)
        finally:
            if self._add_timing: self._add_timing("validate", (time.perf_counter() - _t) * 1000)

    def __getattr__(self, name):
        return getattr(self._inner, name)


class _ProgressBinder:
    """Transparent proxy over ParameterBinderExecutor: progress events for
    bind() and execute() (the latter re-fires per pagination round-trip).
    Every other attribute passes through untouched."""

    def __init__(self, inner, emit=None, add_timing=None):   # audit-trace-2026-09-06
        self._inner = inner
        self._emit = emit            # may be None (plain POST) — timing still on
        self._add_timing = add_timing
        self._n_exec = 0

    def bind(self, *a, **k):
        if self._emit is not None:
            self._emit("bind", "Connecting to your school’s records…")
        _t = time.perf_counter()
        try:
            return self._inner.bind(*a, **k)
        finally:
            if self._add_timing: self._add_timing("bind", (time.perf_counter() - _t) * 1000)

    def execute(self, *a, **k):
        self._n_exec += 1
        if self._emit is not None:
            self._emit("execute", "Getting your answer…" if self._n_exec == 1 else "Getting the rest of your answer…")
        _t = time.perf_counter()
        try:
            return self._inner.execute(*a, **k)
        finally:
            if self._add_timing: self._add_timing("execute", (time.perf_counter() - _t) * 1000)

    def __getattr__(self, name):
        return getattr(self._inner, name)


# ── SSE stage-progress streaming (2026-09-06) ────────────────────────────────
# POST /api/chat/stream — same request body, same auth, same rate limits, and
# the SAME _chat_core implementation as POST /api/chat (one code path, zero
# drift). Response is text/event-stream:
#     : keepalive        comment frame every 15s so proxies don't cut the line
#     event: stage       {"stage": "generate", "detail": "Thinking — …"}
#     event: result      {…the full ChatResponse JSON, identical fields…}
# The result event carries exactly what POST /api/chat would have returned:
# same fallback-message policy, same audit logging, same fail-closed chain.
# Nothing about the pipeline changes — this only narrates it.
# A client disconnect does NOT cancel backend work (same abort semantics as
# POST /api/chat today; the answer still lands in the audit trail).
@app.post("/api/chat/stream")
def chat_stream(req: ChatRequest, request: Request, token: str = Depends(check_rate_limit)):
    if not STREAM_DEFAULT:
        raise HTTPException(501, "Streaming is disabled on this server (AI_SECRETARY_STREAM=0).")
    ip = request.client.host if request.client else "unknown"
    # Pre-flight BEFORE the stream opens, so clients get real HTTP status
    # codes. Prompt-injection is deliberately NOT pre-flighted: _chat_core
    # logs it to the audit trail, and the refusal arrives as a `result` event.
    try:
        sanitize_question(req.question)
    except ValueError as e:
        raise HTTPException(400, str(e))

    q: "queue.Queue" = queue.Queue()

    def emit(stage: str, detail: str = "") -> None:
        q.put({"type": "stage", "stage": stage, "detail": detail})

    def worker() -> None:
        try:
            resp = _chat_core(req, ip, emit=emit)
            q.put({"type": "result", "data": resp.model_dump()})
        except HTTPException as e:
            msg = e.detail if isinstance(e.detail, str) else json.dumps(e.detail)
            refused = e.status_code == 400
            q.put({"type": "result", "data": ChatResponse(
                outcome="REFUSED" if refused else "ERROR",
                stage="security" if refused else "execute",
                message=msg, fallback_used=False).model_dump()})
        except Exception as e:
            q.put({"type": "result", "data": ChatResponse(
                outcome="ERROR", stage="execute", message=safe_error_message(str(e)),
                fallback_used=False).model_dump()})

    threading.Thread(target=worker, daemon=True, name="chat-stream-worker").start()

    def gen():
        yield ": stream open\n\n"
        while True:
            try:
                item = q.get(timeout=15)
            except queue.Empty:
                yield ": keepalive\n\n"
                continue
            yield f"event: {item['type']}\ndata: {json.dumps(item, ensure_ascii=False)}\n\n"
            if item["type"] == "result":
                break

    return StreamingResponse(gen(), media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no", "Connection": "keep-alive"})


@app.post("/api/validate")
def validate_sql(req: dict, token: str = Depends(require_auth)):
    from semantic_rules import check_sql
    vs = check_sql(req.get("sql", ""), req.get("question", ""))
    return {"violations": [{"rule_id": v.rule_id, "severity": v.severity, "message": v.message, "suggested_fix": v.suggested_fix, "module": v.module} for v in vs],
            "violation_count": len(vs), "high_count": sum(1 for v in vs if v.severity == "HIGH"), "medium_count": sum(1 for v in vs if v.severity == "MEDIUM")}

@app.post("/api/branches")
def list_branches(context_json: Dict[str, Any], token: str = Depends(require_auth)):
    try:
        P = _load_pipeline(); ctx = P["parse_context_json"](context_json)
        return {"branches": [{"id": bv.branch_id, "name": bv.name, "is_primary": bv.is_primary} for bv in ctx.branches.values()],
                "user_id": ctx.user_id, "username": ctx.username, "is_super_user": ctx.is_super_user}
    except Exception as e: raise HTTPException(400, f"Invalid Context JSON: {e}")

# ── UX endpoints (2026-09-09) ─────────────────────────────────────────────────
class FeedbackIn(BaseModel):
    question: str = Field(..., min_length=1, max_length=1000)
    rating: str = Field(..., pattern="^(up|down)$")
    reason: str = Field("", max_length=200)
    outcome: str = Field("", max_length=40)

@app.get("/api/ux-config")
def get_ux_config(token: str = Depends(require_auth)):
    """Frontend switchboard: feature flags + texts + suggestion seeds.
    refusal_messages are applied SERVER-SIDE and deliberately not exposed."""
    return {"features": UX_CONFIG["features"],
            "suggested_questions": UX_CONFIG["suggested_questions"],
            "feedback_reasons": UX_CONFIG["feedback_reasons"],
            "zero_result_message": UX_CONFIG["zero_result_message"]}

@app.post("/api/feedback")
def post_feedback(fb: FeedbackIn, request: Request, token: str = Depends(check_rate_limit)):
    """👍/👎 from the chat UI -> ux_feedback table (same SQLite DB as the audit
    trail). Ratings on fast-path answers are the negative-cache signal for the
    self-learning loop; ratings on LLM answers feed the next dataset build."""
    from security import _get_audit_conn
    try:
        conn = _get_audit_conn()
        conn.execute("""CREATE TABLE IF NOT EXISTS ux_feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            question TEXT,
            rating TEXT,
            reason TEXT,
            outcome TEXT,
            ip_address TEXT)""")
        conn.execute("INSERT INTO ux_feedback (timestamp, question, rating, reason, outcome, ip_address) VALUES (?,?,?,?,?,?)",
                     (time.strftime("%Y-%m-%d %H:%M:%S"), fb.question, fb.rating, fb.reason, fb.outcome,
                      request.client.host if request.client else "unknown"))
        conn.commit()
        return {"ok": True}
    except Exception as e:
        raise HTTPException(500, f"Could not store feedback: {e}")

@app.get("/api/feedback")
def get_feedback(limit: int = 200, admin_token: str = Depends(require_admin)):
    from security import _get_audit_conn
    try:
        conn = _get_audit_conn()
        rows = conn.execute("SELECT * FROM ux_feedback ORDER BY id DESC LIMIT ?", [max(1, min(limit, 1000))]).fetchall()
        cols = [d[0] for d in conn.execute("SELECT * FROM ux_feedback LIMIT 0").description]
        total = conn.execute("SELECT COUNT(*) FROM ux_feedback").fetchone()[0]
        return {"rows": [dict(zip(cols, r)) for r in rows], "total": total}
    except Exception as e:
        raise HTTPException(500, f"Feedback read error: {e}")

@app.get("/api/suggest")
def suggest(q: str = "", token: str = Depends(require_auth)):
    """As-you-type suggestions over the KNOWN question set (the same dataset
    the fast path answers instantly). Cheap in-memory ranker, no LLM call."""
    try:
        return {"suggestions": _suggest_matches(q, limit=6)}
    except Exception:
        return {"suggestions": []}


@app.get("/api/admin/features", response_model=FeatureFlagsResponse)
def get_features(admin_token: str = Depends(require_admin)):
    return FeatureFlagsResponse(flags=FEATURE_FLAGS, descriptions=FEATURE_DESCRIPTIONS)

@app.put("/api/admin/features", response_model=FeatureFlagsResponse)
def update_features(update: FeatureFlagsUpdate, admin_token: str = Depends(require_admin)):
    for k, v in update.flags.items():
        if k in FEATURE_FLAGS: FEATURE_FLAGS[k] = bool(v)
    _save_feature_overrides()
    return FeatureFlagsResponse(flags=FEATURE_FLAGS, descriptions=FEATURE_DESCRIPTIONS)

@app.get("/api/audit")
def get_audit_trail(limit: int = 100, offset: int = 0, outcome: str = "", admin_token: str = Depends(require_admin)):
    from security import _get_audit_conn
    try:
        conn = _get_audit_conn()
        query, params, conditions = "SELECT * FROM audit_trail", [], []
        if outcome: conditions.append("outcome = ?"); params.append(outcome)
        if conditions: query += " WHERE " + " AND ".join(conditions)
        query += " ORDER BY id DESC LIMIT ? OFFSET ?"; params.extend([limit, offset])
        rows = conn.execute(query, params).fetchall()
        cols = [d[0] for d in conn.execute("SELECT * FROM audit_trail LIMIT 0").description]
        results = [dict(zip(cols, row)) for row in rows]
        cnt = "SELECT COUNT(*) FROM audit_trail"
        if outcome: cnt += " WHERE outcome = ?"; total = conn.execute(cnt, [outcome]).fetchone()[0]
        else: total = conn.execute(cnt).fetchone()[0]
        return {"rows": results, "total": total, "limit": limit, "offset": offset}
    except Exception as e: raise HTTPException(500, f"Audit trail error: {e}")

@app.get("/api/audit/stats")
def get_audit_stats(admin_token: str = Depends(require_admin)):
    from security import _get_audit_conn
    try:
        conn = _get_audit_conn()
        outcomes = {r[0]: r[1] for r in conn.execute("SELECT outcome, COUNT(*) FROM audit_trail GROUP BY outcome ORDER BY COUNT(*) DESC").fetchall()}
        total = conn.execute("SELECT COUNT(*) FROM audit_trail").fetchone()[0]
        avg_lat = conn.execute("SELECT AVG(latency_ms) FROM audit_trail").fetchone()[0] or 0
        recent = conn.execute("SELECT COUNT(*) FROM audit_trail WHERE timestamp >= date('now', '-7 days')").fetchone()[0]
        stages = {r[0]: r[1] for r in conn.execute("SELECT stage, COUNT(*) FROM audit_trail WHERE outcome='REFUSED' GROUP BY stage ORDER BY COUNT(*) DESC").fetchall()}
        # audit-trace-2026-09-06: per-stage latency aggregation over recent traced rows
        stage_acc = {}
        try:
            trows = conn.execute("SELECT pipeline_trace FROM audit_trail WHERE pipeline_trace IS NOT NULL ORDER BY id DESC LIMIT 500").fetchall()
            for (ptxt,) in trows:
                try: ptj = json.loads(ptxt)
                except Exception: continue
                for st, sv in (ptj.get("stages") or {}).items():
                    if not isinstance(sv, dict): continue
                    acc = stage_acc.setdefault(st, {"sum_ms": 0.0, "calls": 0, "max_ms": 0.0})
                    acc["sum_ms"] += float(sv.get("ms", 0) or 0); acc["calls"] += int(sv.get("calls", 0) or 0)
                    acc["max_ms"] = max(acc["max_ms"], float(sv.get("ms", 0) or 0))
        except Exception: pass
        stage_stats = {st: {"avg_ms": round(v["sum_ms"] / v["calls"], 1) if v["calls"] else 0.0,
                            "max_ms": round(v["max_ms"], 1), "calls": v["calls"]}
                       for st, v in stage_acc.items()}
        return {"total": total, "outcomes": outcomes, "avg_latency_ms": round(avg_lat, 1), "recent_7_days": recent, "refused_stages": stages,
                "stage_stats": stage_stats}
    except Exception as e: raise HTTPException(500, f"Audit stats error: {e}")

@app.delete("/api/audit")
def clear_audit_trail(admin_token: str = Depends(require_admin)):
    """Delete ALL rows from the audit trail. Requires admin token. Cannot be undone."""
    from security import _get_audit_conn
    try:
        conn = _get_audit_conn()
        conn.execute("DELETE FROM audit_trail")
        conn.commit()
        remaining = conn.execute("SELECT COUNT(*) FROM audit_trail").fetchone()[0]
        return {"status": "ok", "message": f"Audit trail cleared. {remaining} row(s) remaining.", "remaining": remaining}
    except Exception as e: raise HTTPException(500, f"Could not clear audit trail: {e}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

"""
erp_config.py — loader for erp_config.json (v97, the ONE ERP settings file)
===========================================================================

erp_config.json (project root, next to this file) is the ONLY place to
change the ERP connection settings:

  * GetUserContext URL        -> "get_user_context_url"
  * ExecuteQuery URL          -> "execute_query_url"
  * Per-tenant API keys       -> "tenant_api_keys"  ({"V3_TestDatabase": "..."})
  * Inline-params workaround  -> "use_inline_params" (true/false)

HOW TO APPLY A CHANGE:  edit erp_config.json  ->  sudo systemctl restart chalo-backend.
Nothing else needs editing. No code changes. No chat-UI changes.

Resolution order for every setting (first non-empty wins):
  1. erp_config.json          (the file — this is the default place to edit)
  2. environment variable     (escape hatch for testing; see _ENV_KEYS below)
  3. built-in fallback        (v96 hardcoded values, so a missing file still boots)

If erp_config.json exists but is not valid JSON, this loader RAISES — a
corrupt file must never silently fall back to stale values.

Pure stdlib. Imported by backend/security.py, pipeline/user_context_api.py
and backend/main.py. The real key VALUE lives only in erp_config.json —
never put it back into code.
"""
from __future__ import annotations

import json
import os
import sys
from typing import Any, Dict, Optional

_ROOT = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.environ.get("ERP_CONFIG_PATH") or os.path.join(_ROOT, "erp_config.json")

# Last-resort fallbacks (the v96 hardcoded values). erp_config.json wins
# whenever it sets a value; env vars sit in the middle.
_BUILTIN_URLS = {
    "get_user_context_url": "https://chaloschools.in/testv4service/DigitalSecretary/AISecretary.asmx/GetUserContext",
    "execute_query_url": "https://chaloschools.in/testv4service/DigitalSecretary/AISecretary.asmx/ExecuteQuery",
}
_BUILTIN_USE_INLINE_PARAMS = True  # matches the old config.yaml's use_inline_params: true

_ENV_KEYS = {
    "get_user_context_url": "USER_CONTEXT_API_URL",
    "execute_query_url": "EXECUTE_QUERY_API_URL",
    "use_inline_params": "ERP_USE_INLINE_PARAMS",
}

_cache: Optional[Dict[str, Any]] = None


def _parse_env_key_map(raw: str) -> Dict[str, str]:
    """Parses 'Db1:key1, Db2:key2' (the AI_SECRETARY_TENANT_KEYS format)."""
    out: Dict[str, str] = {}
    for pair in (raw or "").split(","):
        if ":" in pair:
            db, key = pair.split(":", 1)
            if db.strip() and key.strip():
                out[db.strip()] = key.strip()
    return out


def _read_file_values() -> Dict[str, Any]:
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        raw = json.load(f)
    if not isinstance(raw, dict):
        raise ValueError("erp_config.json must contain a JSON object {...}")
    # Keys starting with "_" are comment fields (e.g. "_README") — ignored.
    return {k: v for k, v in raw.items() if not k.startswith("_")}


def load(force: bool = False) -> Dict[str, Any]:
    """Returns merged ERP settings. Cached after first call (edit the json
    + restart the backend to re-read; or load(force=True) in-process)."""
    global _cache
    if _cache is not None and not force:
        return _cache

    try:
        file_vals = _read_file_values()
    except FileNotFoundError:
        file_vals = {}  # missing file -> fall through to env/builtin defaults
    except json.JSONDecodeError as exc:
        raise RuntimeError(
            f"erp_config.json ({CONFIG_PATH}) is not valid JSON: {exc}. "
            f"Fix the file and restart."
        ) from exc
    except ValueError as exc:
        raise RuntimeError(f"erp_config.json ({CONFIG_PATH}): {exc}") from exc

    merged: Dict[str, Any] = {}

    # URLs + inline-params switch: file -> env -> builtin
    for key, env_name in _ENV_KEYS.items():
        val = file_vals.get(key)
        if val in (None, ""):
            val = os.environ.get(env_name)
        merged[key] = val
    for key, default_url in _BUILTIN_URLS.items():
        if not merged.get(key):
            merged[key] = default_url
    uip = merged.get("use_inline_params")
    if uip is None:
        uip = _BUILTIN_USE_INLINE_PARAMS
    if isinstance(uip, str):
        uip = uip.strip().lower() in ("1", "true", "yes", "on")
    merged["use_inline_params"] = bool(uip)

    # Tenant keys: file map -> (if empty) env map AI_SECRETARY_TENANT_KEYS
    keys = file_vals.get("tenant_api_keys")
    if keys in (None, ""):
        keys = {}
    if not isinstance(keys, dict):
        raise ValueError(
            'erp_config.json: "tenant_api_keys" must be an object like '
            '{"V3_TestDatabase": "<api-key>"}'
        )
    if not keys:
        keys = _parse_env_key_map(os.environ.get("AI_SECRETARY_TENANT_KEYS", ""))
    merged["tenant_api_keys"] = dict(keys)

    _cache = merged
    return _cache


# ── Convenience getters (what the rest of the code calls) ────────────────────

def get(key: str, default: Any = None) -> Any:
    return load().get(key, default)


def get_user_context_url() -> str:
    return load()["get_user_context_url"]


def get_execute_query_url() -> str:
    return load()["execute_query_url"]


def tenant_key(target_database: Optional[str]) -> Optional[str]:
    if not target_database:
        return None
    return load()["tenant_api_keys"].get(target_database)


def use_inline_params() -> bool:
    return bool(load()["use_inline_params"])


def where() -> str:
    """Absolute path of the json file (used in error messages / docs)."""
    return CONFIG_PATH

/* =====================================================================
   ChaloSchools AI Secretary - v28 dataset local test (SSMS)
   Part 1 of 9: queries Q1 to Q500 (500 of 4034 in the full dataset)
   Source: semantic_validation/reference_inputs/training_dataset_final_v28.jsonl
   Generated: 2026-09-04
   The SQL text is EXACTLY what the dataset holds (single quotes appear
   doubled inside the @sql string - T-SQL string escaping; multi-line
   queries keep line breaks, which SQL Server counts as whitespace).
   So any error you see here is an error the trained model would produce.

   ONE SETTING TO CHANGE BEFORE RUNNING:
     The queries are security-scoped to a user, like in production. They run
     as @UserId. Change it to YOUR local user id:
       Find & Replace across these files:   @UserId INT = 1
       (see your users with:  SELECT ID, UserName FROM UserAccountMaster;)
     @SelectedBranchId NULL = all branches you are allowed; put a branch id
       there to simulate one selected branch.

   RECOMMENDED for big runs (stops 500 result grids appearing):
     Query menu > Query Options... > Results > Grid >
     tick 'Discard results after execution', then Execute (F5).
     Everything still runs; errors + summary appear in the Messages tab.
   Failures (INCLUDING compile-time errors - bad syntax, unknown columns,
   unknown tables - thanks to the sp_executesql wrapper) are printed as:
     Q### FAILED: <error text>
        question: <the natural-language question>
   and stored in table #ai_errors until you close the connection.
   ===================================================================== */
SET NOCOUNT ON;
GO
IF OBJECT_ID('tempdb..#ai_errors') IS NULL
    CREATE TABLE #ai_errors (
        qid      INT NOT NULL PRIMARY KEY,
        question NVARCHAR(300),
        error    NVARCHAR(2048),
        ms       INT NOT NULL
    );
GO
-- ============ Q1 | Total fees collected from Class 5 this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total fees collected from Class 5 this year',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS Class5Collection FROM FeesCollection fc INNER JOIN ClassMaster cm ON fc.Class_ID = cm.ID WHERE cm.Name IN (''Class 5'', ''V'') AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (1, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2 | What is our admission conversion this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is our admission conversion this year?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS TotalNewAdmissions, COUNT(DISTINCT CASE WHEN sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) THEN sad.StudentID END) AS StillActive, CAST(COUNT(DISTINCT CASE WHEN sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) THEN sad.StudentID END) * 100.0 / NULLIF(COUNT(DISTINCT sad.StudentID), 0) AS DECIMAL(5,2)) AS RetentionPercent FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id INNER JOIN Student_Master stm ON sad.StudentID = stm.ID WHERE sad.IsNewAdmission = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3 | Who has been absent for the last 5 days continuously? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who has been absent for the last 5 days continuously?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, sm.AdmissionNo, cm.Name AS class_name, sm.FatherContactNo FROM Student_Master sm JOIN ClassMaster cm ON cm.ID = (SELECT TOP 1 sa.Class_ID FROM StudentAttendance sa WHERE sa.Student_ID = sm.ID ORDER BY sa.Attendance_Date DESC) WHERE sm.ID IN (SELECT sa.Student_ID FROM StudentAttendance sa WHERE sa.Attendance_Status_ID = 2 AND sa.Attendance_Date >= DATEADD(DAY, -5, CAST(GETDATE() AS DATE)) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sa.Student_ID HAVING COUNT(*) = 5);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4 | List staff members whose salary is on hold ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List staff members whose salary is on hold',
        @sql NVARCHAR(MAX) = N'SELECT CONCAT(sm.Staff_FirstName, '' '', sm.Staff_LastName) AS StaffName, sm.Staff_ID, em.BankName, em.BankAccountNo FROM EmployeeMaster em INNER JOIN Staff_Master sm ON em.StaffID = sm.Staff_ID WHERE em.IsHold = 1 AND em.IsDeleted = 0 AND em.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q5 | How many enquiries did we get this week? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many enquiries did we get this week?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS WeekEnquiries FROM GeneralCallRegister WHERE CallDate >= DATEADD(DAY, 1-DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE)) AND CallDate <= CAST(GETDATE() AS DATE) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (5, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q6 | Write a poem about education ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Write a poem about education',
        @sql NVARCHAR(MAX) = N'-- This question is outside the scope of the school management database. I can answer questions about students, fees, attendance, staff, exams, transport, and other school operations.
SELECT ''Please ask a question about school data (fees, attendance, students, staff, exams, etc.)'' AS Message;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (6, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q7 | How many terms are there? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many terms are there?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TermCount FROM ExamTermMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND Deleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (7, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q8 | Percentage of receipts cancelled ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Percentage of receipts cancelled',
        @sql NVARCHAR(MAX) = N'SELECT CAST(COUNT(CASE WHEN fc.IsDeleted = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS CancellationPercent FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (8, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q9 | What's the collection on 15th June? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the collection on 15th June?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fc.Receipt_Amt) AS CollectionAmount, COUNT(fc.Id) AS Receipts FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND CAST(fc.Bill_Date AS DATE) = DATEFROMPARTS(CASE WHEN MONTH(GETDATE()) >= 4 THEN YEAR(GETDATE()) ELSE YEAR(GETDATE())-1 END + 0, 6, 15) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (9, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q10 | What's happening with admissions lately? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s happening with admissions lately?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalEnquiries, SUM(CASE WHEN esm.Name = ''Admitted'' THEN 1 ELSE 0 END) AS Converted, SUM(CASE WHEN esm.Name = ''In Progress'' THEN 1 ELSE 0 END) AS InProgress FROM GeneralCallRegister gcr INNER JOIN Enquiry_Status_Master esm ON gcr.CallStatus_ID = esm.ID WHERE gcr.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gcr.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (gcr.IsDeleted = 0 OR gcr.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (10, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q11 | Show the top 10 zero-payment students sorted by demand amount. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the top 10 zero-payment students sorted by demand amount.',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 f.Student_ID, s.FirstName + '' '' + ISNULL(s.LastName, '''') AS StudentName, f.ClassName, s.FatherContactNo, SUM(f.Amount) AS TotalDemand FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID INNER JOIN Student_Master s ON f.Student_ID = s.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Student_ID, s.FirstName, s.LastName, f.ClassName, s.FatherContactNo HAVING SUM(f.Paid_Amt) = 0 AND SUM(f.Amount) > 0 ORDER BY TotalDemand DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (11, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q12 | Kindergarten ki strength? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Kindergarten ki strength?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(sad.Id) AS StudentCount FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND (cm.Name LIKE ''%KG%'' OR cm.Name LIKE ''%Kindergarten%'' OR cm.Name LIKE ''%LKG%'' OR cm.Name LIKE ''%UKG%'' OR cm.Name LIKE ''%Nursery%'' OR cm.Name LIKE ''%Pre%'' OR cm.Name IN (''GATE-1'', ''GATE-2'', ''GATE-3'')) GROUP BY cm.Name ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (12, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q13 | Show collection trend by hour of the day ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show collection trend by hour of the day',
        @sql NVARCHAR(MAX) = N'SELECT DATEPART(HOUR, fc.Bill_Date) AS HourOfDay, COUNT(fc.Id) AS Receipts, SUM(fc.Receipt_Amt) AS TotalAmount FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY DATEPART(HOUR, fc.Bill_Date) ORDER BY HourOfDay;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (13, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q14 | Branch-wise boys count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Branch-wise boys count',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, COUNT(*) AS Boys FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN BranchMaster bm ON sm.BranchID = bm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.Gender IN (''Male'', ''Boy'') AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY Boys DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (14, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q15 | Topper kaun hai school ka? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Topper kaun hai school ka?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 smd.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName, SUM(smd.Marks) AS TotalMarks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN Student_Master stm ON smd.StudentID = stm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 GROUP BY smd.StudentID, stm.AdmissionNo, stm.FirstName, stm.LastName ORDER BY TotalMarks DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (15, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q16 | Year-wise comparison of boys vs girls enrollment ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Year-wise comparison of boys vs girls enrollment',
        @sql NVARCHAR(MAX) = N'SELECT bad.Name AS AcademicYear, COUNT(CASE WHEN sm.Gender IN (''Male'', ''Boy'') THEN 1 END) AS Boys, COUNT(CASE WHEN sm.Gender IN (''Female'', ''Girl'') THEN 1 END) AS Girls FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bad.Name ORDER BY bad.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (16, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q17 | Staff-wise total working days and present days this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff-wise total working days and present days this month',
        @sql NVARCHAR(MAX) = N'SELECT sa.Staff_ID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName, COUNT(*) AS TotalDays, SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS PresentDays, SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END) AS AbsentDays FROM Staff_Attendance sa INNER JOIN Staff_Master sm ON sa.Staff_ID = sm.Staff_ID AND sm.StaffStatus_ID = 1 WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND MONTH(Attendance_Date) = MONTH(GETDATE()) AND YEAR(Attendance_Date) = YEAR(GETDATE()) GROUP BY sa.Staff_ID, sm.Staff_FirstName, sm.Staff_LastName ORDER BY AbsentDays DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (17, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q18 | What's the teacher absentee rate today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the teacher absentee rate today?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AbsenteeRate FROM Staff_Attendance sa INNER JOIN Staff_Master sfm ON sa.Staff_ID = sfm.Staff_ID AND sfm.StaffStatus_ID = 1 WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE)   AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (18, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q19 | Show me the top 20 defaulters with their contact numbers ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me the top 20 defaulters with their contact numbers',
        @sql NVARCHAR(MAX) = N'SELECT TOP 20 ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, sm.AdmissionNo, sm.FatherName, sm.FatherContactNo, sm.MotherContactNo, SUM(fcd.Remaining_Amt) AS outstanding FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Student_Master sm ON fc.Student_ID = sm.ID JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID AND fc.AcademicYearID = sad.AcademicYearID WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fcd.Remaining_Amt > 0 AND sad.IsActive = 1 GROUP BY sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo, sm.FatherName, sm.FatherContactNo, sm.MotherContactNo ORDER BY SUM(fcd.Remaining_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (19, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q20 | How many students were absent in April? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students were absent in April?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sa.Student_ID) AS UniqueAbsentees FROM StudentAttendance sa WHERE MONTH(sa.Attendance_Date) = 4 AND YEAR(sa.Attendance_Date) = 2026 AND sa.Attendance_Status_ID = 2 AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (20, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q21 | What is the average daily collection this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the average daily collection this year?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(AVG(DayCollection) AS DECIMAL(10,2)) AS AvgDailyCollection FROM (SELECT CAST(fc.Bill_Date AS DATE) AS CollDate, SUM(fc.Receipt_Amt) AS DayCollection FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY CAST(fc.Bill_Date AS DATE)) AS DailyTotals;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (21, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q22 | Fee category wise collection this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Fee category wise collection this month',
        @sql NVARCHAR(MAX) = N'SELECT fcd.FeesCategory_Name, SUM(fcd.Paid_Amt) AS total_collected FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE DATEPART(MONTH, fc.Bill_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, fc.Bill_Date) = DATEPART(YEAR, GETDATE()) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fcd.FeesCategory_Name ORDER BY SUM(fcd.Paid_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (22, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q23 | Hey, what's the outstanding for primary classes (1-5)? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the outstanding for primary classes (1-5)?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS PrimaryOutstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND ClassName IN (''Class 1'', ''Class 2'', ''Class 3'', ''Class 4'', ''Class 5'') AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (23, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q24 | How many students are preparing for NEET or JEE? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students are preparing for NEET or JEE?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS neet_jee_count FROM StudentAcademicDetail sad WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.IsNEETJEE = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (24, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q25 | Show cancelled receipts with details ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show cancelled receipts with details',
        @sql NVARCHAR(MAX) = N'SELECT fc.Bill_No, fc.Bill_Date, fc.Admission_No, fc.Receipt_Amt, fc.Cancellation_Date, fc.Cancelled_By_Name FROM FeesCollection fc WHERE fc.IsDeleted = 1 AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY fc.Cancellation_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (25, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q26 | Hey, who collected the most fees today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, who collected the most fees today?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 fc.Collected_By_Name, COUNT(*) AS Receipts, SUM(fc.Receipt_Amt) AS TotalCollected FROM FeesCollection fc WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fc.Collected_By_Name ORDER BY TotalCollected DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (26, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q27 | Pull up homework due tomorrow ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up homework due tomorrow',
        @sql NVARCHAR(MAX) = N'SELECT h.Remarks AS Title, cm.Name AS ClassName, sub.Name AS SubjectName, h.StaffName AS AssignedBy FROM HomeWorkAndAssignment h INNER JOIN ClassMaster cm ON h.Class_ID = cm.ID INNER JOIN Subject_Master sub ON h.Subject_ID = sub.Id WHERE h.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND h.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (h.IsDeleted = 0 OR h.IsDeleted IS NULL) AND CAST(h.SubmissionDate AS DATE) = CAST(DATEADD(DAY, 1, GETDATE()) AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (27, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q28 | Girls who joined this year and are in Class 6 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Girls who joined this year and are in Class 6',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sm.AdmissionDate, sad.RollNo FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE cm.Name IN (''Class 6'', ''VI'') AND sm.Gender IN (''Female'', ''Girl'') AND sad.IsNewAdmission = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sm.AdmissionDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (28, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q29 | Just checking - how many boarding points are there across all routes? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many boarding points are there across all routes?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalBoardingPoints FROM Route_Master rm INNER JOIN Route_MasterDetails rmd ON rm.ID = rmd.Route_ID INNER JOIN BoardingPoint_Master bpm ON rmd.BoardingPoint_ID = bpm.Id WHERE rm.IsDeleted = 0 AND rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (29, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q30 | Give me the staff bank wise distribution ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the staff bank wise distribution',
        @sql NVARCHAR(MAX) = N'SELECT BankName, COUNT(*) AS StaffCount FROM EmployeeMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0 AND BankName IS NOT NULL GROUP BY BankName ORDER BY StaffCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (30, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q31 | Students who were absent on 10th January 2026 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students who were absent on 10th January 2026',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName, secm.Name AS SectionName FROM Student_Master sm INNER JOIN StudentAttendance sa ON sm.ID = sa.Student_ID INNER JOIN ClassMaster cm ON sa.Class_ID = cm.ID INNER JOIN SectionMaster secm ON sa.Section_ID = secm.ID WHERE sa.Attendance_Date = ''2026-01-10'' AND sa.Attendance_Status_ID = 2 AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (31, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q32 | What's the homework frequency per Class per week? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the homework frequency per Class per week?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(*) AS TotalHomework, COUNT(*) * 1.0 / NULLIF(DATEDIFF(WEEK, MIN(h.AssignmentDate), GETDATE()), 0) AS AvgPerWeek FROM HomeWorkAndAssignment h INNER JOIN ClassMaster cm ON h.Class_ID = cm.ID WHERE h.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND h.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (h.IsDeleted = 0 OR h.IsDeleted IS NULL) GROUP BY cm.Name ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (32, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q33 | What's the student count in Class 5? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the student count in Class 5?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS class5_strength FROM StudentAcademicDetail sad JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND cm.Name IN (''Class 5'', ''V'') AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (33, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q34 | What is the average daily collection this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the average daily collection this month?',
        @sql NVARCHAR(MAX) = N'SELECT AVG(daily_total) AS avg_daily_collection FROM (SELECT CAST(fc.Bill_Date AS DATE) AS bill_day, SUM(fc.Receipt_Amt) AS daily_total FROM FeesCollection fc WHERE DATEPART(MONTH, fc.Bill_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, fc.Bill_Date) = DATEPART(YEAR, GETDATE()) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY CAST(fc.Bill_Date AS DATE)) AS daily;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (34, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q35 | What share of collection is from misc receipts? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What share of collection is from misc receipts?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(fc.Misc_Receipt_Amt) * 100.0 / NULLIF(SUM(fc.Receipt_Amt + ISNULL(fc.Misc_Receipt_Amt, 0)), 0) AS DECIMAL(5,2)) AS MiscPercent FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (35, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q36 | How many students are absent on 14 Oct 2025 in Class 9 Section C? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students are absent on 14 Oct 2025 in Class 9 Section C?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS AbsentCount FROM StudentAttendance sa INNER JOIN ClassMaster cm ON sa.Class_ID = cm.ID INNER JOIN SectionMaster secm ON sa.Section_ID = secm.ID WHERE cm.Name IN (''Class 9'', ''IX'') AND secm.Name = ''C'' AND CAST(sa.Attendance_Date AS DATE) = ''2025-10-14'' AND sa.Attendance_Status_ID = 2 AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (36, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q37 | Science teacher for 8B? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Science teacher for 8B?',
        @sql NVARCHAR(MAX) = N'SELECT sm.Staff_FirstName + '' '' + ISNULL(sm.Staff_LastName, '''') AS TeacherName FROM SubjectAllocation_Master sam INNER JOIN Staff_Master sm ON sam.Staff_ID = sm.Staff_ID INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID INNER JOIN SectionMaster secm ON sam.Section_ID = secm.ID INNER JOIN Subject_Master sub ON sam.Subject_ID = sub.Id WHERE cm.Name IN (''Class 8'', ''VIII'') AND secm.Name = ''B'' AND sub.Name = ''Science'' AND sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (sam.IsDeleted = 0 OR sam.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (37, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q38 | Show fee group wise outstanding. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show fee group wise outstanding.',
        @sql NVARCHAR(MAX) = N'SELECT f.FeeGroup_Name, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.FeeGroup_Name ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (38, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q39 | Show month-wise homework assignment trend. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show month-wise homework assignment trend.',
        @sql NVARCHAR(MAX) = N'SELECT FORMAT(AssignmentDate, ''yyyy-MM'') AS [Month], COUNT(*) AS HomeworkCount FROM HomeWorkAndAssignment WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) GROUP BY FORMAT(AssignmentDate, ''yyyy-MM'') ORDER BY [Month];',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (39, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q40 | I need to see collection comparison between weekdays ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see collection comparison between weekdays',
        @sql NVARCHAR(MAX) = N'WITH dc AS (SELECT dm.ID, dm.DayClosureDate AS ClosureDate, dm.CollectedByName AS ClosedBy_Name, SUM(dmd.CollectedAmount) AS TotalCollection, SUM(CASE WHEN cmm.Name = ''Cash'' THEN dmd.CollectedAmount ELSE 0 END) AS CashCollection, SUM(CASE WHEN cmm.Name = ''Bank Online Transfer'' THEN dmd.CollectedAmount ELSE 0 END) AS OnlineCollection, SUM(CASE WHEN cmm.Name NOT IN (''Cash'', ''Bank Online Transfer'', ''Cheque'') THEN dmd.CollectedAmount ELSE 0 END) AS OtherCollection, SUM(CASE WHEN cmm.Name = ''Cheque'' THEN dmd.CollectedAmount ELSE 0 END) AS ChequeCollection FROM DayclosureMaster dm INNER JOIN DayclosureMaster_Details dmd ON dmd.HeaderID = dm.ID LEFT JOIN CollectionMode_Master cmm ON dmd.CollectionMode_ID = cmm.ID WHERE dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (dm.IsDeleted = 0 OR dm.IsDeleted IS NULL) AND (dmd.IsDeleted = 0 OR dmd.IsDeleted IS NULL) GROUP BY dm.ID, dm.DayClosureDate, dm.CollectedByName) SELECT DATENAME(WEEKDAY, ClosureDate) AS DayOfWeek, AVG(TotalCollection) AS AvgCollection, COUNT(*) AS DaysCount FROM dc GROUP BY DATENAME(WEEKDAY, ClosureDate), DATEPART(WEEKDAY, ClosureDate) ORDER BY DATEPART(WEEKDAY, ClosureDate);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (40, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q41 | Hey, what's the term-wise fee collection breakdown? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the term-wise fee collection breakdown?',
        @sql NVARCHAR(MAX) = N'SELECT fcd.Term_ID, SUM(fcd.Paid_Amt) AS TotalPaid, SUM(fcd.Remaining_Amt) AS TotalRemaining FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fcd.Term_ID ORDER BY fcd.Term_ID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (41, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q42 | How many applications are still pending review? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many applications are still pending review?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS PendingApplications FROM ApplicationEntry ae INNER JOIN ApplicationStatus_Master asm ON ae.ApplicationStatus_ID = asm.ID WHERE asm.Name = ''Application Submitted'' AND ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (ae.IsDeleted IS NULL OR ae.IsDeleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (42, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q43 | How many unique staff marked attendance today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many unique staff marked attendance today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT Staff_ID) AS StaffMarked FROM Staff_Attendance WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND Attendance_Date = CAST(GETDATE() AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (43, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q44 | Let me see the hostel fee collection rate ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see the hostel fee collection rate',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(SUM(Paid_Amt) * 100.0 / NULLIF(SUM(Amount), 0), 2) AS HostelFeeCollectionRate FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND IsHostelFee = 1 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (44, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q45 | Pull up subjects available in Class 12 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up subjects available in Class 12',
        @sql NVARCHAR(MAX) = N'SELECT sub.Name AS SubjectName, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS TeacherName FROM ClassSubjectDetails cs INNER JOIN ClassMaster cm ON cs.Class_Id = cm.ID INNER JOIN Subject_Master sub ON cs.Subject_Id = sub.Id LEFT JOIN SubjectAllocation_Master sam ON sam.Class_ID = cs.Class_Id AND sam.Subject_ID = cs.Subject_Id AND (sam.IsDeleted = 0 OR sam.IsDeleted IS NULL) LEFT JOIN Staff_Master sm ON sam.Staff_ID = sm.Staff_ID WHERE cs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND cs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.Name IN (''Class 12'', ''XII'') ORDER BY sub.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (45, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q46 | Show the resolution rate for feedback tickets. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the resolution rate for feedback tickets.',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(CASE WHEN Status = ''Closed'' THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS ResolutionRate FROM FeedbackTicket WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (46, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q47 | Show the day closure summary for today. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the day closure summary for today.',
        @sql NVARCHAR(MAX) = N'WITH dc AS (SELECT dm.ID, dm.DayClosureDate AS ClosureDate, dm.CollectedByName AS ClosedBy_Name, SUM(dmd.CollectedAmount) AS TotalCollection, SUM(CASE WHEN cmm.Name = ''Cash'' THEN dmd.CollectedAmount ELSE 0 END) AS CashCollection, SUM(CASE WHEN cmm.Name = ''Bank Online Transfer'' THEN dmd.CollectedAmount ELSE 0 END) AS OnlineCollection, SUM(CASE WHEN cmm.Name NOT IN (''Cash'', ''Bank Online Transfer'', ''Cheque'') THEN dmd.CollectedAmount ELSE 0 END) AS OtherCollection, SUM(CASE WHEN cmm.Name = ''Cheque'' THEN dmd.CollectedAmount ELSE 0 END) AS ChequeCollection FROM DayclosureMaster dm INNER JOIN DayclosureMaster_Details dmd ON dmd.HeaderID = dm.ID LEFT JOIN CollectionMode_Master cmm ON dmd.CollectionMode_ID = cmm.ID WHERE dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (dm.IsDeleted = 0 OR dm.IsDeleted IS NULL) AND (dmd.IsDeleted = 0 OR dmd.IsDeleted IS NULL) GROUP BY dm.ID, dm.DayClosureDate, dm.CollectedByName) SELECT TotalCollection, CashCollection, OnlineCollection, ChequeCollection, ClosedBy_Name FROM dc WHERE CAST(ClosureDate AS DATE) = CAST(GETDATE() AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (47, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q48 | What is the outstanding for Class 9 in the Pallavaram branch? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the outstanding for Class 9 in the Pallavaram branch?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fisd.Amount - ISNULL(fisd.Concession_Amt,0) - ISNULL(fisd.Paid_Amt,0) - ISNULL(fisd.Lien_Amount,0)) AS Outstanding FROM FeesInformationStudentDetail fisd JOIN ClassMaster cm ON fisd.ClassID = cm.ID WHERE fisd.IsIncludedInLumpSum <> 1 AND fisd.IsDonation = 0 AND cm.Name IN (''Class 9'', ''IX'') AND fisd.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%Pallavaram%'' OR ShortName LIKE ''%Pallavaram%'')) AND fisd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (48, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q49 | Day wise attendance count this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Day wise attendance count this month',
        @sql NVARCHAR(MAX) = N'SELECT Attendance_Date, COUNT(CASE WHEN Attendance_Status_ID = 1 THEN 1 END) AS Present, COUNT(CASE WHEN Attendance_Status_ID = 2 THEN 1 END) AS Absent FROM Staff_Attendance WHERE MONTH(Attendance_Date) = MONTH(GETDATE()) AND YEAR(Attendance_Date) = YEAR(GETDATE()) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY Attendance_Date ORDER BY Attendance_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (49, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q50 | Just checking - did all teachers come in today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - did all teachers come in today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) AS Present, COUNT(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 END) AS Absent FROM Staff_Attendance sa WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE)  AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (50, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q51 | What's the refund to collection ratio? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the refund to collection ratio?',
        @sql NVARCHAR(MAX) = N'SELECT (SELECT ISNULL(SUM(Refund_Amt), 0) FROM RefundReceipt WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)))) AS TotalRefunds, (SELECT ISNULL(SUM(Receipt_Amt), 0) FROM FeesCollection WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND ChequeStatus_ID NOT IN (3, 4)) AS TotalCollections;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (51, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q52 | What's the gender-wise split of admission applications? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the gender-wise split of admission applications?',
        @sql NVARCHAR(MAX) = N'SELECT ae.Gender, COUNT(*) AS ApplicationCount FROM ApplicationEntry ae WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (ae.IsDeleted IS NULL OR ae.IsDeleted = 0) GROUP BY ae.Gender;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (52, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q53 | Show term-wise outstanding fees. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show term-wise outstanding fees.',
        @sql NVARCHAR(MAX) = N'SELECT f.Term_ID, f.Term_Name, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Term_ID, f.Term_Name ORDER BY f.Term_ID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (53, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q54 | Give me a list of students who changed Section with reason ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me a list of students who changed Section with reason',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, sad.SectionChangeReason FROM Student_Master sm JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsSectionChanged = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.ClassName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (54, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q55 | Improvement from unit test to final exam ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Improvement from unit test to final exam',
        @sql NVARCHAR(MAX) = N'SELECT et.Name AS ExamType, CAST(AVG(smd.Marks) AS DECIMAL(5,2)) AS AvgMarks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ExamTypeMaster et ON smm.ExamTypeID = et.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND et.IsDeleted = 0 GROUP BY et.Name, et.ID ORDER BY et.ID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (55, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q56 | Collection since the start of this academic year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Collection since the start of this academic year',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS TotalYearCollection FROM FeesCollection fc WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (56, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q57 | TCs issued in December ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'TCs issued in December',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName, sad.TCIssuedDate FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsTCIssued = 1 AND MONTH(sad.TCIssuedDate) = 12 ORDER BY sad.TCIssuedDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (57, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q58 | Let me see fee group wise outstanding ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see fee group wise outstanding',
        @sql NVARCHAR(MAX) = N'SELECT f.FeeGroup_Name, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.FeeGroup_Name ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (58, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q59 | How did Class 10 perform in midterm vs final? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How did Class 10 perform in midterm vs final?',
        @sql NVARCHAR(MAX) = N'SELECT et.Name AS ExamType, CAST(AVG(smd.Marks) AS DECIMAL(5,2)) AS AvgMarks, CAST(SUM(CASE WHEN smd.Marks >= eced.MinMark THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS PassPct FROM StudentMarkDetails smd INNER JOIN ExamConfigurationEvaluationDetails eced ON smd.EvalHierID = eced.ID INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ExamTypeMaster et ON smm.ExamTypeID = et.ID INNER JOIN ClassMaster c ON smm.ClassID = c.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND et.IsDeleted = 0 AND c.Name = ''Class 10'' GROUP BY et.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (59, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q60 | Exam-wise pass percentage ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Exam-wise pass percentage',
        @sql NVARCHAR(MAX) = N'SELECT et.Name AS ExamType, CAST(SUM(CASE WHEN smd.Marks >= eced.MinMark THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS PassPercentage FROM StudentMarkDetails smd INNER JOIN ExamConfigurationEvaluationDetails eced ON smd.EvalHierID = eced.ID INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ExamTypeMaster et ON smm.ExamTypeID = et.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND et.IsDeleted = 0 GROUP BY et.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (60, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q61 | Show me the fee type-wise collection summary. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me the fee type-wise collection summary.',
        @sql NVARCHAR(MAX) = N'SELECT fcd.FeesType_Name, SUM(fcd.Paid_Amt) AS Collected FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fcd.FeesType_Name ORDER BY Collected DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (61, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q62 | Which students paid donation more than once? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which students paid donation more than once?',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName + '' '' + sm.LastName AS StudentName, sm.FatherName, COUNT(*) AS DonationCount, SUM(d.Receipt_Amt) AS TotalDonated FROM DonationFeesCollection d INNER JOIN Student_Master sm ON d.Student_ID = sm.ID WHERE d.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND d.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (d.IsDeleted = 0 OR d.IsDeleted IS NULL) AND d.ChequeStatus_ID NOT IN (3, 4) GROUP BY sm.FirstName, sm.LastName, sm.FatherName HAVING COUNT(*) > 1 ORDER BY DonationCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (62, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q63 | Give me a list of classes that have fewer than 5 subjects assigned ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me a list of classes that have fewer than 5 subjects assigned',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(DISTINCT cs.Subject_Id) AS SubjectCount FROM ClassSubjectDetails cs INNER JOIN ClassMaster cm ON cs.Class_Id = cm.ID WHERE cs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND cs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY cm.Name HAVING COUNT(DISTINCT cs.Subject_Id) < 5 ORDER BY SubjectCount;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (63, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q64 | Tell me a joke ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Tell me a joke',
        @sql NVARCHAR(MAX) = N'SELECT ''This question is outside school data. I can help with students, fees, attendance, staff, exams and school operations.'' AS Message',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (64, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q65 | Hey, what's the collection for the last 7 days? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the collection for the last 7 days?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS last_7_days_collection FROM FeesCollection fc WHERE fc.Bill_Date >= DATEADD(DAY, -7, CAST(GETDATE() AS DATE)) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (65, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q66 | What is the total number of active vehicles? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total number of active vehicles?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS ActiveVehicles FROM VehicleMaster WHERE IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (66, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q67 | Show class-wise donation collection. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show class-wise donation collection.',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(*) AS Receipts, SUM(d.Receipt_Amt) AS TotalDonation FROM DonationFeesCollection d INNER JOIN Student_Master sm ON d.Student_ID = sm.ID INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE d.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND d.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (d.IsDeleted = 0 OR d.IsDeleted IS NULL) AND d.ChequeStatus_ID NOT IN (3, 4) GROUP BY cm.Name ORDER BY TotalDonation DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (67, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q68 | Give me the total fees received today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the total fees received today',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS total_received_today FROM FeesCollection fc WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (68, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q69 | How much GST was collected this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much GST was collected this month?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fcd.GSTAmount) AS TotalGST FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND MONTH(fc.Bill_Date) = MONTH(GETDATE()) AND YEAR(fc.Bill_Date) = YEAR(GETDATE()) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (69, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q70 | Show department-wise employee distribution ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show department-wise employee distribution',
        @sql NVARCHAR(MAX) = N'SELECT dm.Name AS Department, COUNT(sm.Staff_ID) AS StaffCount FROM StaffDepartmentMaster dm INNER JOIN StaffDepartmentMapping sdm ON dm.Id = sdm.DepartmentID INNER JOIN StaffDepartmentMappingDetail sdmd ON sdm.Id = sdmd.MappingID INNER JOIN Staff_Master sm ON sdmd.StaffID = sm.Staff_ID WHERE dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (dm.IsDeleted IS NULL OR dm.IsDeleted = 0) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1 GROUP BY dm.Name ORDER BY StaffCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (70, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q71 | How many students of Class 3 are absent today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students of Class 3 are absent today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS absent_count FROM StudentAttendance sa JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.Attendance_Status_ID = 2 AND cm.Name IN (''Class 3'', ''III'') AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (71, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q72 | Class-wise summary with strength, new admissions, dropouts, and collection ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class-wise summary with strength, new admissions, dropouts, and collection',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(DISTINCT CASE WHEN sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) THEN sad.StudentID END) AS Strength, COUNT(DISTINCT CASE WHEN sad.IsNewAdmission = 1 AND sad.IsActive = 1 THEN sad.StudentID END) AS NewAdmissions, COUNT(DISTINCT CASE WHEN sad.IsTCIssued = 1 THEN sad.StudentID END) AS Dropouts, ISNULL(fc_agg.TotalCollection, 0) AS TotalCollection FROM StudentAcademicDetail sad JOIN ClassMaster cm ON sad.ClassID = cm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id LEFT JOIN (SELECT fc.Class_ID, SUM(fc.Receipt_Amt) AS TotalCollection FROM FeesCollection fc JOIN Branch_Academic_Details b ON fc.AcademicYearID = b.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN b.Start_Date AND b.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fc.Class_ID) fc_agg ON sad.ClassID = fc_agg.Class_ID WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name, cm.DisplayOrder, fc_agg.TotalCollection ORDER BY cm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (72, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q73 | Month-wise TC requests this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Month-wise TC requests this year',
        @sql NVARCHAR(MAX) = N'SELECT MONTH(tcr.AppliedDate) AS MonthNo, DATENAME(MONTH, tcr.AppliedDate) AS MonthName, COUNT(*) AS TCRequests FROM TCRequest tcr WHERE tcr.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND tcr.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (tcr.IsDeleted IS NULL OR tcr.IsDeleted = 0) GROUP BY MONTH(tcr.AppliedDate), DATENAME(MONTH, tcr.AppliedDate) ORDER BY MonthNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (73, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q74 | I need the staff attendance today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need the staff attendance today',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS PresentToday FROM Staff_Attendance WHERE Attendance_Date = CAST(GETDATE() AS DATE) AND Attendance_Status_ID = 1 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (74, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q75 | Who teaches English across all classes? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who teaches English across all classes?',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT sm.Staff_FirstName + '' '' + sm.Staff_LastName AS TeacherName, cm.Name AS ClassName FROM SubjectAllocation_Master sam INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID INNER JOIN Staff_Master sm ON sam.Staff_ID = sm.Staff_ID INNER JOIN Subject_Master sub ON sam.Subject_ID = sub.Id WHERE sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (sam.IsDeleted = 0 OR sam.IsDeleted IS NULL) AND sub.Name = ''English'' ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (75, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q76 | Pull up all students with marks above 90 in any subject ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up all students with marks above 90 in any subject',
        @sql NVARCHAR(MAX) = N'SELECT pc.StudentName AS StudentName, pc.SubjectName AS SubjectName, cm.Name AS ClassName, pc.Marks FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE pc.Marks >= 90 AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) ORDER BY pc.Marks DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (76, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q77 | Pull up the latest 10 enquiries real quick ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up the latest 10 enquiries real quick',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT TOP 10 em.CallRefNo, em.Parent_Name, em.Student_Name, em.MobileNo1, em.CallDate, esm.Name AS Status FROM GeneralCallRegister em INNER JOIN Enquiry_Status_Master esm ON em.CallStatus_ID = esm.ID WHERE em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND (em.IsDeleted = 0 OR em.IsDeleted IS NULL) ORDER BY em.CallDate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (77, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q78 | Any TCs issued this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Any TCs issued this month?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TCsIssued FROM StudentAcademicDetail sad WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsTCIssued = 1 AND MONTH(sad.TCIssuedDate) = MONTH(GETDATE()) AND YEAR(sad.TCIssuedDate) = YEAR(GETDATE());',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (78, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q79 | So, what's the gender distribution of applicants? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, what''s the gender distribution of applicants?',
        @sql NVARCHAR(MAX) = N'SELECT Gender, COUNT(*) AS Count, CAST(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER() AS DECIMAL(5,2)) AS Percentage FROM ApplicationEntry WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) GROUP BY Gender;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (79, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q80 | Compare total fee collection between 2024-25 and 2025-26 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare total fee collection between 2024-25 and 2025-26',
        @sql NVARCHAR(MAX) = N'SELECT bad.Name AS AcademicYear, SUM(fc.Receipt_Amt) AS TotalCollection FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND (GETDATE() BETWEEN bad.Start_Date AND bad.End_Date OR bad.Id = (SELECT PreviousYearID FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = bad.Branch_Id)) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bad.Name ORDER BY bad.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (80, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q81 | Check cheque collection ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Check cheque collection',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(fc.Id) AS ChequeReceipts, SUM(fc.Receipt_Amt) AS ChequeTotal FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.Collection_Mode_ID IN (SELECT ID FROM CollectionMode_Master WHERE Name = ''Cheque'') AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (81, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q82 | Students with unpaid fees ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students with unpaid fees',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sad.ClassName, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN Student_Master sm ON f.Student_ID = sm.ID INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY sm.AdmissionNo, sm.FirstName, sm.LastName, sad.ClassName HAVING SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 0 ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (82, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q83 | Fee groups that have zero collection so far ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Fee groups that have zero collection so far',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT fcd.FeesGroup_Name FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fcd.FeesGroup_Name HAVING SUM(fcd.Paid_Amt) = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (83, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q84 | Can you show month-wise concession amounts given? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show month-wise concession amounts given?',
        @sql NVARCHAR(MAX) = N'SELECT f.Month_No, f.Month_Name, SUM(ISNULL(f.Concession_Amt, 0)) AS Concession FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Month_No, f.Month_Name ORDER BY f.Month_No;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (84, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q85 | I need to see class-wise collection with rank and percentage ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see class-wise collection with rank and percentage',
        @sql NVARCHAR(MAX) = N'WITH ClassCollection AS (SELECT cm.Name AS ClassName, cm.DisplayOrder, SUM(fc.Receipt_Amt) AS TotalCollection FROM FeesCollection fc JOIN ClassMaster cm ON fc.Class_ID = cm.ID JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name, cm.DisplayOrder) SELECT ClassName, TotalCollection, RANK() OVER (ORDER BY TotalCollection DESC) AS CollectionRank, CAST(TotalCollection * 100.0 / NULLIF(SUM(TotalCollection) OVER (), 0) AS DECIMAL(5,2)) AS PercentContribution FROM ClassCollection ORDER BY DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (85, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q86 | Students from each class who have 100% attendance ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students from each class who have 100% attendance',
        @sql NVARCHAR(MAX) = N'WITH StudentAtt AS (SELECT sa.Student_ID, sa.Class_ID, COUNT(*) AS TotalDays, COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) AS PresentDays FROM StudentAttendance sa JOIN Branch_Academic_Details bad ON sa.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sa.Student_ID, sa.Class_ID HAVING COUNT(*) = COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) AND COUNT(*) > 10) SELECT cm.Name AS ClassName, COUNT(DISTINCT sat.Student_ID) AS PerfectAttendanceStudents FROM StudentAtt sat JOIN ClassMaster cm ON sat.Class_ID = cm.ID GROUP BY cm.Name, cm.DisplayOrder ORDER BY cm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (86, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q87 | Monthly attendance class-wise ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Monthly attendance class-wise',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS class_name, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS attendance_pct FROM StudentAttendance sa JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE DATEPART(MONTH, sa.Attendance_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, sa.Attendance_Date) = DATEPART(YEAR, GETDATE()) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (87, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q88 | What is the total demand for Perambur branch? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total demand for Perambur branch?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fisd.Amount) AS TotalDemand FROM FeesInformationStudentDetail fisd WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND fisd.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%Perambur%'' OR ShortName LIKE ''%Perambur%'')) AND fisd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (88, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q89 | How many students have received concessions? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students have received concessions?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT Student_ID) AS StudentsWithConcession FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND ISNULL(Concession_Amt, 0) > 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (89, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q90 | How many students scored below 35? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students scored below 35?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS BelowPass FROM StudentMarkDetails smd INNER JOIN ExamConfigurationEvaluationDetails eced ON smd.EvalHierID = eced.ID INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND smd.Marks < eced.MinMark;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (90, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q91 | How many leave applications are pending approval? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many leave applications are pending approval?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS PendingLeaves FROM LeaveEntryMaster lem INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND ls.Name = ''Pending'';',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (91, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q92 | Maths mein kaun top kiya? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Maths mein kaun top kiya?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 smd.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName, smd.Marks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN Subject_Master s ON s.BranchID = smd.BranchID INNER JOIN Student_Master stm ON smd.StudentID = stm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND s.Name = ''Maths'' AND s.IsDeleted = 0 ORDER BY smd.Marks DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (92, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q93 | Show the designation-wise headcount of staff ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the designation-wise headcount of staff',
        @sql NVARCHAR(MAX) = N'SELECT sdm2.Name AS Designation, COUNT(*) AS StaffCount FROM Staff_Master sm INNER JOIN StaffDesignationMaster sdm2 ON sm.Designation_ID = sdm2.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sm.IsDeleted = 0 AND sm.StaffStatus_ID = 1 AND sdm2.IsDeleted = 0 GROUP BY sdm2.Name ORDER BY StaffCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (93, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q94 | What's the number of students appearing per exam type? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the number of students appearing per exam type?',
        @sql NVARCHAR(MAX) = N'SELECT et.Name AS ExamType, COUNT(DISTINCT smd.StudentID) AS StudentsAppeared FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ExamTypeMaster et ON smm.ExamTypeID = et.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND et.IsDeleted = 0 GROUP BY et.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (94, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q95 | Month over month salary growth ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Month over month salary growth',
        @sql NVARCHAR(MAX) = N'SELECT gm.MonthName, gm.MonthID, SUM(gem.NetPay) AS TotalSalary FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID INNER JOIN Branch_Academic_Details b ON gm.AcademicYearID = b.Id WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND GETDATE() BETWEEN b.Start_Date AND b.End_Date AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 GROUP BY gm.MonthName, gm.MonthID ORDER BY gm.MonthID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (95, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q96 | Pull up enquiry count by day of week ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up enquiry count by day of week',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT DATENAME(WEEKDAY, CallDate) AS DayOfWeek, COUNT(*) AS EnquiryCount FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL) GROUP BY DATENAME(WEEKDAY, CallDate), DATEPART(WEEKDAY, CallDate) ORDER BY DATEPART(WEEKDAY, CallDate);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (96, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q97 | Enquiries received this month at Medavakkam branch ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Enquiries received this month at Medavakkam branch',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS Enquiries FROM GeneralCallRegister em WHERE DATEPART(MONTH, em.CallDate) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, em.CallDate) = DATEPART(YEAR, GETDATE()) AND em.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%Medavakkam%'' OR ShortName LIKE ''%Medavakkam%'')) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (97, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q98 | VIP students in senior classes who paid via cash ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'VIP students in senior classes who paid via cash',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, SUM(fc.Receipt_Amt) AS CashPaid FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID INNER JOIN FeesCollection fc ON sm.ID = fc.Student_ID WHERE sm.IsVIP = 1 AND cm.Name IN (''Class 9'', ''Class 10'', ''Class 11'', ''Class 12'') AND fc.Collection_Mode_ID IN (SELECT ID FROM CollectionMode_Master WHERE Name = ''Cash'') AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.ID, sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo, sad.ClassName ORDER BY CashPaid DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (98, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q99 | What is the overall boy to girl ratio? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the overall boy to girl ratio?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(CASE WHEN sm.Gender IN (''Male'', ''Boy'') THEN 1 END) AS Boys, COUNT(CASE WHEN sm.Gender IN (''Female'', ''Girl'') THEN 1 END) AS Girls, CAST(COUNT(CASE WHEN sm.Gender IN (''Male'', ''Boy'') THEN 1 END) * 1.0 / NULLIF(COUNT(CASE WHEN sm.Gender IN (''Female'', ''Girl'') THEN 1 END), 0) AS DECIMAL(5,2)) AS BoyGirlRatio FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (99, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q100 | Absentees kitne hain aaj? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Absentees kitne hain aaj?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS AbsentToday FROM StudentAttendance sa WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.Attendance_Status_ID = 2;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
PRINT 'checkpoint: reached Q100';
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (100, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q101 | List staff absent more than 10 days this month based on payroll records ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List staff absent more than 10 days this month based on payroll records',
        @sql NVARCHAR(MAX) = N'SELECT gem.EmployeeID, gem.EmployeeName, (gem.WorkingDays - gem.PresentDays) AS AbsentDays FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) AND (gem.WorkingDays - gem.PresentDays) > 10;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (101, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q102 | What is the average fee per student this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the average fee per student this year?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(SUM(Amount) * 1.0 / NULLIF(COUNT(DISTINCT Student_ID), 0), 2) AS AvgFeePerStudent FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (102, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q103 | Show me the cash amount collected in yesterday's day closing entry ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me the cash amount collected in yesterday''s day closing entry',
        @sql NVARCHAR(MAX) = N'WITH dc AS (SELECT dm.ID, dm.DayClosureDate AS ClosureDate, dm.CollectedByName AS ClosedBy_Name, SUM(dmd.CollectedAmount) AS TotalCollection, SUM(CASE WHEN cmm.Name = ''Cash'' THEN dmd.CollectedAmount ELSE 0 END) AS CashCollection, SUM(CASE WHEN cmm.Name = ''Bank Online Transfer'' THEN dmd.CollectedAmount ELSE 0 END) AS OnlineCollection, SUM(CASE WHEN cmm.Name NOT IN (''Cash'', ''Bank Online Transfer'', ''Cheque'') THEN dmd.CollectedAmount ELSE 0 END) AS OtherCollection, SUM(CASE WHEN cmm.Name = ''Cheque'' THEN dmd.CollectedAmount ELSE 0 END) AS ChequeCollection FROM DayclosureMaster dm INNER JOIN DayclosureMaster_Details dmd ON dmd.HeaderID = dm.ID LEFT JOIN CollectionMode_Master cmm ON dmd.CollectionMode_ID = cmm.ID WHERE dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (dm.IsDeleted = 0 OR dm.IsDeleted IS NULL) AND (dmd.IsDeleted = 0 OR dmd.IsDeleted IS NULL) GROUP BY dm.ID, dm.DayClosureDate, dm.CollectedByName) SELECT CashCollection FROM dc WHERE CAST(ClosureDate AS DATE) = CAST(DATEADD(DAY, -1, GETDATE()) AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (103, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q104 | How's attendance been this week overall? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How''s attendance been this week overall?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(CASE WHEN Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS WeeklyAttendancePct FROM Staff_Attendance WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND Attendance_Date >= DATEADD(DAY, -DATEPART(WEEKDAY, GETDATE()) + 1, CAST(GETDATE() AS DATE)) AND Attendance_Date <= CAST(GETDATE() AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (104, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q105 | Show the number of students who paid fully vs partially vs not paid at all ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the number of students who paid fully vs partially vs not paid at all',
        @sql NVARCHAR(MAX) = N'SELECT ''Fully Paid'' AS category, COUNT(*) AS student_count FROM (SELECT fc.Student_ID FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN StudentAcademicDetail sad ON fc.Student_ID = sad.StudentID AND fc.AcademicYearID = sad.AcademicYearID WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND sad.IsActive = 1 GROUP BY fc.Student_ID HAVING SUM(fcd.Remaining_Amt) = 0) AS fully_paid UNION ALL SELECT ''Partially Paid'' AS category, COUNT(*) AS student_count FROM (SELECT fc.Student_ID FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN StudentAcademicDetail sad ON fc.Student_ID = sad.StudentID AND fc.AcademicYearID = sad.AcademicYearID WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND sad.IsActive = 1 GROUP BY fc.Student_ID HAVING SUM(fcd.Paid_Amt) > 0 AND SUM(fcd.Remaining_Amt) > 0) AS partial;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (105, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q106 | List all upcoming holidays. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all upcoming holidays.',
        @sql NVARCHAR(MAX) = N'SELECT Name, From_Date, To_Date, DATEDIFF(DAY, From_Date, To_Date) + 1 AS Duration FROM HolidayMaster WHERE From_Date >= GETDATE() AND IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY From_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (106, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q107 | Can you show outstanding per Section for Class 9? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show outstanding per Section for Class 9?',
        @sql NVARCHAR(MAX) = N'SELECT SectionName, SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND ClassName = ''Class 9'' AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY SectionName ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (107, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q108 | What's the recovery rate for bus fees vs non-bus fees? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the recovery rate for bus fees vs non-bus fees?',
        @sql NVARCHAR(MAX) = N'SELECT CASE WHEN f.IsBusFee = 1 THEN ''Bus Fee'' ELSE ''Non-Bus Fee'' END AS Category, ROUND(SUM(f.Paid_Amt) * 100.0 / NULLIF(SUM(f.Amount - ISNULL(f.Concession_Amt, 0)), 0), 2) AS RecoveryRate FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY CASE WHEN f.IsBusFee = 1 THEN ''Bus Fee'' ELSE ''Non-Bus Fee'' END;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (108, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q109 | What are the staff positions in the school? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What are the staff positions in the school?',
        @sql NVARCHAR(MAX) = N'SELECT Name AS Position FROM StaffDesignationMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0 ORDER BY Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (109, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q110 | Show all admission types available. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show all admission types available.',
        @sql NVARCHAR(MAX) = N'SELECT ID, Name, Code, Description FROM AdmissionType_Master WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (IsDeleted = 0 OR IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (110, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q111 | Term-wise performance of Class 8 in Mathematics ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Term-wise performance of Class 8 in Mathematics',
        @sql NVARCHAR(MAX) = N'SELECT pc.TermName AS TermName, CAST(AVG(pc.Marks) AS DECIMAL(5,2)) AS AvgMarks FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE cm.Name IN (''Class 8'', ''VIII'') AND pc.SubjectName = ''Maths'' AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) GROUP BY pc.TermName ORDER BY pc.TermName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (111, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q112 | Show demand and outstanding for Class 5 Section A. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show demand and outstanding for Class 5 Section A.',
        @sql NVARCHAR(MAX) = N'SELECT SUM(f.Amount) AS Demand, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.ClassName = ''Class 5'' AND f.SectionName = ''A'' AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (112, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q113 | How many students have outstanding fees greater than 10000? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students have outstanding fees greater than 10000?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS StudentCount FROM (SELECT Student_ID, SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY Student_ID HAVING SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) > 10000) t;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (113, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q114 | Staff with most absences this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff with most absences this month',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 sa.Staff_ID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName, COUNT(*) AS AbsentDays FROM Staff_Attendance sa INNER JOIN Staff_Master sm ON sa.Staff_ID = sm.Staff_ID AND sm.StaffStatus_ID = 1 WHERE sa.Attendance_Status_ID = 2 AND MONTH(sa.Attendance_Date) = MONTH(GETDATE()) AND YEAR(sa.Attendance_Date) = YEAR(GETDATE()) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sa.Staff_ID, sm.Staff_FirstName, sm.Staff_LastName ORDER BY AbsentDays DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (114, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q115 | Age-wise student count distribution ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Age-wise student count distribution',
        @sql NVARCHAR(MAX) = N'SELECT DATEDIFF(YEAR, sm.StudentDob, GETDATE()) AS Age, COUNT(DISTINCT sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.StudentDob IS NOT NULL AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY DATEDIFF(YEAR, sm.StudentDob, GETDATE()) ORDER BY Age;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (115, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q116 | I need the fail percentage by subject ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need the fail percentage by subject',
        @sql NVARCHAR(MAX) = N'SELECT s.Name AS Subject, CAST(SUM(CASE WHEN smd.Marks < eced.MinMark THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS FailPercentage FROM StudentMarkDetails smd INNER JOIN ExamConfigurationEvaluationDetails eced ON smd.EvalHierID = eced.ID INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN Subject_Master s ON s.BranchID = smd.BranchID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND s.IsDeleted = 0 GROUP BY s.Name ORDER BY FailPercentage DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (116, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q117 | What is the average concession per student? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the average concession per student?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(SUM(ISNULL(Concession_Amt, 0)) * 1.0 / NULLIF(COUNT(DISTINCT Student_ID), 0), 2) AS AvgConcession FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND ISNULL(Concession_Amt, 0) > 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (117, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q118 | How many total enquiries do we have this academic year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many total enquiries do we have this academic year?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS TotalEnquiries FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (118, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q119 | Circulars issued for Class 10 this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Circulars issued for Class 10 this year',
        @sql NVARCHAR(MAX) = N'SELECT ce.Title, ce.Circular_Date, ce.Circular_Date FROM CircularEntry ce WHERE ce.Class_Name LIKE ''%Class 10%'' OR ce.Class_Name LIKE ''%X%'' AND ce.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ce.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ce.IsDeleted = 0 OR ce.IsDeleted IS NULL) ORDER BY ce.Circular_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (119, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q120 | What are the routes that have more than 5 boarding points? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What are the routes that have more than 5 boarding points?',
        @sql NVARCHAR(MAX) = N'SELECT rm.Name AS RouteName, COUNT(rmd.Id) AS BoardingPoints FROM Route_Master rm INNER JOIN Route_MasterDetails rmd ON rm.ID = rmd.Route_ID INNER JOIN BoardingPoint_Master bpm ON rmd.BoardingPoint_ID = bpm.Id WHERE rm.IsDeleted = 0 AND rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY rm.Name HAVING COUNT(rmd.Id) > 5;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (120, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q121 | How many students are above 15 years old? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students are above 15 years old?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS students_above_15 FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND DATEDIFF(YEAR, sm.StudentDob, GETDATE()) > 15 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (121, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q122 | Hey, how many TCs have been fully processed and handed over? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many TCs have been fully processed and handed over?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS ProcessedTCs FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.IsTCIssued = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (122, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q123 | TC issuance breakdown by month for the current academic year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'TC issuance breakdown by month for the current academic year',
        @sql NVARCHAR(MAX) = N'SELECT MONTH(sad.TCIssuedDate) AS Month, COUNT(DISTINCT sad.StudentID) AS TCIssued FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsTCIssued = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY MONTH(sad.TCIssuedDate) ORDER BY Month;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (123, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q124 | What is the religion-wise breakdown of students? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the religion-wise breakdown of students?',
        @sql NVARCHAR(MAX) = N'SELECT sm.Religion_Name, COUNT(*) AS total FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY sm.Religion_Name ORDER BY COUNT(*) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (124, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q125 | Show the trend of converted enquiries month over month. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the trend of converted enquiries month over month.',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT FORMAT(CallDate, ''yyyy-MM'') AS Month, COUNT(*) AS ConvertedCount FROM GeneralCallRegister WHERE CallStatus_ID IN (SELECT ID FROM Enquiry_Status_Master WHERE Name = ''Completed'') AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0 GROUP BY FORMAT(CallDate, ''yyyy-MM'') ORDER BY Month;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (125, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q126 | Just checking - how many faculty members are there? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many faculty members are there?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS FacultyCount FROM Staff_Master sm INNER JOIN StaffType_Master stm ON sm.StaffType_ID = stm.ID INNER JOIN StaffTypeCategoryMaster stcm ON stm.Type_Id = stcm.Id WHERE stcm.Name = ''Academic'' AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sm.IsDeleted = 0 AND sm.StaffStatus_ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (126, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q127 | Which fee head contributes the most to collection? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which fee head contributes the most to collection?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 fcd.FeesGroup_Name AS FeeHead, SUM(fcd.Paid_Amt) AS TotalCollected FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fcd.FeesGroup_Name ORDER BY TotalCollected DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (127, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q128 | Compare Term 1 and Term 2 average marks for Class 10 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare Term 1 and Term 2 average marks for Class 10',
        @sql NVARCHAR(MAX) = N'SELECT pc.TermName AS TermName, CAST(AVG(pc.Marks) AS DECIMAL(5,2)) AS AvgMarks FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE cm.Name IN (''Class 10'', ''X'') AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) GROUP BY pc.TermName ORDER BY pc.TermName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (128, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q129 | Branch-wise attendance today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Branch-wise attendance today',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS Present, SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END) AS Absent FROM StudentAttendance sa JOIN BranchMaster bm ON sa.BranchID = bm.ID WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY bm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (129, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q130 | Are any staff children absent today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Are any staff children absent today?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, cm.Name AS class_name FROM StudentAttendance sa JOIN Student_Master sm ON sa.Student_ID = sm.ID JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.Attendance_Status_ID = 2 AND sm.StaffChild = 1 AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (130, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q131 | How many students currently owe late fees? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students currently owe late fees?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT FI.Student_ID) AS StudentsOwing FROM FeesInformationStudentDetail FI INNER JOIN LateFeeMaster lfm ON lfm.TermId = FI.Term_ID AND lfm.IsActive = 1 AND CAST(GETDATE() AS DATE) <= lfm.ValidityDate AND CAST(GETDATE() AS DATE) >= lfm.LastDate INNER JOIN LateFeeDetails lfd ON lfm.ID = lfd.LateFeeID AND (lfd.ClassId = FI.ClassID OR lfd.ClassId = 0) AND CAST(GETDATE() AS DATE) BETWEEN lfd.FromDate AND lfd.ToDate INNER JOIN Fees_Master fmm ON fmm.ID = FI.Fees_ID AND ISNULL(fmm.IsIncludeinLateFee, 0) = 1 INNER JOIN Student_Master SM ON SM.ID = FI.Student_ID LEFT JOIN LateFee_Concession lfc ON lfc.Student_ID = FI.Student_ID AND lfc.LateFeeHeadId = lfm.LateFeeHeadId AND lfc.Term_ID = FI.Term_ID AND lfc.AcademicYearID = FI.AcademicYearID AND lfc.BranchID = FI.BranchID AND ISNULL(lfc.IsDeleted, 0) = 0 WHERE FI.IsIncludedInLumpSum <> 1 AND FI.IsDonation = 0 AND (FI.Amount - ISNULL(FI.Concession_Amt,0) - FI.Paid_Amt - FI.Lien_Amount) > 0 AND CAST(SM.AdmissionDate AS DATE) < lfd.FromDate AND (lfd.Amount - ISNULL(lfc.Concession_Amount, 0)) > 0 AND FI.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (131, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q132 | Attendance not marked for which classes today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Attendance not marked for which classes today?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName FROM ClassMaster cm INNER JOIN StudentAcademicDetail sad ON cm.ID = sad.ClassID WHERE cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 GROUP BY cm.Name EXCEPT SELECT DISTINCT cm.Name FROM StudentAttendance sa INNER JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (132, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q133 | How many students are below average in Class 10? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students are below average in Class 10?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT smd.StudentID) AS BelowAvgStudents FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ClassMaster c ON smm.ClassID = c.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND c.Name = ''Class 10'' AND smd.Marks < (SELECT AVG(smd2.Marks) FROM StudentMarkDetails smd2 INNER JOIN StudentMarkMaster smm2 ON smd2.HeaderID = smm2.ID INNER JOIN ClassMaster c2 ON smm2.ClassID = c2.ID WHERE smd2.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd2.Deleted = 0 AND smm2.Deleted = 0 AND c2.Name = ''Class 10'');',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (133, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q134 | How many salary slips were generated this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many salary slips were generated this month?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS SlipsGenerated FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (134, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q135 | Standard deviation of marks class-wise ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Standard deviation of marks class-wise',
        @sql NVARCHAR(MAX) = N'SELECT c.Name AS ClassName, CAST(STDEV(smd.Marks) AS DECIMAL(5,2)) AS StdDevMarks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ClassMaster c ON smm.ClassID = c.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND c.IsDeleted = 0 GROUP BY c.Name ORDER BY c.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (135, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q136 | Hey, how many students are above 15 years old? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many students are above 15 years old?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS students_above_15 FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND DATEDIFF(YEAR, sm.StudentDob, GETDATE()) > 15 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (136, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q137 | Just checking - how many students are there in each class? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many students are there in each class?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS class_name, COUNT(*) AS total_students FROM StudentAcademicDetail sad JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY cm.Name ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (137, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q138 | Can you show me the school topper with marks? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show me the school topper with marks?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 smd.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName, SUM(smd.Marks) AS TotalMarks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN Student_Master stm ON smd.StudentID = stm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 GROUP BY smd.StudentID, stm.AdmissionNo, stm.FirstName, stm.LastName ORDER BY TotalMarks DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (138, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q139 | Give me the list of all collectors and how much they collected today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the list of all collectors and how much they collected today',
        @sql NVARCHAR(MAX) = N'SELECT fc.Collected_By_Name, COUNT(fc.Id) AS ReceiptCount, SUM(fc.Receipt_Amt) AS TotalCollected FROM FeesCollection fc WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fc.Collected_By_Name ORDER BY TotalCollected DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (139, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q140 | Average marks in Mathematics for all classes ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Average marks in Mathematics for all classes',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, CAST(AVG(pc.Marks) AS DECIMAL(5,2)) AS AvgMarks FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE pc.SubjectName = ''Maths'' AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) GROUP BY cm.Name ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (140, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q141 | How much was the collection on 15th January? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much was the collection on 15th January?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS collection FROM FeesCollection fc WHERE CAST(fc.Bill_Date AS DATE) = DATEFROMPARTS(CASE WHEN MONTH(GETDATE()) >= 4 THEN YEAR(GETDATE()) ELSE YEAR(GETDATE())-1 END + 1, 1, 15) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (141, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q142 | What are the most common reasons for leave applications? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What are the most common reasons for leave applications?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 lem.Purpose AS Reason, COUNT(*) AS Frequency FROM LeaveEntryMaster lem WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND lem.Purpose IS NOT NULL AND lem.Purpose != '''' GROUP BY lem.Purpose ORDER BY Frequency DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (142, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q143 | What is the recovery rate for bus fees vs non-bus fees? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the recovery rate for bus fees vs non-bus fees?',
        @sql NVARCHAR(MAX) = N'SELECT CASE WHEN f.IsBusFee = 1 THEN ''Bus Fee'' ELSE ''Non-Bus Fee'' END AS Category, ROUND(SUM(f.Paid_Amt) * 100.0 / NULLIF(SUM(f.Amount - ISNULL(f.Concession_Amt, 0)), 0), 2) AS RecoveryRate FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY CASE WHEN f.IsBusFee = 1 THEN ''Bus Fee'' ELSE ''Non-Bus Fee'' END;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (143, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q144 | So, what's the fee-wise outstanding for Term 1 in Class 6? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, what''s the fee-wise outstanding for Term 1 in Class 6?',
        @sql NVARCHAR(MAX) = N'SELECT Fees_Name, SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND ClassName = ''Class 6'' AND Term_Name IN (''Term 1'', ''I'') AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY Fees_Name ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (144, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q145 | Hey, how many VIP students do we have? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many VIP students do we have?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS vip_count FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.IsVIP = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (145, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q146 | Bottom 5 classes by attendance rate ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Bottom 5 classes by attendance rate',
        @sql NVARCHAR(MAX) = N'SELECT TOP 5 cm.Name AS ClassName, CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AttendancePercent FROM StudentAttendance sa INNER JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND MONTH(sa.Attendance_Date) = MONTH(GETDATE()) AND YEAR(sa.Attendance_Date) = YEAR(GETDATE()) GROUP BY cm.Name ORDER BY AttendancePercent ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (146, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q147 | What is the highest absentee count on a single day this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the highest absentee count on a single day this month?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 Attendance_Date, COUNT(*) AS AbsentCount FROM Staff_Attendance WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND MONTH(Attendance_Date) = MONTH(GETDATE()) AND YEAR(Attendance_Date) = YEAR(GETDATE()) AND Attendance_Status_ID = 2 GROUP BY Attendance_Date ORDER BY AbsentCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (147, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q148 | How many students need remedial classes based on marks below 35? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students need remedial classes based on marks below 35?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT StudentID) AS NeedRemedial FROM StudentMarkDetails smd INNER JOIN ExamConfigurationEvaluationDetails eced ON smd.EvalHierID = eced.ID INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND smd.Marks < eced.MinMark;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (148, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q149 | Top performers in Mathematics ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Top performers in Mathematics',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 smd.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName, smd.Marks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN Subject_Master s ON s.BranchID = smd.BranchID INNER JOIN Student_Master stm ON smd.StudentID = stm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND s.Name = ''Maths'' AND s.IsDeleted = 0 ORDER BY smd.Marks DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (149, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q150 | List all staff children with their class and section ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all staff children with their class and section',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, secm.Name AS SectionName, sm.FatherName FROM Student_Master sm JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id INNER JOIN SectionMaster secm ON sad.SectionID = secm.ID WHERE sm.StaffChild = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.ClassName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (150, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q151 | How many staff members were present this week? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many staff members were present this week?',
        @sql NVARCHAR(MAX) = N'SELECT sa.Attendance_Date, COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) AS Present, COUNT(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 END) AS Absent FROM Staff_Attendance sa WHERE sa.Attendance_Date >= DATEADD(DAY, 1-DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE)) AND sa.Attendance_Date <= CAST(GETDATE() AS DATE)  AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sa.Attendance_Date ORDER BY sa.Attendance_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (151, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q152 | Monthly attendance rate trend ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Monthly attendance rate trend',
        @sql NVARCHAR(MAX) = N'SELECT MONTH(sa.Attendance_Date) AS MonthNum, DATENAME(MONTH, sa.Attendance_Date) AS MonthName, CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AttendanceRate FROM StudentAttendance sa WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY MONTH(sa.Attendance_Date), DATENAME(MONTH, sa.Attendance_Date) ORDER BY MONTH(sa.Attendance_Date);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (152, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q153 | UPI collection this month for Iyyappanthangal branch ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'UPI collection this month for Iyyappanthangal branch',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fc.Receipt_Amt) AS UPICollection FROM FeesCollection fc WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.Collection_Mode_ID IN (SELECT ID FROM CollectionMode_Master WHERE Name = ''UPI'') AND DATEPART(MONTH, fc.Bill_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, fc.Bill_Date) = DATEPART(YEAR, GETDATE()) AND fc.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%Iyyappanthangal%'' OR ShortName LIKE ''%Iyyappanthangal%'')) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (153, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q154 | Enquiry count for the current year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Enquiry count for the current year',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalEnquiries FROM GeneralCallRegister WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (154, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q155 | What's the term-wise bus fee outstanding? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the term-wise bus fee outstanding?',
        @sql NVARCHAR(MAX) = N'SELECT Term_Name, SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS BusFeeOutstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND IsBusFee = 1 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY Term_Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (155, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q156 | Hey, how many students have been charged bus fees? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many students have been charged bus fees?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT Student_ID) AS BusFeeStudents FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND IsBusFee = 1 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (156, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q157 | Which students have the most feedback tickets? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which students have the most feedback tickets?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 sm.FirstName + '' '' + sm.LastName AS StudentName, ft.ContactName AS Parent_Name, COUNT(*) AS TicketCount FROM FeedbackTicket ft INNER JOIN Student_Master sm ON ft.StudentID = sm.ID WHERE ft.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ft.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND ft.StudentID IS NOT NULL GROUP BY sm.FirstName, sm.LastName, ft.ContactName ORDER BY TicketCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (157, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q158 | Just checking - how many people showed up today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many people showed up today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS PresentCount FROM Staff_Attendance WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND Attendance_Date = CAST(GETDATE() AS DATE) AND Attendance_Status_ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (158, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q159 | Which staff handled the most enquiries? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which staff handled the most enquiries?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT TOP 5 HandledBy_ID, COUNT(*) AS EnquiriesHandled FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL) GROUP BY HandledBy_ID ORDER BY EnquiriesHandled DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (159, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q160 | Which class has the most subjects? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which class has the most subjects?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 cm.Name AS ClassName, COUNT(DISTINCT cs.Subject_Id) AS SubjectCount FROM ClassSubjectDetails cs INNER JOIN ClassMaster cm ON cs.Class_Id = cm.ID WHERE cs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND cs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY cm.Name ORDER BY SubjectCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (160, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q161 | Show students with zero payment in Term 1. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show students with zero payment in Term 1.',
        @sql NVARCHAR(MAX) = N'SELECT f.Student_ID, s.FirstName + '' '' + ISNULL(s.LastName, '''') AS StudentName, f.ClassName, SUM(f.Amount) AS Term1Demand FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID INNER JOIN Student_Master s ON f.Student_ID = s.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.Term_Name IN (''Term 1'', ''I'') AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Student_ID, s.FirstName, s.LastName, f.ClassName HAVING SUM(f.Paid_Amt) = 0 AND SUM(f.Amount) > 0 ORDER BY Term1Demand DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (161, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q162 | Vehicles with expired insurance ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Vehicles with expired insurance',
        @sql NVARCHAR(MAX) = N'SELECT vm.Vehicle_Number, vm.Vehicle_Type_Name, vm.Insurance_Number, vm.Insurance_Expiry_Date FROM VehicleMaster vm WHERE vm.IsDeleted = 0 AND vm.Insurance_Expiry_Date < GETDATE() AND vm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND vm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY vm.Insurance_Expiry_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (162, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q163 | Show me all designations with their descriptions ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me all designations with their descriptions',
        @sql NVARCHAR(MAX) = N'SELECT Name AS Designation, Description FROM StaffDesignationMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0 ORDER BY Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (163, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q164 | Class 4 students whose fathers name starts with R ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class 4 students whose fathers name starts with R',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.FatherName FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.Name IN (''Class 4'', ''IV'') AND sm.FatherName LIKE ''R%'' AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (164, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q165 | Tell me about the staff present today count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Tell me about the staff present today count',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS PresentToday FROM Staff_Attendance WHERE Attendance_Date = CAST(GETDATE() AS DATE) AND Attendance_Status_ID = 1 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (165, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q166 | What is the total outstanding amount across all students? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total outstanding amount across all students?',
        @sql NVARCHAR(MAX) = N'SELECT SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS TotalOutstanding FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (166, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q167 | How many enquiries in the last 30 days? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many enquiries in the last 30 days?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS EnquiriesLast30Days FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND CallDate >= DATEADD(DAY, -30, GETDATE());',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (167, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q168 | What's today's staff attendance percentage? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s today''s staff attendance percentage?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(CASE WHEN Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS AttendancePercentage FROM Staff_Attendance WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND Attendance_Date = CAST(GETDATE() AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (168, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q169 | So, how many staff arrived late today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, how many staff arrived late today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS LateArrivals FROM Staff_Attendance WHERE Attendance_Date = CAST(GETDATE() AS DATE) AND InTime > ''09:00'' AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (169, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q170 | Lien amount held in the Korattur branch ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Lien amount held in the Korattur branch',
        @sql NVARCHAR(MAX) = N'SELECT SUM(ISNULL(fisd.Lien_Amount,0)) AS TotalLien FROM FeesInformationStudentDetail fisd WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND fisd.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%Korattur%'' OR ShortName LIKE ''%Korattur%'')) AND fisd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (170, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q171 | Pull up staff contact details for the administration department ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up staff contact details for the administration department',
        @sql NVARCHAR(MAX) = N'SELECT sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName, sm.Staff_ID FROM StaffDepartmentMapping sdm INNER JOIN StaffDepartmentMappingDetail sdmd ON sdm.Id = sdmd.MappingID INNER JOIN Staff_Master sm ON sdmd.StaffID = sm.Staff_ID AND sm.StaffStatus_ID = 1 INNER JOIN StaffDepartmentMaster dm ON sdm.DepartmentID = dm.Id WHERE dm.Name IN (''Admin'', ''Admin Team'') AND sdm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sdm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (sdm.IsDeleted = 0 OR sdm.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (171, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q172 | I need to see fee type-wise outstanding amounts ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see fee type-wise outstanding amounts',
        @sql NVARCHAR(MAX) = N'SELECT FeesType_Name, SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY FeesType_Name ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (172, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q173 | Show me the term-wise collection percentage. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me the term-wise collection percentage.',
        @sql NVARCHAR(MAX) = N'SELECT Term_Name, ROUND(SUM(Paid_Amt) * 100.0 / NULLIF(SUM(Amount), 0), 2) AS CollectionPercentage FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY Term_Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (173, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q174 | Show fee type-wise outstanding amounts. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show fee type-wise outstanding amounts.',
        @sql NVARCHAR(MAX) = N'SELECT FeesType_Name, SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY FeesType_Name ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (174, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q175 | How many staff are present today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many staff are present today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS PresentToday FROM Staff_Attendance WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND Attendance_Date = CAST(GETDATE() AS DATE) AND Attendance_Status_ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (175, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q176 | So, what's the average salary of staff? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, what''s the average salary of staff?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(AVG(gem.NetPay) AS DECIMAL(12,2)) AS AvgSalary FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (176, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q177 | Students whose admission number starts with 2025 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students whose admission number starts with 2025',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sm.AdmissionNo LIKE ''2025%'' AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) ORDER BY sm.AdmissionNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (177, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q178 | Show days with zero online collection. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show days with zero online collection.',
        @sql NVARCHAR(MAX) = N'WITH dc AS (SELECT dm.ID, dm.DayClosureDate AS ClosureDate, dm.CollectedByName AS ClosedBy_Name, SUM(dmd.CollectedAmount) AS TotalCollection, SUM(CASE WHEN cmm.Name = ''Cash'' THEN dmd.CollectedAmount ELSE 0 END) AS CashCollection, SUM(CASE WHEN cmm.Name = ''Bank Online Transfer'' THEN dmd.CollectedAmount ELSE 0 END) AS OnlineCollection, SUM(CASE WHEN cmm.Name NOT IN (''Cash'', ''Bank Online Transfer'', ''Cheque'') THEN dmd.CollectedAmount ELSE 0 END) AS OtherCollection, SUM(CASE WHEN cmm.Name = ''Cheque'' THEN dmd.CollectedAmount ELSE 0 END) AS ChequeCollection FROM DayclosureMaster dm INNER JOIN DayclosureMaster_Details dmd ON dmd.HeaderID = dm.ID LEFT JOIN CollectionMode_Master cmm ON dmd.CollectionMode_ID = cmm.ID WHERE dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (dm.IsDeleted = 0 OR dm.IsDeleted IS NULL) AND (dmd.IsDeleted = 0 OR dmd.IsDeleted IS NULL) GROUP BY dm.ID, dm.DayClosureDate, dm.CollectedByName) SELECT CAST(ClosureDate AS DATE) AS ClosureDay, TotalCollection, CashCollection FROM dc WHERE (OnlineCollection = 0 OR OnlineCollection IS NULL) ORDER BY ClosureDate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (178, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q179 | I need the rank list for Class 12 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need the rank list for Class 12',
        @sql NVARCHAR(MAX) = N'SELECT smd.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName, SUM(smd.Marks) AS TotalMarks, RANK() OVER (ORDER BY SUM(smd.Marks) DESC) AS Rank FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ClassMaster c ON smm.ClassID = c.ID INNER JOIN Student_Master stm ON smd.StudentID = stm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND c.Name = ''Class 12'' GROUP BY smd.StudentID, stm.AdmissionNo, stm.FirstName, stm.LastName ORDER BY Rank;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (179, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q180 | How many students are currently enrolled? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students are currently enrolled?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS enrolled_students FROM StudentAcademicDetail sad WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (180, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q181 | How many staff children are studying here? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many staff children are studying here?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS staff_children FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.StaffChild = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (181, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q182 | What is the total fee demand for the current academic year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total fee demand for the current academic year?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(f.Amount) AS TotalDemand FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (182, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q183 | How many students enrolled vs appeared in exams are there? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students enrolled vs appeared in exams are there?',
        @sql NVARCHAR(MAX) = N'SELECT (SELECT COUNT(*) FROM StudentAcademicDetail WHERE IsActive = 1 AND ClassID IN (SELECT ID FROM ClassMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0)) AS TotalEnrolled, (SELECT COUNT(DISTINCT smd.StudentID) FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0) AS AppearedInExams;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (183, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q184 | Give me the numbers for today's cash counter ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the numbers for today''s cash counter',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(fc.Id) AS TotalReceipts, SUM(fc.Receipt_Amt) AS TotalAmount FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (184, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q185 | Receipts issued day before yesterday ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Receipts issued day before yesterday',
        @sql NVARCHAR(MAX) = N'SELECT fc.Bill_No, fc.Admission_No, fc.Receipt_Amt, fc.Collected_By_Name, cmm.Name FROM FeesCollection fc LEFT JOIN CollectionMode_Master cmm ON fc.Collection_Mode_ID = cmm.ID WHERE CAST(fc.Bill_Date AS DATE) = CAST(DATEADD(DAY, -2, GETDATE()) AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY fc.Bill_No;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (185, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q186 | Fee collection in the last 3 months ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Fee collection in the last 3 months',
        @sql NVARCHAR(MAX) = N'SELECT FORMAT(fc.Bill_Date, ''yyyy-MM'') AS CollectionMonth, SUM(fc.Receipt_Amt) AS TotalCollection FROM FeesCollection fc WHERE fc.Bill_Date >= DATEADD(MONTH, -3, GETDATE()) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY FORMAT(fc.Bill_Date, ''yyyy-MM'') ORDER BY CollectionMonth;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (186, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q187 | How much was refunded this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much was refunded this month?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(Refund_Amt), 0) AS ThisMonthRefund FROM RefundReceipt WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND MONTH(Bill_Date) = MONTH(GETDATE()) AND YEAR(Bill_Date) = YEAR(GETDATE());',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (187, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q188 | Who is frequently late among staff? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who is frequently late among staff?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 sa.Staff_ID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName, COUNT(*) AS LateDays FROM Staff_Attendance sa INNER JOIN Staff_Master sm ON sa.Staff_ID = sm.Staff_ID AND sm.StaffStatus_ID = 1 WHERE sa.InTime > ''09:00'' AND MONTH(sa.Attendance_Date) = MONTH(GETDATE()) AND YEAR(sa.Attendance_Date) = YEAR(GETDATE()) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sa.Staff_ID, sm.Staff_FirstName, sm.Staff_LastName ORDER BY LateDays DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (188, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q189 | What's the total collection amount this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the total collection amount this year?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS TotalCollection FROM FeesCollection fc WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (189, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q190 | Show chronic absentees - students absent more than 10 days this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show chronic absentees - students absent more than 10 days this month',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, sm.AdmissionNo, cm.Name AS class_name, sm.FatherContactNo, COUNT(*) AS days_absent FROM StudentAttendance sa JOIN Student_Master sm ON sa.Student_ID = sm.ID JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE sa.Attendance_Status_ID = 2 AND DATEPART(MONTH, sa.Attendance_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, sa.Attendance_Date) = DATEPART(YEAR, GETDATE()) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo, cm.Name, sm.FatherContactNo HAVING COUNT(*) > 10 ORDER BY COUNT(*) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (190, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q191 | Day-wise staff attendance trend this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Day-wise staff attendance trend this month',
        @sql NVARCHAR(MAX) = N'SELECT sa.Attendance_Date, COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) AS Present, COUNT(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 END) AS Absent, CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS PresentPercent FROM Staff_Attendance sa WHERE MONTH(sa.Attendance_Date) = MONTH(GETDATE()) AND YEAR(sa.Attendance_Date) = YEAR(GETDATE())  AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sa.Attendance_Date ORDER BY sa.Attendance_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (191, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q192 | Pull up the loss rate by enquiry source ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up the loss rate by enquiry source',
        @sql NVARCHAR(MAX) = N'DECLARE @StatusLost bigint = (SELECT TOP 1 ID FROM Enquiry_Status_Master WHERE Name = ''Dropped'');
WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT emm.Name AS Source, ROUND(SUM(CASE WHEN CallStatus_ID = @StatusLost THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0), 2) AS LossRate FROM GeneralCallRegister em INNER JOIN Enquiry_Mode_Master emm ON em.Mode_ID = emm.ID WHERE em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND em.IsDeleted = 0 GROUP BY emm.Name ORDER BY LossRate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (192, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q193 | Today's collection for T Nagar ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Today''s collection for T Nagar',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fc.Receipt_Amt) AS Collection FROM FeesCollection fc WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND fc.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%T Nagar%'' OR ShortName LIKE ''%T Nagar%'')) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (193, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q194 | Show me admissions in the last 30 days ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me admissions in the last 30 days',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sm.AdmissionDate, sad.ClassName FROM Student_Master sm JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sm.AdmissionDate >= DATEADD(DAY, -30, GETDATE()) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sm.AdmissionDate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (194, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q195 | House-wise distribution of new admissions ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'House-wise distribution of new admissions',
        @sql NVARCHAR(MAX) = N'SELECT sad.HouseName, COUNT(DISTINCT sad.StudentID) AS NewAdmissions FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNewAdmission = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.HouseName IS NOT NULL AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sad.HouseName ORDER BY NewAdmissions DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (195, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q196 | Show concession details with student names and remarks ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show concession details with student names and remarks',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName + '' '' + sm.LastName AS StudentName, cm.Concession_Amount, cm.Remarks FROM Concession_Master cm INNER JOIN Student_Master sm ON cm.Student_ID = sm.ID WHERE cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (cm.IsDeleted IS NULL OR cm.IsDeleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (196, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q197 | How many staff are absent today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many staff are absent today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS AbsentToday FROM Staff_Attendance WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND Attendance_Date = CAST(GETDATE() AS DATE) AND Attendance_Status_ID = 2;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (197, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q198 | Can you show conversion rate month-wise? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show conversion rate month-wise?',
        @sql NVARCHAR(MAX) = N'DECLARE @StatusConverted bigint = (SELECT TOP 1 ID FROM Enquiry_Status_Master WHERE Name = ''Completed'');
WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT MONTH(CallDate) AS EnquiryMonth, DATENAME(MONTH, CallDate) AS MonthName, COUNT(*) AS TotalEnquiries, COUNT(CASE WHEN CallStatus_ID = @StatusConverted THEN 1 END) AS Converted, CAST(COUNT(CASE WHEN CallStatus_ID = @StatusConverted THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS ConversionRate FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL) GROUP BY MONTH(CallDate), DATENAME(MONTH, CallDate) ORDER BY MONTH(CallDate);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (198, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q199 | Can you show refund summary by quarter? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show refund summary by quarter?',
        @sql NVARCHAR(MAX) = N'SELECT DATEPART(QUARTER, Bill_Date) AS Quarter, COUNT(*) AS RefundCount, SUM(Refund_Amt) AS TotalRefund FROM RefundReceipt WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY DATEPART(QUARTER, Bill_Date) ORDER BY Quarter;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (199, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q200 | How many fees received from new admissions are there? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many fees received from new admissions are there?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS new_admission_collection FROM FeesCollection fc JOIN StudentAcademicDetail sad ON fc.Student_ID = sad.StudentID AND fc.AcademicYearID = sad.AcademicYearID WHERE sad.IsNewAdmission = 1 AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
PRINT 'checkpoint: reached Q200';
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (200, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q201 | I need students who have already received their transfer certificate ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need students who have already received their transfer certificate',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS StudentsWithTC FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.IsTCIssued = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (201, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q202 | Compare Term 1 and Term 2 results ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare Term 1 and Term 2 results',
        @sql NVARCHAR(MAX) = N'SELECT etm.Name AS Term, CAST(AVG(smd.Marks) AS DECIMAL(5,2)) AS AvgMarks, CAST(SUM(CASE WHEN smd.Marks >= eced.MinMark THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS PassPct FROM StudentMarkDetails smd INNER JOIN ExamConfigurationEvaluationDetails eced ON smd.EvalHierID = eced.ID INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ExamTypeMaster et ON smm.ExamTypeID = et.ID INNER JOIN ExamTermMaster etm ON et.TermID = etm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND et.IsDeleted = 0 AND etm.Deleted = 0 GROUP BY etm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (202, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q203 | Just checking - how many students have hostel fees assigned? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many students have hostel fees assigned?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT Student_ID) AS HostelFeeStudents FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND IsHostelFee = 1 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (203, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q204 | VIP students who are also staff children ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'VIP students who are also staff children',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, sm.FatherName FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sm.IsVIP = 1 AND sm.StaffChild = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (204, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q205 | Hey, how many receipts issued today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many receipts issued today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS ReceiptsIssued FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (205, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q206 | Give me the week-wise admission count for this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the week-wise admission count for this year',
        @sql NVARCHAR(MAX) = N'SELECT DATEPART(WEEK, sm.AdmissionDate) AS WeekNo, MIN(sm.AdmissionDate) AS WeekStart, COUNT(DISTINCT sad.StudentID) AS Admissions FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNewAdmission = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY DATEPART(WEEK, sm.AdmissionDate) ORDER BY WeekNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (206, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q207 | Show me month-by-month fee collection comparison for 2024-25 vs 2025-26 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me month-by-month fee collection comparison for 2024-25 vs 2025-26',
        @sql NVARCHAR(MAX) = N'SELECT MONTH(fc.Bill_Date) AS MonthNo, DATENAME(MONTH, fc.Bill_Date) AS MonthName, SUM(CASE WHEN yr.IsLastYear = 1 THEN fc.Receipt_Amt ELSE 0 END) AS Collection_LastYear, SUM(CASE WHEN GETDATE() BETWEEN bad.Start_Date AND bad.End_Date THEN fc.Receipt_Amt ELSE 0 END) AS Collection_ThisYear FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id OUTER APPLY (SELECT CASE WHEN bad.Id = (SELECT PreviousYearID FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = bad.Branch_Id) THEN 1 ELSE 0 END AS IsLastYear) yr WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND (GETDATE() BETWEEN bad.Start_Date AND bad.End_Date OR yr.IsLastYear = 1) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY MONTH(fc.Bill_Date), DATENAME(MONTH, fc.Bill_Date) ORDER BY MonthNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (207, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q208 | Sections with highest fail rates ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Sections with highest fail rates',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, secm.Name AS SectionName, CAST(SUM(CASE WHEN smd.Marks < eced.MinMark THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS FailRate FROM StudentMarkDetails smd INNER JOIN ExamConfigurationEvaluationDetails eced ON smd.EvalHierID = eced.ID INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ClassMaster cm ON smm.ClassID = cm.ID INNER JOIN SectionMaster secm ON smm.SectionID = secm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 GROUP BY cm.Name, secm.Name ORDER BY FailRate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (208, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q209 | Who teaches maths in 9B? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who teaches maths in 9B?',
        @sql NVARCHAR(MAX) = N'SELECT sm.Staff_FirstName + '' '' + ISNULL(sm.Staff_LastName, '''') AS TeacherName FROM SubjectAllocation_Master sam INNER JOIN Staff_Master sm ON sam.Staff_ID = sm.Staff_ID INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID INNER JOIN SectionMaster secm ON sam.Section_ID = secm.ID INNER JOIN Subject_Master sub ON sam.Subject_ID = sub.Id WHERE cm.Name IN (''Class 9'', ''IX'') AND secm.Name = ''B'' AND sub.Name = ''Mathematics'' AND sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (sam.IsDeleted = 0 OR sam.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (209, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q210 | Any class with full attendance today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Any class with full attendance today?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName FROM ClassMaster cm WHERE cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND cm.IsDeleted = 0 AND cm.ID NOT IN (SELECT DISTINCT sa.Class_ID FROM StudentAttendance sa WHERE sa.Attendance_Date = CAST(GETDATE() AS DATE) AND sa.Attendance_Status_ID = 2 AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (210, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q211 | Staff type wise salary total ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff type wise salary total',
        @sql NVARCHAR(MAX) = N'SELECT gm.StaffTypeName, SUM(gem.NetPay) AS TotalSalary, COUNT(gem.ID) AS StaffCount FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) GROUP BY gm.StaffTypeName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (211, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q212 | What's the class-wise pending fee amount? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the class-wise pending fee amount?',
        @sql NVARCHAR(MAX) = N'SELECT f.ClassName, SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS Outstanding FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY f.ClassName ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (212, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q213 | How many staff marked attendance today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many staff marked attendance today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalMarked FROM Staff_Attendance WHERE Attendance_Date = CAST(GETDATE() AS DATE) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (213, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q214 | Hostel students in Class 9 and above ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hostel students in Class 9 and above',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.HostelRequired = 1 AND cm.Name IN (''Class 9'', ''Class 10'', ''Class 11'', ''Class 12'') AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (214, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q215 | Can you show the enquiry trend alongside conversion count by month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show the enquiry trend alongside conversion count by month?',
        @sql NVARCHAR(MAX) = N'DECLARE @StatusConverted bigint = (SELECT TOP 1 ID FROM Enquiry_Status_Master WHERE Name = ''Completed'');
DECLARE @StatusLost bigint = (SELECT TOP 1 ID FROM Enquiry_Status_Master WHERE Name = ''Dropped'');
WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT FORMAT(CallDate, ''yyyy-MM'') AS Month, COUNT(*) AS TotalEnquiries, SUM(CASE WHEN CallStatus_ID = @StatusConverted THEN 1 ELSE 0 END) AS Converted, SUM(CASE WHEN CallStatus_ID = @StatusLost THEN 1 ELSE 0 END) AS Lost FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0 GROUP BY FORMAT(CallDate, ''yyyy-MM'') ORDER BY Month;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (215, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q216 | What is the fee collection per active student? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the fee collection per active student?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(SUM(fc.Receipt_Amt) * 1.0 / NULLIF(COUNT(DISTINCT fc.Student_ID), 0), 2) AS AvgCollectionPerStudent FROM FeesCollection fc WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (216, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q217 | Show staff leave summary with total days taken per person. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show staff leave summary with total days taken per person.',
        @sql NVARCHAR(MAX) = N'SELECT lem.Staff_Name AS StaffName, COUNT(*) AS LeaveApplications, SUM(lem.NoOfDays) AS TotalDays, SUM(CASE WHEN ls.Name = ''Pending'' THEN 1 ELSE 0 END) AS Pending, SUM(CASE WHEN ls.Name = ''Approved'' THEN 1 ELSE 0 END) AS Approved FROM LeaveEntryMaster lem INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) GROUP BY lem.Staff_Name ORDER BY TotalDays DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (217, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q218 | Can you show religion-wise student count? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show religion-wise student count?',
        @sql NVARCHAR(MAX) = N'SELECT sm.Religion_Name, COUNT(*) AS student_count FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY sm.Religion_Name ORDER BY COUNT(*) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (218, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q219 | Show the SLA breach - tickets open for more than 14 days. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the SLA breach - tickets open for more than 14 days.',
        @sql NVARCHAR(MAX) = N'SELECT ft.TicketNo, ft.Subject, ft.ContactName AS Parent_Name, ft.Created_Date AS CreatedDate, DATEDIFF(DAY, ft.Created_Date, GETDATE()) AS DaysOpen, esc.IsEscalated FROM FeedbackTicket ft OUTER APPLY (SELECT MAX(ftr.RepliedOn) AS LastReplyDate FROM FeedbackTicketReplies ftr WHERE ftr.TicketID = ft.Id) rp OUTER APPLY (SELECT CASE WHEN EXISTS (SELECT 1 FROM FeedbackEscalationMatrix fem WHERE fem.FeedbackCategoryID = ft.CategoryID AND DATEDIFF(HOUR, ft.Created_Date, ISNULL(rp.LastReplyDate, GETDATE())) > fem.EscalationHours) THEN 1 ELSE 0 END AS IsEscalated) esc WHERE ft.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ft.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND ft.Status IN (''Open'', ''In Progress'', ''Reopened'') AND DATEDIFF(DAY, ft.Created_Date, GETDATE()) > 14 ORDER BY DaysOpen DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (219, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q220 | Give me a summary of enquiry statuses for this year. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me a summary of enquiry statuses for this year.',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT esm.Name AS Status, COUNT(*) AS TotalCount FROM GeneralCallRegister em INNER JOIN Enquiry_Status_Master esm ON em.CallStatus_ID = esm.ID WHERE em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND (em.IsDeleted = 0 OR em.IsDeleted IS NULL) GROUP BY esm.Name ORDER BY esm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (220, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q221 | Who performed yesterday's day closure? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who performed yesterday''s day closure?',
        @sql NVARCHAR(MAX) = N'WITH dc AS (SELECT dm.ID, dm.DayClosureDate AS ClosureDate, dm.CollectedByName AS ClosedBy_Name, SUM(dmd.CollectedAmount) AS TotalCollection, SUM(CASE WHEN cmm.Name = ''Cash'' THEN dmd.CollectedAmount ELSE 0 END) AS CashCollection, SUM(CASE WHEN cmm.Name = ''Bank Online Transfer'' THEN dmd.CollectedAmount ELSE 0 END) AS OnlineCollection, SUM(CASE WHEN cmm.Name NOT IN (''Cash'', ''Bank Online Transfer'', ''Cheque'') THEN dmd.CollectedAmount ELSE 0 END) AS OtherCollection, SUM(CASE WHEN cmm.Name = ''Cheque'' THEN dmd.CollectedAmount ELSE 0 END) AS ChequeCollection FROM DayclosureMaster dm INNER JOIN DayclosureMaster_Details dmd ON dmd.HeaderID = dm.ID LEFT JOIN CollectionMode_Master cmm ON dmd.CollectionMode_ID = cmm.ID WHERE dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (dm.IsDeleted = 0 OR dm.IsDeleted IS NULL) AND (dmd.IsDeleted = 0 OR dmd.IsDeleted IS NULL) GROUP BY dm.ID, dm.DayClosureDate, dm.CollectedByName) SELECT ClosedBy_Name, ClosureDate, TotalCollection FROM dc WHERE CAST(ClosureDate AS DATE) = CAST(DATEADD(DAY, -1, GETDATE()) AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (221, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q222 | I need to see class-wise attendance for today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see class-wise attendance for today',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS class_name, SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS present, SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END) AS absent, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS pct FROM StudentAttendance sa JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (222, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q223 | Who are the consistent toppers across all exams in Class 10? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who are the consistent toppers across all exams in Class 10?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 5 pc.StudentName AS StudentName, CAST(AVG(pc.Marks) AS DECIMAL(5,2)) AS OverallAvg, COUNT(DISTINCT pc.ExamTypeID) AS ExamsAppeared FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE cm.Name IN (''Class 10'', ''X'') AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) GROUP BY pc.StudentName ORDER BY OverallAvg DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (223, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q224 | Pull up the quickest resolved tickets ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up the quickest resolved tickets',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 ft.TicketNo, ft.Subject, ft.Created_Date AS CreatedDate, rp.LastReplyDate AS ResolvedDate, DATEDIFF(HOUR, ft.Created_Date, rp.LastReplyDate) AS HoursToResolve FROM FeedbackTicket ft OUTER APPLY (SELECT MAX(ftr.RepliedOn) AS LastReplyDate FROM FeedbackTicketReplies ftr WHERE ftr.TicketID = ft.Id) rp WHERE ft.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ft.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND ft.Status = ''Closed'' AND rp.LastReplyDate IS NOT NULL ORDER BY HoursToResolve ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (224, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q225 | Can you list out all fee heads with their amounts for Class 8? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you list out all fee heads with their amounts for Class 8?',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT fcd.Fees_Head_ID, fcd.FeesType_Name, fcd.FeesCategory_Name, fcd.Fees_Amount FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN ClassMaster cm ON fc.Class_ID = cm.ID WHERE cm.Name IN (''Class 8'', ''VIII'') AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY fcd.FeesType_Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (225, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q226 | What is the total lien amount this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total lien amount this year?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(Lien_Amount) AS TotalLienAmount FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (226, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q227 | Can you show today's collection bill number wise? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show today''s collection bill number wise?',
        @sql NVARCHAR(MAX) = N'SELECT fc.Bill_No, fc.Admission_No, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, fc.Receipt_Amt, cmm.Name FROM FeesCollection fc JOIN Student_Master sm ON fc.Student_ID = sm.ID LEFT JOIN CollectionMode_Master cmm ON fc.Collection_Mode_ID = cmm.ID WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY fc.Bill_No;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (227, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q228 | Show class-wise application distribution. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show class-wise application distribution.',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassApplied, COUNT(*) AS Applications FROM ApplicationEntry ae INNER JOIN ClassMaster cm ON ae.Student_ClassID = cm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) GROUP BY cm.Name ORDER BY Applications DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (228, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q229 | Pull up age-wise distribution of students real quick ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up age-wise distribution of students real quick',
        @sql NVARCHAR(MAX) = N'SELECT DATEDIFF(YEAR, sm.StudentDob, GETDATE()) AS age, COUNT(*) AS student_count FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.StudentDob IS NOT NULL AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY DATEDIFF(YEAR, sm.StudentDob, GETDATE()) ORDER BY age;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (229, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q230 | Just checking - how many online enquiries did we get? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many online enquiries did we get?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS OnlineEnquiries FROM GeneralCallRegister em INNER JOIN Enquiry_Mode_Master emm ON em.Mode_ID = emm.ID WHERE em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND (em.IsDeleted = 0 OR em.IsDeleted IS NULL) AND emm.Name = ''Online'';',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (230, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q231 | Show all new admissions this year with complete information ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show all new admissions this year with complete information',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sm.AdmissionDate, sm.Gender, sm.StudentDob, sad.ClassName, sad.RollNo, sm.FatherName, sm.FatherContactNo, sm.MotherName FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.IsNewAdmission = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sm.AdmissionDate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (231, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q232 | So, what's the average fee per student by class? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, what''s the average fee per student by class?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(DISTINCT fc.Student_ID) AS PayingStudents, SUM(fc.Receipt_Amt) AS TotalCollection, CAST(SUM(fc.Receipt_Amt) / NULLIF(COUNT(DISTINCT fc.Student_ID), 0) AS DECIMAL(10,2)) AS AvgFeePerStudent FROM FeesCollection fc JOIN ClassMaster cm ON fc.Class_ID = cm.ID JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name, cm.DisplayOrder ORDER BY cm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (232, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q233 | List the subjects taught in Class 10 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List the subjects taught in Class 10',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT pc.SubjectName FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE cm.Name IN (''Class 10'', ''X'') AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) ORDER BY pc.SubjectName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (233, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q234 | Can I see the vIP students performance? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can I see the vIP students performance?',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID AS StudentID, sm.FirstName, sm.LastName, CAST(AVG(smd.Marks) AS DECIMAL(5,2)) AS AvgMarks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN Student_Master sm ON smd.StudentID = sm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND sm.IsVIP = 1 GROUP BY sm.ID, sm.FirstName, sm.LastName ORDER BY AvgMarks DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (234, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q235 | Compare absentees today across all branches ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare absentees today across all branches',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, COUNT(*) AS Absentees FROM StudentAttendance sa JOIN BranchMaster bm ON sa.BranchID = bm.ID WHERE sa.Attendance_Status_ID = 2 AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY Absentees DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (235, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q236 | Lumpsum students as percentage of total ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Lumpsum students as percentage of total',
        @sql NVARCHAR(MAX) = N'SELECT CAST(COUNT(CASE WHEN sad.IsLumpsumApplicable = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS LumpsumPercent FROM StudentAcademicDetail sad WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (236, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q237 | Show teachers who teach more than 3 different subjects. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show teachers who teach more than 3 different subjects.',
        @sql NVARCHAR(MAX) = N'SELECT sm.Staff_FirstName + '' '' + sm.Staff_LastName AS TeacherName, COUNT(DISTINCT sam.Subject_ID) AS SubjectCount FROM SubjectAllocation_Master sam INNER JOIN Staff_Master sm ON sam.Staff_ID = sm.Staff_ID WHERE sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (sam.IsDeleted = 0 OR sam.IsDeleted IS NULL) GROUP BY sm.Staff_FirstName, sm.Staff_LastName HAVING COUNT(DISTINCT sam.Subject_ID) > 3 ORDER BY SubjectCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (237, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q238 | List all drivers with their experience. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all drivers with their experience.',
        @sql NVARCHAR(MAX) = N'SELECT Name, Mobile, License_Number, Experience FROM DriverMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) ORDER BY Experience DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (238, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q239 | I need to see the enquiry to admission funnel - enquiries vs converted vs active students ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see the enquiry to admission funnel - enquiries vs converted vs active students',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT (SELECT COUNT(*) FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0) AS TotalEnquiries, (SELECT COUNT(*) FROM GeneralCallRegister WHERE CallStatus_ID IN (SELECT ID FROM Enquiry_Status_Master WHERE Name = ''Completed'') AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0) AS ConvertedEnquiries, (SELECT COUNT(*) FROM StudentAcademicDetail WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND IsActive = 1 AND IsTCIssued = 0) AS ActiveStudents;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (239, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q240 | Monthly admission count for this academic year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Monthly admission count for this academic year',
        @sql NVARCHAR(MAX) = N'SELECT MONTH(sm.AdmissionDate) AS MonthNum, DATENAME(MONTH, sm.AdmissionDate) AS MonthName, COUNT(*) AS Admissions FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsNewAdmission = 1 AND sad.IsActive = 1 GROUP BY MONTH(sm.AdmissionDate), DATENAME(MONTH, sm.AdmissionDate) ORDER BY MONTH(sm.AdmissionDate);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (240, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q241 | Female students in hostel who have 100% attendance this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Female students in hostel who have 100% attendance this month',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sad.ClassName, sad.RollNo FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sm.Gender IN (''Female'', ''Girl'') AND sad.HostelRequired = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND NOT EXISTS (SELECT 1 FROM StudentAttendance sa WHERE sa.Student_ID = sm.ID AND sa.Attendance_Status_ID = 2 AND MONTH(sa.Attendance_Date) = MONTH(GETDATE()) AND YEAR(sa.Attendance_Date) = YEAR(GETDATE()) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND EXISTS (SELECT 1 FROM StudentAttendance sa WHERE sa.Student_ID = sm.ID AND MONTH(sa.Attendance_Date) = MONTH(GETDATE()) AND YEAR(sa.Attendance_Date) = YEAR(GETDATE()) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (241, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q242 | Which class contributes maximum to total collection? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which class contributes maximum to total collection?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 cm.Name AS ClassName, SUM(fc.Receipt_Amt) AS ClassCollection, CAST(SUM(fc.Receipt_Amt) * 100.0 / (SELECT SUM(Receipt_Amt) FROM FeesCollection WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted IS NULL OR IsDeleted = 0) AND ChequeStatus_ID NOT IN (3, 4)) AS DECIMAL(5,2)) AS ContributionPercent FROM FeesCollection fc INNER JOIN ClassMaster cm ON fc.Class_ID = cm.ID WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY cm.Name ORDER BY SUM(fc.Receipt_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (242, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q243 | How many TCs were issued this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many TCs were issued this month?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TCIssuedCount FROM StudentAcademicDetail sad WHERE MONTH(sad.TCIssuedDate) = MONTH(GETDATE()) AND YEAR(sad.TCIssuedDate) = YEAR(GETDATE()) AND sad.IsTCIssued = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (243, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q244 | Show me the top 5 classes by enquiry count. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me the top 5 classes by enquiry count.',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT TOP 5 cm.Name AS ClassName, COUNT(*) AS EnquiryCount FROM GeneralCallRegister em INNER JOIN ClassMaster cm ON em.Class_ID = cm.ID WHERE em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND em.IsDeleted = 0 GROUP BY cm.Name ORDER BY EnquiryCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (244, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q245 | Compare salary expenses between this year and last year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare salary expenses between this year and last year',
        @sql NVARCHAR(MAX) = N'SELECT ''Current Year'' AS Period, ISNULL(SUM(gem.NetPay), 0) AS TotalSalary FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) UNION ALL SELECT ''Previous Year'' AS Period, ISNULL(SUM(gem.NetPay), 0) AS TotalSalary FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.AcademicYearID IN (SELECT PreviousYearID FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (245, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q246 | Students with outstanding fees who are also marked as staff children ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students with outstanding fees who are also marked as staff children',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName + '' '' + sm.LastName AS StudentName, SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN Student_Master sm ON f.Student_ID = sm.ID WHERE sm.StaffChild = 1 AND f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.FirstName, sm.LastName HAVING SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) > 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (246, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q247 | Transport compliance report - expired documents. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Transport compliance report - expired documents.',
        @sql NVARCHAR(MAX) = N'SELECT ''Driver License'' AS DocumentType, Name AS Entity, License_Expiry_Date AS ExpiryDate FROM DriverMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND License_Expiry_Date < GETDATE() UNION ALL SELECT ''Vehicle Insurance'', Vehicle_Number, Insurance_Expiry_Date FROM VehicleMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND Insurance_Expiry_Date < GETDATE() UNION ALL SELECT ''Vehicle FC'', Vehicle_Number, FC_Date FROM VehicleMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND FC_Date < GETDATE();',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (247, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q248 | How many single-day leaves vs multi-day leaves were taken? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many single-day leaves vs multi-day leaves were taken?',
        @sql NVARCHAR(MAX) = N'SELECT CASE WHEN lem.NoOfDays = 1 THEN ''Single Day'' ELSE ''Multi Day'' END AS LeaveDurationType, COUNT(*) AS [Count] FROM LeaveEntryMaster lem INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND ls.Name = ''Approved'' GROUP BY CASE WHEN lem.NoOfDays = 1 THEN ''Single Day'' ELSE ''Multi Day'' END;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (248, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q249 | Can I see the collection on 15th June? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can I see the collection on 15th June?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fc.Receipt_Amt) AS CollectionAmount, COUNT(fc.Id) AS Receipts FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND CAST(fc.Bill_Date AS DATE) = DATEFROMPARTS(CASE WHEN MONTH(GETDATE()) >= 4 THEN YEAR(GETDATE()) ELSE YEAR(GETDATE())-1 END + 0, 6, 15) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (249, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q250 | Students who availed lumpsum fee and are also in hostel ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students who availed lumpsum fee and are also in hostel',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, sad.Lumpsum_Amount FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.IsLumpsumApplicable = 1 AND sad.HostelRequired = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (250, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q251 | How many enquiries have been converted to admissions? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many enquiries have been converted to admissions?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS ConvertedEnquiries FROM GeneralCallRegister WHERE CallStatus_ID IN (SELECT ID FROM Enquiry_Status_Master WHERE Name = ''Completed'') AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (251, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q252 | What is the class-wise outstanding for annual fees? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the class-wise outstanding for annual fees?',
        @sql NVARCHAR(MAX) = N'SELECT ClassName, SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND Term_Name = ''Annual'' AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY ClassName ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (252, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q253 | How many subjects does each class have exams in? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many subjects does each class have exams in?',
        @sql NVARCHAR(MAX) = N'SELECT ClassID, COUNT(DISTINCT SubjectID) AS SubjectCount FROM ProgressCardDataRetrieval pc WHERE pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY ClassID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (253, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q254 | Show daily application count for this month. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show daily application count for this month.',
        @sql NVARCHAR(MAX) = N'SELECT CAST(ApplicationDate AS DATE) AS AppDate, COUNT(*) AS Applications FROM ApplicationEntry WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND MONTH(ApplicationDate) = MONTH(GETDATE()) AND YEAR(ApplicationDate) = YEAR(GETDATE()) AND (IsDeleted = 0 OR IsDeleted IS NULL) GROUP BY CAST(ApplicationDate AS DATE) ORDER BY AppDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (254, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q255 | Average leaves per staff this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Average leaves per staff this year',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(lem.NoOfDays) * 1.0 / NULLIF(COUNT(DISTINCT lem.Staff_ID), 0) AS DECIMAL(5,2)) AS AvgLeavesPerStaff FROM LeaveEntryMaster lem INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE ls.Name = ''Approved'' AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (255, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q256 | Show fee collection broken down by branch for this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show fee collection broken down by branch for this month',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS BranchName, ISNULL(SUM(fc.Receipt_Amt), 0) AS MonthlyCollection FROM FeesCollection fc JOIN BranchMaster bm ON fc.BranchID = bm.ID WHERE MONTH(fc.Bill_Date) = MONTH(GETDATE()) AND YEAR(fc.Bill_Date) = YEAR(GETDATE()) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY MonthlyCollection DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (256, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q257 | Staff children fee status ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff children fee status',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName, ISNULL(SUM(fcd.Paid_Amt), 0) AS TotalPaid, ISNULL(SUM(fcd.Remaining_Amt), 0) AS TotalPending FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID LEFT JOIN FeesCollection fc ON sm.ID = fc.Student_ID AND fc.AcademicYearID = sad.AcademicYearID AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) LEFT JOIN FeesCollection_Details fcd ON fc.Id = fcd.Fees_Collection_ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sm.StaffChild = 1 AND sad.IsActive = 1 GROUP BY sm.AdmissionNo, sm.FirstName, sm.MiddleName, sm.LastName, cm.Name ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (257, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q258 | Top 5 students in Class 10 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Top 5 students in Class 10',
        @sql NVARCHAR(MAX) = N'SELECT TOP 5 smd.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName, SUM(smd.Marks) AS TotalMarks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ClassMaster c ON smm.ClassID = c.ID INNER JOIN Student_Master stm ON smd.StudentID = stm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND c.Name = ''Class 10'' GROUP BY smd.StudentID, stm.AdmissionNo, stm.FirstName, stm.LastName ORDER BY TotalMarks DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (258, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q259 | List of absentees for today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List of absentees for today',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName FROM StudentAttendance sa INNER JOIN Student_Master sm ON sa.Student_ID = sm.ID INNER JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE sa.Attendance_Status_ID = 2 AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY cm.Name, sm.FirstName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (259, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q260 | Hey, what's the retention rate year on year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the retention rate year on year?',
        @sql NVARCHAR(MAX) = N'SELECT bad.Name AS AcademicYear, COUNT(DISTINCT CASE WHEN sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) THEN sad.StudentID END) AS ActiveStudents, COUNT(DISTINCT CASE WHEN sad.IsTCIssued = 1 THEN sad.StudentID END) AS LeftStudents, CAST(COUNT(DISTINCT CASE WHEN sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) THEN sad.StudentID END) * 100.0 / NULLIF(COUNT(DISTINCT sad.StudentID), 0) AS DECIMAL(5,2)) AS RetentionRate FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id INNER JOIN Student_Master stm ON sad.StudentID = stm.ID WHERE bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bad.Name ORDER BY bad.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (260, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q261 | Students with high marks who also require transport ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students with high marks who also require transport',
        @sql NVARCHAR(MAX) = N'SELECT smd.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName, SUM(smd.Marks) AS TotalMarks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN StudentAcademicDetail sad ON smd.StudentID = sad.StudentID INNER JOIN Student_Master stm ON smd.StudentID = stm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND sad.TransportRequired = 1 AND sad.IsActive = 1 GROUP BY smd.StudentID, stm.AdmissionNo, stm.FirstName, stm.LastName HAVING SUM(smd.Marks) > 400 ORDER BY TotalMarks DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (261, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q262 | Top 10 students with highest concession who are not staff children ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Top 10 students with highest concession who are not staff children',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, SUM(fcd.Concession_Amount) AS TotalConcession FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN FeesCollection fc ON sm.ID = fc.Student_ID INNER JOIN FeesCollection_Details fcd ON fc.Id = fcd.Fees_Collection_ID WHERE (sm.StaffChild = 0 OR sm.StaffChild IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.ID, sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo, sad.ClassName HAVING SUM(fcd.Concession_Amount) > 0 ORDER BY TotalConcession DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (262, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q263 | Show me drivers whose licenses expire in 2026. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me drivers whose licenses expire in 2026.',
        @sql NVARCHAR(MAX) = N'SELECT Name, Mobile, License_Number, License_Expiry_Date FROM DriverMaster WHERE YEAR(License_Expiry_Date) = 2026 AND IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY License_Expiry_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (263, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q264 | Number of students appearing per exam type ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Number of students appearing per exam type',
        @sql NVARCHAR(MAX) = N'SELECT et.Name AS ExamType, COUNT(DISTINCT smd.StudentID) AS StudentsAppeared FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ExamTypeMaster et ON smm.ExamTypeID = et.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND et.IsDeleted = 0 GROUP BY et.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (264, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q265 | Can you show rank list for Class 9 Section A? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show rank list for Class 9 Section A?',
        @sql NVARCHAR(MAX) = N'SELECT smd.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName, SUM(smd.Marks) AS TotalMarks, RANK() OVER (ORDER BY SUM(smd.Marks) DESC) AS Rank FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ClassMaster c ON smm.ClassID = c.ID INNER JOIN SectionMaster secm ON smm.SectionID = secm.ID INNER JOIN Student_Master stm ON smd.StudentID = stm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND c.Name = ''Class 9'' AND secm.Name = ''A'' GROUP BY smd.StudentID, stm.AdmissionNo, stm.FirstName, stm.LastName ORDER BY Rank;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (265, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q266 | Staff salary above 50000 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff salary above 50000',
        @sql NVARCHAR(MAX) = N'SELECT gem.EmployeeID, gem.EmployeeName, gem.NetPay FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) AND gem.NetPay > 50000 ORDER BY gem.NetPay DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (266, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q267 | How many staff members do we have? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many staff members do we have?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalStaff FROM Staff_Master sm WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (267, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q268 | Which section in Class 8 has the most outstanding? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which section in Class 8 has the most outstanding?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 f.SectionName, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.ClassName = ''Class 8'' AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.SectionName ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (268, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q269 | Hey, how many TC requests are still open (not yet completed)? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many TC requests are still open (not yet completed)?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS OpenTCRequests FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.IsActive = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (269, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q270 | Which week had maximum collection this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which week had maximum collection this month?',
        @sql NVARCHAR(MAX) = N'SELECT DATEPART(WEEK, fc.Bill_Date) AS WeekNumber, MIN(CAST(fc.Bill_Date AS DATE)) AS WeekStart, MAX(CAST(fc.Bill_Date AS DATE)) AS WeekEnd, SUM(fc.Receipt_Amt) AS WeeklyCollection FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND MONTH(fc.Bill_Date) = MONTH(GETDATE()) AND YEAR(fc.Bill_Date) = YEAR(GETDATE()) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY DATEPART(WEEK, fc.Bill_Date) ORDER BY SUM(fc.Receipt_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (270, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q271 | What's the total fee collected via cheque that later bounced? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the total fee collected via cheque that later bounced?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS ChequeBounceTotal FROM FeesCollection fc WHERE fc.ChequeStatus_ID = 4 AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (271, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q272 | Which driver has the most experience? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which driver has the most experience?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 Name, Mobile, Experience FROM DriverMaster WHERE IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY Experience DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (272, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q273 | Collection on 15th June ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Collection on 15th June',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fc.Receipt_Amt) AS CollectionAmount, COUNT(fc.Id) AS Receipts FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND CAST(fc.Bill_Date AS DATE) = DATEFROMPARTS(CASE WHEN MONTH(GETDATE()) >= 4 THEN YEAR(GETDATE()) ELSE YEAR(GETDATE())-1 END + 0, 6, 15) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (273, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q274 | Classes with attendance below 80% today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Classes with attendance below 80% today',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS class_name, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS attendance_pct FROM StudentAttendance sa JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name HAVING CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) < 80 ORDER BY attendance_pct ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (274, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q275 | Can you quickly tell me who came late today among teachers? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you quickly tell me who came late today among teachers?',
        @sql NVARCHAR(MAX) = N'SELECT sfm.Staff_FirstName + '' '' + ISNULL(sfm.Staff_LastName, '''') AS StaffName, sa.InTime FROM Staff_Attendance sa INNER JOIN Staff_Master sfm ON sa.Staff_ID = sfm.Staff_ID AND sfm.StaffStatus_ID = 1 WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.InTime > ''09:30:00'' AND sa.Attendance_Status_ID = 1  AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (275, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q276 | Students with no hostel, no transport, no food who have outstanding fees above 15000 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students with no hostel, no transport, no food who have outstanding fees above 15000',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName + '' '' + sm.LastName AS StudentName, SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN Student_Master sm ON f.Student_ID = sm.ID WHERE f.IsHostelFee = 0 AND f.IsBusFee = 0 AND f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.FirstName, sm.LastName HAVING SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) > 15000;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (276, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q277 | Top 5 lowest paid staff ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Top 5 lowest paid staff',
        @sql NVARCHAR(MAX) = N'SELECT TOP 5 gem.EmployeeID, gem.EmployeeName, gem.NetPay FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gem.NetPay > 0 ORDER BY gem.NetPay ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (277, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q278 | Which branch has the highest collection this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which branch has the highest collection this month?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 bm.Name AS Branch, SUM(fc.Receipt_Amt) AS Collection FROM FeesCollection fc JOIN BranchMaster bm ON fc.BranchID = bm.ID WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND DATEPART(MONTH, fc.Bill_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, fc.Bill_Date) = DATEPART(YEAR, GETDATE()) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY Collection DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (278, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q279 | Just checking - how many students are in each Section of Class 6? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many students are in each Section of Class 6?',
        @sql NVARCHAR(MAX) = N'SELECT secm.Name AS SectionName, COUNT(*) AS student_count FROM StudentAcademicDetail sad JOIN ClassMaster cm ON sad.ClassID = cm.ID INNER JOIN SectionMaster secm ON sad.SectionID = secm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND cm.Name IN (''Class 6'', ''VI'') AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY secm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (279, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q280 | What was the average collection per student each year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What was the average collection per student each year?',
        @sql NVARCHAR(MAX) = N'SELECT bad.Name AS AcademicYear, SUM(fc.Receipt_Amt) AS TotalCollection, COUNT(DISTINCT fc.Student_ID) AS PayingStudents, CAST(SUM(fc.Receipt_Amt) / NULLIF(COUNT(DISTINCT fc.Student_ID), 0) AS DECIMAL(10,2)) AS AvgPerStudent FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bad.Name ORDER BY bad.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (280, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q281 | What's the count for number of classes in the Vadapalani branch? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the count for number of classes in the Vadapalani branch?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS Classes FROM ClassMaster cm WHERE cm.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%Vadapalani%'' OR ShortName LIKE ''%Vadapalani%'')) AND cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (281, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q282 | Let me see the month-wise collection with percentage contribution ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see the month-wise collection with percentage contribution',
        @sql NVARCHAR(MAX) = N'WITH MonthlyCollection AS (SELECT MONTH(fc.Bill_Date) AS MonthNo, DATENAME(MONTH, fc.Bill_Date) AS MonthName, SUM(fc.Receipt_Amt) AS MonthCollection FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY MONTH(fc.Bill_Date), DATENAME(MONTH, fc.Bill_Date)) SELECT MonthNo, MonthName, MonthCollection, CAST(MonthCollection * 100.0 / NULLIF(SUM(MonthCollection) OVER (), 0) AS DECIMAL(5,2)) AS ContributionPercent FROM MonthlyCollection ORDER BY MonthNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (282, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q283 | What's the staff not on hold? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the staff not on hold?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS ActiveStaff FROM EmployeeMaster WHERE (IsHold = 0 OR IsHold IS NULL) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (283, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q284 | Show me students admitted this year with their parent contact numbers ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me students admitted this year with their parent contact numbers',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName, sm.LastName, sm.FatherContactNo, sm.MotherContactNo FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (284, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q285 | What's the just the boys count? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the just the boys count?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS BoysCount FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.Gender IN (''Male'', ''Boy'');',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (285, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q286 | Just checking - how many applications were submitted in the month of June? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many applications were submitted in the month of June?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS Applications FROM ApplicationEntry ae WHERE MONTH(ae.ApplicationDate)=6 AND ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (ae.IsDeleted IS NULL OR ae.IsDeleted=0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (286, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q287 | I need tickets linked to specific students ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need tickets linked to specific students',
        @sql NVARCHAR(MAX) = N'SELECT ft.TicketNo, ft.Subject, sm.FirstName + '' '' + sm.LastName AS StudentName, ft.ContactName AS Parent_Name, ft.ContactNumber AS ParentPhone, ft.Status FROM FeedbackTicket ft INNER JOIN Student_Master sm ON ft.StudentID = sm.ID WHERE ft.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ft.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND ft.StudentID IS NOT NULL ORDER BY ft.Created_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (287, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q288 | What is the percentage of fee collected vs fee structure amount? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the percentage of fee collected vs fee structure amount?',
        @sql NVARCHAR(MAX) = N'WITH TotalStructure AS (SELECT SUM(fcd.Fees_Amount) AS TotalDemand FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))), TotalCollected AS (SELECT SUM(fc.Receipt_Amt) AS TotalCollection FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) SELECT tc.TotalCollection, ts.TotalDemand, CAST(tc.TotalCollection * 100.0 / NULLIF(ts.TotalDemand, 0) AS DECIMAL(5,2)) AS CollectionPercent FROM TotalCollected tc, TotalStructure ts;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (288, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q289 | Which classes have no absentees today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which classes have no absentees today?',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT cm.Name AS ClassName FROM ClassMaster cm WHERE cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND cm.IsDeleted = 0 AND cm.ID NOT IN (SELECT DISTINCT sa.Class_ID FROM StudentAttendance sa WHERE sa.Attendance_Date = CAST(GETDATE() AS DATE) AND sa.Attendance_Status_ID = 2 AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (289, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q290 | This week's total collection ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'This week''s total collection',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS this_week_collection FROM FeesCollection fc WHERE fc.Bill_Date >= DATEADD(DAY, 1 - DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE)) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (290, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q291 | What's the loss rate of enquiries? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the loss rate of enquiries?',
        @sql NVARCHAR(MAX) = N'DECLARE @StatusLost bigint = (SELECT TOP 1 ID FROM Enquiry_Status_Master WHERE Name = ''Dropped'');
WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT CAST(COUNT(CASE WHEN CallStatus_ID = @StatusLost THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS LossRatePercent FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (291, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q292 | Let me see the fee type-wise collection summary ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see the fee type-wise collection summary',
        @sql NVARCHAR(MAX) = N'SELECT fcd.FeesType_Name, SUM(fcd.Paid_Amt) AS Collected FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fcd.FeesType_Name ORDER BY Collected DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (292, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q293 | List the exam term names for this branch ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List the exam term names for this branch',
        @sql NVARCHAR(MAX) = N'SELECT etm.Name FROM ExamTermMaster etm WHERE etm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (etm.Deleted IS NULL OR etm.Deleted = 0) ORDER BY etm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (293, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q294 | What's our biggest expense category in salary? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s our biggest expense category in salary?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 5 gem.DesignationName AS Designation, COUNT(*) AS StaffCount, SUM(gem.NetPay) AS TotalPay FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) GROUP BY gem.DesignationName ORDER BY TotalPay DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (294, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q295 | What are the enquiries that are in progress for more than 15 days? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What are the enquiries that are in progress for more than 15 days?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT CallRefNo, Student_Name, Parent_Name, MobileNo1, CallDate, DATEDIFF(DAY, CallDate, GETDATE()) AS DaysPending FROM GeneralCallRegister WHERE CallStatus_ID IN (SELECT ID FROM Enquiry_Status_Master WHERE Name = ''In Progress'') AND DATEDIFF(DAY, CallDate, GETDATE()) > 15 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0 ORDER BY DaysPending DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (295, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q296 | How many receipts were generated last week? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many receipts were generated last week?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(fc.Id) AS ReceiptCount FROM FeesCollection fc WHERE fc.Bill_Date >= DATEADD(WEEK, -1, DATEADD(DAY, -(DATEPART(WEEKDAY, GETDATE()) - 2), CAST(GETDATE() AS DATE))) AND fc.Bill_Date < DATEADD(DAY, -(DATEPART(WEEKDAY, GETDATE()) - 2), CAST(GETDATE() AS DATE)) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (296, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q297 | Pull up class-wise pending late fee totals ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up class-wise pending late fee totals',
        @sql NVARCHAR(MAX) = N'SELECT CM.Name AS ClassName, SUM(lfd.Amount - ISNULL(lfc.Concession_Amount, 0)) AS Pending FROM FeesInformationStudentDetail FI INNER JOIN LateFeeMaster lfm ON lfm.TermId = FI.Term_ID AND lfm.IsActive = 1 AND CAST(GETDATE() AS DATE) <= lfm.ValidityDate AND CAST(GETDATE() AS DATE) >= lfm.LastDate INNER JOIN LateFeeDetails lfd ON lfm.ID = lfd.LateFeeID AND (lfd.ClassId = FI.ClassID OR lfd.ClassId = 0) AND CAST(GETDATE() AS DATE) BETWEEN lfd.FromDate AND lfd.ToDate INNER JOIN Fees_Master fmm ON fmm.ID = FI.Fees_ID AND ISNULL(fmm.IsIncludeinLateFee, 0) = 1 INNER JOIN Student_Master SM ON SM.ID = FI.Student_ID LEFT JOIN LateFee_Concession lfc ON lfc.Student_ID = FI.Student_ID AND lfc.LateFeeHeadId = lfm.LateFeeHeadId AND lfc.Term_ID = FI.Term_ID AND lfc.AcademicYearID = FI.AcademicYearID AND lfc.BranchID = FI.BranchID AND ISNULL(lfc.IsDeleted, 0) = 0 INNER JOIN StudentAcademicDetail SA ON FI.AcademicYearID = SA.AcademicYearID AND SA.StudentID = FI.Student_ID INNER JOIN ClassMaster CM ON CM.ID = SA.ClassID WHERE FI.IsIncludedInLumpSum <> 1 AND FI.IsDonation = 0 AND (FI.Amount - ISNULL(FI.Concession_Amt,0) - FI.Paid_Amt - FI.Lien_Amount) > 0 AND CAST(SM.AdmissionDate AS DATE) < lfd.FromDate AND (lfd.Amount - ISNULL(lfc.Concession_Amount, 0)) > 0 AND FI.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY CM.Name ORDER BY Pending DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (297, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q298 | Class-wise attendance percentage today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class-wise attendance percentage today',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS class_name, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS attendance_pct FROM StudentAttendance sa JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (298, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q299 | What's the dropout rate this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the dropout rate this year?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(COUNT(CASE WHEN sad.IsTCIssued = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS DropoutRate FROM StudentAcademicDetail sad WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (299, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q300 | Staff-wise fee collection this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff-wise fee collection this month',
        @sql NVARCHAR(MAX) = N'SELECT fc.Collected_By_Name, SUM(fc.Receipt_Amt) AS total_amount, COUNT(*) AS receipt_count FROM FeesCollection fc WHERE DATEPART(MONTH, fc.Bill_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, fc.Bill_Date) = DATEPART(YEAR, GETDATE()) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fc.Collected_By_Name ORDER BY SUM(fc.Receipt_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
PRINT 'checkpoint: reached Q300';
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (300, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q301 | What is the staff attendance rate today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the staff attendance rate today?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(CAST(SUM(CASE WHEN Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS FLOAT) * 100 / COUNT(*), 2) AS AttendancePercentage FROM Staff_Attendance WHERE Attendance_Date = CAST(GETDATE() AS DATE) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (301, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q302 | Staff attendance this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff attendance this month',
        @sql NVARCHAR(MAX) = N'SELECT Attendance_Date, COUNT(CASE WHEN Attendance_Status_ID = 1 THEN 1 END) AS Present, COUNT(CASE WHEN Attendance_Status_ID = 2 THEN 1 END) AS Absent FROM Staff_Attendance WHERE MONTH(Attendance_Date) = MONTH(GETDATE()) AND YEAR(Attendance_Date) = YEAR(GETDATE()) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY Attendance_Date ORDER BY Attendance_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (302, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q303 | So, how many students have some outstanding balance? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, how many students have some outstanding balance?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT f.Student_ID) AS StudentsWithOutstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Student_ID HAVING SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (303, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q304 | Can you show all admissions that happened in May 2025? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show all admissions that happened in May 2025?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, sm.AdmissionDate FROM Student_Master sm JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNewAdmission = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND MONTH(sm.AdmissionDate) = 5 AND YEAR(sm.AdmissionDate) = 2025 AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sm.AdmissionDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (304, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q305 | So, what's the total unpaid late fee amount across all students? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, what''s the total unpaid late fee amount across all students?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(lfd.Amount - ISNULL(lfc.Concession_Amount, 0)) AS TotalPending FROM FeesInformationStudentDetail FI INNER JOIN LateFeeMaster lfm ON lfm.TermId = FI.Term_ID AND lfm.IsActive = 1 AND CAST(GETDATE() AS DATE) <= lfm.ValidityDate AND CAST(GETDATE() AS DATE) >= lfm.LastDate INNER JOIN LateFeeDetails lfd ON lfm.ID = lfd.LateFeeID AND (lfd.ClassId = FI.ClassID OR lfd.ClassId = 0) AND CAST(GETDATE() AS DATE) BETWEEN lfd.FromDate AND lfd.ToDate INNER JOIN Fees_Master fmm ON fmm.ID = FI.Fees_ID AND ISNULL(fmm.IsIncludeinLateFee, 0) = 1 INNER JOIN Student_Master SM ON SM.ID = FI.Student_ID LEFT JOIN LateFee_Concession lfc ON lfc.Student_ID = FI.Student_ID AND lfc.LateFeeHeadId = lfm.LateFeeHeadId AND lfc.Term_ID = FI.Term_ID AND lfc.AcademicYearID = FI.AcademicYearID AND lfc.BranchID = FI.BranchID AND ISNULL(lfc.IsDeleted, 0) = 0 WHERE FI.IsIncludedInLumpSum <> 1 AND FI.IsDonation = 0 AND (FI.Amount - ISNULL(FI.Concession_Amt,0) - FI.Paid_Amt - FI.Lien_Amount) > 0 AND CAST(SM.AdmissionDate AS DATE) < lfd.FromDate AND (lfd.Amount - ISNULL(lfc.Concession_Amount, 0)) > 0 AND FI.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (305, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q306 | Let me see demand and outstanding for Class 5 Section A ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see demand and outstanding for Class 5 Section A',
        @sql NVARCHAR(MAX) = N'SELECT SUM(f.Amount) AS Demand, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.ClassName = ''Class 5'' AND f.SectionName = ''A'' AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (306, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q307 | How many students have not paid anything yet? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students have not paid anything yet?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS UnpaidStudents FROM (SELECT Student_ID FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY Student_ID HAVING SUM(Paid_Amt) = 0) t;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (307, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q308 | What are the staff members whose salary is on hold? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What are the staff members whose salary is on hold?',
        @sql NVARCHAR(MAX) = N'SELECT StaffID, BankName, BankAccountNo FROM EmployeeMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0 AND IsHold = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (308, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q309 | Show me the class-wise transport student count alongside hostel student count. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me the class-wise transport student count alongside hostel student count.',
        @sql NVARCHAR(MAX) = N'SELECT ClassName, SUM(CASE WHEN TransportRequired = 1 THEN 1 ELSE 0 END) AS TransportStudents, SUM(CASE WHEN HostelRequired = 1 THEN 1 ELSE 0 END) AS HostelStudents FROM StudentAcademicDetail WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND IsActive = 1 AND IsTCIssued = 0 GROUP BY ClassName ORDER BY ClassName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (309, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q310 | Total count of hostel students ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total count of hostel students',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS HostelStudentCount FROM StudentAcademicDetail sad WHERE sad.HostelRequired = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (310, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q311 | What's the outstanding bus fee amount? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the outstanding bus fee amount?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS BusFeeOutstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND IsBusFee = 1 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (311, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q312 | Let me see top 10 defaulters for transport fees ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see top 10 defaulters for transport fees',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 f.Student_ID, s.FirstName + '' '' + ISNULL(s.LastName, '''') AS StudentName, f.ClassName, s.FatherContactNo, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID INNER JOIN Student_Master s ON f.Student_ID = s.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.IsBusFee = 1 AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Student_ID, s.FirstName, s.LastName, f.ClassName, s.FatherContactNo HAVING SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 0 ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (312, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q313 | Let me see month-wise recovery rate trend ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see month-wise recovery rate trend',
        @sql NVARCHAR(MAX) = N'SELECT f.Month_No, f.Month_Name, ROUND(SUM(f.Paid_Amt) * 100.0 / NULLIF(SUM(f.Amount - ISNULL(f.Concession_Amt, 0)), 0), 2) AS RecoveryRate FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Month_No, f.Month_Name ORDER BY f.Month_No;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (313, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q314 | What is the collection ratio of Term 1 vs Term 2? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the collection ratio of Term 1 vs Term 2?',
        @sql NVARCHAR(MAX) = N'SELECT Term_Name, SUM(Paid_Amt) AS Collected, SUM(Amount) AS Demand, ROUND(SUM(Paid_Amt) * 100.0 / NULLIF(SUM(Amount), 0), 2) AS CollectionRatio FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND Term_Name IN (''Term 1'', ''Term 2'') AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY Term_Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (314, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q315 | Show staff who have taken more than 10 days leave total. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show staff who have taken more than 10 days leave total.',
        @sql NVARCHAR(MAX) = N'SELECT lem.Staff_Name AS StaffName, SUM(lem.NoOfDays) AS TotalDays FROM LeaveEntryMaster lem INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND ls.Name = ''Approved'' GROUP BY lem.Staff_Name HAVING SUM(lem.NoOfDays) > 10 ORDER BY TotalDays DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (315, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q316 | Hey, what's the recovery rate for tuition fees specifically? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the recovery rate for tuition fees specifically?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(SUM(f.Paid_Amt) * 100.0 / NULLIF(SUM(f.Amount - ISNULL(f.Concession_Amt, 0)), 0), 2) AS TuitionRecoveryRate FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.Fees_Name LIKE ''%Tuition%'' AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (316, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q317 | Can you show all subjects taught by a specific teacher? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show all subjects taught by a specific teacher?',
        @sql NVARCHAR(MAX) = N'SELECT sm.Staff_FirstName + '' '' + sm.Staff_LastName AS TeacherName, sub.Name AS SubjectName, cm.Name AS ClassName FROM SubjectAllocation_Master sam INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID INNER JOIN Staff_Master sm ON sam.Staff_ID = sm.Staff_ID INNER JOIN Subject_Master sub ON sam.Subject_ID = sub.Id WHERE sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (sam.IsDeleted = 0 OR sam.IsDeleted IS NULL) ORDER BY sm.Staff_FirstName, cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (317, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q318 | Show class-wise tuition fee outstanding. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show class-wise tuition fee outstanding.',
        @sql NVARCHAR(MAX) = N'SELECT f.ClassName, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS TuitionOutstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.Fees_Name LIKE ''%Tuition%'' AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.ClassName ORDER BY f.ClassName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (318, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q319 | Show me the school topper with marks ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me the school topper with marks',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 smd.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName, SUM(smd.Marks) AS TotalMarks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN Student_Master stm ON smd.StudentID = stm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 GROUP BY smd.StudentID, stm.AdmissionNo, stm.FirstName, stm.LastName ORDER BY TotalMarks DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (319, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q320 | How much concession has been given across all classes? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much concession has been given across all classes?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(ISNULL(Concession_Amt, 0)) AS TotalConcession FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (320, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q321 | What's the term-wise fee collection breakdown? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the term-wise fee collection breakdown?',
        @sql NVARCHAR(MAX) = N'SELECT fcd.Term_ID, SUM(fcd.Paid_Amt) AS TotalPaid, SUM(fcd.Remaining_Amt) AS TotalRemaining FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fcd.Term_ID ORDER BY fcd.Term_ID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (321, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q322 | What is the average age of new admissions? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the average age of new admissions?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(AVG(DATEDIFF(YEAR, sm.StudentDob, GETDATE())) AS DECIMAL(4,1)) AS AvgAge FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNewAdmission = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (322, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q323 | Show all high priority tickets that are not resolved. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show all high priority tickets that are not resolved.',
        @sql NVARCHAR(MAX) = N'SELECT ft.TicketNo, ft.Subject, ft.FeedbackText AS Description, ft.ContactName AS Parent_Name, ft.ContactNumber AS ParentPhone, ft.Created_Date AS CreatedDate, ft.Status FROM FeedbackTicket ft OUTER APPLY (SELECT MAX(ftr.RepliedOn) AS LastReplyDate FROM FeedbackTicketReplies ftr WHERE ftr.TicketID = ft.Id) rp OUTER APPLY (SELECT CASE WHEN EXISTS (SELECT 1 FROM FeedbackEscalationMatrix fem WHERE fem.FeedbackCategoryID = ft.CategoryID AND DATEDIFF(HOUR, ft.Created_Date, ISNULL(rp.LastReplyDate, GETDATE())) > fem.EscalationHours) THEN 1 ELSE 0 END AS IsEscalated) esc WHERE ft.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ft.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND ft.Status IN (''Open'', ''In Progress'', ''Reopened'') AND esc.IsEscalated = 1 ORDER BY ft.Created_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (323, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q324 | Which staff member has taken the most leaves? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which staff member has taken the most leaves?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 lem.Staff_Name AS StaffName, SUM(lem.NoOfDays) AS TotalDays, COUNT(*) AS LeaveCount FROM LeaveEntryMaster lem INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND ls.Name = ''Approved'' GROUP BY lem.Staff_Name ORDER BY TotalDays DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (324, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q325 | What is the total lien amount held against fees this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total lien amount held against fees this year?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(f.Lien_Amount) AS TotalLienAmount FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (325, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q326 | Collector-wise collection summary for this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Collector-wise collection summary for this year',
        @sql NVARCHAR(MAX) = N'SELECT fc.Collected_By_Name, COUNT(fc.Id) AS Receipts, SUM(fc.Receipt_Amt) AS TotalCollected, CAST(SUM(fc.Receipt_Amt) * 100.0 / NULLIF(SUM(SUM(fc.Receipt_Amt)) OVER (), 0) AS DECIMAL(5,2)) AS PercentContribution FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fc.Collected_By_Name ORDER BY TotalCollected DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (326, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q327 | What is the hostel fee outstanding? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the hostel fee outstanding?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS HostelFeeOutstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND IsHostelFee = 1 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (327, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q328 | Hey, what's the median marks for Class 10 in Science? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the median marks for Class 10 in Science?',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY pc.Marks) OVER () AS MedianMarks FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE pc.SubjectName = ''Science'' AND cm.Name IN (''Class 10'', ''X'') AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (328, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q329 | What is today's collection? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is today''s collection?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS today_collection FROM FeesCollection fc WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (329, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q330 | What's the hostel students with fee pending? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the hostel students with fee pending?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, sm.AdmissionNo, SUM(fcd.Remaining_Amt) AS pending FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Student_Master sm ON fc.Student_ID = sm.ID JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID AND fc.AcademicYearID = sad.AcademicYearID WHERE sad.HostelRequired = 1 AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fcd.Remaining_Amt > 0 AND sad.IsActive = 1 GROUP BY sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo ORDER BY SUM(fcd.Remaining_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (330, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q331 | Can you check - class-wise gender distribution for students who opted for food facility? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you check - class-wise gender distribution for students who opted for food facility?',
        @sql NVARCHAR(MAX) = N'SELECT sad.ClassName, sm.Gender, COUNT(*) AS StudentCount FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.FoodRequired = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sad.ClassID, sad.ClassName, sm.Gender ORDER BY sad.ClassID, sm.Gender;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (331, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q332 | Which vehicles are diesel-powered? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which vehicles are diesel-powered?',
        @sql NVARCHAR(MAX) = N'SELECT Vehicle_Number, Make, Model, Seating_Capacity FROM VehicleMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND Fuel_Type_Name = ''Diesel'';',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (332, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q333 | Who are the top 5 defaulters for hostel fees? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who are the top 5 defaulters for hostel fees?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 5 f.Student_ID, s.FirstName + '' '' + ISNULL(s.LastName, '''') AS StudentName, f.ClassName, s.FatherContactNo, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID INNER JOIN Student_Master s ON f.Student_ID = s.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.IsHostelFee = 1 AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Student_ID, s.FirstName, s.LastName, f.ClassName, s.FatherContactNo HAVING SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 0 ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (333, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q334 | Total collection in last 30 days ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total collection in last 30 days',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS Last30DaysCollection FROM FeesCollection fc WHERE fc.Bill_Date >= DATEADD(DAY, -30, CAST(GETDATE() AS DATE)) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (334, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q335 | List non-teaching staff members ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List non-teaching staff members',
        @sql NVARCHAR(MAX) = N'SELECT sm.Staff_ID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName FROM Staff_Master sm INNER JOIN StaffType_Master stm ON sm.StaffType_ID = stm.ID INNER JOIN StaffTypeCategoryMaster stcm ON stm.Type_Id = stcm.Id WHERE stcm.Name IN (''Non-Academic'', ''Management'') AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sm.IsDeleted = 0 AND sm.StaffStatus_ID = 1 ORDER BY sm.Staff_FirstName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (335, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q336 | Just checking - how many enquiries came from newspaper ads? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many enquiries came from newspaper ads?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS NewspaperEnquiries FROM GeneralCallRegister em INNER JOIN Enquiry_Mode_Master emm ON em.Mode_ID = emm.ID WHERE em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND (em.IsDeleted = 0 OR em.IsDeleted IS NULL) AND emm.Name = ''Newspaper'';',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (336, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q337 | Let me see tickets from parents with phone numbers for follow-up ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see tickets from parents with phone numbers for follow-up',
        @sql NVARCHAR(MAX) = N'SELECT ft.TicketNo, ft.ContactName, ft.ContactNumber, ft.Subject FROM FeedbackTicket ft WHERE ft.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (ft.IsDeleted IS NULL OR ft.IsDeleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (337, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q338 | Show month-wise total collection from day closure records. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show month-wise total collection from day closure records.',
        @sql NVARCHAR(MAX) = N'WITH dc AS (SELECT dm.ID, dm.DayClosureDate AS ClosureDate, dm.CollectedByName AS ClosedBy_Name, SUM(dmd.CollectedAmount) AS TotalCollection, SUM(CASE WHEN cmm.Name = ''Cash'' THEN dmd.CollectedAmount ELSE 0 END) AS CashCollection, SUM(CASE WHEN cmm.Name = ''Bank Online Transfer'' THEN dmd.CollectedAmount ELSE 0 END) AS OnlineCollection, SUM(CASE WHEN cmm.Name NOT IN (''Cash'', ''Bank Online Transfer'', ''Cheque'') THEN dmd.CollectedAmount ELSE 0 END) AS OtherCollection, SUM(CASE WHEN cmm.Name = ''Cheque'' THEN dmd.CollectedAmount ELSE 0 END) AS ChequeCollection FROM DayclosureMaster dm INNER JOIN DayclosureMaster_Details dmd ON dmd.HeaderID = dm.ID LEFT JOIN CollectionMode_Master cmm ON dmd.CollectionMode_ID = cmm.ID WHERE dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (dm.IsDeleted = 0 OR dm.IsDeleted IS NULL) AND (dmd.IsDeleted = 0 OR dmd.IsDeleted IS NULL) GROUP BY dm.ID, dm.DayClosureDate, dm.CollectedByName) SELECT FORMAT(ClosureDate, ''yyyy-MM'') AS [Month], SUM(TotalCollection) AS MonthlyTotal, SUM(CashCollection) AS MonthlyCash, SUM(OnlineCollection) AS MonthlyOnline FROM dc GROUP BY FORMAT(ClosureDate, ''yyyy-MM'') ORDER BY [Month];',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (338, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q339 | So, how many enquiries are currently in progress? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, how many enquiries are currently in progress?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS InProgressEnquiries FROM GeneralCallRegister WHERE CallStatus_ID IN (SELECT ID FROM Enquiry_Status_Master WHERE Name = ''In Progress'') AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (339, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q340 | Students collected by 'Admin' who also have late fee charged ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students collected by ''Admin'' who also have late fee charged',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, fc.Bill_No, fc.Bill_Date FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN FeesCollection fc ON sm.ID = fc.Student_ID INNER JOIN FeesCollection_Details fcd ON fc.Id = fcd.Fees_Collection_ID WHERE fc.Collected_By_Name = ''Admin'' AND fcd.LateFeeAmount > 0 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (340, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q341 | Show me students whose fees are paid for all months so far ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me students whose fees are paid for all months so far',
        @sql NVARCHAR(MAX) = N'WITH MonthsSoFar AS (SELECT COUNT(DISTINCT fcd.Month_No) AS TotalMonths FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))), StudentMonths AS (SELECT fc.Student_ID, COUNT(DISTINCT fcd.Month_No) AS PaidMonths FROM FeesCollection fc JOIN FeesCollection_Details fcd ON fc.Id = fcd.Fees_Collection_ID JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fcd.Remaining_Amt = 0 AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fc.Student_ID) SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, smo.PaidMonths FROM StudentMonths smo JOIN Student_Master sm ON smo.Student_ID = sm.ID JOIN MonthsSoFar msf ON smo.PaidMonths >= msf.TotalMonths;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (341, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q342 | Can you show upcoming approved leaves for next week? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show upcoming approved leaves for next week?',
        @sql NVARCHAR(MAX) = N'SELECT lem.Staff_Name AS StaffName, lem.LeaveFromDate, lem.LeaveToDate, lem.NoOfDays, lem.Purpose AS Reason FROM LeaveEntryMaster lem INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND ls.Name = ''Approved'' AND lem.LeaveFromDate BETWEEN DATEADD(DAY, 1, GETDATE()) AND DATEADD(DAY, 7, GETDATE()) ORDER BY lem.LeaveFromDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (342, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q343 | What is the month-wise fee head collection pivot? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the month-wise fee head collection pivot?',
        @sql NVARCHAR(MAX) = N'SELECT fcd.FeesGroup_Name AS FeeHead, SUM(CASE WHEN fcd.Month_No = 4 THEN fcd.Paid_Amt ELSE 0 END) AS Apr, SUM(CASE WHEN fcd.Month_No = 5 THEN fcd.Paid_Amt ELSE 0 END) AS May, SUM(CASE WHEN fcd.Month_No = 6 THEN fcd.Paid_Amt ELSE 0 END) AS Jun, SUM(CASE WHEN fcd.Month_No = 7 THEN fcd.Paid_Amt ELSE 0 END) AS Jul, SUM(CASE WHEN fcd.Month_No = 8 THEN fcd.Paid_Amt ELSE 0 END) AS Aug, SUM(CASE WHEN fcd.Month_No = 9 THEN fcd.Paid_Amt ELSE 0 END) AS Sep FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fcd.FeesGroup_Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (343, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q344 | Total new students admitted today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total new students admitted today',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS TodayAdmissions FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNewAdmission = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND CAST(sm.AdmissionDate AS DATE) = CAST(GETDATE() AS DATE) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (344, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q345 | Show the fee-wise concession for Class 10. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the fee-wise concession for Class 10.',
        @sql NVARCHAR(MAX) = N'SELECT Fees_Name, SUM(ISNULL(Concession_Amt, 0)) AS ConcessionAmount FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND ClassName = ''Class 10'' AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY Fees_Name ORDER BY ConcessionAmount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (345, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q346 | Total teaching staff salary for June ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total teaching staff salary for June',
        @sql NVARCHAR(MAX) = N'SELECT SUM(gem.NetPay) AS TotalSalary FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.MonthID = 6 AND gm.StaffTypeName = ''Teaching'' AND gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (346, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q347 | Students per class breakdown ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students per class breakdown',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(DISTINCT sad.StudentID) AS Students FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID INNER JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY cm.Name, cm.DisplayOrder ORDER BY cm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (347, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q348 | Admission count for each class and section ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Admission count for each class and section',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, secm.Name, COUNT(DISTINCT sad.StudentID) AS NewAdmissions FROM StudentAcademicDetail sad JOIN ClassMaster cm ON sad.ClassID = cm.ID INNER JOIN SectionMaster secm ON sad.SectionID = secm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNewAdmission = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name, cm.DisplayOrder, secm.Name ORDER BY cm.DisplayOrder, secm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (348, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q349 | How many homework assignments were given today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many homework assignments were given today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TodayHomework FROM HomeWorkAndAssignment WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND CAST(AssignmentDate AS DATE) = CAST(GETDATE() AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (349, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q350 | Total payroll for the current month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total payroll for the current month',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(gem.NetPay), 0) AS TotalSalary FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (350, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q351 | What's the month-wise count of unique paying students? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the month-wise count of unique paying students?',
        @sql NVARCHAR(MAX) = N'SELECT MONTH(fc.Bill_Date) AS MonthNo, DATENAME(MONTH, fc.Bill_Date) AS MonthName, COUNT(DISTINCT fc.Student_ID) AS UniquePayingStudents FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY MONTH(fc.Bill_Date), DATENAME(MONTH, fc.Bill_Date) ORDER BY MonthNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (351, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q352 | Show term-wise recovery rate. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show term-wise recovery rate.',
        @sql NVARCHAR(MAX) = N'SELECT f.Term_Name, ROUND(SUM(f.Paid_Amt) * 100.0 / NULLIF(SUM(f.Amount - ISNULL(f.Concession_Amt, 0)), 0), 2) AS RecoveryRate FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Term_Name ORDER BY f.Term_Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (352, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q353 | Just checking - how many students have Term 2 fees fully unpaid? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many students have Term 2 fees fully unpaid?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT f.Student_ID) AS UnpaidStudents FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.Term_Name IN (''Term 2'', ''II'') AND f.Paid_Amt = 0 AND f.Amount > 0 AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (353, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q354 | Collection for a student with admission number 2024-001 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Collection for a student with admission number 2024-001',
        @sql NVARCHAR(MAX) = N'SELECT fc.Bill_No, fc.Bill_Date, fc.Receipt_Amt, cmm.Name, fc.FromMonthName, fc.ToMonthName FROM FeesCollection fc LEFT JOIN CollectionMode_Master cmm ON fc.Collection_Mode_ID = cmm.ID WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.Admission_No = ''2024-001'' AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) ORDER BY fc.Bill_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (354, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q355 | What's the fee category-wise collection? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the fee category-wise collection?',
        @sql NVARCHAR(MAX) = N'SELECT fcd.FeesCategory_Name, SUM(fcd.Paid_Amt) AS Collected FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fcd.FeesCategory_Name ORDER BY Collected DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (355, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q356 | Top 5 students by total fees paid ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Top 5 students by total fees paid',
        @sql NVARCHAR(MAX) = N'SELECT TOP 5 sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName, SUM(fc.Receipt_Amt) AS TotalPaid FROM FeesCollection fc INNER JOIN Student_Master sm ON fc.Student_ID = sm.ID INNER JOIN StudentAcademicDetail sad ON fc.Student_ID = sad.StudentID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY sm.AdmissionNo, sm.FirstName, sm.MiddleName, sm.LastName, cm.Name ORDER BY SUM(fc.Receipt_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (356, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q357 | What is the average number of leave days per application? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the average number of leave days per application?',
        @sql NVARCHAR(MAX) = N'SELECT AVG(CAST(lem.NoOfDays AS FLOAT)) AS AvgLeaveDays FROM LeaveEntryMaster lem INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND ls.Name = ''Approved'';',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (357, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q358 | What is the term-wise fee collection breakdown? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the term-wise fee collection breakdown?',
        @sql NVARCHAR(MAX) = N'SELECT fcd.Term_ID, SUM(fcd.Paid_Amt) AS TotalPaid, SUM(fcd.Remaining_Amt) AS TotalRemaining FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fcd.Term_ID ORDER BY fcd.Term_ID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (358, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q359 | Top 3 fee categories by collection amount ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Top 3 fee categories by collection amount',
        @sql NVARCHAR(MAX) = N'SELECT TOP 3 fcd.FeesCategory_Name, SUM(fcd.Paid_Amt) AS TotalCollection FROM FeesCollection_Details fcd WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY fcd.FeesCategory_Name ORDER BY SUM(fcd.Paid_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (359, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q360 | What is the term-wise fee collection status? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the term-wise fee collection status?',
        @sql NVARCHAR(MAX) = N'SELECT fcd.Term_ID, SUM(fcd.Paid_Amt) AS Collected FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fcd.Term_ID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (360, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q361 | Leave applications submitted today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Leave applications submitted today',
        @sql NVARCHAR(MAX) = N'SELECT sfm.Staff_FirstName + '' '' + ISNULL(sfm.Staff_LastName, '''') AS StaffName, lt.Name AS LeaveType, lem.LeaveFromDate, lem.LeaveToDate, lem.NoOfDays, ls.Name AS Status FROM LeaveEntryMaster lem INNER JOIN Staff_Master sfm ON lem.Staff_ID = sfm.Staff_ID AND sfm.StaffStatus_ID = 1 INNER JOIN LeaveType lt ON lem.LeaveType_ID = lt.ID INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE CAST(lem.Created_Date AS DATE) = CAST(GETDATE() AS DATE) AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY lem.Created_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (361, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q362 | List students with highest concession amounts. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List students with highest concession amounts.',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 f.Student_ID, s.FirstName + '' '' + ISNULL(s.LastName, '''') AS StudentName, f.ClassName, SUM(ISNULL(f.Concession_Amt, 0)) AS TotalConcession FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID INNER JOIN Student_Master s ON f.Student_ID = s.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Student_ID, s.FirstName, s.LastName, f.ClassName HAVING SUM(ISNULL(f.Concession_Amt, 0)) > 0 ORDER BY TotalConcession DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (362, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q363 | I need students for whom TC has already been handed over ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need students for whom TC has already been handed over',
        @sql NVARCHAR(MAX) = N'SELECT sad.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id INNER JOIN Student_Master stm ON sad.StudentID = stm.ID WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.IsTCIssued = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (363, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q364 | Did we collect more in 2025-26 than in 2024-25? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Did we collect more in 2025-26 than in 2024-25?',
        @sql NVARCHAR(MAX) = N'SELECT bad.Name AS AcademicYear, SUM(fc.Receipt_Amt) AS TotalCollection FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND (GETDATE() BETWEEN bad.Start_Date AND bad.End_Date OR bad.Id = (SELECT PreviousYearID FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = bad.Branch_Id)) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bad.Name ORDER BY bad.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (364, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q365 | Can I see the average in-time of staff today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can I see the average in-time of staff today?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(DATEADD(SECOND, AVG(DATEDIFF(SECOND, ''00:00:00'', CAST(InTime AS TIME))), ''00:00:00'') AS TIME) AS AvgInTime FROM Staff_Attendance WHERE Attendance_Date = CAST(GETDATE() AS DATE) AND InTime IS NOT NULL AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (365, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q366 | Show me students who have other exam registrations ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me students who have other exam registrations',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, sad.OtherExamName FROM Student_Master sm JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.OtherExam = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.ClassName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (366, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q367 | Show me per-student average outstanding by class. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me per-student average outstanding by class.',
        @sql NVARCHAR(MAX) = N'SELECT ClassName, ROUND(SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) * 1.0 / NULLIF(COUNT(DISTINCT Student_ID), 0), 2) AS AvgOutstandingPerStudent FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY ClassName ORDER BY AvgOutstandingPerStudent DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (367, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q368 | What percentage of total demand is given as concession? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What percentage of total demand is given as concession?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(SUM(ISNULL(f.Concession_Amt, 0)) * 100.0 / NULLIF(SUM(f.Amount), 0), 2) AS ConcessionPercent FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (368, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q369 | Give me the total number of active and hold staff separately ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the total number of active and hold staff separately',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CASE WHEN em.IsHold = 0 OR em.IsHold IS NULL THEN 1 ELSE 0 END) AS ActiveStaff, SUM(CASE WHEN em.IsHold = 1 THEN 1 ELSE 0 END) AS HoldStaff FROM Staff_Master sm LEFT JOIN EmployeeMaster em ON sm.Staff_ID = em.StaffID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (369, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q370 | Compare number of active students per branch ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare number of active students per branch',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, COUNT(*) AS ActiveStudents FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN BranchMaster bm ON sm.BranchID = bm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY ActiveStudents DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (370, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q371 | What's the nEET/JEE students performance summary? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the nEET/JEE students performance summary?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT smd.StudentID) AS TotalStudents, CAST(AVG(smd.Marks) AS DECIMAL(5,2)) AS AvgMarks, MAX(smd.Marks) AS MaxMarks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN StudentAcademicDetail sad ON smd.StudentID = sad.StudentID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND sad.IsNEETJEE = 1 AND sad.IsActive = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (371, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q372 | Naye admissions ki list do ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Naye admissions ki list do',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName, sm.AdmissionDate FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsNewAdmission = 1 AND sad.IsActive = 1 ORDER BY sm.AdmissionDate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (372, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q373 | Show me all VIP students with their admission details ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me all VIP students with their admission details',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sm.AdmissionDate, sad.ClassName, sad.RollNo, sm.FatherName, sm.FatherContactNo FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sm.IsVIP = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.ClassName, sad.RollNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (373, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q374 | I need the students with SMSFile uploaded ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need the students with SMSFile uploaded',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName, sad.SMSFile FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.SMSFile IS NOT NULL AND sad.SMSFile != '''' AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (374, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q375 | What is the fee category-wise collection? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the fee category-wise collection?',
        @sql NVARCHAR(MAX) = N'SELECT fcd.FeesCategory_Name, SUM(fcd.Paid_Amt) AS Collected FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fcd.FeesCategory_Name ORDER BY Collected DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (375, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q376 | List staff whose salary is on hold ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List staff whose salary is on hold',
        @sql NVARCHAR(MAX) = N'SELECT em.StaffID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName FROM EmployeeMaster em INNER JOIN Staff_Master sm ON em.StaffID = sm.Staff_ID WHERE em.IsHold = 1 AND em.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND em.IsDeleted = 0 AND sm.IsDeleted = 0 AND sm.StaffStatus_ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (376, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q377 | Who's missing from school today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who''s missing from school today?',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName FROM StudentAttendance sa INNER JOIN Student_Master sm ON sa.Student_ID = sm.ID INNER JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE sa.Attendance_Status_ID = 2 AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY cm.Name, sm.FirstName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (377, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q378 | Show me all fee collection details for student with admission number 2023001 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me all fee collection details for student with admission number 2023001',
        @sql NVARCHAR(MAX) = N'SELECT fc.Bill_No, fc.Bill_Date, fc.Receipt_Amt, cmm.Name, fc.Collected_By_Name, fcd.FeesType_Name, fcd.Fees_Amount, fcd.Paid_Amt, fcd.Remaining_Amt, fcd.Concession_Amount FROM FeesCollection fc INNER JOIN FeesCollection_Details fcd ON fc.Id = fcd.Fees_Collection_ID LEFT JOIN CollectionMode_Master cmm ON fc.Collection_Mode_ID = cmm.ID WHERE fc.Admission_No = ''2023001'' AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY fc.Bill_Date, fcd.FeesType_Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (378, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q379 | List enquiries that came from newspaper advertisements. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List enquiries that came from newspaper advertisements.',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT CallRefNo, Student_Name, Parent_Name, MobileNo1, CallDate FROM GeneralCallRegister em INNER JOIN Enquiry_Mode_Master emm ON em.Mode_ID = emm.ID WHERE emm.Name = ''Newspaper'' AND em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND em.IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (379, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q380 | Has salary been generated for this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Has salary been generated for this month?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS GeneratedCount, gsm.MonthName FROM GenerateSalary_Master gsm WHERE gsm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gsm.IsDeleted = 0 AND gsm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gsm.BranchID) GROUP BY gsm.MonthName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (380, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q381 | How many salary paid for the current academic year are there? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many salary paid for the current academic year are there?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(gem.NetPay) AS TotalPaid FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID INNER JOIN Branch_Academic_Details b ON gm.AcademicYearID = b.Id WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND GETDATE() BETWEEN b.Start_Date AND b.End_Date AND gm.IsDeleted = 0 AND gem.IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (381, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q382 | TC comparison - this year vs last year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'TC comparison - this year vs last year',
        @sql NVARCHAR(MAX) = N'SELECT ''Current Year'' AS Period, COUNT(*) AS TCsIssued FROM TCRequest WHERE TC_Status = ''Issued'' AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (IsDeleted IS NULL OR IsDeleted = 0) UNION ALL SELECT ''Previous Year'' AS Period, COUNT(*) AS TCsIssued FROM TCRequest WHERE TC_Status = ''Issued'' AND AcademicYearID IN (SELECT PreviousYearID FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (IsDeleted IS NULL OR IsDeleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (382, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q383 | So, what's the net demand after concessions for the academic year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, what''s the net demand after concessions for the academic year?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(f.Amount - ISNULL(f.Concession_Amt, 0)) AS NetDemand FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (383, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q384 | Show class-wise student count along with fee demand and outstanding. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show class-wise student count along with fee demand and outstanding.',
        @sql NVARCHAR(MAX) = N'SELECT sad.ClassName, COUNT(DISTINCT sad.StudentID) AS StudentCount, SUM(f.Amount) AS FeeDemand, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM StudentAcademicDetail sad LEFT JOIN FeesInformationStudentDetail f ON sad.StudentID = f.Student_ID AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND sad.IsTCIssued = 0 GROUP BY sad.ClassName ORDER BY sad.ClassName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (384, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q385 | Hey, what's the total fee demand for the current academic year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the total fee demand for the current academic year?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(f.Amount) AS TotalDemand FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (385, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q386 | I need to see the quarter-wise enquiry count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see the quarter-wise enquiry count',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT DATEPART(QUARTER, CallDate) AS Quarter, COUNT(*) AS EnquiryCount FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0 GROUP BY DATEPART(QUARTER, CallDate) ORDER BY Quarter;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (386, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q387 | Let me see class-wise application distribution ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see class-wise application distribution',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassApplied, COUNT(*) AS Applications FROM ApplicationEntry ae INNER JOIN ClassMaster cm ON ae.Student_ClassID = cm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) GROUP BY cm.Name ORDER BY Applications DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (387, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q388 | Which students are consistently absent for more than 3 consecutive days? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which students are consistently absent for more than 3 consecutive days?',
        @sql NVARCHAR(MAX) = N'WITH AbsentDays AS (SELECT sa.Student_ID, sa.Attendance_Date, ROW_NUMBER() OVER (PARTITION BY sa.Student_ID ORDER BY sa.Attendance_Date) - DATEDIFF(DAY, ''2000-01-01'', sa.Attendance_Date) AS Grp FROM StudentAttendance sa JOIN Branch_Academic_Details bad ON sa.AcademicYearID = bad.Id WHERE sa.Attendance_Status_ID = 2 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))), ConsecutiveAbsent AS (SELECT Student_ID, COUNT(*) AS ConsecutiveDays, MIN(Attendance_Date) AS StartDate, MAX(Attendance_Date) AS EndDate FROM AbsentDays GROUP BY Student_ID, Grp HAVING COUNT(*) > 3) SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, ca.ConsecutiveDays, ca.StartDate, ca.EndDate FROM ConsecutiveAbsent ca JOIN Student_Master sm ON ca.Student_ID = sm.ID ORDER BY ca.ConsecutiveDays DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (388, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q389 | I need the compare weekday vs weekend collections ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need the compare weekday vs weekend collections',
        @sql NVARCHAR(MAX) = N'SELECT CASE WHEN DATEPART(WEEKDAY, fc.Bill_Date) IN (1, 7) THEN ''Weekend'' ELSE ''Weekday'' END AS DayType, SUM(fc.Receipt_Amt) AS TotalCollection, COUNT(fc.Id) AS TransactionCount FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY CASE WHEN DATEPART(WEEKDAY, fc.Bill_Date) IN (1, 7) THEN ''Weekend'' ELSE ''Weekday'' END;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (389, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q390 | How many classes have less than 90% attendance today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many classes have less than 90% attendance today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS classes_below_90 FROM (SELECT cm.Name, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS pct FROM StudentAttendance sa JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name HAVING CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) < 90) AS t;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (390, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q391 | What is the total concession given term-wise? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total concession given term-wise?',
        @sql NVARCHAR(MAX) = N'SELECT f.Term_Name, SUM(ISNULL(f.Concession_Amt, 0)) AS TotalConcession FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Term_Name ORDER BY f.Term_Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (391, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q392 | What is the recovery rate for tuition fees specifically? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the recovery rate for tuition fees specifically?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(SUM(f.Paid_Amt) * 100.0 / NULLIF(SUM(f.Amount - ISNULL(f.Concession_Amt, 0)), 0), 2) AS TuitionRecoveryRate FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.Fees_Name LIKE ''%Tuition%'' AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (392, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q393 | Show me section-wise outstanding for the entire school. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me section-wise outstanding for the entire school.',
        @sql NVARCHAR(MAX) = N'SELECT ClassName, SectionName, SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY ClassName, SectionName ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (393, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q394 | Which students are waiting to receive their TC? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which students are waiting to receive their TC?',
        @sql NVARCHAR(MAX) = N'SELECT sad.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id INNER JOIN Student_Master stm ON sad.StudentID = stm.ID WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.IsActive = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (394, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q395 | How many students are present today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students are present today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS present_count FROM StudentAttendance sa WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.Attendance_Status_ID = 1 AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (395, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q396 | Rank classes by their fee collection amount ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Rank classes by their fee collection amount',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, SUM(fc.Receipt_Amt) AS TotalCollection, RANK() OVER (ORDER BY SUM(fc.Receipt_Amt) DESC) AS CollectionRank FROM FeesCollection fc JOIN ClassMaster cm ON fc.Class_ID = cm.ID JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name ORDER BY CollectionRank;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (396, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q397 | I need to see staff who joined in the last 3 months ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see staff who joined in the last 3 months',
        @sql NVARCHAR(MAX) = N'SELECT sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName, sm.Staff_DOJ FROM Staff_Master sm WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.Staff_DOJ >= DATEADD(MONTH, -3, GETDATE());',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (397, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q398 | Who paid more than 50000 in a single receipt? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who paid more than 50000 in a single receipt?',
        @sql NVARCHAR(MAX) = N'SELECT fc.Bill_No, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName, fc.Receipt_Amt, fc.Bill_Date FROM FeesCollection fc INNER JOIN Student_Master sm ON fc.Student_ID = sm.ID INNER JOIN StudentAcademicDetail sad ON fc.Student_ID = sad.StudentID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.Receipt_Amt > 50000 AND sad.IsActive = 1 AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) ORDER BY fc.Receipt_Amt DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (398, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q399 | Show vehicle capacity utilization. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show vehicle capacity utilization.',
        @sql NVARCHAR(MAX) = N'SELECT vm.Vehicle_Number, vm.Seating_Capacity, (SELECT COUNT(*) FROM StudentAcademicDetail sad WHERE sad.TransportRequired = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)))) AS TotalTransportStudents FROM VehicleMaster vm WHERE vm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND vm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (vm.IsDeleted = 0 OR vm.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (399, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q400 | Unpaid salary list dikhao ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Unpaid salary list dikhao',
        @sql NVARCHAR(MAX) = N'SELECT sm.Staff_ID AS StaffID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName FROM Staff_Master sm WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sm.IsDeleted = 0 AND sm.StaffStatus_ID = 1 AND NOT EXISTS (SELECT 1 FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gem.EmployeeID = sm.Staff_ID AND gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
PRINT 'checkpoint: reached Q400';
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (400, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q401 | Hey, what's the tuition fee outstanding across all classes? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the tuition fee outstanding across all classes?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS TuitionOutstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND Fees_Name LIKE ''%Tuition%'' AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (401, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q402 | Count of VIP students in the school ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Count of VIP students in the school',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS VIPCount FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sm.IsVIP = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (402, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q403 | Students who paid late fee in the last 3 months ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students who paid late fee in the last 3 months',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN FeesCollection fc ON sm.ID = fc.Student_ID INNER JOIN FeesCollection_Details fcd ON fc.Id = fcd.Fees_Collection_ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.LateFeeAmount > 0 AND fc.Bill_Date >= DATEADD(MONTH, -3, GETDATE()) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (403, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q404 | Just checking - how many staff were present yesterday by staff type? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many staff were present yesterday by staff type?',
        @sql NVARCHAR(MAX) = N'SELECT stm.Name AS StaffType, COUNT(*) AS PresentCount FROM Staff_Attendance sa INNER JOIN Staff_Master sm ON sa.Staff_ID = sm.Staff_ID AND sm.StaffStatus_ID = 1 INNER JOIN StaffType_Master stm ON sm.StaffType_ID = stm.ID WHERE CAST(sa.Attendance_Date AS DATE) = CAST(DATEADD(DAY,-1,GETDATE()) AS DATE) AND sa.Attendance_Status_ID = 1 AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY stm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (404, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q405 | Compare student strength across my branches ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare student strength across my branches',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS BranchName, COUNT(DISTINCT sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id JOIN BranchMaster bm ON bad.Branch_Id = bm.ID WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY StudentCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (405, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q406 | Fee defaulters in the OMR branch ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Fee defaulters in the OMR branch',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT ISNULL(sm.FirstName,'''') + '' '' + ISNULL(sm.MiddleName,'''') + '' '' + ISNULL(sm.LastName,'''') AS StudentName, (fisd.Amount - ISNULL(fisd.Concession_Amt,0) - ISNULL(fisd.Paid_Amt,0) - ISNULL(fisd.Lien_Amount,0)) AS Outstanding FROM FeesInformationStudentDetail fisd JOIN Student_Master sm ON fisd.Student_ID = sm.ID WHERE fisd.IsIncludedInLumpSum <> 1 AND fisd.IsDonation = 0 AND (fisd.Amount - ISNULL(fisd.Concession_Amt,0) - ISNULL(fisd.Paid_Amt,0) - ISNULL(fisd.Lien_Amount,0)) > 0 AND fisd.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%OMR%'' OR ShortName LIKE ''%OMR%'')) AND fisd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (406, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q407 | What is the year-wise GST amount collected? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the year-wise GST amount collected?',
        @sql NVARCHAR(MAX) = N'SELECT bad.Name AS AcademicYear, SUM(fcd.GSTAmount) AS TotalGST FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bad.Name ORDER BY bad.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (407, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q408 | Run me through this week's attendance ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Run me through this week''s attendance',
        @sql NVARCHAR(MAX) = N'SELECT CAST(sa.Attendance_Date AS DATE) AS AttendanceDate, COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) AS Present, COUNT(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 END) AS Absent FROM StudentAttendance sa WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.Attendance_Date >= DATEADD(DAY, 1 - DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE)) AND sa.Attendance_Date <= CAST(GETDATE() AS DATE) GROUP BY CAST(sa.Attendance_Date AS DATE) ORDER BY CAST(sa.Attendance_Date AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (408, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q409 | Count of students without religion information ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Count of students without religion information',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS CountWithoutReligion FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.Religion_Name IS NULL OR sm.Religion_Name = '''');',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (409, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q410 | What's the branch-wise attendance today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the branch-wise attendance today?',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS Present, SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END) AS Absent FROM StudentAttendance sa JOIN BranchMaster bm ON sa.BranchID = bm.ID WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY bm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (410, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q411 | Give me class-wise hostel student strength ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me class-wise hostel student strength',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(DISTINCT sad.StudentID) AS HostelStudents FROM StudentAcademicDetail sad JOIN ClassMaster cm ON sad.ClassID = cm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.HostelRequired = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name, cm.DisplayOrder ORDER BY cm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (411, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q412 | Hey, how many students were there in each year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many students were there in each year?',
        @sql NVARCHAR(MAX) = N'SELECT bad.Name AS AcademicYear, COUNT(DISTINCT sad.StudentID) AS TotalStudents FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bad.Name ORDER BY bad.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (412, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q413 | Hey, what's the collection trend over the last 30 days? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the collection trend over the last 30 days?',
        @sql NVARCHAR(MAX) = N'WITH dc AS (SELECT dm.ID, dm.DayClosureDate AS ClosureDate, dm.CollectedByName AS ClosedBy_Name, SUM(dmd.CollectedAmount) AS TotalCollection, SUM(CASE WHEN cmm.Name = ''Cash'' THEN dmd.CollectedAmount ELSE 0 END) AS CashCollection, SUM(CASE WHEN cmm.Name = ''Bank Online Transfer'' THEN dmd.CollectedAmount ELSE 0 END) AS OnlineCollection, SUM(CASE WHEN cmm.Name NOT IN (''Cash'', ''Bank Online Transfer'', ''Cheque'') THEN dmd.CollectedAmount ELSE 0 END) AS OtherCollection, SUM(CASE WHEN cmm.Name = ''Cheque'' THEN dmd.CollectedAmount ELSE 0 END) AS ChequeCollection FROM DayclosureMaster dm INNER JOIN DayclosureMaster_Details dmd ON dmd.HeaderID = dm.ID LEFT JOIN CollectionMode_Master cmm ON dmd.CollectionMode_ID = cmm.ID WHERE dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (dm.IsDeleted = 0 OR dm.IsDeleted IS NULL) AND (dmd.IsDeleted = 0 OR dmd.IsDeleted IS NULL) GROUP BY dm.ID, dm.DayClosureDate, dm.CollectedByName) SELECT CAST(ClosureDate AS DATE) AS ClosureDay, TotalCollection FROM dc WHERE ClosureDate >= DATEADD(DAY, -30, GETDATE()) ORDER BY ClosureDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (413, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q414 | So, how many boys and girls are there in each Class for transport students? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, how many boys and girls are there in each Class for transport students?',
        @sql NVARCHAR(MAX) = N'SELECT sad.ClassName, sm.Gender, COUNT(*) AS StudentCount FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.TransportRequired = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sad.ClassID, sad.ClassName, sm.Gender ORDER BY sad.ClassID, sm.Gender;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (414, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q415 | Days with no collection at all this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Days with no collection at all this month',
        @sql NVARCHAR(MAX) = N'SELECT CAST(d.DateValue AS DATE) AS NoCollectionDate FROM (SELECT DATEADD(DAY, number, DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)) AS DateValue FROM master.dbo.spt_values WHERE type = ''P'' AND number < DAY(GETDATE())) d WHERE NOT EXISTS (SELECT 1 FROM FeesCollection fc WHERE CAST(fc.Bill_Date AS DATE) = CAST(d.DateValue AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND DATEPART(WEEKDAY, d.DateValue) NOT IN (1) ORDER BY d.DateValue;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (415, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q416 | Attendance today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Attendance today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) AS PresentCount, COUNT(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 END) AS AbsentCount, COUNT(*) AS TotalMarked FROM StudentAttendance sa WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (416, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q417 | How many new admissions did we get each year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many new admissions did we get each year?',
        @sql NVARCHAR(MAX) = N'SELECT bad.Name AS AcademicYear, COUNT(DISTINCT sad.StudentID) AS NewAdmissions FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNewAdmission = 1 AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bad.Name ORDER BY bad.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (417, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q418 | Pull up collection from April month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up collection from April month',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS april_collection FROM FeesCollection fc WHERE DATEPART(MONTH, fc.Bill_Date) = 4 AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (418, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q419 | Show class-wise outstanding fees ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show class-wise outstanding fees',
        @sql NVARCHAR(MAX) = N'SELECT f.ClassName, SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS Outstanding FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY f.ClassName ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (419, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q420 | Give me the average age of students in enquiries ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the average age of students in enquiries',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT AVG(DATEDIFF(YEAR, DOB, GETDATE())) AS AvgAge FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND DOB IS NOT NULL;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (420, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q421 | What is the late fee collection rate this academic year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the late fee collection rate this academic year?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(CASE WHEN fcd.Remaining_Amt = 0 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS CollectionRatePercent FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.LateFeeAmount > 0 AND (fc.IsDeleted = 0 OR fc.IsDeleted IS NULL) AND fc.ChequeStatus_ID NOT IN (3, 4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (421, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q422 | Can I see the transport vs non-transport student ratio? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can I see the transport vs non-transport student ratio?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CASE WHEN TransportRequired = 1 THEN 1 ELSE 0 END) AS TransportUsers, SUM(CASE WHEN TransportRequired = 0 OR TransportRequired IS NULL THEN 1 ELSE 0 END) AS NonTransportUsers, CAST(SUM(CASE WHEN TransportRequired = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS TransportPercentage FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (422, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q423 | Total online collection this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total online collection this year',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS OnlineCollection FROM FeesCollection fc WHERE fc.Collection_Mode_ID IN (SELECT ID FROM CollectionMode_Master WHERE Name = ''Bank Online Transfer'') AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (423, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q424 | Absentees in the last 7 days ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Absentees in the last 7 days',
        @sql NVARCHAR(MAX) = N'SELECT sa.Attendance_Date, COUNT(sa.Student_ID) AS AbsentCount FROM StudentAttendance sa WHERE sa.Attendance_Date >= DATEADD(DAY, -7, CAST(GETDATE() AS DATE)) AND sa.Attendance_Date <= CAST(GETDATE() AS DATE) AND sa.Attendance_Status_ID = 2 AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sa.Attendance_Date ORDER BY sa.Attendance_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (424, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q425 | How much more did we collect this year compared to last year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much more did we collect this year compared to last year?',
        @sql NVARCHAR(MAX) = N'SELECT curr.ThisYear, prev.LastYear, curr.ThisYear - prev.LastYear AS Difference, CAST((curr.ThisYear - prev.LastYear) * 100.0 / NULLIF(prev.LastYear, 0) AS DECIMAL(10,2)) AS GrowthPercent FROM (SELECT SUM(fc.Receipt_Amt) AS ThisYear FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) curr, (SELECT SUM(fc.Receipt_Amt) AS LastYear FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE bad.Id = (SELECT PreviousYearID FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = bad.Branch_Id) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) prev;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (425, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q426 | What is the outstanding for the month of June? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the outstanding for the month of June?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS JuneOutstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.Month_Name = ''June'' AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (426, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q427 | Hey, how many students have both transport and hostel required? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many students have both transport and hostel required?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS BothRequired FROM StudentAcademicDetail WHERE TransportRequired = 1 AND HostelRequired = 1 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND IsActive = 1 AND IsTCIssued = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (427, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q428 | How many employees are currently active? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many employees are currently active?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS ActiveStaff FROM Staff_Master sm WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (428, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q429 | Class 6 Section B attendance for this week ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class 6 Section B attendance for this week',
        @sql NVARCHAR(MAX) = N'SELECT CAST(sa.Attendance_Date AS DATE) AS AttDate, COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) AS Present, COUNT(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 END) AS Absent FROM StudentAttendance sa INNER JOIN ClassMaster cm ON sa.Class_ID = cm.ID INNER JOIN SectionMaster secm ON sa.Section_ID = secm.ID WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.Name IN (''Class 6'', ''VI'') AND secm.Name = ''B'' AND sa.Attendance_Date >= DATEADD(DAY, 1 - DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE)) GROUP BY CAST(sa.Attendance_Date AS DATE) ORDER BY CAST(sa.Attendance_Date AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (429, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q430 | Cash collection this month for Avadi branch ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Cash collection this month for Avadi branch',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fc.Receipt_Amt) AS CashCollection FROM FeesCollection fc WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.Collection_Mode_ID IN (SELECT ID FROM CollectionMode_Master WHERE Name = ''Cash'') AND DATEPART(MONTH, fc.Bill_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, fc.Bill_Date) = DATEPART(YEAR, GETDATE()) AND fc.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%Avadi%'' OR ShortName LIKE ''%Avadi%'')) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (430, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q431 | How many students were admitted versus how many left this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students were admitted versus how many left this year?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT CASE WHEN sad.IsNewAdmission = 1 THEN sad.StudentID END) AS Admitted, COUNT(DISTINCT CASE WHEN sad.IsTCIssued = 1 THEN sad.StudentID END) AS StudentsLeft, COUNT(DISTINCT CASE WHEN sad.IsNewAdmission = 1 THEN sad.StudentID END) - COUNT(DISTINCT CASE WHEN sad.IsTCIssued = 1 THEN sad.StudentID END) AS NetChange FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (431, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q432 | How many vehicles do we have? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many vehicles do we have?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalVehicles FROM VehicleMaster WHERE (IsDeleted IS NULL OR IsDeleted = 0) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (432, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q433 | Fee type wise outstanding amount ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Fee type wise outstanding amount',
        @sql NVARCHAR(MAX) = N'SELECT f.FeesType_Name, SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS Outstanding FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY f.FeesType_Name ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (433, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q434 | Show the oldest unresolved tickets. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the oldest unresolved tickets.',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 ft.TicketNo, ft.Subject, ft.ContactName AS Parent_Name, ft.Created_Date AS CreatedDate, DATEDIFF(DAY, ft.Created_Date, GETDATE()) AS DaysOpen, esc.IsEscalated FROM FeedbackTicket ft OUTER APPLY (SELECT MAX(ftr.RepliedOn) AS LastReplyDate FROM FeedbackTicketReplies ftr WHERE ftr.TicketID = ft.Id) rp OUTER APPLY (SELECT CASE WHEN EXISTS (SELECT 1 FROM FeedbackEscalationMatrix fem WHERE fem.FeedbackCategoryID = ft.CategoryID AND DATEDIFF(HOUR, ft.Created_Date, ISNULL(rp.LastReplyDate, GETDATE())) > fem.EscalationHours) THEN 1 ELSE 0 END AS IsEscalated) esc WHERE ft.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ft.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY ft.Created_Date ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (434, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q435 | Subject-wise average marks ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Subject-wise average marks',
        @sql NVARCHAR(MAX) = N'SELECT s.Name AS Subject, CAST(AVG(smd.Marks) AS DECIMAL(5,2)) AS AvgMarks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN Subject_Master s ON s.BranchID = smd.BranchID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND s.IsDeleted = 0 GROUP BY s.Name ORDER BY AvgMarks DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (435, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q436 | Students owing more than 1 lakh ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students owing more than 1 lakh',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName, SUM(fcd.Remaining_Amt) AS TotalOutstanding FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN Student_Master sm ON fc.Student_ID = sm.ID INNER JOIN StudentAcademicDetail sad ON fc.Student_ID = sad.StudentID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY sm.AdmissionNo, sm.FirstName, sm.MiddleName, sm.LastName, cm.Name HAVING SUM(fcd.Remaining_Amt) > 100000 ORDER BY SUM(fcd.Remaining_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (436, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q437 | What are the classes with recovery rate below 50%? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What are the classes with recovery rate below 50%?',
        @sql NVARCHAR(MAX) = N'SELECT f.ClassName, ROUND(SUM(f.Paid_Amt) * 100.0 / NULLIF(SUM(f.Amount - ISNULL(f.Concession_Amt, 0)), 0), 2) AS RecoveryRate FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.ClassName HAVING SUM(f.Paid_Amt) * 100.0 / NULLIF(SUM(f.Amount - ISNULL(f.Concession_Amt, 0)), 0) < 50 ORDER BY RecoveryRate ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (437, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q438 | Can you list out all unpaid late fees for Class 10 students? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you list out all unpaid late fees for Class 10 students?',
        @sql NVARCHAR(MAX) = N'SELECT SM.FirstName + '' '' + SM.LastName AS StudentName, lfd.Amount - ISNULL(lfc.Concession_Amount, 0) AS NetPayable FROM FeesInformationStudentDetail FI INNER JOIN LateFeeMaster lfm ON lfm.TermId = FI.Term_ID AND lfm.IsActive = 1 AND CAST(GETDATE() AS DATE) <= lfm.ValidityDate AND CAST(GETDATE() AS DATE) >= lfm.LastDate INNER JOIN LateFeeDetails lfd ON lfm.ID = lfd.LateFeeID AND (lfd.ClassId = FI.ClassID OR lfd.ClassId = 0) AND CAST(GETDATE() AS DATE) BETWEEN lfd.FromDate AND lfd.ToDate INNER JOIN Fees_Master fmm ON fmm.ID = FI.Fees_ID AND ISNULL(fmm.IsIncludeinLateFee, 0) = 1 INNER JOIN Student_Master SM ON SM.ID = FI.Student_ID LEFT JOIN LateFee_Concession lfc ON lfc.Student_ID = FI.Student_ID AND lfc.LateFeeHeadId = lfm.LateFeeHeadId AND lfc.Term_ID = FI.Term_ID AND lfc.AcademicYearID = FI.AcademicYearID AND lfc.BranchID = FI.BranchID AND ISNULL(lfc.IsDeleted, 0) = 0 INNER JOIN StudentAcademicDetail SA ON FI.AcademicYearID = SA.AcademicYearID AND SA.StudentID = FI.Student_ID INNER JOIN ClassMaster CM ON CM.ID = SA.ClassID WHERE CM.Name IN (''Class 10'', ''X'') AND FI.IsIncludedInLumpSum <> 1 AND FI.IsDonation = 0 AND (FI.Amount - ISNULL(FI.Concession_Amt,0) - FI.Paid_Amt - FI.Lien_Amount) > 0 AND CAST(SM.AdmissionDate AS DATE) < lfd.FromDate AND (lfd.Amount - ISNULL(lfc.Concession_Amount, 0)) > 0 AND FI.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (438, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q439 | Collection for Term 1 only ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Collection for Term 1 only',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fcd.Paid_Amt) AS Term1Collection FROM FeesCollection_Details fcd WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.Term_ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (439, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q440 | Top 5 classes by fee collection ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Top 5 classes by fee collection',
        @sql NVARCHAR(MAX) = N'SELECT TOP 5 cm.Name AS ClassName, SUM(fc.Receipt_Amt) AS TotalCollection FROM FeesCollection fc INNER JOIN ClassMaster cm ON fc.Class_ID = cm.ID WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY cm.Name ORDER BY SUM(fc.Receipt_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (440, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q441 | VIP students who have remaining fee balance ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'VIP students who have remaining fee balance',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName + '' '' + sm.LastName AS StudentName, SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN Student_Master sm ON f.Student_ID = sm.ID WHERE sm.IsVIP = 1 AND f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.FirstName, sm.LastName HAVING SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) > 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (441, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q442 | Staff attendance vs salary correlation ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff attendance vs salary correlation',
        @sql NVARCHAR(MAX) = N'SELECT gem.EmployeeID AS StaffID, gem.EmployeeName AS StaffName, gem.NetPay AS NetSalary, gem.PresentDays AS DaysPresent, (gem.WorkingDays - gem.PresentDays) AS DaysAbsent FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) ORDER BY (gem.WorkingDays - gem.PresentDays) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (442, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q443 | Total number of active and hold staff separately ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total number of active and hold staff separately',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CASE WHEN em.IsHold = 0 OR em.IsHold IS NULL THEN 1 ELSE 0 END) AS ActiveStaff, SUM(CASE WHEN em.IsHold = 1 THEN 1 ELSE 0 END) AS HoldStaff FROM Staff_Master sm LEFT JOIN EmployeeMaster em ON sm.Staff_ID = em.StaffID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (443, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q444 | Classes that have no new admissions this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Classes that have no new admissions this year',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName FROM ClassMaster cm WHERE cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND cm.IsDeleted = 0 AND cm.ID NOT IN (SELECT DISTINCT sad.ClassID FROM StudentAcademicDetail sad WHERE sad.IsNewAdmission = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (444, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q445 | How much fees collected this year in total? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much fees collected this year in total?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS YearCollection FROM FeesCollection fc WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (445, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q446 | Who has the most absences this academic year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who has the most absences this academic year?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 5 sa.Staff_ID, COUNT(*) AS AbsentDays FROM Staff_Attendance sa INNER JOIN Staff_Master sm ON sa.Staff_ID = sm.Staff_ID AND sm.StaffStatus_ID = 1 INNER JOIN Branch_Academic_Details b ON sa.AcademicYearID = b.Id WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND GETDATE() BETWEEN b.Start_Date AND b.End_Date AND sa.Attendance_Status_ID = 2 GROUP BY sa.Staff_ID, sm.Staff_FirstName, sm.Staff_LastName ORDER BY AbsentDays DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (446, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q447 | What is the total demand for KG classes (LKG, UKG)? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total demand for KG classes (LKG, UKG)?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(f.Amount) AS KGDemand FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.ClassName IN (''LKG'', ''UKG'') AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (447, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q448 | I need recently rejected applications with details ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need recently rejected applications with details',
        @sql NVARCHAR(MAX) = N'SELECT TOP 20 ae.ApplicationNo, ae.FirstName + ISNULL('' '' + ae.MiddleName, '''') + '' '' + ae.LastName AS StudentName, ae.FatherName, ae.ComMobile AS Phone, cm.Name AS ClassApplied, ae.ApplicationDate FROM ApplicationEntry ae INNER JOIN ClassMaster cm ON ae.Student_ClassID = cm.ID INNER JOIN ApplicationStatus_Master asm ON ae.ApplicationStatus_ID = asm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) AND asm.Name = ''Rejected'' ORDER BY ae.ApplicationDate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (448, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q449 | So, what's the total outstanding fee amount for the school? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, what''s the total outstanding fee amount for the school?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS TotalOutstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (449, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q450 | Which drivers have licenses expiring in the next 30 days? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which drivers have licenses expiring in the next 30 days?',
        @sql NVARCHAR(MAX) = N'SELECT Name, Mobile, License_Number, License_Expiry_Date FROM DriverMaster WHERE License_Expiry_Date BETWEEN GETDATE() AND DATEADD(DAY, 30, GETDATE()) AND IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (450, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q451 | How much collection was done for June fees? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much collection was done for June fees?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fcd.Paid_Amt), 0) AS june_fees_collected FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fcd.Fees_Month = ''June'' AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (451, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q452 | Show the concession impact on bus fees vs non-bus fees. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the concession impact on bus fees vs non-bus fees.',
        @sql NVARCHAR(MAX) = N'SELECT CASE WHEN IsBusFee = 1 THEN ''Bus Fee'' ELSE ''Non-Bus Fee'' END AS FeeCategory, SUM(ISNULL(Concession_Amt, 0)) AS ConcessionGiven, SUM(Amount) AS TotalDemand, ROUND(SUM(ISNULL(Concession_Amt, 0)) * 100.0 / NULLIF(SUM(Amount), 0), 2) AS ConcessionPct FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY CASE WHEN IsBusFee = 1 THEN ''Bus Fee'' ELSE ''Non-Bus Fee'' END;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (452, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q453 | Can you show today's late fee collections? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show today''s late fee collections?',
        @sql NVARCHAR(MAX) = N'SELECT fc.Bill_No, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, fcd.LateFeeAmount FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN Student_Master sm ON fc.Student_ID = sm.ID WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.LateFeeAmount > 0 AND CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (453, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q454 | Compare this year admissions across branches ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare this year admissions across branches',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, COUNT(*) AS Admissions FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN BranchMaster bm ON sm.BranchID = bm.ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY Admissions DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (454, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q455 | How many new enquiries are pending? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many new enquiries are pending?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS NewEnquiries FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND CallStatus_ID IN (SELECT ID FROM Enquiry_Status_Master WHERE Name = ''Initiated'');',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (455, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q456 | Pull up days with zero online collection ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up days with zero online collection',
        @sql NVARCHAR(MAX) = N'WITH dc AS (SELECT dm.ID, dm.DayClosureDate AS ClosureDate, dm.CollectedByName AS ClosedBy_Name, SUM(dmd.CollectedAmount) AS TotalCollection, SUM(CASE WHEN cmm.Name = ''Cash'' THEN dmd.CollectedAmount ELSE 0 END) AS CashCollection, SUM(CASE WHEN cmm.Name = ''Bank Online Transfer'' THEN dmd.CollectedAmount ELSE 0 END) AS OnlineCollection, SUM(CASE WHEN cmm.Name NOT IN (''Cash'', ''Bank Online Transfer'', ''Cheque'') THEN dmd.CollectedAmount ELSE 0 END) AS OtherCollection, SUM(CASE WHEN cmm.Name = ''Cheque'' THEN dmd.CollectedAmount ELSE 0 END) AS ChequeCollection FROM DayclosureMaster dm INNER JOIN DayclosureMaster_Details dmd ON dmd.HeaderID = dm.ID LEFT JOIN CollectionMode_Master cmm ON dmd.CollectionMode_ID = cmm.ID WHERE dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (dm.IsDeleted = 0 OR dm.IsDeleted IS NULL) AND (dmd.IsDeleted = 0 OR dmd.IsDeleted IS NULL) GROUP BY dm.ID, dm.DayClosureDate, dm.CollectedByName) SELECT CAST(ClosureDate AS DATE) AS ClosureDay, TotalCollection, CashCollection FROM dc WHERE (OnlineCollection = 0 OR OnlineCollection IS NULL) ORDER BY ClosureDate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (456, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q457 | How many staff members are in each department? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many staff members are in each department?',
        @sql NVARCHAR(MAX) = N'SELECT dm.Name AS Department, COUNT(DISTINCT sdmd.StaffID) AS StaffCount FROM StaffDepartmentMapping sdm INNER JOIN StaffDepartmentMappingDetail sdmd ON sdm.Id = sdmd.MappingID INNER JOIN StaffDepartmentMaster dm ON sdm.DepartmentID = dm.Id WHERE sdm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sdm.IsDeleted = 0 OR sdm.IsDeleted IS NULL) GROUP BY dm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (457, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q458 | How many boarding points do we have in total? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many boarding points do we have in total?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalBoardingPoints FROM Route_Master rm INNER JOIN Route_MasterDetails rmd ON rm.ID = rmd.Route_ID INNER JOIN BoardingPoint_Master bpm ON rmd.BoardingPoint_ID = bpm.Id WHERE rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND rm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (rm.IsDeleted = 0 OR rm.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (458, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q459 | Which enquiries have been in progress for more than 15 days? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which enquiries have been in progress for more than 15 days?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT CallRefNo, Parent_Name, Student_Name, MobileNo1, CallDate, DATEDIFF(DAY, CallDate, GETDATE()) AS DaysPending FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND CallStatus_ID IN (SELECT ID FROM Enquiry_Status_Master WHERE Name = ''In Progress'') AND DATEDIFF(DAY, CallDate, GETDATE()) > 15 ORDER BY CallDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (459, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q460 | Show collector-wise collection for today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show collector-wise collection for today',
        @sql NVARCHAR(MAX) = N'SELECT fc.Collected_By_Name, SUM(fc.Receipt_Amt) AS amount_collected, COUNT(*) AS receipts FROM FeesCollection fc WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fc.Collected_By_Name ORDER BY SUM(fc.Receipt_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (460, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q461 | Which branch has the best attendance percentage today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which branch has the best attendance percentage today?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 bm.Name AS Branch, CAST(100.0 * SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AttendancePct FROM StudentAttendance sa JOIN BranchMaster bm ON sa.BranchID = bm.ID WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY AttendancePct DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (461, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q462 | Let me see application numbers per status per class ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see application numbers per status per class',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, SUM(CASE WHEN asm.Name = ''Application Submitted'' THEN 1 ELSE 0 END) AS Submitted, SUM(CASE WHEN asm.Name = ''Shortlisted'' THEN 1 ELSE 0 END) AS Shortlisted, SUM(CASE WHEN asm.Name = ''Called For Interview'' THEN 1 ELSE 0 END) AS CalledForInterview, SUM(CASE WHEN asm.Name = ''Interview Completed'' THEN 1 ELSE 0 END) AS InterviewCompleted, SUM(CASE WHEN asm.Name = ''Selection letter Sent'' THEN 1 ELSE 0 END) AS SelectionLetterSent, SUM(CASE WHEN asm.Name = ''Admitted'' THEN 1 ELSE 0 END) AS Admitted, SUM(CASE WHEN asm.Name = ''Rejected'' THEN 1 ELSE 0 END) AS Rejected FROM ApplicationEntry ae INNER JOIN ClassMaster cm ON ae.Student_ClassID = cm.ID INNER JOIN ApplicationStatus_Master asm ON ae.ApplicationStatus_ID = asm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) GROUP BY cm.Name ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (462, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q463 | Anything unusual with collections this week compared to last? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Anything unusual with collections this week compared to last?',
        @sql NVARCHAR(MAX) = N'SELECT ''This Week'' AS Period, ISNULL(SUM(fc.Receipt_Amt), 0) AS Collection FROM FeesCollection fc WHERE fc.Bill_Date >= DATEADD(DAY, 1-DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE)) AND fc.Bill_Date <= CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) UNION ALL SELECT ''Last Week'' AS Period, ISNULL(SUM(fc.Receipt_Amt), 0) AS Collection FROM FeesCollection fc WHERE fc.Bill_Date >= DATEADD(DAY, -6-DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE)) AND fc.Bill_Date < DATEADD(DAY, 1-DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE)) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (463, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q464 | Percentage of new admissions vs total ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Percentage of new admissions vs total',
        @sql NVARCHAR(MAX) = N'SELECT CAST(COUNT(CASE WHEN sad.IsNewAdmission = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS NewAdmissionPercent FROM StudentAcademicDetail sad WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (464, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q465 | Show class-wise attendance for today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show class-wise attendance for today',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS class_name, SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS present, SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END) AS absent, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS pct FROM StudentAttendance sa JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (465, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q466 | What's the students in SC/ST community? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the students in SC/ST community?',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.Community_Name, cm.Name AS ClassName FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (sm.Community_Name LIKE ''%SC%'' OR sm.Community_Name LIKE ''%ST%'') AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (466, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q467 | Class-wise late fee collection amount ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class-wise late fee collection amount',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, SUM(fcd.LateFeeAmount) AS LateFeeCollected FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN ClassMaster cm ON fc.Class_ID = cm.ID JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name, cm.DisplayOrder ORDER BY cm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (467, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q468 | Total number of defaulters ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total number of defaulters',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT fc.Student_ID) AS total_defaulters FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN StudentAcademicDetail sad ON fc.Student_ID = sad.StudentID AND fc.AcademicYearID = sad.AcademicYearID WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fcd.Remaining_Amt > 0 AND sad.IsActive = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (468, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q469 | So, how many circulars target all classes? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, how many circulars target all classes?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS AllClassCirculars FROM CircularEntry WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND (Class_ID IS NULL OR Class_ID = '''' OR CircularApplicableFor = ''All'');',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (469, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q470 | What's the fee collection per active student? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the fee collection per active student?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(SUM(fc.Receipt_Amt) * 1.0 / NULLIF(COUNT(DISTINCT fc.Student_ID), 0), 2) AS AvgCollectionPerStudent FROM FeesCollection fc WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (470, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q471 | Staff children performance in exams ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff children performance in exams',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID AS StudentID, sm.FirstName, sm.LastName, CAST(AVG(smd.Marks) AS DECIMAL(5,2)) AS AvgMarks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN Student_Master sm ON smd.StudentID = sm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND sm.StaffChild = 1 GROUP BY sm.ID, sm.FirstName, sm.LastName ORDER BY AvgMarks DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (471, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q472 | Year ka total collection bata do ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Year ka total collection bata do',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fc.Receipt_Amt) AS YearlyCollection FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (472, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q473 | I need the staff type wise salary expenditure ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need the staff type wise salary expenditure',
        @sql NVARCHAR(MAX) = N'SELECT gm.StaffTypeName, SUM(gem.NetPay) AS TotalSalary FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) GROUP BY gm.StaffTypeName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (473, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q474 | How many total students' attendance was marked today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many total students'' attendance was marked today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS total_marked FROM StudentAttendance sa WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (474, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q475 | List top 10 defaulters who have not paid anything in Term 2. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List top 10 defaulters who have not paid anything in Term 2.',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 f.Student_ID, s.FirstName + '' '' + ISNULL(s.LastName, '''') AS StudentName, f.ClassName, s.FatherContactNo, SUM(f.Amount) AS Demand FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID INNER JOIN Student_Master s ON f.Student_ID = s.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.Term_Name IN (''Term 2'', ''II'') AND f.Paid_Amt = 0 AND f.Amount > 0 AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Student_ID, s.FirstName, s.LastName, f.ClassName, s.FatherContactNo ORDER BY Demand DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (475, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q476 | Biggest defaulter in the school? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Biggest defaulter in the school?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName, SUM(fcd.Remaining_Amt) AS TotalOutstanding FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN Student_Master sm ON fc.Student_ID = sm.ID INNER JOIN StudentAcademicDetail sad ON fc.Student_ID = sad.StudentID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.Remaining_Amt > 0 AND sad.IsActive = 1 GROUP BY sm.AdmissionNo, sm.FirstName, sm.MiddleName, sm.LastName, cm.Name ORDER BY SUM(fcd.Remaining_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (476, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q477 | So, what's the total tuition fee outstanding? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, what''s the total tuition fee outstanding?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS TuitionOutstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.Fees_Name LIKE ''%Tuition%'' AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (477, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q478 | Hey, what's the total concession given for bus fees? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the total concession given for bus fees?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(ISNULL(f.Concession_Amt, 0)) AS BusFeeConcession FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.IsBusFee = 1 AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (478, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q479 | What is the fee collection by payment mode for this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the fee collection by payment mode for this month?',
        @sql NVARCHAR(MAX) = N'SELECT cmm.Name AS PaymentMode, COUNT(fc.Id) AS TransactionCount, SUM(fc.Receipt_Amt) AS TotalAmount FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id LEFT JOIN CollectionMode_Master cmm ON fc.Collection_Mode_ID = cmm.ID WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND MONTH(fc.Bill_Date) = MONTH(GETDATE()) AND YEAR(fc.Bill_Date) = YEAR(GETDATE()) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cmm.Name ORDER BY TotalAmount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (479, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q480 | Can you show circulars targeted to specific classes? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show circulars targeted to specific classes?',
        @sql NVARCHAR(MAX) = N'SELECT ce.Title, ce.Class_ID AS ClassIDs, ce.Class_Name, ce.CircularApplicableFor AS TargetAudience, ce.Circular_Date, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS CreatedBy_Name FROM CircularEntry ce LEFT JOIN Staff_Master sm ON ce.Created_By = sm.Staff_ID WHERE ce.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ce.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND ce.Class_ID IS NOT NULL AND ce.Class_ID != '''' AND (ce.IsDeleted = 0 OR ce.IsDeleted IS NULL) ORDER BY ce.Created_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (480, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q481 | Boys vs girls average marks comparison ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Boys vs girls average marks comparison',
        @sql NVARCHAR(MAX) = N'SELECT sm.Gender, CAST(AVG(pc.Marks) AS DECIMAL(5,2)) AS AvgMarks FROM ProgressCardDataRetrieval pc INNER JOIN Student_Master sm ON pc.StudentID = sm.ID WHERE pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) GROUP BY sm.Gender;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (481, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q482 | Can you show me staff count by salary structure? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show me staff count by salary structure?',
        @sql NVARCHAR(MAX) = N'SELECT SalaryStructureID, COUNT(*) AS StaffCount FROM EmployeeMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0 GROUP BY SalaryStructureID ORDER BY StaffCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (482, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q483 | Students failing in both Maths and Science ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students failing in both Maths and Science',
        @sql NVARCHAR(MAX) = N'SELECT q.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName FROM (SELECT m.StudentID FROM (SELECT smd.StudentID FROM StudentMarkDetails smd INNER JOIN ExamConfigurationEvaluationDetails eced ON smd.EvalHierID = eced.ID INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN Subject_Master s ON s.BranchID = smd.BranchID INNER JOIN Student_Master stm ON smd.StudentID = stm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND s.Name = ''Maths'' AND smd.Marks < eced.MinMark) m INNER JOIN (SELECT smd.StudentID FROM StudentMarkDetails smd INNER JOIN ExamConfigurationEvaluationDetails eced ON smd.EvalHierID = eced.ID INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN Subject_Master s ON s.BranchID = smd.BranchID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND s.Name = ''Science'' AND smd.Marks < eced.MinMark) sc ON m.StudentID = sc.StudentID) q INNER JOIN Student_Master stm ON q.StudentID = stm.ID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (483, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q484 | Average collection per branch this academic year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Average collection per branch this academic year',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, AVG(fc.Receipt_Amt) AS AvgReceipt FROM FeesCollection fc JOIN BranchMaster bm ON fc.BranchID = bm.ID WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY AvgReceipt DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (484, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q485 | List defaulters in Class 6 Section A with phone numbers. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List defaulters in Class 6 Section A with phone numbers.',
        @sql NVARCHAR(MAX) = N'SELECT f.Student_ID, s.FirstName + '' '' + ISNULL(s.LastName, '''') AS StudentName, s.FatherContactNo, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID INNER JOIN Student_Master s ON f.Student_ID = s.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.ClassName = ''Class 6'' AND f.SectionName = ''A'' AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Student_ID, s.FirstName, s.LastName, s.FatherContactNo HAVING SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 0 ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (485, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q486 | How many enquiries were closed or lost? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many enquiries were closed or lost?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS ClosedEnquiries FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND CallStatus_ID IN (SELECT ID FROM Enquiry_Status_Master WHERE Name = ''Dropped'');',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (486, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q487 | Show students who use transport but haven't paid bus fees. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show students who use transport but haven''t paid bus fees.',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT sm.ID, sm.FirstName, sm.LastName, sm.AdmissionNo FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN FeesInformationStudentDetail f ON sm.ID = f.Student_ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND sad.TransportRequired = 1 AND f.IsBusFee = 1 AND f.Paid_Amt = 0 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.IsActive = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (487, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q488 | Aaj kitna paisa aaya? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Aaj kitna paisa aaya?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS TodaysTotal FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (488, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q489 | How many girls are there in Class 10? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many girls are there in Class 10?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS GirlsCount FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE cm.Name IN (''Class 10'', ''X'') AND sm.Gender IN (''Female'', ''Girl'') AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (489, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q490 | How many cancelled fee receipts do we have this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many cancelled fee receipts do we have this month?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS CancelledThisMonth FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID = 4 AND MONTH(fc.Bill_Date) = MONTH(GETDATE()) AND YEAR(fc.Bill_Date) = YEAR(GETDATE());',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (490, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q491 | How much did each branch collect? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much did each branch collect?',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, ISNULL(SUM(fc.Receipt_Amt), 0) AS Collection FROM FeesCollection fc INNER JOIN BranchMaster bm ON fc.BranchID = bm.ID WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY Collection DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (491, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q492 | Class 3 students whose mother's name contains Priya ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class 3 students whose mother''s name contains Priya',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.MotherName FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.Name IN (''Class 3'', ''III'') AND sm.MotherName LIKE ''%Priya%'' AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (492, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q493 | Show me the top 10 highest paying students ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me the top 10 highest paying students',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName, SUM(fc.Receipt_Amt) AS TotalPaid FROM FeesCollection fc INNER JOIN Student_Master sm ON fc.Student_ID = sm.ID INNER JOIN StudentAcademicDetail sad ON fc.Student_ID = sad.StudentID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY sm.AdmissionNo, sm.FirstName, sm.MiddleName, sm.LastName, cm.Name ORDER BY SUM(fc.Receipt_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (493, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q494 | How many TC were issued last month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many TC were issued last month?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS TCIssued FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsTCIssued = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND MONTH(sad.TCIssuedDate) = MONTH(DATEADD(MONTH, -1, GETDATE())) AND YEAR(sad.TCIssuedDate) = YEAR(DATEADD(MONTH, -1, GETDATE())) AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (494, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q495 | How many admission enquiries this academic year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many admission enquiries this academic year?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalEnquiries FROM GeneralCallRegister WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (495, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q496 | Pull up term-wise demand, collected, and outstanding breakdown ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up term-wise demand, collected, and outstanding breakdown',
        @sql NVARCHAR(MAX) = N'SELECT f.Term_Name, SUM(f.Amount) AS Demand, SUM(f.Paid_Amt) AS Collected, SUM(ISNULL(f.Concession_Amt, 0)) AS Concession, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Term_Name ORDER BY f.Term_Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (496, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q497 | So, how many students are preparing for NEET/JEE? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, how many students are preparing for NEET/JEE?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS NEETJEE_Students FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNEETJEE = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (497, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q498 | Give me the staff strength ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the staff strength',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalStaff FROM Staff_Master sm WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (498, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q499 | Students absent today who also have more than 20000 outstanding ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students absent today who also have more than 20000 outstanding',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT f.Student_ID, sm.FirstName + '' '' + sm.LastName AS StudentName FROM FeesInformationStudentDetail f INNER JOIN Student_Master sm ON f.Student_ID = sm.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 20000 AND f.Student_ID IN (SELECT sa.Student_ID FROM StudentAttendance sa WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.Attendance_Status_ID = 2);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (499, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q500 | I need to see ticket status distribution ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see ticket status distribution',
        @sql NVARCHAR(MAX) = N'SELECT Status AS TicketStatus, COUNT(*) AS [Count] FROM FeedbackTicket WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY Status ORDER BY Status;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
PRINT 'checkpoint: reached Q500';
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (500, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ===================== PART 1 SUMMARY (Q1-Q500) =====================
DECLARE @lo INT = 1, @hi INT = 500, @fails INT;
SELECT @fails = COUNT(*) FROM #ai_errors WHERE qid BETWEEN @lo AND @hi;
PRINT 'PART 1 done: ' + CAST((@hi - @lo + 1) AS VARCHAR(6)) + ' queries, '
    + CAST(@fails AS VARCHAR(6)) + ' failed.';
DECLARE @qid INT, @qq NVARCHAR(300), @ee NVARCHAR(2048);
DECLARE c CURSOR LOCAL FAST_FORWARD FOR
    SELECT qid, question, error FROM #ai_errors WHERE qid BETWEEN @lo AND @hi ORDER BY qid;
OPEN c;
FETCH NEXT FROM c INTO @qid, @qq, @ee;
WHILE @@FETCH_STATUS = 0
BEGIN
    PRINT 'Q' + CAST(@qid AS VARCHAR(6)) + ' FAILED: ' + LEFT(@ee, 300);
    PRINT '   question: ' + LEFT(@qq, 200);
    FETCH NEXT FROM c INTO @qid, @qq, @ee;
END
CLOSE c; DEALLOCATE c;
SELECT qid, question, error, ms FROM #ai_errors WHERE qid BETWEEN @lo AND @hi ORDER BY qid;
GO

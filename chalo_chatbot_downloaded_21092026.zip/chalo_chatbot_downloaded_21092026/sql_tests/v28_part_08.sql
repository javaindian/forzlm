/* =====================================================================
   ChaloSchools AI Secretary - v28 dataset local test (SSMS)
   Part 8 of 9: queries Q3501 to Q4000 (500 of 4034 in the full dataset)
   Source: semantic_validation/reference_inputs/training_dataset_final_v28.jsonl
   Generated: 2026-09-04
   The SQL text is EXACTLY what the dataset holds (single quotes appear
   doubled inside the @sql string - T-SQL string escaping; multi-line
   queries keep line breaks, which SQL Server counts as whitespace).
   So any error you see here is an error the trained model would produce.

   ONE SETTING TO CHANGE BEFORE RUNNING:
     The queries are security-scoped to a user, like in production. They run
     as @UserId. Change it to YOUR local user id:
       Find & Replace across these files:   @UserId INT = 1
       (see your users with:  SELECT ID, UserName FROM UserAccountMaster;)
     @SelectedBranchId NULL = all branches you are allowed; put a branch id
       there to simulate one selected branch.

   RECOMMENDED for big runs (stops 500 result grids appearing):
     Query menu > Query Options... > Results > Grid >
     tick 'Discard results after execution', then Execute (F5).
     Everything still runs; errors + summary appear in the Messages tab.
   Failures (INCLUDING compile-time errors - bad syntax, unknown columns,
   unknown tables - thanks to the sp_executesql wrapper) are printed as:
     Q### FAILED: <error text>
        question: <the natural-language question>
   and stored in table #ai_errors until you close the connection.
   ===================================================================== */
SET NOCOUNT ON;
GO
IF OBJECT_ID('tempdb..#ai_errors') IS NULL
    CREATE TABLE #ai_errors (
        qid      INT NOT NULL PRIMARY KEY,
        question NVARCHAR(300),
        error    NVARCHAR(2048),
        ms       INT NOT NULL
    );
GO
-- ============ Q3501 | Which branch issued the most transfer certificates this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which branch issued the most transfer certificates this year?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 bm.Name AS Branch, COUNT(*) AS TCIssued FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN BranchMaster bm ON sm.BranchID = bm.ID WHERE sad.IsTCIssued = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY TCIssued DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3501, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3502 | How many salary structures exist? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many salary structures exist?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT SalaryStructureID) AS SalaryStructures FROM EmployeeMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3502, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3503 | What's today's attendance percentage? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s today''s attendance percentage?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS attendance_percentage FROM StudentAttendance sa WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3503, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3504 | What is the average salary for teaching staff? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the average salary for teaching staff?',
        @sql NVARCHAR(MAX) = N'SELECT AVG(gem.NetPay) AS AvgTeachingSalary FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) AND gm.StaffTypeName = ''Teaching'';',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3504, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3505 | Attendance rate for today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Attendance rate for today',
        @sql NVARCHAR(MAX) = N'SELECT CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AttendancePercent FROM StudentAttendance sa WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3505, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3506 | How many enquiries have no phone number? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many enquiries have no phone number?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS NoPhoneEnquiries FROM GeneralCallRegister WHERE (MobileNo1 IS NULL OR MobileNo1 = '''') AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3506, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3507 | Show enquiries handled by a specific staff member with HandledBy_Id = 5. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show enquiries handled by a specific staff member with HandledBy_Id = 5.',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT CallRefNo, Student_Name, Parent_Name, MobileNo1, CallDate, CallStatus_ID FROM GeneralCallRegister WHERE HandledBy_ID = 5 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3507, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3508 | Which students have completed the TC process and left? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which students have completed the TC process and left?',
        @sql NVARCHAR(MAX) = N'SELECT sad.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id INNER JOIN Student_Master stm ON sad.StudentID = stm.ID WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.IsTCIssued = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3508, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3509 | Hey, how many students got TC in the Royapuram branch? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many students got TC in the Royapuram branch?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TCIssued FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsTCIssued = 1 AND sm.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%Royapuram%'' OR ShortName LIKE ''%Royapuram%'')) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3509, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3510 | Let me see applications pending for more than 2 weeks ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see applications pending for more than 2 weeks',
        @sql NVARCHAR(MAX) = N'SELECT ae.ApplicationNo, ae.FirstName + ISNULL('' '' + ae.MiddleName, '''') + '' '' + ae.LastName AS StudentName, ae.FatherName, ae.ComMobile AS Phone, cm.Name AS ClassApplied, ae.ApplicationDate, DATEDIFF(DAY, ae.ApplicationDate, GETDATE()) AS DaysPending FROM ApplicationEntry ae INNER JOIN ClassMaster cm ON ae.Student_ClassID = cm.ID INNER JOIN ApplicationStatus_Master asm ON ae.ApplicationStatus_ID = asm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) AND asm.Name NOT IN (''Admitted'', ''Rejected'') AND DATEDIFF(DAY, ae.ApplicationDate, GETDATE()) > 14 ORDER BY ae.ApplicationDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3510, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3511 | Quick - how many absent today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Quick - how many absent today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS AbsentToday FROM Staff_Attendance WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND Attendance_Date = CAST(GETDATE() AS DATE) AND Attendance_Status_ID = 2;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3511, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3512 | What was yesterday's attendance? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What was yesterday''s attendance?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS present, SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END) AS absent, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS attendance_pct FROM StudentAttendance sa WHERE CAST(sa.Attendance_Date AS DATE) = CAST(DATEADD(DAY, -1, GETDATE()) AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3512, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3513 | Exam types under each term ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Exam types under each term',
        @sql NVARCHAR(MAX) = N'SELECT etm.Name AS Term, et.Name AS ExamType FROM ExamTypeMaster et INNER JOIN ExamTermMaster etm ON et.TermID = etm.ID WHERE et.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND et.IsDeleted = 0 AND etm.Deleted = 0 ORDER BY etm.Name, et.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3513, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3514 | List all staff departments ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all staff departments',
        @sql NVARCHAR(MAX) = N'SELECT Name AS Department FROM StaffDepartmentMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0 ORDER BY Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3514, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3515 | Can you list out staff who were present all days last week? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you list out staff who were present all days last week?',
        @sql NVARCHAR(MAX) = N'SELECT sa.Staff_ID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName FROM Staff_Attendance sa INNER JOIN Staff_Master sm ON sa.Staff_ID = sm.Staff_ID AND sm.StaffStatus_ID = 1 WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.Attendance_Date >= DATEADD(WEEK, -1, DATEADD(DAY, -DATEPART(WEEKDAY, GETDATE()) + 1, CAST(GETDATE() AS DATE))) AND sa.Attendance_Date < DATEADD(DAY, -DATEPART(WEEKDAY, GETDATE()) + 1, CAST(GETDATE() AS DATE)) GROUP BY sa.Staff_ID, sm.Staff_FirstName, sm.Staff_LastName HAVING SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END) = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3515, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3516 | How many students have both transport and hostel required? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students have both transport and hostel required?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS BothRequired FROM StudentAcademicDetail WHERE TransportRequired = 1 AND HostelRequired = 1 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND IsActive = 1 AND IsTCIssued = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3516, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3517 | What is the average number of enquiries per day this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the average number of enquiries per day this month?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT ROUND(CAST(COUNT(*) AS FLOAT) / DAY(GETDATE()), 2) AS AvgPerDay FROM GeneralCallRegister WHERE MONTH(CallDate) = MONTH(GETDATE()) AND YEAR(CallDate) = YEAR(GETDATE()) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3517, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3518 | Show fee-type-wise recovery rate. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show fee-type-wise recovery rate.',
        @sql NVARCHAR(MAX) = N'SELECT f.FeesType_Name, ROUND(SUM(f.Paid_Amt) * 100.0 / NULLIF(SUM(f.Amount - ISNULL(f.Concession_Amt, 0)), 0), 2) AS RecoveryRate FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.FeesType_Name ORDER BY RecoveryRate ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3518, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3519 | How many students scored above 90? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students scored above 90?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS Above90 FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND smd.Marks >= 90;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3519, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3520 | Book a meeting room for tomorrow ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Book a meeting room for tomorrow',
        @sql NVARCHAR(MAX) = N'-- This question asks me to perform an action (book a meeting room), which I cannot do. Meeting room management is also not tracked in this database.
SELECT ''Meeting room booking is not available in this system. Please ask about school data.'' AS Message;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3520, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3521 | How many of VIP students in the school are there? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many of VIP students in the school are there?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS VIPCount FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sm.IsVIP = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3521, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3522 | What's wrong with Class 8B's performance? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s wrong with Class 8B''s performance?',
        @sql NVARCHAR(MAX) = N'-- This question asks for a subjective analysis, which I cannot provide. I can only retrieve data.
-- Here''s Class 8B''s exam performance data:
SELECT pc.SubjectName, CAST(AVG(pc.Marks) AS DECIMAL(5,2)) AS AvgMarks, MIN(pc.Marks) AS Lowest, MAX(pc.Marks) AS Highest FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID INNER JOIN SectionMaster secm ON pc.SectionID = secm.ID WHERE cm.Name IN (''Class 8'', ''VIII'') AND secm.Name = ''B'' AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) GROUP BY pc.SubjectName ORDER BY AvgMarks;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3522, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3523 | Class-wise count of failed students ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class-wise count of failed students',
        @sql NVARCHAR(MAX) = N'SELECT c.Name AS ClassName, COUNT(DISTINCT smd.StudentID) AS FailedStudents FROM StudentMarkDetails smd INNER JOIN ExamConfigurationEvaluationDetails eced ON smd.EvalHierID = eced.ID INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ClassMaster c ON smm.ClassID = c.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND c.IsDeleted = 0 AND smd.Marks < eced.MinMark GROUP BY c.Name ORDER BY FailedStudents DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3523, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3524 | Staff late arrival report this week ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff late arrival report this week',
        @sql NVARCHAR(MAX) = N'SELECT sa.Staff_ID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName, sa.Attendance_Date, sa.InTime FROM Staff_Attendance sa INNER JOIN Staff_Master sm ON sa.Staff_ID = sm.Staff_ID AND sm.StaffStatus_ID = 1 WHERE sa.Attendance_Date >= DATEADD(DAY, -7, CAST(GETDATE() AS DATE)) AND sa.InTime > ''09:00'' AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sa.Attendance_Date DESC, sa.InTime DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3524, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3525 | Year over year concession amount comparison ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Year over year concession amount comparison',
        @sql NVARCHAR(MAX) = N'SELECT bad.Name AS AcademicYear, SUM(fcd.Concession_Amount) AS TotalConcession FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bad.Name ORDER BY bad.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3525, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3526 | How many students have opted for transport facility? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students have opted for transport facility?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS transport_count FROM StudentAcademicDetail sad WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.TransportRequired = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3526, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3527 | What was the trend of misc receipts over the years? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What was the trend of misc receipts over the years?',
        @sql NVARCHAR(MAX) = N'SELECT bad.Name AS AcademicYear, SUM(fc.Misc_Receipt_Amt) AS TotalMiscReceipts FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bad.Name ORDER BY bad.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3527, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3528 | Give me the total present and absent count today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the total present and absent count today',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS total_present, SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END) AS total_absent FROM StudentAttendance sa WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3528, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3529 | What's the compare paid amounts across branches? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the compare paid amounts across branches?',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, SUM(ISNULL(fisd.Paid_Amt,0)) AS TotalPaid FROM FeesInformationStudentDetail fisd JOIN BranchMaster bm ON fisd.BranchID = bm.ID WHERE fisd.IsIncludedInLumpSum <> 1 AND fisd.IsDonation = 0 AND fisd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY TotalPaid DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3529, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3530 | Hey, what's the average score in Science for Class 9? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the average score in Science for Class 9?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(AVG(pc.Marks) AS DECIMAL(5,2)) AS AvgMarks FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE pc.SubjectName = ''Science'' AND cm.Name IN (''Class 9'', ''IX'') AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3530, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3531 | What's the quick count of all classes? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the quick count of all classes?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(sad.Id) AS Students FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) GROUP BY cm.Name, cm.DisplayOrder ORDER BY cm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3531, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3532 | What's the weather today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the weather today?',
        @sql NVARCHAR(MAX) = N'-- This question is outside the scope of the school management database. I can answer questions about students, fees, attendance, staff, exams, transport, and other school operations.
SELECT ''Please ask a question about school data (fees, attendance, students, staff, exams, etc.)'' AS Message;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3532, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3533 | Students with all A+ grades ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students with all A+ grades',
        @sql NVARCHAR(MAX) = N'SELECT smd.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN Student_Master stm ON smd.StudentID = stm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND smd.Grade IS NOT NULL GROUP BY smd.StudentID, stm.AdmissionNo, stm.FirstName, stm.LastName HAVING MIN(smd.Grade) = ''A+'' AND MAX(smd.Grade) = ''A+'';',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3533, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3534 | How many receipts were generated this year in total? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many receipts were generated this year in total?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS total_receipts FROM FeesCollection fc WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3534, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3535 | List leave applications rejected this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List leave applications rejected this month',
        @sql NVARCHAR(MAX) = N'SELECT lem.Staff_Name AS StaffName, lem.LeaveFromDate, lem.LeaveToDate, lem.NoOfDays, lem.Purpose AS Reason FROM LeaveEntryMaster lem INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND ls.Name = ''Cancel'' AND MONTH(lem.LeaveFromDate) = MONTH(GETDATE()) AND YEAR(lem.LeaveFromDate) = YEAR(GETDATE());',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3535, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3536 | How many distinct fee types are charged this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many distinct fee types are charged this year?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT FeesType_Name) AS FeeTypes FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3536, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3537 | Show enquiries with status new that are more than a week old. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show enquiries with status new that are more than a week old.',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT CallRefNo, Parent_Name, Student_Name, MobileNo1, CallDate, DATEDIFF(DAY, CallDate, GETDATE()) AS DaysSinceEnquiry FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND CallStatus_ID IN (SELECT ID FROM Enquiry_Status_Master WHERE Name = ''Initiated'') AND DATEDIFF(DAY, CallDate, GETDATE()) > 7 ORDER BY CallDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3537, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3538 | List students who received the highest refund amounts ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List students who received the highest refund amounts',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 sm.FirstName + '' '' + sm.LastName AS StudentName, r.Refund_Amt, r.Bill_Date FROM RefundReceipt r INNER JOIN Student_Master sm ON r.Student_ID = sm.ID WHERE r.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND r.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY r.Refund_Amt DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3538, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3539 | Show term-wise demand, collected, and outstanding breakdown. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show term-wise demand, collected, and outstanding breakdown.',
        @sql NVARCHAR(MAX) = N'SELECT f.Term_Name, SUM(f.Amount) AS Demand, SUM(f.Paid_Amt) AS Collected, SUM(ISNULL(f.Concession_Amt, 0)) AS Concession, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Term_Name ORDER BY f.Term_Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3539, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3540 | I need to see TC requests that are still pending approval ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see TC requests that are still pending approval',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, sm.FirstName, sm.LastName FROM TCRequest tcr
INNER JOIN Student_Master sm ON tcr.StudentID = sm.ID
WHERE tcr.TC_Status NOT IN (''Issued'', ''Cancel'') AND tcr.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (tcr.IsDeleted IS NULL OR tcr.IsDeleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3540, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3541 | How much miscellaneous fee was collected today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much miscellaneous fee was collected today?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Misc_Receipt_Amt), 0) AS misc_collection FROM FeesCollection fc WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3541, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3542 | Students with concession who still have outstanding balance ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students with concession who still have outstanding balance',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName + '' '' + sm.LastName AS StudentName, SUM(f.Concession_Amt) AS TotalConcession, SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN Student_Master sm ON f.Student_ID = sm.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.Concession_Amt > 0 GROUP BY sm.FirstName, sm.LastName HAVING SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) > 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3542, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3543 | Show top 10 highest donation amounts with student names. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show top 10 highest donation amounts with student names.',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 sm.FirstName + '' '' + sm.LastName AS StudentName, sm.FatherName, d.Receipt_Amt AS Amount, d.Bill_No, d.Bill_Date FROM DonationFeesCollection d INNER JOIN Student_Master sm ON d.Student_ID = sm.ID WHERE d.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND d.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (d.IsDeleted = 0 OR d.IsDeleted IS NULL) AND d.ChequeStatus_ID NOT IN (3, 4) ORDER BY d.Receipt_Amt DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3543, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3544 | What's the girls count in Kilpauk branch? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the girls count in Kilpauk branch?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS Girls FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.Gender IN (''Female'', ''Girl'') AND sm.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%Kilpauk%'' OR ShortName LIKE ''%Kilpauk%'')) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3544, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3545 | Count of active staff ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Count of active staff',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS ActiveStaff FROM Staff_Master sm WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3545, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3546 | What are the all bounced payments along with the student's class? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What are the all bounced payments along with the student''s class?',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName + '' '' + sm.LastName AS StudentName, cm.Name AS ClassName, fc.Receipt_Amt, fc.Bill_Date FROM FeesCollection fc INNER JOIN Student_Master sm ON fc.Student_ID = sm.ID INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID AND fc.AcademicYearID = sad.AcademicYearID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID = 4;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3546, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3547 | Total earnings vs total deductions this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total earnings vs total deductions this month',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CASE WHEN gsed.TypeID = 1 THEN gsed.Amount ELSE 0 END) AS TotalEarnings, SUM(CASE WHEN gsed.TypeID = 2 THEN gsed.Amount ELSE 0 END) AS TotalDeductions, SUM(CASE WHEN gsed.TypeID = 1 THEN gsed.Amount ELSE 0 END) - SUM(CASE WHEN gsed.TypeID = 2 THEN gsed.Amount ELSE 0 END) AS NetPayTotal FROM GenerateSalaryEmployee_Details gsed INNER JOIN GenerateSalary_Master gsm ON gsed.HeaderID = gsm.ID INNER JOIN GenerateSalaryEmployee_Master gsem ON gsed.MasterID = gsem.ID WHERE gsm.MonthID = MONTH(GETDATE()) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3547, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3548 | Branch-wise number of male staff ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Branch-wise number of male staff',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, COUNT(*) AS MaleStaff FROM Staff_Master sfm JOIN BranchMaster bm ON sfm.BranchID = bm.ID WHERE sfm.Staff_Gender = ''Male'' AND (sfm.IsDeleted = 0 OR sfm.IsDeleted IS NULL) AND sfm.StaffStatus_ID = 1 AND sfm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY MaleStaff DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3548, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3549 | Pull up class-wise total outstanding fees ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up class-wise total outstanding fees',
        @sql NVARCHAR(MAX) = N'SELECT f.ClassID, f.ClassName, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.ClassID, f.ClassName ORDER BY f.ClassName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3549, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3550 | Who has done the most day closures this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who has done the most day closures this year?',
        @sql NVARCHAR(MAX) = N'SELECT CollectedByName AS ClosedBy_Name, COUNT(*) AS ClosureCount FROM DayclosureMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) GROUP BY CollectedByName ORDER BY ClosureCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3550, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3551 | I need students who have never had a late fee charged ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need students who have never had a late fee charged',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName FROM Student_Master sm WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sm.ID NOT IN (SELECT DISTINCT fc.Student_ID FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.LateFeeAmount > 0 AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3551, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3552 | Can I see the transport fee outstanding amount? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can I see the transport fee outstanding amount?',
        @sql NVARCHAR(MAX) = N'SELECT SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS TransportOutstanding FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.IsBusFee = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3552, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3553 | How many circulars were sent to staff vs students? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many circulars were sent to staff vs students?',
        @sql NVARCHAR(MAX) = N'SELECT CASE WHEN CircularApplicableFor LIKE ''%Staff%'' THEN ''Staff'' WHEN CircularApplicableFor LIKE ''%Student%'' THEN ''Student'' WHEN CircularApplicableFor LIKE ''%Parent%'' THEN ''Parent'' ELSE ''Other'' END AS Audience, COUNT(*) AS [Count] FROM CircularEntry WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) GROUP BY CASE WHEN CircularApplicableFor LIKE ''%Staff%'' THEN ''Staff'' WHEN CircularApplicableFor LIKE ''%Student%'' THEN ''Student'' WHEN CircularApplicableFor LIKE ''%Parent%'' THEN ''Parent'' ELSE ''Other'' END;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3553, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3554 | What is the overall school average this academic year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the overall school average this academic year?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(AVG(pc.Marks) AS DECIMAL(5,2)) AS SchoolAverage FROM ProgressCardDataRetrieval pc WHERE pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3554, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3555 | What percentage of the total demand has been collected so far? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What percentage of the total demand has been collected so far?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(SUM(f.Paid_Amt) * 100.0 / NULLIF(SUM(f.Amount), 0), 2) AS CollectionPercentage FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3555, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3556 | What's the total demand for tuition fees specifically? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the total demand for tuition fees specifically?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(Amount) AS TuitionDemand FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND Fees_Name LIKE ''%Tuition%'' AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3556, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3557 | Which students have not been marked present or absent today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which students have not been marked present or absent today?',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sad.ClassName, sad.RollNo FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND NOT EXISTS (SELECT 1 FROM StudentAttendance sa WHERE sa.Student_ID = sm.ID AND sa.Attendance_Date = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3557, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3558 | How many VIP students do we have? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many VIP students do we have?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS vip_count FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.IsVIP = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3558, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3559 | Total number of employees in the school ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total number of employees in the school',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalStaff FROM Staff_Master sm WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3559, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3560 | Just checking - how many transport routes do we have? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many transport routes do we have?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalRoutes FROM Route_Master WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3560, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3561 | Hey, how many students are in the Adyar branch? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many students are in the Adyar branch?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS Students FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%Adyar%'' OR ShortName LIKE ''%Adyar%'')) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3561, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3562 | I need the gender split percentage ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need the gender split percentage',
        @sql NVARCHAR(MAX) = N'SELECT sm.Gender, COUNT(*) AS StudentCount, CAST(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM StudentAcademicDetail WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND IsActive = 1 AND (IsTCIssued = 0 OR IsTCIssued IS NULL)) AS DECIMAL(5,2)) AS Percentage FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) GROUP BY sm.Gender;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3562, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3563 | So, what's the collection summary by fee type? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, what''s the collection summary by fee type?',
        @sql NVARCHAR(MAX) = N'SELECT fcd.FeesType_Name, SUM(fcd.Paid_Amt) AS TotalPaid, COUNT(DISTINCT fc.Student_ID) AS StudentCount FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fcd.FeesType_Name ORDER BY TotalPaid DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3563, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3564 | What is the total concession given for bus fees? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total concession given for bus fees?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(ISNULL(f.Concession_Amt, 0)) AS BusFeeConcession FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.IsBusFee = 1 AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3564, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3565 | Who collected the most fees this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who collected the most fees this month?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 5 fc.Collected_By_Name, COUNT(fc.Id) AS ReceiptCount, SUM(fc.Receipt_Amt) AS TotalCollected FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND MONTH(fc.Bill_Date) = MONTH(GETDATE()) AND YEAR(fc.Bill_Date) = YEAR(GETDATE()) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fc.Collected_By_Name ORDER BY TotalCollected DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3565, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3566 | Branch-wise late arrivals today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Branch-wise late arrivals today',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, COUNT(*) AS Late FROM StudentAttendance sa JOIN BranchMaster bm ON sa.BranchID = bm.ID WHERE sa.Attendance_Status_ID = 4 AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY Late DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3566, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3567 | What is the fee collection percentage? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the fee collection percentage?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(SUM(Paid_Amt) * 100.0 / NULLIF(SUM(Amount), 0), 2) AS CollectionPercentage FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3567, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3568 | Pull up students with outstanding more than 100000 with full contact details ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up students with outstanding more than 100000 with full contact details',
        @sql NVARCHAR(MAX) = N'SELECT f.Student_ID, s.FirstName + '' '' + ISNULL(s.MiddleName, '''') + '' '' + ISNULL(s.LastName, '''') AS StudentName, f.ClassName, f.SectionName, s.FatherContactNo, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID INNER JOIN Student_Master s ON f.Student_ID = s.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Student_ID, s.FirstName, s.MiddleName, s.LastName, f.ClassName, f.SectionName, s.FatherContactNo HAVING SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 100000 ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3568, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3569 | Bottom 10 performers in the school ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Bottom 10 performers in the school',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 smd.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName, SUM(smd.Marks) AS TotalMarks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN Student_Master stm ON smd.StudentID = stm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 GROUP BY smd.StudentID, stm.AdmissionNo, stm.FirstName, stm.LastName ORDER BY TotalMarks ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3569, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3570 | What are the lumpsum fee students with their amount? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What are the lumpsum fee students with their amount?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, sad.Lumpsum_Amount FROM Student_Master sm JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsLumpsumApplicable = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.Lumpsum_Amount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3570, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3571 | Can you check - class-wise count of students who have both outstanding fees and poor attendance? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you check - class-wise count of students who have both outstanding fees and poor attendance?',
        @sql NVARCHAR(MAX) = N'SELECT f.ClassName, COUNT(DISTINCT f.Student_ID) AS StudentCount FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 0 AND f.Student_ID IN (SELECT sa.Student_ID FROM StudentAttendance sa WHERE sa.Attendance_Status_ID = 1 GROUP BY sa.Student_ID HAVING COUNT(*) * 1.0 / NULLIF((SELECT COUNT(*) FROM StudentAttendance sa2 WHERE sa2.Student_ID = sa.Student_ID), 0) < 0.6) GROUP BY f.ClassName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3571, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3572 | Show holidays that are longer than 2 days. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show holidays that are longer than 2 days.',
        @sql NVARCHAR(MAX) = N'SELECT Name, From_Date, To_Date, DATEDIFF(DAY, From_Date, To_Date) + 1 AS Duration FROM HolidayMaster WHERE DATEDIFF(DAY, From_Date, To_Date) + 1 > 2 AND IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY Duration DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3572, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3573 | Can you show the number of students who paid fully vs partially vs not paid at all? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show the number of students who paid fully vs partially vs not paid at all?',
        @sql NVARCHAR(MAX) = N'SELECT ''Fully Paid'' AS category, COUNT(*) AS student_count FROM (SELECT fc.Student_ID FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN StudentAcademicDetail sad ON fc.Student_ID = sad.StudentID AND fc.AcademicYearID = sad.AcademicYearID WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND sad.IsActive = 1 GROUP BY fc.Student_ID HAVING SUM(fcd.Remaining_Amt) = 0) AS fully_paid UNION ALL SELECT ''Partially Paid'' AS category, COUNT(*) AS student_count FROM (SELECT fc.Student_ID FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN StudentAcademicDetail sad ON fc.Student_ID = sad.StudentID AND fc.AcademicYearID = sad.AcademicYearID WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND sad.IsActive = 1 GROUP BY fc.Student_ID HAVING SUM(fcd.Paid_Amt) > 0 AND SUM(fcd.Remaining_Amt) > 0) AS partial;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3573, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3574 | Show vehicles with expired fitness certificate. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show vehicles with expired fitness certificate.',
        @sql NVARCHAR(MAX) = N'SELECT Vehicle_Number, Vehicle_Type_Name, FC_Date FROM VehicleMaster WHERE FC_Date < GETDATE() AND IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3574, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3575 | Give me the total sections in the school? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the total sections in the school?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(DISTINCT sad.SectionID) AS SectionCount FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 GROUP BY cm.Name ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3575, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3576 | Show class-wise student count and total outstanding sorted by outstanding descending. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show class-wise student count and total outstanding sorted by outstanding descending.',
        @sql NVARCHAR(MAX) = N'SELECT f.ClassName, COUNT(DISTINCT f.Student_ID) AS StudentCount, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.ClassName ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3576, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3577 | What is the average late fee per student? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the average late fee per student?',
        @sql NVARCHAR(MAX) = N'SELECT AVG(TotalLateFee) AS AvgLateFeePerStudent FROM (SELECT fc.Student_ID, SUM(fcd.LateFeeAmount) AS TotalLateFee FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.LateFeeAmount > 0 AND (fc.IsDeleted = 0 OR fc.IsDeleted IS NULL) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY fc.Student_ID) t;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3577, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3578 | How many students were not promoted? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students were not promoted?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS NotPromoted FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE (sad.IsPromoted = 0 OR sad.IsPromoted IS NULL) AND sad.IsTCIssued = 0 AND bad.Id = (SELECT PreviousYearID FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = bad.Branch_Id) AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3578, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3579 | Non-teaching staff attendance today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Non-teaching staff attendance today',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) AS Present, COUNT(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 END) AS Absent FROM Staff_Attendance sa INNER JOIN Staff_Master sfm ON sa.Staff_ID = sfm.Staff_ID AND sfm.StaffStatus_ID = 1 WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.StaffType_ID != 1  AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3579, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3580 | Pull up class-wise student strength real quick ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up class-wise student strength real quick',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS class_name, COUNT(*) AS student_count FROM StudentAcademicDetail sad JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY cm.Name ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3580, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3581 | I need the students with attendance below 50% ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need the students with attendance below 50%',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, sm.AdmissionNo, cm.Name AS class_name, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS attendance_pct FROM StudentAttendance sa JOIN Student_Master sm ON sa.Student_ID = sm.ID JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE sa.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo, cm.Name HAVING CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) < 50 ORDER BY attendance_pct ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3581, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3582 | Total staff strength vs present today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total staff strength vs present today',
        @sql NVARCHAR(MAX) = N'SELECT (SELECT COUNT(DISTINCT sfm.Staff_ID) FROM Staff_Master sfm WHERE (sfm.IsDeleted IS NULL OR sfm.IsDeleted = 0) AND sfm.StaffStatus_ID = 1 AND sfm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AS TotalStaff, COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) AS PresentToday, COUNT(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 END) AS AbsentToday FROM Staff_Attendance sa WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE)  AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3582, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3583 | I need me a gender-wise split quickly ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need me a gender-wise split quickly',
        @sql NVARCHAR(MAX) = N'SELECT sm.Gender, COUNT(*) AS StudentCount FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) GROUP BY sm.Gender;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3583, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3584 | Gender-wise exam performance comparison ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Gender-wise exam performance comparison',
        @sql NVARCHAR(MAX) = N'SELECT sm.Gender, CAST(AVG(smd.Marks) AS DECIMAL(5,2)) AS AvgMarks, COUNT(DISTINCT sm.ID) AS StudentCount FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN Student_Master sm ON smd.StudentID = sm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 GROUP BY sm.Gender;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3584, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3585 | How many fees collected today are there? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many fees collected today are there?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS TodayCollection FROM FeesCollection fc WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3585, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3586 | Tell me about the students who scored single digits ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Tell me about the students who scored single digits',
        @sql NVARCHAR(MAX) = N'SELECT smd.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName, smd.Marks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN Student_Master stm ON smd.StudentID = stm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND smd.Marks < 10 AND smd.Marks > 0 ORDER BY smd.Marks ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3586, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3587 | How many of active staff are there? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many of active staff are there?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS ActiveStaff FROM Staff_Master sm WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3587, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3588 | Can you show students with both transport and hostel? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show students with both transport and hostel?',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.TransportRequired = 1 AND sad.HostelRequired = 1 AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3588, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3589 | Find students with attendance below 50% ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Find students with attendance below 50%',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AttendancePercent FROM StudentAttendance sa JOIN Student_Master sm ON sa.Student_ID = sm.ID JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON sa.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.AcademicYearID = bad.Id AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo, sad.ClassName HAVING CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) < 50 ORDER BY AttendancePercent;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3589, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3590 | What are the students who requested TC but it hasn't been issued yet? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What are the students who requested TC but it hasn''t been issued yet?',
        @sql NVARCHAR(MAX) = N'SELECT tcr.FirstName, tcr.LastName FROM TCRequest tcr WHERE tcr.IssuedDate IS NULL AND tcr.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (tcr.IsDeleted IS NULL OR tcr.IsDeleted=0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3590, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3591 | Let me see pending vs paid late fee comparison by class ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see pending vs paid late fee comparison by class',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, SUM(CASE WHEN fcd.Remaining_Amt = 0 THEN fcd.LateFeeAmount ELSE 0 END) AS PaidAmount, SUM(CASE WHEN fcd.Remaining_Amt > 0 THEN fcd.LateFeeAmount ELSE 0 END) AS PendingAmount FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN ClassMaster cm ON fc.Class_ID = cm.ID WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.LateFeeAmount > 0 AND (fc.IsDeleted = 0 OR fc.IsDeleted IS NULL) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY cm.Name ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3591, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3592 | Let me see class-wise outstanding fees ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see class-wise outstanding fees',
        @sql NVARCHAR(MAX) = N'SELECT f.ClassName, SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS Outstanding FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY f.ClassName ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3592, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3593 | Can I see the class-wise new admissions count? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can I see the class-wise new admissions count?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS class_name, COUNT(*) AS new_admissions FROM StudentAcademicDetail sad JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.IsNewAdmission = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY cm.Name ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3593, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3594 | How many teachers came today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many teachers came today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TeachersPresent FROM Staff_Attendance sa INNER JOIN Staff_Master sfm ON sa.Staff_ID = sfm.Staff_ID AND sfm.StaffStatus_ID = 1 WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.Attendance_Status_ID = 1  AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3594, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3595 | Show the subject distribution across primary vs secondary classes. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the subject distribution across primary vs secondary classes.',
        @sql NVARCHAR(MAX) = N'SELECT CASE WHEN cm.Name IN (''Class 1'',''Class 2'',''Class 3'',''Class 4'',''Class 5'') THEN ''Primary'' WHEN cm.Name IN (''Class 6'',''Class 7'',''Class 8'') THEN ''Middle'' ELSE ''Secondary'' END AS Level, COUNT(DISTINCT cs.Subject_Id) AS UniqueSubjects, COUNT(*) AS TotalMappings FROM ClassSubjectDetails cs INNER JOIN ClassMaster cm ON cs.Class_Id = cm.ID WHERE cs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND cs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY CASE WHEN cm.Name IN (''Class 1'',''Class 2'',''Class 3'',''Class 4'',''Class 5'') THEN ''Primary'' WHEN cm.Name IN (''Class 6'',''Class 7'',''Class 8'') THEN ''Middle'' ELSE ''Secondary'' END;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3595, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3596 | Is collection better than last year same time? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Is collection better than last year same time?',
        @sql NVARCHAR(MAX) = N'SELECT ''Current Year'' AS Period, ISNULL(SUM(fc.Receipt_Amt), 0) AS Collection FROM FeesCollection fc WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.Bill_Date <= GETDATE() AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) UNION ALL SELECT ''Previous Year'' AS Period, ISNULL(SUM(fc.Receipt_Amt), 0) AS Collection FROM FeesCollection fc WHERE fc.AcademicYearID IN (SELECT PreviousYearID FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3596, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3597 | Let me see house-wise student distribution ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see house-wise student distribution',
        @sql NVARCHAR(MAX) = N'SELECT sad.HouseName, COUNT(DISTINCT sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.HouseName IS NOT NULL AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sad.HouseName ORDER BY StudentCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3597, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3598 | How many defaulters do we have right now? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many defaulters do we have right now?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT f.Student_ID) AS DefaulterCount FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3598, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3599 | Hey, how many total boarding points does the school have? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many total boarding points does the school have?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalBoardingPoints FROM BoardingPoint_Master WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (IsDeleted = 0 OR IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3599, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3600 | Let me see student strength branch-wise ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see student strength branch-wise',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, COUNT(*) AS Students FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN BranchMaster bm ON sm.BranchID = bm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY Students DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
PRINT 'checkpoint: reached Q3600';
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3600, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3601 | List all homework assigned by Priya Sharma this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all homework assigned by Priya Sharma this year',
        @sql NVARCHAR(MAX) = N'SELECT h.Type_Name, h.AssignmentDate, h.Class_ID FROM HomeWorkAndAssignment h WHERE h.StaffName = ''Priya Sharma'' AND h.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date) AND h.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (h.IsDeleted IS NULL OR h.IsDeleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3601, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3602 | So, how many students have paid more than 50000? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, how many students have paid more than 50000?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS StudentCount FROM (SELECT fc.Student_ID, SUM(fc.Receipt_Amt) AS TotalPaid FROM FeesCollection fc WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fc.Student_ID HAVING SUM(fc.Receipt_Amt) > 50000) AS HighPayers;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3602, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3603 | Department wise staff count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Department wise staff count',
        @sql NVARCHAR(MAX) = N'SELECT dm.Name AS Department, COUNT(sm.Staff_ID) AS StaffCount FROM StaffDepartmentMaster dm INNER JOIN StaffDepartmentMapping sdm ON dm.Id = sdm.DepartmentID INNER JOIN StaffDepartmentMappingDetail sdmd ON sdm.Id = sdmd.MappingID INNER JOIN Staff_Master sm ON sdmd.StaffID = sm.Staff_ID WHERE dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (dm.IsDeleted IS NULL OR dm.IsDeleted = 0) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1 GROUP BY dm.Name ORDER BY StaffCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3603, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3604 | Can you show the Class and Section wise outstanding summary? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show the Class and Section wise outstanding summary?',
        @sql NVARCHAR(MAX) = N'SELECT ClassName, SectionName, SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY ClassName, SectionName ORDER BY ClassName, SectionName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3604, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3605 | How many students have bus fee outstanding? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students have bus fee outstanding?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT f.Student_ID) AS StudentsWithBusFeeOutstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.IsBusFee = 1 AND (f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 0 AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3605, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3606 | How many boarding points are there across all routes? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many boarding points are there across all routes?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalBoardingPoints FROM Route_Master rm INNER JOIN Route_MasterDetails rmd ON rm.ID = rmd.Route_ID INNER JOIN BoardingPoint_Master bpm ON rmd.BoardingPoint_ID = bpm.Id WHERE rm.IsDeleted = 0 AND rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3606, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3607 | What was the total salary paid in May 2026? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What was the total salary paid in May 2026?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(gse.NetPay) AS TotalSalary FROM GenerateSalaryEmployee_Master gse INNER JOIN GenerateSalary_Master gsm ON gse.HeaderID = gsm.ID WHERE gsm.MonthID = 5 AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE ''2026-05-01'' BETWEEN Start_Date AND End_Date) AND gsm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (gsm.IsDeleted IS NULL OR gsm.IsDeleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3607, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3608 | Who are the students admitted in the last 7 days? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who are the students admitted in the last 7 days?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sm.AdmissionDate, sad.ClassName FROM Student_Master sm JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sm.AdmissionDate >= DATEADD(DAY, -7, GETDATE()) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sm.AdmissionDate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3608, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3609 | Show the most recent refunds with who processed them ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the most recent refunds with who processed them',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 rr.Bill_Date, rr.Refund_Amt, rr.Created_By FROM RefundReceipt rr WHERE rr.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY rr.Bill_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3609, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3610 | How many new students who joined mid-session do we have? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many new students who joined mid-session do we have?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS MidSessionAdmissions FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNewAdmission = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sm.AdmissionDate > DATEADD(MONTH, 1, bad.Start_Date) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3610, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3611 | New admission students who are absent today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'New admission students who are absent today',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, sm.AdmissionNo, cm.Name AS class_name FROM StudentAttendance sa JOIN Student_Master sm ON sa.Student_ID = sm.ID JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.Attendance_Status_ID = 2 AND sad.IsNewAdmission = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3611, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3612 | Top collecting day of each month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Top collecting day of each month',
        @sql NVARCHAR(MAX) = N'SELECT MonthName, CollectionDate, DailyTotal FROM (SELECT DATENAME(MONTH, fc.Bill_Date) AS MonthName, MONTH(fc.Bill_Date) AS MonthNum, CAST(fc.Bill_Date AS DATE) AS CollectionDate, SUM(fc.Receipt_Amt) AS DailyTotal, ROW_NUMBER() OVER (PARTITION BY MONTH(fc.Bill_Date) ORDER BY SUM(fc.Receipt_Amt) DESC) AS rn FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY DATENAME(MONTH, fc.Bill_Date), MONTH(fc.Bill_Date), CAST(fc.Bill_Date AS DATE)) t WHERE rn = 1 ORDER BY MonthNum;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3612, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3613 | Which house has the most students? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which house has the most students?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 sad.HouseName, COUNT(DISTINCT sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.HouseName IS NOT NULL AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sad.HouseName ORDER BY StudentCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3613, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3614 | Year-over-year concession comparison ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Year-over-year concession comparison',
        @sql NVARCHAR(MAX) = N'SELECT ''Current Year'' AS Period, ISNULL(SUM(fcd.Concession_Amount), 0) AS TotalConcession FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) UNION ALL SELECT ''Previous Year'' AS Period, ISNULL(SUM(fcd.Concession_Amount), 0) AS TotalConcession FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fc.AcademicYearID IN (SELECT PreviousYearID FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3614, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3615 | Which vehicle has the highest seating capacity? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which vehicle has the highest seating capacity?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 Vehicle_Number, Seating_Capacity FROM VehicleMaster WHERE IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY Seating_Capacity DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3615, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3616 | Correlation between staff attendance and salary ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Correlation between staff attendance and salary',
        @sql NVARCHAR(MAX) = N'SELECT gem.EmployeeID, gem.EmployeeName, gem.NetPay, gem.PresentDays, (gem.WorkingDays - gem.PresentDays) AS AbsentDays FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) ORDER BY (gem.WorkingDays - gem.PresentDays) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3616, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3617 | Show top 20 defaulters with their outstanding percentage of demand. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show top 20 defaulters with their outstanding percentage of demand.',
        @sql NVARCHAR(MAX) = N'SELECT TOP 20 f.Student_ID, s.FirstName + '' '' + ISNULL(s.LastName, '''') AS StudentName, f.ClassName, SUM(f.Amount) AS Demand, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding, ROUND(SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) * 100.0 / NULLIF(SUM(f.Amount), 0), 2) AS OutstandingPercent FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID INNER JOIN Student_Master s ON f.Student_ID = s.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Student_ID, s.FirstName, s.LastName, f.ClassName HAVING SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 0 ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3617, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3618 | Show me the list of VIP students ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me the list of VIP students',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, sm.AdmissionNo, cm.Name AS class_name, sm.FatherName, sm.FatherContactNo FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.IsVIP = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3618, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3619 | What are the students with bus fee outstanding greater than 3000? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What are the students with bus fee outstanding greater than 3000?',
        @sql NVARCHAR(MAX) = N'SELECT f.Student_ID, sm.FirstName, sm.LastName, sm.AdmissionNo, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS BusFeeOutstanding FROM FeesInformationStudentDetail f INNER JOIN Student_Master sm ON f.Student_ID = sm.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.IsBusFee = 1 AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY f.Student_ID, sm.FirstName, sm.LastName, sm.AdmissionNo HAVING SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 3000 ORDER BY BusFeeOutstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3619, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3620 | So, how many teachers do we have? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, how many teachers do we have?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TeachingStaff FROM Staff_Master sm INNER JOIN StaffType_Master stm ON sm.StaffType_ID = stm.ID INNER JOIN StaffTypeCategoryMaster stcm ON stm.Type_Id = stcm.Id WHERE stcm.Name = ''Academic'' AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sm.IsDeleted = 0 AND sm.StaffStatus_ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3620, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3621 | So, what's the class-wise conversion rate? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, what''s the class-wise conversion rate?',
        @sql NVARCHAR(MAX) = N'DECLARE @StatusConverted bigint = (SELECT TOP 1 ID FROM Enquiry_Status_Master WHERE Name = ''Completed'');
WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT cm.Name AS ClassName, COUNT(*) AS TotalEnquiries, SUM(CASE WHEN em.CallStatus_ID = @StatusConverted THEN 1 ELSE 0 END) AS Converted, ROUND(SUM(CASE WHEN em.CallStatus_ID = @StatusConverted THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0), 2) AS ConversionRate FROM GeneralCallRegister em INNER JOIN ClassMaster cm ON em.Class_ID = cm.ID WHERE em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND em.IsDeleted = 0 GROUP BY cm.Name ORDER BY ConversionRate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3621, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3622 | Hey, what's the total fee demand for Class 5? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the total fee demand for Class 5?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(Amount) AS TotalDemand FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND ClassName = ''Class 5'' AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3622, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3623 | List students who requested TC but it hasn't been issued yet ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List students who requested TC but it hasn''t been issued yet',
        @sql NVARCHAR(MAX) = N'SELECT tcr.FirstName, tcr.LastName FROM TCRequest tcr WHERE tcr.IssuedDate IS NULL AND tcr.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (tcr.IsDeleted IS NULL OR tcr.IsDeleted=0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3623, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3624 | Just checking - how many fresh admissions happened last month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many fresh admissions happened last month?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS NewAdmissions FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNewAdmission = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND MONTH(sm.AdmissionDate) = MONTH(DATEADD(MONTH, -1, GETDATE())) AND YEAR(sm.AdmissionDate) = YEAR(DATEADD(MONTH, -1, GETDATE())) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3624, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3625 | Show cancelled receipts this year with amount and reason ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show cancelled receipts this year with amount and reason',
        @sql NVARCHAR(MAX) = N'SELECT fc.Bill_No, CAST(fc.Bill_Date AS DATE) AS BillDate, fc.Receipt_Amt, fc.Cancelled_By_Name, CAST(fc.Cancellation_Date AS DATE) AS CancelledDate, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName FROM FeesCollection fc JOIN Student_Master sm ON fc.Student_ID = sm.ID JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE fc.IsDeleted = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY fc.Cancellation_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3625, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3626 | Show current stock levels for all inventory items ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show current stock levels for all inventory items',
        @sql NVARCHAR(MAX) = N'SELECT iim.ItemName, iim.ItemCode, iim.StockInHand FROM InventoryItem_Master iim WHERE iim.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (iim.IsDeleted IS NULL OR iim.IsDeleted = 0) ORDER BY iim.ItemName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3626, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3627 | Compare female staff count across branches ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare female staff count across branches',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, COUNT(*) AS FemaleStaff FROM Staff_Master sfm JOIN BranchMaster bm ON sfm.BranchID = bm.ID WHERE sfm.Staff_Gender = ''Female'' AND (sfm.IsDeleted = 0 OR sfm.IsDeleted IS NULL) AND sfm.StaffStatus_ID = 1 AND sfm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY FemaleStaff DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3627, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3628 | Show expired circulars from last month. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show expired circulars from last month.',
        @sql NVARCHAR(MAX) = N'SELECT Title, Circular_Date, CircularApplicableFor AS TargetAudience, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS CreatedBy_Name FROM CircularEntry ce LEFT JOIN Staff_Master sm ON ce.Created_By = sm.Staff_ID WHERE ce.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ce.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND MONTH(ce.Circular_Date) = MONTH(DATEADD(MONTH, -1, GETDATE())) AND YEAR(ce.Circular_Date) = YEAR(DATEADD(MONTH, -1, GETDATE())) AND (ce.IsDeleted = 0 OR ce.IsDeleted IS NULL) ORDER BY ce.Circular_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3628, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3629 | How many new students enrolled this week? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many new students enrolled this week?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS NewEnrollments FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.IsNewAdmission = 1 AND sm.AdmissionDate >= DATEADD(DAY, -(DATEPART(WEEKDAY, GETDATE()) - 2), CAST(GETDATE() AS DATE)) AND sm.AdmissionDate <= CAST(GETDATE() AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3629, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3630 | Class 12 ke kitne students hain? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class 12 ke kitne students hain?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS Class12Count FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.Name IN (''Class 12'', ''XII'') AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3630, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3631 | I need to see circulars that are valid for more than 30 days ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see circulars that are valid for more than 30 days',
        @sql NVARCHAR(MAX) = N'SELECT Title, Circular_Date, CircularApplicableFor AS TargetAudience FROM CircularEntry WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND IsResponseNeeded = 1 ORDER BY Circular_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3631, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3632 | Show leave type-wise distribution for this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show leave type-wise distribution for this year',
        @sql NVARCHAR(MAX) = N'SELECT lt.Name AS LeaveType, COUNT(*) AS LeaveCount FROM LeaveEntryMaster lem INNER JOIN LeaveType lt ON lem.LeaveType_ID = lt.ID WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date) AND (lem.IsDeleted IS NULL OR lem.IsDeleted = 0) GROUP BY lt.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3632, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3633 | How many late fee entries were generated this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many late fee entries were generated this month?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS ThisMonthLateFees FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.LateFeeAmount > 0 AND (fc.IsDeleted = 0 OR fc.IsDeleted IS NULL) AND fc.ChequeStatus_ID NOT IN (3, 4) AND MONTH(fc.Bill_Date) = MONTH(GETDATE()) AND YEAR(fc.Bill_Date) = YEAR(GETDATE());',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3633, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3634 | List all unique enquiry sources used this year. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all unique enquiry sources used this year.',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT DISTINCT emm.Name AS Source FROM GeneralCallRegister em INNER JOIN Enquiry_Mode_Master emm ON em.Mode_ID = emm.ID WHERE em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND em.IsDeleted = 0 AND emm.Name IS NOT NULL;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3634, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3635 | I need the gender-wise attendance today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need the gender-wise attendance today',
        @sql NVARCHAR(MAX) = N'SELECT sm.Gender, SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS present, SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END) AS absent FROM StudentAttendance sa JOIN Student_Master sm ON sa.Student_ID = sm.ID WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.Gender;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3635, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3636 | Show me enquiry count for last month. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me enquiry count for last month.',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS EnquiriesLastMonth FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND MONTH(CallDate) = MONTH(DATEADD(MONTH, -1, GETDATE())) AND YEAR(CallDate) = YEAR(DATEADD(MONTH, -1, GETDATE()));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3636, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3637 | Class-wise student distribution in percentages ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class-wise student distribution in percentages',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(sad.Id) AS StudentCount, CAST(COUNT(sad.Id) * 100.0 / (SELECT COUNT(*) FROM StudentAcademicDetail sad2 WHERE sad2.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad2.IsActive = 1 AND (sad2.IsTCIssued = 0 OR sad2.IsTCIssued IS NULL)) AS DECIMAL(5,2)) AS Percentage FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) GROUP BY cm.Name, cm.DisplayOrder ORDER BY cm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3637, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3638 | How's the primary section doing? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How''s the primary section doing?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(sad.Id) AS StudentCount FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND cm.Name IN (''Class 1'', ''Class 2'', ''Class 3'', ''Class 4'', ''Class 5'') GROUP BY cm.Name ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3638, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3639 | Who are the top 10 scorers in the school? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who are the top 10 scorers in the school?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 smd.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName, SUM(smd.Marks) AS TotalMarks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN Student_Master stm ON smd.StudentID = stm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 GROUP BY smd.StudentID, stm.AdmissionNo, stm.FirstName, stm.LastName ORDER BY TotalMarks DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3639, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3640 | Highest paid staff and their attendance this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Highest paid staff and their attendance this month',
        @sql NVARCHAR(MAX) = N'SELECT TOP 5 gem.EmployeeID, gem.EmployeeName, gem.NetPay, ISNULL(gem.PresentDays, 0) AS PresentDays, ISNULL(gem.WorkingDays - gem.PresentDays, 0) AS AbsentDays FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) ORDER BY gem.NetPay DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3640, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3641 | How many fee receipts were generated today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many fee receipts were generated today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS receipt_count FROM FeesCollection fc WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3641, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3642 | List students whose TC has been issued ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List students whose TC has been issued',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, sm.AdmissionNo, sad.TCIssuedDate FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsTCIssued = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY sad.TCIssuedDate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3642, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3643 | List all my branches with their principal names ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all my branches with their principal names',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, bm.Principal AS Principal, bm.City, bm.State FROM BranchMaster bm WHERE (bm.IsDeleted = 0 OR bm.IsDeleted IS NULL) AND bm.ID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY bm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3643, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3644 | Show homework assigned yesterday. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show homework assigned yesterday.',
        @sql NVARCHAR(MAX) = N'SELECT h.Remarks AS Title, cm.Name AS ClassName, sub.Name AS SubjectName, h.SubmissionDate AS DueDate FROM HomeWorkAndAssignment h INNER JOIN ClassMaster cm ON h.Class_ID = cm.ID INNER JOIN Subject_Master sub ON h.Subject_ID = sub.Id WHERE h.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND h.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (h.IsDeleted = 0 OR h.IsDeleted IS NULL) AND CAST(h.AssignmentDate AS DATE) = CAST(DATEADD(DAY, -1, GETDATE()) AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3644, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3645 | Staff leave category wise count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff leave category wise count',
        @sql NVARCHAR(MAX) = N'SELECT lcm.Name AS LeaveCategory, COUNT(*) AS StaffCount FROM EmployeeMaster em LEFT JOIN LeaveCategoryMaster lcm ON em.LeaveCategoryID = lcm.ID WHERE em.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (em.IsDeleted = 0 OR em.IsDeleted IS NULL) GROUP BY lcm.Name ORDER BY StaffCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3645, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3646 | Attendance percentage for last 7 days ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Attendance percentage for last 7 days',
        @sql NVARCHAR(MAX) = N'SELECT CAST(sa.Attendance_Date AS DATE) AS date, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS attendance_pct FROM StudentAttendance sa WHERE sa.Attendance_Date >= DATEADD(DAY, -7, CAST(GETDATE() AS DATE)) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY CAST(sa.Attendance_Date AS DATE) ORDER BY CAST(sa.Attendance_Date AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3646, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3647 | What is the average salary for non-teaching staff? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the average salary for non-teaching staff?',
        @sql NVARCHAR(MAX) = N'SELECT AVG(gem.NetPay) AS AvgNonTeachingSalary FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) AND gm.StaffTypeName <> ''Teaching'';',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3647, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3648 | Show the principal of the Besant Nagar branch ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the principal of the Besant Nagar branch',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, bm.Principal AS Principal FROM BranchMaster bm WHERE (bm.Name LIKE ''%Besant Nagar%'' OR bm.ShortName LIKE ''%Besant Nagar%'') AND bm.ID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3648, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3649 | List boarding points with the highest fee ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List boarding points with the highest fee',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 bpm.Name AS BoardingPointName, bpm.Amount FROM BoardingPoint_Master bpm WHERE bpm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (bpm.IsDeleted = 0 OR bpm.IsDeleted IS NULL) ORDER BY bpm.Amount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3649, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3650 | How many circulars were issued this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many circulars were issued this month?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS CircularCount FROM CircularEntry ce WHERE MONTH(ce.Circular_Date) = MONTH(GETDATE()) AND YEAR(ce.Circular_Date) = YEAR(GETDATE()) AND ce.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ce.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ce.IsDeleted = 0 OR ce.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3650, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3651 | What is the total donation amount collected via cash? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total donation amount collected via cash?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(Receipt_Amt), 0) AS CashDonation FROM DonationFeesCollection WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND ChequeStatus_ID NOT IN (3, 4) AND Collection_Mode_ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3651, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3652 | Who owes money to the school? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who owes money to the school?',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sad.ClassName, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN Student_Master sm ON f.Student_ID = sm.ID INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY sm.AdmissionNo, sm.FirstName, sm.LastName, sad.ClassName HAVING SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 0 ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3652, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3653 | Non-teaching staff salary expenditure this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Non-teaching staff salary expenditure this month',
        @sql NVARCHAR(MAX) = N'SELECT SUM(gem.NetPay) AS NonTeachingSalary FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) AND gm.StaffTypeName = ''Non-Teaching'';',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3653, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3654 | Which class has the most students using transport? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which class has the most students using transport?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 cm.Name AS ClassName, COUNT(*) AS TransportStudents FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.TransportRequired = 1 AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY cm.Name ORDER BY TransportStudents DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3654, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3655 | How many total enquiries have been received this academic year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many total enquiries have been received this academic year?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS TotalEnquiries FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3655, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3656 | Can you show comparison of tickets opened vs resolved per month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show comparison of tickets opened vs resolved per month?',
        @sql NVARCHAR(MAX) = N'SELECT FORMAT(ft.Created_Date, ''yyyy-MM'') AS [Month], COUNT(*) AS Opened, SUM(CASE WHEN ft.Status = ''Closed'' AND FORMAT(rp.LastReplyDate, ''yyyy-MM'') = FORMAT(ft.Created_Date, ''yyyy-MM'') THEN 1 ELSE 0 END) AS ResolvedSameMonth FROM FeedbackTicket ft OUTER APPLY (SELECT MAX(ftr.RepliedOn) AS LastReplyDate FROM FeedbackTicketReplies ftr WHERE ftr.TicketID = ft.Id) rp WHERE ft.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ft.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY FORMAT(ft.Created_Date, ''yyyy-MM'') ORDER BY [Month];',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3656, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3657 | What's the overall fee recovery rate for the school? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the overall fee recovery rate for the school?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(SUM(f.Paid_Amt) * 100.0 / NULLIF(SUM(f.Amount - ISNULL(f.Concession_Amt, 0)), 0), 2) AS RecoveryRate FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3657, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3658 | So, what's the collection for the last 7 days? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, what''s the collection for the last 7 days?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS last_7_days_collection FROM FeesCollection fc WHERE fc.Bill_Date >= DATEADD(DAY, -7, CAST(GETDATE() AS DATE)) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3658, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3659 | Hey, how many terms are there? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many terms are there?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TermCount FROM ExamTermMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND Deleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3659, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3660 | I need to see outstanding amount for each fee head ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see outstanding amount for each fee head',
        @sql NVARCHAR(MAX) = N'SELECT f.Fees_Name, SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS Outstanding FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY f.Fees_Name ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3660, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3661 | Hey, what's the fee collection per active student? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the fee collection per active student?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(SUM(fc.Receipt_Amt) * 1.0 / NULLIF(COUNT(DISTINCT fc.Student_ID), 0), 2) AS AvgCollectionPerStudent FROM FeesCollection fc WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3661, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3662 | New admissions vs existing students - marks comparison ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'New admissions vs existing students - marks comparison',
        @sql NVARCHAR(MAX) = N'SELECT CASE WHEN sad.IsNewAdmission = 1 THEN ''New Admission'' ELSE ''Existing'' END AS Category, CAST(AVG(smd.Marks) AS DECIMAL(5,2)) AS AvgMarks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN StudentAcademicDetail sad ON smd.StudentID = sad.StudentID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND sad.IsActive = 1 GROUP BY CASE WHEN sad.IsNewAdmission = 1 THEN ''New Admission'' ELSE ''Existing'' END;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3662, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3663 | Classes where no annual discount has been applied ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Classes where no annual discount has been applied',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT cm.Name AS ClassName FROM ClassMaster cm WHERE cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND cm.IsDeleted = 0 AND cm.ID NOT IN (SELECT DISTINCT fc.Class_ID FROM FeesCollection fc WHERE fc.IsAnnualDiscountApplied = 1 AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3663, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3664 | Show the month with the highest outstanding amount. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the month with the highest outstanding amount.',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 f.Month_No, f.Month_Name, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Month_No, f.Month_Name ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3664, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3665 | Any staff on hold right now? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Any staff on hold right now?',
        @sql NVARCHAR(MAX) = N'SELECT StaffID, BankName FROM EmployeeMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0 AND IsHold = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3665, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3666 | Show circulars addressed to parents this week ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show circulars addressed to parents this week',
        @sql NVARCHAR(MAX) = N'SELECT ce.Title, ce.Circular_Date FROM CircularEntry ce WHERE ce.CircularApplicableFor IN (''Student'', ''Both'') AND ce.Circular_Date >= DATEADD(DAY, -7, CAST(GETDATE() AS DATE)) AND ce.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (ce.IsDeleted IS NULL OR ce.IsDeleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3666, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3667 | How many TCs have been fully processed and handed over? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many TCs have been fully processed and handed over?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS ProcessedTCs FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.IsTCIssued = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3667, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3668 | Change the fee structure for Class 12 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Change the fee structure for Class 12',
        @sql NVARCHAR(MAX) = N'-- This question asks me to perform an UPDATE operation on fee structures, which I cannot do. I can only retrieve data.
-- Here''s the current fee structure instead:
SELECT fcd.FeesType_Name, SUM(fcd.Fees_Amount) AS TotalAmount FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc2 ON fcd.Fees_Collection_ID = fc2.Id INNER JOIN StudentAcademicDetail sad2 ON fc2.Student_ID = sad2.StudentID AND sad2.IsActive = 1 INNER JOIN ClassMaster cm ON sad2.ClassID = cm.ID WHERE cm.Name IN (''Class 12'', ''XII'') AND fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY fcd.FeesType_Name ORDER BY TotalAmount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3668, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3669 | Can you show me hostel students whose attendance is below 75%? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show me hostel students whose attendance is below 75%?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AttendancePercent FROM StudentAttendance sa JOIN Student_Master sm ON sa.Student_ID = sm.ID JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON sa.AcademicYearID = bad.Id WHERE sad.HostelRequired = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.AcademicYearID = bad.Id AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo, sad.ClassName HAVING CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) < 75;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3669, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3670 | Month-wise pending fees breakdown ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Month-wise pending fees breakdown',
        @sql NVARCHAR(MAX) = N'SELECT f.Month_Name, SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS Outstanding FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY f.Month_Name, f.Month_No ORDER BY f.Month_No;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3670, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3671 | What's the fee sub-category wise student count? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the fee sub-category wise student count?',
        @sql NVARCHAR(MAX) = N'SELECT sad.StudentFeeSubCategoryID, COUNT(DISTINCT sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sad.StudentFeeSubCategoryID ORDER BY StudentCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3671, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3672 | Hey, what's the year-on-year growth in number of fee-paying students? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the year-on-year growth in number of fee-paying students?',
        @sql NVARCHAR(MAX) = N'SELECT bad.Name AS AcademicYear, COUNT(DISTINCT fc.Student_ID) AS PayingStudents FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bad.Name ORDER BY bad.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3672, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3673 | Attendance of students who have outstanding greater than 50000 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Attendance of students who have outstanding greater than 50000',
        @sql NVARCHAR(MAX) = N'SELECT sa.Student_ID, sm.FirstName + '' '' + sm.LastName AS StudentName, sa.Attendance_Status_ID FROM StudentAttendance sa INNER JOIN Student_Master sm ON sa.Student_ID = sm.ID WHERE sa.Student_ID IN (SELECT f.Student_ID FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY f.Student_ID HAVING SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) > 50000) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3673, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3674 | What's the pass rate for this academic year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the pass rate for this academic year?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(CASE WHEN pc.Marks >= pc.MinMark THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS PassRate FROM ProgressCardDataRetrieval pc WHERE pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3674, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3675 | Let me see leave applications submitted today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see leave applications submitted today',
        @sql NVARCHAR(MAX) = N'SELECT lem.Staff_Name AS StaffName, lem.LeaveFromDate, lem.LeaveToDate, lem.NoOfDays, lem.Purpose AS Reason FROM LeaveEntryMaster lem WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND CAST(lem.Created_Date AS DATE) = CAST(GETDATE() AS DATE) ORDER BY lem.LeaveFromDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3675, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3676 | What's the total salary paid this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the total salary paid this month?',
        @sql NVARCHAR(MAX) = N'SELECT gsm.MonthName, SUM(gsem.NetPay) AS TotalNetPay, SUM(gsem.GrossAmount) AS TotalGross, COUNT(gsem.ID) AS EmployeeCount FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(GETDATE()) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsm.MonthName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3676, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3677 | Show me month-wise total salary expenditure for this academic year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me month-wise total salary expenditure for this academic year',
        @sql NVARCHAR(MAX) = N'SELECT gsm.MonthName, gsm.MonthID, SUM(gsem.GrossAmount) AS TotalGross, SUM(gsem.NetPay) AS TotalNetPay, COUNT(gsem.ID) AS Headcount FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsm.MonthName, gsm.MonthID ORDER BY gsm.MonthID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3677, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3678 | total payroll cost last month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'total payroll cost last month',
        @sql NVARCHAR(MAX) = N'SELECT gsm.MonthName, SUM(gsem.NetPay) AS TotalNetPay, SUM(gsem.GrossAmount) AS TotalGross FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsm.MonthName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3678, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3679 | how much did we spend on salaries in april? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'how much did we spend on salaries in april?',
        @sql NVARCHAR(MAX) = N'SELECT gsm.MonthName, SUM(gsem.GrossAmount) AS TotalGross, SUM(gsem.NetPay) AS TotalNetPay, COUNT(gsem.ID) AS EmployeeCount FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = 4 AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsm.MonthName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3679, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3680 | Who are the top 10 highest paid employees? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who are the top 10 highest paid employees?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 gsem.EmployeeName, gsem.EmployeeCode, gsem.DesignationName, gsem.GrossAmount, gsem.NetPay FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY gsem.NetPay DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3680, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3681 | show me lowest paid staff members ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'show me lowest paid staff members',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 gsem.EmployeeName, gsem.EmployeeCode, gsem.DesignationName, gsem.GrossAmount, gsem.NetPay FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY gsem.NetPay ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3681, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3682 | Find employees with salary above 50000 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Find employees with salary above 50000',
        @sql NVARCHAR(MAX) = N'SELECT gsem.EmployeeName, gsem.EmployeeCode, gsem.DesignationName, gsem.GrossAmount, gsem.NetPay FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.NetPay > 50000 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY gsem.NetPay DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3682, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3683 | which staff member has the highest gross salary? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'which staff member has the highest gross salary?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 gsem.EmployeeName, gsem.EmployeeCode, gsem.DesignationName, gsem.GrossAmount, gsem.NetPay, gsem.PresentDays, gsem.WorkingDays FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY gsem.GrossAmount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3683, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3684 | Which employees had LOP deductions this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which employees had LOP deductions this month?',
        @sql NVARCHAR(MAX) = N'SELECT gsem.EmployeeName, gsem.EmployeeCode, gsem.DesignationName, gsem.LOPDays, gsem.WorkingDays, gsem.PresentDays FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(GETDATE()) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.LOPDays > 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY gsem.LOPDays DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3684, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3685 | staff with more than 3 days loss of pay ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'staff with more than 3 days loss of pay',
        @sql NVARCHAR(MAX) = N'SELECT gsem.EmployeeName, gsem.EmployeeCode, gsem.LOPDays, gsem.WorkingDays, gsem.PresentDays, gsem.NetPay FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.LOPDays > 3 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY gsem.LOPDays DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3685, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3686 | how many leaves did employees take that affected their salary last month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'how many leaves did employees take that affected their salary last month?',
        @sql NVARCHAR(MAX) = N'SELECT gsem.EmployeeName, gsem.EmployeeCode, gsem.NoofLeave, gsem.LOPDays, gsem.WorkingDays, gsem.PresentDays FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.LOPDays > 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY gsem.LOPDays DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3686, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3687 | Show salary breakup of all employees for last month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show salary breakup of all employees for last month',
        @sql NVARCHAR(MAX) = N'SELECT gsem.EmployeeName, gsem.EmployeeCode, gsed.Particulars, gsed.Amount, CASE WHEN gsed.TypeID = 1 THEN ''Earning'' ELSE ''Deduction'' END AS ComponentType FROM GenerateSalaryEmployee_Details gsed INNER JOIN GenerateSalaryEmployee_Master gsem ON gsed.MasterID = gsem.ID INNER JOIN GenerateSalary_Master gsm ON gsed.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY gsem.EmployeeName, gsed.TypeID, gsed.Particulars;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3687, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3688 | What are the total deductions component-wise this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What are the total deductions component-wise this month?',
        @sql NVARCHAR(MAX) = N'SELECT gsed.Particulars, SUM(gsed.Amount) AS TotalAmount, COUNT(gsed.ID) AS EmployeeCount FROM GenerateSalaryEmployee_Details gsed INNER JOIN GenerateSalary_Master gsm ON gsed.HeaderID = gsm.ID INNER JOIN GenerateSalaryEmployee_Master gsem ON gsed.MasterID = gsem.ID WHERE gsed.TypeID = 2 AND gsm.MonthID = MONTH(GETDATE()) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsed.Particulars ORDER BY TotalAmount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3688, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3689 | total PF contribution this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'total PF contribution this month',
        @sql NVARCHAR(MAX) = N'SELECT gsed.Particulars, SUM(gsed.Amount) AS TotalPF FROM GenerateSalaryEmployee_Details gsed INNER JOIN GenerateSalary_Master gsm ON gsed.HeaderID = gsm.ID INNER JOIN GenerateSalaryEmployee_Master gsem ON gsed.MasterID = gsem.ID WHERE gsed.TypeID = 2 AND gsed.Particulars LIKE ''%PF%'' AND gsm.MonthID = MONTH(GETDATE()) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsed.Particulars;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3689, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3690 | How much ESI was deducted from all staff this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much ESI was deducted from all staff this year?',
        @sql NVARCHAR(MAX) = N'SELECT gsm.MonthName, SUM(gsed.Amount) AS TotalESI FROM GenerateSalaryEmployee_Details gsed INNER JOIN GenerateSalary_Master gsm ON gsed.HeaderID = gsm.ID INNER JOIN GenerateSalaryEmployee_Master gsem ON gsed.MasterID = gsem.ID WHERE gsed.TypeID = 2 AND gsed.Particulars LIKE ''%ESI%'' AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsm.MonthName, gsm.MonthID ORDER BY gsm.MonthID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3690, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3691 | show all earning components and their total amounts ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'show all earning components and their total amounts',
        @sql NVARCHAR(MAX) = N'SELECT gsed.Particulars, SUM(gsed.Amount) AS TotalAmount, COUNT(DISTINCT gsed.EmployeeID) AS EmployeeCount FROM GenerateSalaryEmployee_Details gsed INNER JOIN GenerateSalary_Master gsm ON gsed.HeaderID = gsm.ID INNER JOIN GenerateSalaryEmployee_Master gsem ON gsed.MasterID = gsem.ID WHERE gsed.TypeID = 1 AND gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsed.Particulars ORDER BY TotalAmount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3691, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3692 | What is the salary structure of our teaching staff? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the salary structure of our teaching staff?',
        @sql NVARCHAR(MAX) = N'SELECT CONCAT(sm.Staff_FirstName, '' '', sm.Staff_LastName) AS StaffName, esd.Particulars, esd.Amount, CASE WHEN esd.TypeID = 1 THEN ''Earning'' ELSE ''Deduction'' END AS Type, esd.EffectiveDate FROM EmployeeSalaryDetails esd INNER JOIN EmployeeMaster em ON esd.EmployeeID = em.ID INNER JOIN Staff_Master sm ON em.StaffID = sm.Staff_ID AND sm.StaffStatus_ID = 1 WHERE em.IsDeleted = 0 AND em.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sm.StaffType_ID = 1 ORDER BY StaffName, esd.TypeID, esd.Particulars;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3692, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3693 | List employees with no salary structure defined ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List employees with no salary structure defined',
        @sql NVARCHAR(MAX) = N'SELECT CONCAT(sm.Staff_FirstName, '' '', sm.Staff_LastName) AS StaffName, sm.Staff_ID, em.ID AS EmployeeMasterID FROM EmployeeMaster em INNER JOIN Staff_Master sm ON em.StaffID = sm.Staff_ID AND sm.StaffStatus_ID = 1 WHERE em.IsDeleted = 0 AND em.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND NOT EXISTS (SELECT 1 FROM EmployeeSalaryDetails esd WHERE esd.EmployeeID = em.ID);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3693, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3694 | how many employees have their salary on hold? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'how many employees have their salary on hold?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS HoldCount FROM EmployeeMaster em WHERE em.IsHold = 1 AND em.IsDeleted = 0 AND em.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3694, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3695 | Bank-wise salary disbursement for last month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Bank-wise salary disbursement for last month',
        @sql NVARCHAR(MAX) = N'SELECT em.BankName, COUNT(gsem.ID) AS EmployeeCount, SUM(gsem.NetPay) AS TotalDisbursement FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID INNER JOIN EmployeeMaster em ON gsem.EmployeeID = em.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY em.BankName ORDER BY TotalDisbursement DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3695, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3696 | show me employees paid through cash ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'show me employees paid through cash',
        @sql NVARCHAR(MAX) = N'SELECT CONCAT(sm.Staff_FirstName, '' '', sm.Staff_LastName) AS StaffName, em.BankAccountNo, em.BankName, em.PaymentModeID FROM EmployeeMaster em INNER JOIN Staff_Master sm ON em.StaffID = sm.Staff_ID WHERE em.PaymentModeID = 2 AND em.IsDeleted = 0 AND em.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3696, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3697 | designation-wise average salary ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'designation-wise average salary',
        @sql NVARCHAR(MAX) = N'SELECT gsem.DesignationName, COUNT(gsem.ID) AS Headcount, AVG(gsem.NetPay) AS AvgNetPay, SUM(gsem.NetPay) AS TotalNetPay FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsem.DesignationName ORDER BY AvgNetPay DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3697, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3698 | how many teachers vs non-teaching staff and their salary comparison? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'how many teachers vs non-teaching staff and their salary comparison?',
        @sql NVARCHAR(MAX) = N'SELECT gsem.DesignationName, COUNT(gsem.ID) AS Headcount, SUM(gsem.GrossAmount) AS TotalGross, AVG(gsem.NetPay) AS AvgNetPay FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsem.DesignationName ORDER BY TotalGross DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3698, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3699 | staff type wise salary expenditure this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'staff type wise salary expenditure this year',
        @sql NVARCHAR(MAX) = N'SELECT gsm.StaffTypeName, gsm.MonthName, SUM(gsem.NetPay) AS TotalNetPay FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsm.StaffTypeName, gsm.MonthName, gsm.MonthID ORDER BY gsm.StaffTypeName, gsm.MonthID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3699, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3700 | employees who were present all working days last month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'employees who were present all working days last month',
        @sql NVARCHAR(MAX) = N'SELECT gsem.EmployeeName, gsem.EmployeeCode, gsem.DesignationName, gsem.WorkingDays, gsem.PresentDays, gsem.NetPay FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.PresentDays = gsem.WorkingDays AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY gsem.EmployeeName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
PRINT 'checkpoint: reached Q3700';
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3700, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3701 | staff with lowest attendance in salary month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'staff with lowest attendance in salary month',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 gsem.EmployeeName, gsem.EmployeeCode, gsem.DesignationName, gsem.WorkingDays, gsem.PresentDays, gsem.LOPDays, gsem.NoofLeave FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY gsem.PresentDays ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3701, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3702 | compare total salary expenditure month on month this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'compare total salary expenditure month on month this year',
        @sql NVARCHAR(MAX) = N'SELECT gsm.MonthName, gsm.MonthID, SUM(gsem.GrossAmount) AS TotalGross, SUM(gsem.NetPay) AS TotalNet, COUNT(gsem.ID) AS Headcount FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsm.MonthName, gsm.MonthID ORDER BY gsm.MonthID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3702, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3703 | which month had the highest payroll this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'which month had the highest payroll this year?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 gsm.MonthName, SUM(gsem.NetPay) AS TotalNetPay FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsm.MonthName, gsm.MonthID ORDER BY TotalNetPay DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3703, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3704 | kitna salary diya last month total? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'kitna salary diya last month total?',
        @sql NVARCHAR(MAX) = N'SELECT gsm.MonthName, SUM(gsem.NetPay) AS TotalNetPay, SUM(gsem.GrossAmount) AS TotalGross FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsm.MonthName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3704, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3705 | salary kitna badhaya is saal? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'salary kitna badhaya is saal?',
        @sql NVARCHAR(MAX) = N'-- This question asks about salary increments which require comparing salary structures across time periods. The system tracks current salary components but does not maintain historical increment records.
SELECT ''Salary increment history is not tracked in the current system. You can compare month-on-month gross amounts from GenerateSalaryEmployee_Master for approximate trends.'' AS Info;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3705, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3706 | give me a quick summary of this month's payroll ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'give me a quick summary of this month''s payroll',
        @sql NVARCHAR(MAX) = N'SELECT gsm.MonthName, COUNT(gsem.ID) AS TotalEmployees, SUM(gsem.GrossAmount) AS TotalGross, SUM(gsem.NetPay) AS TotalNet, SUM(gsem.GrossAmount) - SUM(gsem.NetPay) AS TotalDeductions, SUM(gsem.LOPDays) AS TotalLOPDays FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(GETDATE()) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsm.MonthName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3706, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3707 | has everyone's salary been generated for this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'has everyone''s salary been generated for this month?',
        @sql NVARCHAR(MAX) = N'SELECT CASE WHEN EXISTS (SELECT 1 FROM GenerateSalary_Master gsm WHERE gsm.MonthID = MONTH(GETDATE()) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (gsm.IsDeleted = 0 OR gsm.IsDeleted IS NULL)) THEN ''Yes'' ELSE ''No'' END AS SalaryGenerated, (SELECT COUNT(*) FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(GETDATE()) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AS EmployeesProcessed;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3707, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3708 | average salary of our school staff ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'average salary of our school staff',
        @sql NVARCHAR(MAX) = N'SELECT AVG(gsem.NetPay) AS AvgNetPay, AVG(gsem.GrossAmount) AS AvgGross FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3708, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3709 | total TDS deducted from staff salaries this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'total TDS deducted from staff salaries this year',
        @sql NVARCHAR(MAX) = N'SELECT gsm.MonthName, SUM(gsed.Amount) AS TotalTDS FROM GenerateSalaryEmployee_Details gsed INNER JOIN GenerateSalary_Master gsm ON gsed.HeaderID = gsm.ID INNER JOIN GenerateSalaryEmployee_Master gsem ON gsed.MasterID = gsem.ID WHERE gsed.TypeID = 2 AND gsed.Particulars LIKE ''%TDS%'' AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsm.MonthName, gsm.MonthID ORDER BY gsm.MonthID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3709, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3710 | employees whose salary was not generated this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'employees whose salary was not generated this month',
        @sql NVARCHAR(MAX) = N'SELECT CONCAT(sm.Staff_FirstName, '' '', sm.Staff_LastName) AS StaffName, sm.Staff_ID FROM Staff_Master sm INNER JOIN EmployeeMaster em ON sm.Staff_ID = em.StaffID WHERE sm.StaffStatus_ID = 1 AND em.IsDeleted = 0 AND em.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND NOT EXISTS (SELECT 1 FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsem.EmployeeID = em.ID AND gsm.MonthID = MONTH(GETDATE()) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3710, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3711 | Show me salary details of a specific employee by code E001 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me salary details of a specific employee by code E001',
        @sql NVARCHAR(MAX) = N'SELECT gsem.EmployeeName, gsem.EmployeeCode, gsm.MonthName, gsem.WorkingDays, gsem.PresentDays, gsem.LOPDays, gsem.GrossAmount, gsem.NetPay FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsem.EmployeeCode = ''E001'' AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY gsm.MonthID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3711, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3712 | salary slip components for employee code TCH005 last month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'salary slip components for employee code TCH005 last month',
        @sql NVARCHAR(MAX) = N'SELECT gsem.EmployeeName, gsed.Particulars, gsed.Amount, CASE WHEN gsed.TypeID = 1 THEN ''Earning'' ELSE ''Deduction'' END AS Type FROM GenerateSalaryEmployee_Details gsed INNER JOIN GenerateSalaryEmployee_Master gsem ON gsed.MasterID = gsem.ID INNER JOIN GenerateSalary_Master gsm ON gsed.HeaderID = gsm.ID WHERE gsem.EmployeeCode = ''TCH005'' AND gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY gsed.TypeID, gsed.Particulars;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3712, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3713 | How much HRA are we paying in total? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much HRA are we paying in total?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(gsed.Amount) AS TotalHRA, COUNT(DISTINCT gsed.EmployeeID) AS EmployeesReceiving FROM GenerateSalaryEmployee_Details gsed INNER JOIN GenerateSalary_Master gsm ON gsed.HeaderID = gsm.ID INNER JOIN GenerateSalaryEmployee_Master gsem ON gsed.MasterID = gsem.ID WHERE gsed.TypeID = 1 AND gsed.Particulars LIKE ''%HRA%'' AND gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3713, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3714 | staff type wise head count and total salary ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'staff type wise head count and total salary',
        @sql NVARCHAR(MAX) = N'SELECT gsm.StaffTypeName, COUNT(gsem.ID) AS Headcount, SUM(gsem.GrossAmount) AS TotalGross, SUM(gsem.NetPay) AS TotalNet FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsm.StaffTypeName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3714, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3715 | which staff type costs us the most? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'which staff type costs us the most?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 gsm.StaffTypeName, SUM(gsem.NetPay) AS TotalCost, COUNT(gsem.ID) AS Headcount FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsm.StaffTypeName ORDER BY TotalCost DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3715, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3716 | net pay vs gross for all employees last month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'net pay vs gross for all employees last month',
        @sql NVARCHAR(MAX) = N'SELECT gsem.EmployeeName, gsem.EmployeeCode, gsem.GrossAmount, gsem.NetPay, gsem.GrossAmount - gsem.NetPay AS TotalDeductions FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY gsem.EmployeeName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3716, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3717 | show me payroll summary by designation for march ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'show me payroll summary by designation for march',
        @sql NVARCHAR(MAX) = N'SELECT gsem.DesignationName, COUNT(gsem.ID) AS Headcount, SUM(gsem.GrossAmount) AS TotalGross, SUM(gsem.NetPay) AS TotalNet, AVG(gsem.NetPay) AS AvgNetPay FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = 3 AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsem.DesignationName ORDER BY TotalGross DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3717, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3718 | employees with zero net pay ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'employees with zero net pay',
        @sql NVARCHAR(MAX) = N'SELECT gsem.EmployeeName, gsem.EmployeeCode, gsem.DesignationName, gsem.GrossAmount, gsem.NetPay, gsem.LOPDays FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.NetPay = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3718, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3719 | monthly payroll trend graph data ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'monthly payroll trend graph data',
        @sql NVARCHAR(MAX) = N'SELECT gsm.MonthName, gsm.MonthID, SUM(gsem.GrossAmount) AS TotalGross, SUM(gsem.NetPay) AS TotalNet, COUNT(gsem.ID) AS Headcount, SUM(gsem.LOPDays) AS TotalLOP FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsm.MonthName, gsm.MonthID ORDER BY gsm.MonthID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3719, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3720 | salary not yet generated for which months? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'salary not yet generated for which months?',
        @sql NVARCHAR(MAX) = N'SELECT mm.Month_Name FROM Month_Master mm WHERE mm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND mm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND mm.Actual_Month_No NOT IN (SELECT gsm.MonthID FROM GenerateSalary_Master gsm WHERE gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (gsm.IsDeleted = 0 OR gsm.IsDeleted IS NULL)) AND mm.StartDate <= GETDATE() ORDER BY mm.Month_No;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3720, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3721 | difference between gross and net salary for all staff ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'difference between gross and net salary for all staff',
        @sql NVARCHAR(MAX) = N'SELECT gsem.EmployeeName, gsem.EmployeeCode, gsem.GrossAmount, gsem.NetPay, gsem.GrossAmount - gsem.NetPay AS Deductions, CAST((gsem.GrossAmount - gsem.NetPay) * 100.0 / NULLIF(gsem.GrossAmount, 0) AS DECIMAL(5,2)) AS DeductionPercent FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY DeductionPercent DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3721, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3722 | total salary cost year to date ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'total salary cost year to date',
        @sql NVARCHAR(MAX) = N'SELECT SUM(gsem.GrossAmount) AS YTDGross, SUM(gsem.NetPay) AS YTDNet, SUM(gsem.GrossAmount) - SUM(gsem.NetPay) AS YTDDeductions FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3722, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3723 | salary expenditure as percentage of fee collection ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'salary expenditure as percentage of fee collection',
        @sql NVARCHAR(MAX) = N'SELECT (SELECT SUM(gsem.NetPay) FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AS TotalSalary, (SELECT SUM(fc.Receipt_Amt) FROM FeesCollection fc WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AS TotalFeeCollection;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3723, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3724 | employees with highest deductions ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'employees with highest deductions',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 gsem.EmployeeName, gsem.EmployeeCode, gsem.GrossAmount, gsem.NetPay, gsem.GrossAmount - gsem.NetPay AS TotalDeductions FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY TotalDeductions DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3724, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3725 | how many employees received salary last month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'how many employees received salary last month?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS EmployeesProcessed FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3725, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3726 | month wise headcount in payroll ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'month wise headcount in payroll',
        @sql NVARCHAR(MAX) = N'SELECT gsm.MonthName, COUNT(gsem.ID) AS Headcount FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsm.MonthName, gsm.MonthID ORDER BY gsm.MonthID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3726, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3727 | salary component wise total for last month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'salary component wise total for last month',
        @sql NVARCHAR(MAX) = N'SELECT gsed.Particulars, gsed.TypeID, CASE WHEN gsed.TypeID = 1 THEN ''Earning'' ELSE ''Deduction'' END AS Type, SUM(gsed.Amount) AS Total, COUNT(DISTINCT gsed.EmployeeID) AS EmployeeCount FROM GenerateSalaryEmployee_Details gsed INNER JOIN GenerateSalary_Master gsm ON gsed.HeaderID = gsm.ID INNER JOIN GenerateSalaryEmployee_Master gsem ON gsed.MasterID = gsem.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsed.Particulars, gsed.TypeID ORDER BY gsed.TypeID, Total DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3727, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3728 | any employee with negative net pay? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'any employee with negative net pay?',
        @sql NVARCHAR(MAX) = N'SELECT gsem.EmployeeName, gsem.EmployeeCode, gsem.GrossAmount, gsem.NetPay FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.NetPay < 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3728, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3729 | show me the salary structure template for employee ID 5 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'show me the salary structure template for employee ID 5',
        @sql NVARCHAR(MAX) = N'SELECT esd.Particulars, esd.Amount, CASE WHEN esd.TypeID = 1 THEN ''Earning'' ELSE ''Deduction'' END AS Type, esd.EffectiveDate FROM EmployeeSalaryDetails esd WHERE esd.EmployeeID = 5 ORDER BY esd.TypeID, esd.Particulars;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3729, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3730 | employees getting more than 10000 in basic pay ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'employees getting more than 10000 in basic pay',
        @sql NVARCHAR(MAX) = N'SELECT gsem.EmployeeName, gsem.EmployeeCode, gsed.Particulars, gsed.Amount FROM GenerateSalaryEmployee_Details gsed INNER JOIN GenerateSalaryEmployee_Master gsem ON gsed.MasterID = gsem.ID INNER JOIN GenerateSalary_Master gsm ON gsed.HeaderID = gsm.ID WHERE gsed.TypeID = 1 AND gsed.Particulars LIKE ''%Basic%'' AND gsed.Amount > 10000 AND gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY gsed.Amount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3730, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3731 | total professional tax deducted ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'total professional tax deducted',
        @sql NVARCHAR(MAX) = N'SELECT SUM(gsed.Amount) AS TotalProfTax, COUNT(DISTINCT gsed.EmployeeID) AS EmployeeCount FROM GenerateSalaryEmployee_Details gsed INNER JOIN GenerateSalary_Master gsm ON gsed.HeaderID = gsm.ID INNER JOIN GenerateSalaryEmployee_Master gsem ON gsed.MasterID = gsem.ID WHERE gsed.TypeID = 2 AND gsed.Particulars LIKE ''%Professional Tax%'' AND gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3731, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3732 | payroll generated date for last month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'payroll generated date for last month',
        @sql NVARCHAR(MAX) = N'SELECT gsm.MonthName, gsm.StaffTypeName, gsm.ID FROM GenerateSalary_Master gsm WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (gsm.IsDeleted = 0 OR gsm.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3732, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3733 | which designation has the maximum employees? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'which designation has the maximum employees?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 gsem.DesignationName, COUNT(*) AS EmployeeCount FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsem.DesignationName ORDER BY EmployeeCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3733, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3734 | is salary done for june? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'is salary done for june?',
        @sql NVARCHAR(MAX) = N'SELECT CASE WHEN EXISTS (SELECT 1 FROM GenerateSalary_Master gsm WHERE gsm.MonthID = 6 AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (gsm.IsDeleted = 0 OR gsm.IsDeleted IS NULL)) THEN ''Yes'' ELSE ''No'' END AS SalaryGenerated;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3734, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3735 | total manpower cost per month on average ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'total manpower cost per month on average',
        @sql NVARCHAR(MAX) = N'SELECT AVG(MonthTotal) AS AvgMonthlyCost FROM (SELECT gsm.MonthID, SUM(gsem.NetPay) AS MonthTotal FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsm.MonthID) t;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3735, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3736 | staff whose salary is less than 15000 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'staff whose salary is less than 15000',
        @sql NVARCHAR(MAX) = N'SELECT gsem.EmployeeName, gsem.EmployeeCode, gsem.DesignationName, gsem.NetPay FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.NetPay < 15000 AND gsem.NetPay > 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY gsem.NetPay;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3736, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3737 | salary comparison between teaching and non-teaching ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'salary comparison between teaching and non-teaching',
        @sql NVARCHAR(MAX) = N'SELECT gsm.StaffTypeName, COUNT(gsem.ID) AS Headcount, SUM(gsem.GrossAmount) AS TotalGross, AVG(gsem.NetPay) AS AvgNetPay, MIN(gsem.NetPay) AS MinPay, MAX(gsem.NetPay) AS MaxPay FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsm.StaffTypeName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3737, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3738 | employee bank account details for salary transfer ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'employee bank account details for salary transfer',
        @sql NVARCHAR(MAX) = N'SELECT CONCAT(sm.Staff_FirstName, '' '', sm.Staff_LastName) AS StaffName, em.BankName, em.BankAccountNo, em.BankIFSCCode, em.BankBranchName FROM EmployeeMaster em INNER JOIN Staff_Master sm ON em.StaffID = sm.Staff_ID WHERE em.IsDeleted = 0 AND em.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY StaffName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3738, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3739 | What is the total salary bill for the current academic year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total salary bill for the current academic year?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(gsem.GrossAmount) AS TotalGrossBill, SUM(gsem.NetPay) AS TotalNetBill FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3739, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3740 | Show salary details for teaching staff only ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show salary details for teaching staff only',
        @sql NVARCHAR(MAX) = N'SELECT gsem.EmployeeName, gsem.EmployeeCode, gsem.DesignationName, gsem.GrossAmount, gsem.NetPay, gsem.PresentDays, gsem.WorkingDays FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.StaffTypeID = 1 AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY gsem.EmployeeName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3740, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3741 | non-teaching staff salary last month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'non-teaching staff salary last month',
        @sql NVARCHAR(MAX) = N'SELECT gsem.EmployeeName, gsem.EmployeeCode, gsem.DesignationName, gsem.GrossAmount, gsem.NetPay FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.StaffTypeID = 2 AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY gsem.EmployeeName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3741, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3742 | who has the most leaves affecting salary? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'who has the most leaves affecting salary?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 5 gsem.EmployeeName, gsem.EmployeeCode, gsem.NoofLeave, gsem.LOPDays FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY gsem.LOPDays DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3742, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3743 | salary details of staff with employee code ADM001 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'salary details of staff with employee code ADM001',
        @sql NVARCHAR(MAX) = N'SELECT gsem.EmployeeName, gsem.EmployeeCode, gsm.MonthName, gsem.WorkingDays, gsem.PresentDays, gsem.LOPDays, gsem.GrossAmount, gsem.NetPay FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsem.EmployeeCode = ''ADM001'' AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY gsm.MonthID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3743, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3744 | how much do we spend on allowances in total? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'how much do we spend on allowances in total?',
        @sql NVARCHAR(MAX) = N'SELECT gsed.Particulars, SUM(gsed.Amount) AS TotalAmount FROM GenerateSalaryEmployee_Details gsed INNER JOIN GenerateSalary_Master gsm ON gsed.HeaderID = gsm.ID INNER JOIN GenerateSalaryEmployee_Master gsem ON gsed.MasterID = gsem.ID WHERE gsed.TypeID = 1 AND gsed.Particulars LIKE ''%Allowance%'' AND gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY gsed.Particulars ORDER BY TotalAmount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3744, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3745 | list all salary components we pay ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'list all salary components we pay',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT gsed.Particulars, CASE WHEN gsed.TypeID = 1 THEN ''Earning'' ELSE ''Deduction'' END AS Type FROM GenerateSalaryEmployee_Details gsed INNER JOIN GenerateSalary_Master gsm ON gsed.HeaderID = gsm.ID INNER JOIN GenerateSalaryEmployee_Master gsem ON gsed.MasterID = gsem.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY Type, gsed.Particulars;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3745, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3746 | median salary of all employees ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'median salary of all employees',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY gsem.NetPay) OVER () AS MedianSalary FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.MonthID = MONTH(DATEADD(MONTH, -1, GETDATE())) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3746, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3747 | employees not processed in salary this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'employees not processed in salary this month',
        @sql NVARCHAR(MAX) = N'SELECT CONCAT(sm.Staff_FirstName, '' '', sm.Staff_LastName) AS StaffName, sm.Staff_ID FROM Staff_Master sm INNER JOIN EmployeeMaster em ON sm.Staff_ID = em.StaffID WHERE sm.StaffStatus_ID = 1 AND em.IsDeleted = 0 AND em.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND NOT EXISTS (SELECT 1 FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsem.EmployeeID = em.ID AND gsm.MonthID = MONTH(GETDATE()) AND gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3747, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3748 | total salary deductions year to date ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'total salary deductions year to date',
        @sql NVARCHAR(MAX) = N'SELECT SUM(gsem.GrossAmount - gsem.NetPay) AS TotalDeductionsYTD FROM GenerateSalaryEmployee_Master gsem INNER JOIN GenerateSalary_Master gsm ON gsem.HeaderID = gsm.ID WHERE gsm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gsem.IsDeleted = 0 AND gsem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3748, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3749 | How many routes do we have? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many routes do we have?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalRoutes FROM Route_Master WHERE IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3749, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3750 | List all active transport routes ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all active transport routes',
        @sql NVARCHAR(MAX) = N'SELECT rm.Code, rm.Name, rm.Description, rm.VehicleNo FROM Route_Master rm WHERE rm.IsDeleted = 0 AND rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND rm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY rm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3750, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3751 | show me route details with vehicle numbers ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'show me route details with vehicle numbers',
        @sql NVARCHAR(MAX) = N'SELECT rm.Code, rm.Name, rm.VehicleNo, rm.Description FROM Route_Master rm WHERE rm.IsDeleted = 0 AND rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND rm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY rm.Code;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3751, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3752 | which routes have GPS tracking enabled? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'which routes have GPS tracking enabled?',
        @sql NVARCHAR(MAX) = N'SELECT rm.Code, rm.Name, rm.VehicleNo, rm.Imei, rm.URL FROM Route_Master rm WHERE rm.IsDeleted = 0 AND rm.Imei IS NOT NULL AND rm.Imei != '''' AND rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND rm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY rm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3752, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3753 | List all boarding points with their fees ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all boarding points with their fees',
        @sql NVARCHAR(MAX) = N'SELECT bp.Name, bp.Description, bp.Amount FROM BoardingPoint_Master bp WHERE bp.IsDeleted = 0 AND bp.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bp.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY CAST(CAST(bp.Amount AS DECIMAL(18,2)) AS DECIMAL(18,2)) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3753, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3754 | which boarding point charges the highest transport fee? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'which boarding point charges the highest transport fee?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 bp.Name, bp.Amount FROM BoardingPoint_Master bp WHERE bp.IsDeleted = 0 AND bp.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bp.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY CAST(CAST(bp.Amount AS DECIMAL(18,2)) AS DECIMAL(18,2)) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3754, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3755 | How many boarding points does each route have? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many boarding points does each route have?',
        @sql NVARCHAR(MAX) = N'SELECT rm.Name AS RouteName, COUNT(rmd.Id) AS BoardingPointCount FROM Route_Master rm INNER JOIN Route_MasterDetails rmd ON rm.ID = rmd.Route_ID WHERE rm.IsDeleted = 0 AND rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND rm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY rm.Name ORDER BY BoardingPointCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3755, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3756 | show boarding points for route 1 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'show boarding points for route 1',
        @sql NVARCHAR(MAX) = N'SELECT rm.Name AS RouteName, bp.Name AS BoardingPoint, CAST(bp.Amount AS DECIMAL(18,2)) FROM Route_MasterDetails rmd INNER JOIN Route_Master rm ON rmd.Route_ID = rm.ID INNER JOIN BoardingPoint_Master bp ON rmd.BoardingPoint_ID = bp.Id WHERE rm.IsDeleted = 0 AND rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND rm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND rm.Code = ''1'' ORDER BY bp.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3756, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3757 | List all vehicles with their details ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all vehicles with their details',
        @sql NVARCHAR(MAX) = N'SELECT vm.Vehicle_Number, vm.Vehicle_Type_Name, vm.Make, vm.Model, vm.Seating_Capacity, vm.Fuel_Type_Name FROM VehicleMaster vm WHERE vm.IsDeleted = 0 AND vm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND vm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY vm.Vehicle_Number;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3757, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3758 | vehicles with FC expiring this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'vehicles with FC expiring this month',
        @sql NVARCHAR(MAX) = N'SELECT vm.Vehicle_Number, vm.Vehicle_Type_Name, vm.Registration_Number, vm.FC_Date, DATEDIFF(DAY, GETDATE(), vm.FC_Date) AS DaysRemaining FROM VehicleMaster vm WHERE vm.IsDeleted = 0 AND MONTH(vm.FC_Date) = MONTH(GETDATE()) AND YEAR(vm.FC_Date) = YEAR(GETDATE()) AND vm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND vm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY vm.FC_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3758, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3759 | total seating capacity of all our buses ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'total seating capacity of all our buses',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CAST(vm.Seating_Capacity AS INT)) AS TotalCapacity, COUNT(*) AS TotalVehicles FROM VehicleMaster vm WHERE vm.IsDeleted = 0 AND vm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND vm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3759, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3760 | show vehicles by fuel type ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'show vehicles by fuel type',
        @sql NVARCHAR(MAX) = N'SELECT vm.Fuel_Type_Name, COUNT(*) AS VehicleCount, SUM(CAST(vm.Seating_Capacity AS INT)) AS TotalCapacity FROM VehicleMaster vm WHERE vm.IsDeleted = 0 AND vm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND vm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY vm.Fuel_Type_Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3760, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3761 | List all drivers with their contact details ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all drivers with their contact details',
        @sql NVARCHAR(MAX) = N'SELECT dm.Name, dm.Mobile, dm.Email, dm.License_Number, dm.Experience FROM DriverMaster dm WHERE dm.IsDeleted = 0 AND dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY dm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3761, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3762 | drivers whose license is expiring within 3 months ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'drivers whose license is expiring within 3 months',
        @sql NVARCHAR(MAX) = N'SELECT dm.Name, dm.License_Number, dm.License_Expiry_Date, DATEDIFF(DAY, GETDATE(), dm.License_Expiry_Date) AS DaysRemaining, dm.Mobile FROM DriverMaster dm WHERE dm.IsDeleted = 0 AND dm.License_Expiry_Date <= DATEADD(MONTH, 3, GETDATE()) AND dm.License_Expiry_Date >= GETDATE() AND dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY dm.License_Expiry_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3762, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3763 | which driver covers the most distance per day? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'which driver covers the most distance per day?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 dm.Name, dm.DistancePerDay, dm.Mobile, dm.Experience FROM DriverMaster dm WHERE dm.IsDeleted = 0 AND dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY CAST(dm.DistancePerDay AS DECIMAL(10,2)) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3763, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3764 | how many drivers do we have? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'how many drivers do we have?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalDrivers FROM DriverMaster dm WHERE dm.IsDeleted = 0 AND dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3764, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3765 | How many students are using school transport? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students are using school transport?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT bfs.Student_ID) AS TransportStudents FROM BusFeeStrucure bfs WHERE bfs.IsDeleted = 0 AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3765, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3766 | students on each route ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'students on each route',
        @sql NVARCHAR(MAX) = N'SELECT rm.Name AS RouteName, COUNT(DISTINCT bfs.Student_ID) AS StudentCount FROM BusFeeStrucure bfs INNER JOIN Route_Master rm ON bfs.Route_ID = rm.ID WHERE bfs.IsDeleted = 0 AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY rm.Name ORDER BY StudentCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3766, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3767 | route wise transport fee expected ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'route wise transport fee expected',
        @sql NVARCHAR(MAX) = N'SELECT rm.Name AS RouteName, SUM(bfs.Amount) AS TotalExpected, COUNT(DISTINCT bfs.Student_ID) AS StudentCount FROM BusFeeStrucure bfs INNER JOIN Route_Master rm ON bfs.Route_ID = rm.ID WHERE bfs.IsDeleted = 0 AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY rm.Name ORDER BY TotalExpected DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3767, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3768 | which students are assigned to boarding point park street? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'which students are assigned to boarding point park street?',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT stm.AdmissionNo, stm.FirstName, stm.LastName, bp.Name AS BoardingPoint FROM BusFeeStrucure bfs INNER JOIN Student_Master stm ON bfs.Student_ID = stm.ID INNER JOIN BoardingPoint_Master bp ON bfs.BoardingPoint_ID = bp.Id WHERE bfs.IsDeleted = 0 AND bp.Name LIKE ''%park street%'' AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY stm.FirstName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3768, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3769 | what are the transport trip timings? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'what are the transport trip timings?',
        @sql NVARCHAR(MAX) = N'SELECT ttd.TransportSessionName, ttd.TransportStartTime, ttd.TransportEndTime, rm.Name AS RouteName FROM Transport_TripDetails ttd INNER JOIN Route_Master rm ON ttd.RouteID = rm.ID WHERE ttd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ttd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY rm.Name, ttd.TransportStartTime;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3769, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3770 | morning trip schedule for all routes ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'morning trip schedule for all routes',
        @sql NVARCHAR(MAX) = N'SELECT rm.Name AS RouteName, ttd.TransportSessionName, ttd.TransportStartTime, ttd.TransportEndTime FROM Transport_TripDetails ttd INNER JOIN Route_Master rm ON ttd.RouteID = rm.ID WHERE ttd.TransportSessionName LIKE ''%Morning%'' AND ttd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ttd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY ttd.TransportStartTime;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3770, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3771 | how many trips does each route have? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'how many trips does each route have?',
        @sql NVARCHAR(MAX) = N'SELECT rm.Name AS RouteName, COUNT(ttd.ID) AS TripCount FROM Transport_TripDetails ttd INNER JOIN Route_Master rm ON ttd.RouteID = rm.ID WHERE ttd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ttd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY rm.Name ORDER BY TripCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3771, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3772 | bus ka insurance kab expire ho raha hai? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'bus ka insurance kab expire ho raha hai?',
        @sql NVARCHAR(MAX) = N'SELECT vm.Vehicle_Number, vm.Insurance_Number, vm.Insurance_Expiry_Date, DATEDIFF(DAY, GETDATE(), vm.Insurance_Expiry_Date) AS DaysRemaining FROM VehicleMaster vm WHERE vm.IsDeleted = 0 AND vm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND vm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY vm.Insurance_Expiry_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3772, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3773 | kitne bacche bus use karte hain? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'kitne bacche bus use karte hain?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT bfs.Student_ID) AS TransportStudents FROM BusFeeStrucure bfs WHERE bfs.IsDeleted = 0 AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3773, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3774 | transport fee pending for this term ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'transport fee pending for this term',
        @sql NVARCHAR(MAX) = N'SELECT rm.Name AS RouteName, SUM(bfs.Amount) AS ExpectedFee FROM BusFeeStrucure bfs INNER JOIN Route_Master rm ON bfs.Route_ID = rm.ID INNER JOIN TermMaster tm ON bfs.Term_ID = tm.ID WHERE bfs.IsDeleted = 0 AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND tm.ID = (SELECT TOP 1 t.ID FROM TermMaster t WHERE t.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND t.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY t.ID) GROUP BY rm.Name ORDER BY ExpectedFee DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3774, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3775 | which route has the most students? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'which route has the most students?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 rm.Name AS RouteName, COUNT(DISTINCT bfs.Student_ID) AS StudentCount FROM BusFeeStrucure bfs INNER JOIN Route_Master rm ON bfs.Route_ID = rm.ID WHERE bfs.IsDeleted = 0 AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY rm.Name ORDER BY StudentCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3775, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3776 | boarding point wise student distribution for route A ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'boarding point wise student distribution for route A',
        @sql NVARCHAR(MAX) = N'SELECT bp.Name AS BoardingPoint, COUNT(DISTINCT bfs.Student_ID) AS StudentCount, CAST(bp.Amount AS DECIMAL(18,2)) AS FeeAmount FROM BusFeeStrucure bfs INNER JOIN BoardingPoint_Master bp ON bfs.BoardingPoint_ID = bp.Id INNER JOIN Route_Master rm ON bfs.Route_ID = rm.ID WHERE bfs.IsDeleted = 0 AND rm.Name LIKE ''%A%'' AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY bp.Name, bp.Amount ORDER BY StudentCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3776, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3777 | total transport revenue expected this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'total transport revenue expected this year',
        @sql NVARCHAR(MAX) = N'SELECT SUM(bfs.Amount) AS TotalTransportRevenue, COUNT(DISTINCT bfs.Student_ID) AS TotalStudents FROM BusFeeStrucure bfs WHERE bfs.IsDeleted = 0 AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3777, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3778 | how many seats are available across all buses? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'how many seats are available across all buses?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CAST(vm.Seating_Capacity AS INT)) AS TotalSeats FROM VehicleMaster vm WHERE vm.IsDeleted = 0 AND vm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND vm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3778, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3779 | drivers with expired license ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'drivers with expired license',
        @sql NVARCHAR(MAX) = N'SELECT dm.Name, dm.License_Number, dm.License_Expiry_Date, dm.Mobile FROM DriverMaster dm WHERE dm.IsDeleted = 0 AND dm.License_Expiry_Date < GETDATE() AND dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY dm.License_Expiry_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3779, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3780 | term wise transport fee breakup ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'term wise transport fee breakup',
        @sql NVARCHAR(MAX) = N'SELECT tm.Name AS TermName, SUM(bfs.Amount) AS TermFee, COUNT(DISTINCT bfs.Student_ID) AS StudentCount FROM BusFeeStrucure bfs INNER JOIN TermMaster tm ON bfs.Term_ID = tm.ID WHERE bfs.IsDeleted = 0 AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY tm.Name ORDER BY tm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3780, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3781 | show trip details for evening session ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'show trip details for evening session',
        @sql NVARCHAR(MAX) = N'SELECT rm.Name AS RouteName, ttd.TransportSessionName, ttd.TransportStartTime, ttd.TransportEndTime FROM Transport_TripDetails ttd INNER JOIN Route_Master rm ON ttd.RouteID = rm.ID WHERE ttd.TransportSessionName LIKE ''%Evening%'' AND ttd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ttd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY rm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3781, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3782 | route wise boarding point and fees ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'route wise boarding point and fees',
        @sql NVARCHAR(MAX) = N'SELECT rm.Name AS RouteName, bp.Name AS BoardingPoint, CAST(bp.Amount AS DECIMAL(18,2)) FROM Route_MasterDetails rmd INNER JOIN Route_Master rm ON rmd.Route_ID = rm.ID INNER JOIN BoardingPoint_Master bp ON rmd.BoardingPoint_ID = bp.Id WHERE rm.IsDeleted = 0 AND rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND rm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY rm.Name, CAST(bp.Amount AS DECIMAL(18,2)) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3782, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3783 | list students using transport in class 10 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'list students using transport in class 10',
        @sql NVARCHAR(MAX) = N'SELECT stm.AdmissionNo, stm.FirstName, stm.LastName, rm.Name AS RouteName, bp.Name AS BoardingPoint FROM BusFeeStrucure bfs INNER JOIN Student_Master stm ON bfs.Student_ID = stm.ID INNER JOIN Route_Master rm ON bfs.Route_ID = rm.ID INNER JOIN BoardingPoint_Master bp ON bfs.BoardingPoint_ID = bp.Id INNER JOIN ClassMaster cm ON bfs.Class_ID = cm.ID WHERE bfs.IsDeleted = 0 AND cm.Name IN (''Class 10'', ''X'') AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY stm.FirstName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3783, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3784 | students without transport assigned ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'students without transport assigned',
        @sql NVARCHAR(MAX) = N'SELECT TOP 100 stm.AdmissionNo, stm.FirstName, stm.LastName, cm.Name AS ClassName FROM StudentAcademicDetail sad INNER JOIN Student_Master stm ON sad.StudentID = stm.ID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND NOT EXISTS (SELECT 1 FROM BusFeeStrucure bfs WHERE bfs.Student_ID = sad.StudentID AND bfs.IsDeleted = 0 AND bfs.AcademicYearID = sad.AcademicYearID) ORDER BY cm.Name, stm.FirstName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3784, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3785 | percentage of students using transport ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'percentage of students using transport',
        @sql NVARCHAR(MAX) = N'SELECT (SELECT COUNT(DISTINCT bfs.Student_ID) FROM BusFeeStrucure bfs WHERE bfs.IsDeleted = 0 AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)))) AS TransportStudents, (SELECT COUNT(DISTINCT sad.StudentID) FROM StudentAcademicDetail sad WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1) AS TotalStudents, CAST((SELECT COUNT(DISTINCT bfs.Student_ID) FROM BusFeeStrucure bfs WHERE bfs.IsDeleted = 0 AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)))) * 100.0 / NULLIF((SELECT COUNT(DISTINCT sad.StudentID) FROM StudentAcademicDetail sad WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1), 0) AS DECIMAL(5,2)) AS TransportPercent;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3785, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3786 | route with maximum boarding points ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'route with maximum boarding points',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 rm.Name AS RouteName, COUNT(rmd.Id) AS BoardingPoints FROM Route_Master rm INNER JOIN Route_MasterDetails rmd ON rm.ID = rmd.Route_ID WHERE rm.IsDeleted = 0 AND rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND rm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY rm.Name ORDER BY BoardingPoints DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3786, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3787 | cheapest and costliest boarding point ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'cheapest and costliest boarding point',
        @sql NVARCHAR(MAX) = N'SELECT ''Cheapest'' AS Type, bp.Name, CAST(bp.Amount AS DECIMAL(18,2)) FROM BoardingPoint_Master bp WHERE bp.IsDeleted = 0 AND bp.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bp.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND CAST(bp.Amount AS DECIMAL(18,2)) = (SELECT MIN(Amount) FROM BoardingPoint_Master WHERE IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)))) UNION ALL SELECT ''Costliest'', bp.Name, CAST(bp.Amount AS DECIMAL(18,2)) FROM BoardingPoint_Master bp WHERE bp.IsDeleted = 0 AND bp.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bp.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND CAST(bp.Amount AS DECIMAL(18,2)) = (SELECT MAX(Amount) FROM BoardingPoint_Master WHERE IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3787, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3788 | vehicle wise registration and engine details ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'vehicle wise registration and engine details',
        @sql NVARCHAR(MAX) = N'SELECT vm.Vehicle_Number, vm.Registration_Number, vm.Engine_Number, vm.Make, vm.Model, vm.Seating_Capacity FROM VehicleMaster vm WHERE vm.IsDeleted = 0 AND vm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND vm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY vm.Vehicle_Number;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3788, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3789 | total distance covered by all drivers per day ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'total distance covered by all drivers per day',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CAST(dm.DistancePerDay AS DECIMAL(10,2))) AS TotalDailyDistance, COUNT(*) AS TotalDrivers, AVG(CAST(dm.DistancePerDay AS DECIMAL(10,2))) AS AvgDistance FROM DriverMaster dm WHERE dm.IsDeleted = 0 AND dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3789, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3790 | most experienced driver ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'most experienced driver',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 dm.Name, dm.Experience, dm.License_Number, dm.Mobile, dm.DistancePerDay FROM DriverMaster dm WHERE dm.IsDeleted = 0 AND dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY dm.Experience DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3790, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3791 | routes without GPS tracking ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'routes without GPS tracking',
        @sql NVARCHAR(MAX) = N'SELECT rm.Code, rm.Name, rm.VehicleNo FROM Route_Master rm WHERE rm.IsDeleted = 0 AND (rm.Imei IS NULL OR rm.Imei = '''') AND rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND rm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY rm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3791, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3792 | student transport fee month wise ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'student transport fee month wise',
        @sql NVARCHAR(MAX) = N'SELECT bfs.Month_Name, SUM(bfs.Amount) AS MonthlyFee, COUNT(DISTINCT bfs.Student_ID) AS Students FROM BusFeeStrucure bfs WHERE bfs.IsDeleted = 0 AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY bfs.Month_Name, bfs.Month_No ORDER BY bfs.Month_No;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3792, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3793 | trip wise student count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'trip wise student count',
        @sql NVARCHAR(MAX) = N'SELECT ttd.TransportSessionName, COUNT(DISTINCT bfs.Student_ID) AS StudentCount FROM BusFeeStrucure bfs INNER JOIN Transport_TripDetails ttd ON bfs.TripID = ttd.ID WHERE bfs.IsDeleted = 0 AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY ttd.TransportSessionName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3793, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3794 | average transport fee per student ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'average transport fee per student',
        @sql NVARCHAR(MAX) = N'SELECT AVG(StudentTotal) AS AvgTransportFee FROM (SELECT bfs.Student_ID, SUM(bfs.Amount) AS StudentTotal FROM BusFeeStrucure bfs WHERE bfs.IsDeleted = 0 AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY bfs.Student_ID) t;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3794, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3795 | section wise transport users in class 8 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'section wise transport users in class 8',
        @sql NVARCHAR(MAX) = N'SELECT secm.Name AS SectionName, COUNT(DISTINCT bfs.Student_ID) AS TransportStudents FROM BusFeeStrucure bfs INNER JOIN SectionMaster secm ON bfs.Section_ID = secm.ID INNER JOIN ClassMaster cm ON bfs.Class_ID = cm.ID WHERE bfs.IsDeleted = 0 AND cm.Name IN (''Class 8'', ''VIII'') AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY secm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3795, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3796 | Which vehicle has the maximum seating capacity? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which vehicle has the maximum seating capacity?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 vm.Vehicle_Number, vm.Vehicle_Type_Name, vm.Make, vm.Model, vm.Seating_Capacity FROM VehicleMaster vm WHERE vm.IsDeleted = 0 AND vm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND vm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY CAST(vm.Seating_Capacity AS INT) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3796, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3797 | route wise vehicle allocation ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'route wise vehicle allocation',
        @sql NVARCHAR(MAX) = N'SELECT rm.Name AS RouteName, rm.VehicleNo FROM Route_Master rm WHERE rm.IsDeleted = 0 AND rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND rm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY rm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3797, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3798 | students paying more than 5000 transport fee per month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'students paying more than 5000 transport fee per month',
        @sql NVARCHAR(MAX) = N'SELECT stm.AdmissionNo, stm.FirstName, stm.LastName, rm.Name AS RouteName, bfs.Amount FROM BusFeeStrucure bfs INNER JOIN Student_Master stm ON bfs.Student_ID = stm.ID INNER JOIN Route_Master rm ON bfs.Route_ID = rm.ID WHERE bfs.IsDeleted = 0 AND bfs.Amount > 5000 AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY bfs.Amount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3798, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3799 | transport fee summary by class and section ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'transport fee summary by class and section',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, secm.Name AS SectionName, COUNT(DISTINCT bfs.Student_ID) AS Students, SUM(bfs.Amount) AS TotalFee FROM BusFeeStrucure bfs INNER JOIN ClassMaster cm ON bfs.Class_ID = cm.ID INNER JOIN SectionMaster secm ON bfs.Section_ID = secm.ID WHERE bfs.IsDeleted = 0 AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY cm.Name, secm.Name ORDER BY cm.Name, secm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3799, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3800 | driver details with Aadhar number ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'driver details with Aadhar number',
        @sql NVARCHAR(MAX) = N'SELECT dm.Name, dm.Mobile, dm.License_Number, dm.Aadhar_Number, dm.Address FROM DriverMaster dm WHERE dm.IsDeleted = 0 AND dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY dm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
PRINT 'checkpoint: reached Q3800';
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3800, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3801 | how many students per trip session? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'how many students per trip session?',
        @sql NVARCHAR(MAX) = N'SELECT ttd.TransportSessionName, rm.Name AS RouteName, COUNT(DISTINCT bfs.Student_ID) AS StudentCount FROM BusFeeStrucure bfs INNER JOIN Transport_TripDetails ttd ON bfs.TripID = ttd.ID INNER JOIN Route_Master rm ON ttd.RouteID = rm.ID WHERE bfs.IsDeleted = 0 AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY ttd.TransportSessionName, rm.Name ORDER BY ttd.TransportSessionName, rm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3801, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3802 | new students added to transport this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'new students added to transport this year',
        @sql NVARCHAR(MAX) = N'SELECT stm.AdmissionNo, stm.FirstName, stm.LastName, rm.Name AS RouteName, bp.Name AS BoardingPoint FROM BusFeeStrucure bfs INNER JOIN Student_Master stm ON bfs.Student_ID = stm.ID INNER JOIN Route_Master rm ON bfs.Route_ID = rm.ID INNER JOIN BoardingPoint_Master bp ON bfs.BoardingPoint_ID = bp.Id WHERE bfs.IsDeleted = 0 AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY stm.FirstName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3802, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3803 | total transport fee applicable this academic year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'total transport fee applicable this academic year',
        @sql NVARCHAR(MAX) = N'SELECT SUM(bfs.Amount) AS TotalApplicableFee FROM BusFeeStrucure bfs WHERE bfs.IsDeleted = 0 AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3803, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3804 | How many hostels do we have? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many hostels do we have?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalHostels FROM Hostel_Master WHERE IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3804, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3805 | List all hostels ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all hostels',
        @sql NVARCHAR(MAX) = N'SELECT hm.Code, hm.Name, hm.Description FROM Hostel_Master hm WHERE hm.IsDeleted = 0 AND hm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY hm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3805, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3806 | How many rooms are there in each hostel? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many rooms are there in each hostel?',
        @sql NVARCHAR(MAX) = N'SELECT hm.Name AS HostelName, COUNT(hmd.Id) AS TotalRooms, SUM(hmd.MaximumNoStudent) AS TotalCapacity FROM Hostel_MasterDetails hmd INNER JOIN Hostel_Master hm ON hmd.HostelMaster_ID = hm.Id WHERE hm.IsDeleted = 0 AND hm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY hm.Name ORDER BY hm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3806, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3807 | show room details with capacity and amenities ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'show room details with capacity and amenities',
        @sql NVARCHAR(MAX) = N'SELECT hm.Name AS HostelName, hmd.RoomNo, hmd.MaximumNoStudent AS Capacity, hmd.Amount AS RoomFee, hmd.Dimension, hmd.Amenities FROM Hostel_MasterDetails hmd INNER JOIN Hostel_Master hm ON hmd.HostelMaster_ID = hm.Id WHERE hm.IsDeleted = 0 AND hm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY hm.Name, hmd.RoomNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3807, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3808 | which rooms have the highest capacity? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'which rooms have the highest capacity?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 hm.Name AS HostelName, hmd.RoomNo, hmd.MaximumNoStudent AS Capacity, hmd.Amount AS Fee FROM Hostel_MasterDetails hmd INNER JOIN Hostel_Master hm ON hmd.HostelMaster_ID = hm.Id WHERE hm.IsDeleted = 0 AND hm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY hmd.MaximumNoStudent DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3808, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3809 | hostel room fees ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'hostel room fees',
        @sql NVARCHAR(MAX) = N'SELECT hm.Name AS HostelName, hmd.RoomNo, hmd.Amount AS RoomFee, hmd.MaximumNoStudent AS Capacity FROM Hostel_MasterDetails hmd INNER JOIN Hostel_Master hm ON hmd.HostelMaster_ID = hm.Id WHERE hm.IsDeleted = 0 AND hm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY hmd.Amount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3809, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3810 | hostel wise student count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'hostel wise student count',
        @sql NVARCHAR(MAX) = N'SELECT hm.Name AS HostelName, COUNT(DISTINCT hfs.Student_ID) AS StudentCount FROM HostelFeeStructure hfs INNER JOIN Hostel_Master hm ON hfs.Hostel_ID = hm.Id WHERE hfs.IsDeleted = 0 AND hfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY hm.Name ORDER BY StudentCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3810, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3811 | class wise hostel students ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'class wise hostel students',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(DISTINCT hfs.Student_ID) AS HostelStudents FROM HostelFeeStructure hfs INNER JOIN ClassMaster cm ON hfs.Class_ID = cm.ID WHERE hfs.IsDeleted = 0 AND hfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY cm.Name ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3811, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3812 | list students in hostel with their room numbers ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'list students in hostel with their room numbers',
        @sql NVARCHAR(MAX) = N'SELECT stm.AdmissionNo, stm.FirstName, stm.LastName, hm.Name AS HostelName, hmd.RoomNo FROM HostelFeeStructure hfs INNER JOIN Student_Master stm ON hfs.Student_ID = stm.ID INNER JOIN Hostel_Master hm ON hfs.Hostel_ID = hm.Id INNER JOIN Hostel_MasterDetails hmd ON hfs.Room_ID = hmd.Id WHERE hfs.IsDeleted = 0 AND hfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY hm.Name, hmd.RoomNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3812, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3813 | total hostel fee expected this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'total hostel fee expected this year',
        @sql NVARCHAR(MAX) = N'SELECT SUM(hfs.Amount) AS TotalHostelFee, COUNT(DISTINCT hfs.Student_ID) AS StudentCount FROM HostelFeeStructure hfs WHERE hfs.IsDeleted = 0 AND hfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3813, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3814 | term wise hostel fee breakup ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'term wise hostel fee breakup',
        @sql NVARCHAR(MAX) = N'SELECT tm.Name AS TermName, SUM(hfs.Amount) AS TermFee, COUNT(DISTINCT hfs.Student_ID) AS StudentCount FROM HostelFeeStructure hfs INNER JOIN TermMaster tm ON hfs.Term_ID = tm.ID WHERE hfs.IsDeleted = 0 AND hfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY tm.Name ORDER BY tm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3814, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3815 | hostel fee for class 9 students ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'hostel fee for class 9 students',
        @sql NVARCHAR(MAX) = N'SELECT stm.AdmissionNo, stm.FirstName, stm.LastName, hm.Name AS HostelName, hmd.RoomNo, SUM(hfs.Amount) AS TotalFee FROM HostelFeeStructure hfs INNER JOIN Student_Master stm ON hfs.Student_ID = stm.ID INNER JOIN Hostel_Master hm ON hfs.Hostel_ID = hm.Id INNER JOIN Hostel_MasterDetails hmd ON hfs.Room_ID = hmd.Id INNER JOIN ClassMaster cm ON hfs.Class_ID = cm.ID WHERE hfs.IsDeleted = 0 AND cm.Name IN (''Class 9'', ''IX'') AND hfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY stm.AdmissionNo, stm.FirstName, stm.LastName, hm.Name, hmd.RoomNo ORDER BY stm.FirstName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3815, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3816 | hostel occupancy rate ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'hostel occupancy rate',
        @sql NVARCHAR(MAX) = N'SELECT hm.Name AS HostelName, SUM(hmd.MaximumNoStudent) AS TotalCapacity, COUNT(DISTINCT hfs.Student_ID) AS OccupiedBeds, CAST(COUNT(DISTINCT hfs.Student_ID) * 100.0 / NULLIF(SUM(hmd.MaximumNoStudent), 0) AS DECIMAL(5,2)) AS OccupancyPercent FROM Hostel_Master hm INNER JOIN Hostel_MasterDetails hmd ON hm.Id = hmd.HostelMaster_ID LEFT JOIN HostelFeeStructure hfs ON hfs.Hostel_ID = hm.Id AND hfs.Room_ID = hmd.Id AND hfs.IsDeleted = 0 AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) WHERE hm.IsDeleted = 0 AND hm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY hm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3816, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3817 | rooms with available beds ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'rooms with available beds',
        @sql NVARCHAR(MAX) = N'SELECT hm.Name AS HostelName, hmd.RoomNo, hmd.MaximumNoStudent AS Capacity, COUNT(hfs.Student_ID) AS Occupied, hmd.MaximumNoStudent - COUNT(hfs.Student_ID) AS Available FROM Hostel_MasterDetails hmd INNER JOIN Hostel_Master hm ON hmd.HostelMaster_ID = hm.Id LEFT JOIN HostelFeeStructure hfs ON hfs.Room_ID = hmd.Id AND hfs.IsDeleted = 0 AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) WHERE hm.IsDeleted = 0 AND hm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY hm.Name, hmd.RoomNo, hmd.MaximumNoStudent HAVING hmd.MaximumNoStudent - COUNT(hfs.Student_ID) > 0 ORDER BY Available DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3817, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3818 | which hostel has the most vacant beds? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'which hostel has the most vacant beds?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 hm.Name AS HostelName, SUM(hmd.MaximumNoStudent) AS TotalCapacity, COUNT(DISTINCT hfs.Student_ID) AS Occupied, SUM(hmd.MaximumNoStudent) - COUNT(DISTINCT hfs.Student_ID) AS Vacant FROM Hostel_Master hm INNER JOIN Hostel_MasterDetails hmd ON hm.Id = hmd.HostelMaster_ID LEFT JOIN HostelFeeStructure hfs ON hfs.Hostel_ID = hm.Id AND hfs.Room_ID = hmd.Id AND hfs.IsDeleted = 0 AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) WHERE hm.IsDeleted = 0 AND hm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY hm.Name ORDER BY Vacant DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3818, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3819 | hostel mein kitne bacche hain? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'hostel mein kitne bacche hain?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT hfs.Student_ID) AS HostelStudents FROM HostelFeeStructure hfs WHERE hfs.IsDeleted = 0 AND hfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3819, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3820 | any rooms fully occupied? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'any rooms fully occupied?',
        @sql NVARCHAR(MAX) = N'SELECT hm.Name AS HostelName, hmd.RoomNo, hmd.MaximumNoStudent AS Capacity, COUNT(hfs.Student_ID) AS Occupied FROM Hostel_MasterDetails hmd INNER JOIN Hostel_Master hm ON hmd.HostelMaster_ID = hm.Id LEFT JOIN HostelFeeStructure hfs ON hfs.Room_ID = hmd.Id AND hfs.IsDeleted = 0 AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) WHERE hm.IsDeleted = 0 AND hm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY hm.Name, hmd.RoomNo, hmd.MaximumNoStudent HAVING COUNT(hfs.Student_ID) >= hmd.MaximumNoStudent ORDER BY hm.Name, hmd.RoomNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3820, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3821 | total hostel revenue by month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'total hostel revenue by month',
        @sql NVARCHAR(MAX) = N'SELECT hfs.Month_Name, SUM(hfs.Amount) AS MonthlyFee, COUNT(DISTINCT hfs.Student_ID) AS StudentCount FROM HostelFeeStructure hfs WHERE hfs.IsDeleted = 0 AND hfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY hfs.Month_Name, hfs.Month_No ORDER BY hfs.Month_No;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3821, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3822 | most expensive hostel room ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'most expensive hostel room',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 hm.Name AS HostelName, hmd.RoomNo, hmd.Amount AS RoomFee, hmd.MaximumNoStudent AS Capacity, hmd.Amenities FROM Hostel_MasterDetails hmd INNER JOIN Hostel_Master hm ON hmd.HostelMaster_ID = hm.Id WHERE hm.IsDeleted = 0 AND hm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY hmd.Amount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3822, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3823 | average hostel fee per student ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'average hostel fee per student',
        @sql NVARCHAR(MAX) = N'SELECT AVG(StudentTotal) AS AvgFeePerStudent FROM (SELECT hfs.Student_ID, SUM(hfs.Amount) AS StudentTotal FROM HostelFeeStructure hfs WHERE hfs.IsDeleted = 0 AND hfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY hfs.Student_ID) t;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3823, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3824 | which student is in which hostel room? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'which student is in which hostel room?',
        @sql NVARCHAR(MAX) = N'SELECT stm.AdmissionNo, stm.FirstName, stm.LastName, hm.Name AS HostelName, hmd.RoomNo, hmd.Amenities FROM HostelFeeStructure hfs INNER JOIN Student_Master stm ON hfs.Student_ID = stm.ID INNER JOIN Hostel_Master hm ON hfs.Hostel_ID = hm.Id INNER JOIN Hostel_MasterDetails hmd ON hfs.Room_ID = hmd.Id WHERE hfs.IsDeleted = 0 AND hfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY hm.Name, hmd.RoomNo, stm.FirstName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3824, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3825 | hostel fee pending by student ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'hostel fee pending by student',
        @sql NVARCHAR(MAX) = N'SELECT stm.AdmissionNo, stm.FirstName, stm.LastName, SUM(hfs.Amount) AS TotalHostelFee FROM HostelFeeStructure hfs INNER JOIN Student_Master stm ON hfs.Student_ID = stm.ID WHERE hfs.IsDeleted = 0 AND hfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY stm.AdmissionNo, stm.FirstName, stm.LastName ORDER BY TotalHostelFee DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3825, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3826 | percentage of students in hostel ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'percentage of students in hostel',
        @sql NVARCHAR(MAX) = N'SELECT (SELECT COUNT(DISTINCT hfs.Student_ID) FROM HostelFeeStructure hfs WHERE hfs.IsDeleted = 0 AND hfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)))) AS HostelStudents, (SELECT COUNT(DISTINCT sad.StudentID) FROM StudentAcademicDetail sad WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1) AS TotalStudents;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3826, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3827 | room wise student count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'room wise student count',
        @sql NVARCHAR(MAX) = N'SELECT hm.Name AS HostelName, hmd.RoomNo, hmd.MaximumNoStudent AS Capacity, COUNT(hfs.Student_ID) AS CurrentOccupancy FROM Hostel_MasterDetails hmd INNER JOIN Hostel_Master hm ON hmd.HostelMaster_ID = hm.Id LEFT JOIN HostelFeeStructure hfs ON hfs.Room_ID = hmd.Id AND hfs.IsDeleted = 0 AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) WHERE hm.IsDeleted = 0 AND hm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY hm.Name, hmd.RoomNo, hmd.MaximumNoStudent ORDER BY hm.Name, hmd.RoomNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3827, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3828 | total hostel capacity vs occupied ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'total hostel capacity vs occupied',
        @sql NVARCHAR(MAX) = N'SELECT SUM(hmd.MaximumNoStudent) AS TotalCapacity, (SELECT COUNT(DISTINCT hfs.Student_ID) FROM HostelFeeStructure hfs WHERE hfs.IsDeleted = 0 AND hfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)))) AS Occupied FROM Hostel_MasterDetails hmd INNER JOIN Hostel_Master hm ON hmd.HostelMaster_ID = hm.Id WHERE hm.IsDeleted = 0 AND hm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3828, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3829 | hostel students from class 6 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'hostel students from class 6',
        @sql NVARCHAR(MAX) = N'SELECT stm.AdmissionNo, stm.FirstName, stm.LastName, hm.Name AS HostelName, hmd.RoomNo FROM HostelFeeStructure hfs INNER JOIN Student_Master stm ON hfs.Student_ID = stm.ID INNER JOIN Hostel_Master hm ON hfs.Hostel_ID = hm.Id INNER JOIN Hostel_MasterDetails hmd ON hfs.Room_ID = hmd.Id INNER JOIN ClassMaster cm ON hfs.Class_ID = cm.ID WHERE hfs.IsDeleted = 0 AND cm.Name IN (''Class 6'', ''VI'') AND hfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY stm.FirstName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3829, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3830 | hostel monthly fee schedule ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'hostel monthly fee schedule',
        @sql NVARCHAR(MAX) = N'SELECT hfs.Month_Name, hfs.Month_No, SUM(hfs.Amount) AS TotalFee, COUNT(DISTINCT hfs.Student_ID) AS StudentCount FROM HostelFeeStructure hfs WHERE hfs.IsDeleted = 0 AND hfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY hfs.Month_Name, hfs.Month_No ORDER BY hfs.Month_No;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3830, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3831 | rooms with specific amenities like AC ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'rooms with specific amenities like AC',
        @sql NVARCHAR(MAX) = N'SELECT hm.Name AS HostelName, hmd.RoomNo, hmd.Amenities, hmd.Amount AS Fee, hmd.MaximumNoStudent AS Capacity FROM Hostel_MasterDetails hmd INNER JOIN Hostel_Master hm ON hmd.HostelMaster_ID = hm.Id WHERE hm.IsDeleted = 0 AND hmd.Amenities LIKE ''%AC%'' AND hm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3831, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3832 | cheapest hostel room available ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'cheapest hostel room available',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 hm.Name AS HostelName, hmd.RoomNo, hmd.Amount AS Fee, hmd.MaximumNoStudent AS Capacity, hmd.Amenities FROM Hostel_MasterDetails hmd INNER JOIN Hostel_Master hm ON hmd.HostelMaster_ID = hm.Id WHERE hm.IsDeleted = 0 AND hm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY hmd.Amount ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3832, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3833 | hostel fee structure by room type ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'hostel fee structure by room type',
        @sql NVARCHAR(MAX) = N'SELECT hm.Name AS HostelName, hmd.RoomNo, hmd.Dimension, hmd.Amount AS Fee, hmd.MaximumNoStudent AS Capacity, hmd.Amenities FROM Hostel_MasterDetails hmd INNER JOIN Hostel_Master hm ON hmd.HostelMaster_ID = hm.Id WHERE hm.IsDeleted = 0 AND hm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY hmd.Amount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3833, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3834 | students in hostel from class 10 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'students in hostel from class 10',
        @sql NVARCHAR(MAX) = N'SELECT stm.AdmissionNo, stm.FirstName, stm.LastName, hm.Name AS HostelName, hmd.RoomNo FROM HostelFeeStructure hfs INNER JOIN Student_Master stm ON hfs.Student_ID = stm.ID INNER JOIN Hostel_Master hm ON hfs.Hostel_ID = hm.Id INNER JOIN Hostel_MasterDetails hmd ON hfs.Room_ID = hmd.Id INNER JOIN ClassMaster cm ON hfs.Class_ID = cm.ID WHERE hfs.IsDeleted = 0 AND cm.Name IN (''Class 10'', ''X'') AND hfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY stm.FirstName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3834, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3835 | hostel fee per term per student ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'hostel fee per term per student',
        @sql NVARCHAR(MAX) = N'SELECT stm.AdmissionNo, stm.FirstName, stm.LastName, tm.Name AS TermName, SUM(hfs.Amount) AS TermFee FROM HostelFeeStructure hfs INNER JOIN Student_Master stm ON hfs.Student_ID = stm.ID INNER JOIN TermMaster tm ON hfs.Term_ID = tm.ID WHERE hfs.IsDeleted = 0 AND hfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY stm.AdmissionNo, stm.FirstName, stm.LastName, tm.Name ORDER BY stm.FirstName, tm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3835, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3836 | number of empty beds across all hostels ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'number of empty beds across all hostels',
        @sql NVARCHAR(MAX) = N'SELECT SUM(hmd.MaximumNoStudent) - COUNT(DISTINCT hfs.Student_ID) AS EmptyBeds FROM Hostel_MasterDetails hmd INNER JOIN Hostel_Master hm ON hmd.HostelMaster_ID = hm.Id LEFT JOIN HostelFeeStructure hfs ON hfs.Room_ID = hmd.Id AND hfs.IsDeleted = 0 AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) WHERE hm.IsDeleted = 0 AND hm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3836, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3837 | hostel students with their class details ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'hostel students with their class details',
        @sql NVARCHAR(MAX) = N'SELECT stm.AdmissionNo, stm.FirstName, stm.LastName, cm.Name AS ClassName, hm.Name AS HostelName FROM HostelFeeStructure hfs INNER JOIN Student_Master stm ON hfs.Student_ID = stm.ID INNER JOIN ClassMaster cm ON hfs.Class_ID = cm.ID INNER JOIN Hostel_Master hm ON hfs.Hostel_ID = hm.Id WHERE hfs.IsDeleted = 0 AND hfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY cm.Name, stm.FirstName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3837, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3838 | What are the fee terms for this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What are the fee terms for this year?',
        @sql NVARCHAR(MAX) = N'SELECT tm.ID, tm.Name, tm.StartingDate, tm.EndingDate, tm.TotalNoMonths FROM TermMaster tm WHERE tm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND tm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (tm.IsDeleted = 0 OR tm.IsDeleted IS NULL) ORDER BY tm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3838, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3839 | which fee term is currently active? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'which fee term is currently active?',
        @sql NVARCHAR(MAX) = N'SELECT tm.Name, tm.StartingDate, tm.EndingDate FROM TermMaster tm WHERE GETDATE() BETWEEN tm.StartingDate AND tm.EndingDate AND tm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND tm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (tm.IsDeleted = 0 OR tm.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3839, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3840 | how many fee terms do we have? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'how many fee terms do we have?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalTerms FROM TermMaster tm WHERE tm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND tm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (tm.IsDeleted = 0 OR tm.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3840, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3841 | What is the total fee collection target vs actual collected amount for the current term? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total fee collection target vs actual collected amount for the current term?',
        @sql NVARCHAR(MAX) = N'SELECT tm.Name AS TermName, ISNULL((SELECT SUM(f.Amount - ISNULL(f.Concession_Amt, 0)) FROM FeesInformationStudentDetail f WHERE f.Term_ID = tm.ID AND f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))), 0) AS TargetAmount, ISNULL((SELECT SUM(fcd.Paid_Amt) FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fcd.Term_ID = tm.ID AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))), 0) AS CollectedAmount FROM TermMaster tm WHERE GETDATE() BETWEEN tm.StartingDate AND tm.EndingDate AND tm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND tm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (tm.IsDeleted = 0 OR tm.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3841, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3842 | term wise fee collection status ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'term wise fee collection status',
        @sql NVARCHAR(MAX) = N'SELECT tm.Name AS TermName, ISNULL((SELECT SUM(f.Amount - ISNULL(f.Concession_Amt, 0)) FROM FeesInformationStudentDetail f WHERE f.Term_ID = tm.ID AND f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))), 0) AS ExpectedAmount, ISNULL((SELECT SUM(fcd.Paid_Amt) FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fcd.Term_ID = tm.ID AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))), 0) AS CollectedAmount FROM TermMaster tm WHERE tm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND tm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (tm.IsDeleted = 0 OR tm.IsDeleted IS NULL) ORDER BY tm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3842, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3843 | fee outstanding by term ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'fee outstanding by term',
        @sql NVARCHAR(MAX) = N'SELECT f.Term_ID, f.Term_Name, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY f.Term_ID, f.Term_Name ORDER BY f.Term_ID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3843, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3844 | when does the next fee term start? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'when does the next fee term start?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 tm.Name, tm.StartingDate, tm.EndingDate FROM TermMaster tm WHERE tm.StartingDate > GETDATE() AND tm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND tm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (tm.IsDeleted = 0 OR tm.IsDeleted IS NULL) ORDER BY tm.StartingDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3844, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3845 | term 1 vs term 2 collection comparison ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'term 1 vs term 2 collection comparison',
        @sql NVARCHAR(MAX) = N'SELECT fcd.Term_ID, SUM(fcd.Paid_Amt) AS TotalCollected FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fcd.Term_ID ORDER BY fcd.Term_ID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3845, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3846 | how much fee is pending for term 1? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'how much fee is pending for term 1?',
        @sql NVARCHAR(MAX) = N'SELECT f.Term_Name, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Pending FROM FeesInformationStudentDetail f INNER JOIN TermMaster tm ON f.Term_ID = tm.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND tm.Name LIKE ''%Term 1%'' AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY f.Term_Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3846, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3847 | transport fee by term ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'transport fee by term',
        @sql NVARCHAR(MAX) = N'SELECT tm.Name AS TermName, SUM(bfs.Amount) AS TransportFee, COUNT(DISTINCT bfs.Student_ID) AS StudentCount FROM BusFeeStrucure bfs INNER JOIN TermMaster tm ON bfs.Term_ID = tm.ID WHERE bfs.IsDeleted = 0 AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY tm.Name ORDER BY tm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3847, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3848 | hostel fee by term ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'hostel fee by term',
        @sql NVARCHAR(MAX) = N'SELECT tm.Name AS TermName, SUM(hfs.Amount) AS HostelFee, COUNT(DISTINCT hfs.Student_ID) AS StudentCount FROM HostelFeeStructure hfs INNER JOIN TermMaster tm ON hfs.Term_ID = tm.ID WHERE hfs.IsDeleted = 0 AND hfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY tm.Name ORDER BY tm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3848, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3849 | current term fee collection percentage ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'current term fee collection percentage',
        @sql NVARCHAR(MAX) = N'SELECT tm.Name AS TermName, ISNULL((SELECT SUM(f.Amount - ISNULL(f.Concession_Amt, 0)) FROM FeesInformationStudentDetail f WHERE f.Term_ID = tm.ID AND f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))), 0) AS Demand, ISNULL((SELECT SUM(fcd.Paid_Amt) FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fcd.Term_ID = tm.ID AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))), 0) AS Collected, CAST(ISNULL((SELECT SUM(fcd.Paid_Amt) FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fcd.Term_ID = tm.ID AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))), 0) * 100.0 / NULLIF((SELECT SUM(f.Amount - ISNULL(f.Concession_Amt, 0)) FROM FeesInformationStudentDetail f WHERE f.Term_ID = tm.ID AND f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))), 0) AS DECIMAL(5,2)) AS CollectionPercent FROM TermMaster tm WHERE GETDATE() BETWEEN tm.StartingDate AND tm.EndingDate AND tm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND tm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (tm.IsDeleted = 0 OR tm.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3849, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3850 | What are the academic months for this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What are the academic months for this year?',
        @sql NVARCHAR(MAX) = N'SELECT mm.Month_Name, mm.Actual_Month_No, mm.StartDate, mm.EndDate FROM Month_Master mm WHERE mm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND mm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY mm.Month_No;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3850, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3851 | which academic month is running now? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'which academic month is running now?',
        @sql NVARCHAR(MAX) = N'SELECT mm.Month_Name, mm.StartDate, mm.EndDate FROM Month_Master mm WHERE GETDATE() BETWEEN mm.StartDate AND mm.EndDate AND mm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND mm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3851, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3852 | how many academic months are there? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'how many academic months are there?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalMonths FROM Month_Master mm WHERE mm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND mm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3852, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3853 | when does the academic year start and end? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'when does the academic year start and end?',
        @sql NVARCHAR(MAX) = N'SELECT MIN(mm.StartDate) AS YearStart, MAX(mm.EndDate) AS YearEnd FROM Month_Master mm WHERE mm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND mm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3853, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3854 | How many seats are available in each class? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many seats are available in each class?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, secm.Name AS SectionName, csm.TotalSeats, csm.AvailableSeats, csm.Block, csm.Floor FROM ClassSectionMaster csm INNER JOIN ClassMaster cm ON csm.Class_Id = cm.ID INNER JOIN SectionMaster secm ON csm.Section_Id = secm.ID WHERE csm.IsDeleted = 0 AND csm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND csm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY cm.Name, secm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3854, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3855 | total seat capacity of the school ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'total seat capacity of the school',
        @sql NVARCHAR(MAX) = N'SELECT SUM(csm.TotalSeats) AS TotalCapacity, SUM(csm.AvailableSeats) AS AvailableSeats FROM ClassSectionMaster csm WHERE csm.IsDeleted = 0 AND csm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND csm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3855, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3856 | which class has the least available seats? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'which class has the least available seats?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 cm.Name AS ClassName, SUM(csm.TotalSeats) AS TotalSeats, SUM(csm.AvailableSeats) AS AvailableSeats FROM ClassSectionMaster csm INNER JOIN ClassMaster cm ON csm.Class_Id = cm.ID WHERE csm.IsDeleted = 0 AND csm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND csm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY cm.Name ORDER BY SUM(csm.AvailableSeats) ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3856, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3857 | classroom capacity by block and floor ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'classroom capacity by block and floor',
        @sql NVARCHAR(MAX) = N'SELECT csm.Block, csm.Floor, cm.Name AS ClassName, secm.Name AS SectionName, csm.TotalSeats, csm.AvailableSeats FROM ClassSectionMaster csm INNER JOIN ClassMaster cm ON csm.Class_Id = cm.ID INNER JOIN SectionMaster secm ON csm.Section_Id = secm.ID WHERE csm.IsDeleted = 0 AND csm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND csm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY csm.Block, csm.Floor, cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3857, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3858 | sections full to capacity ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'sections full to capacity',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, secm.Name AS SectionName, csm.TotalSeats, csm.AvailableSeats FROM ClassSectionMaster csm INNER JOIN ClassMaster cm ON csm.Class_Id = cm.ID INNER JOIN SectionMaster secm ON csm.Section_Id = secm.ID WHERE csm.IsDeleted = 0 AND csm.AvailableSeats = 0 AND csm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND csm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3858, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3859 | how many total seats in class 5? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'how many total seats in class 5?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, SUM(csm.TotalSeats) AS TotalSeats, SUM(csm.AvailableSeats) AS AvailableSeats FROM ClassSectionMaster csm INNER JOIN ClassMaster cm ON csm.Class_Id = cm.ID WHERE csm.IsDeleted = 0 AND cm.Name IN (''Class 5'', ''V'') AND csm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND csm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3859, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3860 | is there room for more students in class 3? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'is there room for more students in class 3?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, secm.Name AS SectionName, csm.AvailableSeats FROM ClassSectionMaster csm INNER JOIN ClassMaster cm ON csm.Class_Id = cm.ID INNER JOIN SectionMaster secm ON csm.Section_Id = secm.ID WHERE csm.IsDeleted = 0 AND cm.Name IN (''Class 3'', ''III'') AND csm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND csm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY secm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3860, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3861 | school ki total capacity kitni hai? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'school ki total capacity kitni hai?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(csm.TotalSeats) AS TotalCapacity, SUM(csm.AvailableSeats) AS AvailableSeats, SUM(csm.TotalSeats) - SUM(csm.AvailableSeats) AS Occupied FROM ClassSectionMaster csm WHERE csm.IsDeleted = 0 AND csm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND csm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3861, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3862 | How many students are there in class 10 section A? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students are there in class 10 section A?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID INNER JOIN SectionMaster secm ON sad.SectionID = secm.ID WHERE cm.Name = ''Class 10'' AND secm.Name = ''A'' AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3862, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3863 | What is the strength of class 8 section B? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the strength of class 8 section B?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID INNER JOIN SectionMaster secm ON sad.SectionID = secm.ID WHERE cm.Name = ''Class 8'' AND secm.Name = ''B'' AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3863, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3864 | Count students in 9 C for this academic year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Count students in 9 C for this academic year',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID INNER JOIN SectionMaster secm ON sad.SectionID = secm.ID WHERE cm.Name = ''Class 9'' AND secm.Name = ''C'' AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3864, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3865 | how many students in 10 a ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'how many students in 10 a',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID INNER JOIN SectionMaster secm ON sad.SectionID = secm.ID WHERE cm.Name = ''Class 10'' AND secm.Name = ''A'' AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3865, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3866 | Show me the student count for class 6 section A ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me the student count for class 6 section A',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID INNER JOIN SectionMaster secm ON sad.SectionID = secm.ID WHERE cm.Name = ''Class 6'' AND secm.Name = ''A'' AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3866, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3867 | How many students are in class 12 section D? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students are in class 12 section D?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID INNER JOIN SectionMaster secm ON sad.SectionID = secm.ID WHERE cm.Name = ''Class 12'' AND secm.Name = ''D'' AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3867, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3868 | Give me the total students in class 5 section C ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the total students in class 5 section C',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID INNER JOIN SectionMaster secm ON sad.SectionID = secm.ID WHERE cm.Name = ''Class 5'' AND secm.Name = ''C'' AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3868, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3869 | What is the student strength of 11 A? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the student strength of 11 A?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID INNER JOIN SectionMaster secm ON sad.SectionID = secm.ID WHERE cm.Name = ''Class 11'' AND secm.Name = ''A'' AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3869, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3870 | Number of students in class 10 B this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Number of students in class 10 B this year',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID INNER JOIN SectionMaster secm ON sad.SectionID = secm.ID WHERE cm.Name = ''Class 10'' AND secm.Name = ''B'' AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3870, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3871 | how many kids are in 8 C ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'how many kids are in 8 C',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID INNER JOIN SectionMaster secm ON sad.SectionID = secm.ID WHERE cm.Name = ''Class 8'' AND secm.Name = ''C'' AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3871, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3872 | What is the total fee outstanding for class 10? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total fee outstanding for class 10?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(ISNULL(f.Amount,0) - ISNULL(f.Concession_Amt,0) - ISNULL(f.Paid_Amt,0) - ISNULL(f.Lien_Amount,0)), 0) AS OutstandingAmount FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sad ON f.Student_ID = sad.StudentID INNER JOIN ClassMaster cm ON f.ClassID = cm.ID WHERE f.IsIncludedInLumpSum = 0 AND f.IsDonation = 0 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND cm.Name = ''Class 10'' AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3872, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3873 | Class wise outstanding fees report ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class wise outstanding fees report',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, ISNULL(SUM(ISNULL(f.Amount,0) - ISNULL(f.Concession_Amt,0) - ISNULL(f.Paid_Amt,0) - ISNULL(f.Lien_Amount,0)), 0) AS OutstandingAmount FROM FeesInformationStudentDetail f INNER JOIN ClassMaster cm ON f.ClassID = cm.ID WHERE f.IsIncludedInLumpSum = 0 AND f.IsDonation = 0 AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name ORDER BY OutstandingAmount DESC',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3873, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3874 | How much fee is pending for class 8 section B? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much fee is pending for class 8 section B?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(ISNULL(f.Amount,0) - ISNULL(f.Concession_Amt,0) - ISNULL(f.Paid_Amt,0) - ISNULL(f.Lien_Amount,0)), 0) AS PendingAmount FROM FeesInformationStudentDetail f INNER JOIN SectionMaster secm ON f.SectionID = secm.ID WHERE f.IsIncludedInLumpSum = 0 AND f.IsDonation = 0 AND f.ClassName = ''Class 8'' AND secm.Name = ''B'' AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3874, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3875 | Top 10 fee defaulters this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Top 10 fee defaulters this year',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 sm.FirstName + '' '' + sm.LastName AS StudentName, ISNULL(SUM(ISNULL(f.Amount,0) - ISNULL(f.Concession_Amt,0) - ISNULL(f.Paid_Amt,0) - ISNULL(f.Lien_Amount,0)), 0) AS OutstandingAmount FROM FeesInformationStudentDetail f INNER JOIN Student_Master sm ON sm.ID = f.Student_ID WHERE f.IsIncludedInLumpSum = 0 AND f.IsDonation = 0 AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.FirstName, sm.LastName ORDER BY OutstandingAmount DESC',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3875, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3876 | How many students have outstanding fees above 5000? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students have outstanding fees above 5000?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT CASE WHEN (ISNULL(f.Amount,0) - ISNULL(f.Concession_Amt,0) - ISNULL(f.Paid_Amt,0) - ISNULL(f.Lien_Amount,0)) > 5000 THEN f.Student_ID END) AS StudentsAbove5000 FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum = 0 AND f.IsDonation = 0 AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3876, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3877 | How many students have pending fees in class 9? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students have pending fees in class 9?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT f.Student_ID) AS StudentsWithDues FROM FeesInformationStudentDetail f INNER JOIN ClassMaster cm ON f.ClassID = cm.ID WHERE f.IsIncludedInLumpSum = 0 AND f.IsDonation = 0 AND cm.Name = ''Class 9'' AND (ISNULL(f.Amount,0) - ISNULL(f.Concession_Amt,0) - ISNULL(f.Paid_Amt,0) - ISNULL(f.Lien_Amount,0)) > 0 AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3877, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3878 | Outstanding amount per student in class 7 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Outstanding amount per student in class 7',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName + '' '' + sm.LastName AS StudentName, ISNULL(SUM(ISNULL(f.Amount,0) - ISNULL(f.Concession_Amt,0) - ISNULL(f.Paid_Amt,0) - ISNULL(f.Lien_Amount,0)), 0) AS OutstandingAmount FROM FeesInformationStudentDetail f INNER JOIN Student_Master sm ON sm.ID = f.Student_ID WHERE f.IsIncludedInLumpSum = 0 AND f.IsDonation = 0 AND f.ClassName = ''Class 7'' AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.FirstName, sm.LastName ORDER BY OutstandingAmount DESC',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3878, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3879 | What is the total outstanding amount across all classes? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total outstanding amount across all classes?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(ISNULL(f.Amount,0) - ISNULL(f.Concession_Amt,0) - ISNULL(f.Paid_Amt,0) - ISNULL(f.Lien_Amount,0)), 0) AS TotalOutstanding FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum = 0 AND f.IsDonation = 0 AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3879, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3880 | List class 10 students who owe fees ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List class 10 students who owe fees',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT f.Student_ID AS StudentID FROM FeesInformationStudentDetail f INNER JOIN ClassMaster cm ON f.ClassID = cm.ID WHERE f.IsIncludedInLumpSum = 0 AND f.IsDonation = 0 AND cm.Name = ''Class 10'' AND (ISNULL(f.Amount,0) - ISNULL(f.Concession_Amt,0) - ISNULL(f.Paid_Amt,0) - ISNULL(f.Lien_Amount,0)) > 0 AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3880, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3881 | Outstanding dues for the senior secondary classes ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Outstanding dues for the senior secondary classes',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, ISNULL(SUM(ISNULL(f.Amount,0) - ISNULL(f.Concession_Amt,0) - ISNULL(f.Paid_Amt,0) - ISNULL(f.Lien_Amount,0)), 0) AS OutstandingAmount FROM FeesInformationStudentDetail f INNER JOIN ClassMaster cm ON f.ClassID = cm.ID WHERE f.IsIncludedInLumpSum = 0 AND f.IsDonation = 0 AND cm.Name IN (''Class 11'', ''Class 12'') AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3881, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3882 | What is the total fee outstanding for the current term? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total fee outstanding for the current term?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(ISNULL(f.Amount,0) - ISNULL(f.Concession_Amt,0) - ISNULL(f.Paid_Amt,0) - ISNULL(f.Lien_Amount,0)), 0) AS CurrentTermOutstanding FROM FeesInformationStudentDetail f INNER JOIN TermMaster tm ON tm.ID = f.Term_ID AND GETDATE() BETWEEN tm.StartingDate AND tm.EndingDate WHERE f.IsIncludedInLumpSum = 0 AND f.IsDonation = 0 AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3882, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3883 | How much fee was collected in the current term? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much fee was collected in the current term?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fcd.Paid_Amt), 0) AS CurrentTermCollection FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN TermMaster tm ON tm.ID = fcd.Term_ID AND GETDATE() BETWEEN tm.StartingDate AND tm.EndingDate WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3883, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3884 | What is the fee amount billed for the current term? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the fee amount billed for the current term?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(f.Amount), 0) AS CurrentTermBilled FROM FeesInformationStudentDetail f INNER JOIN TermMaster tm ON tm.ID = f.Term_ID AND GETDATE() BETWEEN tm.StartingDate AND tm.EndingDate WHERE f.IsIncludedInLumpSum = 0 AND f.IsDonation = 0 AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3884, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3885 | How many students have not paid the current term fees? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students have not paid the current term fees?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT CASE WHEN (ISNULL(f.Amount,0) - ISNULL(f.Concession_Amt,0) - ISNULL(f.Paid_Amt,0) - ISNULL(f.Lien_Amount,0)) > 0 THEN f.Student_ID END) AS UnpaidStudents FROM FeesInformationStudentDetail f INNER JOIN TermMaster tm ON tm.ID = f.Term_ID AND GETDATE() BETWEEN tm.StartingDate AND tm.EndingDate WHERE f.IsIncludedInLumpSum = 0 AND f.IsDonation = 0 AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3885, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3886 | What is the current term bus fee total? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the current term bus fee total?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(bfs.Amount), 0) AS CurrentTermBusFee FROM BusFeeStrucure bfs INNER JOIN TermMaster tm ON tm.ID = bfs.Term_ID AND GETDATE() BETWEEN tm.StartingDate AND tm.EndingDate WHERE (bfs.IsDeleted IS NULL OR bfs.IsDeleted = 0) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3886, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3887 | What is the current term hostel fee amount? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the current term hostel fee amount?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(hfs.Amount), 0) AS CurrentTermHostelFee FROM HostelFeeStructure hfs INNER JOIN TermMaster tm ON tm.ID = hfs.Term_ID AND GETDATE() BETWEEN tm.StartingDate AND tm.EndingDate WHERE (hfs.IsDeleted IS NULL OR hfs.IsDeleted = 0) AND hfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND hfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3887, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3888 | How much fee concession was given in the current term? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much fee concession was given in the current term?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(f.Concession_Amt), 0) AS CurrentTermConcession FROM FeesInformationStudentDetail f INNER JOIN TermMaster tm ON tm.ID = f.Term_ID AND GETDATE() BETWEEN tm.StartingDate AND tm.EndingDate WHERE f.IsIncludedInLumpSum = 0 AND f.IsDonation = 0 AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3888, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3889 | Current term fee outstanding by class ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Current term fee outstanding by class',
        @sql NVARCHAR(MAX) = N'SELECT f.ClassName, ISNULL(SUM(ISNULL(f.Amount,0) - ISNULL(f.Concession_Amt,0) - ISNULL(f.Paid_Amt,0) - ISNULL(f.Lien_Amount,0)), 0) AS OutstandingAmount FROM FeesInformationStudentDetail f INNER JOIN TermMaster tm ON tm.ID = f.Term_ID AND GETDATE() BETWEEN tm.StartingDate AND tm.EndingDate WHERE f.IsIncludedInLumpSum = 0 AND f.IsDonation = 0 AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY f.ClassName',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3889, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3890 | Show term wise fee collection for this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show term wise fee collection for this year',
        @sql NVARCHAR(MAX) = N'SELECT tm.Name AS TermName, ISNULL(SUM(fcd.Paid_Amt), 0) AS CollectedAmount FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN TermMaster tm ON tm.ID = fcd.Term_ID WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY tm.Name ORDER BY tm.Name',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3890, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3891 | How much fee was collected in term 1? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much fee was collected in term 1?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fcd.Paid_Amt), 0) AS Term1Collection FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN TermMaster tm ON tm.ID = fcd.Term_ID WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND tm.Name LIKE ''%Term 1%'' AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3891, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3892 | Fee collected per term for class 10 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Fee collected per term for class 10',
        @sql NVARCHAR(MAX) = N'SELECT tm.Name AS TermName, ISNULL(SUM(fcd.Paid_Amt), 0) AS CollectedAmount FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN TermMaster tm ON tm.ID = fcd.Term_ID INNER JOIN ClassMaster cm ON fc.Class_ID = cm.ID WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND cm.Name = ''Class 10'' AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY tm.Name',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3892, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3893 | What is the term 2 fee collection total? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the term 2 fee collection total?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fcd.Paid_Amt), 0) AS Term2Collection FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN TermMaster tm ON tm.ID = fcd.Term_ID WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND tm.Name LIKE ''%Term 2%'' AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3893, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3894 | Pending fees by term for this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pending fees by term for this year',
        @sql NVARCHAR(MAX) = N'SELECT tm.Name AS TermName, ISNULL(SUM(ISNULL(f.Amount,0) - ISNULL(f.Concession_Amt,0) - ISNULL(f.Paid_Amt,0) - ISNULL(f.Lien_Amount,0)), 0) AS PendingAmount FROM FeesInformationStudentDetail f INNER JOIN TermMaster tm ON tm.ID = f.Term_ID WHERE f.IsIncludedInLumpSum = 0 AND f.IsDonation = 0 AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY tm.Name ORDER BY PendingAmount DESC',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3894, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3895 | Receipt count by term this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Receipt count by term this year',
        @sql NVARCHAR(MAX) = N'SELECT tm.Name AS TermName, COUNT(*) AS ReceiptCount FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN TermMaster tm ON tm.ID = fcd.Term_ID WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY tm.Name',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3895, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3896 | Which term has the highest fee collection this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which term has the highest fee collection this year?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 tm.Name AS TermName, ISNULL(SUM(fcd.Paid_Amt), 0) AS CollectedAmount FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN TermMaster tm ON tm.ID = fcd.Term_ID WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY tm.Name ORDER BY CollectedAmount DESC',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3896, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3897 | Fee head wise collection for this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Fee head wise collection for this year',
        @sql NVARCHAR(MAX) = N'SELECT fm.Name AS FeeHead, ISNULL(SUM(fcd.Paid_Amt), 0) AS CollectedAmount FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN Fees_Master fm ON fcd.Fees_Head_ID = fm.ID WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fm.Name ORDER BY CollectedAmount DESC',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3897, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3898 | Fee head wise collection today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Fee head wise collection today',
        @sql NVARCHAR(MAX) = N'SELECT fm.Name AS FeeHead, ISNULL(SUM(fcd.Paid_Amt), 0) AS CollectedAmount FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN Fees_Master fm ON fcd.Fees_Head_ID = fm.ID WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fm.Name ORDER BY CollectedAmount DESC',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3898, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3899 | How much was collected under the tuition fee head? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much was collected under the tuition fee head?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fcd.Paid_Amt), 0) AS TuitionFeeCollection FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN Fees_Master fm ON fcd.Fees_Head_ID = fm.ID WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fm.Name LIKE ''%Tuition%'' AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3899, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3900 | Fee head wise outstanding amount ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Fee head wise outstanding amount',
        @sql NVARCHAR(MAX) = N'SELECT fm.Name AS FeeHead, ISNULL(SUM(ISNULL(f.Amount,0) - ISNULL(f.Concession_Amt,0) - ISNULL(f.Paid_Amt,0) - ISNULL(f.Lien_Amount,0)), 0) AS OutstandingAmount FROM FeesInformationStudentDetail f INNER JOIN Fees_Master fm ON f.Fees_ID = fm.ID WHERE f.IsIncludedInLumpSum = 0 AND f.IsDonation = 0 AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fm.Name',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
PRINT 'checkpoint: reached Q3900';
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3900, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3901 | Which fee head has the highest collection this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which fee head has the highest collection this year?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 fm.Name AS FeeHead, ISNULL(SUM(fcd.Paid_Amt), 0) AS CollectedAmount FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN Fees_Master fm ON fcd.Fees_Head_ID = fm.ID WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fm.Name ORDER BY CollectedAmount DESC',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3901, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3902 | Fee head wise collection for class 9 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Fee head wise collection for class 9',
        @sql NVARCHAR(MAX) = N'SELECT fm.Name AS FeeHead, ISNULL(SUM(fcd.Paid_Amt), 0) AS CollectedAmount FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN Fees_Master fm ON fcd.Fees_Head_ID = fm.ID INNER JOIN ClassMaster cm ON fc.Class_ID = cm.ID WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND cm.Name = ''Class 9'' AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fm.Name',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3902, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3903 | Transport fee head collection this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Transport fee head collection this year',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fcd.Paid_Amt), 0) AS TransportFeeCollection FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN Fees_Master fm ON fcd.Fees_Head_ID = fm.ID WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fm.Name LIKE ''%Transport%'' AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3903, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3904 | Fee head wise pending amount for the current term ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Fee head wise pending amount for the current term',
        @sql NVARCHAR(MAX) = N'SELECT fm.Name AS FeeHead, ISNULL(SUM(ISNULL(f.Amount,0) - ISNULL(f.Concession_Amt,0) - ISNULL(f.Paid_Amt,0) - ISNULL(f.Lien_Amount,0)), 0) AS PendingAmount FROM FeesInformationStudentDetail f INNER JOIN Fees_Master fm ON f.Fees_ID = fm.ID INNER JOIN TermMaster tm ON tm.ID = f.Term_ID AND GETDATE() BETWEEN tm.StartingDate AND tm.EndingDate WHERE f.IsIncludedInLumpSum = 0 AND f.IsDonation = 0 AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fm.Name',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3904, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3905 | Fees collected this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Fees collected this month',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS MonthCollection FROM FeesCollection fc WHERE fc.Bill_Date >= DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3905, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3906 | What was yesterday's fee collection total? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What was yesterday''s fee collection total?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS YesterdayCollection FROM FeesCollection fc WHERE CAST(fc.Bill_Date AS DATE) = CAST(DATEADD(DAY, -1, GETDATE()) AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3906, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3907 | Fee collection by payment mode today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Fee collection by payment mode today',
        @sql NVARCHAR(MAX) = N'SELECT cmm.Name AS PaymentMode, ISNULL(SUM(fc.Receipt_Amt), 0) AS CollectedAmount FROM FeesCollection fc INNER JOIN CollectionMode_Master cmm ON fc.Collection_Mode_ID = cmm.ID WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cmm.Name',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3907, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3908 | Payment mode wise collection for this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Payment mode wise collection for this month',
        @sql NVARCHAR(MAX) = N'SELECT cmm.Name AS PaymentMode, ISNULL(SUM(fc.Receipt_Amt), 0) AS CollectedAmount FROM FeesCollection fc INNER JOIN CollectionMode_Master cmm ON fc.Collection_Mode_ID = cmm.ID WHERE fc.Bill_Date >= DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cmm.Name',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3908, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3909 | How much cash was collected today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much cash was collected today?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS CashCollection FROM FeesCollection fc INNER JOIN CollectionMode_Master cmm ON fc.Collection_Mode_ID = cmm.ID WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND cmm.Name = ''Cash'' AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3909, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3910 | Online fee payments this week ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Online fee payments this week',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS OnlineCollection FROM FeesCollection fc INNER JOIN CollectionMode_Master cmm ON fc.Collection_Mode_ID = cmm.ID WHERE fc.Bill_Date >= DATEADD(DAY, 1 - DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE)) AND cmm.Name LIKE ''%Online%'' AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3910, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3911 | How many fee receipts were issued today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many fee receipts were issued today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS ReceiptsIssued FROM FeesCollection fc WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3911, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3912 | List all bounced cheques this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all bounced cheques this year',
        @sql NVARCHAR(MAX) = N'SELECT fc.Bill_No, fc.Bank, fc.Receipt_Amt, fc.Bill_Date, sm.FirstName + '' '' + sm.LastName AS StudentName FROM FeesCollection fc INNER JOIN Student_Master sm ON sm.ID = fc.Student_ID WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID = 3 AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY fc.Bill_Date DESC',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3912, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3913 | Total amount of bounced cheques this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total amount of bounced cheques this year',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS BouncedAmount FROM FeesCollection fc WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID = 3 AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3913, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3914 | Show cancelled fee receipts this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show cancelled fee receipts this month',
        @sql NVARCHAR(MAX) = N'SELECT fc.Bill_No, fc.Receipt_Amt, fc.Cancellation_Date, fc.Reason_For_Cancellation FROM FeesCollection fc WHERE fc.Cancellation_Date >= DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID = 4 AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3914, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3915 | Which cheques are pending clearance? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which cheques are pending clearance?',
        @sql NVARCHAR(MAX) = N'SELECT fc.Bill_No, fc.Bank, fc.Receipt_Amt, fc.ChequeClearanceDate FROM FeesCollection fc WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID IN (1, 2) AND fc.ChequeClearanceDate IS NULL AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3915, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3916 | Bounced cheque count this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Bounced cheque count this month',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS BouncedCheques FROM FeesCollection fc WHERE fc.Bill_Date >= DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID = 3 AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3916, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3917 | Who is the principal of our school? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who is the principal of our school?',
        @sql NVARCHAR(MAX) = N'SELECT bm.Principal AS PrincipalName FROM BranchMaster bm WHERE (bm.IsDeleted IS NULL OR bm.IsDeleted = 0) AND bm.ID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3917, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3918 | Show the principal for each branch ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the principal for each branch',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS BranchName, bm.Principal AS Principal FROM BranchMaster bm WHERE (bm.IsDeleted IS NULL OR bm.IsDeleted = 0) AND bm.ID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY bm.Name',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3918, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3919 | What is the name of the school principal? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the name of the school principal?',
        @sql NVARCHAR(MAX) = N'SELECT bm.Principal AS PrincipalName FROM BranchMaster bm WHERE (bm.IsDeleted IS NULL OR bm.IsDeleted = 0) AND bm.ID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3919, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3920 | Principal and contact person details for our branches ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Principal and contact person details for our branches',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS BranchName, bm.Principal, bm.ContactPerson FROM BranchMaster bm WHERE (bm.IsDeleted IS NULL OR bm.IsDeleted = 0) AND bm.ID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY bm.Name',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3920, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3921 | How many branches have a principal assigned? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many branches have a principal assigned?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS BranchesWithPrincipal FROM BranchMaster bm WHERE (bm.IsDeleted IS NULL OR bm.IsDeleted = 0) AND bm.ID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND bm.Principal IS NOT NULL AND bm.Principal <> ''''',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3921, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3922 | Who is the class teacher of class 8 section A? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who is the class teacher of class 8 section A?',
        @sql NVARCHAR(MAX) = N'SELECT stf.Staff_FirstName + '' '' + ISNULL(stf.Staff_LastName, '''') AS ClassTeacher FROM SubjectAllocation_Master sam INNER JOIN Staff_Master stf ON sam.Staff_ID = stf.Staff_ID INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID INNER JOIN SectionMaster secm ON sam.Section_ID = secm.ID WHERE sam.IsClassTeacher = 1 AND stf.StaffStatus_ID = 1 AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND cm.Name = ''Class 8'' AND secm.Name = ''A''',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3922, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3923 | Class teacher for class 10 B? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class teacher for class 10 B?',
        @sql NVARCHAR(MAX) = N'SELECT stf.Staff_FirstName + '' '' + ISNULL(stf.Staff_LastName, '''') AS ClassTeacher FROM SubjectAllocation_Master sam INNER JOIN Staff_Master stf ON sam.Staff_ID = stf.Staff_ID INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID INNER JOIN SectionMaster secm ON sam.Section_ID = secm.ID WHERE sam.IsClassTeacher = 1 AND stf.StaffStatus_ID = 1 AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND cm.Name = ''Class 10'' AND secm.Name = ''B''',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3923, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3924 | Who is the class teacher of 9 C? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who is the class teacher of 9 C?',
        @sql NVARCHAR(MAX) = N'SELECT stf.Staff_FirstName + '' '' + ISNULL(stf.Staff_LastName, '''') AS ClassTeacher FROM SubjectAllocation_Master sam INNER JOIN Staff_Master stf ON sam.Staff_ID = stf.Staff_ID INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID INNER JOIN SectionMaster secm ON sam.Section_ID = secm.ID WHERE sam.IsClassTeacher = 1 AND stf.StaffStatus_ID = 1 AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND cm.Name = ''Class 9'' AND secm.Name = ''C''',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3924, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3925 | Class teacher of class 12 section A name? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class teacher of class 12 section A name?',
        @sql NVARCHAR(MAX) = N'SELECT stf.Staff_FirstName + '' '' + ISNULL(stf.Staff_LastName, '''') AS ClassTeacher FROM SubjectAllocation_Master sam INNER JOIN Staff_Master stf ON sam.Staff_ID = stf.Staff_ID INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID INNER JOIN SectionMaster secm ON sam.Section_ID = secm.ID WHERE sam.IsClassTeacher = 1 AND stf.StaffStatus_ID = 1 AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND cm.Name = ''Class 12'' AND secm.Name = ''A''',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3925, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3926 | Show me all class teachers with their sections ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me all class teachers with their sections',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, secm.Name AS SectionName, stf.Staff_FirstName + '' '' + ISNULL(stf.Staff_LastName, '''') AS ClassTeacher FROM SubjectAllocation_Master sam INNER JOIN Staff_Master stf ON sam.Staff_ID = stf.Staff_ID INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID INNER JOIN SectionMaster secm ON sam.Section_ID = secm.ID WHERE sam.IsClassTeacher = 1 AND stf.StaffStatus_ID = 1 AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY cm.Name, secm.Name',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3926, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3927 | Class teachers for all sections of class 6 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class teachers for all sections of class 6',
        @sql NVARCHAR(MAX) = N'SELECT secm.Name AS SectionName, stf.Staff_FirstName + '' '' + ISNULL(stf.Staff_LastName, '''') AS ClassTeacher FROM SubjectAllocation_Master sam INNER JOIN Staff_Master stf ON sam.Staff_ID = stf.Staff_ID INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID INNER JOIN SectionMaster secm ON sam.Section_ID = secm.ID WHERE sam.IsClassTeacher = 1 AND stf.StaffStatus_ID = 1 AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND cm.Name = ''Class 6'' ORDER BY secm.Name',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3927, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3928 | List the class teachers for class 5 sections ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List the class teachers for class 5 sections',
        @sql NVARCHAR(MAX) = N'SELECT secm.Name AS SectionName, stf.Staff_FirstName + '' '' + ISNULL(stf.Staff_LastName, '''') AS ClassTeacher FROM SubjectAllocation_Master sam INNER JOIN Staff_Master stf ON sam.Staff_ID = stf.Staff_ID INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID INNER JOIN SectionMaster secm ON sam.Section_ID = secm.ID WHERE sam.IsClassTeacher = 1 AND stf.StaffStatus_ID = 1 AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND cm.Name = ''Class 5'' ORDER BY secm.Name',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3928, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3929 | How many class teacher allocations are there this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many class teacher allocations are there this year?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS ClassTeacherAllocations FROM SubjectAllocation_Master sam INNER JOIN Staff_Master stf ON sam.Staff_ID = stf.Staff_ID INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID INNER JOIN SectionMaster secm ON sam.Section_ID = secm.ID WHERE sam.IsClassTeacher = 1 AND stf.StaffStatus_ID = 1 AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3929, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3930 | Who teaches Maths in class 8? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who teaches Maths in class 8?',
        @sql NVARCHAR(MAX) = N'SELECT stf.Staff_FirstName + '' '' + ISNULL(stf.Staff_LastName, '''') AS TeacherName FROM SubjectAllocation_Master sam INNER JOIN Subject_Master s ON s.Id = sam.Subject_ID INNER JOIN Staff_Master stf ON sam.Staff_ID = stf.Staff_ID INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID WHERE stf.StaffStatus_ID = 1 AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND s.Name = ''Maths'' AND cm.Name = ''Class 8''',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3930, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3931 | Science teacher for class 9? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Science teacher for class 9?',
        @sql NVARCHAR(MAX) = N'SELECT stf.Staff_FirstName + '' '' + ISNULL(stf.Staff_LastName, '''') AS TeacherName FROM SubjectAllocation_Master sam INNER JOIN Subject_Master s ON s.Id = sam.Subject_ID INNER JOIN Staff_Master stf ON sam.Staff_ID = stf.Staff_ID INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID WHERE stf.StaffStatus_ID = 1 AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND s.Name = ''Science'' AND cm.Name = ''Class 9''',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3931, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3932 | Who handles English for class 10 section A? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who handles English for class 10 section A?',
        @sql NVARCHAR(MAX) = N'SELECT stf.Staff_FirstName + '' '' + ISNULL(stf.Staff_LastName, '''') AS TeacherName FROM SubjectAllocation_Master sam INNER JOIN Subject_Master s ON s.Id = sam.Subject_ID INNER JOIN Staff_Master stf ON sam.Staff_ID = stf.Staff_ID INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID INNER JOIN SectionMaster secm ON sam.Section_ID = secm.ID WHERE stf.StaffStatus_ID = 1 AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND s.Name = ''English'' AND cm.Name = ''Class 10'' AND secm.Name = ''A''',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3932, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3933 | Which teacher teaches Computer Science in class 11? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which teacher teaches Computer Science in class 11?',
        @sql NVARCHAR(MAX) = N'SELECT stf.Staff_FirstName + '' '' + ISNULL(stf.Staff_LastName, '''') AS TeacherName FROM SubjectAllocation_Master sam INNER JOIN Subject_Master s ON s.Id = sam.Subject_ID INNER JOIN Staff_Master stf ON sam.Staff_ID = stf.Staff_ID INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID WHERE stf.StaffStatus_ID = 1 AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND s.Name = ''Computer Science'' AND cm.Name = ''Class 11''',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3933, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3934 | Who is the Physics teacher for class 12? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who is the Physics teacher for class 12?',
        @sql NVARCHAR(MAX) = N'SELECT stf.Staff_FirstName + '' '' + ISNULL(stf.Staff_LastName, '''') AS TeacherName FROM SubjectAllocation_Master sam INNER JOIN Subject_Master s ON s.Id = sam.Subject_ID INNER JOIN Staff_Master stf ON sam.Staff_ID = stf.Staff_ID INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID WHERE stf.StaffStatus_ID = 1 AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND s.Name = ''Physics'' AND cm.Name = ''Class 12''',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3934, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3935 | Hindi teacher for class 5? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hindi teacher for class 5?',
        @sql NVARCHAR(MAX) = N'SELECT stf.Staff_FirstName + '' '' + ISNULL(stf.Staff_LastName, '''') AS TeacherName FROM SubjectAllocation_Master sam INNER JOIN Subject_Master s ON s.Id = sam.Subject_ID INNER JOIN Staff_Master stf ON sam.Staff_ID = stf.Staff_ID INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID WHERE stf.StaffStatus_ID = 1 AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND s.Name = ''Hindi'' AND cm.Name = ''Class 5''',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3935, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3936 | List all teachers who teach Social Studies in class 7 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all teachers who teach Social Studies in class 7',
        @sql NVARCHAR(MAX) = N'SELECT stf.Staff_FirstName + '' '' + ISNULL(stf.Staff_LastName, '''') AS TeacherName FROM SubjectAllocation_Master sam INNER JOIN Subject_Master s ON s.Id = sam.Subject_ID INNER JOIN Staff_Master stf ON sam.Staff_ID = stf.Staff_ID INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID WHERE stf.StaffStatus_ID = 1 AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND s.Name = ''Social Studies'' AND cm.Name = ''Class 7''',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3936, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3937 | Who teaches Chemistry in class 10 this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who teaches Chemistry in class 10 this year?',
        @sql NVARCHAR(MAX) = N'SELECT stf.Staff_FirstName + '' '' + ISNULL(stf.Staff_LastName, '''') AS TeacherName FROM SubjectAllocation_Master sam INNER JOIN Subject_Master s ON s.Id = sam.Subject_ID INNER JOIN Staff_Master stf ON sam.Staff_ID = stf.Staff_ID INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID WHERE stf.StaffStatus_ID = 1 AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND s.Name = ''Chemistry'' AND cm.Name = ''Class 10''',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3937, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3938 | How many teaching staff do we have? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many teaching staff do we have?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TeachingStaffCount FROM Staff_Master stf INNER JOIN StaffType_Master stm ON stf.StaffType_ID = stm.ID WHERE stf.StaffStatus_ID = 1 AND (stf.IsDeleted IS NULL OR stf.IsDeleted = 0) AND stf.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND stm.Name = ''Teaching''',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3938, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3939 | List the non teaching staff ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List the non teaching staff',
        @sql NVARCHAR(MAX) = N'SELECT stf.Staff_Code, stf.Staff_FirstName + '' '' + ISNULL(stf.Staff_LastName, '''') AS StaffName FROM Staff_Master stf INNER JOIN StaffType_Master stm ON stf.StaffType_ID = stm.ID WHERE stf.StaffStatus_ID = 1 AND (stf.IsDeleted IS NULL OR stf.IsDeleted = 0) AND stf.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND stm.Name <> ''Teaching'' ORDER BY stf.Staff_FirstName',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3939, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3940 | Count of administrative staff ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Count of administrative staff',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS AdminStaffCount FROM Staff_Master stf INNER JOIN StaffType_Master stm ON stf.StaffType_ID = stm.ID WHERE stf.StaffStatus_ID = 1 AND (stf.IsDeleted IS NULL OR stf.IsDeleted = 0) AND stf.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND stm.Name LIKE ''%Admin%''',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3940, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3941 | Staff strength by staff type ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff strength by staff type',
        @sql NVARCHAR(MAX) = N'SELECT stm.Name AS StaffType, COUNT(*) AS StaffCount FROM Staff_Master stf INNER JOIN StaffType_Master stm ON stf.StaffType_ID = stm.ID WHERE stf.StaffStatus_ID = 1 AND (stf.IsDeleted IS NULL OR stf.IsDeleted = 0) AND stf.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY stm.Name ORDER BY StaffCount DESC',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3941, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3942 | How many drivers are on the rolls? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many drivers are on the rolls?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS DriverCount FROM Staff_Master stf WHERE stf.IsDriver = 1 AND stf.StaffStatus_ID = 1 AND (stf.IsDeleted IS NULL OR stf.IsDeleted = 0) AND stf.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3942, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3943 | List active staff with their staff type ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List active staff with their staff type',
        @sql NVARCHAR(MAX) = N'SELECT stf.Staff_FirstName + '' '' + ISNULL(stf.Staff_LastName, '''') AS StaffName, stm.Name AS StaffType FROM Staff_Master stf INNER JOIN StaffType_Master stm ON stf.StaffType_ID = stm.ID WHERE stf.StaffStatus_ID = 1 AND (stf.IsDeleted IS NULL OR stf.IsDeleted = 0) AND stf.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY stm.Name, stf.Staff_FirstName',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3943, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3944 | How many support staff work here? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many support staff work here?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS SupportStaffCount FROM Staff_Master stf INNER JOIN StaffType_Master stm ON stf.StaffType_ID = stm.ID WHERE stf.StaffStatus_ID = 1 AND (stf.IsDeleted IS NULL OR stf.IsDeleted = 0) AND stf.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND stm.Name LIKE ''%Support%''',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3944, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3945 | Teaching staff count by branch ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Teaching staff count by branch',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS BranchName, COUNT(*) AS TeachingStaff FROM Staff_Master stf INNER JOIN StaffType_Master stm ON stf.StaffType_ID = stm.ID INNER JOIN BranchMaster bm ON stf.BranchID = bm.ID WHERE stm.Name = ''Teaching'' AND stf.StaffStatus_ID = 1 AND (stf.IsDeleted IS NULL OR stf.IsDeleted = 0) AND stf.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3945, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3946 | How many active staff members are there? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many active staff members are there?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS ActiveStaffCount FROM Staff_Master stf WHERE stf.StaffStatus_ID = 1 AND (stf.IsDeleted IS NULL OR stf.IsDeleted = 0) AND stf.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3946, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3947 | List currently working staff ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List currently working staff',
        @sql NVARCHAR(MAX) = N'SELECT stf.Staff_Code, stf.Staff_FirstName + '' '' + ISNULL(stf.Staff_LastName, '''') AS StaffName FROM Staff_Master stf WHERE stf.StaffStatus_ID = 1 AND (stf.IsDeleted IS NULL OR stf.IsDeleted = 0) AND stf.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY stf.Staff_FirstName',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3947, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3948 | How many staff are on the payroll for salary processing? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many staff are on the payroll for salary processing?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS PayrollStaffCount FROM Staff_Master stf WHERE stf.StaffStatus_ID = 1 AND (stf.IsDeleted IS NULL OR stf.IsDeleted = 0) AND stf.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3948, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3949 | Currently teaching staff count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Currently teaching staff count',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS CurrentlyTeachingCount FROM Staff_Master stf INNER JOIN StaffType_Master stm ON stf.StaffType_ID = stm.ID WHERE stf.StaffStatus_ID = 1 AND (stf.IsDeleted IS NULL OR stf.IsDeleted = 0) AND stm.Name = ''Teaching'' AND stf.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3949, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3950 | How many staff are currently on duty? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many staff are currently on duty?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS StaffOnDuty FROM Staff_Master stf WHERE stf.StaffStatus_ID = 1 AND (stf.IsDeleted IS NULL OR stf.IsDeleted = 0) AND stf.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3950, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3951 | How many messages were sent today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many messages were sent today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS MessagesSent FROM SMSAuditTrail sat WHERE CAST(sat.CreatedDate AS DATE) = CAST(GETDATE() AS DATE) AND sat.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3951, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3952 | Messages sent this week ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Messages sent this week',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS MessagesSent FROM SMSAuditTrail sat WHERE sat.CreatedDate >= DATEADD(DAY, 1 - DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE)) AND sat.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3952, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3953 | Message count by screen this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Message count by screen this month',
        @sql NVARCHAR(MAX) = N'SELECT sat.Screen_Names AS Screen, COUNT(*) AS MessageCount FROM SMSAuditTrail sat WHERE sat.CreatedDate >= DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0) AND sat.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sat.Screen_Names ORDER BY MessageCount DESC',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3953, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3954 | Who sent the most messages today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who sent the most messages today?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 sat.CreatedBy AS SentBy, COUNT(*) AS MessageCount FROM SMSAuditTrail sat WHERE CAST(sat.CreatedDate AS DATE) = CAST(GETDATE() AS DATE) AND sat.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sat.CreatedBy ORDER BY MessageCount DESC',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3954, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3955 | Messages sent in the last 24 hours ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Messages sent in the last 24 hours',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS MessagesSent FROM SMSAuditTrail sat WHERE sat.CreatedDate >= DATEADD(HOUR, -24, GETDATE()) AND sat.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3955, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3956 | SMS audit entries by operation this week ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'SMS audit entries by operation this week',
        @sql NVARCHAR(MAX) = N'SELECT sat.Operation, COUNT(*) AS EntryCount FROM SMSAuditTrail sat WHERE sat.CreatedDate >= DATEADD(DAY, 1 - DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE)) AND sat.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sat.Operation',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3956, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3957 | How many feedback tickets were raised this week? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many feedback tickets were raised this week?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS FeedbackCount FROM FeedbackTicket ft WHERE ft.Created_Date >= DATEADD(DAY, 1 - DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE)) AND (ft.IsDeleted = 0 OR ft.IsDeleted IS NULL) AND ft.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3957, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3958 | Feedback tickets by status ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Feedback tickets by status',
        @sql NVARCHAR(MAX) = N'SELECT ft.Status, COUNT(*) AS TicketCount FROM FeedbackTicket ft WHERE (ft.IsDeleted = 0 OR ft.IsDeleted IS NULL) AND ft.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND ft.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY ft.Status',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3958, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3959 | Show recent feedback with contact names ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show recent feedback with contact names',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 ft.TicketNo, ft.ContactName, ft.Subject, ft.Created_Date FROM FeedbackTicket ft WHERE (ft.IsDeleted = 0 OR ft.IsDeleted IS NULL) AND ft.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY ft.Created_Date DESC',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3959, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3960 | Parent complaints by feedback category ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Parent complaints by feedback category',
        @sql NVARCHAR(MAX) = N'SELECT fcat.Name AS Category, COUNT(*) AS TicketCount FROM FeedbackTicket ft INNER JOIN FeedbackCategory fcat ON ft.CategoryID = fcat.ID WHERE (ft.IsDeleted = 0 OR ft.IsDeleted IS NULL) AND ft.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND ft.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fcat.Name ORDER BY TicketCount DESC',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3960, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3961 | How many feedback tickets are pending closure? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many feedback tickets are pending closure?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS PendingTickets FROM FeedbackTicket ft WHERE ISNULL(ft.Status, ''Open'') <> ''Closed'' AND (ft.IsDeleted = 0 OR ft.IsDeleted IS NULL) AND ft.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND ft.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3961, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3962 | Feedback received this month count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Feedback received this month count',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS FeedbackThisMonth FROM FeedbackTicket ft WHERE ft.Created_Date >= DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0) AND (ft.IsDeleted = 0 OR ft.IsDeleted IS NULL) AND ft.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3962, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3963 | How many admission enquiries came in this week? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many admission enquiries came in this week?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS WeekEnquiries FROM GeneralCallRegister gcr WHERE gcr.CallDate >= DATEADD(DAY, 1 - DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE)) AND (gcr.IsDeleted = 0 OR gcr.IsDeleted IS NULL) AND gcr.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3963, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3964 | Admission enquiry count this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Admission enquiry count this month',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS MonthEnquiries FROM GeneralCallRegister gcr WHERE gcr.CallDate >= DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0) AND (gcr.IsDeleted = 0 OR gcr.IsDeleted IS NULL) AND gcr.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3964, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3965 | Enquiries by call category ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Enquiries by call category',
        @sql NVARCHAR(MAX) = N'SELECT ccat.Name AS CallCategory, COUNT(*) AS EnquiryCount FROM GeneralCallRegister gcr INNER JOIN CallCategory_Master ccat ON gcr.CallCategory_ID = ccat.ID WHERE (gcr.IsDeleted = 0 OR gcr.IsDeleted IS NULL) AND gcr.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gcr.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY ccat.Name ORDER BY EnquiryCount DESC',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3965, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3966 | How many enquiries were moved to the admission stage this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many enquiries were moved to the admission stage this year?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS MovedToAdmission FROM GeneralCallRegister gcr WHERE gcr.MovetoEnquiry = 1 AND (gcr.IsDeleted = 0 OR gcr.IsDeleted IS NULL) AND gcr.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND gcr.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3966, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3967 | Who handled the most enquiries this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who handled the most enquiries this month?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 stf.Staff_FirstName + '' '' + ISNULL(stf.Staff_LastName, '''') AS StaffName, COUNT(*) AS EnquiriesHandled FROM GeneralCallRegister gcr INNER JOIN Staff_Master stf ON gcr.HandledBy_ID = stf.Staff_ID WHERE gcr.CallDate >= DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0) AND (gcr.IsDeleted = 0 OR gcr.IsDeleted IS NULL) AND gcr.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY stf.Staff_FirstName, stf.Staff_LastName ORDER BY EnquiriesHandled DESC',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3967, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3968 | How many admission applications got admitted this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many admission applications got admitted this year?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS AdmittedApplications FROM ApplicationEntry ae WHERE ae.AdmissionNo IS NOT NULL AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3968, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3969 | What is the application to admission conversion rate this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the application to admission conversion rate this year?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(CASE WHEN ae.AdmissionNo IS NOT NULL THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS ConversionRate FROM ApplicationEntry ae WHERE (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3969, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3970 | List applications converted to admissions this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List applications converted to admissions this month',
        @sql NVARCHAR(MAX) = N'SELECT ae.ApplicationNo, ae.FirstName + '' '' + ae.LastName AS ApplicantName, ae.AdmissionDate FROM ApplicationEntry ae WHERE ae.AdmissionNo IS NOT NULL AND ae.AdmissionDate >= DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) AND ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3970, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3971 | How many applicants have been given admission numbers this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many applicants have been given admission numbers this year?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS ApplicantsWithAdmission FROM ApplicationEntry ae WHERE ae.AdmissionNo IS NOT NULL AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3971, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3972 | Which classes have attendance not marked for today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which classes have attendance not marked for today?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, secm.Name AS SectionName FROM ClassSectionMaster csm INNER JOIN ClassMaster cm ON csm.Class_Id = cm.ID INNER JOIN SectionMaster secm ON csm.Section_Id = secm.ID WHERE (csm.IsDeleted IS NULL OR csm.IsDeleted = 0) AND csm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND csm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND NOT EXISTS (SELECT 1 FROM StudentAttendance sa WHERE sa.Class_ID = csm.Class_Id AND sa.Section_ID = csm.Section_Id AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3972, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3973 | Class sections where attendance is not entered for today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class sections where attendance is not entered for today',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, secm.Name AS SectionName FROM ClassSectionMaster csm INNER JOIN ClassMaster cm ON csm.Class_Id = cm.ID INNER JOIN SectionMaster secm ON csm.Section_Id = secm.ID WHERE (csm.IsDeleted IS NULL OR csm.IsDeleted = 0) AND csm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND csm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND NOT EXISTS (SELECT 1 FROM StudentAttendance sa WHERE sa.Class_ID = csm.Class_Id AND sa.Section_ID = csm.Section_Id AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3973, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3974 | Which classes did not take attendance yesterday? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which classes did not take attendance yesterday?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, secm.Name AS SectionName FROM ClassSectionMaster csm INNER JOIN ClassMaster cm ON csm.Class_Id = cm.ID INNER JOIN SectionMaster secm ON csm.Section_Id = secm.ID WHERE (csm.IsDeleted IS NULL OR csm.IsDeleted = 0) AND csm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND csm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND NOT EXISTS (SELECT 1 FROM StudentAttendance sa WHERE sa.Class_ID = csm.Class_Id AND sa.Section_ID = csm.Section_Id AND CAST(sa.Attendance_Date AS DATE) = CAST(DATEADD(DAY, -1, GETDATE()) AS DATE))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3974, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3975 | Find class sections with missing attendance today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Find class sections with missing attendance today',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, secm.Name AS SectionName FROM ClassSectionMaster csm INNER JOIN ClassMaster cm ON csm.Class_Id = cm.ID INNER JOIN SectionMaster secm ON csm.Section_Id = secm.ID WHERE (csm.IsDeleted IS NULL OR csm.IsDeleted = 0) AND csm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND csm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND NOT EXISTS (SELECT 1 FROM StudentAttendance sa WHERE sa.Class_ID = csm.Class_Id AND sa.Section_ID = csm.Section_Id AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3975, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3976 | Which sections have not submitted attendance for today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which sections have not submitted attendance for today?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, secm.Name AS SectionName FROM ClassSectionMaster csm INNER JOIN ClassMaster cm ON csm.Class_Id = cm.ID INNER JOIN SectionMaster secm ON csm.Section_Id = secm.ID WHERE (csm.IsDeleted IS NULL OR csm.IsDeleted = 0) AND csm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND csm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND NOT EXISTS (SELECT 1 FROM StudentAttendance sa WHERE sa.Class_ID = csm.Class_Id AND sa.Section_ID = csm.Section_Id AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3976, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3977 | Class 8 sections where attendance is not marked today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class 8 sections where attendance is not marked today',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, secm.Name AS SectionName FROM ClassSectionMaster csm INNER JOIN ClassMaster cm ON csm.Class_Id = cm.ID INNER JOIN SectionMaster secm ON csm.Section_Id = secm.ID WHERE (csm.IsDeleted IS NULL OR csm.IsDeleted = 0) AND csm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND csm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND cm.Name = ''Class 8'' AND NOT EXISTS (SELECT 1 FROM StudentAttendance sa WHERE sa.Class_ID = csm.Class_Id AND sa.Section_ID = csm.Section_Id AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3977, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3978 | For which classes is attendance not updated today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'For which classes is attendance not updated today?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, secm.Name AS SectionName FROM ClassSectionMaster csm INNER JOIN ClassMaster cm ON csm.Class_Id = cm.ID INNER JOIN SectionMaster secm ON csm.Section_Id = secm.ID WHERE (csm.IsDeleted IS NULL OR csm.IsDeleted = 0) AND csm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND csm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND NOT EXISTS (SELECT 1 FROM StudentAttendance sa WHERE sa.Class_ID = csm.Class_Id AND sa.Section_ID = csm.Section_Id AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3978, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3979 | How many class sections have attendance not marked today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many class sections have attendance not marked today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS SectionsNotMarked FROM ClassSectionMaster csm INNER JOIN ClassMaster cm ON csm.Class_Id = cm.ID INNER JOIN SectionMaster secm ON csm.Section_Id = secm.ID WHERE (csm.IsDeleted IS NULL OR csm.IsDeleted = 0) AND csm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND csm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND NOT EXISTS (SELECT 1 FROM StudentAttendance sa WHERE sa.Class_ID = csm.Class_Id AND sa.Section_ID = csm.Section_Id AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3979, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3980 | Attendance summary for today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Attendance summary for today',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END), 0) AS PresentCount, ISNULL(SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END), 0) AS AbsentCount FROM StudentAttendance sa WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3980, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3981 | Present and absent counts for class 9 today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Present and absent counts for class 9 today',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END), 0) AS PresentCount, ISNULL(SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END), 0) AS AbsentCount FROM StudentAttendance sa INNER JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE cm.Name = ''Class 9'' AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3981, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3982 | Attendance summary for this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Attendance summary for this month',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END), 0) AS PresentCount, ISNULL(SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END), 0) AS AbsentCount FROM StudentAttendance sa WHERE sa.Attendance_Date >= DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3982, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3983 | Class wise attendance summary today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class wise attendance summary today',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, ISNULL(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END), 0) AS PresentCount, ISNULL(SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END), 0) AS AbsentCount FROM StudentAttendance sa INNER JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name ORDER BY cm.Name',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3983, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3984 | List absent students in class 8 section A today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List absent students in class 8 section A today',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName + '' '' + sm.LastName AS StudentName FROM StudentAttendance sa INNER JOIN Student_Master sm ON sm.ID = sa.Student_ID INNER JOIN ClassMaster cm ON sa.Class_ID = cm.ID INNER JOIN SectionMaster secm ON sa.Section_ID = secm.ID WHERE sa.Attendance_Status_ID = 2 AND cm.Name = ''Class 8'' AND secm.Name = ''A'' AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3984, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3985 | Attendance summary for this week ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Attendance summary for this week',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END), 0) AS PresentCount, ISNULL(SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END), 0) AS AbsentCount FROM StudentAttendance sa WHERE sa.Attendance_Date >= DATEADD(DAY, 1 - DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE)) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3985, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3986 | How many students are absent today across the school? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students are absent today across the school?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END), 0) AS AbsentCount FROM StudentAttendance sa WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3986, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3987 | Attendance percentage of each student in class 10 this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Attendance percentage of each student in class 10 this month',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName + '' '' + sm.LastName AS StudentName, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AttendancePercentage FROM StudentAttendance sa INNER JOIN Student_Master sm ON sm.ID = sa.Student_ID INNER JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE cm.Name = ''Class 10'' AND sa.Attendance_Date >= DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.FirstName, sm.LastName',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3987, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3988 | Class wise attendance percentage this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class wise attendance percentage this month',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AttendancePercentage FROM StudentAttendance sa INNER JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE sa.Attendance_Date >= DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name ORDER BY cm.Name',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3988, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3989 | Students with attendance below 75 percent this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students with attendance below 75 percent this month',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName + '' '' + sm.LastName AS StudentName, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AttendancePercentage FROM StudentAttendance sa INNER JOIN Student_Master sm ON sm.ID = sa.Student_ID WHERE sa.Attendance_Date >= DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.FirstName, sm.LastName HAVING CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) < 75',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3989, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3990 | Average attendance percentage for class 8 section B this week ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Average attendance percentage for class 8 section B this week',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AttendancePercentage FROM StudentAttendance sa INNER JOIN ClassMaster cm ON sa.Class_ID = cm.ID INNER JOIN SectionMaster secm ON sa.Section_ID = secm.ID WHERE cm.Name = ''Class 8'' AND secm.Name = ''B'' AND sa.Attendance_Date >= DATEADD(DAY, 1 - DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE)) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3990, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3991 | Attendance percentage for class 9 section A today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Attendance percentage for class 9 section A today',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AttendancePercentage FROM StudentAttendance sa INNER JOIN ClassMaster cm ON sa.Class_ID = cm.ID INNER JOIN SectionMaster secm ON sa.Section_ID = secm.ID WHERE cm.Name = ''Class 9'' AND secm.Name = ''A'' AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3991, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3992 | Students with the highest attendance percentage this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students with the highest attendance percentage this month',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 sm.FirstName + '' '' + sm.LastName AS StudentName, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AttendancePercentage FROM StudentAttendance sa INNER JOIN Student_Master sm ON sm.ID = sa.Student_ID WHERE sa.Attendance_Date >= DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.FirstName, sm.LastName ORDER BY AttendancePercentage DESC',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3992, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3993 | List upcoming holidays ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List upcoming holidays',
        @sql NVARCHAR(MAX) = N'SELECT hm.Name AS HolidayName, hm.From_Date, hm.To_Date, CASE WHEN hm.IsHalfDay = 1 THEN ''Half Day'' ELSE ''Full Day'' END AS DayType FROM HolidayMaster hm WHERE (hm.IsDeleted = 0 OR hm.IsDeleted IS NULL) AND hm.From_Date >= CAST(GETDATE() AS DATE) AND hm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY hm.From_Date',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3993, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3994 | Total holiday days this year including half days ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total holiday days this year including half days',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(CASE WHEN hm.IsHalfDay = 1 THEN 0.5 ELSE DATEDIFF(DAY, hm.From_Date, hm.To_Date) + 1 END), 0) AS TotalHolidayDays FROM HolidayMaster hm WHERE (hm.IsDeleted = 0 OR hm.IsDeleted IS NULL) AND hm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND hm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3994, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3995 | Upcoming half day holidays ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Upcoming half day holidays',
        @sql NVARCHAR(MAX) = N'SELECT hm.Name AS HolidayName, hm.From_Date, hm.To_Date FROM HolidayMaster hm WHERE (hm.IsDeleted = 0 OR hm.IsDeleted IS NULL) AND hm.IsHalfDay = 1 AND hm.From_Date >= CAST(GETDATE() AS DATE) AND hm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY hm.From_Date',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3995, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3996 | Holidays falling this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Holidays falling this month',
        @sql NVARCHAR(MAX) = N'SELECT hm.Name AS HolidayName, hm.From_Date, hm.To_Date FROM HolidayMaster hm WHERE (hm.IsDeleted = 0 OR hm.IsDeleted IS NULL) AND hm.From_Date >= DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0) AND hm.From_Date < DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()) + 1, 0) AND hm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY hm.From_Date',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3996, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3997 | List the government holidays this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List the government holidays this year',
        @sql NVARCHAR(MAX) = N'SELECT hm.Name AS HolidayName, hm.From_Date, hm.To_Date FROM HolidayMaster hm WHERE (hm.IsDeleted = 0 OR hm.IsDeleted IS NULL) AND hm.GovernmentHoliday = 1 AND hm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND hm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY hm.From_Date',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3997, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3998 | Compare boys vs girls count in class 10 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare boys vs girls count in class 10',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CASE WHEN sm.Gender IN (''Male'', ''Boy'') THEN 1 ELSE 0 END) AS Boys, SUM(CASE WHEN sm.Gender IN (''Female'', ''Girl'') THEN 1 ELSE 0 END) AS Girls FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE cm.Name = ''Class 10'' AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3998, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3999 | Compare student strength of class 9 vs class 10 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare student strength of class 9 vs class 10',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CASE WHEN cm.Name = ''Class 9'' THEN 1 ELSE 0 END) AS Class9Students, SUM(CASE WHEN cm.Name = ''Class 10'' THEN 1 ELSE 0 END) AS Class10Students FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE cm.Name IN (''Class 9'', ''Class 10'') AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3999, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4000 | Compare fees collected this month vs last month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare fees collected this month vs last month',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CASE WHEN DATEDIFF(MONTH, fc.Bill_Date, GETDATE()) = 0 THEN ISNULL(fc.Receipt_Amt, 0) ELSE 0 END) AS ThisMonth, SUM(CASE WHEN DATEDIFF(MONTH, fc.Bill_Date, GETDATE()) = 1 THEN ISNULL(fc.Receipt_Amt, 0) ELSE 0 END) AS LastMonth FROM FeesCollection fc WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
PRINT 'checkpoint: reached Q4000';
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4000, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ===================== PART 8 SUMMARY (Q3501-Q4000) =====================
DECLARE @lo INT = 3501, @hi INT = 4000, @fails INT;
SELECT @fails = COUNT(*) FROM #ai_errors WHERE qid BETWEEN @lo AND @hi;
PRINT 'PART 8 done: ' + CAST((@hi - @lo + 1) AS VARCHAR(6)) + ' queries, '
    + CAST(@fails AS VARCHAR(6)) + ' failed.';
DECLARE @qid INT, @qq NVARCHAR(300), @ee NVARCHAR(2048);
DECLARE c CURSOR LOCAL FAST_FORWARD FOR
    SELECT qid, question, error FROM #ai_errors WHERE qid BETWEEN @lo AND @hi ORDER BY qid;
OPEN c;
FETCH NEXT FROM c INTO @qid, @qq, @ee;
WHILE @@FETCH_STATUS = 0
BEGIN
    PRINT 'Q' + CAST(@qid AS VARCHAR(6)) + ' FAILED: ' + LEFT(@ee, 300);
    PRINT '   question: ' + LEFT(@qq, 200);
    FETCH NEXT FROM c INTO @qid, @qq, @ee;
END
CLOSE c; DEALLOCATE c;
SELECT qid, question, error, ms FROM #ai_errors WHERE qid BETWEEN @lo AND @hi ORDER BY qid;
GO

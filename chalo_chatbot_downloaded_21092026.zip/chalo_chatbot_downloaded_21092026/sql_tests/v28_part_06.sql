/* =====================================================================
   ChaloSchools AI Secretary - v28 dataset local test (SSMS)
   Part 6 of 9: queries Q2501 to Q3000 (500 of 4034 in the full dataset)
   Source: semantic_validation/reference_inputs/training_dataset_final_v28.jsonl
   Generated: 2026-09-04
   The SQL text is EXACTLY what the dataset holds (single quotes appear
   doubled inside the @sql string - T-SQL string escaping; multi-line
   queries keep line breaks, which SQL Server counts as whitespace).
   So any error you see here is an error the trained model would produce.

   ONE SETTING TO CHANGE BEFORE RUNNING:
     The queries are security-scoped to a user, like in production. They run
     as @UserId. Change it to YOUR local user id:
       Find & Replace across these files:   @UserId INT = 1
       (see your users with:  SELECT ID, UserName FROM UserAccountMaster;)
     @SelectedBranchId NULL = all branches you are allowed; put a branch id
       there to simulate one selected branch.

   RECOMMENDED for big runs (stops 500 result grids appearing):
     Query menu > Query Options... > Results > Grid >
     tick 'Discard results after execution', then Execute (F5).
     Everything still runs; errors + summary appear in the Messages tab.
   Failures (INCLUDING compile-time errors - bad syntax, unknown columns,
   unknown tables - thanks to the sp_executesql wrapper) are printed as:
     Q### FAILED: <error text>
        question: <the natural-language question>
   and stored in table #ai_errors until you close the connection.
   ===================================================================== */
SET NOCOUNT ON;
GO
IF OBJECT_ID('tempdb..#ai_errors') IS NULL
    CREATE TABLE #ai_errors (
        qid      INT NOT NULL PRIMARY KEY,
        question NVARCHAR(300),
        error    NVARCHAR(2048),
        ms       INT NOT NULL
    );
GO
-- ============ Q2501 | How many A grades were given in Class 10? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many A grades were given in Class 10?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS AGradeCount FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE cm.Name IN (''Class 10'', ''X'') AND pc.Grade = ''A'' AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2501, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2502 | What percentage of total fee demand is bus fee? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What percentage of total fee demand is bus fee?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(SUM(CASE WHEN IsBusFee = 1 THEN Amount ELSE 0 END) * 100.0 / NULLIF(SUM(Amount), 0), 2) AS BusFeePercentage FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2502, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2503 | Are there any duplicate class-subject-section mappings? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Are there any duplicate class-subject-section mappings?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, secm.Name AS SectionName, cs.Subject_Id, COUNT(*) AS DuplicateCount FROM ClassSubjectDetails cs INNER JOIN ClassMaster cm ON cs.Class_Id = cm.ID INNER JOIN SectionMaster secm ON cs.Section_Id = secm.ID WHERE cs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND cs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY cm.Name, secm.Name, cs.Subject_Id HAVING COUNT(*) > 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2503, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2504 | Show staff who left early today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show staff who left early today',
        @sql NVARCHAR(MAX) = N'SELECT sa.Staff_ID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName, sa.OutTime FROM Staff_Attendance sa INNER JOIN Staff_Master sm ON sa.Staff_ID = sm.Staff_ID AND sm.StaffStatus_ID = 1 WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.Attendance_Date = CAST(GETDATE() AS DATE) AND sa.Attendance_Status_ID = 1 AND OutTime < ''16:00:00'' AND OutTime IS NOT NULL ORDER BY OutTime ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2504, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2505 | Give me the compare weekday vs weekend collections ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the compare weekday vs weekend collections',
        @sql NVARCHAR(MAX) = N'SELECT CASE WHEN DATEPART(WEEKDAY, fc.Bill_Date) IN (1, 7) THEN ''Weekend'' ELSE ''Weekday'' END AS DayType, SUM(fc.Receipt_Amt) AS TotalCollection, COUNT(fc.Id) AS TransactionCount FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY CASE WHEN DATEPART(WEEKDAY, fc.Bill_Date) IN (1, 7) THEN ''Weekend'' ELSE ''Weekday'' END;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2505, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2506 | I need to see circulars sent to parents ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see circulars sent to parents',
        @sql NVARCHAR(MAX) = N'SELECT ce.Title, ce.Description, ce.Circular_Date, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS CreatedBy_Name, ce.Created_Date AS CreatedDate FROM CircularEntry ce LEFT JOIN Staff_Master sm ON ce.Created_By = sm.Staff_ID WHERE ce.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ce.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND ce.CircularApplicableFor LIKE ''%Parent%'' AND (ce.IsDeleted = 0 OR ce.IsDeleted IS NULL) ORDER BY ce.Created_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2506, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2507 | Show me the most recent 10 refunds issued. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me the most recent 10 refunds issued.',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 r.Bill_Date AS RefundDate, sm.FirstName + '' '' + sm.LastName AS StudentName, r.Refund_Amt AS Amount, r.RequestRemarks AS Reason FROM RefundReceipt r INNER JOIN Student_Master sm ON r.Student_ID = sm.ID WHERE r.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND r.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY r.Bill_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2507, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2508 | Just checking - how many enquiries were closed or lost? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many enquiries were closed or lost?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS ClosedEnquiries FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND CallStatus_ID IN (SELECT ID FROM Enquiry_Status_Master WHERE Name = ''Dropped'');',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2508, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2509 | I need to see applications received in the last 30 days ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see applications received in the last 30 days',
        @sql NVARCHAR(MAX) = N'SELECT ae.ApplicationNo, ae.FirstName + ISNULL('' '' + ae.MiddleName, '''') + '' '' + ae.LastName AS StudentName, ae.FatherName, ae.ComMobile AS Phone, cm.Name AS ClassApplied, asm.Name AS Status FROM ApplicationEntry ae INNER JOIN ClassMaster cm ON ae.Student_ClassID = cm.ID INNER JOIN ApplicationStatus_Master asm ON ae.ApplicationStatus_ID = asm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) AND ae.ApplicationDate >= DATEADD(DAY, -30, GETDATE()) ORDER BY ae.ApplicationDate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2509, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2510 | List all students who got annual discount with discount amount ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all students who got annual discount with discount amount',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, fc.AnnualDiscount_Amt, fc.Bill_No FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN FeesCollection fc ON sm.ID = fc.Student_ID WHERE fc.IsAnnualDiscountApplied = 1 AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY fc.AnnualDiscount_Amt DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2510, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2511 | Which staff members are retiring this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which staff members are retiring this month?',
        @sql NVARCHAR(MAX) = N'SELECT sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName, CASE WHEN sm.Staff_RetirementDate IS NULL THEN DATEADD(YEAR, 58, sm.Staff_DOB) ELSE sm.Staff_RetirementDate END AS RetirementDate FROM Staff_Master sm WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1 AND MONTH(CASE WHEN sm.Staff_RetirementDate IS NULL THEN DATEADD(YEAR, 58, sm.Staff_DOB) ELSE sm.Staff_RetirementDate END) = MONTH(GETDATE()) AND YEAR(CASE WHEN sm.Staff_RetirementDate IS NULL THEN DATEADD(YEAR, 58, sm.Staff_DOB) ELSE sm.Staff_RetirementDate END) = YEAR(GETDATE());',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2511, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2512 | Attendance rate for this week ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Attendance rate for this week',
        @sql NVARCHAR(MAX) = N'SELECT CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS WeeklyAttendanceRate FROM StudentAttendance sa WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.Attendance_Date >= DATEADD(DAY, 1 - DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE)) AND sa.Attendance_Date <= CAST(GETDATE() AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2512, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2513 | What's the annual discount as a percentage of total fees? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the annual discount as a percentage of total fees?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(fc.AnnualDiscount_Amt) * 100.0 / NULLIF((SELECT SUM(fcd2.Fees_Amount) FROM FeesCollection_Details fcd2 WHERE fcd2.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd2.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)))), 0) AS DECIMAL(5,2)) AS DiscountPercent FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.IsAnnualDiscountApplied = 1 AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2513, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2514 | Pull up month-wise late fee generation trend ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up month-wise late fee generation trend',
        @sql NVARCHAR(MAX) = N'SELECT FORMAT(fc.Bill_Date, ''yyyy-MM'') AS [Month], COUNT(*) AS Entries, SUM(fcd.LateFeeAmount) AS TotalAmount FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.LateFeeAmount > 0 AND (fc.IsDeleted = 0 OR fc.IsDeleted IS NULL) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY FORMAT(fc.Bill_Date, ''yyyy-MM'') ORDER BY [Month];',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2514, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2515 | Show me the top 5 classes with highest dropout rate ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me the top 5 classes with highest dropout rate',
        @sql NVARCHAR(MAX) = N'SELECT TOP 5 cm.Name AS ClassName, COUNT(DISTINCT CASE WHEN sad.IsTCIssued = 1 THEN sad.StudentID END) AS Dropouts, COUNT(DISTINCT sad.StudentID) AS TotalStudents, CAST(COUNT(DISTINCT CASE WHEN sad.IsTCIssued = 1 THEN sad.StudentID END) * 100.0 / NULLIF(COUNT(DISTINCT sad.StudentID), 0) AS DECIMAL(5,2)) AS DropoutRate FROM StudentAcademicDetail sad JOIN ClassMaster cm ON sad.ClassID = cm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name ORDER BY DropoutRate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2515, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2516 | Let me see class-wise remaining fee amount ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see class-wise remaining fee amount',
        @sql NVARCHAR(MAX) = N'SELECT f.ClassName, SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS Outstanding FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY f.ClassName ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2516, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2517 | Cancelled receipts in the last 2 weeks ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Cancelled receipts in the last 2 weeks',
        @sql NVARCHAR(MAX) = N'SELECT fc.Bill_No, fc.Admission_No, fc.Receipt_Amt, fc.Cancellation_Date, fc.Cancelled_By_Name FROM FeesCollection fc WHERE fc.IsDeleted = 1 AND fc.Cancellation_Date >= DATEADD(DAY, -14, CAST(GETDATE() AS DATE)) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY fc.Cancellation_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2517, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2518 | Student with highest number of receipts ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Student with highest number of receipts',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, COUNT(fc.Id) AS ReceiptCount, SUM(fc.Receipt_Amt) AS TotalPaid FROM FeesCollection fc INNER JOIN Student_Master sm ON fc.Student_ID = sm.ID WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY sm.AdmissionNo, sm.FirstName, sm.MiddleName, sm.LastName ORDER BY COUNT(fc.Id) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2518, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2519 | Show me source-wise enquiry breakdown. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me source-wise enquiry breakdown.',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT emm.Name AS Source, COUNT(*) AS EnquiryCount FROM GeneralCallRegister em INNER JOIN Enquiry_Mode_Master emm ON em.Mode_ID = emm.ID WHERE em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND (em.IsDeleted = 0 OR em.IsDeleted IS NULL) GROUP BY emm.Name ORDER BY EnquiryCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2519, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2520 | Who collected the most fees today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who collected the most fees today?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 fc.Collected_By_Name, SUM(fc.Receipt_Amt) AS total_collected FROM FeesCollection fc WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fc.Collected_By_Name ORDER BY SUM(fc.Receipt_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2520, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2521 | How many regular admissions were completed this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many regular admissions were completed this year?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS RegularAdmissions FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID INNER JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sm.AdmissionTypeName LIKE ''%REGULAR%'' AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2521, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2522 | Hey, what's the total enrollment count for the current session? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the total enrollment count for the current session?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS TotalEnrollment FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2522, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2523 | Today's fee payment count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Today''s fee payment count',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT fc.Student_ID) AS StudentsPaid FROM FeesCollection fc WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2523, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2524 | Total new admissions this academic year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total new admissions this academic year',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS new_admissions FROM StudentAcademicDetail sad WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.IsNewAdmission = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2524, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2525 | List staff who have not taken any leave this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List staff who have not taken any leave this year',
        @sql NVARCHAR(MAX) = N'SELECT sm.Staff_FirstName, sm.Staff_LastName FROM Staff_Master sm WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1 AND NOT EXISTS (SELECT 1 FROM LeaveEntryMaster lem WHERE lem.Staff_ID = sm.Staff_ID AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date) AND (lem.IsDeleted IS NULL OR lem.IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2525, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2526 | I need to see month-wise new admissions vs students who left ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see month-wise new admissions vs students who left',
        @sql NVARCHAR(MAX) = N'SELECT m.MonthNo, m.MonthName, ISNULL(adm.Admissions, 0) AS Admissions, ISNULL(tc.TCIssued, 0) AS StudentsLeft, ISNULL(adm.Admissions, 0) - ISNULL(tc.TCIssued, 0) AS NetChange FROM (SELECT 4 AS MonthNo, ''April'' AS MonthName UNION ALL SELECT 5, ''May'' UNION ALL SELECT 6, ''June'' UNION ALL SELECT 7, ''July'' UNION ALL SELECT 8, ''August'' UNION ALL SELECT 9, ''September'' UNION ALL SELECT 10, ''October'' UNION ALL SELECT 11, ''November'' UNION ALL SELECT 12, ''December'' UNION ALL SELECT 1, ''January'' UNION ALL SELECT 2, ''February'' UNION ALL SELECT 3, ''March'') m LEFT JOIN (SELECT MONTH(sm.AdmissionDate) AS MonthNo, COUNT(DISTINCT sad.StudentID) AS Admissions FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNewAdmission = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY MONTH(sm.AdmissionDate)) adm ON m.MonthNo = adm.MonthNo LEFT JOIN (SELECT MONTH(sad.TCIssuedDate) AS MonthNo, COUNT(DISTINCT sad.StudentID) AS TCIssued FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsTCIssued = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.TCIssuedDate IS NOT NULL GROUP BY MONTH(sad.TCIssuedDate)) tc ON m.MonthNo = tc.MonthNo ORDER BY CASE WHEN m.MonthNo >= 4 THEN m.MonthNo - 3 ELSE m.MonthNo + 9 END;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2526, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2527 | Give me the fee recovery percentage by class ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the fee recovery percentage by class',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, CAST(SUM(fcd.Paid_Amt) * 100.0 / NULLIF(SUM(fcd.Fees_Amount), 0) AS DECIMAL(5,2)) AS RecoveryPercent FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN ClassMaster cm ON fc.Class_ID = cm.ID WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY cm.Name, cm.DisplayOrder ORDER BY cm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2527, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2528 | How many staff are there in each department? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many staff are there in each department?',
        @sql NVARCHAR(MAX) = N'SELECT dm.Name AS Department, COUNT(sm.Staff_ID) AS StaffCount FROM StaffDepartmentMaster dm INNER JOIN StaffDepartmentMapping sdm ON dm.Id = sdm.DepartmentID INNER JOIN StaffDepartmentMappingDetail sdmd ON sdm.Id = sdmd.MappingID INNER JOIN Staff_Master sm ON sdmd.StaffID = sm.Staff_ID WHERE dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (dm.IsDeleted IS NULL OR dm.IsDeleted = 0) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1 GROUP BY dm.Name ORDER BY StaffCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2528, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2529 | Show all students with marks above 90 in any subject ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show all students with marks above 90 in any subject',
        @sql NVARCHAR(MAX) = N'SELECT pc.StudentName AS StudentName, pc.SubjectName AS SubjectName, cm.Name AS ClassName, pc.Marks FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE pc.Marks >= 90 AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) ORDER BY pc.Marks DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2529, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2530 | Staff attendance vs salary paid - monthly overview ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff attendance vs salary paid - monthly overview',
        @sql NVARCHAR(MAX) = N'SELECT gem.EmployeeID, gem.EmployeeName, gem.NetPay, ISNULL(gem.PresentDays, 0) AS PresentDays, ISNULL(gem.WorkingDays, 0) AS TotalDays FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) ORDER BY gem.NetPay DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2530, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2531 | Fees collected on the last day of previous month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Fees collected on the last day of previous month',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fc.Receipt_Amt) AS LastDayCollection, COUNT(fc.Id) AS ReceiptCount FROM FeesCollection fc WHERE CAST(fc.Bill_Date AS DATE) = CAST(EOMONTH(DATEADD(MONTH, -1, GETDATE())) AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2531, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2532 | Vehicle with the highest seating capacity. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Vehicle with the highest seating capacity.',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 Vehicle_Number, Make, Model, Seating_Capacity FROM VehicleMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) ORDER BY Seating_Capacity DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2532, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2533 | Subject-wise homework given to Class 8 this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Subject-wise homework given to Class 8 this month',
        @sql NVARCHAR(MAX) = N'SELECT sub.Name AS Subject, COUNT(*) AS AssignmentCount FROM HomeWorkAndAssignment hwa INNER JOIN ClassMaster cm ON hwa.Class_ID = cm.ID INNER JOIN Subject_Master sub ON hwa.Subject_ID = sub.Id WHERE cm.Name IN (''Class 8'', ''VIII'') AND MONTH(hwa.AssignmentDate) = MONTH(GETDATE()) AND YEAR(hwa.AssignmentDate) = YEAR(GETDATE()) AND (hwa.IsDeleted IS NULL OR hwa.IsDeleted = 0) AND hwa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hwa.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY sub.Name ORDER BY AssignmentCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2533, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2534 | Absentees today in Guindy campus ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Absentees today in Guindy campus',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS Absentees FROM StudentAttendance sa WHERE sa.Attendance_Status_ID = 2 AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%Guindy%'' OR ShortName LIKE ''%Guindy%'')) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2534, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2535 | What was the attendance trend year over year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What was the attendance trend year over year?',
        @sql NVARCHAR(MAX) = N'SELECT bad.Name AS AcademicYear, COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) AS PresentCount, COUNT(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 END) AS AbsentCount, CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AttendancePercentage FROM StudentAttendance sa JOIN Branch_Academic_Details bad ON sa.AcademicYearID = bad.Id WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bad.Name ORDER BY bad.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2535, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2536 | Pull up defaulters in Class 12 with outstanding above 20000 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up defaulters in Class 12 with outstanding above 20000',
        @sql NVARCHAR(MAX) = N'SELECT f.Student_ID, s.FirstName + '' '' + ISNULL(s.LastName, '''') AS StudentName, f.SectionName, s.FatherContactNo, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID INNER JOIN Student_Master s ON f.Student_ID = s.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.ClassName = ''Class 12'' AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Student_ID, s.FirstName, s.LastName, f.SectionName, s.FatherContactNo HAVING SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 20000 ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2536, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2537 | What was the attendance on Monday? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What was the attendance on Monday?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS present, SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END) AS absent, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS pct FROM StudentAttendance sa WHERE CAST(sa.Attendance_Date AS DATE) = CAST(DATEADD(DAY, 2 - DATEPART(WEEKDAY, GETDATE()), GETDATE()) AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2537, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2538 | List staff with pending salary payments ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List staff with pending salary payments',
        @sql NVARCHAR(MAX) = N'SELECT sm.Staff_ID AS StaffID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName FROM Staff_Master sm WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sm.IsDeleted = 0 AND sm.StaffStatus_ID = 1 AND NOT EXISTS (SELECT 1 FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gem.EmployeeID = sm.Staff_ID AND gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2538, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2539 | Show me staff attendance for this week ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me staff attendance for this week',
        @sql NVARCHAR(MAX) = N'SELECT Attendance_Date, SUM(CASE WHEN Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS Present, SUM(CASE WHEN Attendance_Status_ID = 2 THEN 1 ELSE 0 END) AS Absent FROM Staff_Attendance WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND Attendance_Date >= DATEADD(DAY, -DATEPART(WEEKDAY, GETDATE()) + 1, CAST(GETDATE() AS DATE)) AND Attendance_Date <= CAST(GETDATE() AS DATE) GROUP BY Attendance_Date ORDER BY Attendance_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2539, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2540 | Term-wise top scorer ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Term-wise top scorer',
        @sql NVARCHAR(MAX) = N'SELECT * FROM (SELECT smd.StudentID, etm.Name AS Term, SUM(smd.Marks) AS TotalMarks, ROW_NUMBER() OVER (PARTITION BY etm.Name ORDER BY SUM(smd.Marks) DESC) AS Rn FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ExamTypeMaster et ON smm.ExamTypeID = et.ID INNER JOIN ExamTermMaster etm ON et.TermID = etm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND et.IsDeleted = 0 AND etm.Deleted = 0 GROUP BY smd.StudentID, etm.Name) t WHERE Rn = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2540, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2541 | TC requests applied this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'TC requests applied this month',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, tcr.AppliedDate, tcr.TC_Status FROM TCRequest tcr INNER JOIN Student_Master sm ON tcr.StudentID = sm.ID WHERE MONTH(tcr.AppliedDate) = MONTH(GETDATE()) AND YEAR(tcr.AppliedDate) = YEAR(GETDATE()) AND tcr.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (tcr.IsDeleted IS NULL OR tcr.IsDeleted = 0) ORDER BY tcr.AppliedDate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2541, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2542 | So, what's the percentage of fee collected vs fee structure amount? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, what''s the percentage of fee collected vs fee structure amount?',
        @sql NVARCHAR(MAX) = N'WITH TotalStructure AS (SELECT SUM(fcd.Fees_Amount) AS TotalDemand FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))), TotalCollected AS (SELECT SUM(fc.Receipt_Amt) AS TotalCollection FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) SELECT tc.TotalCollection, ts.TotalDemand, CAST(tc.TotalCollection * 100.0 / NULLIF(ts.TotalDemand, 0) AS DECIMAL(5,2)) AS CollectionPercent FROM TotalCollected tc, TotalStructure ts;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2542, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2543 | Subject with lowest pass rate in the school ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Subject with lowest pass rate in the school',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 pc.SubjectName AS SubjectName, CAST(SUM(CASE WHEN pc.Marks >= pc.MinMark THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS PassRate FROM ProgressCardDataRetrieval pc WHERE pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) GROUP BY pc.SubjectName ORDER BY PassRate ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2543, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2544 | How many receipts are unprinted? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many receipts are unprinted?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS unprinted_receipts FROM FeesCollection fc WHERE (fc.IsReceiptPrinted IS NULL OR fc.IsReceiptPrinted = 0) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2544, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2545 | Can you show the class-wise and status-wise enquiry matrix? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show the class-wise and status-wise enquiry matrix?',
        @sql NVARCHAR(MAX) = N'DECLARE @StatusConverted bigint = (SELECT TOP 1 ID FROM Enquiry_Status_Master WHERE Name = ''Completed'');
DECLARE @StatusInProgress bigint = (SELECT TOP 1 ID FROM Enquiry_Status_Master WHERE Name = ''In Progress'');
DECLARE @StatusLost bigint = (SELECT TOP 1 ID FROM Enquiry_Status_Master WHERE Name = ''Dropped'');
DECLARE @StatusNew bigint = (SELECT TOP 1 ID FROM Enquiry_Status_Master WHERE Name = ''Initiated'');
WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT cm.Name AS ClassName, SUM(CASE WHEN em.CallStatus_ID = @StatusNew THEN 1 ELSE 0 END) AS New, SUM(CASE WHEN em.CallStatus_ID = @StatusInProgress THEN 1 ELSE 0 END) AS InProgress, SUM(CASE WHEN em.CallStatus_ID = @StatusConverted THEN 1 ELSE 0 END) AS Converted, SUM(CASE WHEN em.CallStatus_ID = @StatusLost THEN 1 ELSE 0 END) AS Lost FROM GeneralCallRegister em INNER JOIN ClassMaster cm ON em.Class_ID = cm.ID WHERE em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND em.IsDeleted = 0 GROUP BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2545, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2546 | How many vehicles have capacity greater than 40 seats? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many vehicles have capacity greater than 40 seats?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS LargeVehicles FROM VehicleMaster WHERE Seating_Capacity > 40 AND IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2546, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2547 | Pull up section-wise outstanding for Class 9 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up section-wise outstanding for Class 9',
        @sql NVARCHAR(MAX) = N'SELECT f.SectionID, f.SectionName, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.ClassName = ''Class 9'' AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.SectionID, f.SectionName ORDER BY f.SectionName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2547, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2548 | Total outstanding vs total collected ratio ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total outstanding vs total collected ratio',
        @sql NVARCHAR(MAX) = N'SELECT SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS TotalOutstanding, SUM(f.Paid_Amt) AS TotalCollected FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2548, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2549 | Show me staff who've been irregular this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me staff who''ve been irregular this month',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 sfm.Staff_FirstName + '' '' + ISNULL(sfm.Staff_LastName, '''') AS StaffName, COUNT(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 END) AS AbsentDays FROM Staff_Attendance sa INNER JOIN Staff_Master sfm ON sa.Staff_ID = sfm.Staff_ID AND sfm.StaffStatus_ID = 1 WHERE MONTH(sa.Attendance_Date) = MONTH(GETDATE()) AND YEAR(sa.Attendance_Date) = YEAR(GETDATE())  AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sfm.Staff_FirstName, sfm.Staff_LastName HAVING COUNT(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 END) > 2 ORDER BY AbsentDays DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2549, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2550 | List all students with their payment type and class ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all students with their payment type and class',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, sad.PaymentTypeId FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.ClassName, sm.FirstName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2550, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2551 | Show all drivers and their license expiry dates ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show all drivers and their license expiry dates',
        @sql NVARCHAR(MAX) = N'SELECT dm.Name AS DriverName, dm.License_Expiry_Date FROM DriverMaster dm WHERE (dm.IsDeleted IS NULL OR dm.IsDeleted = 0) AND dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY dm.License_Expiry_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2551, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2552 | TC turnaround time - average days from application to issue ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'TC turnaround time - average days from application to issue',
        @sql NVARCHAR(MAX) = N'SELECT CAST(AVG(DATEDIFF(DAY, tcr.AppliedDate, tcr.IssuedDate)) AS DECIMAL(5,1)) AS AvgDaysToIssue FROM TCRequest tcr WHERE tcr.TC_Status = ''Issued'' AND tcr.IssuedDate IS NOT NULL AND tcr.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND tcr.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (tcr.IsDeleted IS NULL OR tcr.IsDeleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2552, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2553 | Monthly salary bill ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Monthly salary bill',
        @sql NVARCHAR(MAX) = N'SELECT SUM(gem.NetPay) AS TotalSalaryBill FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2553, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2554 | What's our enquiry conversion rate? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s our enquiry conversion rate?',
        @sql NVARCHAR(MAX) = N'DECLARE @StatusConverted bigint = (SELECT TOP 1 ID FROM Enquiry_Status_Master WHERE Name = ''Completed'');
WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT CAST(COUNT(CASE WHEN CallStatus_ID = @StatusConverted THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS ConversionRatePercent FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2554, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2555 | Show me enquiries where email is provided. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me enquiries where email is provided.',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT CallRefNo, Student_Name, Parent_Name, CommunicationEmail, CallDate FROM GeneralCallRegister WHERE CommunicationEmail IS NOT NULL AND CommunicationEmail <> '''' AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2555, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2556 | How many students left the school in the last 6 months? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students left the school in the last 6 months?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TCIssuedCount FROM StudentAcademicDetail sad WHERE sad.IsTCIssued = 1 AND sad.TCIssuedDate >= DATEADD(MONTH, -6, GETDATE()) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2556, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2557 | Can you check - average salary of staff with perfect attendance? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you check - average salary of staff with perfect attendance?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(AVG(gem.NetPay) AS DECIMAL(12,2)) AS AvgSalary FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) AND gem.PresentDays = gem.WorkingDays;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2557, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2558 | Staff who are absent frequently and have high salary ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff who are absent frequently and have high salary',
        @sql NVARCHAR(MAX) = N'SELECT gem.EmployeeID, gem.EmployeeName, gem.NetPay, (gem.WorkingDays - gem.PresentDays) AS AbsentDays FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID INNER JOIN Branch_Academic_Details b ON gm.AcademicYearID = b.Id WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND GETDATE() BETWEEN b.Start_Date AND b.End_Date AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND (gem.WorkingDays - gem.PresentDays) > 15 AND gem.NetPay > 50000 ORDER BY (gem.WorkingDays - gem.PresentDays) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2558, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2559 | Which designation has the highest number of staff? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which designation has the highest number of staff?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 dg.Name AS Designation, COUNT(sm.Staff_ID) AS StaffCount FROM Staff_Master sm INNER JOIN StaffDesignationMaster dg ON sm.Designation_ID = dg.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1 AND (dg.IsDeleted IS NULL OR dg.IsDeleted = 0) GROUP BY dg.Name ORDER BY StaffCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2559, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2560 | What's the staff attendance rate today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the staff attendance rate today?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(CAST(SUM(CASE WHEN Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS FLOAT) * 100 / COUNT(*), 2) AS AttendancePercentage FROM Staff_Attendance WHERE Attendance_Date = CAST(GETDATE() AS DATE) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2560, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2561 | Just checking - how many homework assignments were given today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many homework assignments were given today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TodayHomework FROM HomeWorkAndAssignment WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND CAST(AssignmentDate AS DATE) = CAST(GETDATE() AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2561, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2562 | Hey, what's the total demand for primary classes (Class 1 to 5)? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the total demand for primary classes (Class 1 to 5)?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(f.Amount) AS PrimaryDemand FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.ClassName IN (''Class 1'', ''Class 2'', ''Class 3'', ''Class 4'', ''Class 5'') AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2562, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2563 | How many girls are enrolled currently? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many girls are enrolled currently?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS girls_count FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.Gender IN (''Female'', ''Girl'') AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2563, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2564 | Students without exam registration numbers ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students without exam registration numbers',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName FROM Student_Master sm JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE (sad.ExamRegistrationNo IS NULL OR sad.ExamRegistrationNo = '''') AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.ClassName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2564, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2565 | So, how many parents have we contacted? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, how many parents have we contacted?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sm.ID) AS StudentsWithContact FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND (sm.FatherContactNo IS NOT NULL AND sm.FatherContactNo != '''');',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2565, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2566 | Attendance achhi hai ya kharab? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Attendance achhi hai ya kharab?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(CASE WHEN Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS AttendancePercentage FROM Staff_Attendance WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND MONTH(Attendance_Date) = MONTH(GETDATE()) AND YEAR(Attendance_Date) = YEAR(GETDATE());',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2566, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2567 | How many students on leave today in Choolaimedu? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students on leave today in Choolaimedu?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS OnLeave FROM StudentAttendance sa WHERE sa.Attendance_Status_ID = 6 AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%Choolaimedu%'' OR ShortName LIKE ''%Choolaimedu%'')) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2567, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2568 | Show month-wise salary expenditure for this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show month-wise salary expenditure for this year',
        @sql NVARCHAR(MAX) = N'SELECT gm.MonthName, SUM(gem.NetPay) AS TotalSalary FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID INNER JOIN Branch_Academic_Details b ON gm.AcademicYearID = b.Id WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND GETDATE() BETWEEN b.Start_Date AND b.End_Date AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 GROUP BY gm.MonthName, gm.MonthID ORDER BY gm.MonthID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2568, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2569 | Hey, what's the fee collection percentage? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the fee collection percentage?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(SUM(Paid_Amt) * 100.0 / NULLIF(SUM(Amount), 0), 2) AS CollectionPercentage FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2569, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2570 | Students who were absent for 3 or more consecutive days recently ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students who were absent for 3 or more consecutive days recently',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sad.ClassName FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN StudentAttendance sa1 ON sm.ID = sa1.Student_ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa1.Attendance_Status_ID = 2 AND sa1.Attendance_Date >= DATEADD(DAY, -7, CAST(GETDATE() AS DATE)) AND EXISTS (SELECT 1 FROM StudentAttendance sa2 WHERE sa2.Student_ID = sm.ID AND sa2.Attendance_Status_ID = 2 AND sa2.Attendance_Date = DATEADD(DAY, 1, sa1.Attendance_Date)) AND EXISTS (SELECT 1 FROM StudentAttendance sa3 WHERE sa3.Student_ID = sm.ID AND sa3.Attendance_Status_ID = 2 AND sa3.Attendance_Date = DATEADD(DAY, 2, sa1.Attendance_Date));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2570, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2571 | Show students whose roll number is not assigned ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show students whose roll number is not assigned',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName FROM Student_Master sm JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE (sad.RollNo IS NULL OR sad.RollNo = '''') AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.ClassName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2571, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2572 | Show designation-wise staff count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show designation-wise staff count',
        @sql NVARCHAR(MAX) = N'SELECT dg.Name AS Designation, COUNT(sm.Staff_ID) AS StaffCount FROM Staff_Master sm INNER JOIN StaffDesignationMaster dg ON sm.Designation_ID = dg.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1 AND (dg.IsDeleted IS NULL OR dg.IsDeleted = 0) GROUP BY dg.Name ORDER BY StaffCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2572, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2573 | Show the daily average collection for this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the daily average collection for this month',
        @sql NVARCHAR(MAX) = N'SELECT CAST(AVG(DayCollection) AS DECIMAL(10,2)) AS DailyAverage FROM (SELECT CAST(fc.Bill_Date AS DATE) AS CollDate, SUM(fc.Receipt_Amt) AS DayCollection FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND MONTH(fc.Bill_Date) = MONTH(GETDATE()) AND YEAR(fc.Bill_Date) = YEAR(GETDATE()) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY CAST(fc.Bill_Date AS DATE)) AS DailyTotals;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2573, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2574 | How many staff members are there in the school? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many staff members are there in the school?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalStaff FROM Staff_Master sm WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2574, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2575 | Total fees paid by admission number 2023001 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total fees paid by admission number 2023001',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS TotalPaid FROM FeesCollection fc WHERE fc.Admission_No = ''2023001'' AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2575, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2576 | Let me see fee-type-wise outstanding breakdown ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see fee-type-wise outstanding breakdown',
        @sql NVARCHAR(MAX) = N'SELECT f.FeesType_Name, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.FeesType_Name ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2576, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2577 | What percentage of fees have been collected so far this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What percentage of fees have been collected so far this year?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(fc.Receipt_Amt) * 100.0 / NULLIF((SELECT SUM(fisd.Amount) FROM FeesInformationStudentDetail fisd WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND fisd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fisd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date)), 0) AS DECIMAL(5,2)) AS PercentCollected FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2577, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2578 | I need to see the admission funnel - from submitted to admitted ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see the admission funnel - from submitted to admitted',
        @sql NVARCHAR(MAX) = N'SELECT ''Application Submitted'' AS Stage, COUNT(*) AS [Count] FROM ApplicationEntry WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) UNION ALL SELECT ''Shortlisted'', COUNT(*) FROM ApplicationEntry ae INNER JOIN ApplicationStatus_Master asm ON ae.ApplicationStatus_ID = asm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) AND asm.Name IN (''Shortlisted'', ''Called For Interview'', ''Interview Completed'', ''Selection letter Sent'', ''Admitted'') UNION ALL SELECT ''Called For Interview'', COUNT(*) FROM ApplicationEntry ae INNER JOIN ApplicationStatus_Master asm ON ae.ApplicationStatus_ID = asm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) AND asm.Name IN (''Called For Interview'', ''Interview Completed'', ''Selection letter Sent'', ''Admitted'') UNION ALL SELECT ''Interview Completed'', COUNT(*) FROM ApplicationEntry ae INNER JOIN ApplicationStatus_Master asm ON ae.ApplicationStatus_ID = asm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) AND asm.Name IN (''Interview Completed'', ''Selection letter Sent'', ''Admitted'') UNION ALL SELECT ''Selection letter Sent'', COUNT(*) FROM ApplicationEntry ae INNER JOIN ApplicationStatus_Master asm ON ae.ApplicationStatus_ID = asm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) AND asm.Name IN (''Selection letter Sent'', ''Admitted'') UNION ALL SELECT ''Admitted'', COUNT(*) FROM ApplicationEntry ae INNER JOIN ApplicationStatus_Master asm ON ae.ApplicationStatus_ID = asm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) AND asm.Name = ''Admitted'';',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2578, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2579 | How many stops per route do we have? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many stops per route do we have?',
        @sql NVARCHAR(MAX) = N'SELECT rm.Name AS RouteName, COUNT(rmd.Id) AS NumberOfStops FROM Route_Master rm INNER JOIN Route_MasterDetails rmd ON rm.ID = rmd.Route_ID INNER JOIN BoardingPoint_Master bpm ON rmd.BoardingPoint_ID = bpm.Id WHERE rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND rm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (rm.IsDeleted = 0 OR rm.IsDeleted IS NULL) GROUP BY rm.Name ORDER BY NumberOfStops DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2579, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2580 | So, what's the total concession given term-wise? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, what''s the total concession given term-wise?',
        @sql NVARCHAR(MAX) = N'SELECT f.Term_Name, SUM(ISNULL(f.Concession_Amt, 0)) AS TotalConcession FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Term_Name ORDER BY f.Term_Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2580, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2581 | Show collection from April month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show collection from April month',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS april_collection FROM FeesCollection fc WHERE DATEPART(MONTH, fc.Bill_Date) = 4 AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2581, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2582 | I need to see the number of students with outstanding in each term ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see the number of students with outstanding in each term',
        @sql NVARCHAR(MAX) = N'SELECT f.Term_Name, COUNT(DISTINCT f.Student_ID) AS StudentsWithOutstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 0 AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Term_Name ORDER BY f.Term_Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2582, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2583 | Show month-wise concession amounts given. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show month-wise concession amounts given.',
        @sql NVARCHAR(MAX) = N'SELECT f.Month_No, f.Month_Name, SUM(ISNULL(f.Concession_Amt, 0)) AS Concession FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Month_No, f.Month_Name ORDER BY f.Month_No;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2583, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2584 | Show top 10 defaulters along with number of months they owe. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show top 10 defaulters along with number of months they owe.',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 f.Student_ID, s.FirstName + '' '' + ISNULL(s.LastName, '''') AS StudentName, f.ClassName, COUNT(DISTINCT f.Month_No) AS MonthsOwed, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID INNER JOIN Student_Master s ON f.Student_ID = s.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 0 AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Student_ID, s.FirstName, s.LastName, f.ClassName ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2584, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2585 | What is the first response time for tickets this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the first response time for tickets this month?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalTickets, SUM(CASE WHEN Status <> ''Open'' THEN 1 ELSE 0 END) AS Responded, CAST(SUM(CASE WHEN Status <> ''Open'' THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS ResponseRate FROM FeedbackTicket WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND MONTH(Created_Date) = MONTH(GETDATE()) AND YEAR(Created_Date) = YEAR(GETDATE());',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2585, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2586 | I need to see bank-wise distribution of staff ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see bank-wise distribution of staff',
        @sql NVARCHAR(MAX) = N'SELECT BankName, COUNT(*) AS StaffCount FROM EmployeeMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0 AND BankName IS NOT NULL GROUP BY BankName ORDER BY StaffCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2586, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2587 | What is the total unpaid late fee amount across all students? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total unpaid late fee amount across all students?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(lfd.Amount - ISNULL(lfc.Concession_Amount, 0)) AS TotalPending FROM FeesInformationStudentDetail FI INNER JOIN LateFeeMaster lfm ON lfm.TermId = FI.Term_ID AND lfm.IsActive = 1 AND CAST(GETDATE() AS DATE) <= lfm.ValidityDate AND CAST(GETDATE() AS DATE) >= lfm.LastDate INNER JOIN LateFeeDetails lfd ON lfm.ID = lfd.LateFeeID AND (lfd.ClassId = FI.ClassID OR lfd.ClassId = 0) AND CAST(GETDATE() AS DATE) BETWEEN lfd.FromDate AND lfd.ToDate INNER JOIN Fees_Master fmm ON fmm.ID = FI.Fees_ID AND ISNULL(fmm.IsIncludeinLateFee, 0) = 1 INNER JOIN Student_Master SM ON SM.ID = FI.Student_ID LEFT JOIN LateFee_Concession lfc ON lfc.Student_ID = FI.Student_ID AND lfc.LateFeeHeadId = lfm.LateFeeHeadId AND lfc.Term_ID = FI.Term_ID AND lfc.AcademicYearID = FI.AcademicYearID AND lfc.BranchID = FI.BranchID AND ISNULL(lfc.IsDeleted, 0) = 0 WHERE FI.IsIncludedInLumpSum <> 1 AND FI.IsDonation = 0 AND (FI.Amount - ISNULL(FI.Concession_Amt,0) - FI.Paid_Amt - FI.Lien_Amount) > 0 AND CAST(SM.AdmissionDate AS DATE) < lfd.FromDate AND (lfd.Amount - ISNULL(lfc.Concession_Amount, 0)) > 0 AND FI.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2587, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2588 | Show absent students with reason for today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show absent students with reason for today',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, cm.Name AS class_name, sa.Attendance_Reason FROM StudentAttendance sa JOIN Student_Master sm ON sa.Student_ID = sm.ID JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.Attendance_Status_ID = 2 AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2588, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2589 | Give me the class-wise transport student count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the class-wise transport student count',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(DISTINCT sad.StudentID) AS TransportStudents FROM StudentAcademicDetail sad JOIN ClassMaster cm ON sad.ClassID = cm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.TransportRequired = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name, cm.DisplayOrder ORDER BY cm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2589, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2590 | Show class-wise total concession given. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show class-wise total concession given.',
        @sql NVARCHAR(MAX) = N'SELECT f.ClassName, SUM(ISNULL(f.Concession_Amt, 0)) AS TotalConcession FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.ClassName ORDER BY TotalConcession DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2590, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2591 | What's the average outstanding per student in Class 12? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the average outstanding per student in Class 12?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) * 1.0 / NULLIF(COUNT(DISTINCT f.Student_ID), 0), 2) AS AvgOutstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.ClassName = ''Class 12'' AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2591, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2592 | Which teachers are assigned to Class 10? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which teachers are assigned to Class 10?',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT sm.Staff_FirstName + '' '' + sm.Staff_LastName AS TeacherName, sub.Name AS SubjectName FROM SubjectAllocation_Master sam INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID INNER JOIN Staff_Master sm ON sam.Staff_ID = sm.Staff_ID INNER JOIN Subject_Master sub ON sam.Subject_ID = sub.Id WHERE sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (sam.IsDeleted = 0 OR sam.IsDeleted IS NULL) AND cm.Name IN (''Class 10'', ''X'');',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2592, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2593 | Show class-wise enquiry count. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show class-wise enquiry count.',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT cm.Name AS ClassName, COUNT(*) AS EnquiryCount FROM GeneralCallRegister em INNER JOIN ClassMaster cm ON em.Class_ID = cm.ID WHERE em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND (em.IsDeleted = 0 OR em.IsDeleted IS NULL) GROUP BY cm.Name ORDER BY EnquiryCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2593, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2594 | How much donation was collected online vs offline? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much donation was collected online vs offline?',
        @sql NVARCHAR(MAX) = N'SELECT cmm.Name AS Mode, SUM(d.Receipt_Amt) AS TotalAmount, COUNT(*) AS Receipts FROM DonationFeesCollection d LEFT JOIN CollectionMode_Master cmm ON d.Collection_Mode_ID = cmm.ID WHERE d.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND d.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (d.IsDeleted = 0 OR d.IsDeleted IS NULL) AND d.ChequeStatus_ID NOT IN (3, 4) GROUP BY cmm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2594, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2595 | What's the fee collection for St Xaviers this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the fee collection for St Xaviers this month?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fc.Receipt_Amt) AS Collection FROM FeesCollection fc WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND DATEPART(MONTH, fc.Bill_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, fc.Bill_Date) = DATEPART(YEAR, GETDATE()) AND fc.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%St Xavier%'' OR ShortName LIKE ''%St Xavier%'')) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2595, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2596 | Just checking - how many students have late fees exceeding 5000 rupees? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many students have late fees exceeding 5000 rupees?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS StudentCount FROM (SELECT FI.Student_ID, SUM(lfd.Amount - ISNULL(lfc.Concession_Amount, 0)) AS NetPayable FROM FeesInformationStudentDetail FI INNER JOIN LateFeeMaster lfm ON lfm.TermId = FI.Term_ID AND lfm.IsActive = 1 AND CAST(GETDATE() AS DATE) <= lfm.ValidityDate AND CAST(GETDATE() AS DATE) >= lfm.LastDate INNER JOIN LateFeeDetails lfd ON lfm.ID = lfd.LateFeeID AND (lfd.ClassId = FI.ClassID OR lfd.ClassId = 0) AND CAST(GETDATE() AS DATE) BETWEEN lfd.FromDate AND lfd.ToDate INNER JOIN Fees_Master fmm ON fmm.ID = FI.Fees_ID AND ISNULL(fmm.IsIncludeinLateFee, 0) = 1 INNER JOIN Student_Master SM ON SM.ID = FI.Student_ID LEFT JOIN LateFee_Concession lfc ON lfc.Student_ID = FI.Student_ID AND lfc.LateFeeHeadId = lfm.LateFeeHeadId AND lfc.Term_ID = FI.Term_ID AND lfc.AcademicYearID = FI.AcademicYearID AND lfc.BranchID = FI.BranchID AND ISNULL(lfc.IsDeleted, 0) = 0 WHERE FI.IsIncludedInLumpSum <> 1 AND FI.IsDonation = 0 AND (FI.Amount - ISNULL(FI.Concession_Amt,0) - FI.Paid_Amt - FI.Lien_Amount) > 0 AND CAST(SM.AdmissionDate AS DATE) < lfd.FromDate AND (lfd.Amount - ISNULL(lfc.Concession_Amount, 0)) > 0 AND FI.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY FI.Student_ID HAVING SUM(lfd.Amount - ISNULL(lfc.Concession_Amount, 0)) > 5000) t;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2596, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2597 | What percentage of students are staff children? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What percentage of students are staff children?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(COUNT(CASE WHEN sm.StaffChild = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS StaffChildPercent FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2597, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2598 | How many staff arrived late today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many staff arrived late today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS LateArrivals FROM Staff_Attendance WHERE Attendance_Date = CAST(GETDATE() AS DATE) AND InTime > ''09:00'' AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2598, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2599 | Can you show class-wise tuition fee outstanding? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show class-wise tuition fee outstanding?',
        @sql NVARCHAR(MAX) = N'SELECT f.ClassName, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS TuitionOutstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.Fees_Name LIKE ''%Tuition%'' AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.ClassName ORDER BY f.ClassName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2599, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2600 | Give me the big picture on fees ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the big picture on fees',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fcd.Fees_Amount) AS TotalDemand, SUM(fcd.Paid_Amt) AS TotalCollected, SUM(fcd.Remaining_Amt) AS TotalOutstanding, SUM(fcd.Concession_Amount) AS TotalConcession FROM FeesCollection_Details fcd WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
PRINT 'checkpoint: reached Q2600';
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2600, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2601 | Which day had the lowest attendance this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which day had the lowest attendance this month?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 Attendance_Date, SUM(CASE WHEN Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS PresentCount FROM Staff_Attendance WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND MONTH(Attendance_Date) = MONTH(GETDATE()) AND YEAR(Attendance_Date) = YEAR(GETDATE()) GROUP BY Attendance_Date ORDER BY PresentCount ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2601, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2602 | Hey, how many enquiries have no phone number? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many enquiries have no phone number?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS NoPhoneEnquiries FROM GeneralCallRegister WHERE (MobileNo1 IS NULL OR MobileNo1 = '''') AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2602, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2603 | What's the average staff salary? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the average staff salary?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(AVG(gem.NetPay), 2) AS AvgSalary FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2603, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2604 | Hey, how many people work at our school? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many people work at our school?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalStaff FROM Staff_Master sm WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2604, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2605 | Staff not on hold ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff not on hold',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS ActiveStaff FROM EmployeeMaster WHERE (IsHold = 0 OR IsHold IS NULL) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2605, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2606 | Staff present today count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff present today count',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS PresentToday FROM Staff_Attendance WHERE Attendance_Date = CAST(GETDATE() AS DATE) AND Attendance_Status_ID = 1 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2606, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2607 | Compare today's collection across all branches ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare today''s collection across all branches',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, SUM(fc.Receipt_Amt) AS Collection FROM FeesCollection fc JOIN BranchMaster bm ON fc.BranchID = bm.ID WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY Collection DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2607, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2608 | Staff with pending salary ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff with pending salary',
        @sql NVARCHAR(MAX) = N'SELECT sm.Staff_ID AS StaffID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName FROM Staff_Master sm WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sm.IsDeleted = 0 AND sm.StaffStatus_ID = 1 AND NOT EXISTS (SELECT 1 FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gem.EmployeeID = sm.Staff_ID AND gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2608, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2609 | How many enquiries came in April 2026 for Class 5? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many enquiries came in April 2026 for Class 5?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS EnquiryCount FROM GeneralCallRegister em INNER JOIN ClassMaster cm ON em.Class_ID = cm.ID WHERE cm.Name IN (''Class 5'', ''V'') AND MONTH(em.CallDate) = 4 AND YEAR(em.CallDate) = 2026 AND em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND em.IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2609, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2610 | How many students got admission in April this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students got admission in April this year?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS AprilAdmissions FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNewAdmission = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND MONTH(sm.AdmissionDate) = 4 AND YEAR(sm.AdmissionDate) = 2025 AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2610, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2611 | Pull up the most recent 10 refunds issued real quick ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up the most recent 10 refunds issued real quick',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 r.Bill_Date AS RefundDate, sm.FirstName + '' '' + sm.LastName AS StudentName, r.Refund_Amt AS Amount, r.RequestRemarks AS Reason FROM RefundReceipt r INNER JOIN Student_Master sm ON r.Student_ID = sm.ID WHERE r.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND r.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY r.Bill_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2611, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2612 | So what's the deal with Class 10 fees? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So what''s the deal with Class 10 fees?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fcd.Fees_Amount) AS TotalDemand, SUM(fcd.Paid_Amt) AS TotalPaid, SUM(fcd.Remaining_Amt) AS TotalOutstanding, SUM(fcd.Concession_Amount) AS TotalConcession FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN FeesCollection fc2 ON fcd.Fees_Collection_ID = fc2.Id INNER JOIN StudentAcademicDetail sad2 ON fc2.Student_ID = sad2.StudentID AND sad2.IsActive = 1 INNER JOIN ClassMaster cm ON sad2.ClassID = cm.ID WHERE cm.Name IN (''Class 10'', ''X'') AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2612, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2613 | Subject toppers for Class 10 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Subject toppers for Class 10',
        @sql NVARCHAR(MAX) = N'SELECT * FROM (SELECT smd.StudentID, s.Name AS Subject, smd.Marks, ROW_NUMBER() OVER (PARTITION BY s.Name ORDER BY smd.Marks DESC) AS Rn FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ClassMaster c ON smm.ClassID = c.ID INNER JOIN Subject_Master s ON s.BranchID = smd.BranchID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND c.Name = ''Class 10'' AND s.IsDeleted = 0) t WHERE Rn = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2613, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2614 | Students who were absent more than 10 days and have fees outstanding over 30000 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students who were absent more than 10 days and have fees outstanding over 30000',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT f.Student_ID, sm.FirstName + '' '' + sm.LastName AS StudentName FROM FeesInformationStudentDetail f INNER JOIN Student_Master sm ON f.Student_ID = sm.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 30000 AND f.Student_ID IN (SELECT sa.Student_ID FROM StudentAttendance sa WHERE sa.Attendance_Status_ID = 2 GROUP BY sa.Student_ID HAVING COUNT(*) > 10);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2614, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2615 | Show me enquiries received in the last 30 days grouped by status. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me enquiries received in the last 30 days grouped by status.',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT esm.Name AS Status, COUNT(*) AS EnquiryCount FROM GeneralCallRegister em INNER JOIN Enquiry_Status_Master esm ON em.CallStatus_ID = esm.ID WHERE em.CallDate >= DATEADD(DAY, -30, GETDATE()) AND em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND em.IsDeleted = 0 GROUP BY esm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2615, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2616 | Students whose admission date is not recorded ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students whose admission date is not recorded',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sm.AdmissionDate IS NULL;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2616, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2617 | Staff on salary hold with names ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff on salary hold with names',
        @sql NVARCHAR(MAX) = N'SELECT em.StaffID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName, em.BankName, em.BankAccountNo FROM EmployeeMaster em INNER JOIN Staff_Master sm ON em.StaffID = sm.Staff_ID WHERE em.IsHold = 1 AND em.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND em.IsDeleted = 0 AND sm.IsDeleted = 0 AND sm.StaffStatus_ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2617, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2618 | Who are the top 10 fee defaulters? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who are the top 10 fee defaulters?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, sm.AdmissionNo, cm.Name AS class_name, SUM(fcd.Remaining_Amt) AS outstanding_amount FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Student_Master sm ON fc.Student_ID = sm.ID JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID AND fc.AcademicYearID = sad.AcademicYearID JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fcd.Remaining_Amt > 0 AND sad.IsActive = 1 GROUP BY sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo, cm.Name ORDER BY SUM(fcd.Remaining_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2618, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2619 | Gimme the total outstanding for this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Gimme the total outstanding for this year',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM((fisd.Amount - ISNULL(fisd.Concession_Amt, 0) - ISNULL(fisd.Paid_Amt, 0))), 0) AS TotalOutstanding FROM FeesInformationStudentDetail fisd WHERE (fisd.Amount - ISNULL(fisd.Concession_Amt, 0) - ISNULL(fisd.Paid_Amt, 0)) > 0 AND fisd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fisd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2619, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2620 | How many tickets were raised this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many tickets were raised this month?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS ThisMonthTickets FROM FeedbackTicket WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND MONTH(Created_Date) = MONTH(GETDATE()) AND YEAR(Created_Date) = YEAR(GETDATE());',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2620, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2621 | Staff with maximum deductions this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff with maximum deductions this month',
        @sql NVARCHAR(MAX) = N'SELECT TOP 5 gem.EmployeeID, gem.EmployeeName, (gem.GrossAmount - gem.NetPay) AS TotalDeduction FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) ORDER BY (gem.GrossAmount - gem.NetPay) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2621, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2622 | What is the class-wise count of transport students? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the class-wise count of transport students?',
        @sql NVARCHAR(MAX) = N'SELECT sad.ClassName, COUNT(*) AS TransportStudents FROM StudentAcademicDetail sad WHERE sad.TransportRequired = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND sad.IsTCIssued = 0 GROUP BY sad.ClassName ORDER BY TransportStudents DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2622, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2623 | Late comers today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Late comers today?',
        @sql NVARCHAR(MAX) = N'SELECT sa.Staff_ID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName, sa.InTime FROM Staff_Attendance sa INNER JOIN Staff_Master sm ON sa.Staff_ID = sm.Staff_ID AND sm.StaffStatus_ID = 1 WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.Attendance_Date = CAST(GETDATE() AS DATE) AND InTime > ''09:00:00'' AND InTime IS NOT NULL ORDER BY InTime DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2623, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2624 | How many tickets were resolved this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many tickets were resolved this month?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS ResolvedThisMonth FROM FeedbackTicket ft OUTER APPLY (SELECT MAX(ftr.RepliedOn) AS LastReplyDate FROM FeedbackTicketReplies ftr WHERE ftr.TicketID = ft.Id) rp WHERE ft.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ft.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND ft.Status = ''Closed'' AND MONTH(rp.LastReplyDate) = MONTH(GETDATE()) AND YEAR(rp.LastReplyDate) = YEAR(GETDATE());',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2624, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2625 | Total number of active students ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total number of active students',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS TotalStudents FROM StudentAcademicDetail sad INNER JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2625, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2626 | List all students availing bus facility ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all students availing bus facility',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, sm.FatherContactNo FROM Student_Master sm JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.TransportRequired = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.ClassName, sm.FirstName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2626, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2627 | Show admission type wise student count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show admission type wise student count',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionTypeName, COUNT(*) AS student_count FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY sm.AdmissionTypeName ORDER BY COUNT(*) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2627, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2628 | What are the different late fee rule amounts configured? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What are the different late fee rule amounts configured?',
        @sql NVARCHAR(MAX) = N'SELECT lfm.Name AS LateFeeName, lfd.FromDay, lfd.ToDay, lfd.Amount FROM LateFeeDetails lfd INNER JOIN LateFeeMaster lfm ON lfd.LateFeeID = lfm.ID WHERE lfm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lfm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (lfm.IsDeleted = 0 OR lfm.IsDeleted IS NULL) ORDER BY lfd.FromDay;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2628, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2629 | Percentage of students scoring above 90 in the school ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Percentage of students scoring above 90 in the school',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(CASE WHEN pc.Marks / pc.MaxMarks * 100 >= 90 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS Above90Percentage FROM ProgressCardDataRetrieval pc WHERE pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2629, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2630 | What is the section-wise student strength for Class 5? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the section-wise student strength for Class 5?',
        @sql NVARCHAR(MAX) = N'SELECT secm.Name AS SectionName, COUNT(DISTINCT sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad JOIN ClassMaster cm ON sad.ClassID = cm.ID INNER JOIN SectionMaster secm ON sad.SectionID = secm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE cm.Name IN (''Class 5'', ''V'') AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY secm.Name ORDER BY secm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2630, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2631 | Show all homework assigned this week. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show all homework assigned this week.',
        @sql NVARCHAR(MAX) = N'SELECT h.Remarks AS Title, cm.Name AS ClassName, sub.Name AS SubjectName, h.AssignmentDate AS AssignedDate, h.SubmissionDate AS DueDate FROM HomeWorkAndAssignment h INNER JOIN ClassMaster cm ON h.Class_ID = cm.ID INNER JOIN Subject_Master sub ON h.Subject_ID = sub.Id WHERE h.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND h.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (h.IsDeleted = 0 OR h.IsDeleted IS NULL) AND h.AssignmentDate >= DATEADD(DAY, -7, GETDATE()) ORDER BY h.AssignmentDate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2631, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2632 | Give me the students with no community information ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the students with no community information',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.Community_Name IS NULL OR sm.Community_Name = '''');',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2632, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2633 | How many TC requests are still open (not yet completed)? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many TC requests are still open (not yet completed)?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS OpenTCRequests FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.IsActive = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2633, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2634 | Show circulars created in the last 7 days. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show circulars created in the last 7 days.',
        @sql NVARCHAR(MAX) = N'SELECT Title, Description, Circular_Date, CircularApplicableFor AS TargetAudience, Created_Date AS CreatedDate FROM CircularEntry WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND Created_Date >= DATEADD(DAY, -7, GETDATE()) ORDER BY Created_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2634, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2635 | Just curious, are any cheques bounced this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just curious, are any cheques bounced this month?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS BouncedCheques, ISNULL(SUM(fc.Receipt_Amt), 0) AS BouncedAmount FROM FeesCollection fc WHERE fc.ChequeStatus_ID = 3 AND MONTH(fc.Bill_Date) = MONTH(GETDATE()) AND YEAR(fc.Bill_Date) = YEAR(GETDATE()) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2635, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2636 | Tell me about the branch-wise late arrivals today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Tell me about the branch-wise late arrivals today',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, COUNT(*) AS Late FROM StudentAttendance sa JOIN BranchMaster bm ON sa.BranchID = bm.ID WHERE sa.Attendance_Status_ID = 4 AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY Late DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2636, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2637 | I need to see the monthly fee collection summary ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see the monthly fee collection summary',
        @sql NVARCHAR(MAX) = N'SELECT MONTH(fc.Bill_Date) AS MonthNo, DATENAME(MONTH, fc.Bill_Date) AS MonthName, SUM(fc.Receipt_Amt) AS Collected FROM FeesCollection fc WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY MONTH(fc.Bill_Date), DATENAME(MONTH, fc.Bill_Date) ORDER BY MonthNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2637, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2638 | How many kids take the bus? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many kids take the bus?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS TransportStudents FROM StudentAcademicDetail sad INNER JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.TransportRequired = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2638, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2639 | What is the average class size? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the average class size?',
        @sql NVARCHAR(MAX) = N'SELECT AVG(ClassCount) AS AvgClassSize FROM (SELECT cm.Name, COUNT(DISTINCT sad.StudentID) AS ClassCount FROM StudentAcademicDetail sad JOIN ClassMaster cm ON sad.ClassID = cm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name) AS ClassCounts;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2639, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2640 | How many applications were received per week this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many applications were received per week this month?',
        @sql NVARCHAR(MAX) = N'SELECT DATEPART(WEEK, ApplicationDate) - DATEPART(WEEK, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)) + 1 AS WeekOfMonth, COUNT(*) AS Applications FROM ApplicationEntry WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND MONTH(ApplicationDate) = MONTH(GETDATE()) AND YEAR(ApplicationDate) = YEAR(GETDATE()) AND (IsDeleted = 0 OR IsDeleted IS NULL) GROUP BY DATEPART(WEEK, ApplicationDate) - DATEPART(WEEK, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)) + 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2640, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2641 | Enquiries without email addresses. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Enquiries without email addresses.',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT CallRefNo, Parent_Name, Student_Name, MobileNo1, CallDate FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND (CommunicationEmail IS NULL OR CommunicationEmail = '''');',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2641, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2642 | Attendance today in the Tambaram branch ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Attendance today in the Tambaram branch',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS Present, SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END) AS Absent FROM StudentAttendance sa WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%Tambaram%'' OR ShortName LIKE ''%Tambaram%'')) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2642, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2643 | List circulars requiring a response that haven't been responded to ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List circulars requiring a response that haven''t been responded to',
        @sql NVARCHAR(MAX) = N'SELECT ce.Title, ce.Description, ce.Circular_Date, ce.CircularApplicableFor AS TargetAudience FROM CircularEntry ce WHERE ce.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ce.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ce.IsDeleted = 0 OR ce.IsDeleted IS NULL) AND ce.IsResponseNeeded = 1 ORDER BY ce.Created_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2643, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2644 | What is the total student strength across the school? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total student strength across the school?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalStudents FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID=sm.ID WHERE sad.IsActive=1 AND (sad.IsTCIssued=0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2644, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2645 | What's the count for number of employees in the school? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the count for number of employees in the school?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalStaff FROM Staff_Master sm WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2645, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2646 | How many receipts were cancelled this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many receipts were cancelled this month?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS cancelled_receipts FROM FeesCollection fc WHERE fc.IsDeleted = 1 AND DATEPART(MONTH, fc.Cancellation_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, fc.Cancellation_Date) = DATEPART(YEAR, GETDATE()) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2646, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2647 | Pull up fee-type-wise recovery rate ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up fee-type-wise recovery rate',
        @sql NVARCHAR(MAX) = N'SELECT f.FeesType_Name, ROUND(SUM(f.Paid_Amt) * 100.0 / NULLIF(SUM(f.Amount - ISNULL(f.Concession_Amt, 0)), 0), 2) AS RecoveryRate FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.FeesType_Name ORDER BY RecoveryRate ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2647, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2648 | I wanna see the collection summary for today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I wanna see the collection summary for today',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS total_receipts, COUNT(DISTINCT fc.Student_ID) AS students_count, SUM(fc.Receipt_Amt) AS total_amount, cmm.Name AS mode FROM FeesCollection fc LEFT JOIN CollectionMode_Master cmm ON fc.Collection_Mode_ID = cmm.ID WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cmm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2648, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2649 | I need to see tickets raised today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see tickets raised today',
        @sql NVARCHAR(MAX) = N'SELECT ft.TicketNo, ft.Subject, ft.FeedbackText AS Description, ft.ContactName AS Parent_Name, ft.ContactNumber AS ParentPhone, esc.IsEscalated FROM FeedbackTicket ft OUTER APPLY (SELECT MAX(ftr.RepliedOn) AS LastReplyDate FROM FeedbackTicketReplies ftr WHERE ftr.TicketID = ft.Id) rp OUTER APPLY (SELECT CASE WHEN EXISTS (SELECT 1 FROM FeedbackEscalationMatrix fem WHERE fem.FeedbackCategoryID = ft.CategoryID AND DATEDIFF(HOUR, ft.Created_Date, ISNULL(rp.LastReplyDate, GETDATE())) > fem.EscalationHours) THEN 1 ELSE 0 END AS IsEscalated) esc WHERE ft.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ft.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND CAST(ft.Created_Date AS DATE) = CAST(GETDATE() AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2649, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2650 | Give me the total headcount of staff for 2025-26 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the total headcount of staff for 2025-26',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS Headcount FROM Staff_Master sm WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1 AND sm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2650, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2651 | Attendance trend for staff this week ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Attendance trend for staff this week',
        @sql NVARCHAR(MAX) = N'SELECT Attendance_Date, ROUND(CAST(SUM(CASE WHEN Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS FLOAT) * 100 / COUNT(*), 2) AS AttendancePercent FROM Staff_Attendance WHERE Attendance_Date >= DATEADD(DAY, -7, CAST(GETDATE() AS DATE)) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY Attendance_Date ORDER BY Attendance_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2651, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2652 | Show me student strength branch-wise ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me student strength branch-wise',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, COUNT(*) AS Students FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN BranchMaster bm ON sm.BranchID = bm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY Students DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2652, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2653 | List all girls in Class 10 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all girls in Class 10',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.RollNo, secm.Name FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID INNER JOIN SectionMaster secm ON sad.SectionID = secm.ID WHERE cm.Name IN (''Class 10'', ''X'') AND sm.Gender IN (''Female'', ''Girl'') AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.RollNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2653, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2654 | Hey, what's the backlog of unresolved tickets? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the backlog of unresolved tickets?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS BacklogCount, SUM(esc.IsEscalated) AS Escalated, SUM(1 - esc.IsEscalated) AS WithinSLA, AVG(DATEDIFF(DAY, ft.Created_Date, GETDATE())) AS AvgDaysOpen FROM FeedbackTicket ft OUTER APPLY (SELECT MAX(ftr.RepliedOn) AS LastReplyDate FROM FeedbackTicketReplies ftr WHERE ftr.TicketID = ft.Id) rp OUTER APPLY (SELECT CASE WHEN EXISTS (SELECT 1 FROM FeedbackEscalationMatrix fem WHERE fem.FeedbackCategoryID = ft.CategoryID AND DATEDIFF(HOUR, ft.Created_Date, ISNULL(rp.LastReplyDate, GETDATE())) > fem.EscalationHours) THEN 1 ELSE 0 END AS IsEscalated) esc WHERE ft.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ft.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND ft.Status IN (''Open'', ''In Progress'', ''Reopened'');',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2654, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2655 | Staff attendance summary for yesterday ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff attendance summary for yesterday',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) AS Present, COUNT(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 END) AS Absent, COUNT(*) AS Total FROM Staff_Attendance sa WHERE CAST(sa.Attendance_Date AS DATE) = CAST(DATEADD(DAY, -1, GETDATE()) AS DATE)  AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2655, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2656 | What's the total number of new enquiries? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the total number of new enquiries?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS NewEnquiries FROM GeneralCallRegister WHERE CallStatus_ID IN (SELECT ID FROM Enquiry_Status_Master WHERE Name = ''Initiated'') AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2656, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2657 | Let me see the route with the maximum boarding points ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see the route with the maximum boarding points',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 rm.Name AS RouteName, COUNT(rmd.Id) AS BoardingPoints FROM Route_Master rm INNER JOIN Route_MasterDetails rmd ON rm.ID = rmd.Route_ID INNER JOIN BoardingPoint_Master bpm ON rmd.BoardingPoint_ID = bpm.Id WHERE rm.IsDeleted = 0 AND rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY rm.Name ORDER BY BoardingPoints DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2657, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2658 | What is the total staff strength? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total staff strength?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalStaff FROM Staff_Master sm WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2658, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2659 | Show circulars that mention fee payment ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show circulars that mention fee payment',
        @sql NVARCHAR(MAX) = N'SELECT Title, Description, Circular_Date, CircularApplicableFor AS TargetAudience FROM CircularEntry WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND (Description LIKE ''%fee%'' OR Description LIKE ''%payment%'') ORDER BY Created_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2659, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2660 | Pull up the absentee list ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up the absentee list',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName, secm.Name FROM StudentAttendance sa INNER JOIN Student_Master sm ON sa.Student_ID = sm.ID INNER JOIN StudentAcademicDetail sad ON sa.Student_ID = sad.StudentID AND sa.Class_ID = sad.ClassID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID INNER JOIN SectionMaster secm ON sad.SectionID = secm.ID WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.Attendance_Status_ID = 2 AND sad.IsActive = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2660, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2661 | Which day had the highest collection this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which day had the highest collection this month?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 CAST(fc.Bill_Date AS DATE) AS collection_date, SUM(fc.Receipt_Amt) AS total_amount FROM FeesCollection fc WHERE DATEPART(MONTH, fc.Bill_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, fc.Bill_Date) = DATEPART(YEAR, GETDATE()) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY CAST(fc.Bill_Date AS DATE) ORDER BY SUM(fc.Receipt_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2661, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2662 | Hey, how many students are below average in Class 10? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many students are below average in Class 10?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT smd.StudentID) AS BelowAvgStudents FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ClassMaster c ON smm.ClassID = c.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND c.Name = ''Class 10'' AND smd.Marks < (SELECT AVG(smd2.Marks) FROM StudentMarkDetails smd2 INNER JOIN StudentMarkMaster smm2 ON smd2.HeaderID = smm2.ID INNER JOIN ClassMaster c2 ON smm2.ClassID = c2.ID WHERE smd2.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd2.Deleted = 0 AND smm2.Deleted = 0 AND c2.Name = ''Class 10'');',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2662, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2663 | What is the outstanding for senior secondary classes (Class 11, 12)? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the outstanding for senior secondary classes (Class 11, 12)?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS SeniorOutstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.ClassName IN (''Class 11'', ''Class 12'') AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2663, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2664 | Can I see the students scoring below 20 marks? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can I see the students scoring below 20 marks?',
        @sql NVARCHAR(MAX) = N'SELECT smd.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName, smd.Marks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN Student_Master stm ON smd.StudentID = stm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND smd.Marks < 20 ORDER BY smd.Marks ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2664, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2665 | What's the collection for St Marys branch? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the collection for St Marys branch?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fc.Receipt_Amt) AS Collection FROM FeesCollection fc WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%St Mary%'' OR ShortName LIKE ''%St Mary%'')) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2665, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2666 | Class with lowest fee recovery ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class with lowest fee recovery',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 cm.Name AS ClassName, CAST(SUM(fcd.Paid_Amt) * 100.0 / NULLIF(SUM(fcd.Fees_Amount), 0) AS DECIMAL(5,2)) AS RecoveryPercent FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN ClassMaster cm ON fc.Class_ID = cm.ID WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY cm.Name ORDER BY RecoveryPercent ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2666, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2667 | Total hostellers count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total hostellers count',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS hostel_count FROM StudentAcademicDetail sad WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.HostelRequired = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2667, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2668 | Gender split percentage ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Gender split percentage',
        @sql NVARCHAR(MAX) = N'SELECT sm.Gender, COUNT(*) AS StudentCount, CAST(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM StudentAcademicDetail WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND IsActive = 1 AND (IsTCIssued = 0 OR IsTCIssued IS NULL)) AS DECIMAL(5,2)) AS Percentage FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) GROUP BY sm.Gender;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2668, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2669 | I need the handler-wise conversion rate ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need the handler-wise conversion rate',
        @sql NVARCHAR(MAX) = N'DECLARE @StatusConverted bigint = (SELECT TOP 1 ID FROM Enquiry_Status_Master WHERE Name = ''Completed'');
WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT HandledBy_ID, COUNT(*) AS Total, COUNT(CASE WHEN CallStatus_ID = @StatusConverted THEN 1 END) AS Converted, CAST(COUNT(CASE WHEN CallStatus_ID = @StatusConverted THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS ConversionRate FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL) GROUP BY HandledBy_ID ORDER BY ConversionRate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2669, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2670 | List all staff designations ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all staff designations',
        @sql NVARCHAR(MAX) = N'SELECT Name AS Designation FROM StaffDesignationMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0 ORDER BY Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2670, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2671 | List the top 10 donors by amount ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List the top 10 donors by amount',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 sm.FirstName + '' '' + sm.LastName AS DonorName, sm.FatherName, SUM(d.Receipt_Amt) AS TotalDonated FROM DonationFeesCollection d INNER JOIN Student_Master sm ON d.Student_ID = sm.ID WHERE d.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND d.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (d.IsDeleted = 0 OR d.IsDeleted IS NULL) AND d.ChequeStatus_ID NOT IN (3, 4) GROUP BY sm.FirstName, sm.LastName, sm.FatherName ORDER BY TotalDonated DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2671, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2672 | Staff attendance today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff attendance today',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS PresentToday FROM Staff_Attendance WHERE Attendance_Date = CAST(GETDATE() AS DATE) AND Attendance_Status_ID = 1 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2672, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2673 | How many students got admitted under the regular admission process this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students got admitted under the regular admission process this year?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS RegularAdmissions FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID INNER JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sm.AdmissionTypeName LIKE ''%REGULAR%'' AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2673, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2674 | Hey, what's the total unpaid late fee amount across all students? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the total unpaid late fee amount across all students?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(lfd.Amount - ISNULL(lfc.Concession_Amount, 0)) AS TotalPending FROM FeesInformationStudentDetail FI INNER JOIN LateFeeMaster lfm ON lfm.TermId = FI.Term_ID AND lfm.IsActive = 1 AND CAST(GETDATE() AS DATE) <= lfm.ValidityDate AND CAST(GETDATE() AS DATE) >= lfm.LastDate INNER JOIN LateFeeDetails lfd ON lfm.ID = lfd.LateFeeID AND (lfd.ClassId = FI.ClassID OR lfd.ClassId = 0) AND CAST(GETDATE() AS DATE) BETWEEN lfd.FromDate AND lfd.ToDate INNER JOIN Fees_Master fmm ON fmm.ID = FI.Fees_ID AND ISNULL(fmm.IsIncludeinLateFee, 0) = 1 INNER JOIN Student_Master SM ON SM.ID = FI.Student_ID LEFT JOIN LateFee_Concession lfc ON lfc.Student_ID = FI.Student_ID AND lfc.LateFeeHeadId = lfm.LateFeeHeadId AND lfc.Term_ID = FI.Term_ID AND lfc.AcademicYearID = FI.AcademicYearID AND lfc.BranchID = FI.BranchID AND ISNULL(lfc.IsDeleted, 0) = 0 WHERE FI.IsIncludedInLumpSum <> 1 AND FI.IsDonation = 0 AND (FI.Amount - ISNULL(FI.Concession_Amt,0) - FI.Paid_Amt - FI.Lien_Amount) > 0 AND CAST(SM.AdmissionDate AS DATE) < lfd.FromDate AND (lfd.Amount - ISNULL(lfc.Concession_Amount, 0)) > 0 AND FI.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2674, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2675 | Are there any circulars expiring this week? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Are there any circulars expiring this week?',
        @sql NVARCHAR(MAX) = N'SELECT ce.Title, ce.Circular_Date, ce.Circular_Date FROM CircularEntry ce WHERE ce.Circular_Date BETWEEN CAST(GETDATE() AS DATE) AND DATEADD(DAY, 7, CAST(GETDATE() AS DATE)) AND ce.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ce.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ce.IsDeleted = 0 OR ce.IsDeleted IS NULL) ORDER BY ce.Circular_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2675, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2676 | What percentage of students use transport? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What percentage of students use transport?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(SUM(CASE WHEN TransportRequired = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0), 2) AS TransportPercentage FROM StudentAcademicDetail WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND IsActive = 1 AND IsTCIssued = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2676, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2677 | Show the earliest and latest pickup times across all routes. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the earliest and latest pickup times across all routes.',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT rmd.BoardingPoint_ID) AS TotalBoardingPoints, MIN(bpm.Amount) AS MinFee, MAX(bpm.Amount) AS MaxFee FROM Route_Master rm INNER JOIN Route_MasterDetails rmd ON rm.ID = rmd.Route_ID INNER JOIN BoardingPoint_Master bpm ON rmd.BoardingPoint_ID = bpm.Id WHERE rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND rm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (rm.IsDeleted = 0 OR rm.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2677, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2678 | How many circulars were sent this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many circulars were sent this month?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS CircularsThisMonth FROM CircularEntry WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND MONTH(Created_Date) = MONTH(GETDATE()) AND YEAR(Created_Date) = YEAR(GETDATE());',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2678, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2679 | I need to see teachers who teach more than 3 different subjects ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see teachers who teach more than 3 different subjects',
        @sql NVARCHAR(MAX) = N'SELECT sm.Staff_FirstName + '' '' + sm.Staff_LastName AS TeacherName, COUNT(DISTINCT sam.Subject_ID) AS SubjectCount FROM SubjectAllocation_Master sam INNER JOIN Staff_Master sm ON sam.Staff_ID = sm.Staff_ID WHERE sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (sam.IsDeleted = 0 OR sam.IsDeleted IS NULL) GROUP BY sm.Staff_FirstName, sm.Staff_LastName HAVING COUNT(DISTINCT sam.Subject_ID) > 3 ORDER BY SubjectCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2679, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2680 | Give me the class-wise enquiry breakdown. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the class-wise enquiry breakdown.',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT cm.Name AS ClassName, COUNT(*) AS EnquiryCount FROM GeneralCallRegister em INNER JOIN ClassMaster cm ON em.Class_ID = cm.ID WHERE em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND em.IsDeleted = 0 GROUP BY cm.Name ORDER BY EnquiryCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2680, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2681 | Are there any students with no admission number? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Are there any students with no admission number?',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sad.ClassName FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.AdmissionNo IS NULL OR sm.AdmissionNo = '''');',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2681, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2682 | What is the average attendance percentage for this academic year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the average attendance percentage for this academic year?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS yearly_avg_attendance FROM StudentAttendance sa WHERE sa.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2682, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2683 | What is the total fee demand for this academic year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total fee demand for this academic year?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(Amount) AS TotalDemand FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2683, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2684 | Staff with consecutive absences this week ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff with consecutive absences this week',
        @sql NVARCHAR(MAX) = N'SELECT sfm.Staff_FirstName + '' '' + ISNULL(sfm.Staff_LastName, '''') AS StaffName, COUNT(*) AS ConsecutiveAbsent FROM Staff_Attendance sa INNER JOIN Staff_Master sfm ON sa.Staff_ID = sfm.Staff_ID AND sfm.StaffStatus_ID = 1 WHERE sa.Attendance_Status_ID = 2 AND sa.Attendance_Date >= DATEADD(DAY, 1-DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE)) AND sa.Attendance_Date <= CAST(GETDATE() AS DATE)  AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sfm.Staff_FirstName, sfm.Staff_LastName HAVING COUNT(*) >= 2 ORDER BY ConsecutiveAbsent DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2684, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2685 | Is this month's collection better than the same month last year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Is this month''s collection better than the same month last year?',
        @sql NVARCHAR(MAX) = N'SELECT ''This Year'' AS Period, ISNULL(SUM(fc.Receipt_Amt), 0) AS Collection FROM FeesCollection fc WHERE MONTH(fc.Bill_Date) = MONTH(GETDATE()) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) UNION ALL SELECT ''Last Year'' AS Period, ISNULL(SUM(fc.Receipt_Amt), 0) AS Collection FROM FeesCollection fc WHERE MONTH(fc.Bill_Date) = MONTH(GETDATE()) AND fc.AcademicYearID IN (SELECT PreviousYearID FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2685, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2686 | Who's the class-wise absent count today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who''s the class-wise absent count today?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(DISTINCT sa.Student_ID) AS AbsentCount FROM StudentAttendance sa JOIN ClassMaster cm ON sa.Class_ID = cm.ID JOIN Branch_Academic_Details bad ON sa.AcademicYearID = bad.Id WHERE sa.Attendance_Status_ID = 2 AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name, cm.DisplayOrder ORDER BY cm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2686, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2687 | Who's the Science topper in Class 8? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who''s the Science topper in Class 8?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 pc.StudentName AS StudentName, pc.Marks FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE pc.SubjectName = ''Science'' AND cm.Name IN (''Class 8'', ''VIII'') AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) ORDER BY pc.Marks DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2687, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2688 | Which classes have more than 30% fee outstanding? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which classes have more than 30% fee outstanding?',
        @sql NVARCHAR(MAX) = N'SELECT ClassName, ROUND(SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) * 100.0 / NULLIF(SUM(Amount), 0), 2) AS OutstandingPct FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY ClassName HAVING SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) * 100.0 / NULLIF(SUM(Amount), 0) > 30 ORDER BY OutstandingPct DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2688, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2689 | Hey, how many students have guardian contact but no parent contact? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many students have guardian contact but no parent contact?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS GuardianOnlyStudents FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND (sm.FatherContactNo IS NULL OR sm.FatherContactNo = '''') AND (sm.MotherContactNo IS NULL OR sm.MotherContactNo = '''') AND sm.GuardianContactNo IS NOT NULL AND sm.GuardianContactNo != '''' AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2689, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2690 | Give me a list of subject-wise toppers for the entire school ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me a list of subject-wise toppers for the entire school',
        @sql NVARCHAR(MAX) = N'SELECT pc.SubjectName, pc.StudentName, cm.Name AS ClassName, pc.Marks FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) AND pc.Marks = (SELECT MAX(pc2.Marks) FROM ProgressCardDataRetrieval pc2 WHERE pc2.SubjectID = pc.SubjectID AND pc2.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (pc2.IsDeleted = 0 OR pc2.IsDeleted IS NULL)) ORDER BY pc.SubjectName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2690, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2691 | Which class has the least students? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which class has the least students?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 cm.Name AS class_name, COUNT(*) AS strength FROM StudentAcademicDetail sad JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY cm.Name ORDER BY COUNT(*) ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2691, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2692 | Compare this month's enquiries with last month. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare this month''s enquiries with last month.',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT MONTH(CallDate) AS MonthNo, DATENAME(MONTH, CallDate) AS MonthName, COUNT(*) AS EnquiryCount FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND CallDate >= DATEADD(MONTH, -1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)) GROUP BY MONTH(CallDate), DATENAME(MONTH, CallDate) ORDER BY MonthNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2692, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2693 | How many leave days taken by each staff do we have? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many leave days taken by each staff do we have?',
        @sql NVARCHAR(MAX) = N'SELECT lem.Staff_ID, lem.Staff_Name, SUM(lem.NoOfDays) AS LeaveDays FROM LeaveEntryMaster lem INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND ls.Name = ''Approved'' GROUP BY lem.Staff_ID, lem.Staff_Name ORDER BY LeaveDays DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2693, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2694 | Show circulars that are valid for more than 30 days. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show circulars that are valid for more than 30 days.',
        @sql NVARCHAR(MAX) = N'SELECT Title, Circular_Date, CircularApplicableFor AS TargetAudience FROM CircularEntry WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND IsResponseNeeded = 1 ORDER BY Circular_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2694, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2695 | Show me boys and girls count class-wise ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me boys and girls count class-wise',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS class_name, sm.Gender, COUNT(*) AS total FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY cm.Name, sm.Gender ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2695, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2696 | What is the total demand for optional fees? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total demand for optional fees?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(f.Amount) AS OptionalFeeDemand FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.IsOptionalFee = 1 AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2696, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2697 | Designation wise staff count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Designation wise staff count',
        @sql NVARCHAR(MAX) = N'SELECT dg.Name AS Designation, COUNT(sm.Staff_ID) AS StaffCount FROM Staff_Master sm INNER JOIN StaffDesignationMaster dg ON sm.Designation_ID = dg.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1 AND (dg.IsDeleted IS NULL OR dg.IsDeleted = 0) GROUP BY dg.Name ORDER BY StaffCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2697, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2698 | Can you show the cheapest boarding point fee across all routes? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show the cheapest boarding point fee across all routes?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 rm.Name AS RouteName, bpm.Amount AS Fee FROM Route_Master rm INNER JOIN Route_MasterDetails rmd ON rm.ID = rmd.Route_ID INNER JOIN BoardingPoint_Master bpm ON rmd.BoardingPoint_ID = bpm.Id WHERE rm.IsDeleted = 0 AND rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY bpm.Amount ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2698, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2699 | What's today's attendance? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s today''s attendance?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS present, SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END) AS absent, COUNT(*) AS total, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS attendance_pct FROM StudentAttendance sa WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2699, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2700 | Students who are in hostel but not using transport facility ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students who are in hostel but not using transport facility',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.HostelRequired = 1 AND (sad.TransportRequired = 0 OR sad.TransportRequired IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.ClassName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
PRINT 'checkpoint: reached Q2700';
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2700, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2701 | Students in Class 1 who are below 6 years old ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students in Class 1 who are below 6 years old',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.StudentDob, DATEDIFF(YEAR, sm.StudentDob, GETDATE()) AS Age FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.Name IN (''Class 1'', ''I'') AND DATEDIFF(YEAR, sm.StudentDob, GETDATE()) < 6 AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2701, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2702 | Pull up any day closure where total doesn't maTCh sum of cash, online, and cheque ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up any day closure where total doesn''t maTCh sum of cash, online, and cheque',
        @sql NVARCHAR(MAX) = N'WITH dc AS (SELECT dm.ID, dm.DayClosureDate AS ClosureDate, dm.CollectedByName AS ClosedBy_Name, SUM(dmd.CollectedAmount) AS TotalCollection, SUM(CASE WHEN cmm.Name = ''Cash'' THEN dmd.CollectedAmount ELSE 0 END) AS CashCollection, SUM(CASE WHEN cmm.Name = ''Bank Online Transfer'' THEN dmd.CollectedAmount ELSE 0 END) AS OnlineCollection, SUM(CASE WHEN cmm.Name NOT IN (''Cash'', ''Bank Online Transfer'', ''Cheque'') THEN dmd.CollectedAmount ELSE 0 END) AS OtherCollection, SUM(CASE WHEN cmm.Name = ''Cheque'' THEN dmd.CollectedAmount ELSE 0 END) AS ChequeCollection FROM DayclosureMaster dm INNER JOIN DayclosureMaster_Details dmd ON dmd.HeaderID = dm.ID LEFT JOIN CollectionMode_Master cmm ON dmd.CollectionMode_ID = cmm.ID WHERE dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (dm.IsDeleted = 0 OR dm.IsDeleted IS NULL) AND (dmd.IsDeleted = 0 OR dmd.IsDeleted IS NULL) GROUP BY dm.ID, dm.DayClosureDate, dm.CollectedByName) SELECT CAST(ClosureDate AS DATE) AS ClosureDay, TotalCollection, CashCollection + OnlineCollection + ChequeCollection AS CalculatedTotal, TotalCollection - (CashCollection + OnlineCollection + ChequeCollection) AS Discrepancy FROM dc WHERE TotalCollection != (CashCollection + OnlineCollection + ChequeCollection);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2702, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2703 | Show application status breakdown. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show application status breakdown.',
        @sql NVARCHAR(MAX) = N'SELECT asm.Name AS ApplicationStatus, COUNT(*) AS [Count] FROM ApplicationEntry ae INNER JOIN ApplicationStatus_Master asm ON ae.ApplicationStatus_ID = asm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) GROUP BY asm.Name ORDER BY asm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2703, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2704 | How many staff have salary on hold? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many staff have salary on hold?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS StaffOnHold FROM EmployeeMaster WHERE IsHold = 1 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2704, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2705 | Receipts cancelled by admin Sharma ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Receipts cancelled by admin Sharma',
        @sql NVARCHAR(MAX) = N'SELECT fc.Bill_No, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, fc.Receipt_Amt, fc.Cancellation_Date FROM FeesCollection fc INNER JOIN Student_Master sm ON fc.Student_ID = sm.ID WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.IsDeleted = 1 AND fc.Cancelled_By_Name LIKE ''%Sharma%'' ORDER BY fc.Cancellation_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2705, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2706 | Hey, what's the total distance covered by all drivers per day? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the total distance covered by all drivers per day?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(TRY_CAST(DistancePerDay AS FLOAT)) AS TotalDailyDistance FROM DriverMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2706, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2707 | So, what's the outstanding for Class 9 in the Pallavaram branch? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, what''s the outstanding for Class 9 in the Pallavaram branch?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fisd.Amount - ISNULL(fisd.Concession_Amt,0) - ISNULL(fisd.Paid_Amt,0) - ISNULL(fisd.Lien_Amount,0)) AS Outstanding FROM FeesInformationStudentDetail fisd JOIN ClassMaster cm ON fisd.ClassID = cm.ID WHERE fisd.IsIncludedInLumpSum <> 1 AND fisd.IsDonation = 0 AND cm.Name IN (''Class 9'', ''IX'') AND fisd.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%Pallavaram%'' OR ShortName LIKE ''%Pallavaram%'')) AND fisd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2707, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2708 | How much collection happened on each weekday this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much collection happened on each weekday this month?',
        @sql NVARCHAR(MAX) = N'SELECT DATENAME(WEEKDAY, fc.Bill_Date) AS DayName, SUM(fc.Receipt_Amt) AS TotalCollection, COUNT(fc.Id) AS Receipts FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND MONTH(fc.Bill_Date) = MONTH(GETDATE()) AND YEAR(fc.Bill_Date) = YEAR(GETDATE()) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY DATENAME(WEEKDAY, fc.Bill_Date), DATEPART(WEEKDAY, fc.Bill_Date) ORDER BY DATEPART(WEEKDAY, fc.Bill_Date);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2708, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2709 | Show application numbers per status per class. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show application numbers per status per class.',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, SUM(CASE WHEN asm.Name = ''Application Submitted'' THEN 1 ELSE 0 END) AS Submitted, SUM(CASE WHEN asm.Name = ''Shortlisted'' THEN 1 ELSE 0 END) AS Shortlisted, SUM(CASE WHEN asm.Name = ''Called For Interview'' THEN 1 ELSE 0 END) AS CalledForInterview, SUM(CASE WHEN asm.Name = ''Interview Completed'' THEN 1 ELSE 0 END) AS InterviewCompleted, SUM(CASE WHEN asm.Name = ''Selection letter Sent'' THEN 1 ELSE 0 END) AS SelectionLetterSent, SUM(CASE WHEN asm.Name = ''Admitted'' THEN 1 ELSE 0 END) AS Admitted, SUM(CASE WHEN asm.Name = ''Rejected'' THEN 1 ELSE 0 END) AS Rejected FROM ApplicationEntry ae INNER JOIN ClassMaster cm ON ae.Student_ClassID = cm.ID INNER JOIN ApplicationStatus_Master asm ON ae.ApplicationStatus_ID = asm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) GROUP BY cm.Name ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2709, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2710 | How many open feedback tickets are there? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many open feedback tickets are there?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS OpenTickets FROM FeedbackTicket WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND Status IN (''Open'', ''Reopened'');',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2710, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2711 | Pull up the last 10 fee receipts ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up the last 10 fee receipts',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 fc.Bill_No, fc.Bill_Date, fc.Admission_No, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, fc.Receipt_Amt, cmm.Name FROM FeesCollection fc JOIN Student_Master sm ON fc.Student_ID = sm.ID LEFT JOIN CollectionMode_Master cmm ON fc.Collection_Mode_ID = cmm.ID WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY fc.Bill_Date DESC, fc.Id DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2711, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2712 | List all students who joined recently ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all students who joined recently',
        @sql NVARCHAR(MAX) = N'SELECT TOP 50 ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sm.AdmissionDate, sad.ClassName FROM Student_Master sm JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNewAdmission = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sm.AdmissionDate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2712, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2713 | Show term-wise collection percentage. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show term-wise collection percentage.',
        @sql NVARCHAR(MAX) = N'SELECT f.Term_Name, ROUND(SUM(f.Paid_Amt) * 100.0 / NULLIF(SUM(f.Amount), 0), 2) AS CollectionPercent FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Term_Name ORDER BY f.Term_Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2713, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2714 | Show house-wise student distribution ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show house-wise student distribution',
        @sql NVARCHAR(MAX) = N'SELECT sad.HouseName, COUNT(DISTINCT sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.HouseName IS NOT NULL AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sad.HouseName ORDER BY StudentCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2714, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2715 | Which source brought the least number of enquiries? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which source brought the least number of enquiries?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT TOP 1 emm.Name AS Source, COUNT(*) AS EnquiryCount FROM GeneralCallRegister em INNER JOIN Enquiry_Mode_Master emm ON em.Mode_ID = emm.ID WHERE em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND em.IsDeleted = 0 GROUP BY emm.Name ORDER BY EnquiryCount ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2715, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2716 | Students who have never attended school this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students who have never attended school this year',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sad.ClassName, sm.AdmissionNo FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND NOT EXISTS (SELECT 1 FROM StudentAttendance sa WHERE sa.Student_ID = sm.ID AND sa.Attendance_Status_ID = 1 AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.AcademicYearID = sad.AcademicYearID);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2716, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2717 | Term 1 vs Term 2 class-wise comparison ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Term 1 vs Term 2 class-wise comparison',
        @sql NVARCHAR(MAX) = N'SELECT c.Name AS ClassName, MAX(CASE WHEN etm.Name = ''Term 1'' THEN AvgM END) AS Term1Avg, MAX(CASE WHEN etm.Name = ''Term 2'' THEN AvgM END) AS Term2Avg FROM (SELECT smm.ClassID, et.TermID, CAST(AVG(smd.Marks) AS DECIMAL(5,2)) AS AvgM FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ExamTypeMaster et ON smm.ExamTypeID = et.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 GROUP BY smm.ClassID, et.TermID) sub INNER JOIN ClassMaster c ON sub.ClassID = c.ID INNER JOIN ExamTermMaster etm ON sub.TermID = etm.ID WHERE c.IsDeleted = 0 AND etm.Deleted = 0 GROUP BY c.Name ORDER BY c.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2717, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2718 | What is the refund to collection ratio? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the refund to collection ratio?',
        @sql NVARCHAR(MAX) = N'SELECT (SELECT ISNULL(SUM(Refund_Amt), 0) FROM RefundReceipt WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)))) AS TotalRefunds, (SELECT ISNULL(SUM(Receipt_Amt), 0) FROM FeesCollection WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND ChequeStatus_ID NOT IN (3, 4)) AS TotalCollections;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2718, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2719 | What is the leave approval rate? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the leave approval rate?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(CASE WHEN ls.Name = ''Approved'' THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS ApprovalRate FROM LeaveEntryMaster lem INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2719, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2720 | How many applications were received this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many applications were received this month?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS ThisMonthApplications FROM ApplicationEntry WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND MONTH(ApplicationDate) = MONTH(GETDATE()) AND YEAR(ApplicationDate) = YEAR(GETDATE()) AND (IsDeleted = 0 OR IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2720, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2721 | Can you list out new students with their parent contact numbers? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you list out new students with their parent contact numbers?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, sm.FatherName, sm.FatherContactNo, sm.MotherName, sm.MotherContactNo FROM Student_Master sm JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNewAdmission = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sm.AdmissionDate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2721, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2722 | Compare total late fee collected across academic years ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare total late fee collected across academic years',
        @sql NVARCHAR(MAX) = N'SELECT bad.Name AS AcademicYear, SUM(fcd.LateFeeAmount) AS TotalLateFee FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bad.Name ORDER BY bad.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2722, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2723 | Show staff in-time today who arrived late ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show staff in-time today who arrived late',
        @sql NVARCHAR(MAX) = N'SELECT sfm.Staff_FirstName + '' '' + ISNULL(sfm.Staff_LastName, '''') AS StaffName, sa.InTime FROM Staff_Attendance sa INNER JOIN Staff_Master sfm ON sa.Staff_ID = sfm.Staff_ID AND sfm.StaffStatus_ID = 1 WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.InTime > ''09:00:00'' AND sa.Attendance_Status_ID = 1  AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sa.InTime DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2723, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2724 | What is the dropout rate for this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the dropout rate for this year?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT CASE WHEN sad.IsTCIssued = 1 THEN sad.StudentID END) AS Dropouts, COUNT(DISTINCT sad.StudentID) AS TotalStudents, CAST(COUNT(DISTINCT CASE WHEN sad.IsTCIssued = 1 THEN sad.StudentID END) * 100.0 / NULLIF(COUNT(DISTINCT sad.StudentID), 0) AS DECIMAL(5,2)) AS DropoutRate FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2724, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2725 | Pull up month-wise bus fee outstanding ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up month-wise bus fee outstanding',
        @sql NVARCHAR(MAX) = N'SELECT f.Month_No, f.Month_Name, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS BusFeeOutstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.IsBusFee = 1 AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Month_No, f.Month_Name ORDER BY f.Month_No;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2725, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2726 | Staff attendance rate by staff type this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff attendance rate by staff type this month',
        @sql NVARCHAR(MAX) = N'SELECT StaffType_ID, CAST(SUM(CASE WHEN Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS AttendanceRate FROM Staff_Attendance WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND MONTH(Attendance_Date) = MONTH(GETDATE()) AND YEAR(Attendance_Date) = YEAR(GETDATE()) GROUP BY StaffType_ID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2726, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2727 | Show fee-name-wise demand and collection. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show fee-name-wise demand and collection.',
        @sql NVARCHAR(MAX) = N'SELECT f.Fees_Name, SUM(f.Amount) AS Demand, SUM(f.Paid_Amt) AS Collected, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Fees_Name ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2727, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2728 | Show high priority tickets that are still open. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show high priority tickets that are still open.',
        @sql NVARCHAR(MAX) = N'SELECT ft.TicketNo, ft.Subject, ft.FeedbackText AS Description, ft.ContactName AS Parent_Name, ft.ContactNumber AS ParentPhone, ft.Created_Date AS CreatedDate, DATEDIFF(DAY, ft.Created_Date, GETDATE()) AS DaysOpen FROM FeedbackTicket ft OUTER APPLY (SELECT MAX(ftr.RepliedOn) AS LastReplyDate FROM FeedbackTicketReplies ftr WHERE ftr.TicketID = ft.Id) rp OUTER APPLY (SELECT CASE WHEN EXISTS (SELECT 1 FROM FeedbackEscalationMatrix fem WHERE fem.FeedbackCategoryID = ft.CategoryID AND DATEDIFF(HOUR, ft.Created_Date, ISNULL(rp.LastReplyDate, GETDATE())) > fem.EscalationHours) THEN 1 ELSE 0 END AS IsEscalated) esc WHERE ft.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ft.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND ft.Status IN (''Open'', ''Reopened'') AND esc.IsEscalated = 1 ORDER BY ft.Created_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2728, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2729 | Students whose outstanding is more than their total paid amount ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students whose outstanding is more than their total paid amount',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName + '' '' + sm.LastName AS StudentName, SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS Outstanding, SUM(f.Paid_Amt) AS TotalPaid FROM FeesInformationStudentDetail f INNER JOIN Student_Master sm ON f.Student_ID = sm.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.FirstName, sm.LastName HAVING SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) > SUM(f.Paid_Amt);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2729, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2730 | I need the most recent 10 circulars ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need the most recent 10 circulars',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 ce.Title, ce.Description, ce.Circular_Date, ce.CircularApplicableFor AS TargetAudience, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS CreatedBy_Name, ce.Created_Date AS CreatedDate FROM CircularEntry ce LEFT JOIN Staff_Master sm ON ce.Created_By = sm.Staff_ID WHERE ce.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ce.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ce.IsDeleted = 0 OR ce.IsDeleted IS NULL) ORDER BY ce.Created_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2730, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2731 | What is the total amount collected against the fee demand this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total amount collected against the fee demand this year?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(f.Paid_Amt) AS TotalCollected FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2731, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2732 | Give me a list of all Class teachers across the school ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me a list of all Class teachers across the school',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, secm.Name AS SectionName, sm.Staff_FirstName + '' '' + ISNULL(sm.Staff_LastName, '''') AS ClassTeacher FROM SubjectAllocation_Master sam INNER JOIN Staff_Master sm ON sam.Staff_ID = sm.Staff_ID INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID INNER JOIN SectionMaster secm ON sam.Section_ID = secm.ID WHERE sam.IsClassTeacher = 1 AND sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY cm.Name, secm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2732, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2733 | Pull up students with concession who still have outstanding ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up students with concession who still have outstanding',
        @sql NVARCHAR(MAX) = N'SELECT f.Student_ID, s.FirstName + '' '' + ISNULL(s.LastName, '''') AS StudentName, f.ClassName, SUM(ISNULL(f.Concession_Amt, 0)) AS Concession, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID INNER JOIN Student_Master s ON f.Student_ID = s.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Student_ID, s.FirstName, s.LastName, f.ClassName HAVING SUM(ISNULL(f.Concession_Amt, 0)) > 0 AND SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 0 ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2733, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2734 | How much GST collected from Class 11? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much GST collected from Class 11?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fcd.GSTAmount) AS GSTCollected FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN ClassMaster cm ON fc.Class_ID = cm.ID WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.Name IN (''Class 11'', ''XI'') AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2734, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2735 | I need the average distance per day per driver ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need the average distance per day per driver',
        @sql NVARCHAR(MAX) = N'SELECT AVG(TRY_CAST(DistancePerDay AS FLOAT)) AS AvgDistancePerDay FROM DriverMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2735, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2736 | How many unique teachers are mapped to classes? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many unique teachers are mapped to classes?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT Staff_ID) AS UniqueTeachers FROM SubjectAllocation_Master sam WHERE sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (sam.IsDeleted = 0 OR sam.IsDeleted IS NULL) AND sam.Staff_ID IS NOT NULL;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2736, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2737 | Show enquiry details for a specific parent name. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show enquiry details for a specific parent name.',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT CallRefNo, Parent_Name, Student_Name, MobileNo1, CommunicationEmail, CallDate, (SELECT Name FROM Enquiry_Status_Master WHERE ID = CallStatus_ID) AS Status FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND Parent_Name LIKE ''%Sharma%'';',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2737, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2738 | Students with concession greater than 5000 who are also in hostel ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students with concession greater than 5000 who are also in hostel',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, SUM(fcd.Concession_Amount) AS TotalConcession FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN FeesCollection fc ON sm.ID = fc.Student_ID INNER JOIN FeesCollection_Details fcd ON fc.Id = fcd.Fees_Collection_ID WHERE sad.HostelRequired = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.ID, sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo, sad.ClassName HAVING SUM(fcd.Concession_Amount) > 5000 ORDER BY TotalConcession DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2738, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2739 | Hey, what's the average transport fee across all boarding points? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the average transport fee across all boarding points?',
        @sql NVARCHAR(MAX) = N'SELECT AVG(Amount) AS AvgTransportFee FROM BoardingPoint_Master WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (IsDeleted IS NULL OR IsDeleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2739, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2740 | Staff type wise attendance today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff type wise attendance today',
        @sql NVARCHAR(MAX) = N'SELECT CASE WHEN stcm.Name = ''Academic'' THEN ''Teaching'' ELSE ''Non-Teaching'' END AS StaffType, COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) AS Present, COUNT(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 END) AS Absent FROM Staff_Attendance sa INNER JOIN Staff_Master sm ON sa.Staff_ID = sm.Staff_ID AND sm.StaffStatus_ID = 1 INNER JOIN StaffType_Master stm ON sm.StaffType_ID = stm.ID INNER JOIN StaffTypeCategoryMaster stcm ON stm.Type_Id = stcm.Id WHERE sa.Attendance_Date = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY CASE WHEN stcm.Name = ''Academic'' THEN ''Teaching'' ELSE ''Non-Teaching'' END;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2740, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2741 | Which fee type has the lowest collection rate? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which fee type has the lowest collection rate?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 FeesType_Name, ROUND(SUM(Paid_Amt) * 100.0 / NULLIF(SUM(Amount), 0), 2) AS CollectionRate FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY FeesType_Name ORDER BY CollectionRate ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2741, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2742 | Show outstanding amount for each fee head ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show outstanding amount for each fee head',
        @sql NVARCHAR(MAX) = N'SELECT f.Fees_Name, SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS Outstanding FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY f.Fees_Name ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2742, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2743 | Drivers whose license is expiring in the next 30 days ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Drivers whose license is expiring in the next 30 days',
        @sql NVARCHAR(MAX) = N'SELECT dm.Name AS DriverName, dm.License_Expiry_Date FROM DriverMaster dm WHERE dm.License_Expiry_Date BETWEEN GETDATE() AND DATEADD(DAY, 30, GETDATE()) AND (dm.IsDeleted IS NULL OR dm.IsDeleted = 0) AND dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY dm.License_Expiry_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2743, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2744 | What's the average receipt amount in the Kelambakkam campus this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the average receipt amount in the Kelambakkam campus this year?',
        @sql NVARCHAR(MAX) = N'SELECT AVG(fc.Receipt_Amt) AS AvgReceipt FROM FeesCollection fc WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%Kelambakkam%'' OR ShortName LIKE ''%Kelambakkam%'')) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2744, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2745 | Show subjects available in Class 12. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show subjects available in Class 12.',
        @sql NVARCHAR(MAX) = N'SELECT sub.Name AS SubjectName, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS TeacherName FROM ClassSubjectDetails cs INNER JOIN ClassMaster cm ON cs.Class_Id = cm.ID INNER JOIN Subject_Master sub ON cs.Subject_Id = sub.Id LEFT JOIN SubjectAllocation_Master sam ON sam.Class_ID = cs.Class_Id AND sam.Subject_ID = cs.Subject_Id AND (sam.IsDeleted = 0 OR sam.IsDeleted IS NULL) LEFT JOIN Staff_Master sm ON sam.Staff_ID = sm.Staff_ID WHERE cs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND cs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.Name IN (''Class 12'', ''XII'') ORDER BY sub.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2745, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2746 | What's the number of receipts today in the Saidapet branch? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the number of receipts today in the Saidapet branch?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS Receipts FROM FeesCollection fc WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND fc.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%Saidapet%'' OR ShortName LIKE ''%Saidapet%'')) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2746, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2747 | Pull up father contact details for students with outstanding greater than 20000 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up father contact details for students with outstanding greater than 20000',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName, sm.LastName, sm.AdmissionNo, sm.FatherName, sm.FatherContactNo, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN Student_Master sm ON f.Student_ID = sm.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.FirstName, sm.LastName, sm.AdmissionNo, sm.FatherName, sm.FatherContactNo HAVING SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 20000 ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2747, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2748 | Kal ka collection? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Kal ka collection?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS YesterdayCollection FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND CAST(fc.Bill_Date AS DATE) = CAST(DATEADD(DAY, -1, GETDATE()) AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2748, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2749 | Show the total number of holiday days this year. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the total number of holiday days this year.',
        @sql NVARCHAR(MAX) = N'SELECT SUM(DATEDIFF(DAY, From_Date, To_Date) + 1) AS TotalHolidayDays FROM HolidayMaster WHERE IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND YEAR(From_Date) IN (2025, 2026);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2749, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2750 | What is the outstanding amount for exam fees? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the outstanding amount for exam fees?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS ExamFeeOutstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND Fees_Name LIKE ''%Exam%'' AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2750, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2751 | Monthly fee collection so far ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Monthly fee collection so far',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS MonthlyCollection FROM FeesCollection fc WHERE DATEPART(MONTH, fc.Bill_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, fc.Bill_Date) = DATEPART(YEAR, GETDATE()) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2751, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2752 | Who are the NEET/JEE aspirants? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who are the NEET/JEE aspirants?',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsNEETJEE = 1 AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2752, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2753 | Which class has the best attendance? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which class has the best attendance?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 cm.Name AS ClassName, CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AttendancePercent FROM StudentAttendance sa INNER JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND MONTH(sa.Attendance_Date) = MONTH(GETDATE()) AND YEAR(sa.Attendance_Date) = YEAR(GETDATE()) GROUP BY cm.Name ORDER BY AttendancePercent DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2753, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2754 | What is the gender split for Class 5 right now? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the gender split for Class 5 right now?',
        @sql NVARCHAR(MAX) = N'SELECT sm.Gender, COUNT(DISTINCT sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID=sm.ID INNER JOIN ClassMaster cm ON sad.ClassID=cm.ID WHERE cm.Name IN (''Class 5'',''V'') AND sad.IsActive=1 AND (sad.IsTCIssued=0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.Gender;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2754, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2755 | Hey, monthly fee collection target vs actual (assuming monthly target is annual/12) ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, monthly fee collection target vs actual (assuming monthly target is annual/12)',
        @sql NVARCHAR(MAX) = N'WITH TotalYearly AS (SELECT SUM(fc.Receipt_Amt) AS YearTotal FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))), MonthlyActual AS (SELECT MONTH(fc.Bill_Date) AS MonthNo, DATENAME(MONTH, fc.Bill_Date) AS MonthName, SUM(fc.Receipt_Amt) AS MonthlyCollection FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY MONTH(fc.Bill_Date), DATENAME(MONTH, fc.Bill_Date)) SELECT ma.MonthNo, ma.MonthName, ma.MonthlyCollection AS Actual, CAST(ty.YearTotal / 12.0 AS DECIMAL(10,2)) AS MonthlyAvgTarget FROM MonthlyActual ma, TotalYearly ty ORDER BY ma.MonthNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2755, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2756 | Any active students with TC issued date but not marked as TC issued? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Any active students with TC issued date but not marked as TC issued?',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.TCIssuedDate FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND sad.TCIssuedDate IS NOT NULL AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2756, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2757 | Let me see the top 5 classes by pending late fee amount ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see the top 5 classes by pending late fee amount',
        @sql NVARCHAR(MAX) = N'SELECT TOP 5 cm.Name AS ClassName, SUM(fcd.LateFeeAmount) AS PendingAmount FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN ClassMaster cm ON fc.Class_ID = cm.ID WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.LateFeeAmount > 0 AND fcd.Remaining_Amt > 0 AND (fc.IsDeleted = 0 OR fc.IsDeleted IS NULL) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY cm.Name ORDER BY PendingAmount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2757, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2758 | Can you show the collection gap by fee category? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show the collection gap by fee category?',
        @sql NVARCHAR(MAX) = N'SELECT FeesCategory_Name, SUM(Amount - ISNULL(Concession_Amt, 0)) AS NetDue, SUM(Paid_Amt) AS Collected, SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS Gap FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY FeesCategory_Name ORDER BY Gap DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2758, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2759 | What's the grade distribution of all students? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the grade distribution of all students?',
        @sql NVARCHAR(MAX) = N'SELECT Grade, COUNT(*) AS StudentCount FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND Grade IS NOT NULL GROUP BY Grade ORDER BY Grade;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2759, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2760 | Girls? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Girls?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS GirlsCount FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.Gender IN (''Female'', ''Girl'');',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2760, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2761 | How many vehicles are available vs how many routes are active? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many vehicles are available vs how many routes are active?',
        @sql NVARCHAR(MAX) = N'SELECT (SELECT COUNT(*) FROM VehicleMaster WHERE IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AS TotalVehicles, (SELECT COUNT(*) FROM Route_Master WHERE IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AS TotalRoutes;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2761, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2762 | Daily average absence count this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Daily average absence count this month',
        @sql NVARCHAR(MAX) = N'SELECT AVG(DailyAbsent) AS AvgDailyAbsent FROM (SELECT sa.Attendance_Date, COUNT(*) AS DailyAbsent FROM StudentAttendance sa WHERE MONTH(sa.Attendance_Date) = MONTH(GETDATE()) AND YEAR(sa.Attendance_Date) = YEAR(GETDATE()) AND sa.Attendance_Status_ID = 2 AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sa.Attendance_Date) AS DailyAbsences;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2762, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2763 | How many people collected fees today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many people collected fees today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT fc.Collected_By_Name) AS CollectorCount FROM FeesCollection fc WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2763, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2764 | Which class received the most concession as a percentage of its demand? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which class received the most concession as a percentage of its demand?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 f.ClassName, ROUND(SUM(ISNULL(f.Concession_Amt, 0)) * 100.0 / NULLIF(SUM(f.Amount), 0), 2) AS ConcessionPercent FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.ClassName ORDER BY ConcessionPercent DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2764, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2765 | How many staff children got admitted this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many staff children got admitted this year?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS StaffChildAdmissions FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNewAdmission = 1 AND sm.StaffChild = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2765, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2766 | How many new admissions got hostel? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many new admissions got hostel?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS NewHostelAdmissions FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNewAdmission = 1 AND sad.HostelRequired = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2766, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2767 | Fee categories with no concessions given this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Fee categories with no concessions given this year',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT fcd.FeesCategory_Name FROM FeesCollection_Details fcd WHERE fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.FeesCategory_Name NOT IN (SELECT DISTINCT fcd2.FeesCategory_Name FROM FeesCollection_Details fcd2 INNER JOIN FeesCollection fc ON fcd2.Fees_Collection_ID = fc.Id WHERE fcd2.Concession_Amount > 0 AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fcd2.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd2.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2767, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2768 | Who is on leave today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who is on leave today?',
        @sql NVARCHAR(MAX) = N'SELECT lem.Staff_Name, lem.LeaveFromDate, lem.LeaveToDate FROM LeaveEntryMaster lem WHERE CAST(GETDATE() AS DATE) BETWEEN lem.LeaveFromDate AND lem.LeaveToDate AND lem.LeaveStatus_ID = 1 AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2768, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2769 | Classes where attendance was not taken even once this week ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Classes where attendance was not taken even once this week',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName FROM ClassMaster cm WHERE cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND cm.IsDeleted = 0 AND cm.ID NOT IN (SELECT DISTINCT sa.Class_ID FROM StudentAttendance sa WHERE sa.Attendance_Date >= DATEADD(DAY, -(DATEPART(WEEKDAY, GETDATE()) - 2), CAST(GETDATE() AS DATE)) AND sa.Attendance_Date <= CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2769, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2770 | Total number of transport students ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total number of transport students',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TransportStudentCount FROM StudentAcademicDetail sad WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.TransportRequired = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2770, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2771 | How many kids do we have right now? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many kids do we have right now?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalStudents FROM StudentAcademicDetail sad WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2771, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2772 | Show leaves approved by each approver. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show leaves approved by each approver.',
        @sql NVARCHAR(MAX) = N'SELECT lem.Updated_By AS ApprovedBy_ID, COUNT(*) AS ApprovedCount FROM LeaveEntryMaster lem INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND ls.Name = ''Approved'' AND lem.Updated_By IS NOT NULL GROUP BY lem.Updated_By ORDER BY ApprovedCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2772, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2773 | Can you show class-wise bus fee outstanding? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show class-wise bus fee outstanding?',
        @sql NVARCHAR(MAX) = N'SELECT ClassName, SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS BusFeeOutstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND IsBusFee = 1 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY ClassName ORDER BY BusFeeOutstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2773, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2774 | Students with lumpsum fee who haven't paid yet ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students with lumpsum fee who haven''t paid yet',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sad.ClassName, sad.Lumpsum_Amount FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.IsLumpsumApplicable = 1 AND sad.Paid_Date IS NULL;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2774, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2775 | I need to see tickets from parents with phone numbers for follow-up ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see tickets from parents with phone numbers for follow-up',
        @sql NVARCHAR(MAX) = N'SELECT TicketNo, Subject, ContactName AS Parent_Name, ContactNumber AS ParentPhone, Status FROM FeedbackTicket WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND ContactNumber IS NOT NULL AND ContactNumber != '''' AND Status IN (''Open'', ''In Progress'', ''Reopened'') ORDER BY Created_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2775, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2776 | Students who paid in the last 3 days ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students who paid in the last 3 days',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, fc.Receipt_Amt, CAST(fc.Bill_Date AS DATE) AS PaidDate FROM FeesCollection fc JOIN Student_Master sm ON fc.Student_ID = sm.ID JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.Bill_Date >= DATEADD(DAY, -3, GETDATE()) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY PaidDate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2776, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2777 | How many students were admitted today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students were admitted today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS admitted_today FROM Student_Master sm JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE CAST(sm.AdmissionDate AS DATE) = CAST(GETDATE() AS DATE) AND sad.IsActive = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2777, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2778 | Compare enquiry numbers - this year vs last year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare enquiry numbers - this year vs last year',
        @sql NVARCHAR(MAX) = N'SELECT ''Current Year'' AS Period, COUNT(*) AS Enquiries FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (IsDeleted = 0 OR IsDeleted IS NULL) UNION ALL SELECT ''Previous Year'' AS Period, COUNT(*) AS Enquiries FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT PreviousYearID FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (IsDeleted = 0 OR IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2778, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2779 | Show me day-wise collection for this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me day-wise collection for this month',
        @sql NVARCHAR(MAX) = N'SELECT CAST(fc.Bill_Date AS DATE) AS collection_date, SUM(fc.Receipt_Amt) AS daily_total FROM FeesCollection fc WHERE DATEPART(MONTH, fc.Bill_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, fc.Bill_Date) = DATEPART(YEAR, GETDATE()) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY CAST(fc.Bill_Date AS DATE) ORDER BY CAST(fc.Bill_Date AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2779, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2780 | Hey, how many A grades were given in Class 10? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many A grades were given in Class 10?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS AGradeCount FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE cm.Name IN (''Class 10'', ''X'') AND pc.Grade = ''A'' AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2780, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2781 | What is the total fee collected via cheque that later bounced? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total fee collected via cheque that later bounced?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS ChequeBounceTotal FROM FeesCollection fc WHERE fc.ChequeStatus_ID = 4 AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2781, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2782 | What's the community-wise student strength? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the community-wise student strength?',
        @sql NVARCHAR(MAX) = N'SELECT sm.Community_Name, COUNT(*) AS student_count FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY sm.Community_Name ORDER BY COUNT(*) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2782, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2783 | Show the number of students with outstanding in each term. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the number of students with outstanding in each term.',
        @sql NVARCHAR(MAX) = N'SELECT f.Term_Name, COUNT(DISTINCT f.Student_ID) AS StudentsWithOutstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 0 AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Term_Name ORDER BY f.Term_Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2783, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2784 | What are the the subjects taught in Class 10? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What are the the subjects taught in Class 10?',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT pc.SubjectName FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE cm.Name IN (''Class 10'', ''X'') AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) ORDER BY pc.SubjectName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2784, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2785 | Show the last 10 fee receipts ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the last 10 fee receipts',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 fc.Bill_No, fc.Bill_Date, fc.Admission_No, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, fc.Receipt_Amt, cmm.Name FROM FeesCollection fc JOIN Student_Master sm ON fc.Student_ID = sm.ID LEFT JOIN CollectionMode_Master cmm ON fc.Collection_Mode_ID = cmm.ID WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY fc.Bill_Date DESC, fc.Id DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2785, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2786 | How much fee is still outstanding as a percentage of net demand? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much fee is still outstanding as a percentage of net demand?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) * 100.0 / NULLIF(SUM(f.Amount - ISNULL(f.Concession_Amt, 0)), 0), 2) AS OutstandingPercentage FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2786, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2787 | Any expiring driver licenses? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Any expiring driver licenses?',
        @sql NVARCHAR(MAX) = N'SELECT Name, Mobile, License_Number, License_Expiry_Date, DATEDIFF(DAY, GETDATE(), License_Expiry_Date) AS DaysRemaining FROM DriverMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND License_Expiry_Date <= DATEADD(DAY, 60, GETDATE()) ORDER BY License_Expiry_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2787, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2788 | Show the top 3 fee types contributing to outstanding. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the top 3 fee types contributing to outstanding.',
        @sql NVARCHAR(MAX) = N'SELECT TOP 3 Fees_Name, SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY Fees_Name ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2788, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2789 | I wanna see enquiries received in the last 30 days grouped by status ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I wanna see enquiries received in the last 30 days grouped by status',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT esm.Name AS Status, COUNT(*) AS EnquiryCount FROM GeneralCallRegister em INNER JOIN Enquiry_Status_Master esm ON em.CallStatus_ID = esm.ID WHERE em.CallDate >= DATEADD(DAY, -30, GETDATE()) AND em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND em.IsDeleted = 0 GROUP BY esm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2789, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2790 | Pull up concession category-wise breakdown ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up concession category-wise breakdown',
        @sql NVARCHAR(MAX) = N'SELECT ccm.Name AS ConcessionCategory, COUNT(DISTINCT cm.Student_ID) AS StudentCount, SUM(cm.Concession_Amount) AS TotalConcession FROM Concession_Master cm INNER JOIN Concession_Category_Master ccm ON cm.ConcessionCategory_ID = ccm.Id WHERE cm.IsDeleted = 0 AND cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY ccm.Name ORDER BY TotalConcession DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2790, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2791 | Leave status summary for this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Leave status summary for this year',
        @sql NVARCHAR(MAX) = N'SELECT ls.Name AS Status, COUNT(*) AS Count FROM LeaveEntryMaster lem INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY ls.Name ORDER BY Count DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2791, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2792 | Show late fees calculated today. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show late fees calculated today.',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName + '' '' + sm.LastName AS StudentName, fcd.LateFeeName, fcd.LateFeeAmount, fc.Bill_Date FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN Student_Master sm ON fc.Student_ID = sm.ID WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.LateFeeAmount > 0 AND CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted = 0 OR fc.IsDeleted IS NULL) AND fc.ChequeStatus_ID NOT IN (3, 4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2792, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2793 | Let me see section-wise strength for Class 8 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see section-wise strength for Class 8',
        @sql NVARCHAR(MAX) = N'SELECT secm.Name AS SectionName, COUNT(*) AS strength FROM StudentAcademicDetail sad JOIN ClassMaster cm ON sad.ClassID = cm.ID INNER JOIN SectionMaster secm ON sad.SectionID = secm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND cm.Name IN (''Class 8'', ''VIII'') AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY secm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2793, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2794 | Did performance improve from Term 1 to Term 2? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Did performance improve from Term 1 to Term 2?',
        @sql NVARCHAR(MAX) = N'SELECT pc.TermName AS TermName, CAST(AVG(pc.Marks) AS DECIMAL(5,2)) AS AvgMarks, COUNT(DISTINCT pc.StudentID) AS StudentCount FROM ProgressCardDataRetrieval pc WHERE pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) GROUP BY pc.TermName ORDER BY pc.TermName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2794, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2795 | Hey, what's the enquiry to admission ratio class-wise? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the enquiry to admission ratio class-wise?',
        @sql NVARCHAR(MAX) = N'DECLARE @StatusConverted bigint = (SELECT TOP 1 ID FROM Enquiry_Status_Master WHERE Name = ''Completed'');
WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT cm.Name AS ClassName, COUNT(*) AS TotalEnquiries, SUM(CASE WHEN em.CallStatus_ID = @StatusConverted THEN 1 ELSE 0 END) AS Admissions, CAST(SUM(CASE WHEN em.CallStatus_ID = @StatusConverted THEN 1 ELSE 0 END) * 1.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS Ratio FROM GeneralCallRegister em INNER JOIN ClassMaster cm ON em.Class_ID = cm.ID WHERE em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND (em.IsDeleted = 0 OR em.IsDeleted IS NULL) GROUP BY cm.Name ORDER BY Ratio DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2795, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2796 | VIP students who were absent today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'VIP students who were absent today',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, cm.Name AS ClassName, secm.Name AS SectionName FROM Student_Master sm INNER JOIN StudentAttendance sa ON sm.ID = sa.Student_ID INNER JOIN ClassMaster cm ON sa.Class_ID = cm.ID INNER JOIN SectionMaster secm ON sa.Section_ID = secm.ID WHERE sm.IsVIP = 1 AND sa.Attendance_Date = CAST(GETDATE() AS DATE) AND sa.Attendance_Status_ID = 2 AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2796, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2797 | Show total collection for each branch this academic year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show total collection for each branch this academic year',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, SUM(fc.Receipt_Amt) AS Collection FROM FeesCollection fc JOIN BranchMaster bm ON fc.BranchID = bm.ID WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY Collection DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2797, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2798 | Total enquiries received this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total enquiries received this year',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalEnquiries FROM GeneralCallRegister WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2798, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2799 | Just checking - how many male vs female applications for Class 1? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many male vs female applications for Class 1?',
        @sql NVARCHAR(MAX) = N'SELECT ae.Gender, COUNT(*) AS Applications FROM ApplicationEntry ae INNER JOIN ClassMaster cm ON ae.Student_ClassID = cm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) AND cm.Name IN (''Class 1'', ''I'') GROUP BY ae.Gender;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2799, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2800 | Who all didn't come today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who all didn''t come today?',
        @sql NVARCHAR(MAX) = N'SELECT sa.Staff_ID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName FROM Staff_Attendance sa INNER JOIN Staff_Master sm ON sa.Staff_ID = sm.Staff_ID AND sm.StaffStatus_ID = 1 WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.Attendance_Date = CAST(GETDATE() AS DATE) AND sa.Attendance_Status_ID = 2;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
PRINT 'checkpoint: reached Q2800';
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2800, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2801 | How many students have received concession? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students have received concession?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT fc.Student_ID) AS ConcessionStudentCount FROM FeesCollection fc INNER JOIN FeesCollection_Details fcd ON fc.Id = fcd.Fees_Collection_ID WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fcd.Concession_Amount > 0 AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2801, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2802 | Show me the running total of fee collection day by day this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me the running total of fee collection day by day this year',
        @sql NVARCHAR(MAX) = N'WITH DailyCollection AS (SELECT CAST(fc.Bill_Date AS DATE) AS CollectionDate, SUM(fc.Receipt_Amt) AS DayTotal FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY CAST(fc.Bill_Date AS DATE)) SELECT CollectionDate, DayTotal, SUM(DayTotal) OVER (ORDER BY CollectionDate) AS RunningTotal FROM DailyCollection ORDER BY CollectionDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2802, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2803 | Give me all students whose attendance is below 75% with their parent contact numbers ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me all students whose attendance is below 75% with their parent contact numbers',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, sm.FatherContactNo, sm.MotherContactNo, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sa.ID), 0) AS DECIMAL(5,2)) AS AttendancePercent FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN StudentAttendance sa ON sm.ID = sa.Student_ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.ID, sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo, sad.ClassName, sm.FatherContactNo, sm.MotherContactNo HAVING CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sa.ID), 0) AS DECIMAL(5,2)) < 75 ORDER BY AttendancePercent;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2803, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2804 | Show all transport students with their class and parent details ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show all transport students with their class and parent details',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, sad.RollNo, sm.FatherName, sm.FatherContactNo, sm.MotherName, sm.MotherContactNo FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.TransportRequired = 1 AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.ClassName, sad.RollNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2804, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2805 | Show the class-wise total concession amount. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the class-wise total concession amount.',
        @sql NVARCHAR(MAX) = N'SELECT ClassName, SUM(ISNULL(Concession_Amt, 0)) AS ConcessionAmount FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY ClassName ORDER BY ConcessionAmount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2805, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2806 | Monthly fee collection breakdown ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Monthly fee collection breakdown',
        @sql NVARCHAR(MAX) = N'SELECT DATENAME(MONTH, fc.Bill_Date) AS MonthName, ISNULL(SUM(fc.Receipt_Amt), 0) AS Collection FROM FeesCollection fc WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY DATENAME(MONTH, fc.Bill_Date), MONTH(fc.Bill_Date) ORDER BY MONTH(fc.Bill_Date);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2806, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2807 | Students with pending for more than 3 months ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students with pending for more than 3 months',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, fisd.ClassName, SUM((fisd.Amount - ISNULL(fisd.Concession_Amt, 0) - ISNULL(fisd.Paid_Amt, 0))) AS TotalPending, MIN(fisd.Month_No) AS OldestPendingMonth FROM FeesInformationStudentDetail fisd JOIN Student_Master sm ON fisd.Student_ID = sm.ID JOIN StudentAcademicDetail sad ON fisd.Student_ID = sad.StudentID AND fisd.AcademicYearID = sad.AcademicYearID WHERE fisd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fisd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fisd.Amount - ISNULL(fisd.Concession_Amt, 0) - ISNULL(fisd.Paid_Amt, 0)) > 0 AND fisd.Month_No <= MONTH(GETDATE()) - 3 AND sad.IsActive = 1 GROUP BY sm.AdmissionNo, sm.FirstName, sm.MiddleName, sm.LastName, fisd.ClassName ORDER BY SUM((fisd.Amount - ISNULL(fisd.Concession_Amt, 0) - ISNULL(fisd.Paid_Amt, 0))) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2807, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2808 | How many boys and girls are there in Class 3? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many boys and girls are there in Class 3?',
        @sql NVARCHAR(MAX) = N'SELECT sm.Gender, COUNT(*) AS StudentCount FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID=sm.ID INNER JOIN ClassMaster cm ON sad.ClassID=cm.ID WHERE cm.Name IN (''Class 3'',''III'') AND sad.IsActive=1 AND (sad.IsTCIssued=0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.Gender;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2808, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2809 | Can you show daily collection totals for the past week? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show daily collection totals for the past week?',
        @sql NVARCHAR(MAX) = N'WITH dc AS (SELECT dm.ID, dm.DayClosureDate AS ClosureDate, dm.CollectedByName AS ClosedBy_Name, SUM(dmd.CollectedAmount) AS TotalCollection, SUM(CASE WHEN cmm.Name = ''Cash'' THEN dmd.CollectedAmount ELSE 0 END) AS CashCollection, SUM(CASE WHEN cmm.Name = ''Bank Online Transfer'' THEN dmd.CollectedAmount ELSE 0 END) AS OnlineCollection, SUM(CASE WHEN cmm.Name NOT IN (''Cash'', ''Bank Online Transfer'', ''Cheque'') THEN dmd.CollectedAmount ELSE 0 END) AS OtherCollection, SUM(CASE WHEN cmm.Name = ''Cheque'' THEN dmd.CollectedAmount ELSE 0 END) AS ChequeCollection FROM DayclosureMaster dm INNER JOIN DayclosureMaster_Details dmd ON dmd.HeaderID = dm.ID LEFT JOIN CollectionMode_Master cmm ON dmd.CollectionMode_ID = cmm.ID WHERE dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (dm.IsDeleted = 0 OR dm.IsDeleted IS NULL) AND (dmd.IsDeleted = 0 OR dmd.IsDeleted IS NULL) GROUP BY dm.ID, dm.DayClosureDate, dm.CollectedByName) SELECT CAST(ClosureDate AS DATE) AS ClosureDay, TotalCollection, CashCollection, OnlineCollection, ChequeCollection, ClosedBy_Name FROM dc WHERE ClosureDate >= DATEADD(DAY, -7, GETDATE()) ORDER BY ClosureDate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2809, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2810 | Students who have paid but receipt was not printed ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students who have paid but receipt was not printed',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, fc.Bill_No, fc.Receipt_Amt, fc.Bill_Date FROM Student_Master sm INNER JOIN FeesCollection fc ON sm.ID = fc.Student_ID WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (fc.IsReceiptPrinted = 0 OR fc.IsReceiptPrinted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2810, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2811 | Let me see present count per branch today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see present count per branch today',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, COUNT(*) AS Present FROM StudentAttendance sa JOIN BranchMaster bm ON sa.BranchID = bm.ID WHERE sa.Attendance_Status_ID = 1 AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY Present DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2811, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2812 | What is the average fee per student by class? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the average fee per student by class?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(DISTINCT fc.Student_ID) AS PayingStudents, SUM(fc.Receipt_Amt) AS TotalCollection, CAST(SUM(fc.Receipt_Amt) / NULLIF(COUNT(DISTINCT fc.Student_ID), 0) AS DECIMAL(10,2)) AS AvgFeePerStudent FROM FeesCollection fc JOIN ClassMaster cm ON fc.Class_ID = cm.ID JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name, cm.DisplayOrder ORDER BY cm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2812, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2813 | Who referred the most enquiries? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who referred the most enquiries?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT TOP 10 emm.Name AS ReferredBy, COUNT(*) AS EnquiryCount FROM GeneralCallRegister em INNER JOIN Enquiry_Mode_Master emm ON em.Mode_ID = emm.ID WHERE em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND (em.IsDeleted = 0 OR em.IsDeleted IS NULL) AND emm.Name IS NOT NULL AND emm.Name != '''' GROUP BY emm.Name ORDER BY EnquiryCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2813, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2814 | List top 15 defaulters with their total demand and paid amounts. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List top 15 defaulters with their total demand and paid amounts.',
        @sql NVARCHAR(MAX) = N'SELECT TOP 15 f.Student_ID, s.FirstName + '' '' + ISNULL(s.LastName, '''') AS StudentName, f.ClassName, SUM(f.Amount) AS TotalDemand, SUM(f.Paid_Amt) AS TotalPaid, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID INNER JOIN Student_Master s ON f.Student_ID = s.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Student_ID, s.FirstName, s.LastName, f.ClassName HAVING SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 0 ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2814, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2815 | Hey, what's the outstanding for Term 1? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the outstanding for Term 1?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS Term1Outstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND Term_Name IN (''Term 1'', ''I'') AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2815, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2816 | Who's the students who failed in Mathematics? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who''s the students who failed in Mathematics?',
        @sql NVARCHAR(MAX) = N'SELECT smd.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName, smd.Marks FROM StudentMarkDetails smd INNER JOIN ExamConfigurationEvaluationDetails eced ON smd.EvalHierID = eced.ID INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN Subject_Master s ON s.BranchID = smd.BranchID INNER JOIN Student_Master stm ON smd.StudentID = stm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND s.Name = ''Maths'' AND s.IsDeleted = 0 AND smd.Marks < eced.MinMark ORDER BY smd.Marks ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2816, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2817 | I need the staff with zero net salary ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need the staff with zero net salary',
        @sql NVARCHAR(MAX) = N'SELECT gem.EmployeeID AS StaffID, gem.EmployeeName AS StaffName, gem.NetPay AS NetSalary FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gem.NetPay = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2817, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2818 | Give me a list of drivers with more than 10 years of experience ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me a list of drivers with more than 10 years of experience',
        @sql NVARCHAR(MAX) = N'SELECT Name, Mobile, Experience, License_Number FROM DriverMaster WHERE Experience > 10 AND IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY Experience DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2818, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2819 | This month's collection at Velacherry branch ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'This month''s collection at Velacherry branch',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fc.Receipt_Amt) AS Collection FROM FeesCollection fc WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND DATEPART(MONTH, fc.Bill_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, fc.Bill_Date) = DATEPART(YEAR, GETDATE()) AND fc.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%Velacher%'' OR ShortName LIKE ''%Velacher%'')) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2819, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2820 | Students who haven't been assigned to any house ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students who haven''t been assigned to any house',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName FROM Student_Master sm JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE (sad.HouseName IS NULL OR sad.HouseName = '''') AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.ClassName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2820, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2821 | Show class-wise refund distribution. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show class-wise refund distribution.',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(*) AS RefundCount, SUM(r.Refund_Amt) AS TotalRefund FROM RefundReceipt r INNER JOIN Student_Master sm ON r.Student_ID = sm.ID INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE r.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND r.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY cm.Name ORDER BY TotalRefund DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2821, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2822 | Show top 5 students with highest fee payments this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show top 5 students with highest fee payments this year',
        @sql NVARCHAR(MAX) = N'SELECT TOP 5 ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, SUM(fc.Receipt_Amt) AS TotalPaid FROM FeesCollection fc JOIN Student_Master sm ON fc.Student_ID = sm.ID JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.AcademicYearID = bad.Id AND sad.IsActive = 1 AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo, sad.ClassName ORDER BY TotalPaid DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2822, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2823 | How many students stay in the hostel? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students stay in the hostel?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS HostelStudents FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.HostelRequired = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2823, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2824 | Is there any student without a last name in the system? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Is there any student without a last name in the system?',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, sm.FirstName, sm.AdmissionNo, sad.ClassName FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.LastName IS NULL OR sm.LastName = '''');',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2824, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2825 | Can I see the average receipt amount ratio by class? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can I see the average receipt amount ratio by class?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, AVG(fc.Receipt_Amt) AS AvgReceiptAmt FROM FeesCollection fc INNER JOIN ClassMaster cm ON fc.Class_ID = cm.ID WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY cm.Name, cm.DisplayOrder ORDER BY cm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2825, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2826 | Show route-wise transport fee range. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show route-wise transport fee range.',
        @sql NVARCHAR(MAX) = N'SELECT rm.Name AS RouteName, MIN(bpm.Amount) AS MinFee, MAX(bpm.Amount) AS MaxFee, AVG(CAST(bpm.Amount AS FLOAT)) AS AvgFee FROM Route_Master rm INNER JOIN Route_MasterDetails rmd ON rm.ID = rmd.Route_ID INNER JOIN BoardingPoint_Master bpm ON rmd.BoardingPoint_ID = bpm.Id WHERE rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND rm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (rm.IsDeleted = 0 OR rm.IsDeleted IS NULL) GROUP BY rm.Name ORDER BY AvgFee DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2826, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2827 | Any pending leave requests I need to look at? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Any pending leave requests I need to look at?',
        @sql NVARCHAR(MAX) = N'SELECT sfm.Staff_FirstName + '' '' + ISNULL(sfm.Staff_LastName, '''') AS StaffName, lt.Name AS LeaveType, lem.LeaveFromDate, lem.LeaveToDate, lem.NoOfDays FROM LeaveEntryMaster lem INNER JOIN Staff_Master sfm ON lem.Staff_ID = sfm.Staff_ID AND sfm.StaffStatus_ID = 1 INNER JOIN LeaveType lt ON lem.LeaveType_ID = lt.ID INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE ls.Name = ''Pending'' AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY lem.LeaveFromDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2827, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2828 | Which students have both low attendance and pending fees? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which students have both low attendance and pending fees?',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT f.Student_ID, sm.FirstName + '' '' + sm.LastName AS StudentName FROM FeesInformationStudentDetail f INNER JOIN Student_Master sm ON f.Student_ID = sm.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 0 AND f.Student_ID IN (SELECT sa.Student_ID FROM StudentAttendance sa WHERE sa.Attendance_Status_ID = 2 GROUP BY sa.Student_ID HAVING COUNT(*) * 1.0 / NULLIF((SELECT COUNT(*) FROM StudentAttendance sa2 WHERE sa2.Student_ID = sa.Student_ID), 0) > 0.4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2828, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2829 | Can you list out applications scheduled for interview? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you list out applications scheduled for interview?',
        @sql NVARCHAR(MAX) = N'SELECT ae.ApplicationNo, ae.FirstName + ISNULL('' '' + ae.MiddleName, '''') + '' '' + ae.LastName AS StudentName, ae.FatherName, ae.MotherName, ae.ComMobile AS Phone, cm.Name AS ClassApplied FROM ApplicationEntry ae INNER JOIN ClassMaster cm ON ae.Student_ClassID = cm.ID INNER JOIN ApplicationStatus_Master asm ON ae.ApplicationStatus_ID = asm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) AND asm.Name = ''Called For Interview'' ORDER BY ae.ApplicationDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2829, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2830 | How many people showed up today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many people showed up today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS PresentCount FROM Staff_Attendance WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND Attendance_Date = CAST(GETDATE() AS DATE) AND Attendance_Status_ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2830, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2831 | Which subject has the most failures in Class 9? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which subject has the most failures in Class 9?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 pc.SubjectName AS SubjectName, COUNT(*) AS FailCount FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE cm.Name IN (''Class 9'', ''IX'') AND pc.Marks < pc.MinMark AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) GROUP BY pc.SubjectName ORDER BY FailCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2831, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2832 | How much was collected on each Saturday this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much was collected on each Saturday this month?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(fc.Bill_Date AS DATE) AS Saturday, SUM(fc.Receipt_Amt) AS Collection FROM FeesCollection fc WHERE MONTH(fc.Bill_Date) = MONTH(GETDATE()) AND YEAR(fc.Bill_Date) = YEAR(GETDATE()) AND DATEPART(WEEKDAY, fc.Bill_Date) = 7 AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY CAST(fc.Bill_Date AS DATE) ORDER BY Saturday;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2832, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2833 | List students who have paid nothing and have demand more than 30000. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List students who have paid nothing and have demand more than 30000.',
        @sql NVARCHAR(MAX) = N'SELECT f.Student_ID, s.FirstName + '' '' + ISNULL(s.LastName, '''') AS StudentName, f.ClassName, s.FatherContactNo, SUM(f.Amount) AS TotalDemand FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID INNER JOIN Student_Master s ON f.Student_ID = s.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Student_ID, s.FirstName, s.LastName, f.ClassName, s.FatherContactNo HAVING SUM(f.Paid_Amt) = 0 AND SUM(f.Amount) > 30000 ORDER BY TotalDemand DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2833, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2834 | Rank fee types by outstanding amount ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Rank fee types by outstanding amount',
        @sql NVARCHAR(MAX) = N'SELECT f.FeesType_Name, SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS Outstanding, RANK() OVER (ORDER BY SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) DESC) AS Rank_ FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY f.FeesType_Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2834, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2835 | Which classes still have seats available based on admissions? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which classes still have seats available based on admissions?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(DISTINCT sad.StudentID) AS CurrentStrength FROM StudentAcademicDetail sad JOIN ClassMaster cm ON sad.ClassID = cm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name, cm.DisplayOrder ORDER BY cm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2835, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2836 | Can you show homework remarks/description for a given assignment? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show homework remarks/description for a given assignment?',
        @sql NVARCHAR(MAX) = N'SELECT h.Remarks FROM HomeWorkAndAssignment h WHERE h.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND h.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (h.IsDeleted = 0 OR h.IsDeleted IS NULL) AND h.ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2836, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2837 | Just checking - how many girls are there in Class 10? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many girls are there in Class 10?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS GirlsCount FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE cm.Name IN (''Class 10'', ''X'') AND sm.Gender IN (''Female'', ''Girl'') AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2837, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2838 | Can I see the percentage of receipts cancelled? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can I see the percentage of receipts cancelled?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(COUNT(CASE WHEN fc.IsDeleted = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS CancellationPercent FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2838, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2839 | Show me the male female ratio ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me the male female ratio',
        @sql NVARCHAR(MAX) = N'SELECT sm.Gender, COUNT(*) AS total FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY sm.Gender;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2839, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2840 | So, what's the total uncollected fee amount? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, what''s the total uncollected fee amount?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fcd.Remaining_Amt), 0) AS uncollected_amount FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.Remaining_Amt > 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2840, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2841 | Show pending vs paid late fee comparison by class. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show pending vs paid late fee comparison by class.',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, SUM(CASE WHEN fcd.Remaining_Amt = 0 THEN fcd.LateFeeAmount ELSE 0 END) AS PaidAmount, SUM(CASE WHEN fcd.Remaining_Amt > 0 THEN fcd.LateFeeAmount ELSE 0 END) AS PendingAmount FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN ClassMaster cm ON fc.Class_ID = cm.ID WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.LateFeeAmount > 0 AND (fc.IsDeleted = 0 OR fc.IsDeleted IS NULL) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY cm.Name ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2841, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2842 | How many CNG vehicles do we have? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many CNG vehicles do we have?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS CNGVehicles FROM VehicleMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND Fuel_Type_Name = ''CNG'';',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2842, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2843 | I wanna see collection totals and student totals side by side per branch ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I wanna see collection totals and student totals side by side per branch',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, (SELECT COUNT(*) FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sm.BranchID = bm.ID AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL)) AS Students, (SELECT SUM(fc.Receipt_Amt) FROM FeesCollection fc WHERE fc.BranchID = bm.ID AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4)) AS Collection FROM BranchMaster bm WHERE bm.ID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY bm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2843, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2844 | List students who have paid their late fees this month. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List students who have paid their late fees this month.',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName + '' '' + sm.LastName AS StudentName, sm.FatherName, fcd.LateFeeAmount, fcd.LateFeeName FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN Student_Master sm ON fc.Student_ID = sm.ID WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.LateFeeAmount > 0 AND fcd.Remaining_Amt = 0 AND MONTH(fc.Bill_Date) = MONTH(GETDATE()) AND YEAR(fc.Bill_Date) = YEAR(GETDATE()) AND (fc.IsDeleted = 0 OR fc.IsDeleted IS NULL) AND fc.ChequeStatus_ID NOT IN (3, 4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2844, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2845 | How many applications are still in submitted status for over 30 days? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many applications are still in submitted status for over 30 days?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS StaleApplications FROM ApplicationEntry ae INNER JOIN ApplicationStatus_Master asm ON ae.ApplicationStatus_ID = asm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) AND asm.Name = ''Application Submitted'' AND DATEDIFF(DAY, ae.ApplicationDate, GETDATE()) > 30;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2845, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2846 | List classes with more than 50 students having outstanding. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List classes with more than 50 students having outstanding.',
        @sql NVARCHAR(MAX) = N'SELECT ClassName, COUNT(DISTINCT Student_ID) AS StudentsWithDue FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND (Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) > 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY ClassName HAVING COUNT(DISTINCT Student_ID) > 50 ORDER BY StudentsWithDue DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2846, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2847 | Pull up today's receipts real quick ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up today''s receipts real quick',
        @sql NVARCHAR(MAX) = N'SELECT fc.Bill_No, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, fc.Receipt_Amt, cmm.Name, fc.Collected_By_Name FROM FeesCollection fc INNER JOIN Student_Master sm ON fc.Student_ID = sm.ID LEFT JOIN CollectionMode_Master cmm ON fc.Collection_Mode_ID = cmm.ID WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) ORDER BY fc.Bill_No;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2847, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2848 | Hey, what's the month-wise payable vs paid comparison? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the month-wise payable vs paid comparison?',
        @sql NVARCHAR(MAX) = N'SELECT fcd.Month_No, SUM(fcd.Payable_Amt) AS TotalPayable, SUM(fcd.Paid_Amt) AS TotalPaid, SUM(fcd.Payable_Amt) - SUM(fcd.Paid_Amt) AS Difference FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fcd.Month_No ORDER BY fcd.Month_No;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2848, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2849 | Show top 10 defaulters for transport fees. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show top 10 defaulters for transport fees.',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 f.Student_ID, s.FirstName + '' '' + ISNULL(s.LastName, '''') AS StudentName, f.ClassName, s.FatherContactNo, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID INNER JOIN Student_Master s ON f.Student_ID = s.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.IsBusFee = 1 AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Student_ID, s.FirstName, s.LastName, f.ClassName, s.FatherContactNo HAVING SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 0 ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2849, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2850 | What's today's collection amount? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s today''s collection amount?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS TodayCollection FROM FeesCollection fc WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2850, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2851 | Show me month-wise admissions this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me month-wise admissions this year',
        @sql NVARCHAR(MAX) = N'SELECT DATENAME(MONTH, sm.AdmissionDate) AS admission_month, COUNT(*) AS admission_count FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.IsNewAdmission = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY DATENAME(MONTH, sm.AdmissionDate), DATEPART(MONTH, sm.AdmissionDate) ORDER BY DATEPART(MONTH, sm.AdmissionDate);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2851, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2852 | What is the bus fee collection rate? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the bus fee collection rate?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(SUM(f.Paid_Amt) * 100.0 / NULLIF(SUM(f.Amount), 0), 2) AS BusFeeCollectionRate FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.IsBusFee = 1 AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2852, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2853 | Hey, how many students have concession greater than 5000? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many students have concession greater than 5000?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS StudentCount FROM (SELECT Student_ID, SUM(ISNULL(Concession_Amt, 0)) AS TotalConcession FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY Student_ID HAVING SUM(ISNULL(Concession_Amt, 0)) > 5000) t;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2853, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2854 | Compare cheque collection per branch this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare cheque collection per branch this month',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, SUM(fc.Receipt_Amt) AS ChequeCollection FROM FeesCollection fc JOIN BranchMaster bm ON fc.BranchID = bm.ID WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.Collection_Mode_ID IN (SELECT ID FROM CollectionMode_Master WHERE Name = ''Cheque'') AND DATEPART(MONTH, fc.Bill_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, fc.Bill_Date) = DATEPART(YEAR, GETDATE()) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY ChequeCollection DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2854, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2855 | Students with no date of birth recorded ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students with no date of birth recorded',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sm.StudentDob IS NULL;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2855, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2856 | I need the payment mode wise staff count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need the payment mode wise staff count',
        @sql NVARCHAR(MAX) = N'SELECT PaymentModeID, COUNT(*) AS StaffCount FROM EmployeeMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0 GROUP BY PaymentModeID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2856, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2857 | Staff who came late today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff who came late today',
        @sql NVARCHAR(MAX) = N'SELECT sa.Staff_ID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName, sa.InTime FROM Staff_Attendance sa INNER JOIN Staff_Master sm ON sa.Staff_ID = sm.Staff_ID AND sm.StaffStatus_ID = 1 WHERE sa.Attendance_Date = CAST(GETDATE() AS DATE) AND sa.InTime > ''09:00'' AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sa.InTime DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2857, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2858 | Let me see students whose TC is still pending, not issued yet ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see students whose TC is still pending, not issued yet',
        @sql NVARCHAR(MAX) = N'SELECT sad.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id INNER JOIN Student_Master stm ON sad.StudentID = stm.ID WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.IsActive = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2858, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2859 | Students who owe more than 1 lakh ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students who owe more than 1 lakh',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, sm.AdmissionNo, cm.Name AS class_name, sm.FatherContactNo, SUM(fcd.Remaining_Amt) AS outstanding FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Student_Master sm ON fc.Student_ID = sm.ID JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID AND fc.AcademicYearID = sad.AcademicYearID JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fcd.Remaining_Amt > 0 AND sad.IsActive = 1 GROUP BY sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo, cm.Name, sm.FatherContactNo HAVING SUM(fcd.Remaining_Amt) > 100000 ORDER BY SUM(fcd.Remaining_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2859, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2860 | What is the admission conversion rate from enquiries? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the admission conversion rate from enquiries?',
        @sql NVARCHAR(MAX) = N'DECLARE @StatusConverted bigint = (SELECT TOP 1 ID FROM Enquiry_Status_Master WHERE Name = ''Completed'');
WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT CAST(COUNT(CASE WHEN CallStatus_ID = @StatusConverted THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS ConversionRatePercent FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2860, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2861 | Exam type with highest failure rate ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Exam type with highest failure rate',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 et.Name AS ExamType, CAST(SUM(CASE WHEN smd.Marks < eced.MinMark THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS FailRate FROM StudentMarkDetails smd INNER JOIN ExamConfigurationEvaluationDetails eced ON smd.EvalHierID = eced.ID INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ExamTypeMaster et ON smm.ExamTypeID = et.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND et.IsDeleted = 0 GROUP BY et.Name ORDER BY FailRate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2861, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2862 | I need to see tickets where the same parent has raised multiple complaints ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see tickets where the same parent has raised multiple complaints',
        @sql NVARCHAR(MAX) = N'SELECT ContactName AS Parent_Name, ContactNumber AS ParentPhone, COUNT(*) AS TicketCount, SUM(CASE WHEN Status IN (''Open'', ''In Progress'', ''Reopened'') THEN 1 ELSE 0 END) AS StillOpen FROM FeedbackTicket WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND ContactName IS NOT NULL GROUP BY ContactName, ContactNumber HAVING COUNT(*) > 1 ORDER BY TicketCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2862, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2863 | Give me the exam types under each term ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the exam types under each term',
        @sql NVARCHAR(MAX) = N'SELECT etm.Name AS Term, et.Name AS ExamType FROM ExamTypeMaster et INNER JOIN ExamTermMaster etm ON et.TermID = etm.ID WHERE et.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND et.IsDeleted = 0 AND etm.Deleted = 0 ORDER BY etm.Name, et.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2863, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2864 | List all fee heads with their amounts for Class 8 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all fee heads with their amounts for Class 8',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT fcd.Fees_Head_ID, fcd.FeesType_Name, fcd.FeesCategory_Name, fcd.Fees_Amount FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN ClassMaster cm ON fc.Class_ID = cm.ID WHERE cm.Name IN (''Class 8'', ''VIII'') AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY fcd.FeesType_Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2864, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2865 | Just checking - how many days since the last fee collection was done? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many days since the last fee collection was done?',
        @sql NVARCHAR(MAX) = N'SELECT DATEDIFF(DAY, MAX(CAST(fc.Bill_Date AS DATE)), CAST(GETDATE() AS DATE)) AS DaysSinceLastCollection FROM FeesCollection fc WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2865, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2866 | So, how many new enquiries have not been acted upon in 7 days? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, how many new enquiries have not been acted upon in 7 days?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS StaleEnquiries FROM GeneralCallRegister WHERE CallStatus_ID IN (SELECT ID FROM Enquiry_Status_Master WHERE Name = ''Initiated'') AND DATEDIFF(DAY, CallDate, GETDATE()) > 7 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2866, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2867 | So, what's the total transport fee outstanding? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, what''s the total transport fee outstanding?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS TransportOutstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.IsBusFee = 1 AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2867, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2868 | Compare Term 1 and Term 2 collection rates. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare Term 1 and Term 2 collection rates.',
        @sql NVARCHAR(MAX) = N'SELECT f.Term_Name, ROUND(SUM(f.Paid_Amt) * 100.0 / NULLIF(SUM(f.Amount), 0), 2) AS CollectionRate FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.Term_Name IN (''Term 1'', ''Term 2'') AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Term_Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2868, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2869 | What is the average salary of staff? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the average salary of staff?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(AVG(gem.NetPay) AS DECIMAL(12,2)) AS AvgSalary FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2869, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2870 | Give me the age-wise student count distribution ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the age-wise student count distribution',
        @sql NVARCHAR(MAX) = N'SELECT DATEDIFF(YEAR, sm.StudentDob, GETDATE()) AS Age, COUNT(DISTINCT sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.StudentDob IS NOT NULL AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY DATEDIFF(YEAR, sm.StudentDob, GETDATE()) ORDER BY Age;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2870, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2871 | Any staff on half-day today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Any staff on half-day today?',
        @sql NVARCHAR(MAX) = N'SELECT sfm.Staff_FirstName + '' '' + ISNULL(sfm.Staff_LastName, '''') AS StaffName, sa.InTime, sa.OutTime FROM Staff_Attendance sa INNER JOIN Staff_Master sfm ON sa.Staff_ID = sfm.Staff_ID AND sfm.StaffStatus_ID = 1 WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.Attendance_Status_ID = 3  AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2871, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2872 | Let me see the resolution rate for feedback tickets ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see the resolution rate for feedback tickets',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(CASE WHEN Status = ''Closed'' THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS ResolutionRate FROM FeedbackTicket WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2872, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2873 | Show students with both transport and hostel ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show students with both transport and hostel',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.TransportRequired = 1 AND sad.HostelRequired = 1 AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2873, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2874 | So, how many students belong to each religion? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, how many students belong to each religion?',
        @sql NVARCHAR(MAX) = N'SELECT sm.Religion_Name, COUNT(DISTINCT sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.Religion_Name ORDER BY StudentCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2874, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2875 | Can you show year-wise cancelled receipt count? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show year-wise cancelled receipt count?',
        @sql NVARCHAR(MAX) = N'SELECT bad.Name AS AcademicYear, COUNT(fc.Id) AS CancelledReceipts FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE fc.IsDeleted = 1 AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bad.Name ORDER BY bad.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2875, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2876 | Class 12 fee defaulters with outstanding more than 20000 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class 12 fee defaulters with outstanding more than 20000',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName + '' '' + sm.LastName AS StudentName, SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN Student_Master sm ON f.Student_ID = sm.ID WHERE f.ClassName IN (''Class 12'', ''XII'') AND f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.FirstName, sm.LastName HAVING SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) > 20000;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2876, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2877 | Leave type-wise count for this academic year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Leave type-wise count for this academic year',
        @sql NVARCHAR(MAX) = N'SELECT lt.Name AS LeaveType, COUNT(*) AS LeaveCount, SUM(lem.NoOfDays) AS TotalDays FROM LeaveEntryMaster lem INNER JOIN LeaveType lt ON lem.LeaveType_ID = lt.ID INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE ls.Name = ''Approved'' AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY lt.Name ORDER BY TotalDays DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2877, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2878 | New admissions who are also using transport - class wise count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'New admissions who are also using transport - class wise count',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(DISTINCT sad.StudentID) AS NewTransportStudents FROM StudentAcademicDetail sad JOIN ClassMaster cm ON sad.ClassID = cm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNewAdmission = 1 AND sad.TransportRequired = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name, cm.DisplayOrder ORDER BY cm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2878, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2879 | Give me a list of transport routes with their boarding points ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me a list of transport routes with their boarding points',
        @sql NVARCHAR(MAX) = N'SELECT rm.Name AS RouteName, bpm.Name AS BoardingPoint FROM Route_Master rm INNER JOIN Route_MasterDetails rmd ON rm.ID = rmd.Route_ID INNER JOIN BoardingPoint_Master bpm ON rmd.BoardingPoint_ID = bpm.Id WHERE rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (rm.IsDeleted IS NULL OR rm.IsDeleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2879, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2880 | Which class has the highest pending fees? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which class has the highest pending fees?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 fisd.ClassName, ISNULL(SUM((fisd.Amount - ISNULL(fisd.Concession_Amt, 0) - ISNULL(fisd.Paid_Amt, 0))), 0) AS Outstanding FROM FeesInformationStudentDetail fisd JOIN StudentAcademicDetail sad ON fisd.Student_ID = sad.StudentID AND fisd.AcademicYearID = sad.AcademicYearID AND sad.IsActive = 1 WHERE (fisd.Amount - ISNULL(fisd.Concession_Amt, 0) - ISNULL(fisd.Paid_Amt, 0)) > 0 AND fisd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fisd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY fisd.ClassName ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2880, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2881 | Ratio of hold to active staff ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Ratio of hold to active staff',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CASE WHEN em.IsHold = 1 THEN 1 ELSE 0 END) AS HoldStaff, SUM(CASE WHEN em.IsHold = 0 OR em.IsHold IS NULL THEN 1 ELSE 0 END) AS ActiveStaff, CAST(SUM(CASE WHEN em.IsHold = 1 THEN 1 ELSE 0 END) * 1.0 / NULLIF(SUM(CASE WHEN em.IsHold = 0 OR em.IsHold IS NULL THEN 1 ELSE 0 END), 0) AS DECIMAL(5,4)) AS HoldToActiveRatio FROM Staff_Master sm LEFT JOIN EmployeeMaster em ON sm.Staff_ID = em.StaffID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2881, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2882 | Hey, what's the admission conversion rate from enquiries? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the admission conversion rate from enquiries?',
        @sql NVARCHAR(MAX) = N'DECLARE @StatusConverted bigint = (SELECT TOP 1 ID FROM Enquiry_Status_Master WHERE Name = ''Completed'');
WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT CAST(COUNT(CASE WHEN CallStatus_ID = @StatusConverted THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS ConversionRatePercent FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2882, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2883 | How many students paid for April month specifically? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students paid for April month specifically?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT fc.Student_ID) AS StudentsPaidForApril FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.FromMonthName = ''April'' AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2883, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2884 | How many staff use each bank? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many staff use each bank?',
        @sql NVARCHAR(MAX) = N'SELECT BankName, COUNT(*) AS StaffCount FROM EmployeeMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0 AND BankName IS NOT NULL GROUP BY BankName ORDER BY StaffCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2884, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2885 | Who is the topper in Mathematics for Class 10? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who is the topper in Mathematics for Class 10?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 pc.StudentName AS StudentName, pc.Marks FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE pc.SubjectName = ''Maths'' AND cm.Name IN (''Class 10'', ''X'') AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) ORDER BY pc.Marks DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2885, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2886 | Show homework with short deadlines (due within 1 day of assignment). ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show homework with short deadlines (due within 1 day of assignment).',
        @sql NVARCHAR(MAX) = N'SELECT h.Remarks AS Title, cm.Name AS ClassName, sub.Name AS SubjectName, h.AssignmentDate AS AssignedDate, h.SubmissionDate AS DueDate FROM HomeWorkAndAssignment h INNER JOIN ClassMaster cm ON h.Class_ID = cm.ID INNER JOIN Subject_Master sub ON h.Subject_ID = sub.Id WHERE h.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND h.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (h.IsDeleted = 0 OR h.IsDeleted IS NULL) AND DATEDIFF(DAY, h.AssignmentDate, h.SubmissionDate) <= 1 ORDER BY h.AssignmentDate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2886, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2887 | How many students scored zero in any exam? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students scored zero in any exam?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT pc.StudentID) AS ZeroScorers FROM ProgressCardDataRetrieval pc WHERE pc.Marks = 0 AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2887, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2888 | What is the fee-wise outstanding for Term 1 in Class 6? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the fee-wise outstanding for Term 1 in Class 6?',
        @sql NVARCHAR(MAX) = N'SELECT Fees_Name, SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND ClassName = ''Class 6'' AND Term_Name IN (''Term 1'', ''I'') AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY Fees_Name ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2888, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2889 | I need to see stale enquiries older than 30 days still not converted ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see stale enquiries older than 30 days still not converted',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT CallRefNo, Parent_Name, Student_Name, MobileNo1, CallDate, DATEDIFF(DAY, CallDate, GETDATE()) AS DaysOld FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND CallStatus_ID IN (SELECT ID FROM Enquiry_Status_Master WHERE Name IN (''Initiated'', ''In Progress'')) AND DATEDIFF(DAY, CallDate, GETDATE()) > 30 ORDER BY CallDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2889, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2890 | Which class has the lowest pass percentage? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which class has the lowest pass percentage?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 c.Name AS ClassName, CAST(SUM(CASE WHEN smd.Marks >= eced.MinMark THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS PassPercentage FROM StudentMarkDetails smd INNER JOIN ExamConfigurationEvaluationDetails eced ON smd.EvalHierID = eced.ID INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ClassMaster c ON smm.ClassID = c.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND c.IsDeleted = 0 GROUP BY c.Name ORDER BY PassPercentage ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2890, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2891 | Staff category wise count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff category wise count',
        @sql NVARCHAR(MAX) = N'SELECT stm.Name AS StaffCategory, COUNT(*) AS StaffCount FROM Staff_Master sm INNER JOIN StaffType_Master stm ON sm.StaffType_ID = stm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sm.IsDeleted = 0 AND sm.StaffStatus_ID = 1 GROUP BY stm.Name ORDER BY StaffCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2891, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2892 | Students in SC/ST community ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students in SC/ST community',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.Community_Name, cm.Name AS ClassName FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (sm.Community_Name LIKE ''%SC%'' OR sm.Community_Name LIKE ''%ST%'') AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2892, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2893 | Students with F grade ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students with F grade',
        @sql NVARCHAR(MAX) = N'SELECT smd.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName, COUNT(*) AS FGradeCount FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN Student_Master stm ON smd.StudentID = stm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND smd.Grade = ''F'' GROUP BY smd.StudentID, stm.AdmissionNo, stm.FirstName, stm.LastName ORDER BY FGradeCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2893, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2894 | Can I see the standard deviation of marks class-wise? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can I see the standard deviation of marks class-wise?',
        @sql NVARCHAR(MAX) = N'SELECT c.Name AS ClassName, CAST(STDEV(smd.Marks) AS DECIMAL(5,2)) AS StdDevMarks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ClassMaster c ON smm.ClassID = c.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND c.IsDeleted = 0 GROUP BY c.Name ORDER BY c.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2894, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2895 | Number of non-teaching employees ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Number of non-teaching employees',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS NonTeachingStaff FROM Staff_Master sm INNER JOIN StaffType_Master stm ON sm.StaffType_ID = stm.ID INNER JOIN StaffTypeCategoryMaster stcm ON stm.Type_Id = stcm.Id WHERE stcm.Name IN (''Non-Academic'', ''Management'') AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sm.IsDeleted = 0 AND sm.StaffStatus_ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2895, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2896 | How much fee has been collected from Class 12 students? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much fee has been collected from Class 12 students?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fc.Receipt_Amt) AS Collected FROM FeesCollection fc INNER JOIN ClassMaster cm ON fc.Class_ID = cm.ID WHERE cm.Name IN (''Class 12'', ''XII'') AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2896, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2897 | What are the routes with their total fee collection potential? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What are the routes with their total fee collection potential?',
        @sql NVARCHAR(MAX) = N'SELECT rm.Name AS RouteName, COUNT(rmd.Id) AS Stops, SUM(bpm.Amount) AS TotalFeePotential FROM Route_Master rm INNER JOIN Route_MasterDetails rmd ON rm.ID = rmd.Route_ID INNER JOIN BoardingPoint_Master bpm ON rmd.BoardingPoint_ID = bpm.Id WHERE rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND rm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (rm.IsDeleted = 0 OR rm.IsDeleted IS NULL) GROUP BY rm.Name ORDER BY TotalFeePotential DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2897, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2898 | How many TCs are still pending from last month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many TCs are still pending from last month?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS PendingFromLastMonth FROM TCRequest tcr WHERE tcr.TC_Status = ''Pending'' AND MONTH(tcr.AppliedDate) = MONTH(DATEADD(MONTH, -1, GETDATE())) AND YEAR(tcr.AppliedDate) = YEAR(DATEADD(MONTH, -1, GETDATE())) AND tcr.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (tcr.IsDeleted IS NULL OR tcr.IsDeleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2898, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2899 | What is the fee outstanding for Class 3 Section D? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the fee outstanding for Class 3 Section D?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fisd.Amount - ISNULL(fisd.Paid_Amt,0)) AS Outstanding FROM FeesInformationStudentDetail fisd INNER JOIN SectionMaster secm ON fisd.SectionID = secm.ID WHERE fisd.IsIncludedInLumpSum <> 1 AND fisd.IsDonation = 0 AND fisd.ClassName IN (''Class 3'', ''III'') AND secm.Name = ''D'' AND (fisd.Amount - ISNULL(fisd.Paid_Amt,0)) > 0 AND fisd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2899, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2900 | Total outstanding for the Manapakkam campus ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total outstanding for the Manapakkam campus',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fisd.Amount - ISNULL(fisd.Concession_Amt,0) - ISNULL(fisd.Paid_Amt,0) - ISNULL(fisd.Lien_Amount,0)) AS Outstanding FROM FeesInformationStudentDetail fisd WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND fisd.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%Manapakkam%'' OR ShortName LIKE ''%Manapakkam%'')) AND fisd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
PRINT 'checkpoint: reached Q2900';
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2900, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2901 | What percentage of late fees charged have actually been collected? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What percentage of late fees charged have actually been collected?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(fcd.Paid_Amt) * 100.0 / NULLIF(SUM(fcd.LateFeeAmount), 0) AS DECIMAL(5,2)) AS LateFeeCollectionPercent FROM FeesCollection fc INNER JOIN FeesCollection_Details fcd ON fc.Id = fcd.Fees_Collection_ID WHERE fcd.LateFeeAmount > 0 AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2901, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2902 | Who topped the last exam? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who topped the last exam?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 pc.StudentName, SUM(pc.Marks) AS TotalMarks FROM ProgressCardDataRetrieval pc WHERE pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) GROUP BY pc.StudentName, pc.StudentID ORDER BY TotalMarks DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2902, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2903 | Just checking - how many enquiries in the last 30 days? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many enquiries in the last 30 days?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS EnquiriesLast30Days FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND CallDate >= DATEADD(DAY, -30, GETDATE());',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2903, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2904 | Let me see the student-wise breakdown of fees paid in Class 5 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see the student-wise breakdown of fees paid in Class 5',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.RollNo, SUM(fc.Receipt_Amt) AS TotalPaid FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID LEFT JOIN FeesCollection fc ON sm.ID = fc.Student_ID AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.AcademicYearID = sad.AcademicYearID WHERE cm.Name IN (''Class 5'', ''V'') AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.ID, sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo, sad.RollNo ORDER BY sad.RollNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2904, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2905 | Show students admitted after June 2025 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show students admitted after June 2025',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName, sm.AdmissionDate FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sm.AdmissionDate > ''2025-06-30'' AND sad.IsActive = 1 ORDER BY sm.AdmissionDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2905, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2906 | Show teachers who haven't assigned any homework this month. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show teachers who haven''t assigned any homework this month.',
        @sql NVARCHAR(MAX) = N'SELECT sm.Staff_FirstName + '' '' + sm.Staff_LastName AS TeacherName FROM Staff_Master sm WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sm.Staff_ID IN (SELECT DISTINCT Staff_ID FROM SubjectAllocation_Master WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL)) AND sm.Staff_ID NOT IN (SELECT DISTINCT Staff_ID FROM HomeWorkAndAssignment WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND MONTH(AssignmentDate) = MONTH(GETDATE()) AND YEAR(AssignmentDate) = YEAR(GETDATE()) AND (IsDeleted = 0 OR IsDeleted IS NULL));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2906, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2907 | What is the average fee per boarding point across all routes? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the average fee per boarding point across all routes?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(AVG(CAST(bpm.Amount AS FLOAT)), 2) AS AvgFeePerBoardingPoint FROM Route_Master rm INNER JOIN Route_MasterDetails rmd ON rm.ID = rmd.Route_ID INNER JOIN BoardingPoint_Master bpm ON rmd.BoardingPoint_ID = bpm.Id WHERE rm.IsDeleted = 0 AND rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2907, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2908 | How many routes have a vehicle assigned? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many routes have a vehicle assigned?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS RoutesWithVehicle FROM Route_Master WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND VehicleNo IS NOT NULL AND VehicleNo != '''';',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2908, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2909 | How was the attendance last Friday? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How was the attendance last Friday?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) AS PresentCount, COUNT(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 END) AS AbsentCount, CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AttendancePercent FROM StudentAttendance sa WHERE sa.Attendance_Date = DATEADD(DAY, -(DATEPART(WEEKDAY, GETDATE()) + 1), CAST(GETDATE() AS DATE)) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2909, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2910 | Salary range distribution of staff ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Salary range distribution of staff',
        @sql NVARCHAR(MAX) = N'SELECT CASE WHEN gem.NetPay < 20000 THEN ''Below 20K'' WHEN gem.NetPay BETWEEN 20000 AND 40000 THEN ''20K-40K'' WHEN gem.NetPay BETWEEN 40001 AND 60000 THEN ''40K-60K'' WHEN gem.NetPay BETWEEN 60001 AND 80000 THEN ''60K-80K'' ELSE ''Above 80K'' END AS SalaryRange, COUNT(*) AS StaffCount FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) GROUP BY CASE WHEN gem.NetPay < 20000 THEN ''Below 20K'' WHEN gem.NetPay BETWEEN 20000 AND 40000 THEN ''20K-40K'' WHEN gem.NetPay BETWEEN 40001 AND 60000 THEN ''40K-60K'' WHEN gem.NetPay BETWEEN 60001 AND 80000 THEN ''60K-80K'' ELSE ''Above 80K'' END;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2910, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2911 | How many students scoring centum in each subject do we have? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students scoring centum in each subject do we have?',
        @sql NVARCHAR(MAX) = N'SELECT s.Name AS Subject, COUNT(*) AS CentumCount FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN Subject_Master s ON s.BranchID = smd.BranchID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND s.IsDeleted = 0 AND smd.Marks = 100 GROUP BY s.Name ORDER BY CentumCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2911, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2912 | How many students have lumpsum fee payment? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students have lumpsum fee payment?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS lumpsum_students FROM StudentAcademicDetail sad WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.IsLumpsumApplicable = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2912, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2913 | Give me the house-wise student performance ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the house-wise student performance',
        @sql NVARCHAR(MAX) = N'SELECT sad.HouseName, CAST(AVG(smd.Marks) AS DECIMAL(5,2)) AS AvgMarks, COUNT(DISTINCT smd.StudentID) AS StudentCount FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN StudentAcademicDetail sad ON smd.StudentID = sad.StudentID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND sad.IsActive = 1 AND sad.HouseName IS NOT NULL GROUP BY sad.HouseName ORDER BY AvgMarks DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2913, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2914 | What percentage of enquiries are new versus converted? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What percentage of enquiries are new versus converted?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT esm.Name AS Status, COUNT(*) AS Cnt, ROUND(COUNT(*) * 100.0 / NULLIF(SUM(COUNT(*)) OVER(), 0), 2) AS Percentage FROM GeneralCallRegister em INNER JOIN Enquiry_Status_Master esm ON em.CallStatus_ID = esm.ID WHERE em.CallStatus_ID IN (SELECT ID FROM Enquiry_Status_Master WHERE Name IN (''Initiated'', ''Completed'')) AND em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND em.IsDeleted = 0 GROUP BY esm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2914, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2915 | Show top 20 fee defaulters with class and contact details. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show top 20 fee defaulters with class and contact details.',
        @sql NVARCHAR(MAX) = N'SELECT TOP 20 f.Student_ID, s.FirstName + '' '' + ISNULL(s.LastName, '''') AS StudentName, f.ClassName, f.SectionName, s.FatherContactNo, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID INNER JOIN Student_Master s ON f.Student_ID = s.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Student_ID, s.FirstName, s.LastName, f.ClassName, f.SectionName, s.FatherContactNo HAVING SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 0 ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2915, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2916 | Let me see the number of staff who have bank accounts registered ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see the number of staff who have bank accounts registered',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS StaffWithBankAccounts FROM EmployeeMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0 AND BankAccountNo IS NOT NULL AND BankAccountNo != '''';',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2916, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2917 | Grand total collection across all my branches this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Grand total collection across all my branches this month',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fc.Receipt_Amt) AS TotalCollection FROM FeesCollection fc WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND DATEPART(MONTH, fc.Bill_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, fc.Bill_Date) = DATEPART(YEAR, GETDATE()) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2917, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2918 | I need to see all transport students with their Class and parent details ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see all transport students with their Class and parent details',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, sad.RollNo, sm.FatherName, sm.FatherContactNo, sm.MotherName, sm.MotherContactNo FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.TransportRequired = 1 AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.ClassName, sad.RollNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2918, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2919 | List students for whom TC has already been handed over ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List students for whom TC has already been handed over',
        @sql NVARCHAR(MAX) = N'SELECT sad.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id INNER JOIN Student_Master stm ON sad.StudentID = stm.ID WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.IsTCIssued = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2919, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2920 | How many students have guardian contact but no parent contact? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students have guardian contact but no parent contact?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS GuardianOnlyStudents FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND (sm.FatherContactNo IS NULL OR sm.FatherContactNo = '''') AND (sm.MotherContactNo IS NULL OR sm.MotherContactNo = '''') AND sm.GuardianContactNo IS NOT NULL AND sm.GuardianContactNo != '''' AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2920, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2921 | How many enquiries are still pending follow-up? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many enquiries are still pending follow-up?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS PendingFollowUps FROM GeneralCallRegister WHERE CallStatus_ID IN (SELECT ID FROM Enquiry_Status_Master WHERE Name IN (''Initiated'', ''In Progress'')) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2921, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2922 | Pull up the admission funnel - from submitted to admitted ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up the admission funnel - from submitted to admitted',
        @sql NVARCHAR(MAX) = N'SELECT ''Application Submitted'' AS Stage, COUNT(*) AS [Count] FROM ApplicationEntry WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) UNION ALL SELECT ''Shortlisted'', COUNT(*) FROM ApplicationEntry ae INNER JOIN ApplicationStatus_Master asm ON ae.ApplicationStatus_ID = asm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) AND asm.Name IN (''Shortlisted'', ''Called For Interview'', ''Interview Completed'', ''Selection letter Sent'', ''Admitted'') UNION ALL SELECT ''Called For Interview'', COUNT(*) FROM ApplicationEntry ae INNER JOIN ApplicationStatus_Master asm ON ae.ApplicationStatus_ID = asm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) AND asm.Name IN (''Called For Interview'', ''Interview Completed'', ''Selection letter Sent'', ''Admitted'') UNION ALL SELECT ''Interview Completed'', COUNT(*) FROM ApplicationEntry ae INNER JOIN ApplicationStatus_Master asm ON ae.ApplicationStatus_ID = asm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) AND asm.Name IN (''Interview Completed'', ''Selection letter Sent'', ''Admitted'') UNION ALL SELECT ''Selection letter Sent'', COUNT(*) FROM ApplicationEntry ae INNER JOIN ApplicationStatus_Master asm ON ae.ApplicationStatus_ID = asm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) AND asm.Name IN (''Selection letter Sent'', ''Admitted'') UNION ALL SELECT ''Admitted'', COUNT(*) FROM ApplicationEntry ae INNER JOIN ApplicationStatus_Master asm ON ae.ApplicationStatus_ID = asm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) AND asm.Name = ''Admitted'';',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2922, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2923 | Show all active circulars currently in effect. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show all active circulars currently in effect.',
        @sql NVARCHAR(MAX) = N'SELECT ce.Title, ce.Description, ce.Circular_Date, ce.CircularApplicableFor AS TargetAudience, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS CreatedBy_Name FROM CircularEntry ce LEFT JOIN Staff_Master sm ON ce.Created_By = sm.Staff_ID WHERE ce.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ce.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND ce.Circular_Date >= DATEADD(DAY, -30, CAST(GETDATE() AS DATE)) AND (ce.IsDeleted = 0 OR ce.IsDeleted IS NULL) ORDER BY ce.Created_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2923, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2924 | What's the number of students who scored full marks (100) in any subject? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the number of students who scored full marks (100) in any subject?',
        @sql NVARCHAR(MAX) = N'SELECT pc.StudentName AS StudentName, pc.SubjectName AS SubjectName, cm.Name AS ClassName FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE pc.Marks = 100 AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2924, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2925 | List classes that have fewer than 5 subjects assigned. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List classes that have fewer than 5 subjects assigned.',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(DISTINCT cs.Subject_Id) AS SubjectCount FROM ClassSubjectDetails cs INNER JOIN ClassMaster cm ON cs.Class_Id = cm.ID WHERE cs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND cs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY cm.Name HAVING COUNT(DISTINCT cs.Subject_Id) < 5 ORDER BY SubjectCount;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2925, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2926 | Show the bottom 10 classes by collection amount ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the bottom 10 classes by collection amount',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 cm.Name AS ClassName, ISNULL(SUM(fc.Receipt_Amt), 0) AS TotalCollection FROM ClassMaster cm LEFT JOIN FeesCollection fc ON cm.ID = fc.Class_ID AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) WHERE cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND cm.IsDeleted = 0 GROUP BY cm.ID, cm.Name ORDER BY TotalCollection ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2926, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2927 | What is the average staff salary? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the average staff salary?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(AVG(gem.NetPay), 2) AS AvgSalary FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2927, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2928 | How many receipts were issued today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many receipts were issued today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TodayReceiptCount FROM FeesCollection fc WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2928, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2929 | Tell me about the late arrivals count today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Tell me about the late arrivals count today',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS LateArrivals FROM Staff_Attendance WHERE Attendance_Date = CAST(GETDATE() AS DATE) AND InTime > ''09:00'' AND Attendance_Status_ID = 1 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2929, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2930 | Students who scored below 50 in Mathematics Class 10 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students who scored below 50 in Mathematics Class 10',
        @sql NVARCHAR(MAX) = N'SELECT pc.StudentName AS StudentName, pc.Marks FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE pc.SubjectName = ''Maths'' AND cm.Name IN (''Class 10'', ''X'') AND pc.Marks < 50 AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) ORDER BY pc.Marks ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2930, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2931 | Can I see the percentage of new admissions vs total? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can I see the percentage of new admissions vs total?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(COUNT(CASE WHEN sad.IsNewAdmission = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS NewAdmissionPercent FROM StudentAcademicDetail sad WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2931, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2932 | Let me see the top 10 students with maximum pending fees ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see the top 10 students with maximum pending fees',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 f.Student_ID, sm.FirstName + '' '' + sm.LastName AS StudentName, SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN Student_Master sm ON f.Student_ID = sm.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY f.Student_ID, sm.FirstName, sm.LastName ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2932, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2933 | Show total salary cost per branch this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show total salary cost per branch this month',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS BranchName, SUM(gem.NetPay) AS TotalSalary FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID JOIN BranchMaster bm ON gm.BranchID = bm.ID WHERE gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) AND gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY TotalSalary DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2933, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2934 | Show defaulters in Class 10 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show defaulters in Class 10',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, sm.AdmissionNo, SUM(fcd.Remaining_Amt) AS outstanding FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Student_Master sm ON fc.Student_ID = sm.ID JOIN ClassMaster cm ON fc.Class_ID = cm.ID WHERE cm.Name IN (''Class 10'', ''X'') AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fcd.Remaining_Amt > 0 GROUP BY sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo ORDER BY SUM(fcd.Remaining_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2934, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2935 | Students with perfect attendance who also scored above 90 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students with perfect attendance who also scored above 90',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT pc.StudentName AS StudentName, cm.Name AS ClassName, pc.Marks FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE pc.Marks / pc.MaxMarks * 100 >= 90 AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) ORDER BY pc.Marks DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2935, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2936 | Let me see students with zero payment in Term 1 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see students with zero payment in Term 1',
        @sql NVARCHAR(MAX) = N'SELECT f.Student_ID, s.FirstName + '' '' + ISNULL(s.LastName, '''') AS StudentName, f.ClassName, SUM(f.Amount) AS Term1Demand FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID INNER JOIN Student_Master s ON f.Student_ID = s.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.Term_Name IN (''Term 1'', ''I'') AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Student_ID, s.FirstName, s.LastName, f.ClassName HAVING SUM(f.Paid_Amt) = 0 AND SUM(f.Amount) > 0 ORDER BY Term1Demand DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2936, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2937 | Are there any days without day closure entries this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Are there any days without day closure entries this month?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(d.Date AS DATE) AS MissingDate FROM (SELECT DATEADD(DAY, number, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)) AS Date FROM master.dbo.spt_values WHERE type = ''P'' AND number < DAY(GETDATE())) d WHERE DATEPART(WEEKDAY, d.Date) NOT IN (1, 7) AND NOT EXISTS (SELECT 1 FROM DayclosureMaster dc WHERE dc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND CAST(dc.DayClosureDate AS DATE) = CAST(d.Date AS DATE) AND (dc.IsDeleted = 0 OR dc.IsDeleted IS NULL));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2937, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2938 | Students whose section was changed and who have pending fees ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students whose section was changed and who have pending fees',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT f.Student_ID, sm.FirstName + '' '' + sm.LastName AS StudentName FROM FeesInformationStudentDetail f INNER JOIN Student_Master sm ON f.Student_ID = sm.ID INNER JOIN StudentAcademicDetail sad ON f.Student_ID = sad.StudentID WHERE sad.IsSectionChanged = 1 AND f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2938, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2939 | Hey, percentage of students below Class average per class ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, percentage of students below Class average per class',
        @sql NVARCHAR(MAX) = N'SELECT c.Name AS ClassName, CAST(SUM(CASE WHEN smd.Marks < ca.ClassAvg THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS BelowAvgPct FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ClassMaster c ON smm.ClassID = c.ID INNER JOIN (SELECT smm2.ClassID, AVG(smd2.Marks) AS ClassAvg FROM StudentMarkDetails smd2 INNER JOIN StudentMarkMaster smm2 ON smd2.HeaderID = smm2.ID WHERE smd2.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd2.Deleted = 0 AND smm2.Deleted = 0 GROUP BY smm2.ClassID) ca ON smm.ClassID = ca.ClassID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND c.IsDeleted = 0 GROUP BY c.Name ORDER BY c.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2939, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2940 | List all staff children enrolled currently with their class details ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all staff children enrolled currently with their class details',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, sad.RollNo, sm.FatherName, sm.MotherName FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sm.StaffChild = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.ClassName, sad.RollNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2940, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2941 | What's our fee recovery looking like? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s our fee recovery looking like?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fcd.Paid_Amt), 0) AS TotalCollected, ISNULL(SUM(fcd.Fees_Amount), 0) AS TotalDemand, CAST(ISNULL(SUM(fcd.Paid_Amt), 0) * 100.0 / NULLIF(SUM(fcd.Fees_Amount), 0) AS DECIMAL(5,2)) AS RecoveryPercent FROM FeesCollection_Details fcd WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2941, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2942 | What are the all exam terms? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What are the all exam terms?',
        @sql NVARCHAR(MAX) = N'SELECT Name AS TermName FROM ExamTermMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND Deleted = 0 ORDER BY Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2942, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2943 | What are the staff department-wise with their headcounts? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What are the staff department-wise with their headcounts?',
        @sql NVARCHAR(MAX) = N'SELECT dm.Name AS Department, COUNT(DISTINCT sdmd.StaffID) AS StaffCount FROM StaffDepartmentMapping sdm INNER JOIN StaffDepartmentMappingDetail sdmd ON sdm.Id = sdmd.MappingID INNER JOIN StaffDepartmentMaster dm ON sdm.DepartmentID = dm.Id WHERE sdm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sdm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (sdm.IsDeleted = 0 OR sdm.IsDeleted IS NULL) GROUP BY dm.Name ORDER BY dm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2943, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2944 | Can you show suspended students count per branch today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show suspended students count per branch today?',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, COUNT(*) AS Suspended FROM StudentAttendance sa JOIN BranchMaster bm ON sa.BranchID = bm.ID WHERE sa.Attendance_Status_ID = 7 AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY Suspended DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2944, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2945 | What's the students admitted in June 2025? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the students admitted in June 2025?',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sm.AdmissionDate, sad.ClassName FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND MONTH(sm.AdmissionDate) = 6 AND YEAR(sm.AdmissionDate) = 2025;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2945, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2946 | How many students in each fee category? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students in each fee category?',
        @sql NVARCHAR(MAX) = N'SELECT sad.StudentFeeCategoryID, COUNT(sad.Id) AS StudentCount FROM StudentAcademicDetail sad WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) GROUP BY sad.StudentFeeCategoryID ORDER BY COUNT(sad.Id) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2946, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2947 | Teaching staff salary bill ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Teaching staff salary bill',
        @sql NVARCHAR(MAX) = N'SELECT SUM(gem.NetPay) AS TeachingSalaryBill FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) AND gm.StaffTypeName = ''Teaching'';',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2947, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2948 | What is the outstanding for primary classes (1-5)? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the outstanding for primary classes (1-5)?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS PrimaryOutstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND ClassName IN (''Class 1'', ''Class 2'', ''Class 3'', ''Class 4'', ''Class 5'') AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2948, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2949 | How many TCs were given out each month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many TCs were given out each month?',
        @sql NVARCHAR(MAX) = N'SELECT MONTH(sad.TCIssuedDate) AS Month, COUNT(DISTINCT sad.StudentID) AS TCIssued FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsTCIssued = 1 AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY MONTH(sad.TCIssuedDate) ORDER BY Month;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2949, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2950 | What is the admission conversion rate? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the admission conversion rate?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(CASE WHEN asm.Name = ''Admitted'' THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS ConversionRate FROM ApplicationEntry ae INNER JOIN ApplicationStatus_Master asm ON ae.ApplicationStatus_ID = asm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2950, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2951 | Year-wise annual discount amount given to students ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Year-wise annual discount amount given to students',
        @sql NVARCHAR(MAX) = N'SELECT bad.Name AS AcademicYear, SUM(fc.AnnualDiscount_Amt) AS TotalAnnualDiscount FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.IsAnnualDiscountApplied = 1 AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bad.Name ORDER BY bad.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2951, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2952 | Will attendance improve next month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Will attendance improve next month?',
        @sql NVARCHAR(MAX) = N'-- This question asks for a future prediction, which I cannot provide. I can only query existing data.
-- Here''s the attendance trend for recent months:
SELECT DATENAME(MONTH, sa.Attendance_Date) AS MonthName, CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AttendancePercent FROM StudentAttendance sa WHERE sa.Attendance_Date >= DATEADD(MONTH, -3, GETDATE()) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY DATENAME(MONTH, sa.Attendance_Date), MONTH(sa.Attendance_Date) ORDER BY MONTH(sa.Attendance_Date);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2952, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2953 | How many buses do we have running? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many buses do we have running?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalVehicles FROM VehicleMaster WHERE (IsDeleted IS NULL OR IsDeleted = 0) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2953, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2954 | Class-wise count of students who left school ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class-wise count of students who left school',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(DISTINCT sad.StudentID) AS StudentsLeft FROM StudentAcademicDetail sad JOIN ClassMaster cm ON sad.ClassID = cm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsTCIssued = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name, cm.DisplayOrder ORDER BY cm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2954, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2955 | Just checking - how many drivers have expired licenses? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many drivers have expired licenses?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS ExpiredLicenses FROM DriverMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND License_Expiry_Date < GETDATE();',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2955, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2956 | What exam terms exist for the current year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What exam terms exist for the current year?',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT etm.Name, etm.Code FROM ExamTermMaster etm WHERE etm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (etm.Deleted IS NULL OR etm.Deleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2956, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2957 | Can you show me the salary numbers real quick? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show me the salary numbers real quick?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS StaffCount, SUM(gem.NetPay) AS TotalSalary, CAST(AVG(gem.NetPay) AS DECIMAL(12,2)) AS AvgSalary, MAX(gem.NetPay) AS MaxSalary, MIN(gem.NetPay) AS MinSalary FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2957, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2958 | I need to see month-wise total collection from day closure records ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see month-wise total collection from day closure records',
        @sql NVARCHAR(MAX) = N'WITH dc AS (SELECT dm.ID, dm.DayClosureDate AS ClosureDate, dm.CollectedByName AS ClosedBy_Name, SUM(dmd.CollectedAmount) AS TotalCollection, SUM(CASE WHEN cmm.Name = ''Cash'' THEN dmd.CollectedAmount ELSE 0 END) AS CashCollection, SUM(CASE WHEN cmm.Name = ''Bank Online Transfer'' THEN dmd.CollectedAmount ELSE 0 END) AS OnlineCollection, SUM(CASE WHEN cmm.Name NOT IN (''Cash'', ''Bank Online Transfer'', ''Cheque'') THEN dmd.CollectedAmount ELSE 0 END) AS OtherCollection, SUM(CASE WHEN cmm.Name = ''Cheque'' THEN dmd.CollectedAmount ELSE 0 END) AS ChequeCollection FROM DayclosureMaster dm INNER JOIN DayclosureMaster_Details dmd ON dmd.HeaderID = dm.ID LEFT JOIN CollectionMode_Master cmm ON dmd.CollectionMode_ID = cmm.ID WHERE dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (dm.IsDeleted = 0 OR dm.IsDeleted IS NULL) AND (dmd.IsDeleted = 0 OR dmd.IsDeleted IS NULL) GROUP BY dm.ID, dm.DayClosureDate, dm.CollectedByName) SELECT FORMAT(ClosureDate, ''yyyy-MM'') AS [Month], SUM(TotalCollection) AS MonthlyTotal, SUM(CashCollection) AS MonthlyCash, SUM(OnlineCollection) AS MonthlyOnline FROM dc GROUP BY FORMAT(ClosureDate, ''yyyy-MM'') ORDER BY [Month];',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2958, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2959 | List applications scheduled for interview. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List applications scheduled for interview.',
        @sql NVARCHAR(MAX) = N'SELECT ae.ApplicationNo, ae.FirstName + ISNULL('' '' + ae.MiddleName, '''') + '' '' + ae.LastName AS StudentName, ae.FatherName, ae.MotherName, ae.ComMobile AS Phone, cm.Name AS ClassApplied FROM ApplicationEntry ae INNER JOIN ClassMaster cm ON ae.Student_ClassID = cm.ID INNER JOIN ApplicationStatus_Master asm ON ae.ApplicationStatus_ID = asm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) AND asm.Name = ''Called For Interview'' ORDER BY ae.ApplicationDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2959, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2960 | What's Class 5 attendance today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s Class 5 attendance today?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS present, SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END) AS absent, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS pct FROM StudentAttendance sa JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND cm.Name IN (''Class 5'', ''V'') AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2960, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2961 | What is the overall enquiry conversion rate this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the overall enquiry conversion rate this year?',
        @sql NVARCHAR(MAX) = N'DECLARE @StatusConverted bigint = (SELECT TOP 1 ID FROM Enquiry_Status_Master WHERE Name = ''Completed'');
WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT ROUND(SUM(CASE WHEN CallStatus_ID = @StatusConverted THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0), 2) AS ConversionRate FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2961, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2962 | Show me enquiries from this quarter. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me enquiries from this quarter.',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS EnquiriesThisQuarter FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND DATEPART(QUARTER, CallDate) = DATEPART(QUARTER, GETDATE()) AND YEAR(CallDate) = YEAR(GETDATE());',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2962, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2963 | How many enquiries did we receive this week? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many enquiries did we receive this week?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS EnquiriesThisWeek FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND CallDate >= DATEADD(DAY, 1-DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2963, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2964 | List students in Class 10 with outstanding greater than 5000. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List students in Class 10 with outstanding greater than 5000.',
        @sql NVARCHAR(MAX) = N'SELECT f.Student_ID, sm.FirstName, sm.LastName, sm.AdmissionNo, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN Student_Master sm ON f.Student_ID = sm.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.ClassName = ''Class 10'' AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY f.Student_ID, sm.FirstName, sm.LastName, sm.AdmissionNo HAVING SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 5000 ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2964, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2965 | Show me all hostel students from Class 9 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me all hostel students from Class 9',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.RollNo, secm.Name, sm.FatherContactNo FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID INNER JOIN SectionMaster secm ON sad.SectionID = secm.ID WHERE cm.Name IN (''Class 9'', ''IX'') AND sad.HostelRequired = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.RollNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2965, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2966 | Just tell me the attendance situation ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just tell me the attendance situation',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CASE WHEN Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS Present, SUM(CASE WHEN Attendance_Status_ID = 2 THEN 1 ELSE 0 END) AS Absent, CAST(SUM(CASE WHEN Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS AttendancePct FROM Staff_Attendance WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND Attendance_Date = CAST(GETDATE() AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2966, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2967 | Can you show concession given for each fee type? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show concession given for each fee type?',
        @sql NVARCHAR(MAX) = N'SELECT FeesType_Name, SUM(ISNULL(Concession_Amt, 0)) AS ConcessionAmount FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY FeesType_Name ORDER BY ConcessionAmount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2967, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2968 | How many refunds were processed today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many refunds were processed today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TodayRefunds, ISNULL(SUM(Refund_Amt), 0) AS TodayAmount FROM RefundReceipt WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND CAST(Bill_Date AS DATE) = CAST(GETDATE() AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2968, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2969 | What's the maximum concession given to a single student? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the maximum concession given to a single student?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 FeesInformationStudentDetail.Student_ID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName, SUM(ISNULL(Concession_Amt, 0)) AS MaxConcession FROM FeesInformationStudentDetail INNER JOIN Student_Master stm ON FeesInformationStudentDetail.Student_ID = stm.ID WHERE FeesInformationStudentDetail.IsIncludedInLumpSum <> 1 AND FeesInformationStudentDetail.IsDonation = 0 AND FeesInformationStudentDetail.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND FeesInformationStudentDetail.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY FeesInformationStudentDetail.Student_ID, stm.AdmissionNo, stm.FirstName, stm.LastName ORDER BY MaxConcession DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2969, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2970 | How much was collected in July against the demand? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much was collected in July against the demand?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(f.Amount) AS Demand, SUM(f.Paid_Amt) AS Collected, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.Month_Name = ''July'' AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2970, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2971 | How much concession was given this academic year so far? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much concession was given this academic year so far?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fcd.Concession_Amount), 0) AS TotalConcession FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2971, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2972 | Sections with less than 20 students ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Sections with less than 20 students',
        @sql NVARCHAR(MAX) = N'SELECT sad.ClassName, secm.Name AS SectionName, COUNT(sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad INNER JOIN SectionMaster secm ON sad.SectionID = secm.ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) GROUP BY sad.ClassName, secm.Name HAVING COUNT(sad.StudentID) < 20;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2972, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2973 | Same for Class 10? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Same for Class 10?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(sad.Id) AS StudentCount FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.Name IN (''Class 10'', ''X'') AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2973, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2974 | Show daily admission count for this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show daily admission count for this month',
        @sql NVARCHAR(MAX) = N'SELECT CAST(sm.AdmissionDate AS DATE) AS AdmissionDay, COUNT(DISTINCT sad.StudentID) AS Admissions FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNewAdmission = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND MONTH(sm.AdmissionDate) = MONTH(GETDATE()) AND YEAR(sm.AdmissionDate) = YEAR(GETDATE()) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY CAST(sm.AdmissionDate AS DATE) ORDER BY AdmissionDay;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2974, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2975 | Show newly admitted VIP students ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show newly admitted VIP students',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, sm.AdmissionDate FROM Student_Master sm JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNewAdmission = 1 AND sm.IsVIP = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sm.AdmissionDate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2975, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2976 | Total paisa collected so far? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total paisa collected so far?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fc.Receipt_Amt) AS TotalCollected FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2976, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2977 | Average homework per day this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Average homework per day this month',
        @sql NVARCHAR(MAX) = N'SELECT CAST(COUNT(*) * 1.0 / NULLIF(COUNT(DISTINCT CAST(hwa.AssignmentDate AS DATE)), 0) AS DECIMAL(5,2)) AS AvgPerDay FROM HomeWorkAndAssignment hwa WHERE MONTH(hwa.AssignmentDate) = MONTH(GETDATE()) AND YEAR(hwa.AssignmentDate) = YEAR(GETDATE()) AND (hwa.IsDeleted IS NULL OR hwa.IsDeleted = 0) AND hwa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hwa.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2977, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2978 | Handler-wise conversion rate. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Handler-wise conversion rate.',
        @sql NVARCHAR(MAX) = N'DECLARE @StatusConverted bigint = (SELECT TOP 1 ID FROM Enquiry_Status_Master WHERE Name = ''Completed'');
WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT HandledBy_ID, COUNT(*) AS Total, COUNT(CASE WHEN CallStatus_ID = @StatusConverted THEN 1 END) AS Converted, CAST(COUNT(CASE WHEN CallStatus_ID = @StatusConverted THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS ConversionRate FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL) GROUP BY HandledBy_ID ORDER BY ConversionRate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2978, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2979 | How many students owe between 10000 and 50000? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students owe between 10000 and 50000?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS student_count FROM (SELECT fc.Student_ID, SUM(fcd.Remaining_Amt) AS total_pending FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN StudentAcademicDetail sad ON fc.Student_ID = sad.StudentID AND fc.AcademicYearID = sad.AcademicYearID WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fcd.Remaining_Amt > 0 AND sad.IsActive = 1 GROUP BY fc.Student_ID HAVING SUM(fcd.Remaining_Amt) BETWEEN 10000 AND 50000) AS t;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2979, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2980 | Can you show me collection totals and student totals side by side per branch? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show me collection totals and student totals side by side per branch?',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, (SELECT COUNT(*) FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sm.BranchID = bm.ID AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL)) AS Students, (SELECT SUM(fc.Receipt_Amt) FROM FeesCollection fc WHERE fc.BranchID = bm.ID AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4)) AS Collection FROM BranchMaster bm WHERE bm.ID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY bm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2980, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2981 | Let me see term-wise pass percentage comparison ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see term-wise pass percentage comparison',
        @sql NVARCHAR(MAX) = N'SELECT pc.TermName AS TermName, CAST(SUM(CASE WHEN pc.Marks >= pc.MinMark THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS PassPercentage FROM ProgressCardDataRetrieval pc WHERE pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) GROUP BY pc.TermName ORDER BY pc.TermName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2981, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2982 | What percent of admissions this year are in primary classes? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What percent of admissions this year are in primary classes?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(COUNT(CASE WHEN cm.Name IN (''Class 1'', ''Class 2'', ''Class 3'', ''Class 4'', ''Class 5'') THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS PrimaryAdmissionPercent FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsNewAdmission = 1 AND sad.IsActive = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2982, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2983 | Show me names of all absentees today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me names of all absentees today',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName, secm.Name AS SectionName, sa.StudentRollNo FROM Student_Master sm INNER JOIN StudentAttendance sa ON sm.ID = sa.Student_ID INNER JOIN ClassMaster cm ON sa.Class_ID = cm.ID INNER JOIN SectionMaster secm ON sa.Section_ID = secm.ID WHERE sa.Attendance_Date = CAST(GETDATE() AS DATE) AND sa.Attendance_Status_ID = 2 AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY cm.Name, sa.StudentRollNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2983, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2984 | What's cooking in Class 5? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s cooking in Class 5?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(sad.Id) AS Strength, COUNT(CASE WHEN sm.Gender IN (''Male'', ''Boy'') THEN 1 END) AS Boys, COUNT(CASE WHEN sm.Gender IN (''Female'', ''Girl'') THEN 1 END) AS Girls FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.Name IN (''Class 5'', ''V'') AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2984, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2985 | List top 10 students with highest outstanding fees along with their phone numbers. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List top 10 students with highest outstanding fees along with their phone numbers.',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 f.Student_ID, s.FirstName + '' '' + ISNULL(s.LastName, '''') AS StudentName, f.ClassName, s.FatherContactNo, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID INNER JOIN Student_Master s ON f.Student_ID = s.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Student_ID, s.FirstName, s.LastName, f.ClassName, s.FatherContactNo HAVING SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 0 ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2985, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2986 | List students who failed in any subject this term ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List students who failed in any subject this term',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT smd.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName FROM StudentMarkDetails smd INNER JOIN ExamConfigurationEvaluationDetails eced ON smd.EvalHierID = eced.ID INNER JOIN Student_Master stm ON smd.StudentID = stm.ID WHERE smd.Marks < eced.MinMark AND smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (smd.Deleted IS NULL OR smd.Deleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2986, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2987 | In which year did we have the highest number of new admissions? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'In which year did we have the highest number of new admissions?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 bad.Name AS AcademicYear, COUNT(DISTINCT sad.StudentID) AS NewAdmissions FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNewAdmission = 1 AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bad.Name ORDER BY NewAdmissions DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2987, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2988 | Can you show fee-type-wise collection rate? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show fee-type-wise collection rate?',
        @sql NVARCHAR(MAX) = N'SELECT f.FeesType_Name, ROUND(SUM(f.Paid_Amt) * 100.0 / NULLIF(SUM(f.Amount), 0), 2) AS CollectionRate FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.FeesType_Name ORDER BY CollectionRate ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2988, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2989 | Just checking - how many students have received fee concessions? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many students have received fee concessions?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT f.Student_ID) AS StudentsWithConcession FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND ISNULL(f.Concession_Amt, 0) > 0 AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2989, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2990 | I need the students paying through DD mode ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need the students paying through DD mode',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, fc.Receipt_Amt, fc.Bill_Date FROM FeesCollection fc INNER JOIN Student_Master sm ON fc.Student_ID = sm.ID WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.Collection_Mode_ID IN (SELECT ID FROM CollectionMode_Master WHERE Name = ''DD'') AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) ORDER BY fc.Bill_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2990, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2991 | Transport users growth - this year vs previous year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Transport users growth - this year vs previous year',
        @sql NVARCHAR(MAX) = N'SELECT ''Current Year'' AS Period, COUNT(DISTINCT sad.StudentID) AS TransportUsers FROM StudentAcademicDetail sad WHERE sad.TransportRequired = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) UNION ALL SELECT ''Previous Year'' AS Period, COUNT(DISTINCT sad.StudentID) AS TransportUsers FROM StudentAcademicDetail sad WHERE sad.TransportRequired = 1 AND sad.AcademicYearID IN (SELECT PreviousYearID FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2991, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2992 | Section-wise collection for Class 9 this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Section-wise collection for Class 9 this year',
        @sql NVARCHAR(MAX) = N'SELECT secm.Name AS SectionName, SUM(fc.Receipt_Amt) AS total_collected FROM FeesCollection fc JOIN ClassMaster cm ON fc.Class_ID = cm.ID JOIN SectionMaster secm ON fc.Section_ID = secm.ID WHERE cm.Name IN (''Class 9'', ''IX'') AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY secm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2992, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2993 | Homework pending for submission today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Homework pending for submission today',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, secm.Name AS Section, sub.Name AS Subject, hwa.Remarks FROM HomeWorkAndAssignment hwa INNER JOIN ClassMaster cm ON hwa.Class_ID = cm.ID INNER JOIN SectionMaster secm ON hwa.Section_ID = secm.ID INNER JOIN Subject_Master sub ON hwa.Subject_ID = sub.Id WHERE CAST(hwa.SubmissionDate AS DATE) = CAST(GETDATE() AS DATE) AND (hwa.IsDeleted IS NULL OR hwa.IsDeleted = 0) AND hwa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hwa.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2993, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2994 | Collection between 1st June and 15th June ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Collection between 1st June and 15th June',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS collection FROM FeesCollection fc WHERE fc.Bill_Date >= DATEFROMPARTS(CASE WHEN MONTH(GETDATE()) >= 4 THEN YEAR(GETDATE()) ELSE YEAR(GETDATE())-1 END + 0, 6, 1) AND fc.Bill_Date <= DATEFROMPARTS(CASE WHEN MONTH(GETDATE()) >= 4 THEN YEAR(GETDATE()) ELSE YEAR(GETDATE())-1 END + 0, 6, 15) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2994, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2995 | Give me the total outstanding vs total collected ratio ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the total outstanding vs total collected ratio',
        @sql NVARCHAR(MAX) = N'SELECT SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS TotalOutstanding, SUM(f.Paid_Amt) AS TotalCollected FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2995, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2996 | Pull up the fee type-wise collection summary real quick ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up the fee type-wise collection summary real quick',
        @sql NVARCHAR(MAX) = N'SELECT fcd.FeesType_Name, SUM(fcd.Paid_Amt) AS Collected FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fcd.FeesType_Name ORDER BY Collected DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2996, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2997 | Hey, how many TCs were given out each month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many TCs were given out each month?',
        @sql NVARCHAR(MAX) = N'SELECT MONTH(sad.TCIssuedDate) AS Month, COUNT(DISTINCT sad.StudentID) AS TCIssued FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsTCIssued = 1 AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY MONTH(sad.TCIssuedDate) ORDER BY Month;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2997, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2998 | Any students marked as VIP who haven't paid fees? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Any students marked as VIP who haven''t paid fees?',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sm.IsVIP = 1 AND sm.ID NOT IN (SELECT DISTINCT fc.Student_ID FROM FeesCollection fc WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2998, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q2999 | How many fees yet to be collected are there? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many fees yet to be collected are there?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))), 0) AS amount_yet_to_collect FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (2999, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q3000 | Which day this month had the lowest attendance? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which day this month had the lowest attendance?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 CAST(sa.Attendance_Date AS DATE) AS date, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS pct FROM StudentAttendance sa WHERE DATEPART(MONTH, sa.Attendance_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, sa.Attendance_Date) = DATEPART(YEAR, GETDATE()) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY CAST(sa.Attendance_Date AS DATE) ORDER BY pct ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
PRINT 'checkpoint: reached Q3000';
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (3000, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ===================== PART 6 SUMMARY (Q2501-Q3000) =====================
DECLARE @lo INT = 2501, @hi INT = 3000, @fails INT;
SELECT @fails = COUNT(*) FROM #ai_errors WHERE qid BETWEEN @lo AND @hi;
PRINT 'PART 6 done: ' + CAST((@hi - @lo + 1) AS VARCHAR(6)) + ' queries, '
    + CAST(@fails AS VARCHAR(6)) + ' failed.';
DECLARE @qid INT, @qq NVARCHAR(300), @ee NVARCHAR(2048);
DECLARE c CURSOR LOCAL FAST_FORWARD FOR
    SELECT qid, question, error FROM #ai_errors WHERE qid BETWEEN @lo AND @hi ORDER BY qid;
OPEN c;
FETCH NEXT FROM c INTO @qid, @qq, @ee;
WHILE @@FETCH_STATUS = 0
BEGIN
    PRINT 'Q' + CAST(@qid AS VARCHAR(6)) + ' FAILED: ' + LEFT(@ee, 300);
    PRINT '   question: ' + LEFT(@qq, 200);
    FETCH NEXT FROM c INTO @qid, @qq, @ee;
END
CLOSE c; DEALLOCATE c;
SELECT qid, question, error, ms FROM #ai_errors WHERE qid BETWEEN @lo AND @hi ORDER BY qid;
GO

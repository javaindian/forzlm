/* =====================================================================
   ChaloSchools AI Secretary - v28 dataset local test (SSMS)
   Part 9 of 9: queries Q4001 to Q4034 (34 of 4034 in the full dataset)
   Source: semantic_validation/reference_inputs/training_dataset_final_v28.jsonl
   Generated: 2026-09-04
   The SQL text is EXACTLY what the dataset holds (single quotes appear
   doubled inside the @sql string - T-SQL string escaping; multi-line
   queries keep line breaks, which SQL Server counts as whitespace).
   So any error you see here is an error the trained model would produce.

   ONE SETTING TO CHANGE BEFORE RUNNING:
     The queries are security-scoped to a user, like in production. They run
     as @UserId. Change it to YOUR local user id:
       Find & Replace across these files:   @UserId INT = 1
       (see your users with:  SELECT ID, UserName FROM UserAccountMaster;)
     @SelectedBranchId NULL = all branches you are allowed; put a branch id
       there to simulate one selected branch.

   RECOMMENDED for big runs (stops 500 result grids appearing):
     Query menu > Query Options... > Results > Grid >
     tick 'Discard results after execution', then Execute (F5).
     Everything still runs; errors + summary appear in the Messages tab.
   Failures (INCLUDING compile-time errors - bad syntax, unknown columns,
   unknown tables - thanks to the sp_executesql wrapper) are printed as:
     Q### FAILED: <error text>
        question: <the natural-language question>
   and stored in table #ai_errors until you close the connection.
   ===================================================================== */
SET NOCOUNT ON;
GO
IF OBJECT_ID('tempdb..#ai_errors') IS NULL
    CREATE TABLE #ai_errors (
        qid      INT NOT NULL PRIMARY KEY,
        question NVARCHAR(300),
        error    NVARCHAR(2048),
        ms       INT NOT NULL
    );
GO
-- ============ Q4001 | Compare fee collection this week vs last week ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare fee collection this week vs last week',
        @sql NVARCHAR(MAX) = N'SELECT ''This Week'' AS Period, ISNULL(SUM(fc.Receipt_Amt), 0) AS Collection FROM FeesCollection fc WHERE DATEDIFF(WEEK, fc.Bill_Date, GETDATE()) = 0 AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) UNION ALL SELECT ''Last Week'' AS Period, ISNULL(SUM(fc.Receipt_Amt), 0) AS Collection FROM FeesCollection fc WHERE DATEDIFF(WEEK, fc.Bill_Date, GETDATE()) = 1 AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4001, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4002 | Compare present vs absent students today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare present vs absent students today',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS PresentCount, SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END) AS AbsentCount FROM StudentAttendance sa WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4002, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4003 | Compare today's attendance with yesterday's attendance ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare today''s attendance with yesterday''s attendance',
        @sql NVARCHAR(MAX) = N'SELECT ''Today'' AS DayLabel, SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS PresentCount FROM StudentAttendance sa WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) UNION ALL SELECT ''Yesterday'' AS DayLabel, SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS PresentCount FROM StudentAttendance sa WHERE CAST(sa.Attendance_Date AS DATE) = CAST(DATEADD(DAY, -1, GETDATE()) AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4003, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4004 | Compare teaching vs non teaching staff ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare teaching vs non teaching staff',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CASE WHEN stm.Name = ''Teaching'' THEN 1 ELSE 0 END) AS TeachingStaff, SUM(CASE WHEN stm.Name <> ''Teaching'' THEN 1 ELSE 0 END) AS NonTeachingStaff FROM Staff_Master stf INNER JOIN StaffType_Master stm ON stf.StaffType_ID = stm.ID WHERE stf.StaffStatus_ID = 1 AND (stf.IsDeleted IS NULL OR stf.IsDeleted = 0) AND stf.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4004, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4005 | Compare admission enquiries this week vs last week ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare admission enquiries this week vs last week',
        @sql NVARCHAR(MAX) = N'SELECT ''This Week'' AS Period, COUNT(*) AS EnquiryCount FROM GeneralCallRegister gcr WHERE gcr.CallDate >= DATEADD(DAY, 1 - DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE)) AND gcr.CallDate <= CAST(GETDATE() AS DATE) AND (gcr.IsDeleted = 0 OR gcr.IsDeleted IS NULL) AND gcr.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) UNION ALL SELECT ''Last Week'' AS Period, COUNT(*) AS EnquiryCount FROM GeneralCallRegister gcr WHERE gcr.CallDate >= DATEADD(DAY, -6 - DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE)) AND gcr.CallDate <= DATEADD(DAY, -DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE)) AND (gcr.IsDeleted = 0 OR gcr.IsDeleted IS NULL) AND gcr.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4005, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4006 | List students who took TC this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List students who took TC this year',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName + '' '' + sm.LastName AS StudentName, sad.ClassName, sad.TCIssuedDate FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsTCIssued = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.TCIssuedDate DESC',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4006, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4007 | TC issued students from class 10 this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'TC issued students from class 10 this year',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName + '' '' + sm.LastName AS StudentName, sad.TCIssuedDate FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.IsTCIssued = 1 AND cm.Name = ''Class 10'' AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4007, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4008 | Students who received transfer certificates this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students who received transfer certificates this month',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName + '' '' + sm.LastName AS StudentName, sad.TCIssuedDate FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsTCIssued = 1 AND sad.TCIssuedDate >= DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.TCIssuedDate DESC',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4008, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4009 | How many new admissions are there this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many new admissions are there this year?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS NewAdmissions FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsNewAdmission = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4009, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4010 | New admission students in class 5 list ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'New admission students in class 5 list',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName + '' '' + sm.LastName AS StudentName, sad.RollNo FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.IsNewAdmission = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND cm.Name = ''Class 5'' AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4010, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4011 | New admissions this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'New admissions this month',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS NewAdmissions FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsNewAdmission = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.AdmissionDate >= DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4011, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4012 | Class wise new admission count this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class wise new admission count this year',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(DISTINCT sad.StudentID) AS NewAdmissions FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.IsNewAdmission = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4012, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4013 | Total bus fee by route this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total bus fee by route this year',
        @sql NVARCHAR(MAX) = N'SELECT rm.Name AS RouteName, ISNULL(SUM(bfs.Amount), 0) AS TotalBusFee FROM BusFeeStrucure bfs INNER JOIN Route_Master rm ON bfs.Route_ID = rm.ID WHERE (bfs.IsDeleted = 0 OR bfs.IsDeleted IS NULL) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY rm.Name ORDER BY TotalBusFee DESC',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4013, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4014 | What is the bus fee outstanding for class 8? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the bus fee outstanding for class 8?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(ISNULL(f.Amount,0) - ISNULL(f.Concession_Amt,0) - ISNULL(f.Paid_Amt,0) - ISNULL(f.Lien_Amount,0)), 0) AS BusFeeOutstanding FROM FeesInformationStudentDetail f WHERE f.IsBusFee = 1 AND f.IsIncludedInLumpSum = 0 AND f.IsDonation = 0 AND f.ClassName = ''Class 8'' AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4014, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4015 | Students using transport by boarding point ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students using transport by boarding point',
        @sql NVARCHAR(MAX) = N'SELECT bpm.Name AS BoardingPoint, COUNT(DISTINCT bfs.Student_ID) AS StudentCount FROM BusFeeStrucure bfs INNER JOIN BoardingPoint_Master bpm ON bfs.BoardingPoint_ID = bpm.Id WHERE (bfs.IsDeleted = 0 OR bfs.IsDeleted IS NULL) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bpm.Name ORDER BY StudentCount DESC',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4015, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4016 | Month wise bus fee amount this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Month wise bus fee amount this year',
        @sql NVARCHAR(MAX) = N'SELECT bfs.Month_Name AS FeeMonth, ISNULL(SUM(bfs.Amount), 0) AS BusFeeAmount FROM BusFeeStrucure bfs WHERE (bfs.IsDeleted = 0 OR bfs.IsDeleted IS NULL) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bfs.Month_No, bfs.Month_Name ORDER BY bfs.Month_No',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4016, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4017 | How many class 9 students opted for transport? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many class 9 students opted for transport?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT bfs.Student_ID) AS TransportStudents FROM BusFeeStrucure bfs INNER JOIN ClassMaster cm ON bfs.Class_ID = cm.ID WHERE cm.Name = ''Class 9'' AND (bfs.IsDeleted = 0 OR bfs.IsDeleted IS NULL) AND bfs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND bfs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4017, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4018 | Approved leaves this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Approved leaves this month',
        @sql NVARCHAR(MAX) = N'SELECT lem.Staff_Name, lem.LeaveFromDate, lem.LeaveToDate, lem.NoOfDays FROM LeaveEntryMaster lem WHERE lem.LeaveStatus_ID = 1 AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND lem.LeaveFromDate >= DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0) AND lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4018, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4019 | How many staff are on leave today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many staff are on leave today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS StaffOnLeave FROM LeaveEntryMaster lem WHERE CAST(GETDATE() AS DATE) BETWEEN lem.LeaveFromDate AND lem.LeaveToDate AND lem.LeaveStatus_ID = 1 AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4019, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4020 | Leaves approved this week ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Leaves approved this week',
        @sql NVARCHAR(MAX) = N'SELECT lem.Staff_Name, lem.LeaveFromDate, lem.LeaveToDate FROM LeaveEntryMaster lem WHERE lem.LeaveStatus_ID = 1 AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND lem.LeaveFromDate >= DATEADD(DAY, 1 - DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE)) AND lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4020, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4021 | Staff on leave tomorrow ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff on leave tomorrow',
        @sql NVARCHAR(MAX) = N'SELECT lem.Staff_Name, lem.LeaveFromDate, lem.LeaveToDate FROM LeaveEntryMaster lem WHERE CAST(DATEADD(DAY, 1, GETDATE()) AS DATE) BETWEEN lem.LeaveFromDate AND lem.LeaveToDate AND lem.LeaveStatus_ID = 1 AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4021, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4022 | What is the average marks in Maths for class 10 in term 1? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the average marks in Maths for class 10 in term 1?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(AVG(smd.Marks) AS DECIMAL(5,2)) AS AverageMarks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ExamTypeMaster etm ON etm.ID = smm.ExamTypeID INNER JOIN ExamTermMaster et ON et.ID = etm.TermID INNER JOIN ExamConfigurationEvaluationDetails eced ON eced.ID = smd.EvalHierID AND eced.SubjectEvaluationName LIKE ''%Maths%'' INNER JOIN ClassMaster cm ON cm.ID = smm.ClassID WHERE smd.Deleted = 0 AND smm.Deleted = 0 AND etm.IsDeleted = 0 AND cm.Name = ''Class 10'' AND et.Name LIKE ''%Term 1%'' AND smd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date) AND smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4022, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4023 | How many students passed Maths in term 1 in class 10? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students passed Maths in term 1 in class 10?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT smd.StudentID) AS PassedStudents FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ExamTypeMaster etm ON etm.ID = smm.ExamTypeID INNER JOIN ExamTermMaster et ON et.ID = etm.TermID INNER JOIN ExamConfigurationEvaluationDetails eced ON eced.ID = smd.EvalHierID AND eced.SubjectEvaluationName LIKE ''%Maths%'' INNER JOIN ClassMaster cm ON cm.ID = smm.ClassID WHERE smd.Deleted = 0 AND smm.Deleted = 0 AND etm.IsDeleted = 0 AND cm.Name = ''Class 10'' AND et.Name LIKE ''%Term 1%'' AND smd.Marks >= eced.MinMark AND smd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date) AND smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4023, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4024 | Who are the class 10 toppers in term 1? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who are the class 10 toppers in term 1?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 5 smd.StudentID, SUM(smd.Marks) AS TotalMarks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ExamTypeMaster etm ON etm.ID = smm.ExamTypeID INNER JOIN ExamTermMaster et ON et.ID = etm.TermID INNER JOIN ClassMaster cm ON cm.ID = smm.ClassID WHERE smd.Deleted = 0 AND smm.Deleted = 0 AND etm.IsDeleted = 0 AND cm.Name = ''Class 10'' AND et.Name LIKE ''%Term 1%'' AND smd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date) AND smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY smd.StudentID ORDER BY TotalMarks DESC',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4024, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4025 | List students who failed in Science in term 2 in class 9 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List students who failed in Science in term 2 in class 9',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName + '' '' + sm.LastName AS StudentName, smd.Marks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ExamTypeMaster etm ON etm.ID = smm.ExamTypeID INNER JOIN ExamTermMaster et ON et.ID = etm.TermID INNER JOIN ExamConfigurationEvaluationDetails eced ON eced.ID = smd.EvalHierID AND eced.SubjectEvaluationName LIKE ''%Science%'' INNER JOIN ClassMaster cm ON cm.ID = smm.ClassID INNER JOIN Student_Master sm ON sm.ID = smd.StudentID WHERE smd.Deleted = 0 AND smm.Deleted = 0 AND etm.IsDeleted = 0 AND cm.Name = ''Class 9'' AND et.Name LIKE ''%Term 2%'' AND smd.Marks < eced.MinMark AND smd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date) AND smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4025, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4026 | Highest marks in Science for class 9 in term 2 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Highest marks in Science for class 9 in term 2',
        @sql NVARCHAR(MAX) = N'SELECT MAX(smd.Marks) AS HighestMarks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ExamTypeMaster etm ON etm.ID = smm.ExamTypeID INNER JOIN ExamTermMaster et ON et.ID = etm.TermID INNER JOIN ExamConfigurationEvaluationDetails eced ON eced.ID = smd.EvalHierID AND eced.SubjectEvaluationName LIKE ''%Science%'' INNER JOIN ClassMaster cm ON cm.ID = smm.ClassID WHERE smd.Deleted = 0 AND smm.Deleted = 0 AND etm.IsDeleted = 0 AND cm.Name = ''Class 9'' AND et.Name LIKE ''%Term 2%'' AND smd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date) AND smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4026, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4027 | Subject wise average marks for class 8 in term 1 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Subject wise average marks for class 8 in term 1',
        @sql NVARCHAR(MAX) = N'SELECT eced.SubjectEvaluationName AS Subject, CAST(AVG(smd.Marks) AS DECIMAL(5,2)) AS AverageMarks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ExamTypeMaster etm ON etm.ID = smm.ExamTypeID INNER JOIN ExamTermMaster et ON et.ID = etm.TermID INNER JOIN ExamConfigurationEvaluationDetails eced ON eced.ID = smd.EvalHierID INNER JOIN ClassMaster cm ON cm.ID = smm.ClassID WHERE smd.Deleted = 0 AND smm.Deleted = 0 AND etm.IsDeleted = 0 AND cm.Name = ''Class 8'' AND et.Name LIKE ''%Term 1%'' AND smd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date) AND smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY eced.SubjectEvaluationName',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4027, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4028 | Which subjects are taught in class 8? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which subjects are taught in class 8?',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT s.Name AS SubjectName FROM SubjectAllocation_Master sam INNER JOIN Subject_Master s ON s.Id = sam.Subject_ID INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID WHERE cm.Name = ''Class 8'' AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY s.Name',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4028, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4029 | Subjects for class 10 section A ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Subjects for class 10 section A',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT s.Name AS SubjectName FROM SubjectAllocation_Master sam INNER JOIN Subject_Master s ON s.Id = sam.Subject_ID INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID INNER JOIN SectionMaster secm ON sam.Section_ID = secm.ID WHERE cm.Name = ''Class 10'' AND secm.Name = ''A'' AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4029, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4030 | How many subjects are allocated to class 9 this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many subjects are allocated to class 9 this year?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT s.Id) AS SubjectCount FROM SubjectAllocation_Master sam INNER JOIN Subject_Master s ON s.Id = sam.Subject_ID INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID WHERE cm.Name = ''Class 9'' AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4030, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4031 | List the subjects offered in class 12 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List the subjects offered in class 12',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT s.Name AS SubjectName FROM SubjectAllocation_Master sam INNER JOIN Subject_Master s ON s.Id = sam.Subject_ID INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID WHERE cm.Name = ''Class 12'' AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY s.Name',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4031, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4032 | Write a poem about school life ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Write a poem about school life',
        @sql NVARCHAR(MAX) = N'SELECT ''This question is outside school data. I can help with students, fees, attendance, staff, exams and school operations.'' AS Message',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4032, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4033 | Who won the last cricket world cup? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who won the last cricket world cup?',
        @sql NVARCHAR(MAX) = N'SELECT ''This question is outside school data. I can help with students, fees, attendance, staff, exams and school operations.'' AS Message',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4033, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q4034 | Write an email to parents about the annual day function ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Write an email to parents about the annual day function',
        @sql NVARCHAR(MAX) = N'SELECT ''This question is outside school data. I can help with students, fees, attendance, staff, exams and school operations.'' AS Message',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (4034, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ===================== PART 9 SUMMARY (Q4001-Q4034) =====================
DECLARE @lo INT = 4001, @hi INT = 4034, @fails INT;
SELECT @fails = COUNT(*) FROM #ai_errors WHERE qid BETWEEN @lo AND @hi;
PRINT 'PART 9 done: ' + CAST((@hi - @lo + 1) AS VARCHAR(6)) + ' queries, '
    + CAST(@fails AS VARCHAR(6)) + ' failed.';
DECLARE @qid INT, @qq NVARCHAR(300), @ee NVARCHAR(2048);
DECLARE c CURSOR LOCAL FAST_FORWARD FOR
    SELECT qid, question, error FROM #ai_errors WHERE qid BETWEEN @lo AND @hi ORDER BY qid;
OPEN c;
FETCH NEXT FROM c INTO @qid, @qq, @ee;
WHILE @@FETCH_STATUS = 0
BEGIN
    PRINT 'Q' + CAST(@qid AS VARCHAR(6)) + ' FAILED: ' + LEFT(@ee, 300);
    PRINT '   question: ' + LEFT(@qq, 200);
    FETCH NEXT FROM c INTO @qid, @qq, @ee;
END
CLOSE c; DEALLOCATE c;
SELECT qid, question, error, ms FROM #ai_errors WHERE qid BETWEEN @lo AND @hi ORDER BY qid;
GO

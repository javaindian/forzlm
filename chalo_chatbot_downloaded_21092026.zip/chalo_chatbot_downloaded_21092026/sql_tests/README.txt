CHALOSCHOOLS AI SECRETARY - v28 DATASET LOCAL TEST KIT (SSMS)
Generated 2026-09-04

WHAT THIS IS
  Every one of the 4034 question->SQL pairs of the v28 training dataset,
  written as runnable T-SQL, in the exact text the dataset holds.
  Run them against your local V3_CHALO database to find any errors
  BEFORE sending the dataset to Kaggle for training.
  (2,871 of the queries are text-wise unique; the repeats come from
  different questions that map to the same SQL - all kept so the
  count matches the dataset exactly.)

  HISTORY (2026-09-04): the first smoke run on this kit caught 39
  broken labels (36 missing AND + 3 double WHERE) that pattern rules
  could not see. They were fixed in the dataset, and a SQL syntax
  gate (sqlglot) was added to the dataset builder so they cannot
  recur. This kit also no longer misses compile-time errors: each
  query now runs through EXEC sp_executesql inside TRY/CATCH, so bad
  syntax / unknown columns / unknown tables get COUNTED as failures
  (a bare TRY/CATCH cannot catch compile errors - the batch dies
  before TRY ever runs, which is why the first smoke run showed red
  errors but reported '0 failed').

FILES
  v28_smoke_first50.sql   50 sampled queries (25 classic + 25 new v28
                          material). Run this FIRST, results ON, to
                          eyeball outputs.
  v28_part_01.sql ...     the full 4,034 queries, 500 per file.
  v28_part_09.sql         last 34 queries.
  v28_run_all_single_file.sql   ALL 4,034 queries in ONE self-contained
                          file. NO SQLCMD mode needed: set your user id
                          (Find & Replace in THIS file), then F5.
                          ~8 MB - SSMS takes a few seconds to open it.
  v28_run_all.sql         runs the 9 part files in one execution.
                          NEEDS SQLCMD Mode: Query menu > SQLCMD Mode.
                          If SSMS shows "Incorrect syntax near ':'" it
                          means the mode is off (nothing ran; the banner
                          above the first :r line explains the fix).

  RUN ORDER: smoke first -> then either v28_run_all_single_file.sql
  (simplest), OR v28_run_all.sql with SQLCMD Mode on, OR the 9 part
  files one at a time.

THE ONE SETTING TO CHANGE
  Queries are security-scoped, like in production. They run as user
  @UserId. Change it to your local user id with Find & Replace:
      @UserId INT = 1
  (Find your users with: SELECT ID, UserName FROM UserAccountMaster;)
  @SelectedBranchId NULL = all branches you may access. Put a branch
  id there to simulate a single selected branch.

HOW TO READ RESULTS
  - Each part ends with:   PART x done: 500 queries, N failed.
  - Every failure is printed in the Messages tab:
        Q### FAILED: <error text>
           question: <the natural-language question>
    and stored in the #ai_errors table (qid, question, error, ms)
    for as long as your SSMS connection stays open.
  - Failures INCLUDE compile-time errors (bad syntax, unknown
    columns, unknown tables) - the sp_executesql wrapper makes them
    catchable. 'N failed' is the true count of broken queries.
  - A red error in Messages WITHOUT a Q-number should no longer
    occur; if you see one, it means the harness itself failed on that
    batch - note the line number (it sits between the two comment
    markers of the affected query) and report it.
  - Timing per query is captured (ms column). run_all.sql also shows
    the 20 slowest queries at the end.
  - The query text appears inside the @sql string with single quotes
    doubled ('') - that is normal T-SQL string escaping, not a change
    to the query.
  - Multi-line queries keep their line breaks inside the @sql string;
    SQL Server treats a line break as plain whitespace, so the executed
    query is identical (verified: 4,034/4,034 literals match the
    dataset exactly after unescaping).

TIPS
  - For the full run, tick Query > Query Options > Results > Grid >
    'Discard results after execution' so you don't get 4,034 result
    grids. Errors and summaries still appear in Messages.
  - Expect the full run to take a while (each query carries the RBAC
    branch-scoping subqueries, like production). Checkpoints print
    every 100 queries so you can see it is alive.
  - SSMS runs repeated @variables natively - the school ExecuteQuery
    API limitation with repeated placeholders does not apply here.
  - 17 of the queries are refusal answers (SELECT '...' AS Message).
    They are supposed to return a message, not data - not an error.
  - @AcademicYearID is not used anywhere in this dataset (queries
    resolve the current year via GETDATE() subqueries), so it is not
    declared. The @Status... variables in some enquiry queries are
    declared inside those queries themselves.

AFTER TESTING
  If queries fail, note their Q-numbers. Those exact texts are what
  the model would learn - fix them in the dataset (or report them)
  before training. The Q-number is the line number in
  semantic_validation/reference_inputs/training_dataset_final_v28.jsonl.

/*
  ChaloSchools AI Secretary - v28 dataset local test - RUN EVERYTHING
  4034 queries in 9 parts, one execution. (SQLCMD-MODE version.)

  HOW TO USE
    1. First change the test user in the part files:
       Find & Replace across v28_part_*.sql:   @UserId INT = 1
    2. Open THIS file in SSMS (same folder as the part files).
    3. Query menu > SQLCMD Mode  (MUST be on - see the warning below).
    4. Recommended: Query > Query Options > Results > Grid >
       tick 'Discard results after execution' (avoids thousands of grids).
    5. Execute (F5). Progress checkpoints appear every 100 queries;
       each part prints its summary; the grand total prints at the end.

  NO-MODE ALTERNATIVE: open v28_run_all_single_file.sql instead -
  every query is inline there, so you just press F5 (no mode to switch).
*/
SET NOCOUNT ON;
GO
-- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
--  IF SSMS SHOWED:   Msg 102 ... Incorrect syntax near ':'.
--  at the line just below: SQLCMD MODE IS NOT SWITCHED ON.
--  Nothing has run yet - this is not an error in the queries.
--  Fix:  Query menu > SQLCMD Mode (or the 'SQLCMD Mode' toolbar button),
--        then Execute (F5) again.
--  Or:   open v28_run_all_single_file.sql (no mode needed) and press F5.
-- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
:r v28_part_01.sql
:r v28_part_02.sql
:r v28_part_03.sql
:r v28_part_04.sql
:r v28_part_05.sql
:r v28_part_06.sql
:r v28_part_07.sql
:r v28_part_08.sql
:r v28_part_09.sql

-- ===================== GRAND TOTAL =====================
DECLARE @fails INT;
SELECT @fails = COUNT(*) FROM #ai_errors;
PRINT '==================================================';
PRINT 'ALL DONE: 4034 queries executed.';
PRINT 'TOTAL FAILURES: ' + CAST(@fails AS VARCHAR(6));
SELECT TOP 20 qid, question, error, ms FROM #ai_errors ORDER BY ms DESC; -- 20 slowest (grid)
IF @fails > 0
BEGIN
    PRINT 'FAILING QUERIES (also in #ai_errors):';
    DECLARE @qid INT, @qq NVARCHAR(300), @ee NVARCHAR(2048);
    DECLARE c CURSOR LOCAL FAST_FORWARD FOR SELECT qid, question, error FROM #ai_errors ORDER BY qid;
    OPEN c;
    FETCH NEXT FROM c INTO @qid, @qq, @ee;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        PRINT 'Q' + CAST(@qid AS VARCHAR(6)) + ' FAILED: ' + LEFT(@ee, 300);
        PRINT '   question: ' + LEFT(@qq, 200);
        FETCH NEXT FROM c INTO @qid, @qq, @ee;
    END
    CLOSE c; DEALLOCATE c;
END
ELSE
    PRINT 'All queries ran without errors.';
GO

/* =====================================================================
   ChaloSchools AI Secretary - v28 dataset local test (SSMS)
   Part 2 of 9: queries Q501 to Q1000 (500 of 4034 in the full dataset)
   Source: semantic_validation/reference_inputs/training_dataset_final_v28.jsonl
   Generated: 2026-09-04
   The SQL text is EXACTLY what the dataset holds (single quotes appear
   doubled inside the @sql string - T-SQL string escaping; multi-line
   queries keep line breaks, which SQL Server counts as whitespace).
   So any error you see here is an error the trained model would produce.

   ONE SETTING TO CHANGE BEFORE RUNNING:
     The queries are security-scoped to a user, like in production. They run
     as @UserId. Change it to YOUR local user id:
       Find & Replace across these files:   @UserId INT = 1
       (see your users with:  SELECT ID, UserName FROM UserAccountMaster;)
     @SelectedBranchId NULL = all branches you are allowed; put a branch id
       there to simulate one selected branch.

   RECOMMENDED for big runs (stops 500 result grids appearing):
     Query menu > Query Options... > Results > Grid >
     tick 'Discard results after execution', then Execute (F5).
     Everything still runs; errors + summary appear in the Messages tab.
   Failures (INCLUDING compile-time errors - bad syntax, unknown columns,
   unknown tables - thanks to the sp_executesql wrapper) are printed as:
     Q### FAILED: <error text>
        question: <the natural-language question>
   and stored in table #ai_errors until you close the connection.
   ===================================================================== */
SET NOCOUNT ON;
GO
IF OBJECT_ID('tempdb..#ai_errors') IS NULL
    CREATE TABLE #ai_errors (
        qid      INT NOT NULL PRIMARY KEY,
        question NVARCHAR(300),
        error    NVARCHAR(2048),
        ms       INT NOT NULL
    );
GO
-- ============ Q501 | Are there any holidays this week? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Are there any holidays this week?',
        @sql NVARCHAR(MAX) = N'SELECT Name, From_Date, To_Date FROM HolidayMaster WHERE From_Date BETWEEN DATEADD(DAY, -DATEPART(WEEKDAY, GETDATE()) + 1, CAST(GETDATE() AS DATE)) AND DATEADD(DAY, 7 - DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE)) AND IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (501, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q502 | Show recent circulars ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show recent circulars',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 ce.Title, ce.Circular_Date, ce.Circular_Date, ce.CircularApplicableFor FROM CircularEntry ce WHERE ce.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ce.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ce.IsDeleted = 0 OR ce.IsDeleted IS NULL) ORDER BY ce.Circular_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (502, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q503 | List all unpaid late fees for Class 10 students. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all unpaid late fees for Class 10 students.',
        @sql NVARCHAR(MAX) = N'SELECT SM.FirstName + '' '' + SM.LastName AS StudentName, lfd.Amount - ISNULL(lfc.Concession_Amount, 0) AS NetPayable FROM FeesInformationStudentDetail FI INNER JOIN LateFeeMaster lfm ON lfm.TermId = FI.Term_ID AND lfm.IsActive = 1 AND CAST(GETDATE() AS DATE) <= lfm.ValidityDate AND CAST(GETDATE() AS DATE) >= lfm.LastDate INNER JOIN LateFeeDetails lfd ON lfm.ID = lfd.LateFeeID AND (lfd.ClassId = FI.ClassID OR lfd.ClassId = 0) AND CAST(GETDATE() AS DATE) BETWEEN lfd.FromDate AND lfd.ToDate INNER JOIN Fees_Master fmm ON fmm.ID = FI.Fees_ID AND ISNULL(fmm.IsIncludeinLateFee, 0) = 1 INNER JOIN Student_Master SM ON SM.ID = FI.Student_ID LEFT JOIN LateFee_Concession lfc ON lfc.Student_ID = FI.Student_ID AND lfc.LateFeeHeadId = lfm.LateFeeHeadId AND lfc.Term_ID = FI.Term_ID AND lfc.AcademicYearID = FI.AcademicYearID AND lfc.BranchID = FI.BranchID AND ISNULL(lfc.IsDeleted, 0) = 0 INNER JOIN StudentAcademicDetail SA ON FI.AcademicYearID = SA.AcademicYearID AND SA.StudentID = FI.Student_ID INNER JOIN ClassMaster CM ON CM.ID = SA.ClassID WHERE CM.Name IN (''Class 10'', ''X'') AND FI.IsIncludedInLumpSum <> 1 AND FI.IsDonation = 0 AND (FI.Amount - ISNULL(FI.Concession_Amt,0) - FI.Paid_Amt - FI.Lien_Amount) > 0 AND CAST(SM.AdmissionDate AS DATE) < lfd.FromDate AND (lfd.Amount - ISNULL(lfc.Concession_Amount, 0)) > 0 AND FI.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (503, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q504 | Is there any class where not a single student has paid fees? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Is there any class where not a single student has paid fees?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName FROM ClassMaster cm INNER JOIN StudentAcademicDetail sad ON cm.ID = sad.ClassID LEFT JOIN (SELECT DISTINCT fc.Student_ID, fc.AcademicYearID FROM FeesCollection fc WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4)) paid ON paid.Student_ID = sad.StudentID AND paid.AcademicYearID = sad.AcademicYearID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND cm.IsDeleted = 0 GROUP BY cm.ID, cm.Name HAVING COUNT(paid.Student_ID) = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (504, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q505 | So, average time to convert an enquiry in days ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, average time to convert an enquiry in days',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT AVG(DATEDIFF(DAY, CallDate, GETDATE())) AS AvgDaysToConvert FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND CallStatus_ID IN (SELECT ID FROM Enquiry_Status_Master WHERE Name = ''Completed'');',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (505, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q506 | Students who have both tuition fee and transport fee outstanding ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students who have both tuition fee and transport fee outstanding',
        @sql NVARCHAR(MAX) = N'SELECT f.Student_ID, sm.FirstName + '' '' + sm.LastName AS StudentName FROM FeesInformationStudentDetail f INNER JOIN Student_Master sm ON f.Student_ID = sm.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY f.Student_ID, sm.FirstName, sm.LastName HAVING SUM(CASE WHEN f.FeesType_Name = ''Tuition Fee'' THEN (f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) ELSE 0 END) > 0 AND SUM(CASE WHEN f.IsBusFee = 1 THEN (f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) ELSE 0 END) > 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (506, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q507 | Show top 10 students by concession amount. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show top 10 students by concession amount.',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 cm.Student_ID, sm.FirstName, sm.LastName, sm.AdmissionNo, SUM(cm.Concession_Amount) AS TotalConcession FROM Concession_Master cm INNER JOIN Student_Master sm ON cm.Student_ID = sm.ID WHERE cm.IsDeleted = 0 AND cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Student_ID, sm.FirstName, sm.LastName, sm.AdmissionNo ORDER BY TotalConcession DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (507, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q508 | List all applications for Nursery/LKG/UKG classes ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all applications for Nursery/LKG/UKG classes',
        @sql NVARCHAR(MAX) = N'SELECT ae.FirstName, ae.LastName, ae.ClassName, ae.ComEmail FROM ApplicationEntry ae WHERE ae.ClassName IN (''Nursery'', ''LKG'', ''UKG'') AND ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (ae.IsDeleted IS NULL OR ae.IsDeleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (508, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q509 | Hey, how many enquiries were received between March and June 2026? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many enquiries were received between March and June 2026?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS EnquiryCount FROM GeneralCallRegister WHERE CallDate BETWEEN ''2026-03-01'' AND ''2026-06-30'' AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (509, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q510 | What are the all students with their payment type and class? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What are the all students with their payment type and class?',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, sad.PaymentTypeId FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.ClassName, sm.FirstName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (510, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q511 | Students who declined from Term 1 to Term 2 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students who declined from Term 1 to Term 2',
        @sql NVARCHAR(MAX) = N'SELECT t1.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName, t1.AvgMarks AS Term1Avg, t2.AvgMarks AS Term2Avg, (t1.AvgMarks - t2.AvgMarks) AS Decline FROM (SELECT smd.StudentID, AVG(smd.Marks) AS AvgMarks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ExamTypeMaster et ON smm.ExamTypeID = et.ID INNER JOIN ExamTermMaster etm ON et.TermID = etm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND etm.Name = ''Term 1'' GROUP BY smd.StudentID) t1 INNER JOIN (SELECT smd.StudentID, AVG(smd.Marks) AS AvgMarks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ExamTypeMaster et ON smm.ExamTypeID = et.ID INNER JOIN ExamTermMaster etm ON et.TermID = etm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND etm.Name = ''Term 2'' GROUP BY smd.StudentID) t2 ON t1.StudentID = t2.StudentID INNER JOIN Student_Master stm ON t1.StudentID = stm.ID WHERE t2.AvgMarks < t1.AvgMarks ORDER BY Decline DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (511, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q512 | Staff whose salary exceeds 50000 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff whose salary exceeds 50000',
        @sql NVARCHAR(MAX) = N'SELECT gem.EmployeeID, gem.EmployeeName, gem.NetPay FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) AND gem.NetPay > 50000 ORDER BY gem.NetPay DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (512, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q513 | Staff attendance this week ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff attendance this week',
        @sql NVARCHAR(MAX) = N'SELECT Attendance_Date, COUNT(CASE WHEN Attendance_Status_ID = 1 THEN 1 END) AS Present, COUNT(CASE WHEN Attendance_Status_ID = 2 THEN 1 END) AS Absent FROM Staff_Attendance WHERE Attendance_Date >= DATEADD(DAY, -DATEPART(WEEKDAY, GETDATE()) + 1, CAST(GETDATE() AS DATE)) AND Attendance_Date <= CAST(GETDATE() AS DATE) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY Attendance_Date ORDER BY Attendance_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (513, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q514 | What is the minimum transport fee? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the minimum transport fee?',
        @sql NVARCHAR(MAX) = N'SELECT MIN(bpm.Amount) AS MinFee FROM Route_Master rm INNER JOIN Route_MasterDetails rmd ON rm.ID = rmd.Route_ID INNER JOIN BoardingPoint_Master bpm ON rmd.BoardingPoint_ID = bpm.Id WHERE rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND rm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (rm.IsDeleted = 0 OR rm.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (514, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q515 | Class-wise collected vs pending comparison ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class-wise collected vs pending comparison',
        @sql NVARCHAR(MAX) = N'SELECT fisd.ClassName, SUM(ISNULL(fisd.Paid_Amt,0)) AS collected, SUM((fisd.Amount - ISNULL(fisd.Concession_Amt, 0) - ISNULL(fisd.Paid_Amt, 0))) AS pending, SUM(fisd.Amount) AS total_payable FROM FeesInformationStudentDetail fisd WHERE fisd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fisd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fisd.ClassName ORDER BY fisd.ClassName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (515, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q516 | Collection from April to June this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Collection from April to June this year',
        @sql NVARCHAR(MAX) = N'SELECT FORMAT(fc.Bill_Date, ''MMMM'') AS MonthName, SUM(fc.Receipt_Amt) AS MonthlyCollection FROM FeesCollection fc WHERE fc.Bill_Date >= DATEFROMPARTS(CASE WHEN MONTH(GETDATE()) >= 4 THEN YEAR(GETDATE()) ELSE YEAR(GETDATE())-1 END + 0, 4, 1) AND fc.Bill_Date < DATEFROMPARTS(CASE WHEN MONTH(GETDATE()) >= 4 THEN YEAR(GETDATE()) ELSE YEAR(GETDATE())-1 END + 0, 7, 1) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY FORMAT(fc.Bill_Date, ''MMMM''), MONTH(fc.Bill_Date) ORDER BY MONTH(fc.Bill_Date);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (516, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q517 | Which class has the most students with unpaid late fees? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which class has the most students with unpaid late fees?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 cm.Name AS ClassName, COUNT(DISTINCT fc.Student_ID) AS UnpaidStudents FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN ClassMaster cm ON fc.Class_ID = cm.ID WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.LateFeeAmount > 0 AND fcd.Remaining_Amt > 0 AND (fc.IsDeleted = 0 OR fc.IsDeleted IS NULL) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY cm.Name ORDER BY UnpaidStudents DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (517, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q518 | Students who were absent more than 5 days this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students who were absent more than 5 days this month',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, sm.AdmissionNo, cm.Name AS class_name, COUNT(*) AS absent_days FROM StudentAttendance sa JOIN Student_Master sm ON sa.Student_ID = sm.ID JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE sa.Attendance_Status_ID = 2 AND DATEPART(MONTH, sa.Attendance_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, sa.Attendance_Date) = DATEPART(YEAR, GETDATE()) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo, cm.Name HAVING COUNT(*) > 5 ORDER BY COUNT(*) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (518, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q519 | Give me the salary range distribution of staff ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the salary range distribution of staff',
        @sql NVARCHAR(MAX) = N'SELECT CASE WHEN gem.NetPay < 20000 THEN ''Below 20K'' WHEN gem.NetPay BETWEEN 20000 AND 40000 THEN ''20K-40K'' WHEN gem.NetPay BETWEEN 40001 AND 60000 THEN ''40K-60K'' WHEN gem.NetPay BETWEEN 60001 AND 80000 THEN ''60K-80K'' ELSE ''Above 80K'' END AS SalaryRange, COUNT(*) AS StaffCount FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) GROUP BY CASE WHEN gem.NetPay < 20000 THEN ''Below 20K'' WHEN gem.NetPay BETWEEN 20000 AND 40000 THEN ''20K-40K'' WHEN gem.NetPay BETWEEN 40001 AND 60000 THEN ''40K-60K'' WHEN gem.NetPay BETWEEN 60001 AND 80000 THEN ''60K-80K'' ELSE ''Above 80K'' END;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (519, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q520 | Students whose fee was collected via multiple payment modes this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students whose fee was collected via multiple payment modes this year',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, COUNT(DISTINCT cmm.Name) AS PaymentModeCount FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN FeesCollection fc ON sm.ID = fc.Student_ID LEFT JOIN CollectionMode_Master cmm ON fc.Collection_Mode_ID = cmm.ID WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID = fc.AcademicYearID GROUP BY sm.ID, sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo, sad.ClassName HAVING COUNT(DISTINCT cmm.Name) > 1 ORDER BY PaymentModeCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (520, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q521 | Show class-wise remaining fee amount ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show class-wise remaining fee amount',
        @sql NVARCHAR(MAX) = N'SELECT f.ClassName, SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS Outstanding FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY f.ClassName ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (521, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q522 | Let me see the male female ratio ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see the male female ratio',
        @sql NVARCHAR(MAX) = N'SELECT sm.Gender, COUNT(*) AS total FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY sm.Gender;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (522, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q523 | Pull up collection trend by hour of the day ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up collection trend by hour of the day',
        @sql NVARCHAR(MAX) = N'SELECT DATEPART(HOUR, fc.Bill_Date) AS HourOfDay, COUNT(fc.Id) AS Receipts, SUM(fc.Receipt_Amt) AS TotalAmount FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY DATEPART(HOUR, fc.Bill_Date) ORDER BY HourOfDay;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (523, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q524 | Which class has the best attendance today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which class has the best attendance today?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 cm.Name AS class_name, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS attendance_pct FROM StudentAttendance sa JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name ORDER BY attendance_pct DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (524, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q525 | Average net salary by staff type ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Average net salary by staff type',
        @sql NVARCHAR(MAX) = N'SELECT gm.StaffTypeName, CAST(AVG(gem.NetPay) AS DECIMAL(12,2)) AS AvgNetSalary FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) GROUP BY gm.StaffTypeName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (525, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q526 | Show the loss rate by enquiry source. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the loss rate by enquiry source.',
        @sql NVARCHAR(MAX) = N'DECLARE @StatusLost bigint = (SELECT TOP 1 ID FROM Enquiry_Status_Master WHERE Name = ''Dropped'');
WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT emm.Name AS Source, ROUND(SUM(CASE WHEN CallStatus_ID = @StatusLost THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0), 2) AS LossRate FROM GeneralCallRegister em INNER JOIN Enquiry_Mode_Master emm ON em.Mode_ID = emm.ID WHERE em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND em.IsDeleted = 0 GROUP BY emm.Name ORDER BY LossRate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (526, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q527 | Percentage of staff absent this week ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Percentage of staff absent this week',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(CASE WHEN Attendance_Status_ID = 2 THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS AbsentPercentage FROM Staff_Attendance WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND Attendance_Date >= DATEADD(DAY, -DATEPART(WEEKDAY, GETDATE()) + 1, CAST(GETDATE() AS DATE)) AND Attendance_Date <= CAST(GETDATE() AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (527, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q528 | List staff department-wise with their headcounts ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List staff department-wise with their headcounts',
        @sql NVARCHAR(MAX) = N'SELECT dm.Name AS Department, COUNT(DISTINCT sdmd.StaffID) AS StaffCount FROM StaffDepartmentMapping sdm INNER JOIN StaffDepartmentMappingDetail sdmd ON sdm.Id = sdmd.MappingID INNER JOIN StaffDepartmentMaster dm ON sdm.DepartmentID = dm.Id WHERE sdm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sdm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (sdm.IsDeleted = 0 OR sdm.IsDeleted IS NULL) GROUP BY dm.Name ORDER BY dm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (528, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q529 | How many students appeared for exams this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students appeared for exams this year?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT smd.StudentID) AS StudentsAppeared FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN Branch_Academic_Details b ON smd.AcademicYearID = b.Id WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND GETDATE() BETWEEN b.Start_Date AND b.End_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (529, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q530 | Gender-wise attendance today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Gender-wise attendance today',
        @sql NVARCHAR(MAX) = N'SELECT sm.Gender, SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS present, SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END) AS absent FROM StudentAttendance sa JOIN Student_Master sm ON sa.Student_ID = sm.ID WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.Gender;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (530, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q531 | List all routes with their vehicle numbers. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all routes with their vehicle numbers.',
        @sql NVARCHAR(MAX) = N'SELECT rm.Name AS RouteName, rm.VehicleNo FROM Route_Master rm WHERE rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND rm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (rm.IsDeleted = 0 OR rm.IsDeleted IS NULL) ORDER BY rm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (531, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q532 | Pull up the trend of converted enquiries month over month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up the trend of converted enquiries month over month',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT FORMAT(CallDate, ''yyyy-MM'') AS Month, COUNT(*) AS ConvertedCount FROM GeneralCallRegister WHERE CallStatus_ID IN (SELECT ID FROM Enquiry_Status_Master WHERE Name = ''Completed'') AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0 GROUP BY FORMAT(CallDate, ''yyyy-MM'') ORDER BY Month;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (532, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q533 | I wanna see the class-wise student strength with Section breakup ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I wanna see the class-wise student strength with Section breakup',
        @sql NVARCHAR(MAX) = N'SELECT sad.ClassName, secm.Name AS SectionName, COUNT(sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad INNER JOIN SectionMaster secm ON sad.SectionID = secm.ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) GROUP BY sad.ClassID, sad.ClassName, secm.Name ORDER BY sad.ClassID, secm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (533, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q534 | Rank my branches by student count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Rank my branches by student count',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, COUNT(*) AS Students, RANK() OVER (ORDER BY COUNT(*) DESC) AS BranchRank FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN BranchMaster bm ON sm.BranchID = bm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY Students DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (534, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q535 | How much did each fee head collect compared to last year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much did each fee head collect compared to last year?',
        @sql NVARCHAR(MAX) = N'SELECT fcd.FeesGroup_Name AS FeeHead, SUM(CASE WHEN yr.IsLastYear = 1 THEN fcd.Paid_Amt ELSE 0 END) AS Collection_LastYear, SUM(CASE WHEN GETDATE() BETWEEN bad.Start_Date AND bad.End_Date THEN fcd.Paid_Amt ELSE 0 END) AS Collection_ThisYear, SUM(CASE WHEN GETDATE() BETWEEN bad.Start_Date AND bad.End_Date THEN fcd.Paid_Amt ELSE 0 END) - SUM(CASE WHEN yr.IsLastYear = 1 THEN fcd.Paid_Amt ELSE 0 END) AS Difference FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id OUTER APPLY (SELECT CASE WHEN bad.Id = (SELECT PreviousYearID FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = bad.Branch_Id) THEN 1 ELSE 0 END AS IsLastYear) yr WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND (GETDATE() BETWEEN bad.Start_Date AND bad.End_Date OR yr.IsLastYear = 1) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fcd.FeesGroup_Name ORDER BY fcd.FeesGroup_Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (535, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q536 | Daily collection trend this week ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Daily collection trend this week',
        @sql NVARCHAR(MAX) = N'SELECT CAST(fc.Bill_Date AS DATE) AS collection_date, SUM(fc.Receipt_Amt) AS amount FROM FeesCollection fc WHERE fc.Bill_Date >= DATEADD(DAY, 1 - DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE)) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY CAST(fc.Bill_Date AS DATE) ORDER BY CAST(fc.Bill_Date AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (536, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q537 | Which month had the highest number of leave applications? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which month had the highest number of leave applications?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 FORMAT(lem.LeaveFromDate, ''yyyy-MM'') AS [Month], COUNT(*) AS Applications FROM LeaveEntryMaster lem WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) GROUP BY FORMAT(lem.LeaveFromDate, ''yyyy-MM'') ORDER BY Applications DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (537, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q538 | Class-wise pending fee amount ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class-wise pending fee amount',
        @sql NVARCHAR(MAX) = N'SELECT f.ClassName, SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS Outstanding FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY f.ClassName ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (538, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q539 | Students who have not paid a single rupee ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students who have not paid a single rupee',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, sm.AdmissionNo, cm.Name AS class_name, sm.FatherContactNo FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.StudentID NOT IN (SELECT DISTINCT fc.Student_ID FROM FeesCollection fc WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (539, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q540 | I need the attendance summary for last week ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need the attendance summary for last week',
        @sql NVARCHAR(MAX) = N'SELECT sa.Attendance_Date, SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS PresentCount, SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END) AS AbsentCount FROM StudentAttendance sa WHERE sa.Attendance_Date >= DATEADD(WEEK, -1, DATEADD(DAY, -(DATEPART(WEEKDAY, GETDATE()) - 2), CAST(GETDATE() AS DATE))) AND sa.Attendance_Date < DATEADD(DAY, -(DATEPART(WEEKDAY, GETDATE()) - 2), CAST(GETDATE() AS DATE)) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sa.Attendance_Date ORDER BY sa.Attendance_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (540, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q541 | Show applications submitted today. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show applications submitted today.',
        @sql NVARCHAR(MAX) = N'SELECT ae.ApplicationNo, ae.FirstName + ISNULL('' '' + ae.MiddleName, '''') + '' '' + ae.LastName AS StudentName, ae.FatherName, ae.Gender, cm.Name AS ClassApplied, ae.ComMobile AS Phone FROM ApplicationEntry ae INNER JOIN ClassMaster cm ON ae.Student_ClassID = cm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) AND CAST(ae.ApplicationDate AS DATE) = CAST(GETDATE() AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (541, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q542 | Average salary of staff ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Average salary of staff',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(AVG(gem.NetPay), 2) AS AvgSalary FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (542, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q543 | Online collection for the Sholinganallur campus this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Online collection for the Sholinganallur campus this month',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fc.Receipt_Amt) AS OnlineCollection FROM FeesCollection fc WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.Collection_Mode_ID IN (SELECT ID FROM CollectionMode_Master WHERE Name = ''Bank Online Transfer'') AND DATEPART(MONTH, fc.Bill_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, fc.Bill_Date) = DATEPART(YEAR, GETDATE()) AND fc.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%Sholinganallur%'' OR ShortName LIKE ''%Sholinganallur%'')) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (543, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q544 | How much money is owed to the school? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much money is owed to the school?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)), 0) AS TotalOutstanding FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (544, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q545 | Staff on long leave (more than 5 days) this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff on long leave (more than 5 days) this year',
        @sql NVARCHAR(MAX) = N'SELECT sfm.Staff_FirstName + '' '' + ISNULL(sfm.Staff_LastName, '''') AS StaffName, lt.Name AS LeaveType, lem.LeaveFromDate, lem.LeaveToDate, lem.NoOfDays FROM LeaveEntryMaster lem INNER JOIN Staff_Master sfm ON lem.Staff_ID = sfm.Staff_ID AND sfm.StaffStatus_ID = 1 INNER JOIN LeaveType lt ON lem.LeaveType_ID = lt.ID INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE ls.Name = ''Approved'' AND lem.NoOfDays > 5 AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY lem.NoOfDays DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (545, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q546 | Which section has maximum TCs issued? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which section has maximum TCs issued?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 cm.Name AS ClassName, secm.Name, COUNT(*) AS TCCount FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID INNER JOIN SectionMaster secm ON sad.SectionID = secm.ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsTCIssued = 1 GROUP BY cm.Name, secm.Name ORDER BY COUNT(*) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (546, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q547 | What's the average concession per student? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the average concession per student?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(SUM(ISNULL(Concession_Amt, 0)) * 1.0 / NULLIF(COUNT(DISTINCT Student_ID), 0), 2) AS AvgConcession FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND ISNULL(Concession_Amt, 0) > 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (547, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q548 | Class-wise pass percentage ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class-wise pass percentage',
        @sql NVARCHAR(MAX) = N'SELECT c.Name AS ClassName, CAST(SUM(CASE WHEN smd.Marks >= eced.MinMark THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS PassPercentage FROM StudentMarkDetails smd INNER JOIN ExamConfigurationEvaluationDetails eced ON smd.EvalHierID = eced.ID INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ClassMaster c ON smm.ClassID = c.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND c.IsDeleted = 0 GROUP BY c.Name ORDER BY c.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (548, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q549 | What is the total outstanding fee amount? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total outstanding fee amount?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS TotalOutstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (549, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q550 | Today's collection? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Today''s collection?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS TodaysCollection FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (550, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q551 | Show late fees due in the next 7 days. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show late fees due in the next 7 days.',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName + '' '' + sm.LastName AS StudentName, fcd.LateFeeName, fcd.LateFeeAmount, fc.Bill_Date FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN Student_Master sm ON fc.Student_ID = sm.ID WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.LateFeeAmount > 0 AND fcd.Remaining_Amt > 0 AND (fc.IsDeleted = 0 OR fc.IsDeleted IS NULL) AND fc.ChequeStatus_ID NOT IN (3, 4) ORDER BY fc.Bill_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (551, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q552 | List all staff with 100% attendance this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all staff with 100% attendance this month',
        @sql NVARCHAR(MAX) = N'SELECT sfm.Staff_FirstName + '' '' + ISNULL(sfm.Staff_LastName, '''') AS StaffName FROM Staff_Master sfm WHERE (sfm.IsDeleted IS NULL OR sfm.IsDeleted = 0) AND sfm.StaffStatus_ID = 1 AND sfm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sfm.Staff_ID NOT IN (SELECT sa.Staff_ID FROM Staff_Attendance sa WHERE sa.Attendance_Status_ID = 2 AND MONTH(sa.Attendance_Date) = MONTH(GETDATE()) AND YEAR(sa.Attendance_Date) = YEAR(GETDATE())  AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY sfm.Staff_FirstName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (552, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q553 | Hey, how many half-day holidays are there? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many half-day holidays are there?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS HalfDayHolidays FROM HolidayMaster WHERE IsHalfDay = 1 AND IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND YEAR(From_Date) IN (2025, 2026);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (553, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q554 | Send SMS to all fee defaulters ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Send SMS to all fee defaulters',
        @sql NVARCHAR(MAX) = N'-- This question asks me to perform an action (send SMS), which I cannot do. I can only retrieve data.
-- Here''s what I can show you instead:
SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.FatherContactNo, sm.MotherContactNo, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN Student_Master sm ON f.Student_ID = sm.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY sm.AdmissionNo, sm.FirstName, sm.LastName, sm.FatherContactNo, sm.MotherContactNo HAVING SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 0 ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (554, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q555 | Let me see day-wise attendance for the last 7 days ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see day-wise attendance for the last 7 days',
        @sql NVARCHAR(MAX) = N'SELECT CAST(sa.Attendance_Date AS DATE) AS AttDate, DATENAME(WEEKDAY, sa.Attendance_Date) AS DayName, COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) AS Present, COUNT(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 END) AS Absent, CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AttendancePercent FROM StudentAttendance sa JOIN Branch_Academic_Details bad ON sa.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sa.Attendance_Date >= DATEADD(DAY, -7, GETDATE()) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY CAST(sa.Attendance_Date AS DATE), DATENAME(WEEKDAY, sa.Attendance_Date) ORDER BY AttDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (555, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q556 | Give me the total paid amount in the Kodambakkam branch ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the total paid amount in the Kodambakkam branch',
        @sql NVARCHAR(MAX) = N'SELECT SUM(ISNULL(fisd.Paid_Amt,0)) AS TotalPaid FROM FeesInformationStudentDetail fisd WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND fisd.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%Kodambakkam%'' OR ShortName LIKE ''%Kodambakkam%'')) AND fisd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (556, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q557 | How many more students do we have compared to last year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many more students do we have compared to last year?',
        @sql NVARCHAR(MAX) = N'SELECT ''Current Year'' AS Period, COUNT(DISTINCT sad.StudentID) AS Students FROM StudentAcademicDetail sad WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) UNION ALL SELECT ''Previous Year'' AS Period, COUNT(DISTINCT sad.StudentID) AS Students FROM StudentAcademicDetail sad WHERE sad.AcademicYearID IN (SELECT PreviousYearID FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (557, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q558 | List defaulters with amount more than 50000 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List defaulters with amount more than 50000',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, sm.AdmissionNo, cm.Name AS class_name, SUM(fcd.Remaining_Amt) AS outstanding FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Student_Master sm ON fc.Student_ID = sm.ID JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID AND fc.AcademicYearID = sad.AcademicYearID JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fcd.Remaining_Amt > 0 AND sad.IsActive = 1 GROUP BY sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo, cm.Name HAVING SUM(fcd.Remaining_Amt) > 50000 ORDER BY SUM(fcd.Remaining_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (558, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q559 | I need to see tickets by priority level ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see tickets by priority level',
        @sql NVARCHAR(MAX) = N'SELECT fem.DisplayOrder AS EscalationLevel, COUNT(*) AS [Count] FROM FeedbackTicket ft OUTER APPLY (SELECT MAX(ftr.RepliedOn) AS LastReplyDate FROM FeedbackTicketReplies ftr WHERE ftr.TicketID = ft.Id) rp INNER JOIN FeedbackEscalationMatrix fem ON fem.FeedbackCategoryID = ft.CategoryID WHERE ft.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ft.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND DATEDIFF(HOUR, ft.Created_Date, ISNULL(rp.LastReplyDate, GETDATE())) > fem.EscalationHours GROUP BY fem.DisplayOrder ORDER BY fem.DisplayOrder DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (559, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q560 | Transport students with fee collection details ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Transport students with fee collection details',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(DISTINCT CASE WHEN sad.TransportRequired = 1 THEN sad.StudentID END) AS TransportStudents, ISNULL(SUM(CASE WHEN sad.TransportRequired = 1 THEN fc_sub.TotalPaid END), 0) AS TransportStudentCollection FROM StudentAcademicDetail sad JOIN ClassMaster cm ON sad.ClassID = cm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id LEFT JOIN (SELECT fc.Student_ID, SUM(fc.Receipt_Amt) AS TotalPaid FROM FeesCollection fc WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fc.Student_ID) fc_sub ON sad.StudentID = fc_sub.Student_ID WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name, cm.DisplayOrder ORDER BY cm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (560, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q561 | Can you show class-wise outstanding fees in descending order? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show class-wise outstanding fees in descending order?',
        @sql NVARCHAR(MAX) = N'SELECT ClassName, SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY ClassName ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (561, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q562 | Average marks of bottom 25% students ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Average marks of bottom 25% students',
        @sql NVARCHAR(MAX) = N'SELECT CAST(AVG(TotalMarks) AS DECIMAL(5,2)) AS AvgOfBottom25 FROM (SELECT smd.StudentID, SUM(smd.Marks) AS TotalMarks, NTILE(4) OVER (ORDER BY SUM(smd.Marks) ASC) AS Quartile FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 GROUP BY smd.StudentID) t WHERE Quartile = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (562, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q563 | And what about section B? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'And what about section B?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(sad.Id) AS StudentCount FROM StudentAcademicDetail sad INNER JOIN SectionMaster secm ON sad.SectionID = secm.ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND secm.Name = ''B'' AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (563, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q564 | Staff absentee count by department ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff absentee count by department',
        @sql NVARCHAR(MAX) = N'SELECT sa.StaffType_ID, COUNT(*) AS AbsentCount FROM Staff_Attendance sa INNER JOIN Staff_Master sfm ON sa.Staff_ID = sfm.Staff_ID AND sfm.StaffStatus_ID = 1 WHERE MONTH(sa.Attendance_Date) = MONTH(GETDATE()) AND YEAR(sa.Attendance_Date) = YEAR(GETDATE()) AND sa.Attendance_Status_ID = 2 AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sa.StaffType_ID ORDER BY AbsentCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (564, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q565 | So, how many students stay in the hostel? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, how many students stay in the hostel?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS HostelStudents FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.HostelRequired = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (565, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q566 | Show applications received in the last 30 days. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show applications received in the last 30 days.',
        @sql NVARCHAR(MAX) = N'SELECT ae.ApplicationNo, ae.FirstName + ISNULL('' '' + ae.MiddleName, '''') + '' '' + ae.LastName AS StudentName, ae.FatherName, ae.ComMobile AS Phone, cm.Name AS ClassApplied, asm.Name AS Status FROM ApplicationEntry ae INNER JOIN ClassMaster cm ON ae.Student_ClassID = cm.ID INNER JOIN ApplicationStatus_Master asm ON ae.ApplicationStatus_ID = asm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) AND ae.ApplicationDate >= DATEADD(DAY, -30, GETDATE()) ORDER BY ae.ApplicationDate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (566, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q567 | List all vehicle types and their count. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all vehicle types and their count.',
        @sql NVARCHAR(MAX) = N'SELECT Vehicle_Type_Name, COUNT(*) AS VehicleCount FROM VehicleMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) GROUP BY Vehicle_Type_Name ORDER BY VehicleCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (567, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q568 | What is the total concession given this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total concession given this year?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(ISNULL(Concession_Amt, 0)) AS TotalConcession FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (568, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q569 | Yesterday's attendance report please ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Yesterday''s attendance report please',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CASE WHEN Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS Present, SUM(CASE WHEN Attendance_Status_ID = 2 THEN 1 ELSE 0 END) AS Absent FROM Staff_Attendance WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND Attendance_Date = DATEADD(DAY, -1, CAST(GETDATE() AS DATE));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (569, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q570 | Average collection per receipt this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Average collection per receipt this year',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(fc.Receipt_Amt) / NULLIF(COUNT(fc.Id), 0) AS DECIMAL(10,2)) AS AvgPerReceipt FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (570, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q571 | Did all teachers come in on Monday? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Did all teachers come in on Monday?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) AS Present, COUNT(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 END) AS Absent FROM Staff_Attendance sa WHERE CAST(sa.Attendance_Date AS DATE) = CAST(DATEADD(DAY, 2 - DATEPART(WEEKDAY, GETDATE()), GETDATE()) AS DATE)  AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (571, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q572 | Compare cash vs online vs cheque collection ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare cash vs online vs cheque collection',
        @sql NVARCHAR(MAX) = N'SELECT cmm.Name, SUM(fc.Receipt_Amt) AS TotalAmount, COUNT(fc.Id) AS TransactionCount FROM FeesCollection fc LEFT JOIN CollectionMode_Master cmm ON fc.Collection_Mode_ID = cmm.ID WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cmm.Name IN (''Cash'', ''Bank Online Transfer'', ''Cheque'') AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY cmm.Name ORDER BY SUM(fc.Receipt_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (572, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q573 | Teacher attendance for the last 7 days ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Teacher attendance for the last 7 days',
        @sql NVARCHAR(MAX) = N'SELECT sa.Attendance_Date, COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) AS Present, COUNT(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 END) AS Absent FROM Staff_Attendance sa INNER JOIN Staff_Master sfm ON sa.Staff_ID = sfm.Staff_ID AND sfm.StaffStatus_ID = 1 WHERE sa.Attendance_Date >= DATEADD(DAY, -7, CAST(GETDATE() AS DATE)) AND sa.Attendance_Date <= CAST(GETDATE() AS DATE)   AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sa.Attendance_Date ORDER BY sa.Attendance_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (573, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q574 | What is the total bus fee demand this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total bus fee demand this year?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(Amount) AS BusFeeDemand FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND IsBusFee = 1 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (574, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q575 | Show quarterly collection comparison across years ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show quarterly collection comparison across years',
        @sql NVARCHAR(MAX) = N'SELECT bad.Name AS AcademicYear, DATEPART(QUARTER, fc.Bill_Date) AS Quarter, SUM(fc.Receipt_Amt) AS QuarterlyCollection FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bad.Name, DATEPART(QUARTER, fc.Bill_Date) ORDER BY bad.Name, Quarter;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (575, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q576 | Can you show class-wise collection with rank and percentage? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show class-wise collection with rank and percentage?',
        @sql NVARCHAR(MAX) = N'WITH ClassCollection AS (SELECT cm.Name AS ClassName, cm.DisplayOrder, SUM(fc.Receipt_Amt) AS TotalCollection FROM FeesCollection fc JOIN ClassMaster cm ON fc.Class_ID = cm.ID JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name, cm.DisplayOrder) SELECT ClassName, TotalCollection, RANK() OVER (ORDER BY TotalCollection DESC) AS CollectionRank, CAST(TotalCollection * 100.0 / NULLIF(SUM(TotalCollection) OVER (), 0) AS DECIMAL(5,2)) AS PercentContribution FROM ClassCollection ORDER BY DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (576, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q577 | Let me see fee-type-wise concession given ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see fee-type-wise concession given',
        @sql NVARCHAR(MAX) = N'SELECT f.FeesType_Name, SUM(ISNULL(f.Concession_Amt, 0)) AS Concession FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.FeesType_Name ORDER BY Concession DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (577, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q578 | What is the enquiry to admission ratio class-wise? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the enquiry to admission ratio class-wise?',
        @sql NVARCHAR(MAX) = N'DECLARE @StatusConverted bigint = (SELECT TOP 1 ID FROM Enquiry_Status_Master WHERE Name = ''Completed'');
WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT cm.Name AS ClassName, COUNT(*) AS TotalEnquiries, SUM(CASE WHEN em.CallStatus_ID = @StatusConverted THEN 1 ELSE 0 END) AS Admissions, CAST(SUM(CASE WHEN em.CallStatus_ID = @StatusConverted THEN 1 ELSE 0 END) * 1.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS Ratio FROM GeneralCallRegister em INNER JOIN ClassMaster cm ON em.Class_ID = cm.ID WHERE em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND (em.IsDeleted = 0 OR em.IsDeleted IS NULL) GROUP BY cm.Name ORDER BY Ratio DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (578, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q579 | Hey, what's the average fee per boarding point across all routes? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the average fee per boarding point across all routes?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(AVG(CAST(bpm.Amount AS FLOAT)), 2) AS AvgFeePerBoardingPoint FROM Route_Master rm INNER JOIN Route_MasterDetails rmd ON rm.ID = rmd.Route_ID INNER JOIN BoardingPoint_Master bpm ON rmd.BoardingPoint_ID = bpm.Id WHERE rm.IsDeleted = 0 AND rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (579, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q580 | How many girls in Class 8 at the Ashok Nagar branch? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many girls in Class 8 at the Ashok Nagar branch?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS Girls FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.Gender IN (''Female'', ''Girl'') AND cm.Name IN (''Class 8'', ''VIII'') AND sm.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%Ashok Nagar%'' OR ShortName LIKE ''%Ashok Nagar%'')) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (580, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q581 | Tell me about the subject toppers for Class 10 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Tell me about the subject toppers for Class 10',
        @sql NVARCHAR(MAX) = N'SELECT * FROM (SELECT smd.StudentID, s.Name AS Subject, smd.Marks, ROW_NUMBER() OVER (PARTITION BY s.Name ORDER BY smd.Marks DESC) AS Rn FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ClassMaster c ON smm.ClassID = c.ID INNER JOIN Subject_Master s ON s.BranchID = smd.BranchID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND c.Name = ''Class 10'' AND s.IsDeleted = 0) t WHERE Rn = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (581, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q582 | How many enquiries were received today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many enquiries were received today?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS TodayEnquiries FROM GeneralCallRegister WHERE CAST(CallDate AS DATE) = CAST(GETDATE() AS DATE) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (582, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q583 | Which classes got homework today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which classes got homework today?',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT cm.Name AS ClassName FROM HomeWorkAndAssignment hwa INNER JOIN ClassMaster cm ON hwa.Class_ID = cm.ID WHERE CAST(hwa.AssignmentDate AS DATE) = CAST(GETDATE() AS DATE) AND (hwa.IsDeleted IS NULL OR hwa.IsDeleted = 0) AND hwa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hwa.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (583, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q584 | I wanna see vIP student attendance today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I wanna see vIP student attendance today',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName, CASE WHEN sa.Attendance_Status_ID = 1 THEN ''Present'' ELSE ''Absent'' END AS Status FROM StudentAttendance sa INNER JOIN Student_Master sm ON sa.Student_ID = sm.ID INNER JOIN StudentAcademicDetail sad ON sa.Student_ID = sad.StudentID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sm.IsVIP = 1 AND sad.IsActive = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (584, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q585 | How many staff are on hold? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many staff are on hold?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS HoldStaff FROM EmployeeMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0 AND IsHold = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (585, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q586 | Show complete class-subject-teacher mapping. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show complete class-subject-teacher mapping.',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, sub.Name AS SubjectName, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS TeacherName FROM ClassSubjectDetails cs INNER JOIN ClassMaster cm ON cs.Class_Id = cm.ID INNER JOIN Subject_Master sub ON cs.Subject_Id = sub.Id LEFT JOIN SubjectAllocation_Master sam ON sam.Class_ID = cs.Class_Id AND sam.Subject_ID = cs.Subject_Id AND (sam.IsDeleted = 0 OR sam.IsDeleted IS NULL) LEFT JOIN Staff_Master sm ON sam.Staff_ID = sm.Staff_ID WHERE cs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND cs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY cm.Name, sub.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (586, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q587 | Show fee type wise collection this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show fee type wise collection this year',
        @sql NVARCHAR(MAX) = N'SELECT fcd.FeesType_Name, SUM(fcd.Paid_Amt) AS total_collected FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fcd.FeesType_Name ORDER BY SUM(fcd.Paid_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (587, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q588 | Tell me about the pull up the absentee list ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Tell me about the pull up the absentee list',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName, secm.Name FROM StudentAttendance sa INNER JOIN Student_Master sm ON sa.Student_ID = sm.ID INNER JOIN StudentAcademicDetail sad ON sa.Student_ID = sad.StudentID AND sa.Class_ID = sad.ClassID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID INNER JOIN SectionMaster secm ON sad.SectionID = secm.ID WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.Attendance_Status_ID = 2 AND sad.IsActive = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (588, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q589 | Hey, how many boys and girls are there in Class 3? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many boys and girls are there in Class 3?',
        @sql NVARCHAR(MAX) = N'SELECT sm.Gender, COUNT(*) AS StudentCount FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID=sm.ID INNER JOIN ClassMaster cm ON sad.ClassID=cm.ID WHERE cm.Name IN (''Class 3'',''III'') AND sad.IsActive=1 AND (sad.IsTCIssued=0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.Gender;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (589, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q590 | Can you show me the list of exam terms configured? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show me the list of exam terms configured?',
        @sql NVARCHAR(MAX) = N'SELECT etm.Name, etm.Code FROM ExamTermMaster etm WHERE etm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (etm.Deleted IS NULL OR etm.Deleted = 0) ORDER BY etm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (590, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q591 | I need to see any day closure where total doesn't maTCh sum of cash, online, and cheque ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see any day closure where total doesn''t maTCh sum of cash, online, and cheque',
        @sql NVARCHAR(MAX) = N'WITH dc AS (SELECT dm.ID, dm.DayClosureDate AS ClosureDate, dm.CollectedByName AS ClosedBy_Name, SUM(dmd.CollectedAmount) AS TotalCollection, SUM(CASE WHEN cmm.Name = ''Cash'' THEN dmd.CollectedAmount ELSE 0 END) AS CashCollection, SUM(CASE WHEN cmm.Name = ''Bank Online Transfer'' THEN dmd.CollectedAmount ELSE 0 END) AS OnlineCollection, SUM(CASE WHEN cmm.Name NOT IN (''Cash'', ''Bank Online Transfer'', ''Cheque'') THEN dmd.CollectedAmount ELSE 0 END) AS OtherCollection, SUM(CASE WHEN cmm.Name = ''Cheque'' THEN dmd.CollectedAmount ELSE 0 END) AS ChequeCollection FROM DayclosureMaster dm INNER JOIN DayclosureMaster_Details dmd ON dmd.HeaderID = dm.ID LEFT JOIN CollectionMode_Master cmm ON dmd.CollectionMode_ID = cmm.ID WHERE dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (dm.IsDeleted = 0 OR dm.IsDeleted IS NULL) AND (dmd.IsDeleted = 0 OR dmd.IsDeleted IS NULL) GROUP BY dm.ID, dm.DayClosureDate, dm.CollectedByName) SELECT CAST(ClosureDate AS DATE) AS ClosureDay, TotalCollection, CashCollection + OnlineCollection + ChequeCollection AS CalculatedTotal, TotalCollection - (CashCollection + OnlineCollection + ChequeCollection) AS Discrepancy FROM dc WHERE TotalCollection != (CashCollection + OnlineCollection + ChequeCollection);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (591, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q592 | Compare staff strength across my branches ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare staff strength across my branches',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, COUNT(*) AS Staff FROM Staff_Master sfm JOIN BranchMaster bm ON sfm.BranchID = bm.ID WHERE (sfm.IsDeleted = 0 OR sfm.IsDeleted IS NULL) AND sfm.StaffStatus_ID = 1 AND sfm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY Staff DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (592, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q593 | List staff currently on leave today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List staff currently on leave today',
        @sql NVARCHAR(MAX) = N'SELECT lem.Staff_Name AS StaffName, lem.LeaveType_ID, lem.NoOfDays, lem.Purpose AS Reason FROM LeaveEntryMaster lem INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND ls.Name = ''Approved'' AND CAST(GETDATE() AS DATE) BETWEEN lem.LeaveFromDate AND lem.LeaveToDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (593, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q594 | How many students left between April and June? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students left between April and June?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TCIssuedCount FROM StudentAcademicDetail sad WHERE sad.IsTCIssued = 1 AND sad.TCIssuedDate >= DATEFROMPARTS(CASE WHEN MONTH(GETDATE()) >= 4 THEN YEAR(GETDATE()) ELSE YEAR(GETDATE())-1 END + 0, 4, 1) AND sad.TCIssuedDate < DATEFROMPARTS(CASE WHEN MONTH(GETDATE()) >= 4 THEN YEAR(GETDATE()) ELSE YEAR(GETDATE())-1 END + 0, 7, 1) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (594, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q595 | Has our fee recovery improved from last year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Has our fee recovery improved from last year?',
        @sql NVARCHAR(MAX) = N'SELECT ''Current Year'' AS Period, CAST(SUM(fcd.Paid_Amt) * 100.0 / NULLIF(SUM(fcd.Fees_Amount), 0) AS DECIMAL(5,2)) AS RecoveryPercent FROM FeesCollection_Details fcd WHERE fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) UNION ALL SELECT ''Previous Year'' AS Period, CAST(SUM(fcd.Paid_Amt) * 100.0 / NULLIF(SUM(fcd.Fees_Amount), 0) AS DECIMAL(5,2)) AS RecoveryPercent FROM FeesCollection_Details fcd WHERE fcd.AcademicYearID IN (SELECT PreviousYearID FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (595, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q596 | Show me the collection summary for today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me the collection summary for today',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS total_receipts, COUNT(DISTINCT fc.Student_ID) AS students_count, SUM(fc.Receipt_Amt) AS total_amount, cmm.Name AS mode FROM FeesCollection fc LEFT JOIN CollectionMode_Master cmm ON fc.Collection_Mode_ID = cmm.ID WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cmm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (596, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q597 | Show staff who joined in the last 3 months ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show staff who joined in the last 3 months',
        @sql NVARCHAR(MAX) = N'SELECT sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName, sm.Staff_DOJ FROM Staff_Master sm WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.Staff_DOJ >= DATEADD(MONTH, -3, GETDATE());',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (597, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q598 | Average marks progression across all exams ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Average marks progression across all exams',
        @sql NVARCHAR(MAX) = N'SELECT et.Name AS ExamType, et.ID AS ExamOrder, CAST(AVG(smd.Marks) AS DECIMAL(5,2)) AS AvgMarks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ExamTypeMaster et ON smm.ExamTypeID = et.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND et.IsDeleted = 0 GROUP BY et.Name, et.ID ORDER BY et.ID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (598, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q599 | Which class has the most new admissions? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which class has the most new admissions?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 cm.Name AS ClassName, COUNT(DISTINCT sad.StudentID) AS NewAdmissions FROM StudentAcademicDetail sad JOIN ClassMaster cm ON sad.ClassID = cm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNewAdmission = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name ORDER BY NewAdmissions DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (599, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q600 | Attendance report for 5th June ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Attendance report for 5th June',
        @sql NVARCHAR(MAX) = N'SELECT sa.Class_ID, COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) AS PresentCount, COUNT(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 END) AS AbsentCount FROM StudentAttendance sa WHERE sa.Attendance_Date = DATEFROMPARTS(CASE WHEN MONTH(GETDATE()) >= 4 THEN YEAR(GETDATE()) ELSE YEAR(GETDATE())-1 END + 0, 6, 5) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sa.Class_ID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
PRINT 'checkpoint: reached Q600';
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (600, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q601 | What is the class-wise conversion rate? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the class-wise conversion rate?',
        @sql NVARCHAR(MAX) = N'DECLARE @StatusConverted bigint = (SELECT TOP 1 ID FROM Enquiry_Status_Master WHERE Name = ''Completed'');
WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT cm.Name AS ClassName, COUNT(*) AS TotalEnquiries, SUM(CASE WHEN em.CallStatus_ID = @StatusConverted THEN 1 ELSE 0 END) AS Converted, ROUND(SUM(CASE WHEN em.CallStatus_ID = @StatusConverted THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0), 2) AS ConversionRate FROM GeneralCallRegister em INNER JOIN ClassMaster cm ON em.Class_ID = cm.ID WHERE em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND em.IsDeleted = 0 GROUP BY cm.Name ORDER BY ConversionRate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (601, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q602 | Can you show payment mode wise collection today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show payment mode wise collection today?',
        @sql NVARCHAR(MAX) = N'SELECT cmm.Name AS payment_mode, ISNULL(SUM(fc.Receipt_Amt), 0) AS amount FROM FeesCollection fc LEFT JOIN CollectionMode_Master cmm ON fc.Collection_Mode_ID = cmm.ID WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cmm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (602, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q603 | Sections with exactly one student ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Sections with exactly one student',
        @sql NVARCHAR(MAX) = N'SELECT sad.ClassName, secm.Name AS SectionName, COUNT(sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad INNER JOIN SectionMaster secm ON sad.SectionID = secm.ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) GROUP BY sad.ClassID, sad.ClassName, secm.Name HAVING COUNT(sad.StudentID) = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (603, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q604 | Which class lost the most students this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which class lost the most students this year?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 cm.Name AS ClassName, COUNT(*) AS TCCount FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsTCIssued = 1 GROUP BY cm.Name ORDER BY COUNT(*) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (604, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q605 | Find students whose father name is not filled ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Find students whose father name is not filled',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.FatherName IS NULL OR sm.FatherName = '''');',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (605, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q606 | How many kids bunked today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many kids bunked today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS AbsentToday FROM StudentAttendance sa WHERE sa.Attendance_Status_ID = 2 AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (606, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q607 | List students who left the school but are still awaiting TC issuance ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List students who left the school but are still awaiting TC issuance',
        @sql NVARCHAR(MAX) = N'SELECT sad.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id INNER JOIN Student_Master stm ON sad.StudentID = stm.ID WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.IsActive = 0 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (607, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q608 | How many new admissions do we have this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many new admissions do we have this year?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS new_admissions FROM StudentAcademicDetail sad WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.IsNewAdmission = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (608, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q609 | Which class has the highest strength? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which class has the highest strength?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 cm.Name AS ClassName, COUNT(DISTINCT sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad JOIN ClassMaster cm ON sad.ClassID = cm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name ORDER BY StudentCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (609, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q610 | Names and phone numbers of top 10 fee defaulters ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Names and phone numbers of top 10 fee defaulters',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sm.FatherContactNo, sm.MotherContactNo, sad.ClassName, SUM(fcd.Remaining_Amt) AS TotalOutstanding FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN FeesCollection fc ON sm.ID = fc.Student_ID INNER JOIN FeesCollection_Details fcd ON fc.Id = fcd.Fees_Collection_ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.ID, sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo, sm.FatherContactNo, sm.MotherContactNo, sad.ClassName HAVING SUM(fcd.Remaining_Amt) > 0 ORDER BY TotalOutstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (610, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q611 | What's today's collection? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s today''s collection?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS today_collection FROM FeesCollection fc WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (611, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q612 | Which term and class combination has the worst collection? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which term and class combination has the worst collection?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 fcd.Term_ID, cm.Name AS ClassName, SUM(fcd.Paid_Amt) AS Collected FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN ClassMaster cm ON fc.Class_ID = cm.ID WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fcd.Term_ID, cm.Name ORDER BY Collected ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (612, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q613 | Can you show all pending leave requests with staff details? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show all pending leave requests with staff details?',
        @sql NVARCHAR(MAX) = N'SELECT lem.Staff_Name AS StaffName, lem.LeaveFromDate, lem.LeaveToDate, lem.NoOfDays, lem.Purpose AS Reason, lem.LeaveType_ID FROM LeaveEntryMaster lem INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND ls.Name = ''Pending'' ORDER BY lem.LeaveFromDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (613, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q614 | Give me the pass percentage for Class 12 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the pass percentage for Class 12',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(CASE WHEN smd.Marks >= eced.MinMark THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS PassPercentage FROM StudentMarkDetails smd INNER JOIN ExamConfigurationEvaluationDetails eced ON smd.EvalHierID = eced.ID INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ClassMaster c ON smm.ClassID = c.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND c.Name = ''Class 12'';',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (614, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q615 | Show daily homework count for the last 2 weeks. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show daily homework count for the last 2 weeks.',
        @sql NVARCHAR(MAX) = N'SELECT CAST(AssignmentDate AS DATE) AS AssignDate, COUNT(*) AS HomeworkCount FROM HomeWorkAndAssignment WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND AssignmentDate >= DATEADD(DAY, -14, GETDATE()) GROUP BY CAST(AssignmentDate AS DATE) ORDER BY AssignDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (615, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q616 | How many exams has the school conducted this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many exams has the school conducted this year?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT etm.ID) AS ExamCount FROM ExamTypeMaster etm WHERE etm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND etm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND etm.IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (616, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q617 | Staff count - teaching vs non-teaching ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Staff count - teaching vs non-teaching',
        @sql NVARCHAR(MAX) = N'SELECT gm.StaffTypeName, COUNT(DISTINCT gem.EmployeeID) AS StaffCount FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) GROUP BY gm.StaffTypeName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (617, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q618 | Show the top 5 classes by total fee demand. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the top 5 classes by total fee demand.',
        @sql NVARCHAR(MAX) = N'SELECT TOP 5 ClassName, SUM(Amount) AS TotalDemand FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY ClassName ORDER BY TotalDemand DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (618, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q619 | Students admitted in June 2025 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students admitted in June 2025',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sm.AdmissionDate, sad.ClassName FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND MONTH(sm.AdmissionDate) = 6 AND YEAR(sm.AdmissionDate) = 2025;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (619, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q620 | Hey, how many students have opted for food? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many students have opted for food?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS food_students FROM StudentAcademicDetail sad WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.FoodRequired = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (620, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q621 | How does this year's total refund compare to last year's? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How does this year''s total refund compare to last year''s?',
        @sql NVARCHAR(MAX) = N'SELECT AcademicYearID, SUM(Refund_Amt) AS TotalRefund FROM RefundReceipt WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY AcademicYearID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (621, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q622 | Who's handling the most enquiries this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who''s handling the most enquiries this month?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 5 gcr.HandledBy_ID, COUNT(*) AS EnquiryCount FROM GeneralCallRegister gcr WHERE MONTH(gcr.CallDate) = MONTH(GETDATE()) AND YEAR(gcr.CallDate) = YEAR(GETDATE()) AND gcr.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (gcr.IsDeleted = 0 OR gcr.IsDeleted IS NULL) GROUP BY gcr.HandledBy_ID ORDER BY EnquiryCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (622, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q623 | What's the gender ratio class-wise? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the gender ratio class-wise?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(CASE WHEN sm.Gender IN (''Male'', ''Boy'') THEN 1 END) AS Boys, COUNT(CASE WHEN sm.Gender IN (''Female'', ''Girl'') THEN 1 END) AS Girls, CAST(COUNT(CASE WHEN sm.Gender IN (''Male'', ''Boy'') THEN 1 END) * 1.0 / NULLIF(COUNT(CASE WHEN sm.Gender IN (''Female'', ''Girl'') THEN 1 END), 0) AS DECIMAL(5,2)) AS BoyGirlRatio FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN ClassMaster cm ON sad.ClassID = cm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name, cm.DisplayOrder ORDER BY cm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (623, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q624 | Show me all routes with vehicle number details. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me all routes with vehicle number details.',
        @sql NVARCHAR(MAX) = N'SELECT Name AS RouteName, Code AS RouteCode, VehicleNo FROM Route_Master WHERE IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (624, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q625 | Let me see section-wise subject allocation for Class 9 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see section-wise subject allocation for Class 9',
        @sql NVARCHAR(MAX) = N'SELECT secm.Name AS SectionName, sub.Name AS SubjectName, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS TeacherName FROM SubjectAllocation_Master sam INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID INNER JOIN SectionMaster secm ON sam.Section_ID = secm.ID INNER JOIN Subject_Master sub ON sam.Subject_ID = sub.Id LEFT JOIN Staff_Master sm ON sam.Staff_ID = sm.Staff_ID WHERE sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (sam.IsDeleted = 0 OR sam.IsDeleted IS NULL) AND cm.Name IN (''Class 9'', ''IX'') ORDER BY secm.Name, sub.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (625, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q626 | Hey, what's the outstanding for Term 2? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the outstanding for Term 2?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS Term2Outstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND Term_Name IN (''Term 2'', ''II'') AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (626, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q627 | Which vehicles have FC date expiring soon? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which vehicles have FC date expiring soon?',
        @sql NVARCHAR(MAX) = N'SELECT Vehicle_Number, Vehicle_Type_Name, FC_Date FROM VehicleMaster WHERE FC_Date BETWEEN GETDATE() AND DATEADD(DAY, 30, GETDATE()) AND IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (627, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q628 | Mode-wise collection breakup for this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Mode-wise collection breakup for this month',
        @sql NVARCHAR(MAX) = N'SELECT cmm.Name AS payment_mode, ISNULL(SUM(fc.Receipt_Amt), 0) AS total_amount, COUNT(*) AS receipt_count FROM FeesCollection fc LEFT JOIN CollectionMode_Master cmm ON fc.Collection_Mode_ID = cmm.ID WHERE DATEPART(MONTH, fc.Bill_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, fc.Bill_Date) = DATEPART(YEAR, GETDATE()) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cmm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (628, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q629 | I need the Class 10 result summary ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need the Class 10 result summary',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT smd.StudentID) AS TotalStudents, CAST(AVG(smd.Marks) AS DECIMAL(5,2)) AS AvgMarks, MAX(smd.Marks) AS HighestMarks, MIN(smd.Marks) AS LowestMarks, CAST(SUM(CASE WHEN smd.Marks >= eced.MinMark THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS PassPct FROM StudentMarkDetails smd INNER JOIN ExamConfigurationEvaluationDetails eced ON smd.EvalHierID = eced.ID INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ClassMaster c ON smm.ClassID = c.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND c.Name = ''Class 10'';',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (629, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q630 | Which students are failing in Science? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which students are failing in Science?',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT pc.StudentName AS StudentName, cm.Name AS ClassName, pc.Marks FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE pc.SubjectName = ''Science'' AND pc.Marks < pc.MinMark AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) ORDER BY cm.Name, StudentName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (630, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q631 | Can I see the Class with lowest fee recovery? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can I see the Class with lowest fee recovery?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 cm.Name AS ClassName, CAST(SUM(fcd.Paid_Amt) * 100.0 / NULLIF(SUM(fcd.Fees_Amount), 0) AS DECIMAL(5,2)) AS RecoveryPercent FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN ClassMaster cm ON fc.Class_ID = cm.ID WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY cm.Name ORDER BY RecoveryPercent ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (631, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q632 | Fee collection summary - class wise and month wise ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Fee collection summary - class wise and month wise',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS class_name, DATENAME(MONTH, fc.Bill_Date) AS month_name, SUM(fc.Receipt_Amt) AS collection FROM FeesCollection fc JOIN ClassMaster cm ON fc.Class_ID = cm.ID WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name, DATENAME(MONTH, fc.Bill_Date), DATEPART(MONTH, fc.Bill_Date) ORDER BY cm.Name, DATEPART(MONTH, fc.Bill_Date);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (632, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q633 | Who has the most absences among staff? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who has the most absences among staff?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 5 sa.Staff_ID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName, COUNT(*) AS AbsentDays FROM Staff_Attendance sa INNER JOIN Staff_Master sm ON sa.Staff_ID = sm.Staff_ID AND sm.StaffStatus_ID = 1 WHERE sa.Attendance_Status_ID = 2 AND MONTH(sa.Attendance_Date) = MONTH(GETDATE()) AND YEAR(sa.Attendance_Date) = YEAR(GETDATE()) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sa.Staff_ID, sm.Staff_FirstName, sm.Staff_LastName ORDER BY AbsentDays DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (633, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q634 | Count of staff on hold ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Count of staff on hold',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS StaffOnHold FROM EmployeeMaster WHERE IsHold = 1 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (634, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q635 | Which teachers are absent today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which teachers are absent today?',
        @sql NVARCHAR(MAX) = N'SELECT sa.Staff_ID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName, sa.Attendance_Reason FROM Staff_Attendance sa INNER JOIN Staff_Master sm ON sa.Staff_ID = sm.Staff_ID AND sm.StaffStatus_ID = 1 INNER JOIN StaffType_Master stm ON sm.StaffType_ID = stm.ID INNER JOIN StaffTypeCategoryMaster stcm ON stm.Type_Id = stcm.Id WHERE sa.Attendance_Date = CAST(GETDATE() AS DATE) AND sa.Attendance_Status_ID = 2 AND stcm.Name = ''Academic'' AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (635, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q636 | Class-wise new admissions count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class-wise new admissions count',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS class_name, COUNT(*) AS new_admissions FROM StudentAcademicDetail sad JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.IsNewAdmission = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY cm.Name ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (636, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q637 | Give me the lowdown on transport fees ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the lowdown on transport fees',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fcd.Fees_Amount) AS TotalDemand, SUM(fcd.Paid_Amt) AS TotalPaid, SUM(fcd.Remaining_Amt) AS Outstanding FROM FeesCollection_Details fcd WHERE fcd.FeesType_Name LIKE ''%Transport%'' AND fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (637, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q638 | What is the outstanding amount for Class 10? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the outstanding amount for Class 10?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.ClassName = ''Class 10'' AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (638, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q639 | Year-wise average attendance percentage ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Year-wise average attendance percentage',
        @sql NVARCHAR(MAX) = N'SELECT bad.Name AS AcademicYear, CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AvgAttendancePercent FROM StudentAttendance sa JOIN Branch_Academic_Details bad ON sa.AcademicYearID = bad.Id WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bad.Name ORDER BY bad.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (639, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q640 | Class-wise absent count today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class-wise absent count today',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(DISTINCT sa.Student_ID) AS AbsentCount FROM StudentAttendance sa JOIN ClassMaster cm ON sa.Class_ID = cm.ID JOIN Branch_Academic_Details bad ON sa.AcademicYearID = bad.Id WHERE sa.Attendance_Status_ID = 2 AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name, cm.DisplayOrder ORDER BY cm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (640, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q641 | Students absent for 3 consecutive days ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students absent for 3 consecutive days',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, sm.AdmissionNo, cm.Name AS class_name FROM Student_Master sm JOIN StudentAttendance sa1 ON sm.ID = sa1.Student_ID JOIN StudentAttendance sa2 ON sm.ID = sa2.Student_ID JOIN StudentAttendance sa3 ON sm.ID = sa3.Student_ID JOIN ClassMaster cm ON sa1.Class_ID = cm.ID WHERE sa1.Attendance_Status_ID = 2 AND sa2.Attendance_Status_ID = 2 AND sa3.Attendance_Status_ID = 2 AND CAST(sa1.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND CAST(sa2.Attendance_Date AS DATE) = CAST(DATEADD(DAY, -1, GETDATE()) AS DATE) AND CAST(sa3.Attendance_Date AS DATE) = CAST(DATEADD(DAY, -2, GETDATE()) AS DATE) AND sa1.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (641, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q642 | How many defaulters are there in each class? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many defaulters are there in each class?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS class_name, COUNT(DISTINCT fc.Student_ID) AS defaulter_count FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN ClassMaster cm ON fc.Class_ID = cm.ID JOIN StudentAcademicDetail sad ON fc.Student_ID = sad.StudentID AND fc.AcademicYearID = sad.AcademicYearID WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fcd.Remaining_Amt > 0 AND sad.IsActive = 1 GROUP BY cm.Name ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (642, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q643 | What's the attendance report for 5th June? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the attendance report for 5th June?',
        @sql NVARCHAR(MAX) = N'SELECT sa.Class_ID, COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) AS PresentCount, COUNT(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 END) AS AbsentCount FROM StudentAttendance sa WHERE sa.Attendance_Date = DATEFROMPARTS(CASE WHEN MONTH(GETDATE()) >= 4 THEN YEAR(GETDATE()) ELSE YEAR(GETDATE())-1 END + 0, 6, 5) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sa.Class_ID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (643, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q644 | I need to see the bus fee collection rate ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see the bus fee collection rate',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(SUM(Paid_Amt) * 100.0 / NULLIF(SUM(Amount), 0), 2) AS BusFeeCollectionRate FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND IsBusFee = 1 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (644, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q645 | Total lien amount held per branch ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total lien amount held per branch',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, SUM(ISNULL(fisd.Lien_Amount,0)) AS TotalLien FROM FeesInformationStudentDetail fisd JOIN BranchMaster bm ON fisd.BranchID = bm.ID WHERE fisd.IsIncludedInLumpSum <> 1 AND fisd.IsDonation = 0 AND fisd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY TotalLien DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (645, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q646 | Rank houses by total students ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Rank houses by total students',
        @sql NVARCHAR(MAX) = N'SELECT sad.HouseName, COUNT(sad.Id) AS StudentCount, RANK() OVER (ORDER BY COUNT(sad.Id) DESC) AS Ranking FROM StudentAcademicDetail sad WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.HouseName IS NOT NULL GROUP BY sad.HouseName ORDER BY StudentCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (646, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q647 | Show suspended students count per branch today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show suspended students count per branch today',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, COUNT(*) AS Suspended FROM StudentAttendance sa JOIN BranchMaster bm ON sa.BranchID = bm.ID WHERE sa.Attendance_Status_ID = 7 AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY Suspended DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (647, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q648 | Transport fee collection for this term ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Transport fee collection for this term',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fcd.Paid_Amt) AS TransportFeeCollected FROM FeesCollection_Details fcd INNER JOIN Fees_Master fm ON fcd.Fees_Head_ID = fm.ID WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fm.Name LIKE ''%Transport%'';',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (648, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q649 | What is the average number of days between admission and first fee payment? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the average number of days between admission and first fee payment?',
        @sql NVARCHAR(MAX) = N'WITH FirstPayment AS (SELECT fc.Student_ID, MIN(fc.Bill_Date) AS FirstPayDate FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fc.Student_ID) SELECT CAST(AVG(CAST(DATEDIFF(DAY, sm.AdmissionDate, fp.FirstPayDate) AS FLOAT)) AS DECIMAL(5,1)) AS AvgDaysToFirstPayment FROM FirstPayment fp JOIN Student_Master sm ON fp.Student_ID = sm.ID JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNewAdmission = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (649, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q650 | How many absentees in each Class today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many absentees in each Class today?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS class_name, COUNT(*) AS absent_count FROM StudentAttendance sa JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.Attendance_Status_ID = 2 AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name ORDER BY COUNT(*) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (650, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q651 | Let me see students who have other exam registrations ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see students who have other exam registrations',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, sad.OtherExamName FROM Student_Master sm JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.OtherExam = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.ClassName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (651, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q652 | Total salary paid for the current academic year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total salary paid for the current academic year',
        @sql NVARCHAR(MAX) = N'SELECT SUM(gem.NetPay) AS TotalPaid FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID INNER JOIN Branch_Academic_Details b ON gm.AcademicYearID = b.Id WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND GETDATE() BETWEEN b.Start_Date AND b.End_Date AND gm.IsDeleted = 0 AND gem.IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (652, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q653 | What will our collection be next month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What will our collection be next month?',
        @sql NVARCHAR(MAX) = N'-- This question asks for a future prediction, which I cannot provide. I can only query existing data.
-- Here''s the month-wise collection trend this year:
SELECT DATENAME(MONTH, fc.Bill_Date) AS MonthName, ISNULL(SUM(fc.Receipt_Amt), 0) AS Collection FROM FeesCollection fc WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY DATENAME(MONTH, fc.Bill_Date), MONTH(fc.Bill_Date) ORDER BY MONTH(fc.Bill_Date);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (653, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q654 | Which class has the most demand based on enquiries? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which class has the most demand based on enquiries?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT TOP 5 cm.Name AS ClassName, COUNT(*) AS EnquiryCount FROM GeneralCallRegister em INNER JOIN ClassMaster cm ON em.Class_ID = cm.ID WHERE em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND (em.IsDeleted = 0 OR em.IsDeleted IS NULL) GROUP BY cm.Name ORDER BY EnquiryCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (654, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q655 | Compare Term 1 and Term 2 outstanding side by side. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare Term 1 and Term 2 outstanding side by side.',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CASE WHEN Term_Name IN (''Term 1'', ''I'') THEN Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0) ELSE 0 END) AS Term1Outstanding, SUM(CASE WHEN Term_Name IN (''Term 2'', ''II'') THEN Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0) ELSE 0 END) AS Term2Outstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (655, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q656 | Fee collection comparison between sections of Class 9 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Fee collection comparison between sections of Class 9',
        @sql NVARCHAR(MAX) = N'SELECT secm.Name AS SectionName, COUNT(fc.Id) AS Receipts, SUM(fc.Receipt_Amt) AS TotalCollection FROM FeesCollection fc JOIN ClassMaster cm ON fc.Class_ID = cm.ID JOIN SectionMaster secm ON fc.Section_ID = secm.ID JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE cm.Name IN (''Class 9'', ''IX'') AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY secm.Name ORDER BY secm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (656, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q657 | Let me see all admission types available ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see all admission types available',
        @sql NVARCHAR(MAX) = N'SELECT ID, Name, Code, Description FROM AdmissionType_Master WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (IsDeleted = 0 OR IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (657, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q658 | Grade distribution of all students ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Grade distribution of all students',
        @sql NVARCHAR(MAX) = N'SELECT Grade, COUNT(*) AS StudentCount FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND Grade IS NOT NULL GROUP BY Grade ORDER BY Grade;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (658, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q659 | Which department has the least number of employees? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which department has the least number of employees?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 dm.Name AS Department, COUNT(sm.Staff_ID) AS StaffCount FROM StaffDepartmentMaster dm INNER JOIN StaffDepartmentMapping sdm ON dm.Id = sdm.DepartmentID INNER JOIN StaffDepartmentMappingDetail sdmd ON sdm.Id = sdmd.MappingID INNER JOIN Staff_Master sm ON sdmd.StaffID = sm.Staff_ID WHERE dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (dm.IsDeleted IS NULL OR dm.IsDeleted = 0) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1 GROUP BY dm.Name ORDER BY StaffCount ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (659, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q660 | Online payments for Class 10 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Online payments for Class 10',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fc.Receipt_Amt) AS OnlineTotal, COUNT(fc.Id) AS TransactionCount FROM FeesCollection fc INNER JOIN ClassMaster cm ON fc.Class_ID = cm.ID WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.Name IN (''Class 10'', ''X'') AND fc.Collection_Mode_ID IN (SELECT ID FROM CollectionMode_Master WHERE Name = ''Bank Online Transfer'') AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (660, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q661 | Which class has the highest number of new admissions? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which class has the highest number of new admissions?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 cm.Name AS ClassName, COUNT(*) AS NewAdmissions FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsNewAdmission = 1 AND sad.IsActive = 1 GROUP BY cm.Name ORDER BY COUNT(*) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (661, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q662 | How many unassigned tickets are there? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many unassigned tickets are there?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS UnassignedTickets FROM FeedbackTicket ft WHERE NOT EXISTS (SELECT 1 FROM FeedbackTicketReplies ftr WHERE ftr.TicketID = ft.Id) AND ft.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ft.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND ft.Status IN (''Open'', ''In Progress'', ''Reopened'');',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (662, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q663 | Pull up routes sorted by number of stops in descending order ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up routes sorted by number of stops in descending order',
        @sql NVARCHAR(MAX) = N'SELECT rm.Name AS RouteName, COUNT(rmd.Id) AS Stops FROM Route_Master rm INNER JOIN Route_MasterDetails rmd ON rm.ID = rmd.Route_ID INNER JOIN BoardingPoint_Master bpm ON rmd.BoardingPoint_ID = bpm.Id WHERE rm.IsDeleted = 0 AND rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY rm.Name ORDER BY Stops DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (663, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q664 | Show Class 10 students with outstanding above 25000 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show Class 10 students with outstanding above 25000',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName + '' '' + sm.LastName AS StudentName, SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN Student_Master sm ON f.Student_ID = sm.ID WHERE f.ClassName IN (''Class 10'', ''X'') AND f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.FirstName, sm.LastName HAVING SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) > 25000;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (664, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q665 | Show the bus fee vs hostel fee comparison. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the bus fee vs hostel fee comparison.',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CASE WHEN IsBusFee = 1 THEN Amount ELSE 0 END) AS BusFeeDemand, SUM(CASE WHEN IsBusFee = 1 THEN Paid_Amt ELSE 0 END) AS BusFeeCollected, SUM(CASE WHEN IsHostelFee = 1 THEN Amount ELSE 0 END) AS HostelFeeDemand, SUM(CASE WHEN IsHostelFee = 1 THEN Paid_Amt ELSE 0 END) AS HostelFeeCollected FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (665, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q666 | Which day had the highest fee collection this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which day had the highest fee collection this month?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 CAST(fc.Bill_Date AS DATE) AS CollectionDate, SUM(fc.Receipt_Amt) AS DailyCollection FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND MONTH(fc.Bill_Date) = MONTH(GETDATE()) AND YEAR(fc.Bill_Date) = YEAR(GETDATE()) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY CAST(fc.Bill_Date AS DATE) ORDER BY DailyCollection DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (666, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q667 | Which subject has the lowest average marks across the school? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which subject has the lowest average marks across the school?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 pc.SubjectName AS SubjectName, CAST(AVG(pc.Marks) AS DECIMAL(5,2)) AS AvgMarks FROM ProgressCardDataRetrieval pc WHERE pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) GROUP BY pc.SubjectName ORDER BY AvgMarks ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (667, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q668 | What's the staff salary below 20000? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the staff salary below 20000?',
        @sql NVARCHAR(MAX) = N'SELECT gem.EmployeeID, gem.EmployeeName, gem.NetPay FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) AND gem.NetPay < 20000 ORDER BY gem.NetPay ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (668, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q669 | Pull up the number of students who paid fully vs partially vs not paid at all ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up the number of students who paid fully vs partially vs not paid at all',
        @sql NVARCHAR(MAX) = N'SELECT ''Fully Paid'' AS category, COUNT(*) AS student_count FROM (SELECT fc.Student_ID FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN StudentAcademicDetail sad ON fc.Student_ID = sad.StudentID AND fc.AcademicYearID = sad.AcademicYearID WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND sad.IsActive = 1 GROUP BY fc.Student_ID HAVING SUM(fcd.Remaining_Amt) = 0) AS fully_paid UNION ALL SELECT ''Partially Paid'' AS category, COUNT(*) AS student_count FROM (SELECT fc.Student_ID FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN StudentAcademicDetail sad ON fc.Student_ID = sad.StudentID AND fc.AcademicYearID = sad.AcademicYearID WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND sad.IsActive = 1 GROUP BY fc.Student_ID HAVING SUM(fcd.Paid_Amt) > 0 AND SUM(fcd.Remaining_Amt) > 0) AS partial;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (669, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q670 | List students with outstanding in all terms. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List students with outstanding in all terms.',
        @sql NVARCHAR(MAX) = N'SELECT f.Student_ID, s.FirstName, s.LastName, COUNT(DISTINCT f.Term_Name) AS TermsWithDues FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID INNER JOIN Student_Master s ON f.Student_ID = s.ID WHERE f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 0 AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Student_ID, s.FirstName, s.LastName HAVING COUNT(DISTINCT f.Term_Name) = (SELECT COUNT(DISTINCT Term_Name) FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (670, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q671 | How's collection going this week? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How''s collection going this week?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(fc.Bill_Date AS DATE) AS CollectionDate, SUM(fc.Receipt_Amt) AS DailyTotal FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND CAST(fc.Bill_Date AS DATE) >= DATEADD(DAY, 1 - DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE)) AND CAST(fc.Bill_Date AS DATE) <= CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY CAST(fc.Bill_Date AS DATE) ORDER BY CAST(fc.Bill_Date AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (671, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q672 | What is the running total of collections month by month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the running total of collections month by month?',
        @sql NVARCHAR(MAX) = N'WITH dc AS (SELECT dm.ID, dm.DayClosureDate AS ClosureDate, dm.CollectedByName AS ClosedBy_Name, SUM(dmd.CollectedAmount) AS TotalCollection, SUM(CASE WHEN cmm.Name = ''Cash'' THEN dmd.CollectedAmount ELSE 0 END) AS CashCollection, SUM(CASE WHEN cmm.Name = ''Bank Online Transfer'' THEN dmd.CollectedAmount ELSE 0 END) AS OnlineCollection, SUM(CASE WHEN cmm.Name NOT IN (''Cash'', ''Bank Online Transfer'', ''Cheque'') THEN dmd.CollectedAmount ELSE 0 END) AS OtherCollection, SUM(CASE WHEN cmm.Name = ''Cheque'' THEN dmd.CollectedAmount ELSE 0 END) AS ChequeCollection FROM DayclosureMaster dm INNER JOIN DayclosureMaster_Details dmd ON dmd.HeaderID = dm.ID LEFT JOIN CollectionMode_Master cmm ON dmd.CollectionMode_ID = cmm.ID WHERE dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (dm.IsDeleted = 0 OR dm.IsDeleted IS NULL) AND (dmd.IsDeleted = 0 OR dmd.IsDeleted IS NULL) GROUP BY dm.ID, dm.DayClosureDate, dm.CollectedByName) SELECT [Month], MonthlyTotal, SUM(MonthlyTotal) OVER (ORDER BY YM ROWS UNBOUNDED PRECEDING) AS RunningTotal FROM (SELECT YEAR(ClosureDate) * 100 + MONTH(ClosureDate) AS YM, FORMAT(MIN(ClosureDate), ''yyyy-MM'') AS [Month], SUM(TotalCollection) AS MonthlyTotal FROM dc GROUP BY YEAR(ClosureDate) * 100 + MONTH(ClosureDate)) monthly ORDER BY YM;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (672, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q673 | How many enquiries does each handler have? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many enquiries does each handler have?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT HandledBy_ID, COUNT(*) AS EnquiryCount FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0 GROUP BY HandledBy_ID ORDER BY EnquiryCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (673, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q674 | Show refunds issued in the last 7 days. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show refunds issued in the last 7 days.',
        @sql NVARCHAR(MAX) = N'SELECT r.Bill_Date AS RefundDate, sm.FirstName + '' '' + sm.LastName AS StudentName, r.Refund_Amt AS Amount, r.RequestRemarks AS Reason FROM RefundReceipt r INNER JOIN Student_Master sm ON r.Student_ID = sm.ID WHERE r.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND r.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND r.Bill_Date >= DATEADD(DAY, -7, GETDATE()) ORDER BY r.Bill_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (674, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q675 | Who's the class-wise toppers? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who''s the class-wise toppers?',
        @sql NVARCHAR(MAX) = N'SELECT * FROM (SELECT smd.StudentID, c.Name AS ClassName, SUM(smd.Marks) AS TotalMarks, ROW_NUMBER() OVER (PARTITION BY c.Name ORDER BY SUM(smd.Marks) DESC) AS Rn FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ClassMaster c ON smm.ClassID = c.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND c.IsDeleted = 0 GROUP BY smd.StudentID, c.Name) t WHERE Rn = 1 ORDER BY ClassName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (675, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q676 | Show fee-type-wise concession given. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show fee-type-wise concession given.',
        @sql NVARCHAR(MAX) = N'SELECT f.FeesType_Name, SUM(ISNULL(f.Concession_Amt, 0)) AS Concession FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.FeesType_Name ORDER BY Concession DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (676, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q677 | Class 7 students who haven't paid anything this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class 7 students who haven''t paid anything this year',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.FatherName, sm.FatherContactNo FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.Name IN (''Class 7'', ''VII'') AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.StudentID NOT IN (SELECT fc.Student_ID FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (677, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q678 | Average salary of staff with perfect attendance ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Average salary of staff with perfect attendance',
        @sql NVARCHAR(MAX) = N'SELECT CAST(AVG(gem.NetPay) AS DECIMAL(12,2)) AS AvgSalary FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) AND gem.PresentDays = gem.WorkingDays;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (678, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q679 | What is the total demand amount for April month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the total demand amount for April month?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(f.Amount) AS AprilDemand FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.Month_Name = ''April'' AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (679, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q680 | How many homework items were created this academic year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many homework items were created this academic year?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalHomework FROM HomeWorkAndAssignment WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (680, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q681 | Show today's late fee collections ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show today''s late fee collections',
        @sql NVARCHAR(MAX) = N'SELECT fc.Bill_No, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, fcd.LateFeeAmount FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN Student_Master sm ON fc.Student_ID = sm.ID WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.LateFeeAmount > 0 AND CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (681, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q682 | Students in Class 10 who have never been absent and have zero outstanding ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students in Class 10 who have never been absent and have zero outstanding',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT f.Student_ID, sm.FirstName + '' '' + sm.LastName AS StudentName FROM FeesInformationStudentDetail f INNER JOIN Student_Master sm ON f.Student_ID = sm.ID WHERE f.ClassName IN (''Class 10'', ''X'') AND f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY f.Student_ID, sm.FirstName, sm.LastName HAVING SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) = 0 AND f.Student_ID NOT IN (SELECT sa.Student_ID FROM StudentAttendance sa WHERE sa.Attendance_Status_ID = 2);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (682, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q683 | Percentage of students with pending fees ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Percentage of students with pending fees',
        @sql NVARCHAR(MAX) = N'SELECT CAST(COUNT(DISTINCT CASE WHEN (f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 0 THEN f.Student_ID END) * 100.0 / NULLIF(COUNT(DISTINCT f.Student_ID), 0) AS DECIMAL(5,2)) AS PercentWithPending FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (683, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q684 | Late fee as percentage of total collection ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Late fee as percentage of total collection',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(fcd.LateFeeAmount) * 100.0 / NULLIF(SUM(fcd.Paid_Amt), 0) AS DECIMAL(5,2)) AS LateFeePercent FROM FeesCollection_Details fcd WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (684, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q685 | Show any day closure where total doesn't match sum of cash, online, and cheque. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show any day closure where total doesn''t match sum of cash, online, and cheque.',
        @sql NVARCHAR(MAX) = N'WITH dc AS (SELECT dm.ID, dm.DayClosureDate AS ClosureDate, dm.CollectedByName AS ClosedBy_Name, SUM(dmd.CollectedAmount) AS TotalCollection, SUM(CASE WHEN cmm.Name = ''Cash'' THEN dmd.CollectedAmount ELSE 0 END) AS CashCollection, SUM(CASE WHEN cmm.Name = ''Bank Online Transfer'' THEN dmd.CollectedAmount ELSE 0 END) AS OnlineCollection, SUM(CASE WHEN cmm.Name NOT IN (''Cash'', ''Bank Online Transfer'', ''Cheque'') THEN dmd.CollectedAmount ELSE 0 END) AS OtherCollection, SUM(CASE WHEN cmm.Name = ''Cheque'' THEN dmd.CollectedAmount ELSE 0 END) AS ChequeCollection FROM DayclosureMaster dm INNER JOIN DayclosureMaster_Details dmd ON dmd.HeaderID = dm.ID LEFT JOIN CollectionMode_Master cmm ON dmd.CollectionMode_ID = cmm.ID WHERE dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (dm.IsDeleted = 0 OR dm.IsDeleted IS NULL) AND (dmd.IsDeleted = 0 OR dmd.IsDeleted IS NULL) GROUP BY dm.ID, dm.DayClosureDate, dm.CollectedByName) SELECT CAST(ClosureDate AS DATE) AS ClosureDay, TotalCollection, CashCollection + OnlineCollection + ChequeCollection AS CalculatedTotal, TotalCollection - (CashCollection + OnlineCollection + ChequeCollection) AS Discrepancy FROM dc WHERE TotalCollection != (CashCollection + OnlineCollection + ChequeCollection);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (685, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q686 | Show the collection efficiency by class (paid vs demand) ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the collection efficiency by class (paid vs demand)',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, SUM(fcd.Fees_Amount) AS TotalDemand, SUM(fcd.Paid_Amt) AS TotalPaid, CAST(SUM(fcd.Paid_Amt) * 100.0 / NULLIF(SUM(fcd.Fees_Amount), 0) AS DECIMAL(5,2)) AS CollectionEfficiency FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN ClassMaster cm ON fc.Class_ID = cm.ID JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name, cm.DisplayOrder ORDER BY cm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (686, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q687 | Show the total cheque collections this month. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the total cheque collections this month.',
        @sql NVARCHAR(MAX) = N'WITH dc AS (SELECT dm.ID, dm.DayClosureDate AS ClosureDate, dm.CollectedByName AS ClosedBy_Name, SUM(dmd.CollectedAmount) AS TotalCollection, SUM(CASE WHEN cmm.Name = ''Cash'' THEN dmd.CollectedAmount ELSE 0 END) AS CashCollection, SUM(CASE WHEN cmm.Name = ''Bank Online Transfer'' THEN dmd.CollectedAmount ELSE 0 END) AS OnlineCollection, SUM(CASE WHEN cmm.Name NOT IN (''Cash'', ''Bank Online Transfer'', ''Cheque'') THEN dmd.CollectedAmount ELSE 0 END) AS OtherCollection, SUM(CASE WHEN cmm.Name = ''Cheque'' THEN dmd.CollectedAmount ELSE 0 END) AS ChequeCollection FROM DayclosureMaster dm INNER JOIN DayclosureMaster_Details dmd ON dmd.HeaderID = dm.ID LEFT JOIN CollectionMode_Master cmm ON dmd.CollectionMode_ID = cmm.ID WHERE dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (dm.IsDeleted = 0 OR dm.IsDeleted IS NULL) AND (dmd.IsDeleted = 0 OR dmd.IsDeleted IS NULL) GROUP BY dm.ID, dm.DayClosureDate, dm.CollectedByName) SELECT ISNULL(SUM(ChequeCollection), 0) AS TotalChequeThisMonth FROM dc WHERE MONTH(ClosureDate) = MONTH(GETDATE()) AND YEAR(ClosureDate) = YEAR(GETDATE());',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (687, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q688 | Show me month-wise enquiry trend. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me month-wise enquiry trend.',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT MONTH(CallDate) AS MonthNo, DATENAME(MONTH, CallDate) AS MonthName, COUNT(*) AS EnquiryCount FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL) GROUP BY MONTH(CallDate), DATENAME(MONTH, CallDate) ORDER BY MonthNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (688, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q689 | Pass ya fail - overall kya scene hai? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pass ya fail - overall kya scene hai?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CASE WHEN smd.Marks >= eced.MinMark THEN 1 ELSE 0 END) AS Passed, SUM(CASE WHEN smd.Marks < eced.MinMark THEN 1 ELSE 0 END) AS Failed, CAST(SUM(CASE WHEN smd.Marks >= eced.MinMark THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS PassPct FROM StudentMarkDetails smd INNER JOIN ExamConfigurationEvaluationDetails eced ON smd.EvalHierID = eced.ID INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (689, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q690 | I need to see fee category wise outstanding summary ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see fee category wise outstanding summary',
        @sql NVARCHAR(MAX) = N'SELECT f.FeesCategory_Name, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.FeesCategory_Name ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (690, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q691 | Show the number of receipts generated each year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the number of receipts generated each year',
        @sql NVARCHAR(MAX) = N'SELECT bad.Name AS AcademicYear, COUNT(fc.Id) AS TotalReceipts FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bad.Name ORDER BY bad.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (691, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q692 | Hey, what's the section-wise fee collection for Class 10? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the section-wise fee collection for Class 10?',
        @sql NVARCHAR(MAX) = N'SELECT secm.Name AS SectionName, SUM(fc.Receipt_Amt) AS Collected FROM FeesCollection fc INNER JOIN ClassMaster cm ON fc.Class_ID = cm.ID INNER JOIN SectionMaster secm ON fc.Section_ID = secm.ID WHERE cm.Name IN (''Class 10'', ''X'') AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY secm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (692, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q693 | Show the number of closed enquiries per month. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the number of closed enquiries per month.',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT DATENAME(MONTH, CallDate) AS MonthName, COUNT(*) AS ClosedCount FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND CallStatus_ID IN (SELECT ID FROM Enquiry_Status_Master WHERE Name = ''Dropped'') GROUP BY MONTH(CallDate), DATENAME(MONTH, CallDate) ORDER BY MONTH(CallDate);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (693, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q694 | Transport fee collection so far ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Transport fee collection so far',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fcd.Paid_Amt) AS transport_fee_collected FROM FeesCollection_Details fcd INNER JOIN Fees_Master fm ON fcd.Fees_Head_ID = fm.ID JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fm.Name LIKE ''%Transport%'' AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (694, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q695 | What is the average outstanding per student in Class 12? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the average outstanding per student in Class 12?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) * 1.0 / NULLIF(COUNT(DISTINCT f.Student_ID), 0), 2) AS AvgOutstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.ClassName = ''Class 12'' AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (695, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q696 | Show class-wise fee recovery rate. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show class-wise fee recovery rate.',
        @sql NVARCHAR(MAX) = N'SELECT f.ClassName, ROUND(SUM(f.Paid_Amt) * 100.0 / NULLIF(SUM(f.Amount - ISNULL(f.Concession_Amt, 0)), 0), 2) AS RecoveryRate FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.ClassName ORDER BY RecoveryRate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (696, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q697 | Show applications waiting for interview ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show applications waiting for interview',
        @sql NVARCHAR(MAX) = N'SELECT ae.FirstName, ae.LastName, ae.InterviewDate FROM ApplicationEntry ae INNER JOIN ApplicationStatus_Master asm ON ae.ApplicationStatus_ID = asm.ID WHERE asm.Name = ''Called For Interview'' AND ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (ae.IsDeleted IS NULL OR ae.IsDeleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (697, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q698 | Students above 15 years of age ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students above 15 years of age',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName, sm.StudentDob, DATEDIFF(YEAR, sm.StudentDob, GETDATE()) AS Age FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND DATEDIFF(YEAR, sm.StudentDob, GETDATE()) > 15 AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) ORDER BY sm.StudentDob;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (698, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q699 | Just checking - how many refunds were processed today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many refunds were processed today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TodayRefunds, ISNULL(SUM(Refund_Amt), 0) AS TodayAmount FROM RefundReceipt WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND CAST(Bill_Date AS DATE) = CAST(GETDATE() AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (699, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q700 | Show me how Class 6 performed overall this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me how Class 6 performed overall this year',
        @sql NVARCHAR(MAX) = N'SELECT pc.ExamTypeName AS ExamName, CAST(AVG(pc.Marks) AS DECIMAL(5,2)) AS AvgMarks, CAST(SUM(CASE WHEN pc.Marks >= pc.MinMark THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS PassPercentage FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE cm.Name IN (''Class 6'', ''VI'') AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) GROUP BY pc.ExamTypeName ORDER BY pc.ExamTypeName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
PRINT 'checkpoint: reached Q700';
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (700, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q701 | Give me a list of of students absent today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me a list of of students absent today',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, sm.AdmissionNo, cm.Name AS class_name, sa.StudentRollNo FROM StudentAttendance sa JOIN Student_Master sm ON sa.Student_ID = sm.ID JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.Attendance_Status_ID = 2 AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY cm.Name, sa.StudentRollNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (701, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q702 | List of absent staff today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List of absent staff today',
        @sql NVARCHAR(MAX) = N'SELECT sa.Staff_ID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName, sa.Attendance_Reason FROM Staff_Attendance sa INNER JOIN Staff_Master sm ON sa.Staff_ID = sm.Staff_ID AND sm.StaffStatus_ID = 1 WHERE sa.Attendance_Date = CAST(GETDATE() AS DATE) AND sa.Attendance_Status_ID = 2 AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (702, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q703 | List students from each house with their names and classes ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List students from each house with their names and classes',
        @sql NVARCHAR(MAX) = N'SELECT sad.HouseName, sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sad.ClassName, sad.RollNo FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.HouseName IS NOT NULL ORDER BY sad.HouseName, sad.ClassName, sad.RollNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (703, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q704 | Give me a list of defaulters with amount more than 50000 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me a list of defaulters with amount more than 50000',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, sm.AdmissionNo, cm.Name AS class_name, SUM(fcd.Remaining_Amt) AS outstanding FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Student_Master sm ON fc.Student_ID = sm.ID JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID AND fc.AcademicYearID = sad.AcademicYearID JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fcd.Remaining_Amt > 0 AND sad.IsActive = 1 GROUP BY sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo, cm.Name HAVING SUM(fcd.Remaining_Amt) > 50000 ORDER BY SUM(fcd.Remaining_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (704, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q705 | New admissions in Class 1 who are staff children and use transport ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'New admissions in Class 1 who are staff children and use transport',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sm.AdmissionDate, sm.FatherName FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE cm.Name IN (''Class 1'', ''I'') AND sad.IsNewAdmission = 1 AND sm.StaffChild = 1 AND sad.TransportRequired = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (705, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q706 | Which staff member has the longest tenure at the school? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which staff member has the longest tenure at the school?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 sm.Staff_ID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName, sm.Staff_DOJ, DATEDIFF(YEAR, sm.Staff_DOJ, GETDATE()) AS TenureYears FROM Staff_Master sm WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sm.IsDeleted = 0 ORDER BY sm.Staff_DOJ ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (706, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q707 | What is today's attendance? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is today''s attendance?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS present, SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END) AS absent, COUNT(*) AS total, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS attendance_pct FROM StudentAttendance sa WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (707, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q708 | So, what's the source-wise conversion rate? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, what''s the source-wise conversion rate?',
        @sql NVARCHAR(MAX) = N'DECLARE @StatusConverted bigint = (SELECT TOP 1 ID FROM Enquiry_Status_Master WHERE Name = ''Completed'');
WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT emm.Name AS Source, COUNT(*) AS TotalEnquiries, SUM(CASE WHEN CallStatus_ID = @StatusConverted THEN 1 ELSE 0 END) AS Converted, ROUND(SUM(CASE WHEN CallStatus_ID = @StatusConverted THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0), 2) AS ConversionRate FROM GeneralCallRegister em INNER JOIN Enquiry_Mode_Master emm ON em.Mode_ID = emm.ID WHERE em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND em.IsDeleted = 0 GROUP BY emm.Name ORDER BY ConversionRate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (708, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q709 | Show me who's been bunking a lot ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me who''s been bunking a lot',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 sa.Staff_ID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName, COUNT(*) AS AbsentDays FROM Staff_Attendance sa INNER JOIN Staff_Master sm ON sa.Staff_ID = sm.Staff_ID AND sm.StaffStatus_ID = 1 INNER JOIN Branch_Academic_Details b ON sa.AcademicYearID = b.Id WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND GETDATE() BETWEEN b.Start_Date AND b.End_Date AND sa.Attendance_Status_ID = 2 GROUP BY sa.Staff_ID, sm.Staff_FirstName, sm.Staff_LastName ORDER BY AbsentDays DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (709, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q710 | Hey, what's the average days to convert an enquiry? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the average days to convert an enquiry?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT ROUND(AVG(CAST(DATEDIFF(DAY, CallDate, GETDATE()) AS FLOAT)), 1) AS AvgDaysToConvert FROM GeneralCallRegister WHERE CallStatus_ID IN (SELECT ID FROM Enquiry_Status_Master WHERE Name = ''Completed'') AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (710, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q711 | Year-wise count of students who got promoted ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Year-wise count of students who got promoted',
        @sql NVARCHAR(MAX) = N'SELECT bad.Name AS AcademicYear, COUNT(DISTINCT sad.StudentID) AS PromotedStudents FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsPromoted = 1 AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bad.Name ORDER BY bad.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (711, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q712 | So, class-wise summary with strength, new admissions, dropouts, and collection ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, class-wise summary with strength, new admissions, dropouts, and collection',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(DISTINCT CASE WHEN sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) THEN sad.StudentID END) AS Strength, COUNT(DISTINCT CASE WHEN sad.IsNewAdmission = 1 AND sad.IsActive = 1 THEN sad.StudentID END) AS NewAdmissions, COUNT(DISTINCT CASE WHEN sad.IsTCIssued = 1 THEN sad.StudentID END) AS Dropouts, ISNULL(fc_agg.TotalCollection, 0) AS TotalCollection FROM StudentAcademicDetail sad JOIN ClassMaster cm ON sad.ClassID = cm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id LEFT JOIN (SELECT fc.Class_ID, SUM(fc.Receipt_Amt) AS TotalCollection FROM FeesCollection fc JOIN Branch_Academic_Details b ON fc.AcademicYearID = b.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN b.Start_Date AND b.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fc.Class_ID) fc_agg ON sad.ClassID = fc_agg.Class_ID WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name, cm.DisplayOrder, fc_agg.TotalCollection ORDER BY cm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (712, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q713 | What's the total deduction amount for this academic year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the total deduction amount for this academic year?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(gem.GrossAmount - gem.NetPay) AS YearlyDeductions FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID INNER JOIN Branch_Academic_Details b ON gm.AcademicYearID = b.Id WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND GETDATE() BETWEEN b.Start_Date AND b.End_Date AND gm.IsDeleted = 0 AND gem.IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (713, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q714 | Can you show me all hostel students from Class 9? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show me all hostel students from Class 9?',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.RollNo, secm.Name, sm.FatherContactNo FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID INNER JOIN SectionMaster secm ON sad.SectionID = secm.ID WHERE cm.Name IN (''Class 9'', ''IX'') AND sad.HostelRequired = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.RollNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (714, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q715 | Pull up the rejection rate for leave applications ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up the rejection rate for leave applications',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(CASE WHEN ls.Name = ''Cancel'' THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS RejectionRate FROM LeaveEntryMaster lem INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (715, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q716 | Can you show feedback tickets by category and status? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show feedback tickets by category and status?',
        @sql NVARCHAR(MAX) = N'SELECT CategoryID AS Category_ID, SUM(CASE WHEN Status = ''Open'' THEN 1 ELSE 0 END) AS [Open], SUM(CASE WHEN Status = ''In Progress'' THEN 1 ELSE 0 END) AS InProgress, SUM(CASE WHEN Status = ''Closed'' THEN 1 ELSE 0 END) AS Closed, SUM(CASE WHEN Status = ''Reopened'' THEN 1 ELSE 0 END) AS Reopened FROM FeedbackTicket WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY CategoryID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (716, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q717 | List all departments with their staff numbers ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all departments with their staff numbers',
        @sql NVARCHAR(MAX) = N'SELECT dm.Name AS Department, COUNT(sm.Staff_ID) AS StaffCount FROM StaffDepartmentMaster dm INNER JOIN StaffDepartmentMapping sdm ON dm.Id = sdm.DepartmentID INNER JOIN StaffDepartmentMappingDetail sdmd ON sdm.Id = sdmd.MappingID INNER JOIN Staff_Master sm ON sdmd.StaffID = sm.Staff_ID WHERE dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (dm.IsDeleted IS NULL OR dm.IsDeleted = 0) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1 GROUP BY dm.Name ORDER BY StaffCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (717, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q718 | How much online payment was received today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much online payment was received today?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS online_collection FROM FeesCollection fc WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND fc.Collection_Mode_ID IN (SELECT ID FROM CollectionMode_Master WHERE Name = ''Bank Online Transfer'') AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (718, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q719 | Pull up the number of upcoming compliance deadlines in the next 90 days ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up the number of upcoming compliance deadlines in the next 90 days',
        @sql NVARCHAR(MAX) = N'SELECT (SELECT COUNT(*) FROM DriverMaster WHERE License_Expiry_Date BETWEEN GETDATE() AND DATEADD(DAY, 90, GETDATE()) AND IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AS DriverLicenseExpiring, (SELECT COUNT(*) FROM VehicleMaster WHERE Insurance_Expiry_Date BETWEEN GETDATE() AND DATEADD(DAY, 90, GETDATE()) AND IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AS InsuranceExpiring, (SELECT COUNT(*) FROM VehicleMaster WHERE FC_Date BETWEEN GETDATE() AND DATEADD(DAY, 90, GETDATE()) AND IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AS FCExpiring;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (719, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q720 | Students with 100% attendance this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students with 100% attendance this month',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, sm.AdmissionNo, cm.Name AS class_name FROM StudentAttendance sa JOIN Student_Master sm ON sa.Student_ID = sm.ID JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE DATEPART(MONTH, sa.Attendance_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, sa.Attendance_Date) = DATEPART(YEAR, GETDATE()) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo, cm.Name, sa.Student_ID HAVING SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END) = 0 ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (720, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q721 | Let me see the collection summary for today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see the collection summary for today',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS total_receipts, COUNT(DISTINCT fc.Student_ID) AS students_count, SUM(fc.Receipt_Amt) AS total_amount, cmm.Name AS mode FROM FeesCollection fc LEFT JOIN CollectionMode_Master cmm ON fc.Collection_Mode_ID = cmm.ID WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cmm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (721, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q722 | What are the students with outstanding in all terms? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What are the students with outstanding in all terms?',
        @sql NVARCHAR(MAX) = N'SELECT f.Student_ID, s.FirstName, s.LastName, COUNT(DISTINCT f.Term_Name) AS TermsWithDues FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID INNER JOIN Student_Master s ON f.Student_ID = s.ID WHERE f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 0 AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Student_ID, s.FirstName, s.LastName HAVING COUNT(DISTINCT f.Term_Name) = (SELECT COUNT(DISTINCT Term_Name) FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (722, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q723 | Is everyone present today in Class 10? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Is everyone present today in Class 10?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) AS Present, COUNT(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 END) AS Absent FROM StudentAttendance sa INNER JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.Name IN (''Class 10'', ''X'') AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (723, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q724 | Show the average daily collection for this month. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the average daily collection for this month.',
        @sql NVARCHAR(MAX) = N'WITH dc AS (SELECT dm.ID, dm.DayClosureDate AS ClosureDate, dm.CollectedByName AS ClosedBy_Name, SUM(dmd.CollectedAmount) AS TotalCollection, SUM(CASE WHEN cmm.Name = ''Cash'' THEN dmd.CollectedAmount ELSE 0 END) AS CashCollection, SUM(CASE WHEN cmm.Name = ''Bank Online Transfer'' THEN dmd.CollectedAmount ELSE 0 END) AS OnlineCollection, SUM(CASE WHEN cmm.Name NOT IN (''Cash'', ''Bank Online Transfer'', ''Cheque'') THEN dmd.CollectedAmount ELSE 0 END) AS OtherCollection, SUM(CASE WHEN cmm.Name = ''Cheque'' THEN dmd.CollectedAmount ELSE 0 END) AS ChequeCollection FROM DayclosureMaster dm INNER JOIN DayclosureMaster_Details dmd ON dmd.HeaderID = dm.ID LEFT JOIN CollectionMode_Master cmm ON dmd.CollectionMode_ID = cmm.ID WHERE dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (dm.IsDeleted = 0 OR dm.IsDeleted IS NULL) AND (dmd.IsDeleted = 0 OR dmd.IsDeleted IS NULL) GROUP BY dm.ID, dm.DayClosureDate, dm.CollectedByName) SELECT AVG(TotalCollection) AS AvgDailyCollection FROM dc WHERE MONTH(ClosureDate) = MONTH(GETDATE()) AND YEAR(ClosureDate) = YEAR(GETDATE());',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (724, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q725 | Show me the month-wise enquiry count for this academic year. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me the month-wise enquiry count for this academic year.',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT FORMAT(CallDate, ''yyyy-MM'') AS Month, COUNT(*) AS EnquiryCount FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0 GROUP BY FORMAT(CallDate, ''yyyy-MM'') ORDER BY Month;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (725, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q726 | What percentage of enquiries are still new and untouched? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What percentage of enquiries are still new and untouched?',
        @sql NVARCHAR(MAX) = N'DECLARE @StatusNew bigint = (SELECT TOP 1 ID FROM Enquiry_Status_Master WHERE Name = ''Initiated'');
WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT CAST(COUNT(CASE WHEN CallStatus_ID = @StatusNew THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS NewPercentage FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (726, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q727 | So, what's the library fee demand and collection? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, what''s the library fee demand and collection?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(f.Amount) AS Demand, SUM(f.Paid_Amt) AS Collected, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.Fees_Name LIKE ''%Library%'' AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (727, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q728 | What's the online payments for Class 10? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the online payments for Class 10?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fc.Receipt_Amt) AS OnlineTotal, COUNT(fc.Id) AS TransactionCount FROM FeesCollection fc INNER JOIN ClassMaster cm ON fc.Class_ID = cm.ID WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.Name IN (''Class 10'', ''X'') AND fc.Collection_Mode_ID IN (SELECT ID FROM CollectionMode_Master WHERE Name = ''Bank Online Transfer'') AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (728, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q729 | Total fees collected today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total fees collected today',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS TodayCollection FROM FeesCollection fc WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (729, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q730 | Can you list out students whose transfer certificate request is not yet processed? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you list out students whose transfer certificate request is not yet processed?',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, sm.FirstName, sm.LastName FROM TCRequest tcr
INNER JOIN Student_Master sm ON tcr.StudentID = sm.ID
WHERE tcr.TC_Status NOT IN (''Issued'', ''Cancel'') AND tcr.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (tcr.IsDeleted IS NULL OR tcr.IsDeleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (730, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q731 | Show the hostel fee collection rate. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the hostel fee collection rate.',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(SUM(Paid_Amt) * 100.0 / NULLIF(SUM(Amount), 0), 2) AS HostelFeeCollectionRate FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND IsHostelFee = 1 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (731, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q732 | Branch-wise fee collection this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Branch-wise fee collection this year',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, ISNULL(SUM(fc.Receipt_Amt), 0) AS Collection FROM FeesCollection fc INNER JOIN BranchMaster bm ON fc.BranchID = bm.ID WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY Collection DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (732, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q733 | Fail percentage by subject ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Fail percentage by subject',
        @sql NVARCHAR(MAX) = N'SELECT s.Name AS Subject, CAST(SUM(CASE WHEN smd.Marks < eced.MinMark THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS FailPercentage FROM StudentMarkDetails smd INNER JOIN ExamConfigurationEvaluationDetails eced ON smd.EvalHierID = eced.ID INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN Subject_Master s ON s.BranchID = smd.BranchID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND s.IsDeleted = 0 GROUP BY s.Name ORDER BY FailPercentage DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (733, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q734 | Class 10 exam performance trend across all exams this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class 10 exam performance trend across all exams this year',
        @sql NVARCHAR(MAX) = N'SELECT pc.ExamTypeName AS ExamName, CAST(AVG(pc.Marks) AS DECIMAL(5,2)) AS AvgMarks, COUNT(DISTINCT pc.StudentID) AS Students FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE cm.Name IN (''Class 10'', ''X'') AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) GROUP BY pc.ExamTypeName ORDER BY pc.ExamTypeName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (734, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q735 | So, percentage of students scoring above 90 in the school ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, percentage of students scoring above 90 in the school',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(CASE WHEN pc.Marks / pc.MaxMarks * 100 >= 90 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS Above90Percentage FROM ProgressCardDataRetrieval pc WHERE pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (735, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q736 | Show new admissions with their fee status ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show new admissions with their fee status',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, sm.AdmissionDate, ISNULL(fp.TotalPaid, 0) AS TotalPaid, CASE WHEN fp.TotalPaid IS NULL THEN ''Not Paid'' WHEN fp.TotalPaid > 0 THEN ''Paid'' END AS FeeStatus FROM Student_Master sm JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id LEFT JOIN (SELECT fc.Student_ID, SUM(fc.Receipt_Amt) AS TotalPaid FROM FeesCollection fc WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fc.Student_ID) fp ON sm.ID = fp.Student_ID WHERE sad.IsNewAdmission = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sm.AdmissionDate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (736, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q737 | NEET/JEE students as percentage of senior secondary ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'NEET/JEE students as percentage of senior secondary',
        @sql NVARCHAR(MAX) = N'SELECT CAST(COUNT(CASE WHEN sad.IsNEETJEE = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS NEETJEEPercent FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.Name IN (''Class 11'', ''Class 12'') AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (737, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q738 | New admissions in Class 1 who use transport ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'New admissions in Class 1 who use transport',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sm.AdmissionDate, sm.FatherContactNo FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE cm.Name IN (''Class 1'', ''I'') AND sad.IsNewAdmission = 1 AND sad.TransportRequired = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sm.AdmissionDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (738, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q739 | List all staff children with their class ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all staff children with their class',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, cm.Name AS class_name FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.StaffChild = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (739, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q740 | Students paying through DD mode ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students paying through DD mode',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, fc.Receipt_Amt, fc.Bill_Date FROM FeesCollection fc INNER JOIN Student_Master sm ON fc.Student_ID = sm.ID WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.Collection_Mode_ID IN (SELECT ID FROM CollectionMode_Master WHERE Name = ''DD'') AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) ORDER BY fc.Bill_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (740, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q741 | What percentage of staff are on hold? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What percentage of staff are on hold?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(CASE WHEN IsHold = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS HoldPercentage FROM EmployeeMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (741, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q742 | Total collection this academic year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total collection this academic year',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS yearly_collection FROM FeesCollection fc WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (742, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q743 | I need to see the outstanding distribution - how many students owe 0-1000, 1000-5000, 5000-10000, 10000+? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see the outstanding distribution - how many students owe 0-1000, 1000-5000, 5000-10000, 10000+?',
        @sql NVARCHAR(MAX) = N'SELECT CASE WHEN Outstanding BETWEEN 0 AND 1000 THEN ''0-1000'' WHEN Outstanding BETWEEN 1001 AND 5000 THEN ''1001-5000'' WHEN Outstanding BETWEEN 5001 AND 10000 THEN ''5001-10000'' ELSE ''10000+'' END AS OutstandingRange, COUNT(*) AS StudentCount FROM (SELECT Student_ID, SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY Student_ID HAVING SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) > 0) t GROUP BY CASE WHEN Outstanding BETWEEN 0 AND 1000 THEN ''0-1000'' WHEN Outstanding BETWEEN 1001 AND 5000 THEN ''1001-5000'' WHEN Outstanding BETWEEN 5001 AND 10000 THEN ''5001-10000'' ELSE ''10000+'' END;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (743, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q744 | Late fee collections? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Late fee collections?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fcd.LateFeeAmount) AS TotalLateFee FROM FeesCollection_Details fcd WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.LateFeeAmount > 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (744, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q745 | Show the percentage increase in fee collection year on year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the percentage increase in fee collection year on year',
        @sql NVARCHAR(MAX) = N'WITH YearlyCollection AS (SELECT bad.Name AS AcademicYear, SUM(fc.Receipt_Amt) AS TotalCollection FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bad.Name) SELECT curr.AcademicYear, curr.TotalCollection, LAG(curr.TotalCollection) OVER (ORDER BY curr.AcademicYear) AS PreviousYearCollection, CAST((curr.TotalCollection - LAG(curr.TotalCollection) OVER (ORDER BY curr.AcademicYear)) * 100.0 / NULLIF(LAG(curr.TotalCollection) OVER (ORDER BY curr.AcademicYear), 0) AS DECIMAL(10,2)) AS GrowthPercent FROM YearlyCollection curr ORDER BY curr.AcademicYear;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (745, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q746 | Show month-wise collection for this academic year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show month-wise collection for this academic year',
        @sql NVARCHAR(MAX) = N'SELECT DATENAME(MONTH, fc.Bill_Date) AS month_name, SUM(fc.Receipt_Amt) AS total_collected FROM FeesCollection fc WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY DATENAME(MONTH, fc.Bill_Date), DATEPART(MONTH, fc.Bill_Date) ORDER BY DATEPART(MONTH, fc.Bill_Date);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (746, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q747 | What's the staff without bank account details? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the staff without bank account details?',
        @sql NVARCHAR(MAX) = N'SELECT StaffID FROM EmployeeMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0 AND (BankAccountNo IS NULL OR BankAccountNo = '''');',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (747, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q748 | Can you show circulars created today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show circulars created today?',
        @sql NVARCHAR(MAX) = N'SELECT ce.Title, ce.Description, ce.Circular_Date, ce.CircularApplicableFor AS TargetAudience, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS CreatedBy_Name FROM CircularEntry ce LEFT JOIN Staff_Master sm ON ce.Created_By = sm.Staff_ID WHERE ce.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ce.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND CAST(ce.Created_Date AS DATE) = CAST(GETDATE() AS DATE) AND (ce.IsDeleted = 0 OR ce.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (748, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q749 | I wanna see the cancellations ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I wanna see the cancellations',
        @sql NVARCHAR(MAX) = N'SELECT fc.Bill_No, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, fc.Receipt_Amt, fc.Cancellation_Date, fc.Cancelled_By_Name FROM FeesCollection fc INNER JOIN Student_Master sm ON fc.Student_ID = sm.ID WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.IsDeleted = 1 ORDER BY fc.Cancellation_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (749, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q750 | Which route is the busiest? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which route is the busiest?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 rm.Name AS RouteName, COUNT(rmd.Id) AS StopCount FROM Route_Master rm INNER JOIN Route_MasterDetails rmd ON rm.ID = rmd.Route_ID INNER JOIN BoardingPoint_Master bpm ON rmd.BoardingPoint_ID = bpm.Id WHERE rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND rm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (rm.IsDeleted = 0 OR rm.IsDeleted IS NULL) GROUP BY rm.Name ORDER BY StopCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (750, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q751 | Can you list out defaulters with amount more than 50000? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you list out defaulters with amount more than 50000?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, sm.AdmissionNo, cm.Name AS class_name, SUM(fcd.Remaining_Amt) AS outstanding FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Student_Master sm ON fc.Student_ID = sm.ID JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID AND fc.AcademicYearID = sad.AcademicYearID JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fcd.Remaining_Amt > 0 AND sad.IsActive = 1 GROUP BY sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo, cm.Name HAVING SUM(fcd.Remaining_Amt) > 50000 ORDER BY SUM(fcd.Remaining_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (751, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q752 | Show me all enquiries older than 30 days still in new status. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me all enquiries older than 30 days still in new status.',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT CallRefNo, Student_Name, Parent_Name, MobileNo1, CallDate, DATEDIFF(DAY, CallDate, GETDATE()) AS DaysPending FROM GeneralCallRegister WHERE CallStatus_ID IN (SELECT ID FROM Enquiry_Status_Master WHERE Name = ''Initiated'') AND DATEDIFF(DAY, CallDate, GETDATE()) > 30 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0 ORDER BY CallDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (752, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q753 | I need circulars requiring a response that haven't been responded to ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need circulars requiring a response that haven''t been responded to',
        @sql NVARCHAR(MAX) = N'SELECT ce.Title, ce.Description, ce.Circular_Date, ce.CircularApplicableFor AS TargetAudience FROM CircularEntry ce WHERE ce.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ce.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ce.IsDeleted = 0 OR ce.IsDeleted IS NULL) AND ce.IsResponseNeeded = 1 ORDER BY ce.Created_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (753, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q754 | Top 3 classes with highest outstanding ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Top 3 classes with highest outstanding',
        @sql NVARCHAR(MAX) = N'SELECT TOP 3 f.ClassName, SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS Outstanding FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY f.ClassName ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (754, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q755 | How many students were admitted after the session started? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students were admitted after the session started?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS LateAdmissions FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNewAdmission = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sm.AdmissionDate > bad.Start_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (755, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q756 | How many students are using hostel facility based on fee records? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students are using hostel facility based on fee records?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT f.Student_ID) AS HostelStudents FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.IsHostelFee = 1 AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (756, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q757 | Exam mein koi 100 marks laya? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Exam mein koi 100 marks laya?',
        @sql NVARCHAR(MAX) = N'SELECT smd.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName, smd.Marks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN Student_Master stm ON smd.StudentID = stm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND smd.Marks = 100;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (757, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q758 | Total pending fees across all students ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total pending fees across all students',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)), 0) AS TotalOutstanding FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (758, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q759 | Show all department names ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show all department names',
        @sql NVARCHAR(MAX) = N'SELECT Name AS DepartmentName FROM StaffDepartmentMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0 ORDER BY Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (759, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q760 | Students who got annual discount ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students who got annual discount',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName, fc.AnnualDiscount_Amt FROM FeesCollection fc INNER JOIN Student_Master sm ON fc.Student_ID = sm.ID INNER JOIN StudentAcademicDetail sad ON fc.Student_ID = sad.StudentID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.IsAnnualDiscountApplied = 1 AND fc.AnnualDiscount_Amt > 0 AND sad.IsActive = 1 AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) ORDER BY fc.AnnualDiscount_Amt DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (760, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q761 | List all designations ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all designations',
        @sql NVARCHAR(MAX) = N'SELECT ID, Name, Description FROM StaffDesignationMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0 ORDER BY Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (761, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q762 | Is today's attendance better than yesterday? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Is today''s attendance better than yesterday?',
        @sql NVARCHAR(MAX) = N'SELECT ''Today'' AS day, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS pct FROM StudentAttendance sa WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) UNION ALL SELECT ''Yesterday'' AS day, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS pct FROM StudentAttendance sa WHERE CAST(sa.Attendance_Date AS DATE) = CAST(DATEADD(DAY, -1, GETDATE()) AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (762, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q763 | Give me the average marks per subject across all exams ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the average marks per subject across all exams',
        @sql NVARCHAR(MAX) = N'SELECT pc.SubjectName AS SubjectName, CAST(AVG(pc.Marks) AS DECIMAL(5,2)) AS AvgMarks FROM ProgressCardDataRetrieval pc WHERE pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) GROUP BY pc.SubjectName ORDER BY AvgMarks DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (763, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q764 | Fee outstanding for the Velachery campus ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Fee outstanding for the Velachery campus',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fisd.Amount - ISNULL(fisd.Concession_Amt,0) - ISNULL(fisd.Paid_Amt,0) - ISNULL(fisd.Lien_Amount,0)) AS Outstanding FROM FeesInformationStudentDetail fisd WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND fisd.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%Velachery%'' OR ShortName LIKE ''%Velachery%'')) AND fisd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (764, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q765 | List staff who were present all days last week ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List staff who were present all days last week',
        @sql NVARCHAR(MAX) = N'SELECT sa.Staff_ID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName FROM Staff_Attendance sa INNER JOIN Staff_Master sm ON sa.Staff_ID = sm.Staff_ID AND sm.StaffStatus_ID = 1 WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.Attendance_Date >= DATEADD(WEEK, -1, DATEADD(DAY, -DATEPART(WEEKDAY, GETDATE()) + 1, CAST(GETDATE() AS DATE))) AND sa.Attendance_Date < DATEADD(DAY, -DATEPART(WEEKDAY, GETDATE()) + 1, CAST(GETDATE() AS DATE)) GROUP BY sa.Staff_ID, sm.Staff_FirstName, sm.Staff_LastName HAVING SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END) = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (765, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q766 | Show the latest 20 fee receipts with student names ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the latest 20 fee receipts with student names',
        @sql NVARCHAR(MAX) = N'SELECT TOP 20 fc.Bill_No, fc.Bill_Date, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, fc.Receipt_Amt, cmm.Name, fc.Collected_By_Name FROM FeesCollection fc INNER JOIN Student_Master sm ON fc.Student_ID = sm.ID LEFT JOIN CollectionMode_Master cmm ON fc.Collection_Mode_ID = cmm.ID WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY fc.Bill_Date DESC, fc.Bill_No DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (766, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q767 | Top 10 students with most absences this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Top 10 students with most absences this month',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, sm.AdmissionNo, cm.Name AS class_name, COUNT(*) AS absent_days FROM StudentAttendance sa JOIN Student_Master sm ON sa.Student_ID = sm.ID JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE sa.Attendance_Status_ID = 2 AND DATEPART(MONTH, sa.Attendance_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, sa.Attendance_Date) = DATEPART(YEAR, GETDATE()) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo, cm.Name ORDER BY COUNT(*) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (767, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q768 | What's the overall boy to girl ratio? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the overall boy to girl ratio?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(CASE WHEN sm.Gender IN (''Male'', ''Boy'') THEN 1 END) AS Boys, COUNT(CASE WHEN sm.Gender IN (''Female'', ''Girl'') THEN 1 END) AS Girls, CAST(COUNT(CASE WHEN sm.Gender IN (''Male'', ''Boy'') THEN 1 END) * 1.0 / NULLIF(COUNT(CASE WHEN sm.Gender IN (''Female'', ''Girl'') THEN 1 END), 0) AS DECIMAL(5,2)) AS BoyGirlRatio FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (768, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q769 | I need to see driver contact details ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see driver contact details',
        @sql NVARCHAR(MAX) = N'SELECT Name, Mobile, License_Number FROM DriverMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) ORDER BY Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (769, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q770 | What is the capital of France? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the capital of France?',
        @sql NVARCHAR(MAX) = N'SELECT ''This question is outside school data. I can help with students, fees, attendance, staff, exams and school operations.'' AS Message',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (770, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q771 | Absentee rate by class today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Absentee rate by class today',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AbsenteeRate FROM StudentAttendance sa INNER JOIN ClassMaster cm ON sa.Class_ID = cm.ID WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) GROUP BY cm.Name, cm.DisplayOrder ORDER BY cm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (771, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q772 | Hey, what's the total concession in the Concession_Master table? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the total concession in the Concession_Master table?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(Concession_Amount) AS TotalConcession FROM Concession_Master WHERE IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (772, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q773 | Highest and lowest collection months this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Highest and lowest collection months this year',
        @sql NVARCHAR(MAX) = N'SELECT DATENAME(MONTH, fc.Bill_Date) AS MonthName, SUM(fc.Receipt_Amt) AS MonthlyTotal FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY DATENAME(MONTH, fc.Bill_Date), MONTH(fc.Bill_Date) ORDER BY SUM(fc.Receipt_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (773, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q774 | Total collection this year by branch, highest first ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total collection this year by branch, highest first',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, SUM(fc.Receipt_Amt) AS Collection FROM FeesCollection fc JOIN BranchMaster bm ON fc.BranchID = bm.ID WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY Collection DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (774, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q775 | Show me which leave requests got turned down this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me which leave requests got turned down this month',
        @sql NVARCHAR(MAX) = N'SELECT lem.Staff_Name AS StaffName, lem.LeaveFromDate, lem.Purpose AS Reason FROM LeaveEntryMaster lem INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND ls.Name = ''Cancel'' AND MONTH(lem.LeaveFromDate) = MONTH(GETDATE()) AND YEAR(lem.LeaveFromDate) = YEAR(GETDATE());',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (775, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q776 | List students with bus fee outstanding greater than 3000. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List students with bus fee outstanding greater than 3000.',
        @sql NVARCHAR(MAX) = N'SELECT f.Student_ID, sm.FirstName, sm.LastName, sm.AdmissionNo, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS BusFeeOutstanding FROM FeesInformationStudentDetail f INNER JOIN Student_Master sm ON f.Student_ID = sm.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.IsBusFee = 1 AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY f.Student_ID, sm.FirstName, sm.LastName, sm.AdmissionNo HAVING SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) > 3000 ORDER BY BusFeeOutstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (776, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q777 | How many leave requests are pending right now? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many leave requests are pending right now?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS PendingLeaves FROM LeaveEntryMaster lem INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE ls.Name = ''Pending'' AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (777, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q778 | Hey, how many students in each Class have both hostel and transport? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many students in each Class have both hostel and transport?',
        @sql NVARCHAR(MAX) = N'SELECT sad.ClassName, COUNT(*) AS StudentCount FROM StudentAcademicDetail sad WHERE sad.HostelRequired = 1 AND sad.TransportRequired = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) GROUP BY sad.ClassID, sad.ClassName ORDER BY sad.ClassID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (778, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q779 | What's the total demand amount for April month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the total demand amount for April month?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(f.Amount) AS AprilDemand FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.Month_Name = ''April'' AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (779, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q780 | I need the staff with pending salary ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need the staff with pending salary',
        @sql NVARCHAR(MAX) = N'SELECT sm.Staff_ID AS StaffID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName FROM Staff_Master sm WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sm.IsDeleted = 0 AND sm.StaffStatus_ID = 1 AND NOT EXISTS (SELECT 1 FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gem.EmployeeID = sm.Staff_ID AND gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (780, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q781 | Pull up the earliest and latest pickup times across all routes ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up the earliest and latest pickup times across all routes',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT rmd.BoardingPoint_ID) AS TotalBoardingPoints, MIN(bpm.Amount) AS MinFee, MAX(bpm.Amount) AS MaxFee FROM Route_Master rm INNER JOIN Route_MasterDetails rmd ON rm.ID = rmd.Route_ID INNER JOIN BoardingPoint_Master bpm ON rmd.BoardingPoint_ID = bpm.Id WHERE rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND rm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (rm.IsDeleted = 0 OR rm.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (781, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q782 | Pull up leaves approved by each approver ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up leaves approved by each approver',
        @sql NVARCHAR(MAX) = N'SELECT lem.Updated_By AS ApprovedBy_ID, COUNT(*) AS ApprovedCount FROM LeaveEntryMaster lem INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND ls.Name = ''Approved'' AND lem.Updated_By IS NOT NULL GROUP BY lem.Updated_By ORDER BY ApprovedCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (782, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q783 | Can you show me the top 5 classes by enquiry count? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show me the top 5 classes by enquiry count?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT TOP 5 cm.Name AS ClassName, COUNT(*) AS EnquiryCount FROM GeneralCallRegister em INNER JOIN ClassMaster cm ON em.Class_ID = cm.ID WHERE em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND em.IsDeleted = 0 GROUP BY cm.Name ORDER BY EnquiryCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (783, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q784 | How many boys are in the Porur branch? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many boys are in the Porur branch?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS Boys FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.Gender IN (''Male'', ''Boy'') AND sm.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%Porur%'' OR ShortName LIKE ''%Porur%'')) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (784, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q785 | How is this year's enquiry count compared to total capacity? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How is this year''s enquiry count compared to total capacity?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS TotalEnquiries FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND (IsDeleted = 0 OR IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (785, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q786 | Just checking - how many staff are absent today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many staff are absent today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS AbsentToday FROM Staff_Attendance WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND Attendance_Date = CAST(GETDATE() AS DATE) AND Attendance_Status_ID = 2;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (786, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q787 | I need the students born in 2015 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need the students born in 2015',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName, sm.StudentDob FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND YEAR(sm.StudentDob) = 2015 AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) ORDER BY sm.StudentDob;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (787, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q788 | I need the defaulters contact list for SMS ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need the defaulters contact list for SMS',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT sm.FatherContactNo AS contact_number, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, sm.FatherName FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Student_Master sm ON fc.Student_ID = sm.ID JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID AND fc.AcademicYearID = sad.AcademicYearID WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fcd.Remaining_Amt > 0 AND sad.IsActive = 1 AND sm.FatherContactNo IS NOT NULL;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (788, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q789 | So, what's the total bus fee outstanding? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, what''s the total bus fee outstanding?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS BusFeeOutstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.IsBusFee = 1 AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (789, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q790 | What is the strength of each class? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the strength of each class?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS class_name, COUNT(*) AS strength FROM StudentAcademicDetail sad JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY cm.Name ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (790, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q791 | Class 10 result summary ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class 10 result summary',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT smd.StudentID) AS TotalStudents, CAST(AVG(smd.Marks) AS DECIMAL(5,2)) AS AvgMarks, MAX(smd.Marks) AS HighestMarks, MIN(smd.Marks) AS LowestMarks, CAST(SUM(CASE WHEN smd.Marks >= eced.MinMark THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS PassPct FROM StudentMarkDetails smd INNER JOIN ExamConfigurationEvaluationDetails eced ON smd.EvalHierID = eced.ID INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ClassMaster c ON smm.ClassID = c.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND c.Name = ''Class 10'';',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (791, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q792 | Show subject-wise homework count this month. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show subject-wise homework count this month.',
        @sql NVARCHAR(MAX) = N'SELECT sub.Name AS SubjectName, COUNT(*) AS HomeworkCount FROM HomeWorkAndAssignment h INNER JOIN Subject_Master sub ON h.Subject_ID = sub.Id WHERE h.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND h.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (h.IsDeleted = 0 OR h.IsDeleted IS NULL) AND MONTH(h.AssignmentDate) = MONTH(GETDATE()) AND YEAR(h.AssignmentDate) = YEAR(GETDATE()) GROUP BY sub.Name ORDER BY HomeworkCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (792, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q793 | Can you show month-wise application trend? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show month-wise application trend?',
        @sql NVARCHAR(MAX) = N'SELECT FORMAT(ApplicationDate, ''yyyy-MM'') AS Month, COUNT(*) AS Applications FROM ApplicationEntry WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) GROUP BY FORMAT(ApplicationDate, ''yyyy-MM'') ORDER BY Month;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (793, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q794 | Hostel students from different states (not Indian nationality) ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hostel students from different states (not Indian nationality)',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sm.Nationality_Name, sad.ClassName FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.HostelRequired = 1 AND sm.Nationality_Name IS NOT NULL AND sm.Nationality_Name != ''Indian'' AND sm.Nationality_Name != '''' AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (794, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q795 | Are there any cancelled receipts this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Are there any cancelled receipts this month?',
        @sql NVARCHAR(MAX) = N'SELECT fc.Id, fc.Bill_No, fc.Bill_Date, fc.Admission_No, fc.Receipt_Amt, fc.Cancellation_Date, fc.Cancelled_By_Name FROM FeesCollection fc WHERE fc.IsDeleted = 1 AND MONTH(fc.Cancellation_Date) = MONTH(GETDATE()) AND YEAR(fc.Cancellation_Date) = YEAR(GETDATE()) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (795, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q796 | Are there any students on the verge of being struck off for low attendance? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Are there any students on the verge of being struck off for low attendance?',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sad.ClassName, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sa.ID), 0) AS DECIMAL(5,2)) AS AttendancePercent FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN StudentAttendance sa ON sm.ID = sa.Student_ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.AdmissionNo, sm.FirstName, sm.LastName, sad.ClassName HAVING CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(sa.ID), 0) AS DECIMAL(5,2)) < 50 ORDER BY AttendancePercent;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (796, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q797 | Number of students per class who are active ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Number of students per class who are active',
        @sql NVARCHAR(MAX) = N'SELECT sad.ClassName, COUNT(*) AS ActiveStudents FROM StudentAcademicDetail sad WHERE sad.IsActive = 1 AND sad.ClassID IN (SELECT ID FROM ClassMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0) GROUP BY sad.ClassName ORDER BY sad.ClassName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (797, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q798 | Which student has perfect attendance this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which student has perfect attendance this year?',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, cm.Name AS ClassName FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.ID NOT IN (SELECT DISTINCT sa.Student_ID FROM StudentAttendance sa WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.Attendance_Status_ID = 2);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (798, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q799 | I need the top 5 lowest paid staff ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need the top 5 lowest paid staff',
        @sql NVARCHAR(MAX) = N'SELECT TOP 5 gem.EmployeeID, gem.EmployeeName, gem.NetPay FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gem.NetPay > 0 ORDER BY gem.NetPay ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (799, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q800 | Just checking - how many staff arrived before 8 AM today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many staff arrived before 8 AM today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS EarlyArrivals FROM Staff_Attendance WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND Attendance_Date = CAST(GETDATE() AS DATE) AND InTime < ''08:00:00'' AND InTime IS NOT NULL;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
PRINT 'checkpoint: reached Q800';
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (800, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q801 | Collection by a specific cashier named Ravi ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Collection by a specific cashier named Ravi',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(fc.Id) AS ReceiptCount, SUM(fc.Receipt_Amt) AS TotalCollected FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.Collected_By_Name LIKE ''%Ravi%'' AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (801, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q802 | Can you show the top 5 classes by outstanding amount? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show the top 5 classes by outstanding amount?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 5 f.ClassName, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.ClassName ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (802, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q803 | What is the average score in Science for Class 9? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the average score in Science for Class 9?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(AVG(pc.Marks) AS DECIMAL(5,2)) AS AvgMarks FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE pc.SubjectName = ''Science'' AND cm.Name IN (''Class 9'', ''IX'') AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (803, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q804 | Students with more than 5 absent days this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students with more than 5 absent days this month',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, COUNT(*) AS AbsentDays FROM StudentAttendance sa JOIN Student_Master sm ON sa.Student_ID = sm.ID JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON sa.AcademicYearID = bad.Id WHERE sa.Attendance_Status_ID = 2 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND MONTH(sa.Attendance_Date) = MONTH(GETDATE()) AND YEAR(sa.Attendance_Date) = YEAR(GETDATE()) AND sad.AcademicYearID = bad.Id AND sad.IsActive = 1 AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo, sad.ClassName HAVING COUNT(*) > 5 ORDER BY AbsentDays DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (804, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q805 | List all compliance issues - expired licenses, insurance, and FC. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all compliance issues - expired licenses, insurance, and FC.',
        @sql NVARCHAR(MAX) = N'SELECT ''Driver License'' AS IssueType, d.Name AS Entity, d.License_Expiry_Date AS ExpiryDate FROM DriverMaster d WHERE d.License_Expiry_Date < GETDATE() AND d.IsDeleted = 0 AND d.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) UNION ALL SELECT ''Vehicle Insurance'', v.Vehicle_Number, v.Insurance_Expiry_Date FROM VehicleMaster v WHERE v.Insurance_Expiry_Date < GETDATE() AND v.IsDeleted = 0 AND v.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) UNION ALL SELECT ''Vehicle FC'', v.Vehicle_Number, v.FC_Date FROM VehicleMaster v WHERE v.FC_Date < GETDATE() AND v.IsDeleted = 0 AND v.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (805, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q806 | Show the class-wise summary combining student strength, fee demand, collection, outstanding, and concession. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the class-wise summary combining student strength, fee demand, collection, outstanding, and concession.',
        @sql NVARCHAR(MAX) = N'SELECT f.ClassName, COUNT(DISTINCT f.Student_ID) AS StudentCount, SUM(f.Amount) AS Demand, SUM(f.Paid_Amt) AS Collected, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding, SUM(ISNULL(f.Concession_Amt, 0)) AS Concession, ROUND(SUM(f.Paid_Amt) * 100.0 / NULLIF(SUM(f.Amount), 0), 2) AS CollectionRate FROM FeesInformationStudentDetail f WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY f.ClassName ORDER BY f.ClassName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (806, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q807 | Top 10 students with maximum outstanding fees ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Top 10 students with maximum outstanding fees',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 f.Student_ID, sm.FirstName + '' '' + sm.LastName AS StudentName, SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN Student_Master sm ON f.Student_ID = sm.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY f.Student_ID, sm.FirstName, sm.LastName ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (807, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q808 | What happened with collections this morning? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What happened with collections this morning?',
        @sql NVARCHAR(MAX) = N'SELECT fc.Bill_No, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, fc.Receipt_Amt, cmm.Name FROM FeesCollection fc INNER JOIN Student_Master sm ON fc.Student_ID = sm.ID LEFT JOIN CollectionMode_Master cmm ON fc.Collection_Mode_ID = cmm.ID WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) ORDER BY fc.Bill_No;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (808, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q809 | I need all routes and their boarding points ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need all routes and their boarding points',
        @sql NVARCHAR(MAX) = N'SELECT rm.Name AS RouteName, bpm.Name AS BoardingPointName FROM Route_Master rm INNER JOIN Route_MasterDetails rmd ON rm.ID = rmd.Route_ID INNER JOIN BoardingPoint_Master bpm ON rmd.BoardingPoint_ID = bpm.Id WHERE rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND rm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (rm.IsDeleted = 0 OR rm.IsDeleted IS NULL) ORDER BY rm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (809, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q810 | Let me see outstanding for all fee types in Class 7 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see outstanding for all fee types in Class 7',
        @sql NVARCHAR(MAX) = N'SELECT FeesType_Name, SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND ClassName = ''Class 7'' AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY FeesType_Name ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (810, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q811 | Can I see the staff punctuality report? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can I see the staff punctuality report?',
        @sql NVARCHAR(MAX) = N'SELECT sa.Staff_ID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName, COUNT(CASE WHEN sa.InTime <= ''09:00'' THEN 1 END) AS OnTimeDays, COUNT(CASE WHEN sa.InTime > ''09:00'' THEN 1 END) AS LateDays FROM Staff_Attendance sa INNER JOIN Staff_Master sm ON sa.Staff_ID = sm.Staff_ID AND sm.StaffStatus_ID = 1 WHERE MONTH(sa.Attendance_Date) = MONTH(GETDATE()) AND YEAR(sa.Attendance_Date) = YEAR(GETDATE()) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sa.Staff_ID, sm.Staff_FirstName, sm.Staff_LastName ORDER BY LateDays DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (811, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q812 | I need to see term-wise outstanding for Class 7 Section B ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see term-wise outstanding for Class 7 Section B',
        @sql NVARCHAR(MAX) = N'SELECT f.Term_Name, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.ClassName = ''Class 7'' AND f.SectionName = ''B'' AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Term_Name ORDER BY f.Term_Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (812, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q813 | What's the enquiry pipeline looking like right now? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the enquiry pipeline looking like right now?',
        @sql NVARCHAR(MAX) = N'SELECT esm.Name AS Status, COUNT(*) AS Total FROM GeneralCallRegister gcr INNER JOIN Enquiry_Status_Master esm ON gcr.CallStatus_ID = esm.ID WHERE gcr.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gcr.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (gcr.IsDeleted = 0 OR gcr.IsDeleted IS NULL) GROUP BY esm.Name ORDER BY Total DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (813, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q814 | Students who changed section and are now in Section B of Class 4 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students who changed section and are now in Section B of Class 4',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.SectionChangeReason FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE cm.Name IN (''Class 4'', ''IV'') AND sad.IsSectionChanged = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (814, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q815 | Let me see the class-wise transport student count alongside hostel student count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see the class-wise transport student count alongside hostel student count',
        @sql NVARCHAR(MAX) = N'SELECT ClassName, SUM(CASE WHEN TransportRequired = 1 THEN 1 ELSE 0 END) AS TransportStudents, SUM(CASE WHEN HostelRequired = 1 THEN 1 ELSE 0 END) AS HostelStudents FROM StudentAcademicDetail WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND IsActive = 1 AND IsTCIssued = 0 GROUP BY ClassName ORDER BY ClassName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (815, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q816 | Attendance percentage for last academic year vs this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Attendance percentage for last academic year vs this year',
        @sql NVARCHAR(MAX) = N'SELECT bad.Name AS AcademicYear, CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AttendancePercent FROM StudentAttendance sa INNER JOIN Branch_Academic_Details bad ON sa.AcademicYearID = bad.Id WHERE bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (GETDATE() BETWEEN bad.Start_Date AND bad.End_Date OR bad.Id = (SELECT PreviousYearID FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = bad.Branch_Id)) GROUP BY bad.Name ORDER BY bad.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (816, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q817 | How many enquiries are currently in progress? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many enquiries are currently in progress?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS InProgressEnquiries FROM GeneralCallRegister WHERE CallStatus_ID IN (SELECT ID FROM Enquiry_Status_Master WHERE Name = ''In Progress'') AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (817, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q818 | What is the retention rate year on year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the retention rate year on year?',
        @sql NVARCHAR(MAX) = N'SELECT bad.Name AS AcademicYear, COUNT(DISTINCT CASE WHEN sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) THEN sad.StudentID END) AS ActiveStudents, COUNT(DISTINCT CASE WHEN sad.IsTCIssued = 1 THEN sad.StudentID END) AS LeftStudents, CAST(COUNT(DISTINCT CASE WHEN sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) THEN sad.StudentID END) * 100.0 / NULLIF(COUNT(DISTINCT sad.StudentID), 0) AS DECIMAL(5,2)) AS RetentionRate FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id INNER JOIN Student_Master stm ON sad.StudentID = stm.ID WHERE bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bad.Name ORDER BY bad.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (818, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q819 | So, how many students paid fees today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, how many students paid fees today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT fc.Student_ID) AS students_paid_today FROM FeesCollection fc WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (819, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q820 | What's the average time from application to admission? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the average time from application to admission?',
        @sql NVARCHAR(MAX) = N'SELECT AVG(DATEDIFF(DAY, ae.ApplicationDate, ae.AdmissionDate)) AS AvgDaysInPipeline FROM ApplicationEntry ae INNER JOIN ApplicationStatus_Master asm ON ae.ApplicationStatus_ID = asm.ID WHERE ae.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ae.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (ae.IsDeleted = 0 OR ae.IsDeleted IS NULL) AND asm.Name = ''Admitted'' AND ae.AdmissionDate IS NOT NULL;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (820, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q821 | What is today's staff attendance percentage? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is today''s staff attendance percentage?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(CASE WHEN Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS AttendancePercentage FROM Staff_Attendance WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND Attendance_Date = CAST(GETDATE() AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (821, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q822 | Give me a quick staff overview ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me a quick staff overview',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(sm.Staff_ID) AS TotalStaff, SUM(CASE WHEN em.IsHold = 1 THEN 1 ELSE 0 END) AS OnHold, SUM(CASE WHEN em.IsHold = 0 OR em.IsHold IS NULL THEN 1 ELSE 0 END) AS Active FROM Staff_Master sm LEFT JOIN EmployeeMaster em ON sm.Staff_ID = em.StaffID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (822, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q823 | How many working days this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many working days this month?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT CAST(sa.Attendance_Date AS DATE)) AS working_days FROM StudentAttendance sa WHERE DATEPART(MONTH, sa.Attendance_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, sa.Attendance_Date) = DATEPART(YEAR, GETDATE()) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (823, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q824 | Which class and section has the lowest attendance this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which class and section has the lowest attendance this month?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 cm.Name AS ClassName, secm.Name AS SectionName, CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AttendancePercent FROM StudentAttendance sa JOIN ClassMaster cm ON sa.Class_ID = cm.ID JOIN SectionMaster secm ON sa.Section_ID = secm.ID JOIN Branch_Academic_Details bad ON sa.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND MONTH(sa.Attendance_Date) = MONTH(GETDATE()) AND YEAR(sa.Attendance_Date) = YEAR(GETDATE()) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name, secm.Name ORDER BY AttendancePercent ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (824, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q825 | Show upcoming approved leaves for next week. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show upcoming approved leaves for next week.',
        @sql NVARCHAR(MAX) = N'SELECT lem.Staff_Name AS StaffName, lem.LeaveFromDate, lem.LeaveToDate, lem.NoOfDays, lem.Purpose AS Reason FROM LeaveEntryMaster lem INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND ls.Name = ''Approved'' AND lem.LeaveFromDate BETWEEN DATEADD(DAY, 1, GETDATE()) AND DATEADD(DAY, 7, GETDATE()) ORDER BY lem.LeaveFromDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (825, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q826 | Give me a list of all concession categories ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me a list of all concession categories',
        @sql NVARCHAR(MAX) = N'SELECT Name FROM Concession_Category_Master WHERE IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (826, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q827 | Is our average attendance better than last year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Is our average attendance better than last year?',
        @sql NVARCHAR(MAX) = N'SELECT ''Current Year'' AS Period, CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AvgAttendance FROM StudentAttendance sa WHERE sa.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) UNION ALL SELECT ''Previous Year'' AS Period, CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AvgAttendance FROM StudentAttendance sa WHERE sa.AcademicYearID IN (SELECT PreviousYearID FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (827, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q828 | How much is the total dues for this academic year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much is the total dues for this academic year?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM((fisd.Amount - ISNULL(fisd.Concession_Amt, 0) - ISNULL(fisd.Paid_Amt, 0))), 0) AS total_dues FROM FeesInformationStudentDetail fisd WHERE fisd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fisd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (828, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q829 | Show hostel fee outstanding class-wise. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show hostel fee outstanding class-wise.',
        @sql NVARCHAR(MAX) = N'SELECT f.ClassName, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS HostelOutstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.IsHostelFee = 1 AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.ClassName ORDER BY HostelOutstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (829, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q830 | How many people work at our school? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many people work at our school?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalStaff FROM Staff_Master sm WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (830, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q831 | What's the subject-wise fail count? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the subject-wise fail count?',
        @sql NVARCHAR(MAX) = N'SELECT s.Name AS Subject, COUNT(*) AS FailCount FROM StudentMarkDetails smd INNER JOIN ExamConfigurationEvaluationDetails eced ON smd.EvalHierID = eced.ID INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN Subject_Master s ON s.BranchID = smd.BranchID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND s.IsDeleted = 0 AND smd.Marks < eced.MinMark GROUP BY s.Name ORDER BY FailCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (831, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q832 | Can you list out all NEET/JEE aspirants with their details? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you list out all NEET/JEE aspirants with their details?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, sm.FatherContactNo FROM Student_Master sm JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNEETJEE = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.ClassName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (832, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q833 | What's our staff salary bill looking like? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s our staff salary bill looking like?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(gem.NetPay) AS MonthlySalaryBill FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (833, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q834 | Hey, how many students have received concessions? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many students have received concessions?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT Student_ID) AS StudentsWithConcession FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND ISNULL(Concession_Amt, 0) > 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (834, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q835 | Students who left in the last 30 days ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students who left in the last 30 days',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, sad.TCIssuedDate FROM Student_Master sm JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsTCIssued = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.TCIssuedDate >= DATEADD(DAY, -30, GETDATE()) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.TCIssuedDate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (835, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q836 | How much of Term 1 demand is still outstanding as a percentage? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much of Term 1 demand is still outstanding as a percentage?',
        @sql NVARCHAR(MAX) = N'SELECT ROUND(SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) * 100.0 / NULLIF(SUM(f.Amount - ISNULL(f.Concession_Amt, 0)), 0), 2) AS OutstandingPercent FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.Term_Name IN (''Term 1'', ''I'') AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (836, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q837 | What percentage of total students are in Class 10? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What percentage of total students are in Class 10?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(COUNT(CASE WHEN cm.Name IN (''Class 10'', ''X'') THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS Class10Percent FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (837, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q838 | How many admission applications have been received this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many admission applications have been received this year?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalApplications FROM ApplicationEntry WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (838, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q839 | Show me which staff are on approved leave right now ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me which staff are on approved leave right now',
        @sql NVARCHAR(MAX) = N'SELECT lem.Staff_Name AS StaffName, lem.LeaveFromDate, lem.LeaveToDate FROM LeaveEntryMaster lem INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND ls.Name = ''Approved'' AND CAST(GETDATE() AS DATE) BETWEEN lem.LeaveFromDate AND lem.LeaveToDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (839, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q840 | Which teachers came late today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which teachers came late today?',
        @sql NVARCHAR(MAX) = N'SELECT sa.Staff_ID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName, sa.InTime FROM Staff_Attendance sa INNER JOIN Staff_Master sm ON sa.Staff_ID = sm.Staff_ID AND sm.StaffStatus_ID = 1 INNER JOIN StaffType_Master stm ON sm.StaffType_ID = stm.ID INNER JOIN StaffTypeCategoryMaster stcm ON stm.Type_Id = stcm.Id WHERE sa.Attendance_Date = CAST(GETDATE() AS DATE) AND sa.InTime > ''09:00'' AND stcm.Name = ''Academic'' AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sa.InTime DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (840, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q841 | Weekly staff attendance report ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Weekly staff attendance report',
        @sql NVARCHAR(MAX) = N'SELECT Attendance_Date, COUNT(CASE WHEN Attendance_Status_ID = 1 THEN 1 END) AS Present, COUNT(CASE WHEN Attendance_Status_ID = 2 THEN 1 END) AS Absent FROM Staff_Attendance WHERE Attendance_Date >= DATEADD(DAY, -7, CAST(GETDATE() AS DATE)) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY Attendance_Date ORDER BY Attendance_Date;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (841, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q842 | How much annual discount was applied? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much annual discount was applied?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.AnnualDiscount_Amt), 0) AS annual_discount FROM FeesCollection fc WHERE fc.IsAnnualDiscountApplied = 1 AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (842, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q843 | Give me the term-wise outstanding fees ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the term-wise outstanding fees',
        @sql NVARCHAR(MAX) = N'SELECT f.Term_Name, SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS Outstanding FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY f.Term_Name ORDER BY f.Term_Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (843, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q844 | List the top 5 highest paying students this year with full details ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List the top 5 highest paying students this year with full details',
        @sql NVARCHAR(MAX) = N'SELECT TOP 5 sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, sm.FatherName, sm.FatherContactNo, SUM(fc.Receipt_Amt) AS TotalPaid FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN FeesCollection fc ON sm.ID = fc.Student_ID WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.ID, sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo, sad.ClassName, sm.FatherName, sm.FatherContactNo ORDER BY TotalPaid DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (844, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q845 | Let me see leave type wise distribution of approved leaves ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see leave type wise distribution of approved leaves',
        @sql NVARCHAR(MAX) = N'SELECT lt.Name AS LeaveType, COUNT(*) AS LeaveCount, SUM(lem.NoOfDays) AS TotalDays FROM LeaveEntryMaster lem INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID INNER JOIN LeaveType lt ON lem.LeaveType_ID = lt.ID WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND ls.Name = ''Approved'' GROUP BY lt.Name ORDER BY TotalDays DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (845, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q846 | Just checking - how many tickets are in progress right now? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many tickets are in progress right now?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS InProgressTickets FROM FeedbackTicket WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND Status = ''In Progress'';',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (846, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q847 | Number of stops per route. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Number of stops per route.',
        @sql NVARCHAR(MAX) = N'SELECT rm.Name AS RouteName, COUNT(rmd.Id) AS NumberOfStops FROM Route_Master rm INNER JOIN Route_MasterDetails rmd ON rm.ID = rmd.Route_ID INNER JOIN BoardingPoint_Master bpm ON rmd.BoardingPoint_ID = bpm.Id WHERE rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND rm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (rm.IsDeleted = 0 OR rm.IsDeleted IS NULL) GROUP BY rm.Name ORDER BY NumberOfStops DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (847, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q848 | How much concession has been given this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much concession has been given this year?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fcd.Concession_Amount), 0) AS total_concession FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (848, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q849 | What is the collection for Saint Marys campus today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the collection for Saint Marys campus today?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fc.Receipt_Amt) AS Collection FROM FeesCollection fc WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND fc.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%Mary%'' OR ShortName LIKE ''%Mary%'')) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (849, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q850 | Pull up complete class-subject-teacher mapping ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up complete class-subject-teacher mapping',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, sub.Name AS SubjectName, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS TeacherName FROM ClassSubjectDetails cs INNER JOIN ClassMaster cm ON cs.Class_Id = cm.ID INNER JOIN Subject_Master sub ON cs.Subject_Id = sub.Id LEFT JOIN SubjectAllocation_Master sam ON sam.Class_ID = cs.Class_Id AND sam.Subject_ID = cs.Subject_Id AND (sam.IsDeleted = 0 OR sam.IsDeleted IS NULL) LEFT JOIN Staff_Master sm ON sam.Staff_ID = sm.Staff_ID WHERE cs.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND cs.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY cm.Name, sub.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (850, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q851 | Show me staff who were absent yesterday ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me staff who were absent yesterday',
        @sql NVARCHAR(MAX) = N'SELECT sa.Staff_ID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName FROM Staff_Attendance sa INNER JOIN Staff_Master sm ON sa.Staff_ID = sm.Staff_ID AND sm.StaffStatus_ID = 1 WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.Attendance_Date = DATEADD(DAY, -1, CAST(GETDATE() AS DATE)) AND sa.Attendance_Status_ID = 2;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (851, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q852 | Has anyone collected fees through cheque this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Has anyone collected fees through cheque this month?',
        @sql NVARCHAR(MAX) = N'SELECT fc.Id, fc.Bill_No, fc.Bill_Date, fc.Admission_No, fc.Receipt_Amt, fc.Collected_By_Name FROM FeesCollection fc WHERE fc.Collection_Mode_ID IN (SELECT ID FROM CollectionMode_Master WHERE Name = ''Cheque'') AND MONTH(fc.Bill_Date) = MONTH(GETDATE()) AND YEAR(fc.Bill_Date) = YEAR(GETDATE()) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (852, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q853 | How much collection happened through cash vs online? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much collection happened through cash vs online?',
        @sql NVARCHAR(MAX) = N'SELECT cmm.Name, COUNT(fc.Id) AS Receipts, SUM(fc.Receipt_Amt) AS TotalAmount, CAST(SUM(fc.Receipt_Amt) * 100.0 / NULLIF(SUM(SUM(fc.Receipt_Amt)) OVER (), 0) AS DECIMAL(5,2)) AS Percentage FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id LEFT JOIN CollectionMode_Master cmm ON fc.Collection_Mode_ID = cmm.ID WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cmm.Name ORDER BY TotalAmount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (853, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q854 | Average fee paid per student in Class 9 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Average fee paid per student in Class 9',
        @sql NVARCHAR(MAX) = N'SELECT AVG(StudentTotal) AS AvgFeePaid FROM (SELECT fc.Student_ID, SUM(fc.Receipt_Amt) AS StudentTotal FROM FeesCollection fc INNER JOIN ClassMaster cm ON fc.Class_ID = cm.ID WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.Name IN (''Class 9'', ''IX'') AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY fc.Student_ID) AS StudentFees;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (854, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q855 | List lumpsum fee students with their amount ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List lumpsum fee students with their amount',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, sad.Lumpsum_Amount FROM Student_Master sm JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsLumpsumApplicable = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.Lumpsum_Amount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (855, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q856 | So, what's the weakest subject in Class 10? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, what''s the weakest subject in Class 10?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 pc.SubjectName AS SubjectName, CAST(AVG(pc.Marks) AS DECIMAL(5,2)) AS AvgMarks FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE cm.Name IN (''Class 10'', ''X'') AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) GROUP BY pc.SubjectName ORDER BY AvgMarks ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (856, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q857 | How many boys and girls are there in the school? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many boys and girls are there in the school?',
        @sql NVARCHAR(MAX) = N'SELECT sm.Gender, COUNT(*) AS student_count FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY sm.Gender;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (857, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q858 | Show Class 10 strength in the Anna Nagar branch ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show Class 10 strength in the Anna Nagar branch',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS Students FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND cm.Name IN (''Class 10'', ''X'') AND sm.BranchID IN (SELECT ID FROM BranchMaster WHERE (Name LIKE ''%Anna Nagar%'' OR ShortName LIKE ''%Anna Nagar%'')) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (858, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q859 | Let me see tickets resolved in the last 7 days ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see tickets resolved in the last 7 days',
        @sql NVARCHAR(MAX) = N'SELECT ft.TicketNo, ft.Subject, ft.Status FROM FeedbackTicket ft WHERE ft.Status = ''Resolved'' AND ft.Created_Date >= DATEADD(DAY, -7, GETDATE()) AND ft.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (ft.IsDeleted IS NULL OR ft.IsDeleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (859, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q860 | Compare total demand vs collection per branch ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare total demand vs collection per branch',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, SUM(fisd.Amount) AS Demand, SUM(ISNULL(fisd.Paid_Amt,0)) AS Paid FROM FeesInformationStudentDetail fisd JOIN BranchMaster bm ON fisd.BranchID = bm.ID WHERE fisd.IsIncludedInLumpSum <> 1 AND fisd.IsDonation = 0 AND fisd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY Demand DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (860, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q861 | List students who scored above 90 in Mathematics ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List students who scored above 90 in Mathematics',
        @sql NVARCHAR(MAX) = N'SELECT pc.StudentName AS StudentName, cm.Name AS ClassName, pc.Marks FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE pc.SubjectName = ''Maths'' AND pc.Marks >= 90 AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) ORDER BY pc.Marks DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (861, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q862 | List all routes and their boarding points ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all routes and their boarding points',
        @sql NVARCHAR(MAX) = N'SELECT rm.Name AS RouteName, bpm.Name AS BoardingPointName FROM Route_Master rm INNER JOIN Route_MasterDetails rmd ON rm.ID = rmd.Route_ID INNER JOIN BoardingPoint_Master bpm ON rmd.BoardingPoint_ID = bpm.Id WHERE rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND rm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (rm.IsDeleted = 0 OR rm.IsDeleted IS NULL) ORDER BY rm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (862, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q863 | Show me the month-wise collection with percentage contribution ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me the month-wise collection with percentage contribution',
        @sql NVARCHAR(MAX) = N'WITH MonthlyCollection AS (SELECT MONTH(fc.Bill_Date) AS MonthNo, DATENAME(MONTH, fc.Bill_Date) AS MonthName, SUM(fc.Receipt_Amt) AS MonthCollection FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY MONTH(fc.Bill_Date), DATENAME(MONTH, fc.Bill_Date)) SELECT MonthNo, MonthName, MonthCollection, CAST(MonthCollection * 100.0 / NULLIF(SUM(MonthCollection) OVER (), 0) AS DECIMAL(5,2)) AS ContributionPercent FROM MonthlyCollection ORDER BY MonthNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (863, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q864 | Teacher presence rate for this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Teacher presence rate for this month',
        @sql NVARCHAR(MAX) = N'SELECT CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS PresenceRate FROM Staff_Attendance sa WHERE MONTH(sa.Attendance_Date) = MONTH(GETDATE()) AND YEAR(sa.Attendance_Date) = YEAR(GETDATE())  AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (864, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q865 | Pull up class-wise enquiry count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up class-wise enquiry count',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT cm.Name AS ClassName, COUNT(*) AS EnquiryCount FROM GeneralCallRegister em INNER JOIN ClassMaster cm ON em.Class_ID = cm.ID WHERE em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND (em.IsDeleted = 0 OR em.IsDeleted IS NULL) GROUP BY cm.Name ORDER BY EnquiryCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (865, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q866 | Total deductions this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total deductions this month',
        @sql NVARCHAR(MAX) = N'SELECT SUM(gem.GrossAmount - gem.NetPay) AS TotalDeductions FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID = (SELECT DATEDIFF(MONTH, Start_Date, GETDATE()) + 1 FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id = gm.BranchID);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (866, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q867 | Class-wise student count with average marks ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class-wise student count with average marks',
        @sql NVARCHAR(MAX) = N'SELECT c.Name AS ClassName, COUNT(DISTINCT sad.StudentID) AS StudentCount, CAST(AVG(smd.Marks) AS DECIMAL(5,2)) AS AvgMarks FROM StudentAcademicDetail sad INNER JOIN ClassMaster c ON sad.ClassID = c.ID LEFT JOIN StudentMarkDetails smd ON sad.StudentID = smd.StudentID AND smd.Deleted = 0 LEFT JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID AND smm.Deleted = 0 WHERE c.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND c.IsDeleted = 0 AND sad.IsActive = 1 GROUP BY c.Name ORDER BY c.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (867, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q868 | Pull up month-wise leave application trend ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up month-wise leave application trend',
        @sql NVARCHAR(MAX) = N'SELECT FORMAT(lem.LeaveFromDate, ''yyyy-MM'') AS [Month], COUNT(*) AS Applications, SUM(CASE WHEN ls.Name = ''Approved'' THEN 1 ELSE 0 END) AS Approved, SUM(CASE WHEN ls.Name = ''Cancel'' THEN 1 ELSE 0 END) AS Rejected, SUM(CASE WHEN ls.Name = ''Pending'' THEN 1 ELSE 0 END) AS Pending FROM LeaveEntryMaster lem INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) GROUP BY FORMAT(lem.LeaveFromDate, ''yyyy-MM'') ORDER BY [Month];',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (868, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q869 | Show mode-wise donation collection breakdown ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show mode-wise donation collection breakdown',
        @sql NVARCHAR(MAX) = N'SELECT cmm.Name AS Mode, SUM(d.Receipt_Amt) AS TotalAmount, COUNT(*) AS Receipts FROM DonationFeesCollection d LEFT JOIN CollectionMode_Master cmm ON d.Collection_Mode_ID = cmm.ID WHERE d.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND d.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (d.IsDeleted = 0 OR d.IsDeleted IS NULL) AND d.ChequeStatus_ID NOT IN (3, 4) GROUP BY cmm.Name ORDER BY TotalAmount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (869, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q870 | Total salary expenditure for the last quarter ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total salary expenditure for the last quarter',
        @sql NVARCHAR(MAX) = N'SELECT SUM(gem.NetPay) AS QuarterlySalary FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 AND gm.MonthID IN (MONTH(GETDATE()), MONTH(GETDATE())-1, MONTH(GETDATE())-2);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (870, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q871 | List students who changed section with reason ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List students who changed section with reason',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, sad.SectionChangeReason FROM Student_Master sm JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsSectionChanged = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.ClassName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (871, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q872 | Teachers who assigned homework today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Teachers who assigned homework today',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT sfm.Staff_FirstName + '' '' + ISNULL(sfm.Staff_LastName, '''') AS TeacherName, sub.Name AS Subject FROM HomeWorkAndAssignment hwa INNER JOIN Staff_Master sfm ON hwa.Staff_ID = sfm.Staff_ID INNER JOIN Subject_Master sub ON hwa.Subject_ID = sub.Id WHERE CAST(hwa.AssignmentDate AS DATE) = CAST(GETDATE() AS DATE) AND (hwa.IsDeleted IS NULL OR hwa.IsDeleted = 0) AND hwa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND hwa.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (872, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q873 | Class-wise fee collection percentage of total ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class-wise fee collection percentage of total',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, SUM(fc.Receipt_Amt) AS ClassCollection, CAST(SUM(fc.Receipt_Amt) * 100.0 / NULLIF(SUM(SUM(fc.Receipt_Amt)) OVER (), 0) AS DECIMAL(5,2)) AS PercentOfTotal FROM FeesCollection fc JOIN ClassMaster cm ON fc.Class_ID = cm.ID JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name, cm.DisplayOrder ORDER BY cm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (873, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q874 | Show me all bounced cheque fee receipts this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me all bounced cheque fee receipts this month',
        @sql NVARCHAR(MAX) = N'SELECT fc.Bill_No, fc.Bill_Date, fc.Receipt_Amt, fc.Student_ID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName FROM FeesCollection fc INNER JOIN Student_Master stm ON fc.Student_ID = stm.ID WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID = 4 AND MONTH(fc.Bill_Date) = MONTH(GETDATE()) AND YEAR(fc.Bill_Date) = YEAR(GETDATE());',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (874, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q875 | Fee type wise collection for Class 12 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Fee type wise collection for Class 12',
        @sql NVARCHAR(MAX) = N'SELECT fcd.FeesType_Name, SUM(fcd.Paid_Amt) AS Collected, SUM(fcd.Remaining_Amt) AS Pending FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id INNER JOIN ClassMaster cm ON fc.Class_ID = cm.ID WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.Name IN (''Class 12'', ''XII'') AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY fcd.FeesType_Name ORDER BY SUM(fcd.Paid_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (875, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q876 | Can you show me classes where outstanding exceeds 100000? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show me classes where outstanding exceeds 100000?',
        @sql NVARCHAR(MAX) = N'SELECT ClassName, SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY ClassName HAVING SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) > 100000 ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (876, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q877 | Students who improved from Term 1 to Term 2 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students who improved from Term 1 to Term 2',
        @sql NVARCHAR(MAX) = N'SELECT t1.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName, t1.AvgMarks AS Term1Avg, t2.AvgMarks AS Term2Avg, (t2.AvgMarks - t1.AvgMarks) AS Improvement FROM (SELECT smd.StudentID, AVG(smd.Marks) AS AvgMarks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ExamTypeMaster et ON smm.ExamTypeID = et.ID INNER JOIN ExamTermMaster etm ON et.TermID = etm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND etm.Name = ''Term 1'' GROUP BY smd.StudentID) t1 INNER JOIN (SELECT smd.StudentID, AVG(smd.Marks) AS AvgMarks FROM StudentMarkDetails smd INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID INNER JOIN ExamTypeMaster et ON smm.ExamTypeID = et.ID INNER JOIN ExamTermMaster etm ON et.TermID = etm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0 AND etm.Name = ''Term 2'' GROUP BY smd.StudentID) t2 ON t1.StudentID = t2.StudentID INNER JOIN Student_Master stm ON t1.StudentID = stm.ID WHERE t2.AvgMarks > t1.AvgMarks ORDER BY Improvement DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (877, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q878 | Total collection for this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total collection for this month',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS collection_this_month FROM FeesCollection fc WHERE DATEPART(MONTH, fc.Bill_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, fc.Bill_Date) = DATEPART(YEAR, GETDATE()) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (878, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q879 | Are there any students who received multiple refunds? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Are there any students who received multiple refunds?',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName + '' '' + sm.LastName AS StudentName, COUNT(*) AS RefundCount, SUM(r.Refund_Amt) AS TotalRefunded FROM RefundReceipt r INNER JOIN Student_Master sm ON r.Student_ID = sm.ID WHERE r.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND r.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY sm.FirstName, sm.LastName HAVING COUNT(*) > 1 ORDER BY RefundCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (879, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q880 | Which section had the worst attendance today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which section had the worst attendance today?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 cm.Name AS ClassName, secm.Name AS Section, COUNT(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 END) AS AbsentCount FROM StudentAttendance sa INNER JOIN ClassMaster cm ON sa.Class_ID = cm.ID INNER JOIN SectionMaster secm ON sa.Section_ID = secm.ID WHERE CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name, secm.Name ORDER BY AbsentCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (880, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q881 | Which day of the week gets the most homework assigned? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which day of the week gets the most homework assigned?',
        @sql NVARCHAR(MAX) = N'SELECT DATENAME(WEEKDAY, AssignmentDate) AS DayOfWeek, COUNT(*) AS HomeworkCount FROM HomeWorkAndAssignment WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) GROUP BY DATENAME(WEEKDAY, AssignmentDate), DATEPART(WEEKDAY, AssignmentDate) ORDER BY HomeworkCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (881, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q882 | Show the outstanding distribution - how many students owe 0-1000, 1000-5000, 5000-10000, 10000+? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the outstanding distribution - how many students owe 0-1000, 1000-5000, 5000-10000, 10000+?',
        @sql NVARCHAR(MAX) = N'SELECT CASE WHEN Outstanding BETWEEN 0 AND 1000 THEN ''0-1000'' WHEN Outstanding BETWEEN 1001 AND 5000 THEN ''1001-5000'' WHEN Outstanding BETWEEN 5001 AND 10000 THEN ''5001-10000'' ELSE ''10000+'' END AS OutstandingRange, COUNT(*) AS StudentCount FROM (SELECT Student_ID, SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY Student_ID HAVING SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) > 0) t GROUP BY CASE WHEN Outstanding BETWEEN 0 AND 1000 THEN ''0-1000'' WHEN Outstanding BETWEEN 1001 AND 5000 THEN ''1001-5000'' WHEN Outstanding BETWEEN 5001 AND 10000 THEN ''5001-10000'' ELSE ''10000+'' END;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (882, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q883 | How many receipts got cancelled this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many receipts got cancelled this month?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(fc.Id) AS CancelledReceipts, SUM(fc.Receipt_Amt) AS CancelledAmount FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE fc.IsDeleted = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND MONTH(fc.Cancellation_Date) = MONTH(GETDATE()) AND YEAR(fc.Cancellation_Date) = YEAR(GETDATE()) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (883, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q884 | I need the check cheque collection ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need the check cheque collection',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(fc.Id) AS ChequeReceipts, SUM(fc.Receipt_Amt) AS ChequeTotal FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.Collection_Mode_ID IN (SELECT ID FROM CollectionMode_Master WHERE Name = ''Cheque'') AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (884, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q885 | List tickets raised for a specific student with student names ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List tickets raised for a specific student with student names',
        @sql NVARCHAR(MAX) = N'SELECT ft.TicketNo, sm.FirstName + '' '' + sm.LastName AS StudentName, ft.Subject FROM FeedbackTicket ft INNER JOIN Student_Master sm ON ft.StudentID = sm.ID WHERE ft.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (ft.IsDeleted IS NULL OR ft.IsDeleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (885, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q886 | What is the average attendance percentage for this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the average attendance percentage for this month?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AvgAttendancePercent FROM StudentAttendance sa WHERE sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND MONTH(sa.Attendance_Date) = MONTH(GETDATE()) AND YEAR(sa.Attendance_Date) = YEAR(GETDATE());',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (886, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q887 | What is the admission count by day of the week? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the admission count by day of the week?',
        @sql NVARCHAR(MAX) = N'SELECT DATENAME(WEEKDAY, sm.AdmissionDate) AS DayOfWeek, COUNT(DISTINCT sad.StudentID) AS Admissions FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNewAdmission = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY DATENAME(WEEKDAY, sm.AdmissionDate), DATEPART(WEEKDAY, sm.AdmissionDate) ORDER BY DATEPART(WEEKDAY, sm.AdmissionDate);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (887, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q888 | I need to see new admissions with their fee status ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see new admissions with their fee status',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, sm.AdmissionDate, ISNULL(fp.TotalPaid, 0) AS TotalPaid, CASE WHEN fp.TotalPaid IS NULL THEN ''Not Paid'' WHEN fp.TotalPaid > 0 THEN ''Paid'' END AS FeeStatus FROM Student_Master sm JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id LEFT JOIN (SELECT fc.Student_ID, SUM(fc.Receipt_Amt) AS TotalPaid FROM FeesCollection fc WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fc.Student_ID) fp ON sm.ID = fp.Student_ID WHERE sad.IsNewAdmission = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sm.AdmissionDate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (888, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q889 | Tell me about the staff who left early today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Tell me about the staff who left early today',
        @sql NVARCHAR(MAX) = N'SELECT sa.Staff_ID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName, sa.OutTime FROM Staff_Attendance sa INNER JOIN Staff_Master sm ON sa.Staff_ID = sm.Staff_ID AND sm.StaffStatus_ID = 1 WHERE sa.Attendance_Date = CAST(GETDATE() AS DATE) AND sa.OutTime < ''17:00'' AND sa.OutTime IS NOT NULL AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sa.OutTime;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (889, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q890 | I need the receipts cancelled by admin Sharma ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need the receipts cancelled by admin Sharma',
        @sql NVARCHAR(MAX) = N'SELECT fc.Bill_No, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, fc.Receipt_Amt, fc.Cancellation_Date FROM FeesCollection fc INNER JOIN Student_Master sm ON fc.Student_ID = sm.ID WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.IsDeleted = 1 AND fc.Cancelled_By_Name LIKE ''%Sharma%'' ORDER BY fc.Cancellation_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (890, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q891 | Which subject needs the most improvement in Class 9? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which subject needs the most improvement in Class 9?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 pc.SubjectName AS SubjectName, CAST(AVG(pc.Marks) AS DECIMAL(5,2)) AS AvgMarks, CAST(SUM(CASE WHEN pc.Marks < pc.MinMark THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS FailPercentage FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE cm.Name IN (''Class 9'', ''IX'') AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) GROUP BY pc.SubjectName ORDER BY AvgMarks ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (891, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q892 | Pull up year-wise student dropout rate real quick ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up year-wise student dropout rate real quick',
        @sql NVARCHAR(MAX) = N'SELECT bad.Name AS AcademicYear, COUNT(DISTINCT sad.StudentID) AS TotalStudents, COUNT(DISTINCT CASE WHEN sad.IsTCIssued = 1 THEN sad.StudentID END) AS Dropouts, CAST(COUNT(DISTINCT CASE WHEN sad.IsTCIssued = 1 THEN sad.StudentID END) * 100.0 / NULLIF(COUNT(DISTINCT sad.StudentID), 0) AS DECIMAL(5,2)) AS DropoutRate FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bad.Name ORDER BY bad.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (892, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q893 | So, monthly fee collection target vs actual (assuming monthly target is annual/12) ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, monthly fee collection target vs actual (assuming monthly target is annual/12)',
        @sql NVARCHAR(MAX) = N'WITH TotalYearly AS (SELECT SUM(fc.Receipt_Amt) AS YearTotal FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))), MonthlyActual AS (SELECT MONTH(fc.Bill_Date) AS MonthNo, DATENAME(MONTH, fc.Bill_Date) AS MonthName, SUM(fc.Receipt_Amt) AS MonthlyCollection FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY MONTH(fc.Bill_Date), DATENAME(MONTH, fc.Bill_Date)) SELECT ma.MonthNo, ma.MonthName, ma.MonthlyCollection AS Actual, CAST(ty.YearTotal / 12.0 AS DECIMAL(10,2)) AS MonthlyAvgTarget FROM MonthlyActual ma, TotalYearly ty ORDER BY ma.MonthNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (893, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q894 | I need to see Class and Section wise total outstanding ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see Class and Section wise total outstanding',
        @sql NVARCHAR(MAX) = N'SELECT f.ClassName, f.SectionName, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.ClassName, f.SectionName ORDER BY f.ClassName, f.SectionName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (894, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q895 | I need the break it down class-wise ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need the break it down class-wise',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(sad.Id) AS StudentCount FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) GROUP BY cm.Name ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (895, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q896 | Outstanding amount for transport fee students ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Outstanding amount for transport fee students',
        @sql NVARCHAR(MAX) = N'SELECT SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS Outstanding FROM FeesInformationStudentDetail f WHERE f.IsBusFee = 1 AND f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (896, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q897 | Which house has the fewest students? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which house has the fewest students?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 sad.HouseName, COUNT(DISTINCT sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.HouseName IS NOT NULL AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sad.HouseName ORDER BY StudentCount ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (897, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q898 | Are we getting more enquiries than last year at this point? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Are we getting more enquiries than last year at this point?',
        @sql NVARCHAR(MAX) = N'SELECT ''Current Year'' AS Period, COUNT(*) AS TotalEnquiries FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (IsDeleted = 0 OR IsDeleted IS NULL) UNION ALL SELECT ''Previous Year'' AS Period, COUNT(*) AS TotalEnquiries FROM GeneralCallRegister WHERE AcademicYearID IN (SELECT PreviousYearID FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (IsDeleted = 0 OR IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (898, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q899 | Students who have not been given any concession ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students who have not been given any concession',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sad.ClassName FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND NOT EXISTS (SELECT 1 FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fc.Student_ID = sm.ID AND fcd.Concession_Amount > 0 AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (899, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q900 | What was last month's collection? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What was last month''s collection?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS last_month_collection FROM FeesCollection fc WHERE DATEPART(MONTH, fc.Bill_Date) = DATEPART(MONTH, DATEADD(MONTH, -1, GETDATE())) AND DATEPART(YEAR, fc.Bill_Date) = DATEPART(YEAR, DATEADD(MONTH, -1, GETDATE())) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
PRINT 'checkpoint: reached Q900';
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (900, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q901 | Let me see class-wise outstanding for Term 1 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see class-wise outstanding for Term 1',
        @sql NVARCHAR(MAX) = N'SELECT f.ClassName, SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.Term_Name IN (''Term 1'', ''I'') AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.ClassName ORDER BY f.ClassName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (901, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q902 | Show tickets by priority level. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show tickets by priority level.',
        @sql NVARCHAR(MAX) = N'SELECT fem.DisplayOrder AS EscalationLevel, COUNT(*) AS [Count] FROM FeedbackTicket ft OUTER APPLY (SELECT MAX(ftr.RepliedOn) AS LastReplyDate FROM FeedbackTicketReplies ftr WHERE ftr.TicketID = ft.Id) rp INNER JOIN FeedbackEscalationMatrix fem ON fem.FeedbackCategoryID = ft.CategoryID WHERE ft.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ft.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND DATEDIFF(HOUR, ft.Created_Date, ISNULL(rp.LastReplyDate, GETDATE())) > fem.EscalationHours GROUP BY fem.DisplayOrder ORDER BY fem.DisplayOrder DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (902, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q903 | How much tuition fee has been collected this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much tuition fee has been collected this year?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fcd.Paid_Amt) AS tuition_fee_collected FROM FeesCollection_Details fcd INNER JOIN Fees_Master fm ON fcd.Fees_Head_ID = fm.ID JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fm.Name LIKE ''%Tuition%'' AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (903, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q904 | Class-wise conversion rate for enquiries. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class-wise conversion rate for enquiries.',
        @sql NVARCHAR(MAX) = N'DECLARE @StatusConverted bigint = (SELECT TOP 1 ID FROM Enquiry_Status_Master WHERE Name = ''Completed'');
WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT cm.Name AS ClassName, COUNT(*) AS TotalEnquiries, COUNT(CASE WHEN em.CallStatus_ID = @StatusConverted THEN 1 END) AS Converted, CAST(COUNT(CASE WHEN em.CallStatus_ID = @StatusConverted THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS ConversionRate FROM GeneralCallRegister em INNER JOIN ClassMaster cm ON em.Class_ID = cm.ID WHERE em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND (em.IsDeleted = 0 OR em.IsDeleted IS NULL) GROUP BY cm.Name ORDER BY ConversionRate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (904, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q905 | Give me the total count of hostel students ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the total count of hostel students',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS HostelStudentCount FROM StudentAcademicDetail sad WHERE sad.HostelRequired = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (905, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q906 | Today's new enquiry count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Today''s new enquiry count',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TodayEnquiries FROM GeneralCallRegister WHERE CAST(CallDate AS DATE) = CAST(GETDATE() AS DATE) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (IsDeleted = 0 OR IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (906, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q907 | What is the day closure collection for the last working day? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the day closure collection for the last working day?',
        @sql NVARCHAR(MAX) = N'WITH dc AS (SELECT dm.ID, dm.DayClosureDate AS ClosureDate, dm.CollectedByName AS ClosedBy_Name, SUM(dmd.CollectedAmount) AS TotalCollection, SUM(CASE WHEN cmm.Name = ''Cash'' THEN dmd.CollectedAmount ELSE 0 END) AS CashCollection, SUM(CASE WHEN cmm.Name = ''Bank Online Transfer'' THEN dmd.CollectedAmount ELSE 0 END) AS OnlineCollection, SUM(CASE WHEN cmm.Name NOT IN (''Cash'', ''Bank Online Transfer'', ''Cheque'') THEN dmd.CollectedAmount ELSE 0 END) AS OtherCollection, SUM(CASE WHEN cmm.Name = ''Cheque'' THEN dmd.CollectedAmount ELSE 0 END) AS ChequeCollection FROM DayclosureMaster dm INNER JOIN DayclosureMaster_Details dmd ON dmd.HeaderID = dm.ID LEFT JOIN CollectionMode_Master cmm ON dmd.CollectionMode_ID = cmm.ID WHERE dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (dm.IsDeleted = 0 OR dm.IsDeleted IS NULL) AND (dmd.IsDeleted = 0 OR dmd.IsDeleted IS NULL) GROUP BY dm.ID, dm.DayClosureDate, dm.CollectedByName) SELECT TOP 1 CAST(ClosureDate AS DATE) AS LastClosureDate, TotalCollection, CashCollection, OnlineCollection, ChequeCollection, ClosedBy_Name FROM dc WHERE CAST(ClosureDate AS DATE) < CAST(GETDATE() AS DATE) ORDER BY ClosureDate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (907, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q908 | Show comparison of tickets opened vs resolved per month. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show comparison of tickets opened vs resolved per month.',
        @sql NVARCHAR(MAX) = N'SELECT FORMAT(ft.Created_Date, ''yyyy-MM'') AS [Month], COUNT(*) AS Opened, SUM(CASE WHEN ft.Status = ''Closed'' AND FORMAT(rp.LastReplyDate, ''yyyy-MM'') = FORMAT(ft.Created_Date, ''yyyy-MM'') THEN 1 ELSE 0 END) AS ResolvedSameMonth FROM FeedbackTicket ft OUTER APPLY (SELECT MAX(ftr.RepliedOn) AS LastReplyDate FROM FeedbackTicketReplies ftr WHERE ftr.TicketID = ft.Id) rp WHERE ft.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ft.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY FORMAT(ft.Created_Date, ''yyyy-MM'') ORDER BY [Month];',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (908, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q909 | Class-wise TC count this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class-wise TC count this year',
        @sql NVARCHAR(MAX) = N'SELECT sad.ClassName, COUNT(*) AS TCCount FROM TCRequest tcr INNER JOIN StudentAcademicDetail sad ON tcr.StudentID = sad.StudentID WHERE tcr.TC_Status = ''Issued'' AND tcr.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND tcr.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (tcr.IsDeleted IS NULL OR tcr.IsDeleted = 0) GROUP BY sad.ClassName ORDER BY TCCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (909, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q910 | So, how many students are in the first division (above 60%) in Class 12? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, how many students are in the first division (above 60%) in Class 12?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS FirstDivisionCount FROM (SELECT pc.StudentID, AVG(pc.Marks) AS AvgMarks FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE cm.Name IN (''Class 12'', ''XII'') AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) GROUP BY pc.StudentID HAVING AVG(pc.Marks / pc.MaxMarks * 100) >= 60) t;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (910, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q911 | How many working days remain after accounting for holidays? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many working days remain after accounting for holidays?',
        @sql NVARCHAR(MAX) = N'SELECT DATEDIFF(DAY, GETDATE(), DATEFROMPARTS(CASE WHEN MONTH(GETDATE()) >= 4 THEN YEAR(GETDATE()) ELSE YEAR(GETDATE())-1 END + 1, 3, 31)) - (SELECT COUNT(*) FROM HolidayMaster WHERE From_Date >= GETDATE() AND From_Date <= DATEFROMPARTS(CASE WHEN MONTH(GETDATE()) >= 4 THEN YEAR(GETDATE()) ELSE YEAR(GETDATE())-1 END + 1, 3, 31) AND IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AS RemainingWorkingDays;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (911, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q912 | Show concession category wise total amount from Concession_Master. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show concession category wise total amount from Concession_Master.',
        @sql NVARCHAR(MAX) = N'SELECT cc.Name AS ConcessionCategory, SUM(cm.Concession_Amount) AS TotalConcession FROM Concession_Master cm INNER JOIN Concession_Category_Master cc ON cm.ConcessionCategory_ID = cc.Id WHERE cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND cm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND cm.IsDeleted = 0 GROUP BY cc.Name ORDER BY TotalConcession DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (912, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q913 | Who is the class teacher for Class 8 Section A? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who is the class teacher for Class 8 Section A?',
        @sql NVARCHAR(MAX) = N'SELECT sm.Staff_FirstName + '' '' + ISNULL(sm.Staff_LastName, '''') AS ClassTeacher FROM SubjectAllocation_Master sam INNER JOIN Staff_Master sm ON sam.Staff_ID = sm.Staff_ID INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID INNER JOIN SectionMaster secm ON sam.Section_ID = secm.ID WHERE cm.Name IN (''Class 8'', ''VIII'') AND secm.Name = ''A'' AND sam.IsClassTeacher = 1 AND sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (913, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q914 | Week-wise collection for this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Week-wise collection for this month',
        @sql NVARCHAR(MAX) = N'SELECT DATEPART(WEEK, fc.Bill_Date) - DATEPART(WEEK, DATEFROMPARTS(YEAR(fc.Bill_Date), MONTH(fc.Bill_Date), 1)) + 1 AS WeekNumber, SUM(fc.Receipt_Amt) AS WeeklyCollection FROM FeesCollection fc WHERE MONTH(fc.Bill_Date) = MONTH(GETDATE()) AND YEAR(fc.Bill_Date) = YEAR(GETDATE()) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY DATEPART(WEEK, fc.Bill_Date) - DATEPART(WEEK, DATEFROMPARTS(YEAR(fc.Bill_Date), MONTH(fc.Bill_Date), 1)) + 1 ORDER BY WeekNumber;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (914, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q915 | Students who are inactive but not issued TC ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students who are inactive but not issued TC',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 0 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (915, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q916 | Can you show class-wise fee recovery rate? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show class-wise fee recovery rate?',
        @sql NVARCHAR(MAX) = N'SELECT f.ClassName, ROUND(SUM(f.Paid_Amt) * 100.0 / NULLIF(SUM(f.Amount - ISNULL(f.Concession_Amt, 0)), 0), 2) AS RecoveryRate FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.ClassName ORDER BY RecoveryRate DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (916, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q917 | So, what's the week-over-week application growth? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, what''s the week-over-week application growth?',
        @sql NVARCHAR(MAX) = N'SELECT DATEPART(WEEK, ApplicationDate) AS WeekNum, COUNT(*) AS Applications FROM ApplicationEntry WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) GROUP BY DATEPART(WEEK, ApplicationDate) ORDER BY WeekNum;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (917, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q918 | So, what's the overall pass percentage for the school? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, what''s the overall pass percentage for the school?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(CASE WHEN smd.Marks >= eced.MinMark THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS PassPercentage FROM StudentMarkDetails smd INNER JOIN ExamConfigurationEvaluationDetails eced ON smd.EvalHierID = eced.ID INNER JOIN StudentMarkMaster smm ON smd.HeaderID = smm.ID WHERE smd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND smd.Deleted = 0 AND smm.Deleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (918, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q919 | I need all departments with their staff numbers ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need all departments with their staff numbers',
        @sql NVARCHAR(MAX) = N'SELECT dm.Name AS Department, COUNT(sm.Staff_ID) AS StaffCount FROM StaffDepartmentMaster dm INNER JOIN StaffDepartmentMapping sdm ON dm.Id = sdm.DepartmentID INNER JOIN StaffDepartmentMappingDetail sdmd ON sdm.Id = sdmd.MappingID INNER JOIN Staff_Master sm ON sdmd.StaffID = sm.Staff_ID WHERE dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (dm.IsDeleted IS NULL OR dm.IsDeleted = 0) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.StaffStatus_ID = 1 GROUP BY dm.Name ORDER BY StaffCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (919, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q920 | Can you show the collection efficiency by Class (paid vs demand)? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show the collection efficiency by Class (paid vs demand)?',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, SUM(fcd.Fees_Amount) AS TotalDemand, SUM(fcd.Paid_Amt) AS TotalPaid, CAST(SUM(fcd.Paid_Amt) * 100.0 / NULLIF(SUM(fcd.Fees_Amount), 0) AS DECIMAL(5,2)) AS CollectionEfficiency FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN ClassMaster cm ON fc.Class_ID = cm.ID JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name, cm.DisplayOrder ORDER BY cm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (920, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q921 | So, what's the total outstanding fee? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, what''s the total outstanding fee?',
        @sql NVARCHAR(MAX) = N'SELECT SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS TotalOutstanding FROM FeesInformationStudentDetail f WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (921, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q922 | Which students have pending fees for more than 6 months? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which students have pending fees for more than 6 months?',
        @sql NVARCHAR(MAX) = N'SELECT sm.FirstName + '' '' + sm.LastName AS StudentName, SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN Student_Master sm ON f.Student_ID = sm.ID WHERE f.LastDayToPay < DATEADD(MONTH, -6, GETDATE()) AND f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.FirstName, sm.LastName HAVING SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) > 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (922, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q923 | What's the average fee paid per student? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What''s the average fee paid per student?',
        @sql NVARCHAR(MAX) = N'SELECT AVG(StudentTotal) AS AvgFeePaid FROM (SELECT fc.Student_ID, SUM(fc.Receipt_Amt) AS StudentTotal FROM FeesCollection fc WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fc.Student_ID) AS StudentTotals;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (923, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q924 | Show me class-wise student strength ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me class-wise student strength',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS class_name, COUNT(*) AS student_count FROM StudentAcademicDetail sad JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) GROUP BY cm.Name ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (924, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q925 | Hey, how many applications have incomplete contact information? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many applications have incomplete contact information?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS IncompleteApps FROM ApplicationEntry WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted = 0 OR IsDeleted IS NULL) AND (ComMobile IS NULL OR ComMobile = '''' OR CommunicationMailID IS NULL OR CommunicationMailID = '''');',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (925, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q926 | Year-on-year student strength comparison ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Year-on-year student strength comparison',
        @sql NVARCHAR(MAX) = N'SELECT ''Current Year'' AS Period, COUNT(DISTINCT sad.StudentID) AS TotalStudents FROM StudentAcademicDetail sad WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) UNION ALL SELECT ''Previous Year'' AS Period, COUNT(DISTINCT sad.StudentID) AS TotalStudents FROM StudentAcademicDetail sad WHERE sad.AcademicYearID IN (SELECT PreviousYearID FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (926, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q927 | List all fee defaulters of Class 1 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'List all fee defaulters of Class 1',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, sm.AdmissionNo, sm.FatherContactNo, SUM(fcd.Remaining_Amt) AS outstanding FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Student_Master sm ON fc.Student_ID = sm.ID JOIN ClassMaster cm ON fc.Class_ID = cm.ID WHERE cm.Name IN (''Class 1'', ''I'') AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fcd.Remaining_Amt > 0 GROUP BY sm.FirstName, sm.MiddleName, sm.LastName, sm.AdmissionNo, sm.FatherContactNo HAVING SUM(fcd.Remaining_Amt) > 0 ORDER BY SUM(fcd.Remaining_Amt) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (927, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q928 | Food wale students? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Food wale students?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS FoodStudents FROM StudentAcademicDetail sad WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.FoodRequired = 1 AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (928, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q929 | Just checking - how many students were on permission today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Just checking - how many students were on permission today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS StudentsOnPermission FROM StudentAttendance sa WHERE sa.Attendance_Status_ID = 4 AND CAST(sa.Attendance_Date AS DATE) = CAST(GETDATE() AS DATE) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (929, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q930 | How many students have fully paid their fees? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many students have fully paid their fees?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS fully_paid_students FROM (SELECT fc.Student_ID FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN StudentAcademicDetail sad ON fc.Student_ID = sad.StudentID AND fc.AcademicYearID = sad.AcademicYearID WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND sad.IsActive = 1 GROUP BY fc.Student_ID HAVING SUM(fcd.Remaining_Amt) = 0) AS t;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (930, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q931 | Students who haven't paid even a single rupee this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students who haven''t paid even a single rupee this year',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sm.ID NOT IN (SELECT DISTINCT fc.Student_ID FROM FeesCollection fc WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (931, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q932 | Show term-wise collection ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show term-wise collection',
        @sql NVARCHAR(MAX) = N'SELECT fcd.Term_ID, SUM(fcd.Paid_Amt) AS total_collected FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fcd.Term_ID ORDER BY fcd.Term_ID;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (932, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q933 | New staff joined this academic year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'New staff joined this academic year',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS NewStaff FROM Staff_Master sm WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (sm.IsDeleted IS NULL OR sm.IsDeleted = 0) AND sm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (933, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q934 | Number of new students who joined mid-session ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Number of new students who joined mid-session',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT sad.StudentID) AS MidSessionAdmissions FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNewAdmission = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sm.AdmissionDate > DATEADD(MONTH, 1, bad.Start_Date) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (934, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q935 | How many single-day vs multi-day leaves were taken this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many single-day vs multi-day leaves were taken this month?',
        @sql NVARCHAR(MAX) = N'SELECT CASE WHEN lem.NoOfDays = 1 THEN ''Single-day'' ELSE ''Multi-day'' END AS LeaveCategory, COUNT(*) AS LeaveCount FROM LeaveEntryMaster lem WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND MONTH(lem.LeaveFromDate) = MONTH(GETDATE()) AND YEAR(lem.LeaveFromDate) = YEAR(GETDATE()) AND (lem.IsDeleted IS NULL OR lem.IsDeleted = 0) GROUP BY CASE WHEN lem.NoOfDays = 1 THEN ''Single-day'' ELSE ''Multi-day'' END;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (935, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q936 | I need to see students whose TC has been issued ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see students whose TC has been issued',
        @sql NVARCHAR(MAX) = N'SELECT sad.StudentID, stm.AdmissionNo, ISNULL(stm.FirstName,'''') + '' '' + ISNULL(stm.LastName,'''') AS StudentName FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id INNER JOIN Student_Master stm ON sad.StudentID = stm.ID WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.IsTCIssued = 1;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (936, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q937 | Fees collected in the first week of this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Fees collected in the first week of this month',
        @sql NVARCHAR(MAX) = N'SELECT SUM(fc.Receipt_Amt) AS FirstWeekCollection, COUNT(fc.Id) AS ReceiptCount FROM FeesCollection fc WHERE fc.Bill_Date >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1) AND fc.Bill_Date <= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 7) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (937, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q938 | Students absent yesterday whose fees collection was done today ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Students absent yesterday whose fees collection was done today',
        @sql NVARCHAR(MAX) = N'SELECT DISTINCT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, fc.Receipt_Amt FROM Student_Master sm INNER JOIN StudentAttendance sa ON sm.ID = sa.Student_ID INNER JOIN FeesCollection fc ON sm.ID = fc.Student_ID WHERE sa.Attendance_Date = CAST(DATEADD(DAY, -1, GETDATE()) AS DATE) AND sa.Attendance_Status_ID = 2 AND CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (938, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q939 | So, what's the hostel fee outstanding? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, what''s the hostel fee outstanding?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS HostelFeeOutstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND IsHostelFee = 1 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (939, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q940 | Pass percentage in English for Class 8 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pass percentage in English for Class 8',
        @sql NVARCHAR(MAX) = N'SELECT CAST(SUM(CASE WHEN pc.Marks >= pc.MinMark THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS PassPercentage FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE pc.SubjectName = ''English'' AND cm.Name IN (''Class 8'', ''VIII'') AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (940, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q941 | So, how many were absent yesterday? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, how many were absent yesterday?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS absent_yesterday FROM StudentAttendance sa WHERE CAST(sa.Attendance_Date AS DATE) = CAST(DATEADD(DAY, -1, GETDATE()) AS DATE) AND sa.Attendance_Status_ID = 2 AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (941, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q942 | What was the total amount closed out in cash mode yesterday? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What was the total amount closed out in cash mode yesterday?',
        @sql NVARCHAR(MAX) = N'WITH dc AS (SELECT dm.ID, dm.DayClosureDate AS ClosureDate, dm.CollectedByName AS ClosedBy_Name, SUM(dmd.CollectedAmount) AS TotalCollection, SUM(CASE WHEN cmm.Name = ''Cash'' THEN dmd.CollectedAmount ELSE 0 END) AS CashCollection, SUM(CASE WHEN cmm.Name = ''Bank Online Transfer'' THEN dmd.CollectedAmount ELSE 0 END) AS OnlineCollection, SUM(CASE WHEN cmm.Name NOT IN (''Cash'', ''Bank Online Transfer'', ''Cheque'') THEN dmd.CollectedAmount ELSE 0 END) AS OtherCollection, SUM(CASE WHEN cmm.Name = ''Cheque'' THEN dmd.CollectedAmount ELSE 0 END) AS ChequeCollection FROM DayclosureMaster dm INNER JOIN DayclosureMaster_Details dmd ON dmd.HeaderID = dm.ID LEFT JOIN CollectionMode_Master cmm ON dmd.CollectionMode_ID = cmm.ID WHERE dm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND dm.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (dm.IsDeleted = 0 OR dm.IsDeleted IS NULL) AND (dmd.IsDeleted = 0 OR dmd.IsDeleted IS NULL) GROUP BY dm.ID, dm.DayClosureDate, dm.CollectedByName) SELECT CashCollection FROM dc WHERE CAST(ClosureDate AS DATE) = CAST(DATEADD(DAY, -1, GETDATE()) AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (942, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q943 | Top 3 enquiry sources this year. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Top 3 enquiry sources this year.',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT TOP 3 emm.Name AS Source, COUNT(*) AS EnquiryCount FROM GeneralCallRegister em INNER JOIN Enquiry_Mode_Master emm ON em.Mode_ID = emm.ID WHERE em.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND em.BranchID IN (SELECT BranchID FROM AllowedBranches) AND (em.IsDeleted = 0 OR em.IsDeleted IS NULL) GROUP BY emm.Name ORDER BY EnquiryCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (943, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q944 | Give me a branch-wise breakdown of boys and girls ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me a branch-wise breakdown of boys and girls',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, SUM(CASE WHEN sm.Gender IN (''Male'', ''Boy'') THEN 1 ELSE 0 END) AS Boys, SUM(CASE WHEN sm.Gender IN (''Female'', ''Girl'') THEN 1 ELSE 0 END) AS Girls FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN BranchMaster bm ON sm.BranchID = bm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY bm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (944, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q945 | How many enquiries were lost this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many enquiries were lost this year?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT COUNT(*) AS LostEnquiries FROM GeneralCallRegister WHERE CallStatus_ID IN (SELECT ID FROM Enquiry_Status_Master WHERE Name = ''Dropped'') AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (945, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q946 | How many leaves were rejected this academic year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many leaves were rejected this academic year?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS RejectedLeaves FROM LeaveEntryMaster lem INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID = ls.ID WHERE lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND lem.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (lem.IsDeleted = 0 OR lem.IsDeleted IS NULL) AND ls.Name = ''Cancel'';',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (946, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q947 | Let me see the outstanding fee amount for each of my branches ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see the outstanding fee amount for each of my branches',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, SUM((f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0))) AS Outstanding FROM FeesInformationStudentDetail f INNER JOIN BranchMaster bm ON f.BranchID = bm.ID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1)) GROUP BY bm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (947, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q948 | Pull up the bus fee vs hostel fee comparison ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up the bus fee vs hostel fee comparison',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CASE WHEN IsBusFee = 1 THEN Amount ELSE 0 END) AS BusFeeDemand, SUM(CASE WHEN IsBusFee = 1 THEN Paid_Amt ELSE 0 END) AS BusFeeCollected, SUM(CASE WHEN IsHostelFee = 1 THEN Amount ELSE 0 END) AS HostelFeeDemand, SUM(CASE WHEN IsHostelFee = 1 THEN Paid_Amt ELSE 0 END) AS HostelFeeCollected FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (948, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q949 | How many distinct fee types are configured this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many distinct fee types are configured this year?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(DISTINCT f.FeesType_Name) AS FeeTypeCount FROM FeesInformationStudentDetail f WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (949, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q950 | What is the attendance percentage for each day this week? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the attendance percentage for each day this week?',
        @sql NVARCHAR(MAX) = N'SELECT CAST(sa.Attendance_Date AS DATE) AS AttDate, DATENAME(WEEKDAY, sa.Attendance_Date) AS DayName, COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) AS Present, COUNT(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 END) AS Absent, CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AttendancePercent FROM StudentAttendance sa JOIN Branch_Academic_Details bad ON sa.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sa.Attendance_Date >= DATEADD(DAY, -DATEPART(WEEKDAY, GETDATE()) + 1, CAST(GETDATE() AS DATE)) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY CAST(sa.Attendance_Date AS DATE), DATENAME(WEEKDAY, sa.Attendance_Date) ORDER BY AttDate;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (950, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q951 | How many vehicles are of bus type? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many vehicles are of bus type?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS BusCount FROM VehicleMaster WHERE Vehicle_Type_Name = ''Bus'' AND IsDeleted = 0 AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (951, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q952 | Which class had the most students leaving? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which class had the most students leaving?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 cm.Name AS ClassName, COUNT(DISTINCT sad.StudentID) AS StudentsLeft FROM StudentAcademicDetail sad JOIN ClassMaster cm ON sad.ClassID = cm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsTCIssued = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY cm.Name ORDER BY StudentsLeft DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (952, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q953 | Who takes Social Studies for 10A? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Who takes Social Studies for 10A?',
        @sql NVARCHAR(MAX) = N'SELECT sm.Staff_FirstName + '' '' + ISNULL(sm.Staff_LastName, '''') AS TeacherName FROM SubjectAllocation_Master sam INNER JOIN Staff_Master sm ON sam.Staff_ID = sm.Staff_ID INNER JOIN ClassMaster cm ON sam.Class_ID = cm.ID INNER JOIN SectionMaster secm ON sam.Section_ID = secm.ID INNER JOIN Subject_Master sub ON sam.Subject_ID = sub.Id WHERE cm.Name IN (''Class 10'', ''X'') AND secm.Name = ''A'' AND sub.Name = ''Social Studies'' AND sam.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sam.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (sam.IsDeleted = 0 OR sam.IsDeleted IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (953, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q954 | Science topper in Class 8 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Science topper in Class 8',
        @sql NVARCHAR(MAX) = N'SELECT TOP 1 pc.StudentName AS StudentName, pc.Marks FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE pc.SubjectName = ''Science'' AND cm.Name IN (''Class 8'', ''VIII'') AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) ORDER BY pc.Marks DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (954, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q955 | Can you show expired circulars from last month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show expired circulars from last month?',
        @sql NVARCHAR(MAX) = N'SELECT Title, Circular_Date, CircularApplicableFor AS TargetAudience, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS CreatedBy_Name FROM CircularEntry ce LEFT JOIN Staff_Master sm ON ce.Created_By = sm.Staff_ID WHERE ce.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND ce.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND MONTH(ce.Circular_Date) = MONTH(DATEADD(MONTH, -1, GETDATE())) AND YEAR(ce.Circular_Date) = YEAR(DATEADD(MONTH, -1, GETDATE())) AND (ce.IsDeleted = 0 OR ce.IsDeleted IS NULL) ORDER BY ce.Circular_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (955, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q956 | Hey, how many leave requests are awaiting approval right now? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, how many leave requests are awaiting approval right now?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS PendingLeaves FROM LeaveEntryMaster lem INNER JOIN LeaveStatus ls ON lem.LeaveStatus_ID=ls.ID WHERE ls.Name=''Pending'' AND lem.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (lem.IsDeleted IS NULL OR lem.IsDeleted=0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (956, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q957 | Which class has the highest fee collection AND lowest attendance? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Which class has the highest fee collection AND lowest attendance?',
        @sql NVARCHAR(MAX) = N'WITH ClassCollection AS (SELECT fc.Class_ID, SUM(fc.Receipt_Amt) AS TotalCollection FROM FeesCollection fc JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fc.Class_ID), ClassAttendance AS (SELECT sa.Class_ID, CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AttendancePercent FROM StudentAttendance sa JOIN Branch_Academic_Details bad ON sa.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sa.Class_ID) SELECT cm.Name AS ClassName, cc.TotalCollection, ca.AttendancePercent FROM ClassCollection cc JOIN ClassAttendance ca ON cc.Class_ID = ca.Class_ID JOIN ClassMaster cm ON cc.Class_ID = cm.ID ORDER BY cc.TotalCollection DESC, ca.AttendancePercent ASC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (957, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q958 | Give me the class-wise student distribution in percentages ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the class-wise student distribution in percentages',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName, COUNT(sad.Id) AS StudentCount, CAST(COUNT(sad.Id) * 100.0 / (SELECT COUNT(*) FROM StudentAcademicDetail sad2 WHERE sad2.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad2.IsActive = 1 AND (sad2.IsTCIssued = 0 OR sad2.IsTCIssued IS NULL)) AS DECIMAL(5,2)) AS Percentage FROM StudentAcademicDetail sad INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) GROUP BY cm.Name, cm.DisplayOrder ORDER BY cm.DisplayOrder;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (958, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q959 | Show me the daily enquiry trend for the last 14 days. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me the daily enquiry trend for the last 14 days.',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT CAST(CallDate AS DATE) AS EnquiryDay, COUNT(*) AS EnquiryCount FROM GeneralCallRegister WHERE CallDate >= DATEADD(DAY, -14, GETDATE()) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0 GROUP BY CAST(CallDate AS DATE) ORDER BY EnquiryDay;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (959, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q960 | Religion-wise student distribution in percentage ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Religion-wise student distribution in percentage',
        @sql NVARCHAR(MAX) = N'SELECT sm.Religion_Name, COUNT(*) AS StudentCount, CAST(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM StudentAcademicDetail sad2 INNER JOIN Student_Master sm2 ON sad2.StudentID = sm2.ID WHERE sad2.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad2.IsActive = 1 AND (sad2.IsTCIssued = 0 OR sad2.IsTCIssued IS NULL)) AS DECIMAL(5,2)) AS Percentage FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) GROUP BY sm.Religion_Name ORDER BY COUNT(*) DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (960, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q961 | I need to see the overall picture ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need to see the overall picture',
        @sql NVARCHAR(MAX) = N'SELECT (SELECT COUNT(*) FROM StudentAcademicDetail WHERE AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND IsActive = 1 AND (IsTCIssued = 0 OR IsTCIssued IS NULL)) AS TotalStudents, (SELECT ISNULL(SUM(Receipt_Amt), 0) FROM FeesCollection WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (IsDeleted IS NULL OR IsDeleted = 0) AND ChequeStatus_ID NOT IN (3, 4)) AS TotalCollection, (SELECT ISNULL(SUM(Remaining_Amt), 0) FROM FeesCollection_Details WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND Remaining_Amt > 0) AS TotalOutstanding;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (961, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q962 | Collection during February this year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Collection during February this year',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS FebruaryCollection FROM FeesCollection fc WHERE MONTH(fc.Bill_Date) = 2 AND YEAR(fc.Bill_Date) = 2026 AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (962, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q963 | Pull up community-wise student distribution ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Pull up community-wise student distribution',
        @sql NVARCHAR(MAX) = N'SELECT sm.Community_Name, COUNT(DISTINCT sad.StudentID) AS StudentCount FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.Community_Name ORDER BY StudentCount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (963, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q964 | Reset the password for teacher ID 45 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Reset the password for teacher ID 45',
        @sql NVARCHAR(MAX) = N'-- This question asks me to perform a system administration action (reset password), which I cannot do. I can only retrieve data.
SELECT ''Password reset cannot be performed through queries. Please contact the system administrator.'' AS Message;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (964, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q965 | Class 8 rank list with total marks ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Class 8 rank list with total marks',
        @sql NVARCHAR(MAX) = N'SELECT RANK() OVER (ORDER BY SUM(pc.Marks) DESC) AS Rank, pc.StudentName AS StudentName, SUM(pc.Marks) AS TotalMarks, CAST(AVG(pc.Marks) AS DECIMAL(5,2)) AS AvgMarks FROM ProgressCardDataRetrieval pc INNER JOIN ClassMaster cm ON pc.ClassID = cm.ID WHERE cm.Name IN (''Class 8'', ''VIII'') AND pc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND pc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (pc.IsDeleted = 0 OR pc.IsDeleted IS NULL) GROUP BY pc.StudentName ORDER BY TotalMarks DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (965, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q966 | Give me the branch-wise boys count ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the branch-wise boys count',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, COUNT(*) AS Boys FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN BranchMaster bm ON sm.BranchID = bm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.Gender IN (''Male'', ''Boy'') AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bm.Name ORDER BY Boys DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (966, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q967 | What was the attendance on 15th June? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What was the attendance on 15th June?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS present, SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END) AS absent, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS pct FROM StudentAttendance sa WHERE CAST(sa.Attendance_Date AS DATE) = DATEFROMPARTS(CASE WHEN MONTH(GETDATE()) >= 4 THEN YEAR(GETDATE()) ELSE YEAR(GETDATE())-1 END + 0, 6, 15) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (967, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q968 | Show me this week's attendance trend ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show me this week''s attendance trend',
        @sql NVARCHAR(MAX) = N'SELECT CAST(sa.Attendance_Date AS DATE) AS date, SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) AS present, SUM(CASE WHEN sa.Attendance_Status_ID = 2 THEN 1 ELSE 0 END) AS absent, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS pct FROM StudentAttendance sa WHERE sa.Attendance_Date >= DATEADD(DAY, 1 - DATEPART(WEEKDAY, GETDATE()), CAST(GETDATE() AS DATE)) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY CAST(sa.Attendance_Date AS DATE) ORDER BY CAST(sa.Attendance_Date AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (968, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q969 | Salary summary by staff type for the year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Salary summary by staff type for the year',
        @sql NVARCHAR(MAX) = N'SELECT gm.StaffTypeName, SUM(gem.NetPay) AS TotalSalary, COUNT(DISTINCT gem.EmployeeID) AS StaffCount FROM GenerateSalaryEmployee_Master gem INNER JOIN GenerateSalary_Master gm ON gem.HeaderID = gm.ID INNER JOIN Branch_Academic_Details b ON gm.AcademicYearID = b.Id WHERE gm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND GETDATE() BETWEEN b.Start_Date AND b.End_Date AND gm.IsDeleted = 0 AND gem.IsDeleted = 0 GROUP BY gm.StaffTypeName;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (969, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q970 | So, what's the total fee collected from hostel students? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, what''s the total fee collected from hostel students?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS hostel_collection FROM FeesCollection fc JOIN StudentAcademicDetail sad ON fc.Student_ID = sad.StudentID AND fc.AcademicYearID = sad.AcademicYearID WHERE sad.HostelRequired = 1 AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (970, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q971 | Can you show collection by branch for the current academic year with a grand total row? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show collection by branch for the current academic year with a grand total row?',
        @sql NVARCHAR(MAX) = N'SELECT bm.Name AS Branch, SUM(fc.Receipt_Amt) AS Collection FROM FeesCollection fc JOIN BranchMaster bm ON fc.BranchID = bm.ID WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY ROLLUP(bm.Name) ORDER BY GROUPING(bm.Name), Collection DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (971, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q972 | How many staff arrived before 8 AM today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How many staff arrived before 8 AM today?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS EarlyArrivals FROM Staff_Attendance WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND Attendance_Date = CAST(GETDATE() AS DATE) AND InTime < ''08:00:00'' AND InTime IS NOT NULL;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (972, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q973 | Let me see the route-wise transport fee range ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Let me see the route-wise transport fee range',
        @sql NVARCHAR(MAX) = N'SELECT rm.Name AS RouteName, MIN(bpm.Amount) AS MinFee, MAX(bpm.Amount) AS MaxFee FROM Route_Master rm INNER JOIN Route_MasterDetails rmd ON rm.ID = rmd.Route_ID INNER JOIN BoardingPoint_Master bpm ON rmd.BoardingPoint_ID = bpm.Id WHERE rm.IsDeleted = 0 AND rm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY rm.Name ORDER BY rm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (973, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q974 | How much money was lost to bounced cheque payments this year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much money was lost to bounced cheque payments this year?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS BouncedChequeAmount FROM FeesCollection fc WHERE fc.ChequeStatus_ID = 4 AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (974, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q975 | Compare attendance this month with last month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Compare attendance this month with last month',
        @sql NVARCHAR(MAX) = N'SELECT ''This Month'' AS period, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS pct FROM StudentAttendance sa WHERE DATEPART(MONTH, sa.Attendance_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, sa.Attendance_Date) = DATEPART(YEAR, GETDATE()) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) UNION ALL SELECT ''Last Month'' AS period, CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS pct FROM StudentAttendance sa WHERE DATEPART(MONTH, sa.Attendance_Date) = DATEPART(MONTH, DATEADD(MONTH, -1, GETDATE())) AND DATEPART(YEAR, sa.Attendance_Date) = DATEPART(YEAR, DATEADD(MONTH, -1, GETDATE())) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (975, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q976 | What is the collection summary by fee type? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the collection summary by fee type?',
        @sql NVARCHAR(MAX) = N'SELECT fcd.FeesType_Name, SUM(fcd.Paid_Amt) AS TotalPaid, COUNT(DISTINCT fc.Student_ID) AS StudentCount FROM FeesCollection_Details fcd JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id JOIN Branch_Academic_Details bad ON fc.AcademicYearID = bad.Id WHERE (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY fcd.FeesType_Name ORDER BY TotalPaid DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (976, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q977 | Show the nationality-wise count of new admissions ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show the nationality-wise count of new admissions',
        @sql NVARCHAR(MAX) = N'SELECT sm.Nationality_Name, COUNT(DISTINCT sad.StudentID) AS Admissions FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.IsNewAdmission = 1 AND GETDATE() BETWEEN bad.Start_Date AND bad.End_Date AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY sm.Nationality_Name ORDER BY Admissions DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (977, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q978 | What is the outstanding for examination fees? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the outstanding for examination fees?',
        @sql NVARCHAR(MAX) = N'SELECT SUM(f.Amount - ISNULL(f.Concession_Amt, 0) - ISNULL(f.Paid_Amt, 0) - ISNULL(f.Lien_Amount, 0)) AS ExamFeeOutstanding FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND f.Fees_Name LIKE ''%Exam%'' AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (978, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q979 | Total collection for this academic year ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total collection for this academic year',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS YearCollection FROM FeesCollection fc WHERE fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (979, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q980 | Give me the department list with descriptions ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me the department list with descriptions',
        @sql NVARCHAR(MAX) = N'SELECT Name AS Department, Description FROM StaffDepartmentMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0 ORDER BY Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (980, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q981 | How much have we collected since the start of this month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How much have we collected since the start of this month?',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS MonthlyCollection FROM FeesCollection fc WHERE DATEPART(MONTH, fc.Bill_Date) = DATEPART(MONTH, GETDATE()) AND DATEPART(YEAR, fc.Bill_Date) = DATEPART(YEAR, GETDATE()) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (981, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q982 | Classes with no transport students at all ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Classes with no transport students at all',
        @sql NVARCHAR(MAX) = N'SELECT cm.Name AS ClassName FROM ClassMaster cm WHERE cm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND cm.IsDeleted = 0 AND cm.ID NOT IN (SELECT DISTINCT sad.ClassID FROM StudentAcademicDetail sad WHERE sad.TransportRequired = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (982, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q983 | Any lumpsum payments? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Any lumpsum payments?',
        @sql NVARCHAR(MAX) = N'SELECT sm.AdmissionNo, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sad.Lumpsum_Amount, sad.Paid_Date FROM StudentAcademicDetail sad INNER JOIN Student_Master sm ON sad.StudentID = sm.ID WHERE sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsLumpsumApplicable = 1 AND sad.IsActive = 1 ORDER BY sad.Paid_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (983, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q984 | Give me today's fee collection amount ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me today''s fee collection amount',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(SUM(fc.Receipt_Amt), 0) AS collection_today FROM FeesCollection fc WHERE CAST(fc.Bill_Date AS DATE) = CAST(GETDATE() AS DATE) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (984, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q985 | I wanna see the list of VIP students ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I wanna see the list of VIP students',
        @sql NVARCHAR(MAX) = N'SELECT ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS student_name, sm.AdmissionNo, cm.Name AS class_name, sm.FatherName, sm.FatherContactNo FROM StudentAcademicDetail sad JOIN Student_Master sm ON sad.StudentID = sm.ID JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.IsVIP = 1 AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY cm.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (985, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q986 | So, how many students used hostel facility each year? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'So, how many students used hostel facility each year?',
        @sql NVARCHAR(MAX) = N'SELECT bad.Name AS AcademicYear, COUNT(DISTINCT sad.StudentID) AS HostelStudents FROM StudentAcademicDetail sad JOIN Branch_Academic_Details bad ON sad.AcademicYearID = bad.Id WHERE sad.HostelRequired = 1 AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND bad.Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY bad.Name ORDER BY bad.Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (986, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q987 | Can you list out the most recent refunds issued? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you list out the most recent refunds issued?',
        @sql NVARCHAR(MAX) = N'SELECT TOP 10 r.Bill_Date, r.RequestRemarks AS Reason, r.Refund_Amt AS Amount FROM RefundReceipt r WHERE r.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND r.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) ORDER BY r.Bill_Date DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (987, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q988 | Boys from SC community in Class 9 and Class 10 ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Boys from SC community in Class 9 and Class 10',
        @sql NVARCHAR(MAX) = N'SELECT sm.ID, ISNULL(sm.FirstName, '''') + '' '' + ISNULL(sm.MiddleName, '''') + '' '' + ISNULL(sm.LastName, '''') AS StudentName, sm.AdmissionNo, sad.ClassName, sad.RollNo FROM Student_Master sm INNER JOIN StudentAcademicDetail sad ON sm.ID = sad.StudentID INNER JOIN ClassMaster cm ON sad.ClassID = cm.ID WHERE cm.Name IN (''Class 9'', ''Class 10'') AND sm.Gender IN (''Male'', ''Boy'') AND sm.Community_Name = ''SC'' AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL) AND sm.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) ORDER BY sad.ClassName, sad.RollNo;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (988, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q989 | How did attendance compare between this year and last year for the same month? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'How did attendance compare between this year and last year for the same month?',
        @sql NVARCHAR(MAX) = N'SELECT ''Current Year'' AS Period, CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AttendancePercent FROM StudentAttendance sa WHERE MONTH(sa.Attendance_Date) = MONTH(GETDATE()) AND sa.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) UNION ALL SELECT ''Previous Year'' AS Period, CAST(COUNT(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) AS AttendancePercent FROM StudentAttendance sa WHERE MONTH(sa.Attendance_Date) = MONTH(GETDATE()) AND sa.AcademicYearID IN (SELECT PreviousYearID FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0));',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (989, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q990 | Fees collected on Saturday this month ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Fees collected on Saturday this month',
        @sql NVARCHAR(MAX) = N'SELECT CAST(fc.Bill_Date AS DATE) AS CollectionDate, SUM(fc.Receipt_Amt) AS Amount FROM FeesCollection fc WHERE fc.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fc.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND DATEPART(WEEKDAY, fc.Bill_Date) = 7 AND MONTH(fc.Bill_Date) = MONTH(GETDATE()) AND YEAR(fc.Bill_Date) = YEAR(GETDATE()) AND (fc.IsDeleted IS NULL OR fc.IsDeleted = 0) AND fc.ChequeStatus_ID NOT IN (3, 4) GROUP BY CAST(fc.Bill_Date AS DATE) ORDER BY CAST(fc.Bill_Date AS DATE);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (990, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q991 | What is the average days to convert an enquiry? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What is the average days to convert an enquiry?',
        @sql NVARCHAR(MAX) = N'WITH AllowedBranches AS (
    SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId)
    UNION
    SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)
)
SELECT ROUND(AVG(CAST(DATEDIFF(DAY, CallDate, GETDATE()) AS FLOAT)), 1) AS AvgDaysToConvert FROM GeneralCallRegister WHERE CallStatus_ID IN (SELECT ID FROM Enquiry_Status_Master WHERE Name = ''Completed'') AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM AllowedBranches)) AND BranchID IN (SELECT BranchID FROM AllowedBranches) AND IsDeleted = 0;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (991, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q992 | Show month-wise total demand and total collected. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show month-wise total demand and total collected.',
        @sql NVARCHAR(MAX) = N'SELECT f.Month_No, f.Month_Name, SUM(f.Amount) AS Demand, SUM(f.Paid_Amt) AS Collected FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Month_No, f.Month_Name ORDER BY f.Month_No;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (992, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q993 | Hey, what's the total late fee pending amount for each late fee type? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Hey, what''s the total late fee pending amount for each late fee type?',
        @sql NVARCHAR(MAX) = N'SELECT fcd.LateFeeName, SUM(fcd.LateFeeAmount) AS PendingAmount, COUNT(*) AS PendingCount FROM FeesCollection_Details fcd INNER JOIN FeesCollection fc ON fcd.Fees_Collection_ID = fc.Id WHERE fcd.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND fcd.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND fcd.LateFeeAmount > 0 AND (fc.IsDeleted = 0 OR fc.IsDeleted IS NULL) AND fc.ChequeStatus_ID NOT IN (3, 4) AND fcd.Remaining_Amt > 0 GROUP BY fcd.LateFeeName ORDER BY PendingAmount DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (993, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q994 | Give me a list of TC issuances from the last one week ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Give me a list of TC issuances from the last one week',
        @sql NVARCHAR(MAX) = N'SELECT tcr.FirstName, tcr.LastName, tcr.IssuedDate FROM TCRequest tcr WHERE tcr.IssuedDate >= DATEADD(DAY, -7, CAST(GETDATE() AS DATE)) AND tcr.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND (tcr.IsDeleted IS NULL OR tcr.IsDeleted = 0);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (994, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q995 | What are the all staff departments? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'What are the all staff departments?',
        @sql NVARCHAR(MAX) = N'SELECT Name AS Department FROM StaffDepartmentMaster WHERE BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND IsDeleted = 0 ORDER BY Name;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (995, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q996 | I need classes with more than 50 students having outstanding ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'I need classes with more than 50 students having outstanding',
        @sql NVARCHAR(MAX) = N'SELECT ClassName, COUNT(DISTINCT Student_ID) AS StudentsWithDue FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND (Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) > 0 AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY ClassName HAVING COUNT(DISTINCT Student_ID) > 50 ORDER BY StudentsWithDue DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (996, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q997 | Can you show month-wise total demand and total collected? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can you show month-wise total demand and total collected?',
        @sql NVARCHAR(MAX) = N'SELECT f.Month_No, f.Month_Name, SUM(f.Amount) AS Demand, SUM(f.Paid_Amt) AS Collected FROM FeesInformationStudentDetail f INNER JOIN StudentAcademicDetail sa ON f.Student_ID = sa.StudentID AND f.ClassID = sa.ClassID WHERE f.IsIncludedInLumpSum <> 1 AND f.IsDonation = 0 AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sa.IsActive = 1 AND (sa.IsTCIssued = 0 OR sa.IsTCIssued IS NULL) GROUP BY f.Month_No, f.Month_Name ORDER BY f.Month_No;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (997, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q998 | Show outstanding per section for Class 9. ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Show outstanding per section for Class 9.',
        @sql NVARCHAR(MAX) = N'SELECT SectionName, SUM(Amount - ISNULL(Concession_Amt, 0) - ISNULL(Paid_Amt, 0) - ISNULL(Lien_Amount, 0)) AS Outstanding FROM FeesInformationStudentDetail WHERE IsIncludedInLumpSum <> 1 AND IsDonation = 0 AND ClassName = ''Class 9'' AND AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) GROUP BY SectionName ORDER BY Outstanding DESC;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (998, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q999 | Total strength? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Total strength?',
        @sql NVARCHAR(MAX) = N'SELECT COUNT(*) AS TotalStrength FROM StudentAcademicDetail sad WHERE sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0))) AND sad.IsActive = 1 AND (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL);',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (999, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ============ Q1000 | Can I see the absence reasons for today? ============
DECLARE @UserId INT = 1, @SelectedBranchId INT = NULL,
        @q NVARCHAR(300) = N'Can I see the absence reasons for today?',
        @sql NVARCHAR(MAX) = N'SELECT sa.Staff_ID, sm.Staff_FirstName + '' '' + sm.Staff_LastName AS StaffName, sa.Attendance_Reason FROM Staff_Attendance sa INNER JOIN Staff_Master sm ON sa.Staff_ID = sm.Staff_ID AND sm.StaffStatus_ID = 1 WHERE sa.Attendance_Date = CAST(GETDATE() AS DATE) AND sa.Attendance_Status_ID = 2 AND sa.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) AND (IsDeleted IS NULL OR IsDeleted = 0)) AND sa.Attendance_Reason IS NOT NULL;',
        @t0 DATETIME2 = SYSDATETIME(), @ms INT = 0;
BEGIN TRY
    EXEC sp_executesql @sql, N'@UserId INT, @SelectedBranchId INT',
        @UserId, @SelectedBranchId;
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
PRINT 'checkpoint: reached Q1000';
END TRY
BEGIN CATCH
    SET @ms = DATEDIFF(MILLISECOND, @t0, SYSDATETIME());
    INSERT INTO #ai_errors (qid, question, error, ms)
    VALUES (1000, @q, CAST(ERROR_NUMBER() AS VARCHAR(8)) + ': ' + ERROR_MESSAGE(), @ms);
END CATCH
GO
-- ===================== PART 2 SUMMARY (Q501-Q1000) =====================
DECLARE @lo INT = 501, @hi INT = 1000, @fails INT;
SELECT @fails = COUNT(*) FROM #ai_errors WHERE qid BETWEEN @lo AND @hi;
PRINT 'PART 2 done: ' + CAST((@hi - @lo + 1) AS VARCHAR(6)) + ' queries, '
    + CAST(@fails AS VARCHAR(6)) + ' failed.';
DECLARE @qid INT, @qq NVARCHAR(300), @ee NVARCHAR(2048);
DECLARE c CURSOR LOCAL FAST_FORWARD FOR
    SELECT qid, question, error FROM #ai_errors WHERE qid BETWEEN @lo AND @hi ORDER BY qid;
OPEN c;
FETCH NEXT FROM c INTO @qid, @qq, @ee;
WHILE @@FETCH_STATUS = 0
BEGIN
    PRINT 'Q' + CAST(@qid AS VARCHAR(6)) + ' FAILED: ' + LEFT(@ee, 300);
    PRINT '   question: ' + LEFT(@qq, 200);
    FETCH NEXT FROM c INTO @qid, @qq, @ee;
END
CLOSE c; DEALLOCATE c;
SELECT qid, question, error, ms FROM #ai_errors WHERE qid BETWEEN @lo AND @hi ORDER BY qid;
GO

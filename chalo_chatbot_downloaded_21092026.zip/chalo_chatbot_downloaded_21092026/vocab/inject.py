"""
inject.py — Vocab Engine: build the per-branch injection prompt (both modes)
=============================================================================

Two modes, matching the Option A decision (round-4 §30):

1. STOPGAP MODE (inject_vocab=False, default — works with the current v27 model)
   - The model is NOT given the branch's real vocabulary at generation time.
   - The synonym store (synonyms.json) + value_resolver's validate-and-substitute
     handle phrasing-to-canonical mapping after generation.
   - Used by the runtime pipeline when inject_vocab is OFF in config.

2. FULL MODE (inject_vocab=True — for the v28 vocab-aware retrain)
   - The model IS given the branch's real vocabulary (Classes/Sections/Subjects/
     EnquiryStatuses/FeeHeads/ExamTerms/FeeTerms) at generation time, prepended
     to the system prompt.
   - The model writes the correct literal at generation time, eliminating the
     validate-and-substitute round-trip.
   - Requires a v28 retrain where the same vocab block was in every training
     example's `instruction` field (see prepare_data.py FROZEN_SYSTEM_PROMPT).

Both modes share the same Context JSON source (UserBranchDetails) and the same
synonym store (synonyms.json). Switching modes is config-driven; no code change.
"""
from __future__ import annotations
import json
import os
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any

# Concept type → Context JSON branch key
CONCEPT_TO_JSON_KEY = {
    "CLASS": "Classes",
    "SECTION": "Sections",
    "SUBJECT": "Subjects",
    "ENQUIRY_STATUS": "EnquiryStatuses",
    "FEE_HEAD": "FeeHeads",
    "EXAM_TERM": "ExamTerms",
    "FEE_TERM": "FeeTerms",  # NEW — not yet in the real API; fallback adds it
}

# Human labels for the injection prompt
_CONCEPT_PROMPT_LABEL = {
    "CLASS": "Classes",
    "SECTION": "Sections",
    "SUBJECT": "Subjects",
    "ENQUIRY_STATUS": "Enquiry statuses",
    "FEE_HEAD": "Fee heads",
    "EXAM_TERM": "Exam terms",
    "FEE_TERM": "Fee terms",
}

# ── BranchVocab (per-branch real master-data vocabulary) ──────────────────────

@dataclass
class AcademicYear:
    id: int
    name: str
    is_current: bool = False
    previous_year_id: Optional[int] = None

@dataclass
class BranchVocab:
    branch_id: int
    name: Optional[str] = None
    is_primary: bool = False
    academic_years: List[AcademicYear] = field(default_factory=list) if False else None
    vocab: Dict[str, List[str]] = None  # concept_type → ordered list of real values

    def __post_init__(self):
        if self.academic_years is None: self.academic_years = []
        if self.vocab is None: self.vocab = {}

    @property
    def current_academic_year(self) -> Optional[AcademicYear]:
        for ay in self.academic_years:
            if ay.is_current: return ay
        return None

    def values(self, concept_type: str) -> List[str]:
        return self.vocab.get(concept_type, [])

    def is_member(self, concept_type: str, value: str) -> bool:
        """EXACT (case-sensitive) membership — matches the DB literal exactly."""
        return value in self.values(concept_type)

    def match_ci(self, concept_type: str, value: str) -> List[str]:
        """Case-insensitive matches (0, 1, or 2+) — for near-miss detection."""
        if not value: return []
        needle = value.strip().lower()
        return [v for v in self.values(concept_type) if v.strip().lower() == needle]

@dataclass
class UserContextVocab:
    user_id: int
    username: str = ""
    staff_name: str = ""
    is_super_user: bool = False
    target_database: Optional[str] = None
    short_name: Optional[str] = None
    branches: Dict[int, BranchVocab] = field(default_factory=dict) if False else None

    def __post_init__(self):
        if self.branches is None: self.branches = {}

    def branch(self, branch_id: int) -> BranchVocab:
        b = self.branches.get(branch_id)
        if b is None:
            raise ValueError(f"Branch {branch_id} not in this user's context.")
        return b

    @property
    def branch_ids(self) -> List[int]:
        return list(self.branches.keys())

# ── Synonym store (phrasing → ConceptKey) ────────────────────────────────────

class SynonymStore:
    """Maps user phrasings to canonical ConceptKeys per concept type.
    Loaded once from synonyms.json. Pure data — no DB, no state."""

    def __init__(self, path: str = None):
        if path is None:
            path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "synonyms.json")
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        self._data = {k: v for k, v in data.items() if not k.startswith("_")}
        # build reverse index: phrasing (lowercased) → ConceptKey, per concept_type
        self._reverse: Dict[str, Dict[str, str]] = {}
        for concept_type, keymap in self._data.items():
            self._reverse[concept_type] = {}
            if not isinstance(keymap, dict): continue
            for concept_key, phrasings in keymap.items():
                if concept_key.startswith("_"): continue
                for phrasing in phrasings:
                    self._reverse[concept_type][phrasing.strip().lower()] = concept_key

    def lookup(self, concept_type: str, user_value: str) -> Optional[str]:
        """Return the canonical ConceptKey for a user phrasing, or None."""
        if concept_type not in self._reverse: return None
        return self._reverse[concept_type].get(user_value.strip().lower())

    def candidates(self, concept_type: str, user_value: str, threshold: float = 0.86) -> List[str]:
        """Fuzzy lookup: return ConceptKeys whose phrasings are similar to user_value.
        Used by value_resolver when exact match misses."""
        import difflib
        if concept_type not in self._reverse: return []
        needle = user_value.strip().lower()
        if not needle: return []
        scored: Dict[str, float] = {}
        for phrasing, concept_key in self._reverse[concept_type].items():
            score = difflib.SequenceMatcher(None, needle, phrasing).ratio()
            if score > scored.get(concept_key, 0.0):
                scored[concept_key] = score
        above = {k: v for k, v in scored.items() if v >= threshold}
        if not above: return []
        if len(above) == 1: return [next(iter(above))]
        ranked = sorted(above.items(), key=lambda kv: kv[1], reverse=True)
        if ranked[0][1] - ranked[1][1] >= 0.05:
            return [ranked[0][0]]
        return [k for k, _ in ranked]

    def concept_types(self) -> List[str]:
        return list(self._data.keys())

# ── Injection prompt builder (FULL mode) ──────────────────────────────────────

def build_injection_prompt(
    branch: BranchVocab,
    concept_types: Optional[List[str]] = None,
    max_values_per_concept: Optional[int] = None,
) -> str:
    """
    Build a compact vocabulary block to inject into the model's system prompt
    (FULL mode — for the v28 vocab-aware retrain). The model uses these EXACT
    real literals while generating SQL.

    Returns a string like:
        This branch's real master-data values (use these EXACT names, do not invent):
        - Classes: PreKG, LKG, UKG, I, II, III, IV, V, VI, VII, VIII, IX, X, XI, XII
        - Sections: All, BRAINY, EXPERT, FOUNDATION, INTELLIGENT, TALENTED
        - Subjects: MATHS, ENGLISH, SCIENCE, PHYSICS, CHEMISTRY
        - Enquiry statuses: Initiated, Updated, Completed, Dropped
        - Fee heads: Admission Fee, Tuition Fees, Transport Fee
        - Exam terms: Term I, Term II, EoY
        - Fee terms: Term 1, Term 2, Term 3
    """
    types = concept_types or [t for t in CONCEPT_TO_JSON_KEY if branch.values(t)]
    lines = ["This branch's real master-data values (use these EXACT names, do not invent or approximate):"]
    for t in types:
        vals = branch.values(t)
        if not vals: continue
        shown = vals
        suffix = ""
        if max_values_per_concept and len(vals) > max_values_per_concept:
            shown = vals[:max_values_per_concept]
            suffix = ", …"
        label = _CONCEPT_PROMPT_LABEL.get(t, t)
        lines.append(f"- {label}: {', '.join(shown)}{suffix}")
    return "\n".join(lines)

# ── Validate-and-substitute (STOPGAP mode) ────────────────────────────────────

@dataclass
class SubstitutionResult:
    concept_type: str
    user_value: str
    database_value: Optional[str] = None  # the branch's real literal to substitute
    matched_via: Optional[str] = None     # "exact_member" | "synonym_exact" | "synonym_fuzzy"
    needs_disambiguation: bool = False
    candidates: List[str] = None
    reason: Optional[str] = None

    def __post_init__(self):
        if self.candidates is None: self.candidates = []

def validate_and_substitute(
    concept_type: str,
    user_value: str,
    branch: BranchVocab,
    synonym_store: SynonymStore,
    fuzzy_threshold: float = 0.86,
) -> SubstitutionResult:
    """
    STOPGAP mode: validate the user's (or model's) value against the branch's
    real vocab, AND return the real literal to substitute back into the SQL.

    This fixes the F6 bug (round-2 §14b): the original VALIDATE stage validated
    but did NOT substitute, so a query with the wrong literal executed and
    returned empty rows as a confident ANSWER. This function returns the
    database_value to splice back into the SQL.
    """
    # 0. Direct exact-member check (fast path)
    if branch.is_member(concept_type, user_value):
        return SubstitutionResult(concept_type, user_value,
                                   database_value=user_value,
                                   matched_via="exact_member")

    # 1. Map phrasing → canonical ConceptKey via synonyms
    concept_key = synonym_store.lookup(concept_type, user_value)
    if concept_key is None:
        # Try fuzzy
        cands = synonym_store.candidates(concept_type, user_value, fuzzy_threshold)
        if len(cands) == 1:
            concept_key = cands[0]
        elif len(cands) >= 2:
            return SubstitutionResult(concept_type, user_value,
                                       needs_disambiguation=True,
                                       candidates=cands, reason="multiple_synonyms")

    if concept_key is not None:
        # 2. Find the ConceptKey's synonyms and test each against the branch vocab
        keymap = synonym_store._data.get(concept_type, {})
        if isinstance(keymap, dict) and concept_key in keymap:
            for term in keymap[concept_key]:
                if branch.is_member(concept_type, term):
                    return SubstitutionResult(concept_type, user_value,
                                               database_value=term,
                                               matched_via="synonym_exact")

    # 3. No exact member — case-insensitive near-miss on raw value
    ci_hits = branch.match_ci(concept_type, user_value)
    if len(ci_hits) == 1:
        # Single near-miss (e.g. "maths" vs branch "MATHS"): substitute it
        return SubstitutionResult(concept_type, user_value,
                                   database_value=ci_hits[0],
                                   matched_via="ci_near_miss")
    if len(ci_hits) >= 2:
        return SubstitutionResult(concept_type, user_value,
                                   needs_disambiguation=True,
                                   candidates=ci_hits, reason="multiple_ci")

    # 4. Nothing recognized — fail closed (return the branch's full vocab for disambiguation)
    return SubstitutionResult(concept_type, user_value,
                               needs_disambiguation=False,
                               candidates=list(branch.values(concept_type)),
                               reason="not_recognized")

# ── Context JSON parser (shared by both modes) ───────────────────────────────

def parse_context_json(payload) -> UserContextVocab:
    """Parse the ERP Context JSON (dict or str) into a UserContextVocab.
    Tolerant of missing concept arrays (a branch simply has empty vocab for that concept).
    Adds FeeTerms fallback when the API doesn't return it (queries TermMaster — but here
    we just leave it empty; the caller's fallback fills it)."""
    if isinstance(payload, str):
        payload = json.loads(payload)
    umd = (payload or {}).get("UserMasterDetails")
    if not isinstance(umd, dict):
        raise ValueError("Context JSON missing 'UserMasterDetails'.")
    uid = umd.get("Id")
    if uid is None:
        raise ValueError("Context JSON missing UserMasterDetails.Id.")
    ctx = UserContextVocab(
        user_id=int(uid),
        username=umd.get("UserName") or "",
        staff_name=umd.get("StaffName") or "",
        is_super_user=bool(umd.get("IsSuperUser", False)),
        target_database=umd.get("DBPrefix"),
        short_name=umd.get("ShortName"),
    )
    for b in umd.get("UserBranchDetails", []) or []:
        bid = b.get("ID")
        if bid is None: continue
        bid = int(bid)
        ays = []
        for ay in b.get("AcademicYears", []) or []:
            if ay.get("Id") is None: continue
            ays.append(AcademicYear(
                id=int(ay["Id"]),
                name=ay.get("Name") or "",
                is_current=bool(ay.get("IsCurrentYear", False)),
                previous_year_id=ay.get("PreviousAcademicYearID"),
            ))
        vocab: Dict[str, List[str]] = {}
        for concept_type, json_key in CONCEPT_TO_JSON_KEY.items():
            raw = b.get(json_key, []) or []
            if concept_type == "CLASS":
                objs = [c for c in raw if isinstance(c, dict) and c.get("Name")]
                objs.sort(key=lambda c: c.get("DisplayOrder", 1_000_000))
                vocab[concept_type] = [c["Name"] for c in objs]
            else:
                vocab[concept_type] = [str(v) for v in raw if v is not None and str(v) != ""]
        ctx.branches[bid] = BranchVocab(
            branch_id=bid, name=b.get("Name"),
            is_primary=bool(b.get("IsPrimary", False)),
            academic_years=ays, vocab=vocab,
        )
    return ctx

# ── FeeTerms fallback (when the API doesn't return them) ──────────────────────

def add_fee_terms_fallback(ctx: UserContextVocab, branch_id: int, fee_terms: List[str]) -> None:
    """If the real GetUserContext API doesn't return FeeTerms yet, call this with
    the result of `SELECT Name FROM TermMaster WHERE BranchID=? AND AcademicYearID=? AND IsDeleted=0`
    to populate the FEE_TERM vocab for the branch. Same pattern as the existing
    _merge_local_sections fallback in user_context_api.py."""
    branch = ctx.branch(branch_id)
    branch.vocab["FEE_TERM"] = list(fee_terms)

# ── Mode switch (config-driven) ───────────────────────────────────────────────

def build_system_prompt(
    base_prompt: str,
    branch: Optional[BranchVocab],
    inject_vocab: bool = False,
    concept_types: Optional[List[str]] = None,
) -> str:
    """
    Build the final system prompt for the LLM.

    Args:
        base_prompt: the frozen base prompt (must match training exactly — see
                     prepare_data.py FROZEN_SYSTEM_PROMPT).
        branch: the resolved BranchVocab for the user's selected branch.
        inject_vocab: STOPGAP mode (False, default) — append no vocab block;
                     rely on validate-and-substitute post-generation. Works
                     with the v27 model.
                     FULL mode (True) — append the vocab block. Requires the
                     v28 vocab-aware retrain.
        concept_types: which concepts to include (default: all with values).
    """
    if not inject_vocab or branch is None:
        return base_prompt
    injection = build_injection_prompt(branch, concept_types)
    return (base_prompt + "\n\n" + injection).strip()

# ── Self-test ──────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    # Test the synonym store + validate-and-substitute
    store = SynonymStore()
    print(f"Synonym store loaded. Concept types: {store.concept_types()}")
    print()

    # Simulate a branch that stores 'MATHS' uppercase
    branch = BranchVocab(
        branch_id=1, name="Test Branch",
        vocab={"SUBJECT": ["MATHS", "ENGLISH", "SCIENCE", "PHYSICS", "CHEMISTRY"]},
    )

    test_cases = [
        ("SUBJECT", "maths"),      # → MATHS (ci near-miss)
        ("SUBJECT", "Maths"),      # → MATHS (exact member after ci)
        ("SUBJECT", "Mathematics"),# → MATHS (synonym_exact)
        ("SUBJECT", "math"),       # → MATHS (synonym fuzzy)
        ("SUBJECT", "Geography"),  # → not_recognized (fail closed)
        ("CLASS", "8th"),          # → VIII (synonym_exact — but branch has no CLASS vocab here)
    ]
    print("=== validate_and_substitute tests ===")
    for ctype, val in test_cases:
        r = validate_and_substitute(ctype, val, branch, store)
        print(f"  {ctype} '{val}' → database_value={r.database_value!r}, "
              f"matched_via={r.matched_via}, disambiguate={r.needs_disambiguation}, "
              f"reason={r.reason}")

    print()
    print("=== build_injection_prompt (FULL mode) ===")
    full_branch = BranchVocab(
        branch_id=1, name="CHALO INTERNATIONAL SCHOOL",
        vocab={
            "CLASS": ["PreKG", "LKG", "UKG", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"],
            "SECTION": ["All", "BRAINY", "EXPERT", "FOUNDATION", "INTELLIGENT", "TALENTED"],
            "SUBJECT": ["MATHS", "ENGLISH", "SCIENCE", "PHYSICS", "CHEMISTRY"],
            "ENQUIRY_STATUS": ["Initiated", "Updated", "Completed", "Dropped"],
            "FEE_HEAD": ["Admission Fee", "Tuition Fees", "Transport Fee"],
            "EXAM_TERM": ["Term I", "Term II", "EoY"],
            "FEE_TERM": ["Term 1", "Term 2", "Term 3"],
        },
    )
    print(build_injection_prompt(full_branch))

    print()
    print("=== build_system_prompt (both modes) ===")
    BASE = ("You are a T-SQL expert for the ChaloSchools (V3_CHALO) school management "
            "database. Convert the following natural language question into a single, "
            "executable T-SQL query. Use @UserId to scope results to the branches that "
            "user has access to via UserAccountRoleDetails.")
    print("--- STOPGAP mode (inject_vocab=False) ---")
    print(build_system_prompt(BASE, full_branch, inject_vocab=False))
    print()
    print("--- FULL mode (inject_vocab=True) ---")
    print(build_system_prompt(BASE, full_branch, inject_vocab=True))

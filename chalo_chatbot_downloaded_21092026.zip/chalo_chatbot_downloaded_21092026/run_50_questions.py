#!/usr/bin/env python3
"""
run_50_questions.py — Benchmark 50 questions against the ChaloSchools AI Secretary
===================================================================================

WHAT THIS DOES:
  Sends 50 questions through YOUR FastAPI backend (port 8000) and captures
  the full output (SQL, trace, violations, rows, latency) for analysis.

  The output markdown file is what you paste back to me.

PREREQUISITES:
  1. The FastAPI backend running (your app):
     cd chalo_chatbot/backend && python -m uvicorn main:app --port 8000
  2. llama.cpp running at http://localhost:8080 (your trained model)
  3. The ExecuteQuery API reachable (for api_wrapper mode)
  4. Python 3.8+ with the `requests` package installed (pip install requests)

USAGE:
  python run_50_questions.py
  python run_50_questions.py --mode api_wrapper --branch 1
  python run_50_questions.py --start-from 15   (resume from Q15)
  python run_50_questions.py --context-json my_context.json

OUTPUT:
  output/50_questions_results.md   ← paste this back to me
  output/50_questions_results.json ← structured data
"""

import json, os, sys, time, argparse, requests
from datetime import datetime
from collections import defaultdict

# ═══════════════════════════════════════════════════════════════════════════════
# THE 50 QUESTIONS
# ═══════════════════════════════════════════════════════════════════════════════

QUESTIONS = [
    {"id": 1,  "module": "Fees",            "q": "What is the fee outstanding for the current term?"},
    {"id": 2,  "module": "Fees",            "q": "Show top 10 defaulters with the highest outstanding"},
    {"id": 3,  "module": "Fees",            "q": "Class-wise outstanding amount for Class 10 and Class 12"},
    {"id": 4,  "module": "Fees",            "q": "Section-wise fee collection for Class 9 this year"},
    {"id": 5,  "module": "Fees",            "q": "Term-wise fee collection breakdown"},
    {"id": 6,  "module": "Fees",            "q": "Bus fee outstanding for this term"},
    {"id": 7,  "module": "Fees",            "q": "Hostel fee collection this academic year"},
    {"id": 8,  "module": "Fees",            "q": "Fee head wise concession provided amount"},
    {"id": 9,  "module": "Fees",            "q": "How much fees were collected today?"},
    {"id": 10, "module": "Fees",            "q": "Total fee demand vs collected for this academic year"},
    {"id": 11, "module": "Students",        "q": "How many students are currently enrolled in Class 10 Section A?"},
    {"id": 12, "module": "Students",        "q": "Class-wise student count for all classes"},
    {"id": 13, "module": "Students",        "q": "Section-wise student strength for Class 8"},
    {"id": 14, "module": "Students",        "q": "How many new admissions this year?"},
    {"id": 15, "module": "Students",        "q": "Students who got TC this academic year"},
    {"id": 16, "module": "Students",        "q": "Which classes still have seats available?"},
    {"id": 17, "module": "Students",        "q": "Students with attendance below 75% this term"},
    {"id": 18, "module": "Students",        "q": "Class 10 Section B student list with roll numbers"},
    {"id": 19, "module": "Exams",           "q": "How many students passed maths in Term 1?"},
    {"id": 20, "module": "Exams",           "q": "Class-wise topper list for Term II"},
    {"id": 21, "module": "Exams",           "q": "Students who failed in any subject this term"},
    {"id": 22, "module": "Exams",           "q": "Subject-wise average marks for Term I"},
    {"id": 23, "module": "Exams",           "q": "Which subjects have mark entry pending?"},
    {"id": 24, "module": "Exams",           "q": "Report card published exam name and class wise count"},
    {"id": 25, "module": "Exams",           "q": "Top 5 students in Physics across all classes"},
    {"id": 26, "module": "Staff",           "q": "Who is the principal?"},
    {"id": 27, "module": "Staff",           "q": "Who is the class teacher for Class 8 Section A?"},
    {"id": 28, "module": "Staff",           "q": "Who teaches Mathematics in Class 9 Section B?"},
    {"id": 29, "module": "Staff",           "q": "How many staff are absent today?"},
    {"id": 30, "module": "Staff",           "q": "Staff type wise count"},
    {"id": 31, "module": "Staff",           "q": "Show staff turnover for this academic year"},
    {"id": 32, "module": "Admissions",      "q": "How many enquiries received so far?"},
    {"id": 33, "module": "Admissions",      "q": "Enquiry to admission conversion rate"},
    {"id": 34, "module": "Admissions",      "q": "Application status wise count"},
    {"id": 35, "module": "Admissions",      "q": "How many applications are pending review?"},
    {"id": 36, "module": "Admissions",      "q": "Class wise enquiry count this week"},
    {"id": 37, "module": "Transport",       "q": "How many students use transport?"},
    {"id": 38, "module": "Transport",       "q": "List all bus routes and their boarding points"},
    {"id": 39, "module": "Transport",       "q": "Bus fee outstanding by route"},
    {"id": 40, "module": "Transport",       "q": "How many vehicles are in the fleet?"},
    {"id": 41, "module": "Payroll",         "q": "Total payroll amount processed this month"},
    {"id": 42, "module": "Payroll",         "q": "Show the salary structure for employee ID 5"},
    {"id": 43, "module": "Payroll",         "q": "How many credit notes were generated this year?"},
    {"id": 44, "module": "Inventory",       "q": "What inventory items are running low in stock?"},
    {"id": 45, "module": "Inventory",       "q": "List all suppliers"},
    {"id": 46, "module": "Inventory",       "q": "Current stock level for all items"},
    {"id": 47, "module": "Communication",   "q": "How many SMS were sent today?"},
    {"id": 48, "module": "Communication",   "q": "Total notifications sent this academic year"},
    {"id": 49, "module": "Parent Feedback", "q": "Are there any unresolved parent complaints?"},
    {"id": 50, "module": "Parent Feedback", "q": "How many feedback tickets are open?"},
]

# ═══════════════════════════════════════════════════════════════════════════════
# SAMPLE CONTEXT JSON — replace with your real one via --context-json
# ═══════════════════════════════════════════════════════════════════════════════

SAMPLE_CONTEXT = {
    "UserMasterDetails": {
        "Id": 116, "UserName": "abav", "IsSuperUser": False, "DBPrefix": "V3_TestDatabase",
        "UserBranchDetails": [{
            "ID": 1, "Name": "CHALO INTERNATIONAL SCHOOL", "IsPrimary": True,
            "AcademicYears": [{"Id": 6, "Name": "2026-2027", "IsCurrentYear": True}],
            "Classes": [{"Name": c, "DisplayOrder": i+1} for i, c in enumerate(
                ["PreKG","LKG","UKG","I","II","III","IV","V","VI","VII","VIII","IX","X","XI","XII"])],
            "Sections": ["A","B","C","D","E"],
            "Subjects": ["Maths","English","Physics","Chemistry","Biology","Computer Science","Social Science","Tamil","Hindi"],
            "EnquiryStatuses": ["Initiated","Updated","Completed","Dropped"],
            "FeeHeads": ["Admission Fee","Tuition Fee","Transport Fee","Hostel Fee","Exam Fee"],
            "ExamTerms": ["Term I","Term II","Term III"],
            "FeeTerms": ["Term 1","Term 2","Term 3"],
        }]
    }
}

# ═══════════════════════════════════════════════════════════════════════════════
# SEND ONE QUESTION TO THE BACKEND
# ═══════════════════════════════════════════════════════════════════════════════

def send_question(backend_url, auth_token, question, context_json, branch_id, mode):
    """POST /api/chat and return the full JSON response."""
    payload = {
        "question": question,
        "context_json": context_json,
        "branch_id": branch_id,
        "mode": mode,
    }
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {auth_token}",
    }
    try:
        resp = requests.post(
            f"{backend_url}/api/chat",
            json=payload, headers=headers, timeout=180
        )
        if resp.status_code == 401:
            return {"outcome": "AUTH_ERROR", "message": "Invalid auth token", "sql": None,
                     "trace": [], "semantic_violations": [], "latency_ms": 0, "stage": "auth"}
        if resp.status_code == 429:
            print("  Rate limited — waiting 30s...")
            time.sleep(30)
            resp = requests.post(f"{backend_url}/api/chat", json=payload, headers=headers, timeout=180)
        if resp.status_code != 200:
            return {"outcome": "HTTP_ERROR", "message": f"HTTP {resp.status_code}: {resp.text[:200]}",
                     "sql": None, "trace": [], "semantic_violations": [], "latency_ms": 0, "stage": "http"}
        return resp.json()
    except requests.exceptions.Timeout:
        return {"outcome": "TIMEOUT", "message": "Request timed out (180s)", "sql": None,
                 "trace": [], "semantic_violations": [], "latency_ms": 180000, "stage": "timeout"}
    except requests.exceptions.ConnectionError as e:
        return {"outcome": "CONNECTION_ERROR", "message": str(e)[:200], "sql": None,
                 "trace": [], "semantic_violations": [], "latency_ms": 0, "stage": "connection"}
    except Exception as e:
        return {"outcome": "ERROR", "message": str(e)[:200], "sql": None,
                 "trace": [], "semantic_violations": [], "latency_ms": 0, "stage": "exception"}

# ═══════════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    ap = argparse.ArgumentParser(description="Benchmark 50 questions against the AI Secretary backend.")
    ap.add_argument("--backend-url", default="http://localhost:8000",
                    help="Your FastAPI backend URL (default: http://localhost:8000)")
    ap.add_argument("--auth-token", default="dev-token-please-change-in-prod",
                    help="The auth token (from your .env file)")
    ap.add_argument("--mode", default="api_wrapper", choices=["dry_run", "api_wrapper"],
                    help="api_wrapper = execute against DB (default); dry_run = preview SQL only")
    ap.add_argument("--branch", type=int, default=1, help="Branch ID (default: 1)")
    ap.add_argument("--out-dir", default="./output", help="Output directory (default: ./output)")
    ap.add_argument("--context-json", default=None,
                    help="Path to your Context JSON file (if not provided, uses embedded sample)")
    ap.add_argument("--start-from", type=int, default=1, help="Start from question N (for resuming)")
    ap.add_argument("--delay", type=float, default=1.0, help="Seconds between questions (default: 1.0)")
    args = ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)

    # Load the context JSON
    if args.context_json and os.path.exists(args.context_json):
        with open(args.context_json, encoding="utf-8") as f:
            context_json = json.load(f)
        print(f"Loaded context JSON from {args.context_json}")
    else:
        context_json = SAMPLE_CONTEXT
        print("Using embedded sample context JSON (pass --context-json for your real one)")

    # Health check
    print(f"\nChecking backend at {args.backend_url}...")
    try:
        health = requests.get(f"{args.backend_url}/api/health", timeout=10).json()
        print(f"  Health: {health.get('status')} | rules: {health.get('rules_count')} | version: {health.get('version')}")
        if health.get("status") != "ok":
            print("  WARNING: backend is not healthy. Proceeding anyway.")
    except Exception as e:
        print(f"  ERROR: cannot reach backend at {args.backend_url}: {e}")
        print(f"  Make sure the backend is running:")
        print(f"    cd chalo_chatbot/backend")
        print(f"    python -m uvicorn main:app --host 0.0.0.0 --port 8000")
        sys.exit(1)

    # Run the 50 questions
    print(f"\n{'='*80}")
    print(f"Probe run - 50 questions")
    print(f"User: {context_json.get('UserMasterDetails',{}).get('Id','?')}  Branch: {args.branch}")
    print(f"Backend: {args.backend_url}  Mode: {args.mode}")
    print(f"Started: {datetime.now().isoformat()}")
    print(f"{'='*80}")

    results = []
    for q_obj in QUESTIONS:
        if q_obj["id"] < args.start_from:
            continue

        qid = q_obj["id"]
        module = q_obj["module"]
        question = q_obj["q"]

        print(f"\n{'='*80}")
        print(f"S.No: {qid}   Module: {module}")
        print(f"Question: {question}")
        print(f"{'-'*80}")

        t0 = time.time()
        result = send_question(args.backend_url, args.auth_token, question,
                               context_json, args.branch, args.mode)
        elapsed = time.time() - t0

        outcome = result.get("outcome", "UNKNOWN")
        stage = result.get("stage", "")
        sql = result.get("sql") or ""
        trace = result.get("trace") or []
        violations = result.get("semantic_violations") or []
        message = result.get("message") or ""
        detail = result.get("detail") or ""
        latency = result.get("latency_ms") or (elapsed * 1000)
        rows = result.get("rows") or []
        columns = result.get("columns") or []
        total_count = result.get("total_row_count")
        sql_source = result.get("sql_source") or ""

        # Print the result (same format you've been pasting)
        print(f"Outcome: {outcome}")
        if sql_source:
            print(f"SQL source: {sql_source}")
        print()
        if sql:
            print(f"SQL:")
            print(f"  {sql}")
        print()
        if outcome == "ANSWER":
            if rows:
                print(f"Answer:")
                for row in rows[:5]:
                    print(f"  {row}")
                if total_count and total_count > 5:
                    print(f"  ... ({total_count} rows total, showing first 5)")
            else:
                print(f"Answer: (query succeeded, 0 rows returned)")
        elif message:
            print(f"Answer: {message}")
        print()

        if trace:
            print(f"Trace:")
            for t in trace:
                print(f"  {t}")
        print()

        if violations:
            print(f"Semantic violations ({len(violations)}):")
            for v in violations:
                print(f"  [{v.get('severity','?')}] {v.get('rule_id','?')}: {v.get('message','')}")
                if v.get("suggested_fix"):
                    print(f"    Fix: {v['suggested_fix']}")
            print()

        if outcome in ("CONNECTION_ERROR", "AUTH_ERROR"):
            print(f"ERROR: {message}")
            print(f"Stopping. Fix the issue and re-run with --start-from {qid}")
            break

        # Store the result
        results.append({
            "id": qid, "module": module, "question": question,
            "outcome": outcome, "stage": stage, "sql": sql, "sql_source": sql_source,
            "message": message, "detail": detail, "trace": trace,
            "semantic_violations": violations,
            "latency_ms": latency,
            "row_count": total_count if total_count is not None else len(rows),
            "columns": list(columns),
            "rows_sample": [list(r) for r in rows[:3]] if rows else [],
        })

        # Rate-limit delay
        if args.delay > 0 and qid < 50:
            time.sleep(args.delay)

    # ═══════════════════════════════════════════════════════════════════════════
    # SUMMARY
    # ═══════════════════════════════════════════════════════════════════════════

    print(f"\n{'='*80}")
    print(f"MODULE SUMMARY")
    print(f"{'='*80}")

    module_stats = defaultdict(lambda: {"total": 0, "answer": 0, "refused": 0, "error": 0})
    for r in results:
        m = r["module"]
        module_stats[m]["total"] += 1
        if r["outcome"] == "ANSWER":
            module_stats[m]["answer"] += 1
        elif "REFUSED" in r["outcome"] or "DISAMBIG" in r["outcome"]:
            module_stats[m]["refused"] += 1
        else:
            module_stats[m]["error"] += 1

    print(f"{'Module':<20} {'Total':>5} {'Answer':>7} {'Refused':>7} {'Error':>5}")
    print(f"{'-'*20} {'-'*5} {'-'*7} {'-'*7} {'-'*5}")
    for m in sorted(module_stats.keys()):
        s = module_stats[m]
        print(f"{m:<20} {s['total']:>5} {s['answer']:>7} {s['refused']:>7} {s['error']:>5}")

    total_answered = sum(1 for r in results if r["outcome"] == "ANSWER")
    total_refused = sum(1 for r in results if "REFUSED" in r["outcome"] or "DISAMBIG" in r["outcome"])
    total_error = sum(1 for r in results if r["outcome"] in ("ERROR", "TIMEOUT", "CONNECTION_ERROR", "HTTP_ERROR"))
    total_violations = sum(len(r.get("semantic_violations", [])) for r in results)
    avg_latency = sum(r.get("latency_ms", 0) for r in results) / max(len(results), 1)

    print(f"\n{'='*80}")
    print(f"OVERALL: {len(results)}/50 completed | {total_answered} answered | {total_refused} refused | {total_error} errors")
    print(f"Total violations: {total_violations} | Avg latency: {avg_latency:.0f}ms")
    print(f"Finished: {datetime.now().isoformat()}")
    print(f"{'='*80}")

    # ═══════════════════════════════════════════════════════════════════════════
    # WRITE OUTPUT FILES
    # ═══════════════════════════════════════════════════════════════════════════

    # JSON
    json_path = os.path.join(args.out_dir, "50_questions_results.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False, default=str)
    print(f"\nJSON: {json_path}")

    # Markdown (the file to paste back to me)
    md_path = os.path.join(args.out_dir, "50_questions_results.md")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(f"# 50 Questions - Benchmark Results\n\n")
        f.write(f"**Date:** {datetime.now().isoformat(timespec='seconds')}\n")
        f.write(f"**Backend:** {args.backend_url}\n")
        f.write(f"**Mode:** {args.mode} | **Branch:** {args.branch}\n")
        f.write(f"**Questions completed:** {len(results)}/50\n\n")
        f.write("---\n\n")

        # Summary
        f.write("## Summary\n\n")
        f.write(f"| Metric | Count |\n|---|---:|\n")
        f.write(f"| Answered | {total_answered} |\n")
        f.write(f"| Refused | {total_refused} |\n")
        f.write(f"| Errors | {total_error} |\n")
        f.write(f"| Total violations | {total_violations} |\n")
        f.write(f"| Avg latency | {avg_latency:.0f}ms |\n\n")

        # Module summary
        f.write("### Module breakdown\n\n")
        f.write("| Module | Total | Answer | Refused | Error |\n|---|---:|---:|---:|---:|\n")
        for m in sorted(module_stats.keys()):
            s = module_stats[m]
            f.write(f"| {m} | {s['total']} | {s['answer']} | {s['refused']} | {s['error']} |\n")
        f.write("\n---\n\n")

        # Per-question detail
        f.write("## Per-question results\n\n")
        for r in results:
            f.write(f"### Q{r['id']} [{r['module']}] - {r['question']}\n\n")
            f.write(f"**Outcome:** {r['outcome']} | **Stage:** {r.get('stage','')} | "
                    f"**Latency:** {r.get('latency_ms',0):.0f}ms | **Source:** {r.get('sql_source','')}\n\n")
            if r.get("message"):
                f.write(f"**Message:** {r['message']}\n\n")
            if r.get("sql"):
                f.write(f"**SQL:**\n```sql\n{r['sql']}\n```\n\n")
            if r.get("semantic_violations"):
                f.write("**Semantic violations:**\n")
                for v in r["semantic_violations"]:
                    f.write(f"- `{v.get('rule_id','?')}` [{v.get('severity','?')}]: {v.get('message','')}\n")
                    if v.get("suggested_fix"):
                        f.write(f"  - Fix: {v['suggested_fix']}\n")
                f.write("\n")
            if r.get("trace"):
                f.write("**Trace:**\n```\n")
                for t in r["trace"]:
                    f.write(f"  {t}\n")
                f.write("```\n\n")
            if r.get("rows_sample"):
                f.write(f"**Result sample ({len(r['rows_sample'])} of {r.get('row_count',0)} rows):**\n")
                f.write(f"Columns: {r.get('columns', [])}\n\n")
                for row in r["rows_sample"]:
                    f.write(f"  {row}\n")
                f.write("\n")
            f.write("---\n\n")

    print(f"Markdown: {md_path}")
    print(f"\n>> Paste the markdown file ({md_path}) back to me for analysis.")

if __name__ == "__main__":
    main()

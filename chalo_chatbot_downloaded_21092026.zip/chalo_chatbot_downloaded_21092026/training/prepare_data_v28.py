#!/usr/bin/env python3
"""
prepare_data_v28.py — Build the v28 training dataset (ERP codebase-analysis retrain)
====================================================================================

WHAT THIS IS
------------
The v28 training-data builder, per the plan documented in:
  - docs/INSTRUCTION_IMPROVEMENT.md  (the improved instruction, 7 gaps)
  - docs/PRODUCTION_TRACE_OBSERVATIONS.md  (§22: the ~130-220 new examples)
  - codebase_analysis/README.md  (Step 4: query templates -> training examples)
  - docs/SESSION_HANDOFF.md  (update 2026-09-04)

WHAT IT DOES
------------
  1. Reads the v27 base dataset (3,867 examples) AND the v28 additions
     (training_dataset_v28_additions.jsonl — drafted from the ERP's own
     query templates + the documented blindspots).
  2. De-duplicates (normalized question text) — additions WIN over v27
     (they are the corrected labels for the same questions).
  3. Validates BOTH halves with the 54-rule semantic engine:
       - the ADDITIONS must pass with ZERO violations (hard gate — these
         are new, hand-verified labels; any violation is a bug to fix);
       - the v27 base gets a full report (the known ~440 buggy labels are
         documented; cleaning them is a separate, tracked task).
       - SQL SYNTAX GATE (added 2026-09-04): every output must PARSE as
         valid T-SQL (sqlglot, dialect tsql). Pattern rules cannot see a
         missing AND or a double WHERE — the owner's local SSMS test of the
         smoke file caught 39 such labels in the v28 additions (all fixed
         the same day; the v27 base parsed 100% clean). The additions must
         parse with ZERO failures (hard gate); the base is parse-reported
         without blocking (frozen artifact, cleanup tracked).
  4. Applies the IMPROVED v28 instruction (below) to every example.
  5. Shuffles (seeded) and splits 92% / 8% into train/val.
  6. Writes train_v28.jsonl + val_v28.jsonl + DATASET_VERSION_V28.txt.

THEN (manual steps, per docs/INSTRUCTION_IMPROVEMENT.md §5)
-----------------------------------------------------------
  - Upload train_v28.jsonl + val_v28.jsonl to Kaggle.
  - Run training/finetune_qwen25coder_TRAIN_KAGGLE_v27.ipynb with:
      DATASET = train_v28/val_v28, MAX_SEQ_LENGTH = 2560, r = 16,
      lora_dropout = 0.05, lr = 1e-4, warmup_steps = 35, epochs = 2
  - Export GGUF via the Colab notebook (q5_k_m or q8_0).
  - Re-run the 50-question benchmark: v25 50% mismatch -> v27 18% ->
    v28 target < 5%.

Usage:
  python prepare_data_v28.py                  # full build (gates the additions)
  python prepare_data_v28.py --report-only    # validate only, no split
"""
import json
import os
import re
import sys
import random
import argparse
import csv

try:
    import sqlglot
except ImportError:
    sys.exit("sqlglot is REQUIRED for the syntax gate: pip install sqlglot")

HERE = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(HERE)
SEMVAL = os.path.join(PROJECT_ROOT, "semantic_validation")
REF_INPUTS = os.path.join(SEMVAL, "reference_inputs")

V27_SOURCE = os.path.join(REF_INPUTS, "training_dataset_final_v27.jsonl")
V28_ADDITIONS = os.path.join(REF_INPUTS, "training_dataset_v28_additions.jsonl")
COMBINED_OUT = os.path.join(REF_INPUTS, "training_dataset_final_v28.jsonl")
TRAIN_OUT = os.path.join(HERE, "train_v28.jsonl")
VAL_OUT = os.path.join(HERE, "val_v28.jsonl")
VERSION_OUT = os.path.join(HERE, "DATASET_VERSION_V28.txt")
REPORT_DIR = os.path.join(SEMVAL, "validation_reports", "v28")

VAL_FRACTION = 0.08
SEED = 42

# ── The improved v28 instruction ─────────────────────────────────────────────
# Frozen for v28: EVERY v28 training example carries this exact text in its
# `instruction` field, and the v28 runtime prompt must lead with the same text
# (pipeline/schema_knowledge.py FROZEN_V27_PROMPT is replaced by this after
# the v28 model lands). Based on docs/INSTRUCTION_IMPROVEMENT.md §4, refined
# with the ERP codebase-analysis findings (2026-09-04):
#   - the academic year resolves via the Branch_Academic_Details date window
#     (per-branch year IDs — a single hardcoded year or YEAR(GETDATE()) is
#     always wrong; this matches the v27 label style and STUD-004)
#   - ChequeStatus full enum (1-5), StaffStatus, IsClassTeacher
#   - the hallucination traps that produced the worst v27 benchmark failures
V28_INSTRUCTION = (
    "You are a T-SQL expert for the ChaloSchools (V3_CHALO) school management "
    "database. Convert the user's natural-language question into a single, "
    "executable T-SQL SELECT query.\n\n"
    "SECURITY (always):\n"
    "- Scope every query to the user's branches: BranchID IN (SELECT BranchID "
    "FROM UserAccountRoleDetails WHERE UserID = @UserId AND (@SelectedBranchId "
    "IS NULL OR BranchID = @SelectedBranchId) UNION SELECT ID FROM BranchMaster "
    "WHERE EXISTS (SELECT 1 FROM UserAccountMaster WHERE ID = @UserId AND "
    "IsSuperUser = 1) AND (@SelectedBranchId IS NULL OR ID = @SelectedBranchId) "
    "AND (IsDeleted IS NULL OR IsDeleted = 0)).\n"
    "- Current academic year: AcademicYearID IN (SELECT Id FROM "
    "Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date "
    "AND Branch_Id IN (<the same branch scoping>)). Never hardcode a year and "
    "never use YEAR(GETDATE()).\n\n"
    "TWO TERM CONCEPTS:\n"
    "- FEE terms: TermMaster (StartingDate, EndingDate). Fee tables join "
    "Term_ID -> TermMaster.ID.\n"
    "- EXAM terms: ExamTermMaster (StartDate, EndDate, Deleted). Exam tables "
    "join TermID -> ExamTermMaster.ID.\n"
    "- Never mix them.\n\n"
    "OUTSTANDING FORMULA (fee ledger, FeesInformationStudentDetail):\n"
    "ISNULL(Amount,0) - ISNULL(Concession_Amt,0) - ISNULL(Paid_Amt,0) - "
    "ISNULL(Lien_Amount,0), with IsIncludedInLumpSum = 0 AND IsDonation = 0.\n\n"
    "ALWAYS FILTER:\n"
    "- Active students: (IsTCIssued = 0 OR IsTCIssued IS NULL) on "
    "StudentAcademicDetail (class/section/year live there, NOT on Student_Master).\n"
    "- Valid receipts: ChequeStatus_ID IN (1,2) (3=bounced, 4=cancelled, "
    "5=stopped). Use FeesCollection.Receipt_Amt for amounts.\n"
    "- Active staff: StaffStatus_ID = 1. Staff names are Staff_FirstName / "
    "Staff_LastName. Class teacher = SubjectAllocation_Master.IsClassTeacher = 1.\n"
    "- Soft deletes: (IsDeleted = 0 OR IsDeleted IS NULL); ExamTermMaster uses "
    "Deleted, not IsDeleted.\n\n"
    "KNOWN TRAPS: BusFeeStrucure is misspelled (no second 't'). ClassMaster's "
    "name column is Name. Fee-head answers must JOIN Fees_Master for the name. "
    "Messages sent = SMSAuditTrail; feedback = FeedbackTicket; enquiries = "
    "GeneralCallRegister; staff lists = Staff_Master (EmployeeMaster is "
    "payroll/bank only). 'Attendance not marked' = NOT EXISTS. Principal = "
    "BranchMaster.Principal.\n\n"
    "OUTPUT: only the T-SQL query — no markdown fences, no explanation, no "
    "trailing semicolon. A single SELECT (or WITH ... SELECT). If the question "
    "is not about school data or asks for a write operation, output a SELECT "
    "returning a single Message column with a short refusal."
)


def _norm(text: str) -> str:
    """Normalize a question for de-duplication (lowercase, strip punctuation/ws)."""
    return re.sub(r"[^a-z0-9 ]+", " ", text.lower()).strip()


def load_jsonl(path):
    if not os.path.exists(path):
        raise FileNotFoundError(f"Can't find {path}")
    recs = []
    with open(path, encoding="utf-8") as f:
        for i, line in enumerate(f, 1):
            line = line.strip()
            if not line: continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError as e:
                raise ValueError(f"{path} line {i} is not valid JSON: {e}")
            if "input" not in rec or "output" not in rec:
                raise ValueError(f"{path} line {i} missing 'input'/'output'")
            recs.append({"input": rec["input"], "output": rec["output"]})
    return recs


def validate(pairs, engine):
    violations_by_example = {}
    rule_counts = {}
    high = total = 0
    for i, p in enumerate(pairs):
        vs = engine(p["output"], p["input"])
        if vs:
            violations_by_example[i] = vs
            for v in vs:
                total += 1
                if v.severity == "HIGH": high += 1
                rule_counts[v.rule_id] = rule_counts.get(v.rule_id, 0) + 1
    return violations_by_example, {
        "total": len(pairs), "flagged": len(violations_by_example),
        "high": high, "total_violations": total, "rule_counts": rule_counts,
    }


def parse_gate(pairs):
    """Return (n_failures, [(index, question, first_error_line), ...])."""
    fails = []
    for i, p in enumerate(pairs):
        try:
            sqlglot.parse_one(p["output"], read="tsql")
        except Exception as e:
            fails.append((i, p["input"], str(e).splitlines()[0]))
    return len(fails), fails


def write_report(violations_by_example, pairs, summary, path_csv, path_md, label):
    os.makedirs(os.path.dirname(path_csv), exist_ok=True)
    with open(path_csv, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["example_index", "input", "rule_id", "severity", "message", "suggested_fix"])
        for idx, vs in violations_by_example.items():
            for v in vs:
                w.writerow([idx, pairs[idx]["input"][:120], v.rule_id, v.severity,
                            v.message, v.suggested_fix])
    with open(path_md, "w", encoding="utf-8") as f:
        f.write(f"# v28 validation report — {label}\n\n")
        f.write(f"**Examples:** {summary['total']}\n**Flagged:** {summary['flagged']} "
                f"({summary['flagged']*100/max(1,summary['total']):.1f}%)\n"
                f"**HIGH:** {summary['high']}\n**Violations:** {summary['total_violations']}\n\n")
        f.write("| Rule | Count |\n|---|---:|\n")
        for rid, n in sorted(summary["rule_counts"].items(), key=lambda x: -x[1]):
            f.write(f"| `{rid}` | {n} |\n")


def main():
    ap = argparse.ArgumentParser(description="Build the v28 training dataset.")
    ap.add_argument("--report-only", action="store_true",
                    help="Validate + write reports; do not produce train/val.")
    args = ap.parse_args()

    # engine = the SAME 54-rule engine the runtime uses (synced copy in
    # semantic_validation/ — one engine, two entry points).
    sys.path.insert(0, SEMVAL)
    from semantic_rules import check_sql, rule_count

    print(f"Rules engine: {rule_count()} rules")
    base = load_jsonl(V27_SOURCE)
    print(f"v27 base:     {len(base)} examples  ({V27_SOURCE})")
    additions = load_jsonl(V28_ADDITIONS)
    print(f"v28 additions:{len(additions)} examples  ({V28_ADDITIONS})")

    # ── Hard gate: the additions must be CLEAN ──
    add_v, add_s = validate(additions, check_sql)
    print(f"\nAdditions validation: {add_s['flagged']} flagged / {add_s['total']} "
          f"({add_s['flagged']*100/max(1,add_s['total']):.1f}%), "
          f"{add_s['high']} HIGH, {add_s['total_violations']} total")
    write_report(add_v, additions, add_s,
                 os.path.join(REPORT_DIR, "additions_violations.csv"),
                 os.path.join(REPORT_DIR, "additions_summary.md"), "v28 additions")
    if add_s["total_violations"] > 0:
        print("\nGATE FAILED: the v28 additions contain violations.")
        print("These are hand-verified labels — fix them (see the report) instead of")
        print("training on them. Nothing was written.")
        sys.exit(1)
    print("GATE PASSED: additions are clean (0 violations).")

    # ── Hard gate #2: the additions must PARSE as valid T-SQL ──
    n_add_parse, add_parse_fails = parse_gate(additions)
    if n_add_parse:
        print(f"\nSYNTAX GATE FAILED: {n_add_parse} addition(s) do not parse as T-SQL:")
        for i, q, err in add_parse_fails[:20]:
            print(f"  [{i+1}] {q[:60]} :: {err}")
        print("A query that does not parse cannot run — the model would learn a broken")
        print("label. Fix the additions (regenerate via the v28 generator) and re-run.")
        sys.exit(1)
    print("SYNTAX GATE PASSED: all additions parse as valid T-SQL.")

    n_base_parse, base_parse_fails = parse_gate(base)
    if n_base_parse:
        print(f"\nv27 base parse check: {n_base_parse} failure(s) (reported, non-blocking")
        print("— the base is frozen; broken labels are tracked for cleanup):")
        for i, q, err in base_parse_fails[:20]:
            print(f"  [{i+1}] {q[:60]} :: {err}")
    else:
        print("v27 base parse check: 0 failures (all 3,867 labels parse as T-SQL).")

    # ── v27 base report (documented buggy labels; cleanup is a separate task) ──
    base_v, base_s = validate(base, check_sql)
    print(f"\nv27 base validation: {base_s['flagged']} flagged ({base_s['flagged']*100/max(1,base_s['total']):.1f}%), "
          f"{base_s['high']} HIGH — the KNOWN buggy-label set (cleanup tracked separately).")
    write_report(base_v, base, base_s,
                 os.path.join(REPORT_DIR, "v27_base_violations.csv"),
                 os.path.join(REPORT_DIR, "v27_base_summary.md"), "v27 base (carried into v28)")

    # ── Merge: additions WIN on duplicate questions (corrected labels) ──
    seen = {}
    order = []
    for p in base + additions:
        k = _norm(p["input"])
        if k in seen:
            seen[k]["output"] = p["output"]  # corrected label overwrites
        else:
            seen[k] = dict(p)
            order.append(k)
    merged = [seen[k] for k in order]
    replaced = len(base) + len(additions) - len(merged)
    print(f"\nMerged: {len(merged)} unique examples ({replaced} v27 labels replaced "
          f"by corrected v28 additions)")

    # ── Apply the v28 instruction ──
    for p in merged:
        p["instruction"] = V28_INSTRUCTION

    # ── Write the combined dataset (source of truth for v28) ──
    with open(COMBINED_OUT, "w", encoding="utf-8") as f:
        for p in merged:
            f.write(json.dumps(p, ensure_ascii=False) + "\n")
    print(f"Combined dataset -> {COMBINED_OUT}")

    if args.report_only:
        print("\n--report-only: reports written. No train/val split produced.")
        return

    # ── Split ──
    random.seed(SEED)
    pairs = list(merged)
    random.shuffle(pairs)
    n_val = max(1, int(len(pairs) * VAL_FRACTION))
    val, train = pairs[:n_val], pairs[n_val:]
    with open(TRAIN_OUT, "w", encoding="utf-8") as f:
        for p in train:
            f.write(json.dumps(p, ensure_ascii=False) + "\n")
    with open(VAL_OUT, "w", encoding="utf-8") as f:
        for p in val:
            f.write(json.dumps(p, ensure_ascii=False) + "\n")

    est_tokens = len(V28_INSTRUCTION) // 4
    with open(VERSION_OUT, "w", encoding="utf-8") as f:
        f.write("DATASET_VERSION=v28\n")
        f.write(f"BASE_SOURCE={V27_SOURCE}\n")
        f.write(f"ADDITIONS_SOURCE={V28_ADDITIONS}\n")
        f.write(f"COMBINED={COMBINED_OUT}\n")
        f.write(f"TOTAL_PAIRS={len(pairs)}\n")
        f.write(f"TRAIN_PAIRS={len(train)}\n")
        f.write(f"VAL_PAIRS={len(val)}\n")
        f.write(f"V27_REPLACED_BY_ADDITIONS={replaced}\n")
        f.write(f"RULES_ENGINE={rule_count()}\n")
        f.write(f"ADDITIONS_FLAGGED={add_s['flagged']} (gate: 0 required)\n")
        f.write(f"BASE_FLAGGED={base_s['flagged']} (known buggy labels, cleanup tracked)\n")
        f.write(f"PARSE_GATE=sqlglot tsql\n")
        f.write(f"ADDITIONS_PARSE_FAILURES={n_add_parse} (gate: 0 required)\n")
        f.write(f"BASE_PARSE_FAILURES={n_base_parse} (frozen base, reported)\n")
        f.write(f"SYNTAX_FIX_2026_09_04=39 addition labels repaired (missing AND x36, double WHERE x3) after the owner's SSMS smoke test caught them\n")
        f.write(f"SEED={SEED}\n")
        f.write(f"INSTRUCTION_CHARS={len(V28_INSTRUCTION)} (~{est_tokens} tokens)\n")
    print(f"\nTrain: {len(train)} -> {TRAIN_OUT}")
    print(f"Val:   {len(val)} -> {VAL_OUT}")
    print(f"Version record -> {VERSION_OUT}")
    print(f"\nNEXT: upload train_v28/val_v28 to Kaggle; MAX_SEQ_LENGTH=2560, r=16,")
    print("dropout=0.05, lr=1e-4, warmup=35, epochs=2 (per INSTRUCTION_IMPROVEMENT §5).")


if __name__ == "__main__":
    main()

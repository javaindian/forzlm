# Training — Model Fine-Tuning

This folder contains everything you need to fine-tune the Qwen 2.5 Coder 7B model that powers the AI Secretary.

> **Current version: v28** (2026-09-04). The v28 dataset is **execution-verified**: all 4,034
> question→SQL pairs ran clean on the owner's local SQL Server before training. Use the **v28**
> files below. The v27 files are kept only as the previous-version reference.

## Files

| File | What it is |
|------|------------|
| `train_v28.jsonl` | ★ **The v28 training split — 3,712 examples** (upload this to Kaggle) |
| `val_v28.jsonl` | ★ **The v28 validation split — 322 examples** (upload this to Kaggle) |
| `DATASET_VERSION_V28.txt` | Provenance card: sources, counts, gates, seed, instruction length |
| `prepare_data_v28.py` | Builds the v28 dataset (54-rule semantic gate + sqlglot parse gate — HARD gates) |
| `finetune_qwen25coder_TRAIN_KAGGLE_v28.ipynb` | ★ **Kaggle notebook — Stage 1: fine-tune Qwen 2.5 Coder 7B on v28** |
| `finetune_qwen25coder_GGUF_EXPORT_COLAB_v28.ipynb` | ★ **Colab notebook — Stage 2: export the v28 adapter to GGUF** |
| `finetune_qwen25coder_TRAIN_KAGGLE_v27.ipynb` | (previous) v27 training notebook — reference only |
| `finetune_qwen25coder_GGUF_EXPORT_COLAB_v27.ipynb` | (previous) v27 export notebook — reference only |
| `prepare_data_v27.py` | (previous) simpler v27 splitter, no validation gate |

## The training pipeline (v28)

```
[DONE] prepare_data_v28.py  →  Kaggle v28 notebook (Stage 1)  →  Colab v28 notebook (Stage 2)
        ↓                              ↓                                ↓
 train_v28.jsonl + val_v28.jsonl   LoRA adapter (~300MB)      qwen25coder_chaloschools_v28*.gguf
 (4,034 pairs, 0 gate failures,      download from              Q4_K_M, ~4-5 GB →
  0 execution errors on local DB)    Kaggle Output tab          scripts/start_llm.bat
```

## How to run (the short version)

1. **Prerequisites on Kaggle** (all free):
   - A Kaggle account with **phone verification** (required to enable GPUs)
   - GPU quota: ~30 h/week free — the v28 run needs **~1–1.5 h** on 1× T4
   - (Optional) a Hugging Face token, if you want to push the adapter to the Hub
     instead of downloading it from the Kaggle Output tab

2. **Upload the dataset:**
   - Kaggle → **Datasets → New Dataset**
   - Upload **`train_v28.jsonl`** and **`val_v28.jsonl`** (both from this folder)
   - Name it `chaloschools-sql-dataset-v28` (or any slug — then edit `TRAIN_PATH`/`VAL_PATH`
     in the notebook's paths cell to match)

3. **Fine-tune (Stage 1, Kaggle):**
   - Create a new Kaggle Notebook → File → Import `finetune_qwen25coder_TRAIN_KAGGLE_v28.ipynb`
   - Settings (right panel): **Accelerator → GPU T4 x2**, **Internet → On**
   - "+ Add Input" → attach your `chaloschools-sql-dataset-v28` dataset
   - Run all cells (~1–1.5 h). Hyperparameters unchanged from v27 except
     `MAX_SEQ_LENGTH = 3072` (v28's longest example is 9,111 chars; 2560 would truncate it)
   - Download the `qwen25coder_chaloschools_lora/` folder from the Output tab (~300 MB)

4. **Export to GGUF (Stage 2, Colab):**
   - Open `finetune_qwen25coder_GGUF_EXPORT_COLAB_v28.ipynb` in Google Colab (GPU runtime)
   - Upload your fine-tuned adapter folder
   - Run all cells (uses llama.cpp's `convert_hf_to_gguf.py` + `quantize`)
   - Download the `.gguf` file (Q4_K_M quantization, ~4–5 GB)

5. **Place the GGUF:**
   - Put the `.gguf` file where `scripts/start_llm.bat` expects it
     (default: `D:\models\qwen25coder_chaloschools_v27.gguf` — edit the .bat to point at your v28 file)
   - See `docs/diagrams/04-llm-setup.drawio` for a visual

6. **Verify the retrain:**
   - Re-run the 50 golden questions (`scripts/run_50.bat`) and compare against the
     pre-retrain baseline — target <5% mismatch

## Important notes

- **Recommended before training:** run the 50-golden-question benchmark **on the current v27
  model first** (`scripts/run_50.bat`) so you have a before/after score for the v28 retrain.
- **The v28 dataset passed every gate:** 54-rule semantic validation (0 violations in the
  additions), sqlglot parse (0 failures), and the owner's local SSMS execution run
  (4,034/4,034 clean, 2026-09-04). Labels are execution-verified before training — the exact
  failure mode the smoke test caught (39 broken labels) cannot recur silently.
- **The model needs ~8 GB VRAM** for training (Qwen 2.5 Coder 7B in 4-bit). Kaggle T4 (16 GB)
  is comfortable; the notebook deliberately uses only 1 of the 2 T4s (faster per Unsloth's own
  benchmarks).
- **The GGUF needs ~5 GB RAM** at inference time (Q4_K_M quantization). A modern laptop
  (8 GB+ RAM) is fine for local testing.
- **v28 carries the expanded instruction** (2,451 chars ≈ 612 tokens, the frozen system prompt
  with the knowledge block) on every row — the same prompt the deployed backend serves.

## See also

- `DATASET_VERSION_V28.txt` — provenance of every number above
- `docs/INSTRUCTION_IMPROVEMENT.md` — how to improve the frozen system prompt
- `../semantic_validation/README.md` — how to validate + clean the training dataset
- `../sql_tests/README.txt` — the SSMS execution kit that validated the labels
- `docs/diagrams/04-llm-setup.drawio` — visual flow of the LLM setup

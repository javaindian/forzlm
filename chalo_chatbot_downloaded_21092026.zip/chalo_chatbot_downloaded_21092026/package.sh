#!/usr/bin/env bash
# ============================================================
# package.sh — Create a clean, downloadable zip of the project
# ============================================================
#
# WHAT THIS DOES:
#   Creates chalo_chatbot.zip with everything you need to run
#   the AI Secretary, EXCLUDING junk (node_modules, __pycache__,
#   .next build cache, .pyc files, audit_trail.db runtime data).
#
# USAGE (Mac/Linux/Git Bash on Windows):
#   cd /home/z/my-project/chalo_chatbot
#   bash package.sh
#
# OUTPUT:
#   chalo_chatbot.zip  (in this folder)
#
# THEN:
#   Download chalo_chatbot.zip, unzip on any machine,
#   read README.md → STRUCTURE.md → follow Quick Start.
# ============================================================

set -e

cd "$(dirname "$0")"

echo "============================================================"
echo "  Packaging chalo_chatbot for clean download"
echo "============================================================"
echo ""

# Check zip is available
if ! command -v zip &> /dev/null; then
    echo "ERROR: 'zip' is not installed."
    echo "  Mac: built-in"
    echo "  Linux: sudo apt install zip  (or: sudo dnf install zip)"
    echo "  Windows: use package.bat instead, or install Git Bash"
    exit 1
fi

# Clean any previous zip
rm -f chalo_chatbot.zip

# What to exclude (these are all auto-generated or runtime data)
# NOTE: patterns are passed to zip as separate QUOTED arguments (a single
# -x flag, one pattern per arg). Do NOT build one unquoted $EXCLUDE_ARGS
# string — the shell would glob-expand `*/.venv/*` against THIS workspace
# and silently turn the excludes into literal paths (that bug shipped
# 1,959 .venv entries in the 2026-09-04 zip before it was caught).
EXCLUDES=(
    "chalo_chatbot/node_modules/*"    "chalo_chatbot/*node_modules"
    "chalo_chatbot/__pycache__/*"     "chalo_chatbot/*__pycache__*"
    "chalo_chatbot/.next/*"           "chalo_chatbot/*.next*"
    "*.pyc"                           # Python compiled files (anywhere)
    "*.DS_Store"                      # Mac junk (anywhere)
    "*Thumbs.db"                      # Windows junk (anywhere)
    "chalo_chatbot/.venv/*"           "chalo_chatbot/.venv"
    "chalo_chatbot/*/.venv/*"         "chalo_chatbot/*/.venv"
    "chalo_chatbot/venv/*"            "chalo_chatbot/*venv"
    "*audit_trail.db*"                # Runtime SQLite (db + journal, anywhere)
    "chalo_chatbot/.env"              # Secrets — never ship (but KEEP .env.example)
    "chalo_chatbot/*/.env"            "chalo_chatbot/*/.env/*"
    "chalo_chatbot/.git/*"            "chalo_chatbot/*/.git"
    "chalo_chatbot/chalo_chatbot.zip" # never zip the zip
)

echo "Creating chalo_chatbot.zip ..."
echo ""

# Create the zip (from the parent dir so the archive contains chalo_chatbot/)
# One -x flag; every pattern is a separately quoted argument — no glob expansion.
cd ..
zip -r chalo_chatbot/chalo_chatbot.zip chalo_chatbot \
    -x "${EXCLUDES[@]}" \
    -q

cd chalo_chatbot

# ---------------------------------------------------------------
# JUNK GATE — fail loudly if any excluded pattern leaked in.
# (The 2026-09-04 zip shipped 1,959 .venv entries silently; never again.)
# ---------------------------------------------------------------
LEAKS=$(unzip -l chalo_chatbot.zip | grep -cE "\.venv/|node_modules/|__pycache__|\.pyc$|\.next/|audit_trail\.db|/\.env$|\.git/" || true)
if [ "${LEAKS:-0}" -gt 0 ]; then
    echo ""
    echo "ERROR: junk detection gate failed — $LEAKS leaked entries found:"
    unzip -l chalo_chatbot.zip | grep -E "\.venv/|node_modules/|__pycache__|\.pyc$|\.next/|audit_trail\.db|/\.env$|\.git/" | head -10
    exit 1
fi
echo "Junk gate: 0 leaked entries (node_modules / .venv / __pycache__ / .pyc / .next / .env / .git / audit db)"

# Sanity gate: the must-ship files are actually in the zip
for MUST in \
    "chalo_chatbot/README.md" \
    "chalo_chatbot/START_HERE.bat" \
    "chalo_chatbot/frontend/chat.html" \
    "chalo_chatbot/backend/main.py" \
    "chalo_chatbot/backend/requirements.txt" \
    "chalo_chatbot/backend/.env.example" \
    "chalo_chatbot/pipeline/orchestrator.py" \
    "chalo_chatbot/training/train_v28.jsonl" \
    "chalo_chatbot/training/val_v28.jsonl" \
    "chalo_chatbot/training/finetune_qwen25coder_TRAIN_KAGGLE_v28.ipynb" \
    "chalo_chatbot/training/finetune_qwen25coder_GGUF_EXPORT_COLAB_v28.ipynb" \
    "chalo_chatbot/sql_tests/v28_run_all_single_file.sql" \
    "chalo_chatbot/docs/OCI_UBUNTU_QUICKSTART.md"; do
    if ! unzip -l chalo_chatbot.zip | grep -q "$MUST"; then
        echo "ERROR: must-ship file missing from zip: $MUST"
        exit 1
    fi
done
echo "Must-ship gate: 13/13 key files present (frontend, backend, pipeline, v28 training kit, sql_tests, OCI quickstart doc)"

echo ""
echo "============================================================"
echo "  DONE!"
echo "============================================================"
echo ""
echo "  Output: $(pwd)/chalo_chatbot.zip"
echo "  Size:   $(du -h chalo_chatbot.zip | cut -f1)"
echo ""
echo "  To use:"
echo "    1. Download chalo_chatbot.zip"
echo "    2. Unzip it on any machine"
echo "    3. Open README.md → follow Quick Start"
echo ""
echo "  What's inside (top level):"
unzip -l chalo_chatbot.zip | grep -E "^\s+\d+.*chalo_chatbot/[^/]+/?$" | head -20
echo ""

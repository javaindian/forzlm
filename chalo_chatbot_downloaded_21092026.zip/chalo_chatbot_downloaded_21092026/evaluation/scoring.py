"""
scoring.py — Score a model's output on a golden question
=============================================================================
4-axis scoring:
  - structural_pass: passes guardrail + alias + branch-scoping + semantic-rules (binary)
  - semantic_match: 3 = correct tables+joins+filters+formula, 2 = correct intent but
                    missing/extra filter, 1 = wrong table or wrong join, 0 = garbage/refusal
  - outcome_match: ANSWER with sane rows OR REFUSED with correct reason (binary)
  - latency_ms: time to produce output (numeric)
"""
from __future__ import annotations
import json, re, time
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "pipeline"))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from semantic_rules import check_sql, Violation

_FROM_JOIN = re.compile(r"\b(?:FROM|JOIN)\s+(?:\[?dbo\]?\.)?\[?(\w+)\]?", re.IGNORECASE)

def _tables(sql: str) -> set:
    return {m.group(1) for m in _FROM_JOIN.finditer(sql)}

@dataclass
class ScoreResult:
    question_id: int
    question: str
    module: str
    expected_outcome: str
    actual_outcome: str
    structural_pass: bool
    semantic_match: int          # 0-3
    outcome_match: bool
    latency_ms: float
    sql: Optional[str] = None
    violations: List[Dict] = field(default_factory=list)
    expected_tables: List[str] = field(default_factory=list)
    actual_tables: List[str] = field(default_factory=list)
    missing_tables: List[str] = field(default_factory=list)
    extra_tables: List[str] = field(default_factory=list)
    expected_filters: List[str] = field(default_factory=list)
    notes: str = ""

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items()}

def score_one(
    golden: dict,
    pipeline_result: dict,  # the orchestrator's PipelineResult as a dict
    latency_ms: float,
) -> ScoreResult:
    """Score one golden question against the pipeline's result."""
    qid = golden["id"]
    q = golden["question"]
    expected_outcome = golden["expected_outcome"]
    expected_tables = set(golden.get("expected_tables", []))
    expected_filters = golden.get("expected_filters", [])

    actual_outcome = str(pipeline_result.get("outcome", ""))
    sql = pipeline_result.get("sql", "") or ""
    actual_tables = _tables(sql) if sql else set()

    # Structural pass: the pipeline reached EXECUTE without REFUSED/ERROR
    # (or REFUSED with a structural reason). Use the trace + semantic violations.
    violations = check_sql(sql, q) if sql else []
    violations_list = [{"rule_id": v.rule_id, "severity": v.severity, "message": v.message} for v in violations]
    structural_pass = actual_outcome in ("ANSWER",) or (
        actual_outcome in ("REFUSED",) and not any(v.severity == "HIGH" and v.rule_id in (
            "MULTI-STMT", "WRITE-VERB", "SENSITIVE-TABLE", "SENSITIVE-COL"
        ) for v in violations)
    )

    # Semantic match: tables + filters
    missing_tables = sorted(expected_tables - actual_tables)
    extra_tables = sorted(actual_tables - expected_tables)
    if not sql or actual_outcome in ("ERROR",):
        semantic_match = 0
    elif actual_outcome == "REFUSED":
        # A correct refusal (sensitive/out-of-scope) is a semantic match
        if expected_outcome == "REFUSED":
            semantic_match = 3
        else:
            semantic_match = 0
    elif expected_outcome == "REFUSED":
        # Was supposed to refuse but answered — semantic failure
        semantic_match = 0
    else:
        # Check expected tables
        if missing_tables:
            semantic_match = 1  # wrong/missing tables
        else:
            # Check expected filters (rough — substring presence in SQL)
            filters_found = sum(1 for f in expected_filters if _filter_present(f, sql))
            filter_ratio = filters_found / max(len(expected_filters), 1)
            if filter_ratio >= 0.8:
                semantic_match = 3
            elif filter_ratio >= 0.5:
                semantic_match = 2
            else:
                semantic_match = 1

    # Outcome match: ANSWER when expected ANSWER (with sane rows), REFUSED when expected REFUSED
    if expected_outcome == "REFUSED":
        outcome_match = actual_outcome == "REFUSED"
    elif expected_outcome == "ANSWER":
        outcome_match = actual_outcome == "ANSWER"
    elif expected_outcome == "ANSWER or REFUSED":
        outcome_match = actual_outcome in ("ANSWER", "REFUSED")
    else:
        outcome_match = False

    return ScoreResult(
        question_id=qid, question=q, module=golden.get("module", "?"),
        expected_outcome=expected_outcome, actual_outcome=actual_outcome,
        structural_pass=structural_pass, semantic_match=semantic_match,
        outcome_match=outcome_match, latency_ms=latency_ms,
        sql=sql, violations=violations_list,
        expected_tables=sorted(expected_tables), actual_tables=sorted(actual_tables),
        missing_tables=missing_tables, extra_tables=extra_tables,
        expected_filters=expected_filters, notes=golden.get("notes", ""),
    )

def _filter_present(filter_spec: str, sql: str) -> bool:
    """Rough check: is the filter's key tokens present in the SQL?
    filter_spec is a human-readable description like 'Structure_Type IN (Academic,Optional)'."""
    s = sql.lower()
    f = filter_spec.lower()
    # Special cases
    if "lien" in f: return "lien" in s
    if "chequestatus" in f: return "chequestatus" in s
    if "receipt_amt" in f: return "receipt_amt" in s
    if "branch_academic_details" in f: return "branch_academic_details" in s
    if "getdate() between" in f and "startingdate" in f: return "startingdate" in s
    if "getdate() between" in f: return "getdate()" in s and "between" in s
    if "structure_type" in f: return "structure_type" in s
    if "isincludedinlumpsum" in f: return "isincludedinlumpsum" in s
    if "isbusfee" in f: return "isbusfee" in s
    if "ishostelfee" in f: return "ishostelfee" in s
    if "istcissued" in f: return "istcissued" in s
    if "isnewadmission" in f: return "isnewadmission" in s
    if "isactive" in f: return "isactive" in s
    if "isclassteacher" in f: return "isclassteacher" in s
    if "staffstatus_id" in f: return "staffstatus_id" in s
    if "academicyearid" in f: return "academicyearid" in s
    if "subjectid" in f and "join" in f: return "subjectid" in s or "subject_id" in s
    if "typeid" in f: return "typeid" in s
    if "transportrequired" in f: return "transportrequired" in s
    if "applicationno" in f: return "applicationno" in s
    if "group by" in f: return "group by" in s
    if "order by" in f: return "order by" in s
    if "select bm.principal" in f: return "principal" in s
    if "minmark from exam-config" in f: return "minmark" in s
    if "exam-term filter" in f: return ("examtermmaster" in s) or ("examtypemaster" in s)
    if "subject filter" in f: return "subject_master" in s or "sub.name" in s
    if "class filter" in f: return "classmaster" in s or "class_id" in s
    if "section filter" in f: return "sectionmaster" in s or "section_id" in s
    if "branch scoping" in f: return "useraccountroledetails" in s
    if "status = pending" in f: return "pending" in s
    if "status = open" in f: return "open" in s
    if "date = today" in f or "collectiondate = today" in f or "assigneddate = today" in f or "sentdate = today" in f:
        return "getdate()" in s or "cast(getdate()" in s
    if "in current month" in f: return "getdate()" in s or "month" in s
    if "month filter" in f: return "month" in s
    # default: substring
    return f[:30] in s

# ── Aggregate scoring ──────────────────────────────────────────────────────────

@dataclass
class AggregateScore:
    total: int
    structural_pass_count: int
    semantic_match_avg: float
    outcome_match_count: int
    outcome_match_pct: float
    latency_avg_ms: float
    latency_p95_ms: float
    by_module: Dict[str, dict]
    novel_score: dict  # scores for novel: true questions only

def aggregate(results: List[ScoreResult]) -> AggregateScore:
    total = len(results)
    if total == 0:
        return AggregateScore(0, 0, 0.0, 0, 0.0, 0.0, 0.0, {}, {})
    structural_pass = sum(1 for r in results if r.structural_pass)
    semantic_avg = sum(r.semantic_match for r in results) / total
    outcome_match = sum(1 for r in results if r.outcome_match)
    latencies = sorted(r.latency_ms for r in results)
    latency_avg = sum(latencies) / total
    latency_p95 = latencies[int(total * 0.95)] if total > 1 else latencies[0]

    by_module: Dict[str, dict] = {}
    for r in results:
        m = r.module
        if m not in by_module:
            by_module[m] = {"total": 0, "structural": 0, "semantic_sum": 0,
                             "outcome": 0, "latency_sum": 0}
        by_module[m]["total"] += 1
        by_module[m]["structural"] += int(r.structural_pass)
        by_module[m]["semantic_sum"] += r.semantic_match
        by_module[m]["outcome"] += int(r.outcome_match)
        by_module[m]["latency_sum"] += r.latency_ms
    for m, d in by_module.items():
        d["semantic_avg"] = d["semantic_sum"] / d["total"] if d["total"] else 0
        d["outcome_pct"] = d["outcome"] / d["total"] if d["total"] else 0
        d["latency_avg"] = d["latency_sum"] / d["total"] if d["total"] else 0

    # Novel-only scores (the pure-generalization signal)
    return AggregateScore(
        total=total,
        structural_pass_count=structural_pass,
        semantic_match_avg=semantic_avg,
        outcome_match_count=outcome_match,
        outcome_match_pct=outcome_match / total,
        latency_avg_ms=latency_avg,
        latency_p95_ms=latency_p95,
        by_module=by_module,
        novel_score={},  # filled by caller who knows which are novel
    )

if __name__ == "__main__":
    # Self-test: score a few mock results
    golden = json.load(open(os.path.join(os.path.dirname(__file__), "golden_questions.json")))
    qs = golden["questions"]

    # Mock a correct answer for Q1
    mock_result = {
        "outcome": "ANSWER",
        "sql": "SELECT SUM(Amount - ISNULL(Concession_Amt,0) - Paid_Amt - ISNULL(Lien_Amount,0)) AS Outstanding FROM FeesInformationStudentDetail f JOIN TermMaster tm ON tm.ID = f.Term_ID WHERE GETDATE() BETWEEN tm.StartingDate AND tm.EndingDate AND f.Structure_Type IN ('Academic','Optional') AND f.IsIncludedInLumpSum = 0 AND f.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE GETDATE() BETWEEN Start_Date AND End_Date) AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID=@UserId)",
    }
    r = score_one(qs[0], mock_result, 1500.0)
    print(f"Q1 (correct): structural={r.structural_pass}, semantic={r.semantic_match}/3, outcome={r.outcome_match}")
    print(f"  missing_tables={r.missing_tables}, extra_tables={r.extra_tables}")

    # Mock a wrong answer for Q1 (joins ExamTermMaster)
    mock_wrong = {
        "outcome": "ANSWER",
        "sql": "SELECT SUM(Amount-Paid_Amt) FROM FeesInformationStudentDetail f JOIN ExamTermMaster e ON e.ID = f.Term_ID WHERE GETDATE() BETWEEN e.StartDate AND e.EndDate AND f.BranchID IN (SELECT BranchID FROM UserAccountRoleDetails WHERE UserID=@UserId)",
    }
    r = score_one(qs[0], mock_wrong, 1200.0)
    print(f"Q1 (wrong): structural={r.structural_pass}, semantic={r.semantic_match}/3, outcome={r.outcome_match}")
    print(f"  violations: {[v['rule_id'] for v in r.violations]}")

    # Mock a refusal for Q46 (sensitive)
    mock_refuse = {"outcome": "REFUSED", "sql": "SELECT Password FROM UserAccountMaster"}
    r = score_one(qs[45], mock_refuse, 800.0)  # Q46
    print(f"Q46 (refused): structural={r.structural_pass}, semantic={r.semantic_match}/3, outcome={r.outcome_match}")

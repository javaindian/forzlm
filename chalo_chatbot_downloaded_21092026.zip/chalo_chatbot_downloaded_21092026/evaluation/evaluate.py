#!/usr/bin/env python3
"""
evaluate.py — Run the accuracy harness against a served model
=============================================================================
Loads golden_questions.json, runs each question through the full pipeline
(orchestrator with all stages), scores the result, writes a report.

Usage:
    python3 evaluate.py --model-url http://localhost:8080/v1/chat/completions \
                        --context-json /path/to/context.json \
                        --branch 1
    # → output/report.html, output/scores.csv, output/summary.md

The pipeline is the full reconstructed orchestrator (context → inject → generate
→ guardrail → alias → branch-scope → semantic-rules → validate → bind → execute).
For evaluation, EXECUTE runs in dry_run mode (no DB calls) — we measure the SQL
generation + all the gates, not the actual query results (which need a live DB).
"""
from __future__ import annotations
import json, csv, os, sys, time, argparse, html
from datetime import datetime
from typing import List

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "pipeline"))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from orchestrator import Orchestrator, Outcome, Stage
from context import UserContext, Branch, build_context_from_json
from vocab.inject import parse_context_json, SynonymStore
from value_resolver import ValueValidator
from llm_client import LlamaCppClient
import entity_extractor
from scoring import score_one, aggregate, AggregateScore

HERE = os.path.dirname(os.path.abspath(__file__))

def main():
    ap = argparse.ArgumentParser(description="Run the accuracy harness.")
    ap.add_argument("--model-url", default="http://localhost:8080/v1/chat/completions",
                    help="llama.cpp OpenAI-compatible endpoint")
    ap.add_argument("--context-json", required=True,
                    help="Path to a Context JSON file (the user's session context)")
    ap.add_argument("--branch", type=int, default=None,
                    help="Selected branch ID (if the user has multiple branches)")
    ap.add_argument("--golden", default=os.path.join(HERE, "golden_questions.json"))
    ap.add_argument("--out-dir", default=os.path.join(HERE, "output"))
    ap.add_argument("--synonyms", default=os.path.join(HERE, "..", "vocab", "synonyms.json"))
    ap.add_argument("--temperature", type=float, default=0.0)
    ap.add_argument("--max-tokens", type=int, default=512)
    ap.add_argument("--inject-vocab", action="store_true",
                    help="Enable vocab injection (FULL mode — requires v28 retrain)")
    ap.add_argument("--fast-paths", action="store_true",
                    help="Enable fast-paths (off by default — D1.9)")
    args = ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)

    # Load golden questions
    with open(args.golden, encoding="utf-8") as f:
        golden = json.load(f)
    questions = golden["questions"]
    print(f"Loaded {len(questions)} golden questions.")

    # Load Context JSON → UserContext
    with open(args.context_json, encoding="utf-8") as f:
        ctx_payload = json.load(f)
    ctx = build_context_from_json(ctx_payload)
    if args.branch is not None and args.branch != ctx.selected_branch_id:
        from context import ContextManager
        # Direct attribute update for the evaluation harness
        if args.branch in [b.branch_id for b in ctx.authorized_branches]:
            ctx.selected_branch_id = args.branch
        else:
            print(f"ERROR: branch {args.branch} not in user's authorized branches "
                  f"({[b.branch_id for b in ctx.authorized_branches]})")
            sys.exit(1)

    # Build the pipeline components
    llm = LlamaCppClient(url=args.model_url, temperature=args.temperature,
                          max_tokens=args.max_tokens)
    store = SynonymStore(args.synonyms)

    def llm_generate(system_prompt, question):
        return llm.generate(system_prompt, question)

    def make_validator(bv):
        return ValueValidator(bv, synonym_store=store)

    # Build a dry-run binder (no execution — we measure generation + gates only)
    from parameter_binder import ParameterBinderExecutor
    binder = ParameterBinderExecutor(endpoint_url="", target_database="",
                                       dry_run=True)

    orch = Orchestrator(
        llm_generate=llm_generate,
        binder=binder,
        mode="dry_run",
        fast_paths_enabled=args.fast_paths,
        semantic_rules_enabled=True,
        make_validator=make_validator,
        extract_values=entity_extractor.extract_values,
        base_system_prompt=(
            "You are a T-SQL expert for the ChaloSchools (V3_CHALO) school management "
            "database. Convert the following natural language question into a single, "
            "executable T-SQL query. Use @UserId (bound as a query parameter at runtime "
            "from the logged-in user's session) to scope results to the branches that "
            "user has access to via UserAccountRoleDetails."
        ),
        inject_vocab=args.inject_vocab,
    )

    # Run each golden question
    results = []
    print(f"\n{'='*70}")
    print(f"Running {len(questions)} questions against {args.model_url}")
    print(f"Branch: {ctx.selected_branch_id} | inject_vocab: {args.inject_vocab} | fast_paths: {args.fast_paths}")
    print(f"{'='*70}\n")

    for q in questions:
        t0 = time.time()
        try:
            pr = orch.run(q["question"], ctx)
            latency_ms = (time.time() - t0) * 1000
            # Convert PipelineResult to dict for the scorer
            pr_dict = {
                "outcome": str(pr.outcome).replace("Outcome.", ""),
                "sql": pr.sql or "",
                "stage": str(pr.stage).replace("Stage.", ""),
                "message": pr.message,
                "trace": pr.trace,
            }
        except Exception as e:
            latency_ms = (time.time() - t0) * 1000
            pr_dict = {"outcome": "ERROR", "sql": "", "stage": "execute",
                        "message": str(e), "trace": []}
        sr = score_one(q, pr_dict, latency_ms)
        results.append(sr)
        status = "✓" if sr.outcome_match else "✗"
        print(f"  {status} Q{sr.question_id:2d} [{sr.module:15}] sem={sr.semantic_match}/3 "
              f"struct={int(sr.structural_pass)} out={int(sr.outcome_match)} "
              f"{sr.latency_ms:6.0f}ms — {sr.question[:50]}")

    # Aggregate
    agg = aggregate(results)
    novel_results = [r for r, q in zip(results, questions) if q.get("novel")]
    novel_agg = aggregate(novel_results)

    # Write CSV
    csv_path = os.path.join(args.out_dir, "scores.csv")
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["id", "module", "novel", "question", "expected_outcome", "actual_outcome",
                    "structural_pass", "semantic_match", "outcome_match", "latency_ms",
                    "missing_tables", "extra_tables", "violations", "notes"])
        for sr, q in zip(results, questions):
            w.writerow([sr.question_id, sr.module, q.get("novel", False), sr.question,
                        sr.expected_outcome, sr.actual_outcome, int(sr.structural_pass),
                        sr.semantic_match, int(sr.outcome_match), round(sr.latency_ms, 0),
                        "|".join(sr.missing_tables), "|".join(sr.extra_tables),
                        "|".join(v["rule_id"] for v in sr.violations), sr.notes])

    # Write markdown summary
    md_path = os.path.join(args.out_dir, "summary.md")
    L = [
        f"# Accuracy Harness Report\n",
        f"**Model:** {args.model_url}\n",
        f"**Branch:** {ctx.selected_branch_id} | **inject_vocab:** {args.inject_vocab} | **fast_paths:** {args.fast_paths}\n",
        f"**Generated:** {datetime.now().isoformat(timespec='seconds')}\n",
        f"---\n",
        f"## Aggregate scores\n",
        f"- Total questions: **{agg.total}**",
        f"- Structural pass: **{agg.structural_pass_count}/{agg.total}** ({agg.structural_pass_count*100/agg.total:.1f}%)",
        f"- Semantic match avg: **{agg.semantic_match_avg:.2f}/3.0**",
        f"- Outcome match: **{agg.outcome_match_count}/{agg.total}** ({agg.outcome_match_pct*100:.1f}%)",
        f"- Latency avg: **{agg.latency_avg_ms:.0f}ms** | p95: **{agg.latency_p95_ms:.0f}ms**\n",
        f"## Novel-only scores (pure generalization — {len(novel_results)} questions)\n",
        f"- Structural pass: **{novel_agg.structural_pass_count}/{novel_agg.total}**",
        f"- Semantic match avg: **{novel_agg.semantic_match_avg:.2f}/3.0**",
        f"- Outcome match: **{novel_agg.outcome_match_count}/{novel_agg.total}** ({novel_agg.outcome_match_pct*100:.1f}%)\n",
        f"## By module\n",
        f"| Module | Total | Structural | Sem avg | Outcome % | Latency avg |",
        f"|---|---:|---:|---:|---:|---:|",
    ]
    for m, d in sorted(agg.by_module.items()):
        L.append(f"| {m} | {d['total']} | {d['structural']}/{d['total']} | "
                 f"{d['semantic_avg']:.2f} | {d['outcome_pct']*100:.0f}% | {d['latency_avg']:.0f}ms |")
    L.append("\n## Per-question results\n")
    L.append("| ID | Module | Q | Sem | Struct | Outcome | Latency |")
    L.append("|---:|---|---|---:|---:|---:|---:|")
    for sr in results:
        L.append(f"| {sr.question_id} | {sr.module} | {sr.question[:40]} | "
                 f"{sr.semantic_match}/3 | {int(sr.structural_pass)} | {int(sr.outcome_match)} | "
                 f"{sr.latency_ms:.0f}ms |")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write("\n".join(L))

    # Console summary
    print(f"\n{'='*70}")
    print(f"AGGREGATE: struct {agg.structural_pass_count}/{agg.total} | "
          f"sem {agg.semantic_match_avg:.2f}/3 | "
          f"outcome {agg.outcome_match_count}/{agg.total} | "
          f"latency {agg.latency_avg_ms:.0f}ms")
    print(f"NOVEL-ONLY: struct {novel_agg.structural_pass_count}/{novel_agg.total} | "
          f"sem {novel_agg.semantic_match_avg:.2f}/3 | "
          f"outcome {novel_agg.outcome_match_count}/{novel_agg.total}")
    print(f"\nArtifacts: {csv_path}, {md_path}")
    print(f"{'='*70}")

if __name__ == "__main__":
    main()

---
name: chalo-schools-persona
description: |
  Persona and project context for the ChaloSchools AI Secretary project. Use this skill whenever the user mentions ChaloSchools, the AI Secretary, the school chatbot, the ERP, fee outstanding, student queries, the pipeline, semantic rules, the LLM model, llama.cpp, Qwen, training data, branch scoping, ExecuteQuery, GetUserContext, or any work related to the ChaloSchools text-to-SQL chatbot system. Also trigger when the user mentions "my school ERP", "the chatbot", "the pipeline", "the model", "the rules engine", or references files like start_backend.bat, start_llm.bat, chat.html, audit.html, orchestrator.py, semantic_rules.py, or question_extractor.py.
---

# ChaloSchools AI Secretary — Persona & Project Context

## Who the user is

The user is the owner/operator of ChaloSchools, a school ERP platform with 15 modules. They are building an AI chatbot that lets school staff ask natural-language questions and get answers from the database.

**The user is NOT a techie.** Use plain English, explain WHY not just WHAT, give concrete examples, warn if something might break, lay out trade-offs honestly.

**Working style:** Wants honest assessments (will call out patch work), prefers root-cause fixes ("no workarounds henceforth"), uses Windows + npm + Python 3.11+, tests locally before OCI deployment, wants docs updated every time.

## Project overview

Text-to-SQL chatbot for ChaloSchools ERP. Status: end-to-end verified (StudentCount = 32). Lives at `D:\aisecretary-z\chalo_chatbot\` (Windows) or `/home/z/my-project/chalo_chatbot/` (dev).

## The 3 services

| Service | Port | Start command |
|---------|------|--------------|
| llama.cpp LLM (Qwen 2.5 Coder 7B, Q4_K_M) | 8080 | `scripts/start_llm.bat` |
| FastAPI backend (9 endpoints) | 8000 | `scripts/start_backend.bat` |
| Chat UI (standalone HTML) | — | `frontend/start_chat.bat` |

One-click: `START_HERE.bat`. User's paths pre-filled: `D:\llama-b6691\llama-server.exe`, `D:\ggufs\AISv27-qwen2.5-coder-7b-instruct.Q4_K_M.gguf`.

## Pipeline (9 stages)

CONTEXT → INJECT → EXTRACT (Option 1.5) → GENERATE → GUARDRAIL → VALIDATE → SEMANTIC (32 rules) → BIND → EXECUTE

## 3 security parameters

1. `@UserId` — from Context JSON (e.g. 116)
2. `@SelectedBranchId` — null = all authorized branches
3. `@AcademicYearID` — omitted in multi-branch mode (GETDATE() subquery handles per-branch)

## Critical config

- `use_inline_params=True` — school's API fails on repeated @placeholders (WORKAROUND, dev team needs to fix)
- API key: `5e8d1e96...` in `backend/.env` as `AI_SECRETARY_TENANT_KEYS`
- `CTX_SIZE=2560` in start_llm.bat — set for TRAINING (prevents silent truncation), can safely increase to 4096 for INFERENCE

## Dev team asks (PENDING)

1. Fix ExecuteQuery API (repeated @placeholders bug)
2. Fix GetUserContext API (Sections: [] — should return real section names)
3. SQL Profiler trace (optional, for codebase analysis)

## Pending features

1. Disclaimer in chat.html ("AI can make mistakes...")
2. LLM model selector dropdown (CLM 1.0 current, 2.0/3.0 disabled)
3. Show thinking process (configurable show/hide)
4. Standard reply for unanswerable questions (configurable)

## Known limitations

- v27 model ignores named sections (needs v28 retrain)
- Fast paths disabled (training label noise)
- CPU-only (15-35s per query; GPU would make it 1-3s)
- 7B model produces shallow code analysis (raw extracts are better)
- 3B model is NOT at par with 7B for complex queries (keep 7B, get GPU)

## User preferences (IMPORTANT)

1. **No workarounds** — fix root causes
2. **npm, not bun**
3. **Windows** — batch files must be pure ASCII, no unescaped parens/redirects/! in echo
4. **Plain English** — not a techie
5. **Honest assessments** — say if it's a patch
6. **Documentation** — update all docs every time code changes
7. **Pre-filled paths** — don't revert to placeholders

## Key files

| File | What |
|------|------|
| `backend/main.py` | FastAPI (9 endpoints, dotenv, use_inline_params, audit tenant) |
| `backend/security.py` | Auth, CORS, audit (target_database column) |
| `pipeline/orchestrator.py` | 9 stages, question extractor, TOP-N fix |
| `pipeline/semantic_rules.py` | 32-rule validation engine |
| `pipeline/question_extractor.py` | Option 1.5 (pre-LLM entity extraction) |
| `frontend/chat.html` | Chat UI (branch dropdown, 3 Settings fields) |
| `frontend/audit.html` | Audit viewer (Tenant, Export XLSX, Reset) |
| `codebase_analysis/` | Tribal knowledge extraction toolkit |
| `SESSION_RECORD.md` | Complete project record |

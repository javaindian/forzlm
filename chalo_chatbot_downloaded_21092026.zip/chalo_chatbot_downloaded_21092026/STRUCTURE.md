# Project Structure — ChaloSchools AI Secretary

This document shows the **complete folder tree** with a one-line description for every file. Use this as your map when downloading or navigating the codebase.

---

## Top-level layout

```
chalo_chatbot/
├── README.md                  ← START HERE — overview, quick start, architecture
├── START_HERE.bat             ← ★ ONE-CLICK STARTER (Windows) — opens all 3 services
├── STRUCTURE.md               ← THIS FILE — the full annotated tree
├── SESSION_RECORD.md          ← (added 2026-09-03) the complete project narrative — 16 sections, ~526 lines
├── run_50_questions.py        ← the 50-question benchmark script
├── context.json               ← sample Context JSON (for run_50.bat testing)
├── package.sh / package.bat   ← build a clean chalo_chatbot.zip for download
├── skills/                    ← (added 2026-09-03) in-project copy of the persona skill — may be absent if not bundled
│   └── chalo-chatbot-persona/SKILL.md   ← project-context skill that auto-triggers on ChaloSchools mentions
│
├── backend/                   ← The production API service (FastAPI, port 8000)
├── frontend/                  ← The user-facing UI (2 options: HTML or Next.js)
├── scripts/                   ← Windows launcher scripts (.bat) — all self-bootstrap
├── pipeline/                  ← The inference pipeline (17 Python modules)
├── vocab/                     ← The vocab/synonym engine
├── evaluation/                ← Accuracy test harness (50 golden questions)
├── training/                  ← Model fine-tuning (v28 notebooks + execution-verified dataset)
├── semantic_validation/      ← The training-data gate (5 files, ~5,000 LOC)
├── web/                       ← Static assets (screenshots)
└── docs/                      ← All documentation (.md, .pdf, .xlsx, .drawio)
```

---

## Detailed tree (every file described)

```
chalo_chatbot/
│
├── README.md                        — Overview, quick start, 3-service architecture
├── START_HERE.bat                   — ★ ONE-CLICK STARTER (Windows) — opens all 3 services
├── STRUCTURE.md                      — This file (the full annotated tree)
├── SESSION_RECORD.md                 — (added 2026-09-03) the complete project narrative — 16 sections, ~526 lines, ~27 KB
├── run_50_questions.py               — the 50-question benchmark script
├── context.json                      — sample Context JSON (for run_50.bat testing)
├── package.sh / package.bat          — build a clean chalo_chatbot.zip for download
│
├── skills/                          — (added 2026-09-03) IN-PROJECT COPY OF THE PERSONA SKILL (may be absent if not bundled)
│   └── chalo-chatbot-persona/
│       └── SKILL.md                    Project-context skill — auto-triggers on ChaloSchools mentions. Canonical copy at chalo-chatbot-persona/SKILL.md outside the package.
│
├── backend/                          — PRODUCTION API (FastAPI, port 8000)
│   ├── main.py                         FastAPI app: 9 endpoints (4 user + 5 admin/audit)
│   ├── security.py                     Bearer auth + CORS + rate limiting + audit
│   ├── requirements.txt                 Python deps (run: pip install -r requirements.txt)
│   ├── .env.example                     Env vars template (copy to .env — OPTIONAL, app uses dev defaults)
│   ├── feature_overrides.json          Admin-controlled feature flags (auto-chart, insights, etc.)
│   └── audit_trail.db                  SQLite audit log (auto-created on first run)
│
├── frontend/                         — THE USER-FACING UI (two options)
│   ├── README.md                       How to use the frontend (which option to pick)
│   ├── chat.html                       ★ OPTION A: standalone chat UI (open in browser, no build)
│   ├── audit.html                      OPTION A: standalone audit-trail viewer
│   ├── start_chat.bat                  OPTION A: Windows launcher for chat.html
│   └── nextjs-ui/                      OPTION B: full Next.js React app (requires npm install)
│       ├── package.json                Dependencies (Next.js 16, React, shadcn/ui, Prisma)
│       ├── next.config.ts              Next.js config
│       ├── tsconfig.json               TypeScript config
│       ├── tailwind.config.ts          Tailwind CSS config
│       ├── postcss.config.mjs          PostCSS config
│       ├── components.json             shadcn/ui component config
│       ├── next-env.d.ts               Next.js type declarations
│       ├── prisma/                     Prisma schema (SQLite)
│       ├── public/                     Static assets (logo, robots)
│       └── src/
│           ├── app/
│           │   ├── page.tsx              ★ The main chat page (React)
│           │   ├── layout.tsx            Root layout
│           │   ├── globals.css           Global styles
│           │   └── api/route.ts          API route
│           ├── components/ui/            50+ shadcn/ui components (button, card, dialog, ...)
│           ├── hooks/
│           │   ├── use-toast.ts          Toast notifications hook
│           │   └── use-mobile.ts         Mobile detection hook
│           └── lib/
│               ├── utils.ts              cn() helper + misc utils
│               └── db.ts                 Prisma client
│
├── scripts/                          — WINDOWS LAUNCHER SCRIPTS
│   ├── start_llm.bat                   Start llama.cpp LLM server (port 8080) — edit paths at top
│   ├── start_backend.bat               Start FastAPI backend (port 8000) — auto-finds ../backend
│   └── run_50.bat                      Run the 50-question benchmark — edit paths at top
│
├── pipeline/                         — THE INFERENCE PIPELINE (17 modules, ~6,000 LOC)
│   ├── orchestrator.py                 The conductor — runs all 11 stages in order
│   ├── semantic_rules.py               The 32-rule semantic validation engine
│   ├── context.py                      Loads + parses the user's Context JSON
│   ├── context_vocab.py                Vocabulary helpers for context fields
│   ├── llm_client.py                   HTTP client → llama-server (port 8080)
│   ├── guardrail.py                    Pre-LLM safety checks
│   ├── alias_scope_check.py            Checks that table/column aliases are in scope
│   ├── branch_scoping_gate.py          Branch-scoped access control (UserMasterDetails.BranchId)
│   ├── entity_extractor.py             Pulls entities (class, section, term) from the question
│   ├── value_resolver.py               Resolves entity values to DB IDs
│   ├── parameter_binder.py             Binds resolved values into the SQL template
│   ├── local_executor.py               Runs SQL against a local MS SQL Server (testing)
│   ├── api_executor.py                 Runs SQL via the school's ExecuteQuery ASMX API
│   ├── user_context_api.py             Fetches user context from the school's API
│   ├── concept_store.py                Stores concept definitions
│   ├── dataset_lookup.py               Looks up dataset references
│   └── template_lookups.py             Resolves SQL templates
│
├── vocab/                            — THE VOCAB/SYNONYM ENGINE
│   ├── inject.py                       STOPGAP + FULL modes, config-switchable
│   └── synonyms.json                  9 concept types, hand-curated synonyms
│
├── evaluation/                        — ACCURACY TEST HARNESS
│   ├── golden_questions.json           50 questions (20 novel, held out)
│   ├── scoring.py                      4-axis scoring (correctness, safety, latency, format)
│   ├── evaluate.py                     Run all 50 questions against a served model
│   └── sample_context.json             Sample Context JSON (runnable out of the box)
│
├── training/                         — MODEL FINE-TUNING (v28 current — execution-verified dataset)
│   ├── README.md                       How to use the training pipeline (v28 steps + Kaggle prerequisites)
│   ├── train_v28.jsonl                 ★ v28 TRAIN split — 3,712 examples (upload to Kaggle)
│   ├── val_v28.jsonl                   ★ v28 VAL split — 322 examples (upload to Kaggle)
│   ├── DATASET_VERSION_V28.txt         Provenance card (sources, counts, gates, seed)
│   ├── prepare_data_v28.py             Builds v28 (54-rule semantic gate + sqlglot parse gate — HARD gates)
│   ├── finetune_qwen25coder_TRAIN_KAGGLE_v28.ipynb    ★ Kaggle Stage 1 — fine-tune Qwen 2.5 Coder 7B on v28
│   ├── finetune_qwen25coder_GGUF_EXPORT_COLAB_v28.ipynb  ★ Colab Stage 2 — export the v28 adapter to GGUF
│   ├── prepare_data_v27.py             (previous) v27 splitter — reference only
│   ├── finetune_qwen25coder_TRAIN_KAGGLE_v27.ipynb    (previous) v27 notebook — reference only
│   └── finetune_qwen25coder_GGUF_EXPORT_COLAB_v27.ipynb  (previous) v27 notebook — reference only
│
├── semantic_validation/             — THE TRAINING-DATA GATE (~5,000 LOC)
│   ├── README.md                       How to validate + clean the training dataset
│   ├── semantic_rules.py               The 32-rule validation engine (synced with pipeline/)
│   ├── validate_dataset.py             Standalone validator → HTML + CSV + MD report
│   ├── prepare_data.py                  Gated prepare_data (refuses if HIGH-severity violations > 0)
│   ├── rules_catalog.json               Full 78-rule catalog
│   └── reference_inputs/               Bundled v27 dataset + schema + SPs

├── web/                              — STATIC ASSETS
│   └── screenshot_landing.png          Landing page screenshot
│
└── docs/                             — ALL DOCUMENTATION (24 files)
    ├── HOW_IT_WORKS.md                 Plain-language guide (read first)
    ├── API_CONTRACT.md                 Mobile-app integration guide (give to mobile team)
    ├── PRD.md                          Product requirements (goals, metrics, risks)
    ├── PROJECT_STATUS.md               Current snapshot (done/pending/issues)
    ├── SESSION_HANDOFF.md              How to resume work + what NOT to do
    ├── IMPROVEMENTS_VS_AISEC.md         What I improved vs. the original aisec.zip
    ├── VOCAB_EXPLAINED.md              What "vocab" means (plain language)
    ├── INSTRUCTION_IMPROVEMENT.md       How to improve the frozen system prompt (v28)
    ├── CONVERSATIONAL_HANDLING.md      Casual to-and-fro UX design
    ├── BRAINSTORM.md                    Out-of-the-box ideas to make it enticing
    ├── DEV_TEAM_ASKS.md                 What we need from the dev team (prioritized)
    ├── WINDOWS_LOCAL_TESTING.md         Windows-only local testing guide
    ├── OCI_DEPLOYMENT.md                OCI production deployment (Linux, nginx, Vault)
    ├── HARDWARE_AND_DEPLOYMENT.md       Hardware requirements + deployment options
    ├── ADMIN_CONFIG_UI.md              Admin config UI documentation
    ├── VAPT_READINESS.md                Vulnerability assessment readiness
    ├── SCHEMA_CHANGE_PLAYBOOK.md        How to handle DB schema changes
    ├── PRODUCTION_TRACE_OBSERVATIONS.md  Trace observations from production
    ├── DATA_DICTIONARY.md               Data dictionary (markdown)
    ├── DATA_DICTIONARY.xlsx             Data dictionary (Excel)
    ├── INSTRUCTION_MANUAL.md            Instruction manual (markdown)
    ├── INSTRUCTION_MANUAL.pdf           Instruction manual (PDF)
    ├── COMPLETE_GUIDE.md                Complete guide (markdown)
    ├── COMPLETE_GUIDE.pdf               Complete guide (PDF)
    └── diagrams/                        ★ draw.io flow diagrams (open in app.diagrams.net)
        ├── 01-folder-structure.drawio       This folder tree as a visual diagram
        ├── 02-system-workflow.drawio        End-to-end query workflow
        ├── 03-query-pipeline.drawio         Detailed pipeline with decision branches
        ├── 04-llm-setup.drawio              LLM setup + GGUF placement
        ├── chalo-ai-secretary-all-diagrams.drawio  All 4 in one file (open as tabs)
        └── README.md                       How to open the diagrams
```

---

## What was reorganized (2026-08-30)

The frontend files used to be **buried inside `docs/`** mixed with documentation, which made the download confusing. Here's what moved:

| Before (confusing) | After (clean) |
|--------------------|--------------|
| `docs/chat.html` | `frontend/chat.html` |
| `docs/audit.html` | `frontend/audit.html` |
| `docs/start_chat.bat` | `frontend/start_chat.bat` |
| `docs/start_llm.bat` | `scripts/start_llm.bat` |
| `docs/start_backend.bat` | `scripts/start_backend.bat` |
| `docs/run_50.bat` | `scripts/run_50.bat` |
| *(Next.js UI was in project root `src/`, not in the download)* | `frontend/nextjs-ui/` (now included) |

Now `docs/` contains **only documentation**, `frontend/` contains **only UI**, and `scripts/` contains **only launchers**.

---

## Where to find what you need

| You want to... | Go to |
|----------------|-------|
| **Start everything with one click (Windows)** | **`START_HERE.bat`** (opens all 3 services in 3 windows) |
| Understand the project | `README.md` → `docs/HOW_IT_WORKS.md` |
| See the folder tree | `STRUCTURE.md` (this file) |
| Open the chat UI (fastest) | `frontend/chat.html` (just open in a browser, or `frontend/start_chat.bat`) |
| Open the chat UI (React version) | `frontend/nextjs-ui/` (run `npm install && npm run dev`) |
| Start the backend | `scripts/start_backend.bat` (Windows — auto-creates venv + installs deps) or `cd backend && uvicorn main:app` (after `pip install -r backend/requirements.txt`) |
| Start the LLM | `scripts/start_llm.bat` (Windows — friendly GGUF help) or `./llama-server -m model.gguf --port 8080` |
| See the audit trail | `frontend/audit.html` (open in browser) |
| **Export the audit trail to Excel** | `frontend/audit.html` → click the green **Export XLSX** button (downloads a `.xlsx`; falls back to CSV if offline) |
| **Reset (clear) the audit trail** | `frontend/audit.html` → click the red **Reset** button (confirms how many rows will be deleted; cannot be undone) |
| Read the API contract (mobile team) | `docs/API_CONTRACT.md` |
| Run the 50-question test | `scripts/run_50.bat` (Windows — auto-creates venv + uses sample context.json) |
| Understand the pipeline | `pipeline/orchestrator.py` (start there) + `docs/HOW_IT_WORKS.md` |
| See the 32 semantic rules | `pipeline/semantic_rules.py` |
| Validate the training dataset | `semantic_validation/` (now included in this package) |
| See the data dictionary | `docs/DATA_DICTIONARY.md` or `.xlsx` |
| Deploy to production (OCI) | `docs/OCI_DEPLOYMENT.md` |
| **See the planned features / roadmap (added 2026-09-03)** | `README.md` → "Planned features / Roadmap" section. Also `docs/PROJECT_STATUS.md` §4.6 + the 2026-09-03 update; `docs/SESSION_HANDOFF.md` (2026-09-03 update); `docs/INSTRUCTION_MANUAL.md` §2.8 + §2.9; `docs/COMPLETE_GUIDE.md` §4.7 + §4.8 |
| **Read the full project narrative (added 2026-09-03)** | `SESSION_RECORD.md` (project root, ~526 lines, ~27 KB) — 16 sections covering the whole journey from "I have a school ERP" to end-to-end verified |

---

## Visual diagram

For a visual flow diagram of this folder structure (draw.io compatible), see:
`/home/z/my-project/docs/diagrams/01-folder-structure.drawio`

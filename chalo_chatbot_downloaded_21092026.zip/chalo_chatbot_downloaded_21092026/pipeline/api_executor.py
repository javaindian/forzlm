"""
AI Secretary — Application Layer :: API Executor (NEW, round-2)
=================================================================

Extracted from parameter_binder.py for clarity. The api_wrapper execution path:
POST to the ExecuteQuery ASMX endpoint, double-JSON-encode the request,
double-decode the response, handle Success/Data/TotalRowCount/ErrorMessage/
ErrorCode.

Same logic as the original parameter_binder's _post method, but as a standalone
class `APIExecutor` with `execute(bound_request) -> ExecutionResult`. This
separates the EXECUTION concern from the BINDING concern (the ParameterBinder
binds; the APIExecutor executes the bound request).

Why split:
  - The ParameterBinder's execute() couples bind + HTTP. Splitting lets the
    orchestrator compose them: it can bind once, retry-execute the same bound
    request multiple times (transient network failures), and inspect the
    BoundRequest independently of execution.
  - The orchestrator can also call APIExecutor directly with a pre-built
    BoundRequest when it doesn't need the binder's parity check (e.g. it has
    already validated placeholders upstream).

Wire format (unchanged from parameter_binder):
  POST /testv4service/DigitalSecretary/AISecretary.asmx/ExecuteQuery
  Headers:  x-api-key: <key>,  Content-Type: application/json
  Body:     { "request": "<stringified-JSON of the inner payload>" }
  Inner:    { TargetDatabase, SqlQuery, Parameters, PageNumber, PageSize }

Response (parsed twice):
  Top:  { "d": "<stringified-JSON>" }
  Inner: { Success, Data, RowCount, TotalRowCount, PageNumber, PageSize,
           TotalPages, ErrorMessage, ErrorCode }

No hardcoded paths/endpoints (Bible Rule 1). Pure-stdlib HTTP via urllib so
no new dependency. pyodbc is NOT imported here — this is the API path.

Reconstructed as a NEW file in the round-2 split (extracted from
parameter_binder.py). Diff against your real files before deploying.
"""

from __future__ import annotations

import json
import urllib.request
import urllib.error
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional


# Re-export the shared dataclasses so callers don't have to import from two
# places. (Parameter binder remains the canonical home; APIExecutor
# consumers can use either module's BoundRequest/ExecutionResult interchangeably
# since the dataclasses are structurally identical.)
try:
    from .parameter_binder import BoundRequest, ExecutionResult
except ImportError:  # pragma: no cover
    from parameter_binder import BoundRequest, ExecutionResult  # type: ignore


class APIExecutorError(Exception):
    """Wraps network / HTTP / parse failures of the ExecuteQuery call."""


class APIExecutor:
    """
    Standalone executor for the ExecuteQuery API (round-2 split).

    Usage:
        api = APIExecutor(endpoint_url="https://.../ExecuteQuery",
                          api_key="…", timeout_seconds=30)
        result = api.execute(bound_request)   # ExecutionResult

    The BoundRequest is what ParameterBinderExecutor.bind() produces —
    see parameter_binder.BoundRequest. The same double-JSON-encode /
    double-decode wire format is used.

    Args:
        endpoint_url: full ExecuteQuery URL.
        api_key:      sent as the x-api-key header (per-tenant — see
                      user_context_api.TENANT_API_KEY_MAP).
        auth_token:   optional bearer/shared token (rare; ASMX usually uses
                      the x-api-key header only).
        timeout_seconds: HTTP timeout.
        http_opener:  injectable callable(inner_body_dict) -> inner_response_dict
                      for testing (skips the envelope encoding/decoding).
    """

    def __init__(
        self,
        endpoint_url: str,
        api_key: Optional[str] = None,
        auth_token: Optional[str] = None,
        timeout_seconds: int = 30,
        http_opener: Any = None,
    ):
        self.endpoint_url = endpoint_url
        self.api_key = api_key
        self.auth_token = auth_token
        self.timeout_seconds = timeout_seconds
        self._http_opener = http_opener

    def execute(self, bound_request: BoundRequest) -> ExecutionResult:
        """
        POST the bound request to ExecuteQuery and return the parsed
        ExecutionResult. Handles:
          * double-JSON-encode of the request (inner body stringified into
            a top-level "request" field — confirmed intentional ASMX/.NET
            pattern),
          * double-decode of the response (top-level "d" string is itself a
            stringified JSON payload),
          * Success/Data/TotalRowCount/ErrorMessage/ErrorCode extraction.
        """
        body = bound_request.to_body()
        try:
            raw = self._post(body)
        except Exception as e:
            return ExecutionResult(ok=False, request_body=body, error=str(e))

        if not isinstance(raw, dict):
            return ExecutionResult(ok=False, request_body=body,
                                   error="Unexpected response shape.", raw=raw)

        success = raw.get("Success")
        if success is False:
            return ExecutionResult(
                ok=False, request_body=body, raw=raw, success=False,
                error=raw.get("ErrorMessage") or "Query failed on the server.",
                error_code=raw.get("ErrorCode"),
            )

        rows = raw.get("Data") or []
        total = raw.get("TotalRowCount")
        return ExecutionResult(
            ok=True,
            dry_run=False,
            request_body=body,
            rows=rows,
            total_row_count=total,
            page_number=raw.get("PageNumber", bound_request.page_number),
            page_size=raw.get("PageSize", bound_request.page_size),
            total_pages=raw.get("TotalPages"),
            success=True,
            raw=raw,
        )

    # ── HTTP (stdlib; injectable for tests) ──
    def _post(self, body: Dict[str, Any]) -> Any:
        """
        Send the inner payload using the real ExecuteQuery wire format and
        return the ALREADY double-parsed inner response payload.

        Wire out:  { "request": "<stringified inner payload>" }
                   header x-api-key: <key>
        Wire in:   { "d": "<stringified inner response>" }  -> parsed twice.

        The injected test opener (self._http_opener) is given the INNER `body`
        dict directly and is expected to return the INNER response dict, so
        tests don't have to replicate the double-encoding envelope.
        """
        if self._http_opener is not None:
            return self._http_opener(body)  # test seam

        # Envelope: the inner payload is stringified into a top-level "request".
        envelope = {"request": json.dumps(body)}
        data = json.dumps(envelope).encode("utf-8")
        req = urllib.request.Request(self.endpoint_url, data=data, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("Accept", "application/json")
        if self.api_key:
            req.add_header("x-api-key", self.api_key)
        if self.auth_token:
            req.add_header("Authorization", f"Bearer {self.auth_token}")
        with urllib.request.urlopen(req, timeout=self.timeout_seconds) as resp:
            payload = resp.read().decode("utf-8")

        # Parse #1: top-level object with a "d" JSON string.
        try:
            outer = json.loads(payload)
        except json.JSONDecodeError:
            return {"raw_text": payload}
        # Parse #2: "d" itself is a stringified JSON payload.
        d = outer.get("d") if isinstance(outer, dict) else None
        if isinstance(d, str):
            try:
                return json.loads(d)
            except json.JSONDecodeError:
                return {"raw_text": d}
        # Some environments may already return a parsed object.
        return d if isinstance(d, dict) else outer

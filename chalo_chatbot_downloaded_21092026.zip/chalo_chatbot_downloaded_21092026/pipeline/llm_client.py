"""
AI Secretary — Application Layer :: Local LLM Client (llama.cpp)
================================================================

A thin client for the local fine-tuned model served by llama.cpp's
OpenAI-compatible endpoint (POST /v1/chat/completions). Produces the T-SQL for
a natural-language question given a system prompt (which includes the injected
per-branch vocabulary block).

No hardcoded URL/keys/clients (Bible Rule 1): the endpoint and generation params
are injected by the caller (from config.models). Uses urllib (stdlib) so there
is no new dependency; an injectable `poster` seam allows testing without a live
server.

Returns CLEAN SQL — strips markdown fences, a leading "sql" language tag, and
trailing chatter — so downstream guardrails/binder get exactly the statement.

⚠️ ROUND-2 EXTENSION (D1.8): truncation guard. The client now inspects
`choices[0].finish_reason`; when it equals `"length"`, the model was cut off by
`max_tokens` and the produced SQL is structurally incomplete — executing it
would risk a partial query that fails or returns wrong results silently. The
client raises `TruncationError` so the orchestrator can refuse with a helpful
"please ask a more specific question" message instead of letting truncated
SQL through. `last_finish_reason` is also exposed for callers that prefer
sentinel-based handling.

Reconstructed from the original app_layer/ code + round-2 extensions.
Diff against your real files before deploying.
"""

from __future__ import annotations

import json
import re
import urllib.request
from typing import Any, Dict, List, Optional, Callable


class TruncationError(Exception):
    """
    Raised when the model's `finish_reason == "length"` — i.e. the response was
    cut off by `max_tokens` before the SQL was structurally complete. The
    orchestrator catches this and refuses (D1.8) rather than executing the
    truncated SQL.
    """


def clean_sql(raw: str) -> str:
    """
    Normalize a model completion down to a single SQL statement:
      * strip ```sql ... ``` fences and stray backticks
      * drop a leading bare 'sql' line
      * trim to the first statement's content (keep it intact; do not mangle)
    Conservative — only removes wrapper noise, never rewrites the SQL itself.
    """
    if not raw:
        return ""
    s = raw.strip()
    # Remove fenced code blocks ```sql ... ``` or ``` ... ```
    fence = re.search(r"```(?:sql)?\s*(.+?)```", s, flags=re.IGNORECASE | re.DOTALL)
    if fence:
        s = fence.group(1).strip()
    # Drop a leading language tag line
    s = re.sub(r"^\s*sql\s*\n", "", s, flags=re.IGNORECASE)
    # Strip surrounding stray backticks/quotes
    s = s.strip("`").strip()
    return s.strip()


class LlamaCppClient:
    """
    Calls a llama.cpp OpenAI-compatible chat-completions endpoint.

    Args:
        url: full endpoint, e.g. "http://localhost:8080/v1/chat/completions".
        temperature / max_tokens / stop: generation params (from config.models.text_to_sql).
        timeout_seconds: HTTP timeout.
        poster: injectable callable(payload_dict) -> response_dict for testing.
    """

    def __init__(self, url: str, temperature: float = 0.1, max_tokens: int = 768,
                 stop: Optional[List[str]] = None, timeout_seconds: int = 120,
                 repeat_penalty: float = 1.1,
                 poster: Optional[Callable[[Dict[str, Any]], Dict[str, Any]]] = None):
        self.url = url
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.stop = stop or []
        self.timeout = timeout_seconds
        # repeat_penalty=1.1 confirmed NECESSARY in this project's eval notes —
        # without it the model degenerates into repeat-loops (observed 2026-08-07:
        # a hallucinated locality-LIKE list repeating until the token limit).
        self.repeat_penalty = repeat_penalty
        self._poster = poster
        # D1.8: expose the last finish_reason for callers that prefer the
        # sentinel-style API (kept alongside the raising API). Reset every call.
        self.last_finish_reason: Optional[str] = None

    def generate(self, system_prompt: str, question: str) -> str:
        """Return cleaned T-SQL for `question` under `system_prompt`.

        Raises TruncationError when the model's `finish_reason == "length"`
        (D1.8) — the orchestrator catches this and refuses with a helpful
        message rather than executing the truncated SQL.
        """
        payload: Dict[str, Any] = {
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": question},
            ],
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
        }
        # llama.cpp accepts repeat_penalty on its OpenAI-compatible endpoint.
        if self.repeat_penalty:
            payload["repeat_penalty"] = self.repeat_penalty
        if self.stop:
            payload["stop"] = self.stop

        resp = self._post(payload)
        # OpenAI-compatible shape: choices[0].message.content + finish_reason
        try:
            choice = resp["choices"][0]
            content = choice["message"]["content"]
            finish_reason = choice.get("finish_reason")
        except (KeyError, IndexError, TypeError):
            content = ""
            finish_reason = None

        self.last_finish_reason = finish_reason

        # D1.8 — if the model was cut off by max_tokens, refuse rather than
        # execute the (structurally incomplete) SQL it managed to emit.
        if finish_reason == "length":
            raise TruncationError(
                "LLM response was truncated by max_tokens (finish_reason='length') — "
                "the SQL is structurally incomplete. Ask a more specific question."
            )

        return clean_sql(content)

    def _post(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        if self._poster is not None:
            return self._poster(payload)  # test seam
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(self.url, data=data, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("Accept", "application/json")
        with urllib.request.urlopen(req, timeout=self.timeout) as r:
            body = r.read().decode("utf-8")
        try:
            return json.loads(body)
        except json.JSONDecodeError:
            return {}

"""
AI Secretary — Application Layer :: Local DB Executor
=====================================================

Executes a bound (parameterized) query DIRECTLY against a local MS SQL Server
via pyodbc + sp_executesql — NO ExecuteQuery HTTP API involved.

This is the "direct" execution path for a fully-live demo on the user's own
machine, with zero dependency on the dev team's ExecuteQuery endpoint. It is an
alternative to app_layer.parameter_binder's HTTP path; the Parameter Binder
still produces the exact same safe bound request — only the final execution
target differs (local DB vs their API).

CRITICAL SAFETY (VAPT Rule 2 — no SQLi):
  Values are bound as REAL parameters through sp_executesql. They are NEVER
  concatenated into the SQL string. Named @placeholders in the model SQL map to
  sp_executesql's @params. Even free-text a user typed is treated strictly as
  data by the engine.

Defense in depth:
  * SELECT-only is enforced UPSTREAM by the Parameter Binder before a query
    reaches here; this module additionally refuses anything whose first verb is
    not SELECT/WITH as a second guard.
  * Strongly recommended: connect with a READ-ONLY SQL login (db_datareader, no
    write grants) so the database ITSELF cannot be written even if a bug slipped
    through. The executor cannot enforce this — it is an ops/credential choice.

⚠️ ROUND-2 EXTENSION (D1.11): a simple connection pool.
  The original opened a fresh pyodbc connection PER QUERY, which is slow under
  load (every call pays the full ODBC handshake, ~50-150ms on a remote server).
  The extended version keeps ONE module-level connection alive, guarded by a
  threading.Lock — same connection reused across queries. Reconnects lazily
  if the cached connection has died (server restart / network blip). Kept
  simple: no third-party pool, no per-thread connections (the orchestrator is
  single-threaded per request). If a future deployment goes multi-threaded,
  upgrade to a real pool — but for this project's request volume the
  single-connection pool is enough and easy to reason about.

No hardcoded paths/credentials/clients in code (Bible Rule 1): the connection
parameters are injected by the caller (from config). pyodbc is imported lazily
so this module can be imported/tested where pyodbc is absent.

Reconstructed from the original app_layer/local_executor.py + round-2 D1.11
extension. Diff against your real files before deploying.
"""

from __future__ import annotations

import re
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional


class LocalExecutorError(Exception):
    """Execution failure against the local DB (fail closed)."""


class UnsafeQueryError(LocalExecutorError):
    """The SQL is not a read-only SELECT (second-line guard)."""


@dataclass
class LocalExecRes:
    ok: bool
    columns: List[str] = field(default_factory=list)
    rows: List[List[Any]] = field(default_factory=list)
    row_count: int = 0
    truncated: bool = False
    execution_time_ms: int = 0
    error: Optional[str] = None


# sp_executesql wants an @name typed param declaration string, e.g.
#   N'@ClassName nvarchar(4000), @UserId int, @SelectedBranchId int'
# We infer a conservative type per value; NULL/str -> nvarchar, int -> int.
def _sql_type_for(value: Any) -> str:
    if isinstance(value, bool):
        return "bit"
    if isinstance(value, int):
        return "int"
    if isinstance(value, float):
        return "float"
    # None or str -> nvarchar (NULL binds fine as nvarchar)
    return "nvarchar(4000)"


# ── D1.11: simple module-level connection pool ──────────────────────────
# One connection per (driver, server, port, username, database). Guarded by
# a single lock (the orchestrator is single-threaded per request; if a future
# deployment goes multi-threaded, upgrade to a real pool — but for this
# project's request volume the single-connection pool is enough and easy to
# reason about).
_POOL_LOCK = threading.Lock()
_POOL_CONN: Dict[tuple, Any] = {}  # (driver, server, port, username, database) -> conn


def _pool_key(executor: "LocalDBExecutor", database: str) -> tuple:
    return (
        executor._driver,
        executor._server,
        executor._port,
        executor._username,
        database,
    )


def _is_alive(conn: Any) -> bool:
    """Cheap liveness check — does a SELECT 1 round-trip. Returns False on
    any exception (caller will reconnect)."""
    if conn is None:
        return False
    try:
        cur = conn.cursor()
        cur.execute("SELECT 1")
        cur.fetchone()
        return True
    except Exception:
        return False


def _close_pooled_conn(key: tuple) -> None:
    """Close + drop a pooled connection (under lock)."""
    with _POOL_LOCK:
        conn = _POOL_CONN.pop(key, None)
    if conn is not None:
        try:
            conn.close()
        except Exception:
            pass


def close_all_pooled_connections() -> None:
    """Close every cached connection (called on app shutdown)."""
    with _POOL_LOCK:
        keys = list(_POOL_CONN.keys())
    for k in keys:
        _close_pooled_conn(k)


class LocalDBExecutor:
    """
    Runs a bound query on a local MS SQL Server via sp_executesql.

    Usage:
        ex = LocalDBExecutor(driver="ODBC Driver 17 for SQL Server",
                             server="localhost", port=1433,
                             username="ai_readonly", password="…",
                             timeout_seconds=30, max_rows=1000)
        res = ex.execute(sql_with_placeholders, parameters, database="V3_TestDatabase")
    """

    def __init__(self, driver: str, server: str, port: int,
                 username: str, password: str,
                 timeout_seconds: int = 30, max_rows: int = 1000,
                 connector: Any = None,
                 use_pool: bool = True):
        self._driver = driver
        self._server = server
        self._port = port
        self._username = username
        self._password = password
        self._timeout = timeout_seconds
        self._max_rows = max_rows
        # `connector` is an injectable pyodbc-like module for testing
        # (must expose .connect(conn_str) -> connection). Defaults to pyodbc.
        self._connector = connector
        # D1.11: connection pool toggle (default ON). Tests can disable to
        # preserve the original per-query connection behavior.
        self._use_pool = use_pool

    def _conn_str(self, database: str) -> str:
        # SERVER format:
        #   * Named instance (e.g. HOST\\SQLEXPRESS): use the name AS-IS, no
        #     port (named instances use dynamic ports via SQL Browser).
        #   * Default instance with an explicit port: HOST,PORT.
        # Heuristic: backslash in server (named instance) OR no port -> omit ,port.
        if "\\" in str(self._server) or not self._port:
            server_part = f"{self._server}"
        else:
            server_part = f"{self._server},{self._port}"
        return (
            f"DRIVER={{{self._driver}}};"
            f"SERVER={server_part};"
            f"DATABASE={database};"
            f"UID={self._username};"
            f"PWD={self._password};"
            f"Connection Timeout={self._timeout};"
        )

    def _connect(self, database: str):
        connector = self._connector
        if connector is None:
            import pyodbc  # lazy — only needed for real execution
            connector = pyodbc
        return connector.connect(self._conn_str(database))

    # D1.11: get a (possibly cached) connection. If the cached connection
    # has died, reconnect under the lock. If pooling is disabled, always
    # open a fresh connection (matches the original behavior).
    def _get_connection(self, database: str):
        if not self._use_pool:
            return self._connect(database), False  # (conn, owned=True)

        key = _pool_key(self, database)
        with _POOL_LOCK:
            conn = _POOL_CONN.get(key)
            if conn is not None and _is_alive(conn):
                return conn, False  # pooled — don't close after use

        # Either no cached conn, or the cached one is dead — open a fresh one.
        # Open OUTSIDE the lock (pyodbc.connect can block on network I/O; we
        # don't want to serialize every reconnect). Then race to install it
        # under the lock — if we lose the race, close the loser.
        new_conn = self._connect(database)
        with _POOL_LOCK:
            existing = _POOL_CONN.get(key)
            if existing is not None and _is_alive(existing):
                # Someone else won the race — close ours, use theirs.
                try:
                    new_conn.close()
                except Exception:
                    pass
                return existing, False
            _POOL_CONN[key] = new_conn
        return new_conn, False  # always return False for "owned" — pool owns it

    @staticmethod
    def _assert_read_only(sql: str) -> None:
        stripped = re.sub(r"^\s*(--[^\n]*\n|/\*.*?\*/)\s*", "", sql.strip(), flags=re.DOTALL)
        first = re.match(r"\s*(\w+)", stripped)
        if not first or first.group(1).upper() not in {"SELECT", "WITH"}:
            raise UnsafeQueryError("Only SELECT (or WITH … SELECT) queries may execute.")

    @staticmethod
    def _order_params(sql: str, parameters: Dict[str, Any]) -> List[str]:
        """
        Determine which @params actually appear in the SQL (so we only declare
        those to sp_executesql), preserving a stable order.
        """
        present = []
        seen = set()
        for m in re.finditer(r"(?<!@)@(\w+)", sql):
            name = m.group(1)
            key = f"@{name}"
            if key in parameters and key not in seen:
                present.append(key)
                seen.add(key)
        return present

    def execute(self, sql: str, parameters: Dict[str, Any],
                database: str) -> LocalExecRes:
        """
        Execute `sql` (with @placeholders) binding `parameters` via sp_executesql.

        parameters: {"@ClassName": "X", "@UserId": 2, "@SelectedBranchId": None,
                     "@AcademicYearID": 7}  (D1.3)
        """
        self._assert_read_only(sql)

        ordered = self._order_params(sql, parameters)
        # Build the sp_executesql parameter DECLARATION + the bound arg list.
        decl = ", ".join(f"{name} {_sql_type_for(parameters[name])}" for name in ordered)
        # exec sp_executesql @stmt, @params, @p1=?, @p2=? ... — values passed as
        # pyodbc positional args so they are BOUND, never concatenated.
        placeholders_assign = ", ".join(f"{name}=?" for name in ordered)

        outer = "EXEC sp_executesql ?, ?" + (
            (", " + placeholders_assign) if ordered else ""
        )
        # pyodbc positional args, in order: @stmt, @params, then each value.
        args: List[Any] = [sql, decl] + [parameters[name] for name in ordered]

        start = time.time()
        try:
            conn, owned = self._get_connection(database)
        except Exception as e:  # driver missing / connection refused / auth
            return LocalExecRes(ok=False, error=f"Connection failed: {e}")

        try:
            cur = conn.cursor()
            cur.execute(outer, args)
            columns = [c[0] for c in cur.description] if cur.description else []
            raw = cur.fetchmany(self._max_rows + 1)
            truncated = len(raw) > self._max_rows
            rows: List[List[Any]] = []
            for r in raw[: self._max_rows]:
                rows.append([
                    (v.isoformat() if hasattr(v, "isoformat") else v) for v in r
                ])
            return LocalExecRes(
                ok=True, columns=columns, rows=rows, row_count=len(rows),
                truncated=truncated,
                execution_time_ms=int((time.time() - start) * 1000),
            )
        except Exception as e:
            # D1.11: if the connection died mid-flight, drop it from the pool so
            # the next call reconnects fresh.
            if self._use_pool:
                _close_pooled_conn(_pool_key(self, database))
            return LocalExecRes(ok=False, error=str(e))
        finally:
            if owned:
                try:
                    conn.close()
                except Exception:
                    pass

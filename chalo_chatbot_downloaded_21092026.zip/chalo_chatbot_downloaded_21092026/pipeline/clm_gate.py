# clm_gate.py - CLM r1 tiering gates (Gate1 intent / Gate2 SQL-shape).
#
# Design contract (owner-approved, see clm_config + tier design doc):
#   * Tier-blind model: tiers are CONFIG DATA - never model, dataset, or code.
#   * Gate1 = intent gate, pre-model, at CONTEXT entry. Refuses registered
#     exception questions for tiers that don't serve them (0 GPU cost).
#   * Gate2 = SQL-shape gate, post-validation / pre-execution (first execute
#     only). Ships in monitor mode (log-only) for false-positive tuning.
#   * Fail-open: ANY error inside a gate must never take the chatbot down -
#     refusals are data-driven, not crashes. Callers also wrap us in try/except.
#   * Hot-reload: config + sidecar are mtime-checked per request; edits land on
#     the next message with NO service restart.
#
# Deployed at $APP_ROOT/pipeline/clm_gate.py alongside orchestrator.py.
# Data at $APP_ROOT/clm/{clm_config.json, exceptions_sidecar.csv}.

import csv
import json
import os
import re

def _detect_app_root() -> str:
    """CHALO_APP_ROOT env wins; otherwise derive from this file's location:
    .../<APP_ROOT>/chalo_chatbot/pipeline/clm_gate.py -> <APP_ROOT>.
    Works unchanged on the VPS (/opt/chalo-ai-secretary) and on a Windows
    laptop (e.g. D:\\clm_test) with no environment variables."""
    env = os.environ.get("CHALO_APP_ROOT")
    if env:
        return env
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.dirname(os.path.dirname(here))  # pipeline -> chalo_chatbot -> APP_ROOT

_APP_ROOT = _detect_app_root()
CONFIG_PATH = os.path.join(_APP_ROOT, "clm", "clm_config.json")
SIDECAR_PATH = os.path.join(_APP_ROOT, "clm", "exceptions_sidecar.csv")

# UI selector values (chat.html) -> config tier keys. Unknown values degrade to 1.0.
_TIER_ALIASES = {"clm1": "1.0", "clm2": "2.0", "clm3": "3.0",
                 "1.0": "1.0", "2.0": "2.0", "3.0": "3.0"}

_state = {"key": None, "config": None, "questions": {}}


def _norm_question(q: str) -> str:
    """Normalize a question for registry matching (exact-match only by design;
    paraphrases intentionally pass through as everyday - documented limitation)."""
    q = (q or "").strip().lower()
    q = re.sub(r"\s+", " ", q)
    q = q.rstrip("?.!;: ")
    return q


def _maybe_reload() -> dict:
    """(mtime_ns, size)-keyed lazy load. Any load error keeps the last good
    state; if there is no last good state the caller's fail-open path handles
    it. Exact-integer key: float-second mtimes can collide for two writes
    under ~1us apart (r2.3 hardening - race caught by the functional suite)."""
    try:
        cs, ss = os.stat(CONFIG_PATH), os.stat(SIDECAR_PATH)
        key = ((cs.st_mtime_ns, cs.st_size), (ss.st_mtime_ns, ss.st_size))
    except OSError:
        return _state  # files unreadable right now: serve last good config
    if _state["key"] == key and _state["config"] is not None:
        return _state
    try:
        cfg = json.load(open(CONFIG_PATH, "r", encoding="utf-8"))
        questions = {}
        with open(SIDECAR_PATH, "r", encoding="utf-8", newline="") as fh:
            for row in csv.DictReader(fh):
                questions[_norm_question(row.get("input", ""))] = row.get("qid", "")
    except Exception:
        # Broken/unreadable config edit: keep serving the last good state.
        # (Callers still fail-open around us; this just avoids refusing every
        # subsequent request while a bad edit is on disk.)
        if _state["config"] is not None:
            return _state
        raise
    _state.update(key=key, config=cfg, questions=questions)
    print(f"clm: {len(questions)} exceptions registered (sidecar rows {len(questions)}); "
          f"tier 2.0 enabled={cfg.get('tiers', {}).get('2.0', {}).get('enabled', False)}; "
          f"gate1={cfg.get('enforcement', {}).get('gate1', 'enforce')}; "
          f"gate2={cfg.get('enforcement', {}).get('gate2', 'monitor')}; "
          f"config={CONFIG_PATH}", flush=True)
    return _state


def _effective_tier(cfg: dict, tier_raw: str) -> str:
    tier = _TIER_ALIASES.get((tier_raw or "").strip().lower(), "1.0")
    if not cfg.get("tiers", {}).get(tier, {}).get("enabled", False):
        tier = "1.0"  # disabled tiers fall back to 1.0 behavior (stage-1 rollout)
    return tier


def gate1_check(question: str, tier_raw: str) -> dict:
    """Return {action, qid, tier, trace, message}. action in {allow, refuse}."""
    st = _maybe_reload()
    cfg = st["config"]
    tier = _effective_tier(cfg, tier_raw)
    qid = st["questions"].get(_norm_question(question), "")
    if not qid:
        # Unregistered question -> everyday default (membership pending-registration).
        return {"action": "allow", "qid": "-", "tier": tier,
                "trace": f"gate1: unregistered -> everyday default tier={tier} action=allow",
                "message": None}
    allowed = cfg.get("question_groups", {}).get("exceptions", {}).get("tiers", ["2.0"])
    if tier in allowed:
        return {"action": "allow", "qid": qid, "tier": tier,
                "trace": f"gate1: qid={qid} tier={tier} action=allow", "message": None}
    msg = cfg.get("refusal", {}).get("message", "")
    return {"action": "refuse", "qid": qid, "tier": tier,
            "trace": f"gate1: qid={qid} tier={tier} action=refuse", "message": msg}


def gate2_check(sql: str) -> dict:
    """Return {matched, action, trace, message}. monitor logs; enforce refuses.
    No trace line when nothing matches (silence == clean pass, not a failure)."""
    st = _maybe_reload()
    cfg = st["config"]
    mode = cfg.get("enforcement", {}).get("gate2", "monitor")
    matched = []
    try:
        for rule in cfg.get("sql_shape_rules", []):
            if re.search(rule.get("signature", ""), sql or ""):
                matched.append(rule.get("id", "?"))
    except re.error:
        matched = []  # a broken regex in config must not crash the pipeline
    if not matched:
        return {"matched": False, "action": "allow", "trace": None, "message": None}
    refuse = (mode == "enforce")
    return {"matched": True,
            "action": "refuse" if refuse else "monitor-log",
            "trace": f"gate2[{mode}]: matched {matched}",
            "message": cfg.get("refusal", {}).get("message", "") if refuse else None}


def banner() -> str:
    """One-line registration summary (same text the gate prints on first load)."""
    st = _maybe_reload()
    cfg = st["config"]
    return (f"clm: {len(st['questions'])} exceptions registered; "
            f"tier 2.0 enabled={cfg.get('tiers', {}).get('2.0', {}).get('enabled', False)}; "
            f"gate1={cfg.get('enforcement', {}).get('gate1')}; "
            f"gate2={cfg.get('enforcement', {}).get('gate2')}; "
            f"fail_open={cfg.get('enforcement', {}).get('fail_open')}")

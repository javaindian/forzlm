"""
AI Secretary — Application Layer :: Parameter Binder & Executor (Component #5)
==============================================================================

Purpose
-------
The final step of the app layer. Takes:
    * a model-generated SQL query containing named placeholders
      (@ClassName, @UserId, @SelectedBranchId, @AcademicYearID, ...),
    * the security parameters from the Context Manager,
    * the resolved master-data values from the Value Resolver,
and executes it against Chalo's ExecuteQuery API — binding every value as a
SEPARATE parameter, never concatenated into the SQL text.

Agreed API contract (per API_parameter_request_for_dev_team.md + the dev team's
ExecuteQuery API Documentation)
---------------------------------------------------------------
POST /testv4service/DigitalSecretary/AISecretary.asmx/ExecuteQuery

WIRE FORMAT (important — the inner payload is DOUBLE-ENCODED):
  Headers:  x-api-key: <key>,  Content-Type: application/json
  Body:     { "request": "<stringified-JSON of the inner payload>" }

  Inner payload (stringified into "request"):
    {
      "TargetDatabase": "V3_TestDatabase",
      "SqlQuery": "SELECT ... WHERE cm.Name = @ClassName AND ... UserID = @UserId",
      "Parameters": { "@ClassName": "Class 10", "@UserId": 2 },
      "PageNumber": 1,
      "PageSize": 10
    }

  The server binds @-placeholders via sp_executesql. `Parameters` is optional and
  backward-compatible (existing inline callers unaffected).

RESPONSE (must be parsed TWICE):
  Top level:  { "d": "<stringified-JSON>" }
  Decoded d:  { "Success": bool, "Data": [ {...}, ... ], "RowCount": int,
                "TotalRowCount": int, "PageNumber": int, "PageSize": int,
                "TotalPages": int, "ErrorMessage": str|null, "ErrorCode": str|null }
  Row objects live under "Data"; total under "TotalRowCount".

Why this component exists (VAPT Rule 2 — no SQLi)
-------------------------------------------------
Values — especially free-text a user typed into the chat box — must NEVER be
spliced into the SQL string. This binder is the mechanism that guarantees it:
it refuses to execute unless every placeholder in the SQL has a bound parameter,
and it never builds the final value-substituted SQL itself.

⚠️ ROUND-2 EXTENSIONS:
  D1.3 — `@AcademicYearID` is now a SECURITY PARAMETER alongside `@UserId`
          and `@SelectedBranchId`. The orchestrator's UserContext.to_query_params()
          resolves it from the Context JSON's `IsCurrentYear` AcademicYear for
          the selected branch and passes it in `security_params`. The binder
          treats it the same way as the other two: it's NEVER user input, it's
          always trusted-context-derived.
  D1.4 / F6 — `substitute_validated_values(sql, substitutions)` helper.
          After the VALIDATE stage, the orchestrator collects
          {("<user_value>", "<database_value>")} pairs from the ValueValidator
          results (every result with should_substitute=True) and calls this to
          REWRITE the SQL literals BEFORE the semantic-rules check. The
          substitution is a SAFE regex literal replace on quoted strings only —
          it never touches placeholders, parameter names, or columns.

NOTE ON EXECUTION PATHS (round-2 split): the api_wrapper execution path has
been EXTRACTED to api_executor.py as a standalone APIExecutor class. This
module's ParameterBinderExecutor still has its .execute() method (for
backward compatibility) which delegates to APIExecutor when mode=="api_wrapper".
For the live pipeline, the orchestrator may either:
  (a) call self._binder.execute(...) (legacy API — kept), or
  (b) call APIExecutor(binder).execute(bound_request) directly (cleaner).
The two are functionally equivalent; (b) is preferred for new code.

Safety behaviour
----------------
    * SELECT-only: rejects any query whose first significant verb is not SELECT,
      or that contains a blocked write keyword (DROP/DELETE/UPDATE/... ) as a
      statement verb — mirrors config.yaml `safety.blocked_keywords`.
    * Placeholder/parameter parity: every @placeholder in the SQL must have a
      value in Parameters, and vice-versa — else fail closed (no execution).
    * @UserId, @SelectedBranchId, and @AcademicYearID (the security params)
      are injected from the trusted UserContext, never from user input.
    * dry_run: when enabled, returns the exact request body WITHOUT calling the
      API (mirrors config.yaml `server.dry_run`) — for safe testing.

No hardcoded paths, endpoints, or client names in code (Bible Rule 1): the
endpoint, target DB, token and dry_run flag are all injected by the caller
(from config). Pure-stdlib HTTP via urllib so no new dependency is required.

Reconstructed from the original app_layer/parameter_binder.py + round-2
extensions. Diff against your real files before deploying.
"""

from __future__ import annotations

import json
import re
import urllib.request
import urllib.error
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Tuple


# Placeholders that identify @named parameters in the SQL (not @@SYSTEM vars).
_PLACEHOLDER = re.compile(r"(?<!@)@(\w+)")

# CONFIRMED via direct, isolated testing against the real server: TOP N
# fails execution regardless of GROUP BY/ORDER BY/aggregates being present
# -- a query with GROUP BY + ORDER BY succeeds; the SAME query with only
# TOP 1 added fails; a query with JUST "TOP 1 ... ORDER BY" (no GROUP BY
# at all) also fails. The common, isolated variable is TOP N itself, not
# any of the other SQL constructs. Affects 281 of 2,417 training examples
# (~12%) -- a significant, common pattern (highest/lowest/top-N style
# questions), not a rare edge case.
_TOP_N = re.compile(r"\bTOP\s+(\d+)\b", re.IGNORECASE)


# ── D1.3: the security placeholders (never from user input) ──────────────
# These three are TRUSTED-context-derived and always bound as real parameters.
# Everything else in `Parameters` is either an LLM-emitted @-placeholder (also
# bound) or a resolved master-data value (validated upstream).
SECURITY_PLACEHOLDERS = {"UserId", "SelectedBranchId", "AcademicYearID"}


def _extract_top_n(sql: str):
    """
    If the SQL uses TOP N, returns (sql_with_top_removed, N). Otherwise
    returns (sql, None) unchanged. The API's own PageSize mechanism
    (already confirmed reliable) achieves the same row-limiting intent
    without triggering the confirmed TOP N execution failure.
    """
    m = _TOP_N.search(sql)
    if not m:
        return sql, None
    n = int(m.group(1))
    stripped = _TOP_N.sub("", sql, count=1)
    stripped = re.sub(r"\s{2,}", " ", stripped).strip()  # tidy the extra space left behind
    return stripped, n


def _sql_literal(value: Any) -> str:
    """
    Converts a Python value to a SAFE SQL literal for inlining, when the
    real ExecuteQuery API's Parameters-based binding isn't usable (the
    confirmed, currently-broken server-side limitation on repeated
    placeholders in nested subqueries).

    THE ACTUAL SAFETY-CRITICAL PART: every value going through here has
    ALREADY been through this project's real safety chain before it
    arrives -- @UserId/@SelectedBranchId/@AcademicYearID come from the trusted
    UserContext (never user-typed), and any resolved string values
    (class names, section names, etc.) have ALREADY been validated as
    real, existing branch-vocabulary values by ValueValidator before
    binding is ever attempted. This function is a second layer of
    defense on top of that, not the only one -- but it must still be
    correct on its own, since defense-in-depth means every layer holds.

    - None -> the bare SQL keyword NULL (not a quoted string).
    - bool -> 1 or 0 (bit).
    - int/float -> the plain number, no quotes (never a source of
      injection since numbers can't contain a stray quote character).
    - str -> single-quoted, with every embedded single quote DOUBLED
      (SQL Server's standard escaping: O'Brien -> 'O''Brien'). This is
      the one case that would be genuinely unsafe if done wrong.
    """
    if value is None:
        return "NULL"
    if isinstance(value, bool):
        return "1" if value else "0"
    if isinstance(value, (int, float)):
        return str(value)
    escaped = str(value).replace("'", "''")
    return f"'{escaped}'"


def inline_parameters(sql: str, parameters: Dict[str, Any]) -> str:
    """
    Replaces every @name placeholder in `sql` with its safely-escaped
    literal value from `parameters`. Used only when the real API's
    Parameters-based binding can't be used (the confirmed, currently
    broken repeated-placeholder-in-subquery limitation) -- this is a
    fallback, not the preferred path; parameterized binding remains the
    default whenever the server supports it.

    Raises ValueError if the SQL references a placeholder with no
    supplied value -- fails closed, same discipline as the existing
    bind() parity check, rather than silently leaving @name in the text.
    """
    missing = []

    def _replace(m: re.Match) -> str:
        name = m.group(1)
        key = f"@{name}"
        if key not in parameters:
            missing.append(key)
            return m.group(0)
        return _sql_literal(parameters[key])

    result = _PLACEHOLDER.sub(_replace, sql)
    if missing:
        raise ValueError(f"No value supplied for placeholder(s): {', '.join(sorted(set(missing)))}")
    return result


# ── D1.4 / F6: substitute_validated_values ──────────────────────────────
# After VALIDATE, the orchestrator collects {("<user_value>", "<database_value>")}
# pairs from the ValueValidator results and calls this to REWRITE the SQL
# literals BEFORE the semantic-rules check.
#
# This is a SAFE regex literal replace on quoted SQL strings only — it does
# NOT touch placeholders, parameter names, columns, or anything else. The
# substitution is on `'literal'` strings only (single-quoted, with SQL-style
# '' escape for embedded quotes), since that's how master-data values are
# inlined by the LLM (cm.Name = 'Class 10', sub.Name = 'maths', etc.).
#
# Why a regex replace and not a token-aware parse: the LLM inlines literals
# in standard T-SQL form, so a regex on 'literal' is sufficient and SAFE —
# any value the orchestrator passes here has already been validated against
# the branch vocab (so it can't be malformed SQL). The escape-doubling rule
# for the new literal is applied (so the substituted SQL is still valid T-SQL).

_LITERAL_REPLACE_PATTERN = re.compile(r"'((?:[^']|'')*)'")


def substitute_validated_values(sql: str,
                                 substitutions: Dict[str, str]) -> str:
    """
    D1.4 / F6 — rewrite the SQL literals post-VALIDATE, before the
    semantic-rules check. `substitutions` is a mapping from
    `<user_value>` (the literal the LLM emitted) to `<database_value>`
    (the branch's real literal to substitute). Only single-quoted string
    literals are touched; placeholders, parameter names, columns, and
    numeric literals are not.

    The substitution is applied to each `'literal'` token in the SQL: if
    the literal (after un-escaping doubled single quotes) EXACTLY equals
    one of the substitution keys, it is replaced with the new value
    (escaped and re-quoted per SQL Server rules). Case-sensitive match —
    the orchestrator should normalize keys to whatever the LLM emitted.

    Idempotent: applying the same substitutions twice is a no-op the
    second time (the new literal is already the database_value, which
    isn't in the substitution keys).

    Args:
        sql: the LLM-generated SQL with master-data literals to rewrite.
        substitutions: {user_value -> database_value} map.

    Returns: the rewritten SQL.
    """
    if not substitutions:
        return sql

    # Invert keys for quick lookup: un-escaped literal -> replacement value.
    # The keys are exact-match strings (case-sensitive). A literal that
    # contains a single quote (e.g. "O'Brien") would have '' in the SQL
    # text; we un-escape both sides for comparison.
    lookup = {}
    for user_val, db_val in substitutions.items():
        lookup[user_val.replace("''", "'")] = db_val

    if not lookup:
        return sql

    def _replace_literal(m: re.Match) -> str:
        raw = m.group(1)
        unescaped = raw.replace("''", "'")
        if unescaped in lookup:
            new_val = lookup[unescaped]
            escaped = str(new_val).replace("'", "''")
            return f"'{escaped}'"
        return m.group(0)

    return _LITERAL_REPLACE_PATTERN.sub(_replace_literal, sql)


# Write verbs that must never appear as a statement verb (SELECT-only service).
_DEFAULT_BLOCKED = {
    "DROP", "DELETE", "UPDATE", "INSERT", "ALTER", "CREATE",
    "TRUNCATE", "EXEC", "EXECUTE", "MERGE", "GRANT", "REVOKE",
}


class BinderError(Exception):
    """Base class for bind/execute failures (fail closed)."""


class UnboundParameterError(BinderError):
    """A placeholder in the SQL has no supplied value, or vice-versa."""


class UnsafeQueryError(BinderError):
    """The SQL is not a read-only SELECT / contains a blocked verb."""


@dataclass
class BoundRequest:
    """The exact request body sent to (or previewed for) ExecuteQuery."""
    target_database: str
    sql_query: str
    parameters: Dict[str, Any]
    page_number: int
    page_size: int

    def to_body(self) -> Dict[str, Any]:
        return {
            "TargetDatabase": self.target_database,
            "SqlQuery": self.sql_query,
            "Parameters": self.parameters,
            "PageNumber": self.page_number,
            "PageSize": self.page_size,
        }


@dataclass
class ExecutionResult:
    ok: bool
    dry_run: bool = False
    request_body: Optional[Dict[str, Any]] = None
    rows: List[Any] = field(default_factory=list)
    total_row_count: Optional[int] = None
    page_number: Optional[int] = None
    page_size: Optional[int] = None
    error: Optional[str] = None
    raw: Optional[Any] = None
    success: Optional[bool] = None       # inner payload "Success"
    total_pages: Optional[int] = None    # inner payload "TotalPages"
    error_code: Optional[str] = None     # inner payload "ErrorCode"


class ParameterBinderExecutor:
    """
    Binds resolved values as separate parameters and calls ExecuteQuery.

    All environment specifics are injected (no hardcoding):
        endpoint_url    — full ExecuteQuery URL (from config)
        target_database — e.g. "V3_TestDatabase" (from config/session)
        auth_token      — optional bearer/shared token (from config)
        api_key         — sent as the x-api-key header (from config)
        dry_run         — if True, never calls the API; returns the body
        timeout_seconds — HTTP timeout
        blocked_keywords— override the default write-verb blocklist
        use_inline_params — fallback for the confirmed, currently-broken
                             server-side repeated-placeholder limitation
    """

    def __init__(
        self,
        endpoint_url: str,
        target_database: str,
        auth_token: Optional[str] = None,
        api_key: Optional[str] = None,
        dry_run: bool = True,
        timeout_seconds: int = 30,
        blocked_keywords: Optional[List[str]] = None,
        http_opener: Any = None,   # inject for testing; defaults to urllib
        use_inline_params: bool = False,   # SWAPPABLE fallback -- see inline_parameters() docstring
    ):
        self.endpoint_url = endpoint_url
        self.target_database = target_database
        self.auth_token = auth_token
        self.api_key = api_key            # sent as the x-api-key header
        self.dry_run = dry_run
        self.timeout_seconds = timeout_seconds
        self._blocked = {k.upper() for k in (blocked_keywords or _DEFAULT_BLOCKED)}
        self._http_opener = http_opener  # callable(request_body_dict) -> dict
        # Config-driven swap: real ExecuteQuery API currently fails on
        # repeated @-placeholders inside nested subqueries (confirmed,
        # dev team working on it). When True, values are safely inlined
        # directly into SqlQuery text (see inline_parameters()) and no
        # Parameters field is sent at all -- a fallback, not the
        # preferred path. Flip back to False the moment the real fix
        # lands, no other code changes needed.
        self.use_inline_params = use_inline_params

    # ── SELECT-only safety ──
    def _assert_read_only(self, sql: str) -> None:
        # First significant token must be SELECT or WITH (CTE) — anything else
        # (or a blocked write verb anywhere as a statement) is rejected.
        stripped = sql.strip()
        # remove leading line/block comments defensively
        stripped = re.sub(r"^\s*(--[^\n]*\n|/\*.*?\*/)\s*", "", stripped, flags=re.DOTALL)
        first = re.match(r"\s*(\w+)", stripped)
        if not first or first.group(1).upper() not in {"SELECT", "WITH"}:
            raise UnsafeQueryError("Only SELECT (or WITH ... SELECT) queries are permitted.")

        # Block write verbs appearing as statement verbs (word-boundary, not
        # inside identifiers/strings). Conservative: flag if a blocked keyword
        # appears as a standalone token.
        upper = stripped.upper()
        for kw in self._blocked:
            if re.search(rf"\b{kw}\b", upper):
                raise UnsafeQueryError(f"Blocked keyword '{kw}' present — query rejected.")

    # ── Placeholder / parameter parity (fail closed) ──
    @staticmethod
    def _placeholders_in(sql: str) -> set:
        return {m.group(1) for m in _PLACEHOLDER.finditer(sql)}

    def bind(
        self,
        sql: str,
        security_params: Dict[str, Any],
        resolved_values: Optional[Dict[str, Any]] = None,
        page_number: int = 1,
        page_size: int = 10,
    ) -> BoundRequest:
        """
        Merge trusted security params + resolved master-data values into a single
        Parameters object and verify parity with the SQL's placeholders.

        Args:
            sql: model SQL with @placeholders.
            security_params: from UserContext.to_query_params(), e.g.
                             {"UserId": 2, "SelectedBranchId": None,
                              "AcademicYearID": 7} (D1.3). Keys may be
                             with or without a leading '@' — normalized here.
            resolved_values: from the Value Resolver, e.g. {"ClassName": "Class 10"}.
            page_number/page_size: pagination (ExecuteQuery supports paging).

        Raises:
            UnsafeQueryError        — non-SELECT / blocked verb.
            UnboundParameterError   — placeholder/parameter mismatch.
        """
        self._assert_read_only(sql)

        # Normalize all keys to "@name" form.
        params: Dict[str, Any] = {}
        for src in (security_params or {}, resolved_values or {}):
            for k, v in src.items():
                key = k if k.startswith("@") else f"@{k}"
                params[key] = v

        placeholders = self._placeholders_in(sql)                 # names w/o '@'
        param_names = {k[1:] for k in params.keys()}              # names w/o '@'

        missing = placeholders - param_names
        if missing:
            raise UnboundParameterError(
                "SQL placeholders with no bound value: "
                + ", ".join("@" + m for m in sorted(missing))
            )
        extra = param_names - placeholders
        # Security placeholders (UserId, SelectedBranchId, AcademicYearID) are
        # PRE-RESOLVED by the backend from the trusted Context JSON. The model
        # is ALLOWED to not use them — e.g. it may scope by GETDATE() instead of
        # @AcademicYearID, or it may scope to all branches (no @SelectedBranchId).
        # Silently drop unused security params; only fail for stray NON-security
        # params, which indicate a real mismatch (e.g. resolved value for a
        # placeholder the model didn't emit).
        stray = {e for e in extra if e not in SECURITY_PLACEHOLDERS}
        if stray:
            raise UnboundParameterError(
                "Bound values not referenced by the SQL: "
                + ", ".join("@" + e for e in sorted(stray))
            )
        # Drop the unused security params from the final payload so the
        # ExecuteQuery API doesn't receive parameters the SQL doesn't use.
        if extra:
            unused_keys = {f"@{e}" for e in extra}
            params = {k: v for k, v in params.items() if k not in unused_keys}

        return BoundRequest(
            target_database=self.target_database,
            sql_query=sql,
            parameters=params,
            page_number=page_number,
            page_size=page_size,
        )

    # ── Execute (or preview under dry_run) ──
    def execute(
        self,
        sql: str,
        security_params: Dict[str, Any],
        resolved_values: Optional[Dict[str, Any]] = None,
        page_number: int = 1,
        page_size: int = 10,
    ) -> ExecutionResult:
        # CONFIRMED (direct isolated testing): TOP N fails execution on the
        # real server regardless of other SQL constructs present. Strip it
        # and use PageSize instead -- same row-limiting intent, achieved
        # through the API's own, already-confirmed-reliable mechanism.
        sql, top_n = _extract_top_n(sql)
        if top_n is not None:
            page_size = top_n
            page_number = 1  # "top N" always means the first N, never a later page

        try:
            bound = self.bind(sql, security_params, resolved_values, page_number, page_size)
        except BinderError as e:
            return ExecutionResult(ok=False, error=str(e))

        body = bound.to_body()

        if self.use_inline_params:
            # Swap: same validated sql/parameters, safely inlined instead
            # of bound -- for the confirmed, currently-broken
            # repeated-placeholder limitation on the real server.
            try:
                body["SqlQuery"] = inline_parameters(bound.sql_query, bound.parameters)
            except ValueError as e:
                return ExecutionResult(ok=False, error=f"Inline parameter substitution failed: {e}")
            body["Parameters"] = {}  # values are now in SqlQuery text directly, nothing left to bind

        if self.dry_run:
            # Never hits the network — returns the exact body for inspection.
            return ExecutionResult(ok=True, dry_run=True, request_body=body)

        try:
            raw = self._post(body)
        except Exception as e:  # network / HTTP / parse
            return ExecutionResult(ok=False, request_body=body, error=str(e))

        # `raw` here is the ALREADY double-parsed inner payload (see _post),
        # i.e. the decoded contents of the top-level "d" string:
        #   {Success, Data, RowCount, TotalRowCount, PageNumber, PageSize,
        #    TotalPages, ErrorMessage, ErrorCode}
        if not isinstance(raw, dict):
            return ExecutionResult(ok=False, request_body=body,
                                   error="Unexpected response shape.", raw=raw)

        success = raw.get("Success")
        # Server-reported failure (e.g. SQL error) — surface it, fail closed.
        if success is False:
            return ExecutionResult(
                ok=False, request_body=body, raw=raw, success=False,
                error=raw.get("ErrorMessage") or "Query failed on the server.",
                error_code=raw.get("ErrorCode"),
            )

        rows = raw.get("Data") or []
        total = raw.get("TotalRowCount")
        return ExecutionResult(
            ok=True,
            dry_run=False,
            request_body=body,
            rows=rows,
            total_row_count=total,
            page_number=raw.get("PageNumber", page_number),
            page_size=raw.get("PageSize", page_size),
            total_pages=raw.get("TotalPages"),
            success=True,
            raw=raw,
        )

    # ── HTTP (stdlib; injectable for tests) ──
    def _post(self, body: Dict[str, Any]) -> Any:
        """
        Send the inner payload using the real ExecuteQuery wire format and
        return the ALREADY double-parsed inner response payload.

        Wire out:  { "request": "<stringified inner payload>" }
                   header x-api-key: <key>
        Wire in:   { "d": "<stringified inner response>" }  -> parsed twice.

        The injected test opener (self._http_opener) is given the INNER `body`
        dict directly and is expected to return the INNER response dict, so
        tests don't have to replicate the double-encoding envelope.
        """
        if self._http_opener is not None:
            return self._http_opener(body)  # test seam

        # Envelope: the inner payload is stringified into a top-level "request".
        envelope = {"request": json.dumps(body)}
        data = json.dumps(envelope).encode("utf-8")
        req = urllib.request.Request(self.endpoint_url, data=data, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("Accept", "application/json")
        if self.api_key:
            req.add_header("x-api-key", self.api_key)
        if self.auth_token:
            req.add_header("Authorization", f"Bearer {self.auth_token}")
        with urllib.request.urlopen(req, timeout=self.timeout_seconds) as resp:
            payload = resp.read().decode("utf-8")

        # Parse #1: top-level object with a "d" JSON string.
        try:
            outer = json.loads(payload)
        except json.JSONDecodeError:
            return {"raw_text": payload}
        # Parse #2: "d" itself is a stringified JSON payload.
        d = outer.get("d") if isinstance(outer, dict) else None
        if isinstance(d, str):
            try:
                return json.loads(d)
            except json.JSONDecodeError:
                return {"raw_text": d}
        # Some environments may already return a parsed object.
        return d if isinstance(d, dict) else outer

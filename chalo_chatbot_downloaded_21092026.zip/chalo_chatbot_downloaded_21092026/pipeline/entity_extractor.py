"""
entity_extractor.py — feeds orchestrator.py's VALIDATE stage.

Matches the exact interface orchestrator.py's __init__ expects:
    extract_values(sql, branch_vocab) -> List[Dict[str, str]]
    each item: {"concept_type": ..., "value": ...}

SECTION IS INCLUDED, wired against context_vocab.py's CONCEPT_TO_JSON_KEY
(now has "SECTION": "Sections", sourced locally via generate_branch_
contexts.py until the dev team's real API adds it).

IN-LIST HANDLING (important, found via real testing): the model often
writes alternative-spelling hedges like cm.Name IN ('Class 10', 'X') --
offering both an Arabic and Roman-numeral name, expecting the database
to match whichever is real for the branch. These are NOT independent
values that must each be individually valid -- they're one logical
class, offered as alternatives. If checked one at a time with immediate
refusal on the first miss, a real match later in the same list never
gets a chance. So IN-lists are validated AS A GROUP here, using the
branch_vocab already passed in: if ANY candidate in the group is a real
member, nothing gets returned for that group at all (the model already
found its match). Only if NONE match does one representative value get
returned for the orchestrator to disambiguate/refuse on.

⚠️ ROUND-2 EXTENSIONS:
  - D1.13: added FEE_TERM pattern `tm.Name = '...'` (TermMaster alias tm).
    Per the schema audit, FEE terms live in TermMaster (NOT ExamTermMaster),
    and `tm` is the established alias for TermMaster across the SP corpus
    (sp_TermMaster_SelectAll etc.). The model is expected to use `tm.Name`
    when filtering fee terms. This extractor routes that literal into the
    FEE_TERM concept type for validation against the branch's FeeTerms vocab
    (populated via add_fee_terms_fallback when the API doesn't supply it).
  - EXPERIMENTAL: added a designation/role pattern `r.Name = '...'`
    (UserAccountRoleMaster alias `r`). This is EXPERIMENTAL — the alias
    `r` is short and could plausibly belong to other tables in some
    queries (RoleMaster, ReligionMaster, RegionMaster). Marked
    `_EXPERIMENTAL_DESIGNATION` so the orchestrator can opt-in via config.
    The original `et.` (ExamTypeMaster vs ExamTermMaster ambiguity) and
    `s.` (Student_Master vs Subject_Master) exclusions are KEPT — confirmed
    real collision risk in the v27 dataset.

Reconstructed from the original app_layer/ code + round-2 extensions.
Diff against your real files before deploying.
"""
import re

# (concept_type, pattern-for-IN-lists, pattern-for-single-equals)
_GROUPED_PATTERNS = [
    ("CLASS", re.compile(r"\bcm\.Name\s+IN\s*\(([^)]+)\)", re.IGNORECASE)),
    ("SECTION", re.compile(r"\bsecm\.Name\s+IN\s*\(([^)]+)\)", re.IGNORECASE)),
]

_SINGLE_PATTERNS = [
    ("CLASS", re.compile(r"\bcm\.Name\s*=\s*'([^']+)'", re.IGNORECASE)),
    ("SECTION", re.compile(r"\bsecm\.Name\s*=\s*'([^']+)'", re.IGNORECASE)),
    # CONFIRMED against the real v16 dataset: Subject_Master uses aliases
    # "sub", "s", AND "s2" -- "s2" added here since it's unambiguous
    # (confirmed only ever used for Subject_Master). "s" is deliberately
    # EXCLUDED: confirmed the SAME alias is also used for Student_Master
    # in real training examples -- adding it would misfire, attempting to
    # validate student names as subjects. A real gap, left open rather
    # than guessed at; would need per-query join-context awareness this
    # simple regex approach doesn't have.
    ("SUBJECT", re.compile(r"\b(?:sub(?:ject)?|s2)\.Name\s*=\s*'([^']+)'", re.IGNORECASE)),
    ("ENQUIRY_STATUS", re.compile(r"\b(?:es|Enquiry_?Status)\.?Name\s*=\s*'([^']+)'", re.IGNORECASE)),
    # CONFIRMED: Fees_Master also uses "fmm" in real examples, unambiguous
    # (confirmed only ever used for Fees_Master) -- added.
    ("FEE_HEAD", re.compile(r"\b(?:fm|fmm|Fees?_?Master)\.Name\s*=\s*'([^']+)'", re.IGNORECASE)),
    # CONFIRMED: "et" is deliberately EXCLUDED here -- the real dataset
    # uses "et" for BOTH ExamTypeMaster and ExamTermMaster, which are
    # different concepts. Adding it risks validating an exam-type value
    # against exam-term vocabulary (or vice versa). Left open rather than
    # guessed at, same reasoning as the Subject_Master "s" exclusion above.
    ("EXAM_TERM", re.compile(r"\betm\.Name\s*=\s*'([^']+)'", re.IGNORECASE)),
    # ── D1.13: FEE_TERM — TermMaster alias tm. The schema audit confirmed
    # FEE terms live in TermMaster (NOT ExamTermMaster); the alias `tm` is
    # the established convention for TermMaster across the SP corpus.
    ("FEE_TERM", re.compile(r"\btm\.Name\s*=\s*'([^']+)'", re.IGNORECASE)),
]

# EXPERIMENTAL — designation/role literal (UserAccountRoleMaster alias `r`).
# The alias `r` is short and could collide with RoleMaster/ReligionMaster/
# RegionMaster in some queries. NOT enabled by default — the orchestrator
# must opt in by passing `extract_experimental_designation=True` (or by
# editing _SINGLE_PATTERNS to include this entry). Kept here as a documented
# experiment pending v28 dataset coverage confirmation.
_EXPERIMENTAL_DESIGNATION = (
    "DESIGNATION",
    re.compile(r"\br\.Name\s*=\s*'([^']+)'", re.IGNORECASE),
)


def extract_values(sql: str, branch_vocab=None,
                    include_experimental: bool = False) -> list[dict]:
    """
    Extract candidate master-data literals from `sql` for VALIDATE.

    Args:
        sql: the T-SQL query.
        branch_vocab: optional BranchVocab with `is_member(concept_type, value)`
            — used to validate IN-lists as a group (a real match in any one
            candidate suppresses the whole group).
        include_experimental: opt-in for the experimental `r.Name = '...'`
            designation/role pattern (D1.13 experimental). Default False —
            leave it OFF until v28 dataset coverage is confirmed.

    Returns: list of {"concept_type": ..., "value": ...} dicts.
    """
    found = []

    # IN-lists: validate as a group. If branch_vocab isn't available for
    # some reason, fall back to returning every candidate individually
    # (safe default -- more likely to over-flag than to silently miss).
    for concept_type, pattern in _GROUPED_PATTERNS:
        for m in pattern.finditer(sql):
            raw = m.group(1)
            candidates = [v.strip() for v in re.findall(r"'([^']+)'", raw)]
            if not candidates:
                continue
            if branch_vocab is not None and hasattr(branch_vocab, "is_member"):
                if any(branch_vocab.is_member(concept_type, c) for c in candidates):
                    continue  # at least one real match — the model's hedge worked
                found.append({"concept_type": concept_type, "value": candidates[0]})
            else:
                for c in candidates:
                    found.append({"concept_type": concept_type, "value": c})

    # Single-value patterns: no grouping ambiguity, check directly.
    patterns = list(_SINGLE_PATTERNS)
    if include_experimental:
        patterns.append(_EXPERIMENTAL_DESIGNATION)
    for concept_type, pattern in patterns:
        for m in pattern.finditer(sql):
            found.append({"concept_type": concept_type, "value": m.group(1).strip()})

    return found

"""
AI Secretary — Application Layer :: Dataset Lookup (latency fast-path)
========================================================================

Purpose
-------
Before calling the LLM, check whether the incoming question matches a
training-dataset example closely enough to reuse its already-verified
SQL directly — skipping generation entirely for that case.

HONEST SCOPE, STATED PLAINLY: this only helps for questions that are the
same or nearly the same as a training example, INCLUDING the same
parameter values ("Class 7" only matches "Class 7", not "Class 9").
Real template-based parameter substitution (recognizing "Class 7" as a
variable slot, generalizing to any class) is a materially bigger,
separate piece of engineering, not attempted here. This is a real,
useful latency win for repeated/near-repeated questions -- not a general
solution -- and the LLM remains the fallback for everything else.

Normalization matches the same discipline as value_resolver.py's
_normalize() (lowercase, strip punctuation/whitespace) -- applied to the
whole question string here, not a single value.

WHY A SEPARATE STEP, NOT REPLACING VALUE-LEVEL FUZZY MATCHING: this is
question-level matching (is this the SAME question as one already seen),
entirely distinct from value_resolver.py's job (is THIS VALUE, inside an
already-generated query, a real one for this branch). Both can run in the
same pipeline without conflict -- this decides whether the LLM runs
at all; value_resolver still validates whatever SQL is ultimately used,
whether it came from here or from the LLM.

⚠️ ROUND-2 EXTENSION (D1.9): the fast-paths (dataset_lookup AND the
template lookups in template_lookups.py) are now gated by a
`fast_paths_enabled` flag (default False). The orchestrator checks this
flag before consulting ANY fast-path. The original code unconditionally
consulted them when the lookup instance was wired in, which let
label-noise in the training dataset silently leak into live answers
before the labels were cleaned. Default OFF in production until the
labels are verified clean; tests can flip it ON explicitly via the
constructor arg. The orchestrator is the single gate — individual lookups
remain pure (no global state), so they're trivially testable.

Reconstructed from the original app_layer/dataset_lookup.py + round-2
D1.9 gate. Diff against your real files before deploying.
"""

from __future__ import annotations

import json
import re
from typing import Dict, Optional


_PUNCT = re.compile(r"[^\w\s]")
_WS = re.compile(r"\s+")


def _normalize(question: str) -> str:
    """
    Same normalization discipline as value_resolver.py's _normalize():
    lowercase, strip punctuation, collapse whitespace. Deliberately does
    NOT do anything more aggressive (no synonym expansion, no stemming)
    -- this is meant to catch near-identical phrasing (trailing "?",
    extra spaces, casing), not paraphrases, which is a different,
    materially riskier problem (a wrong cache hit on a paraphrase could
    silently answer a different question than the one asked).
    """
    q = question.strip().lower()
    q = _PUNCT.sub("", q)
    q = _WS.sub(" ", q).strip()
    return q


# ── FILLER-TOLERANT normalization (2026-09-06) ───────────────────────────────
# Strips semantically empty filler phrases so "how many students are there in
# class 7" and "how many students in class 7" share one index key. Audited
# against the real train_v28.jsonl: with exactly this list 1,744 previously
# unreachable phrasings become instant (+47% instant coverage); only 6
# stripped keys map to >1 distinct SQL, and _build_loose_index EXCLUDES those
# entirely — so a filler-tolerant hit is always the dataset's single verified
# SQL for that question shape. Deliberately does NOT strip meaning-bearing
# words ("my", "not", "without", "top", "bottom", numbers, class/section/
# subject words).
_FILLER_RES = tuple(re.compile(p) for p in (
    r"\bare there\b",
    r"\bis there\b",
    r"\bcan you tell me\b",
    r"\btell me\b",
    r"\bplease\b",
    r"\bthe\b",
    r"\bare\b",
    r"\bis\b",
    r"\bwas\b",
    r"\bwere\b",
    r"\bdo we have\b",
    r"\bcan you\b",
))


def _strip_fillers(question: str) -> str:
    q = _normalize(question)
    for rx in _FILLER_RES:
        q = rx.sub(" ", q)
    return _WS.sub(" ", q).strip()


# Public alias (2026-09-09, v63 quick-win batch): template_lookups.py reuses the
# SAME filler discipline for its template keys so "how many students are in 8"
# and "How many students are there in class 10?" collapse to one template key.
# One source of truth for the filler list — do not copy the regexes elsewhere.
def strip_fillers(question: str) -> str:
    return _strip_fillers(question)


class DatasetLookup:
    """
    Loads a training dataset (JSONL, {"input": ..., "output": ...} per
    line) once and provides fast, normalized-exact lookup.

    Usage:
        lookup = DatasetLookup("training_dataset_final_v17.jsonl")
        sql = lookup.find(question)  # None if no match -- caller falls
                                       # back to the LLM as normal.

    The `enabled` flag (D1.9) is informational — the orchestrator is the
    single gate that decides whether to consult this lookup at all. It
    defaults to True here (the lookup is harmless when constructed); the
    orchestrator's `fast_paths_enabled` (default False) is the
    production switch.
    """

    def __init__(self, dataset_path: str, enabled: bool = True):
        self._index: Dict[str, str] = {}
        self._loose: Dict[str, str] = {}
        self.enabled = enabled
        self._load(dataset_path)
        self._build_loose_index(dataset_path)

    def _load(self, path: str) -> None:
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                record = json.loads(line)
                question = record.get("input", "")
                sql = record.get("output", "")
                if not question or not sql:
                    continue
                key = _normalize(question)
                # First occurrence wins if duplicates somehow exist --
                # dataset is already confirmed duplicate-free, but fail
                # safe rather than silently overwrite.
                self._index.setdefault(key, sql)

    def find(self, question: str) -> Optional[str]:
        """Returns the matched SQL, or None if no match exists (caller falls
        back to the template lookups, then the LLM, as normal)."""
        if not self.enabled:
            return None
        hit = self._index.get(_normalize(question))
        if hit is not None:
            return hit
        # FILLER-TOLERANT fallback (2026-09-06): same verified SQL for
        # questions that differ ONLY by semantically empty filler words.
        # Collision-excluded at build time — see _build_loose_index.
        return self._loose.get(_strip_fillers(question))

    def _build_loose_index(self, path: str) -> None:
        """Secondary index keyed on filler-stripped normalization, built from
        the same dataset as the exact index. A stripped key is stored ONLY
        when it maps to EXACTLY ONE distinct SQL across the whole dataset
        (including records whose exact key equals the stripped key) — so a
        loose hit can never disagree with the exact index about what the
        right SQL for a question shape is. First-occurrence wins among
        byte-identical SQL strings. Any read error disables the loose index
        (fail-safe: exact matching + LLM fallback continue to work)."""
        from collections import defaultdict
        candidates: Dict[str, set] = defaultdict(set)
        try:
            with open(path, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    record = json.loads(line)
                    question = record.get("input", "")
                    sql = record.get("output", "")
                    if not question or not sql:
                        continue
                    candidates[_strip_fillers(question)].add(sql)
        except Exception:
            self._loose = {}
            return
        self._loose = {k: sorted(v)[0] for k, v in candidates.items() if len(v) == 1}

    def __len__(self) -> int:
        return len(self._index)

"""
AI Secretary — Application Layer :: Branch-Scoping Security Gate (Component #6)
==================================================================================

Purpose
-------
An INDEPENDENT, structural check that every generated SELECT genuinely
contains an intact, real branch-scoping clause tying results to the
authenticated @UserId — checked BEFORE execution, without trusting the
model to have gotten it right.

WHY THIS EXISTS (the real gap it closes): every other check in this
pipeline verifies something else -- the schema guardrail checks tables/
columns exist and blocks write verbs; alias_scope_check.py checks
Msg 4104/209-style scoping bugs; the value resolver validates that
specific VALUES are real. NONE of them verify that the security
boilerplate itself is present and unmodified. The entire branch-
isolation guarantee currently rests on the model reliably reproducing
that boilerplate every time -- reinforced by training, never
independently verified. This project has already confirmed, repeatedly,
that the model has a real reliability gap (sometimes failing to
reproduce even a verbatim, directly-trained pattern). This module
assumes that gap can appear here too, and checks for it directly rather
than trusting training alone.

WHAT THIS DOES NOT CLAIM: it does not detect every conceivable SQL
injection or prompt-injection technique. It verifies one specific,
concrete thing -- that the real UserAccountRoleDetails-based
@UserId -> BranchID linkage is present, intact, and actually being used
to constrain the query -- structurally, not by trusting surface text.
Prompt injection attempts that produce SQL WITHOUT this linkage are
caught here; ones that somehow produce SQL WITH an intact linkage but
are wrong in some other way are not this module's job (guardrail,
alias_scope_check, and VALIDATE cover different failure classes).

FAILS CLOSED: if this check cannot confidently confirm the scoping is
genuinely present and intact, it refuses. It never guesses that
scoping is "probably fine."

NOTE ON ROUND-2 F1: the F1 finding ("too strict for BranchMaster-as-target")
is documented but the fix is in the orchestrator's intent-classifier, NOT
this gate. Per task spec, this gate is left unchanged.

Reconstructed from the original app_layer/ code (no round-2 changes — unchanged).
Diff against your real files before deploying.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List, Optional
from functools import lru_cache


@dataclass
class BranchScopingResult:
    is_valid: bool
    reason: Optional[str] = None
    matched_pattern: Optional[str] = None  # "inline" | "cte" -- which real pattern was found


# ── Strip comments and string literals first, so a scoping clause
#    hidden inside a comment or a quoted string never counts as real. ──
_LINE_COMMENT = re.compile(r"--[^\n]*")
_BLOCK_COMMENT = re.compile(r"/\*.*?\*/", re.DOTALL)
_STRING_LITERAL = re.compile(r"'(?:[^']|'')*'")


def _strip_comments_and_strings(sql: str) -> str:
    """
    Removes comments and string literal CONTENTS (replacing them with a
    same-length placeholder, not deleting -- preserves overall structure/
    positions so this remains a reliable substring to search, while
    guaranteeing nothing inside a comment or a quoted string can be
    mistaken for real, executable scoping logic).
    """
    sql = _BLOCK_COMMENT.sub(lambda m: " " * len(m.group(0)), sql)
    sql = _LINE_COMMENT.sub(lambda m: " " * len(m.group(0)), sql)
    sql = _STRING_LITERAL.sub(lambda m: "'" + "X" * (len(m.group(0)) - 2) + "'", sql)
    return sql


# The real, established linkage: @UserId tied to UserAccountRoleDetails
# via an actual UserID = @UserId filter -- not just both terms appearing
# somewhere, but genuinely connected. This is deliberately specific
# rather than a loose "mentions BranchID somewhere" check, since a loose
# check is exactly the kind of thing an adversarial or malformed query
# could satisfy without any real scoping at all.
_REAL_USERID_LINKAGE = re.compile(
    r"UserAccountRoleDetails\s+WHERE\s+UserID\s*=\s*@UserId", re.IGNORECASE
)

# CONFIRMED via direct testing against the real dataset: the outer column
# wrapping this linkage varies by which table is being scoped --
# "X.BranchID IN (...)" for tables with a BranchID foreign key,
# "X.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details WHERE ...
# Branch_Id IN (...))" for the indirect academic-year path (220 of 2,413
# real examples use exactly this, confirmed), and "bm.ID IN (...)" when
# BranchMaster itself is the table being queried. Enumerating every
# specific column name is fragile and would need updating for every new
# variant. Instead: verify the subquery CONTAINING the real linkage is
# itself preceded by "IN" within a short distance -- i.e. actually used
# as a filter somewhere, regardless of what the outer column is called.
_USAGE_LOOKBACK_CHARS = 120  # expanded to capture longer column expressions


def _is_actually_used_as_filter(clean_sql: str, linkage_match: re.Match) -> bool:
    """
    Walks outward from the real linkage to find the nearest enclosing
    "(SELECT ... FROM UserAccountRoleDetails" or CTE-reference opening
    paren, then checks whether "IN" appears shortly before that paren --
    confirming this subquery is genuinely being used to filter something,
    not just present as inert, unused text.
    """
    # Find the start of the subquery/CTE this linkage lives inside: walk
    # backward from the linkage to the nearest unmatched "(".
    pos = linkage_match.start()
    depth = 0
    i = pos
    while i > 0:
        i -= 1
        if clean_sql[i] == ')':
            depth += 1
        elif clean_sql[i] == '(':
            if depth == 0:
                break
            depth -= 1
    # i now points at the opening "(" of the enclosing subquery (or 0 if
    # none found, meaning the linkage sits at the top level -- not a
    # valid filterable position either way).
    if i <= 0:
        return False
    lookback_start = max(0, i - _USAGE_LOOKBACK_CHARS)
    preceding_text = clean_sql[lookback_start:i]
    return bool(re.search(r"\bIN\s*$", preceding_text, re.IGNORECASE))


_CTE_DEFINITION = re.compile(
    r"WITH\s+(\w+)\s+AS\s*\(", re.IGNORECASE
)


def _cte_containing_linkage(clean_sql: str, linkage_pos: int) -> Optional[str]:
    """If the real linkage sits inside a CTE's own definition, returns
    that CTE's name; otherwise None. Needed because a CTE definition's
    opening paren is preceded by "cte_name AS", not "IN" -- the general
    lookback check below doesn't apply to a CTE's own definition, only
    to where the CTE is later USED."""
    for m in _CTE_DEFINITION.finditer(clean_sql):
        def_start = m.end() - 1  # position of the CTE's own opening "("
        depth = 0
        i = def_start
        end = len(clean_sql)
        for i in range(def_start, end):
            if clean_sql[i] == '(':
                depth += 1
            elif clean_sql[i] == ')':
                depth -= 1
                if depth == 0:
                    break
        if def_start <= linkage_pos <= i:
            return m.group(1)
    return None


@lru_cache(maxsize=1024)
def check_branch_scoping(sql: str) -> BranchScopingResult:
    """
    Verifies the generated SQL genuinely, structurally contains an
    intact branch-scoping clause tied to the real, authenticated
    @UserId -- independent of whether the model "should" have included
    it. Called before EXECUTE, alongside (not instead of) the existing
    guardrail/alias_scope_check/VALIDATE stages.
    """
    if not sql or not sql.strip():
        return BranchScopingResult(is_valid=False, reason="Empty query.")

    clean = _strip_comments_and_strings(sql)

    linkage_match = _REAL_USERID_LINKAGE.search(clean)
    if not linkage_match:
        return BranchScopingResult(
            is_valid=False,
            reason=(
                "No genuine UserAccountRoleDetails WHERE UserID = @UserId linkage "
                "found -- the query does not appear to be scoped to the "
                "authenticated user at all."
            ),
        )

    # Path 1: is the linkage ALREADY directly used as a filter right where
    # it sits -- covers both non-CTE cases AND CTEs where the filter is
    # applied inside the CTE's own body (the CTE already contains only
    # scoped data; the outer query needs no further check). Tried first
    # since it's the more common, more direct shape.
    if _is_actually_used_as_filter(clean, linkage_match):
        return BranchScopingResult(is_valid=True, matched_pattern="direct-or-indirect")

    # Path 2: only reached if the linkage ISN'T already directly wrapped
    # by its own IN (...) -- the remaining valid shape is a CTE whose
    # ENTIRE body IS the raw lookup query itself (e.g. "AllowedBranches":
    # just SELECT BranchID FROM UserAccountRoleDetails WHERE ..., with no
    # wrapping IN needed inside the CTE, since producing that list IS the
    # CTE's job). This is only safe if the CTE is actually referenced via
    # IN (...) somewhere else -- an unused CTE like this provides nothing.
    cte_name = _cte_containing_linkage(clean, linkage_match.start())
    if cte_name is not None:
        usage_pattern = re.compile(
            rf"\bIN\s*\(\s*SELECT\s+\w+\s+FROM\s+{re.escape(cte_name)}\b", re.IGNORECASE
        )
        if usage_pattern.search(clean):
            return BranchScopingResult(is_valid=True, matched_pattern="cte")
        return BranchScopingResult(
            is_valid=False,
            reason=(
                f"A CTE '{cte_name}' with genuine UserID = @UserId scoping is "
                f"defined, but never actually referenced via an IN (...) filter "
                f"anywhere else in the query -- defined-but-unused scoping "
                f"provides no real protection."
            ),
        )

    return BranchScopingResult(
        is_valid=False,
        reason=(
            "A UserAccountRoleDetails/@UserId reference exists, but it does not "
            "appear to be actually used as an IN (...) filter anywhere -- "
            "cannot confirm the query is genuinely scoped, not just containing "
            "inert/unused text that happens to mention the right table."
        ),
    )

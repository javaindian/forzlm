"""
AI Secretary — Application Layer :: Concept Store (SQLite backing for Component #2)
==================================================================================

Storage for the two concept tables described in the App Layer PRD §6:

    AISecretary_ConceptSynonym  (global)   — how people phrase a concept.
    AISecretary_ConceptMapping  (per-branch) — the branch's real stored value.

SQLite is used for now (matches the existing stack); the schema is intentionally
close to the PRD's SQL Server DDL so a later swap is mechanical.

⚠️ ROUND-2 STATUS — LEGACY COMPAT LAYER. The new vocab engine
(/home/z/my-project/chalo_chatbot/vocab/inject.py + vocab/synonyms.json)
SUPERSEDES this module for the live pipeline: synonyms are now loaded from
synonyms.json via `SynonymStore`, and the per-branch vocab comes from the
Context JSON via context_vocab.BranchVocab (NOT from a maintained
ConceptMapping table). The original code paths still reference
ConceptStore (ValueResolver legacy path, value_resolver's `_canonical_terms`
fallback when no SynonymStore is wired), so this module is retained as a
compat layer — unchanged from the original. Do not extend it; new work goes
into the vocab engine. See value_resolver.py's `ValueValidator` for the
live path.

No hardcoded paths (Bible Rule 1): the DB path is passed in or derived from an
env var / caller. No client names anywhere.

Reconstructed from the original app_layer/ code (no round-2 changes — retained
as legacy compat). Diff against your real files before deploying.
"""

from __future__ import annotations

import os
import sqlite3
from typing import List, Optional, Dict, Any


# ── Schema (SQLite dialect, mirrors PRD §6 SQL Server tables) ──
_SCHEMA = """
CREATE TABLE IF NOT EXISTS AISecretary_ConceptSynonym (
    ID          INTEGER PRIMARY KEY AUTOINCREMENT,
    ConceptType TEXT NOT NULL,          -- CLASS / SUBJECT / ENQUIRY_STATUS / EXAM_TERM / ...
    ConceptKey  TEXT NOT NULL,          -- internal key, e.g. GRADE_10
    UserTerm    TEXT NOT NULL           -- a phrasing, e.g. "Class 10", "10th"
);
CREATE INDEX IF NOT EXISTS ix_synonym_type ON AISecretary_ConceptSynonym(ConceptType);

CREATE TABLE IF NOT EXISTS AISecretary_ConceptMapping (
    ID            INTEGER PRIMARY KEY AUTOINCREMENT,
    BranchID      INTEGER,              -- NULL applies globally; else branch-specific
    ConceptType   TEXT NOT NULL,
    ConceptKey    TEXT NOT NULL,
    SourceTable   TEXT NOT NULL,        -- real table the value lives in, e.g. ClassMaster
    DatabaseValue TEXT NOT NULL,        -- exact real value for this branch, e.g. 'X'
    IsActive      INTEGER NOT NULL DEFAULT 1   -- soft-disable without deleting
);
CREATE INDEX IF NOT EXISTS ix_mapping_lookup
    ON AISecretary_ConceptMapping(ConceptType, ConceptKey, BranchID, IsActive);
"""


class ConceptStore:
    """Thin data-access layer over the two concept tables (SQLite).

    LEGACY COMPAT — see module docstring. The new vocab engine
    (vocab/inject.py SynonymStore) is the preferred synonym source; this
    class is kept only for the original ValueResolver (table-substitution)
    code path and any offline tooling that still reads it.
    """

    def __init__(self, db_path: str):
        """
        Args:
            db_path: filesystem path to the SQLite DB, or ":memory:" for tests.
                     Derived by the caller (no hardcoding here).
        """
        self.db_path = db_path
        if db_path != ":memory:":
            parent = os.path.dirname(os.path.abspath(db_path))
            os.makedirs(parent, exist_ok=True)
            self._conn = sqlite3.connect(db_path)
        else:
            # Keep a single shared in-memory connection alive for the object's life.
            self._conn = sqlite3.connect(":memory:")
        self._conn.row_factory = sqlite3.Row
        self.init_schema()

    def init_schema(self) -> None:
        self._conn.executescript(_SCHEMA)
        self._conn.commit()

    # ── Synonyms ──
    def add_synonym(self, concept_type: str, concept_key: str, user_term: str) -> None:
        self._conn.execute(
            "INSERT INTO AISecretary_ConceptSynonym (ConceptType, ConceptKey, UserTerm) "
            "VALUES (?, ?, ?)",
            [concept_type, concept_key, user_term],
        )
        self._conn.commit()

    def synonyms_for_type(self, concept_type: str) -> List[Dict[str, Any]]:
        """All (ConceptKey, UserTerm) synonyms for a concept type (global)."""
        cur = self._conn.execute(
            "SELECT ConceptKey, UserTerm FROM AISecretary_ConceptSynonym "
            "WHERE ConceptType = ?",
            [concept_type],
        )
        return [dict(r) for r in cur.fetchall()]

    # ── Mappings ──
    def add_mapping(
        self,
        concept_type: str,
        concept_key: str,
        source_table: str,
        database_value: str,
        branch_id: Optional[int] = None,
        is_active: bool = True,
    ) -> None:
        self._conn.execute(
            "INSERT INTO AISecretary_ConceptMapping "
            "(BranchID, ConceptType, ConceptKey, SourceTable, DatabaseValue, IsActive) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            [branch_id, concept_type, concept_key, source_table, database_value,
             1 if is_active else 0],
        )
        self._conn.commit()

    def mappings_for_key(
        self, concept_type: str, concept_key: str, branch_id: int
    ) -> List[Dict[str, Any]]:
        """
        Active mappings resolving (concept_type, concept_key) for a branch.

        Branch-specific rows (BranchID = branch_id) take precedence; global rows
        (BranchID IS NULL) act as a fallback only when no branch-specific row
        exists. Returned list is what the resolver inspects for 0 / 1 / 2+ logic.
        """
        cur = self._conn.execute(
            "SELECT BranchID, SourceTable, DatabaseValue "
            "FROM AISecretary_ConceptMapping "
            "WHERE ConceptType = ? AND ConceptKey = ? AND IsActive = 1 "
            "AND (BranchID = ? OR BranchID IS NULL)",
            [concept_type, concept_key, branch_id],
        )
        rows = [dict(r) for r in cur.fetchall()]

        branch_specific = [r for r in rows if r["BranchID"] is not None]
        if branch_specific:
            return branch_specific        # branch rows win outright
        return [r for r in rows if r["BranchID"] is None]  # else global fallback

    def mappings_for_type(self, concept_type: str, branch_id: int) -> List[Dict[str, Any]]:
        """
        Every active mapping for a concept TYPE at a branch — the branch's full
        vocabulary for that concept (used by the Disambiguation Handler to offer
        the branch's own real values on a no_match).

        Branch-specific rows take precedence over global (BranchID IS NULL) rows
        for the SAME ConceptKey; global rows appear only for keys that have no
        branch-specific row. Ordered by DatabaseValue for a stable UI.
        """
        cur = self._conn.execute(
            "SELECT BranchID, ConceptKey, SourceTable, DatabaseValue "
            "FROM AISecretary_ConceptMapping "
            "WHERE ConceptType = ? AND IsActive = 1 "
            "AND (BranchID = ? OR BranchID IS NULL) "
            "ORDER BY DatabaseValue",
            [concept_type, branch_id],
        )
        rows = [dict(r) for r in cur.fetchall()]

        # Per ConceptKey, prefer branch-specific rows; fall back to global.
        keys_with_branch = {
            r["ConceptKey"] for r in rows if r["BranchID"] is not None
        }
        result = []
        for r in rows:
            if r["BranchID"] is not None:
                result.append(r)                       # branch-specific: always
            elif r["ConceptKey"] not in keys_with_branch:
                result.append(r)                       # global only if no branch row
        return result

    def close(self) -> None:
        self._conn.close()

"""
AI Secretary — Application Layer :: Template Lookups (latency fast-paths)
==========================================================================

Combines the four template-based lookups (class / section / top-N /
class+section compressed) into one module so the orchestrator imports them
from one place. Each class is reconstructed faithfully from the original
app_layer/<name>_template_lookup.py — same logic, same dataset coverage
checks, same contamination guards. See each class's docstring for its
specific scope.

⚠️ ROUND-2 EXTENSION (D1.9): each lookup has an `enabled` flag (default
True — harmless when constructed). The ORCHESTRATOR's `fast_paths_enabled`
config flag (default False) is the single production gate — when it's
OFF, the orchestrator skips every fast-path entirely and goes straight to
the LLM. The individual lookups remain pure (no global state), so they're
trivially testable in isolation. The gate is the orchestrator's
responsibility to enforce, not these classes'.

Reconstructed from the original app_layer/ template_lookup files + round-2
D1.9 gate. Diff against your real files before deploying.
"""

from __future__ import annotations

import json
import re
from typing import Dict, Optional, Set, Tuple


_PUNCT = re.compile(r"[^\w\s]")
_WS = re.compile(r"\s+")


def _normalize(text: str) -> str:
    """Lowercase + strip punctuation + collapse whitespace. Same discipline
    as dataset_lookup.py / value_resolver.py — only catches near-identical
    phrasing (trailing "?", casing, spacing), never paraphrases."""
    t = text.strip().lower()
    t = _PUNCT.sub("", t)
    t = _WS.sub(" ", t).strip()
    return t


# ═══════════════════════════════════════════════════════════════════════════
#  ClassTemplateLookup — generalized class-number substitution
# ═══════════════════════════════════════════════════════════════════════════

class ClassTemplateLookup:
    """
    An extension of dataset_lookup.py's exact-match idea: instead of only
    matching a question that's IDENTICAL to a training example, this
    recognizes when a question matches a training example's STRUCTURE with
    a DIFFERENT class number, and substitutes the right value back into the
    already-verified SQL -- e.g. a training example for "Class 7" can now
    also correctly answer "Class 9", "Class 3", etc., without the LLM.

    CONFIRMED SCOPE, NOT ASSUMED: checked directly against the real dataset
    -- 131 of 2,405 examples have BOTH a class mention in the question text
    AND the exact cm.Name IN ('Class N', 'ROMAN') SQL pattern this depends
    on. Each of those 131 effectively covers up to 12 real questions (one
    per grade) instead of just 1. Examples using a different SQL shape for
    class filtering (69 found) are NOT covered by this -- they fall through
    to the LLM exactly as before, same as any other cache miss.

    SAFETY: the substituted SQL still goes through the full normal
    pipeline afterward (guardrail, alias_scope_check, VALIDATE, EXECUTE) --
    this only decides what SQL text to try, it does not bypass any of the
    existing safety checks. A wrong substitution would be caught by
    VALIDATE the same way a wrong LLM generation would be.

    DELIBERATELY NOT GENERALIZED further than Class in this pass -- Section,
    Subject, dates, etc. would each need their own detection/substitution
    logic and their own real-dataset coverage check, not assumed to work
    the same way.
    """

    _GRADE_WORDS = {
        "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6,
        "seven": 7, "eight": 8, "nine": 9, "ten": 10, "eleven": 11, "twelve": 12,
    }
    _ROMAN_TO_NUM = {"i": 1, "ii": 2, "iii": 3, "iv": 4, "v": 5, "vi": 6, "vii": 7,
                     "viii": 8, "ix": 9, "x": 10, "xi": 11, "xii": 12}
    _NUM_TO_ROMAN = {v: k.upper() for k, v in _ROMAN_TO_NUM.items()}

    _QUESTION_PATTERNS = [
        re.compile(r'\bclass\s+(\d{1,2})\b', re.IGNORECASE),
        re.compile(r'\b(\d{1,2})(st|nd|rd|th)\s*(standard|std|grade)?\b', re.IGNORECASE),
        re.compile(r'\b(\d{1,2})\s+std\b', re.IGNORECASE),
        re.compile(r'\bstd\.?\s+(\d{1,2})\b', re.IGNORECASE),
        re.compile(r'\bgrade\s+(\d{1,2})\b', re.IGNORECASE),
        re.compile(r'\bclass\s+([a-zA-Z]+)\b', re.IGNORECASE),
        # v63 quick-win (2026-09-09): BARE class number — "how many students are
        # in 8" / "students of 10". Lookbehind keeps the preposition in the
        # question (span = the number ONLY), so the templatized key keeps the
        # same shape as dataset rows built with the explicit patterns
        # ("...there in class 10?" → "how many students in {{CLASS}}").
        # Fixed-width lookbehinds (Python re limitation), one per preposition.
        # Deliberately LAST so explicit forms above always win. SAFETY NETS:
        # (1) the templatized key must EXIST in the index built from verified
        # dataset rows — "marks above 90" / "fee between 10000 and 20000" can
        # never templatize; (2) first-occurrence guard in _find_class_in_question
        # (a bare "8" already present earlier in the question skips the match);
        # (3) 1-12 range enforced there too. A miss still falls to the LLM.
        re.compile(r'(?<=\bin\s)(\d{1,2})\b', re.IGNORECASE),
        re.compile(r'(?<=\bfor\s)(\d{1,2})\b', re.IGNORECASE),
        re.compile(r'(?<=\bfrom\s)(\d{1,2})\b', re.IGNORECASE),
        re.compile(r'(?<=\bof\s)(\d{1,2})\b', re.IGNORECASE),
    ]
    _SQL_CLASS_PATTERN = re.compile(r"cm\.Name IN \('Class \d{1,2}', '[IVX]+'\)")

    def __init__(self, dataset_path: str, enabled: bool = True):
        self._templates: Dict[str, str] = {}  # templated_question -> templated_sql
        self.enabled = enabled
        self._load(dataset_path)

    @classmethod
    def _find_class_in_question(cls, text: str) -> Optional[Tuple[str, int]]:
        for pattern in cls._QUESTION_PATTERNS:
            m = pattern.search(text)
            if not m:
                continue
            # v63 first-occurrence guard: _templatize_question() replaces the
            # FIRST occurrence of the matched span. If the span text appears
            # EARLIER in the question too (e.g. a bare "8" in "18 students..."),
            # replace() would hit the wrong spot — skip this match entirely.
            if text.find(m.group(0)) != m.start():
                continue
            num_str = m.group(1)
            if num_str.isdigit():
                n = int(num_str)
                if 1 <= n <= 12:
                    return m.group(0), n
                continue
            lower = num_str.lower()
            if lower in cls._GRADE_WORDS:
                return m.group(0), cls._GRADE_WORDS[lower]
            if lower in cls._ROMAN_TO_NUM:
                return m.group(0), cls._ROMAN_TO_NUM[lower]
        return None

    @staticmethod
    def _templatize_question(question: str, matched_span: str) -> str:
        """Replaces the matched class mention with a placeholder, then normalizes.

        v63 quick-win (2026-09-09): keys are now FILLER-TOLERANT — the same
        _strip_fillers discipline as DatasetLookup's loose index, so dataset
        row "How many students are there in class 10?" and incoming "how many
        students are in 8" collapse to the identical key
        "how many students {{CLASS}}". Applied identically at build time and
        lookup time; the single-SQL collision rule is unchanged (a stripped key
        is stored only when exactly one distinct verified SQL maps to it)."""
        placeholder_q = question.replace(matched_span, " {{CLASS}} ", 1)
        try:
            from dataset_lookup import strip_fillers
        except ImportError:  # package-relative (orchestrator imports)
            from .dataset_lookup import strip_fillers
        return strip_fillers(placeholder_q)

    def _load(self, path: str) -> None:
        # v63 (2026-09-09): filler-tolerant keys can now COLLIDE — two dataset
        # rows that differ only by filler words ("are there" vs "are") collapse
        # to one stripped template key. Same discipline as DatasetLookup's loose
        # index: a stripped key is stored ONLY when every qualifying dataset row
        # behind it agrees on ONE distinct templated SQL. Otherwise the key is
        # dropped entirely (miss → LLM, exactly as before) — a template hit can
        # never disagree with the verified dataset about the right SQL shape.
        from collections import defaultdict
        candidates: Dict[str, Set[str]] = defaultdict(set)
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                record = json.loads(line)
                question = record.get("input", "")
                sql = record.get("output", "")
                if not question or not sql:
                    continue

                q_match = self._find_class_in_question(question)
                sql_match = self._SQL_CLASS_PATTERN.search(sql)
                if not q_match or not sql_match:
                    continue  # doesn't qualify for templating -- not an error, just out of scope

                span_text, grade = q_match

                # SAFETY CHECK (found via direct testing, not assumed): the
                # class number/roman form can ALSO appear elsewhere in the
                # SQL -- e.g. a column alias like "class10_strength" from
                # the SPECIFIC training example's own phrasing. Substituting
                # only the WHERE-clause literal would leave that other
                # occurrence stale and misleading (a Class 9 answer labeled
                # "class10_strength"). Exclude any example where the grade
                # number/roman form appears anywhere OUTSIDE the one
                # standard literal we know how to substitute correctly.
                sql_without_literal = sql[:sql_match.start()] + sql[sql_match.end():]
                roman_form = self._NUM_TO_ROMAN.get(grade, "")
                # Numeric grade: plain substring check -- confirmed via
                # direct testing that \b word-boundary matching misses
                # concatenated cases like "class10_strength" (no real
                # boundary between "class" and "10" there).
                # Roman form: KEEP word-boundary matching -- a plain
                # substring check for something like "IX" would false-
                # positive inside unrelated words ("MAX", "FIX", "PREFIX"),
                # over-excluding many genuinely safe examples.
                numeric_unsafe = str(grade) in sql_without_literal
                roman_unsafe = bool(roman_form) and re.search(rf'\b{roman_form}\b', sql_without_literal)
                if numeric_unsafe or roman_unsafe:
                    continue  # unsafe to templatize -- number appears elsewhere too

                templated_q = self._templatize_question(question, span_text)
                templated_sql = self._SQL_CLASS_PATTERN.sub("{{CLASS_LITERAL}}", sql, count=1)
                candidates[templated_q].add(templated_sql)

        self._templates = {k: sorted(v)[0] for k, v in candidates.items() if len(v) == 1}

    def find(self, question: str) -> Optional[str]:
        """
        Returns fully-substituted, ready-to-use SQL if the question
        matches a known template (any grade 1-12), else None -- caller
        falls back to exact DatasetLookup, then the LLM, as normal.
        """
        if not self.enabled:
            return None
        q_match = self._find_class_in_question(question)
        if not q_match:
            return None
        span_text, grade = q_match

        templated_q = self._templatize_question(question, span_text)
        templated_sql = self._templates.get(templated_q)
        if templated_sql is None:
            return None

        roman = self._NUM_TO_ROMAN.get(grade)
        if roman is None:
            return None  # defensive -- grade should always be 1-12 by construction
        real_literal = f"cm.Name IN ('Class {grade}', '{roman}')"
        return templated_sql.replace("{{CLASS_LITERAL}}", real_literal)

    def __len__(self) -> int:
        return len(self._templates)


# ═══════════════════════════════════════════════════════════════════════════
#  SectionTemplateLookup — narrower: only generalizes among CONFIRMED section letters
# ═══════════════════════════════════════════════════════════════════════════

class SectionTemplateLookup:
    """
    Same idea as ClassTemplateLookup, applied to Section. IMPORTANT
    DIFFERENCE FROM CLASS: Class has a universal, known 1-12 range, so any
    class number can be safely generalized to. Section names are school/
    branch-specific vocabulary with no fixed universal set (confirmed
    elsewhere in this project: real branches use different conventions --
    plain letters, or names like "BRAINY"/"FOUNDATION 2"). This module
    CANNOT safely generalize to an arbitrary section name a user might type
    -- there's no way to validate it's real without branch context this
    lookup doesn't have.

    What it DOES do, safely: generalizes among the SPECIFIC section values
    already confirmed present in the training dataset for matching question
    shapes (checked directly: A, B, C). If a user asks about a section
    letter never seen in training, this correctly misses and falls through
    to the LLM -- narrower than Class's coverage, but honest about it rather
    than guessing.

    CONFIRMED SCOPE: 14 of 2,405 examples have a section letter appearing in
    both question text and as a secm.Name filter in the SQL.
    """

    _QUESTION_PATTERN = re.compile(r'\bsection\s+([A-Za-z])\b', re.IGNORECASE)
    _SQL_PATTERN = re.compile(r"secm\.Name\s*=\s*'([A-Za-z])'")

    def __init__(self, dataset_path: str, enabled: bool = True):
        self._templates: Dict[str, str] = {}
        self._known_sections: Set[str] = set()
        self.enabled = enabled
        self._load(dataset_path)

    def _load(self, path: str) -> None:
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                record = json.loads(line)
                question = record.get("input", "")
                sql = record.get("output", "")
                if not question or not sql:
                    continue

                sql_match = self._SQL_PATTERN.search(sql)
                if not sql_match:
                    continue
                section_letter = sql_match.group(1).upper()

                q_match = self._QUESTION_PATTERN.search(question)
                if not q_match or q_match.group(1).upper() != section_letter:
                    continue

                # Contamination check, same discipline as the other
                # template modules: exclude if the letter appears
                # elsewhere in the SQL as a standalone word (word
                # boundary is meaningful here since it's a single letter,
                # much likelier to appear as a real word boundary
                # elsewhere than a multi-digit number would).
                sql_without_literal = sql[:sql_match.start()] + sql[sql_match.end():]
                if re.search(rf"\b{section_letter}\b", sql_without_literal):
                    continue

                self._known_sections.add(section_letter)
                templated_q = _normalize(question.replace(q_match.group(0), " {{SECTION}} ", 1))
                templated_sql = self._SQL_PATTERN.sub("{{SECTION_LITERAL}}", sql, count=1)
                self._templates.setdefault(templated_q, templated_sql)

    def find(self, question: str) -> Optional[str]:
        if not self.enabled:
            return None
        q_match = self._QUESTION_PATTERN.search(question)
        if not q_match:
            return None
        section_letter = q_match.group(1).upper()

        # Only generalize to section letters CONFIRMED present in
        # training data -- never invent/accept an arbitrary one.
        if section_letter not in self._known_sections:
            return None

        templated_q = _normalize(question.replace(q_match.group(0), " {{SECTION}} ", 1))
        templated_sql = self._templates.get(templated_q)
        if templated_sql is None:
            return None

        return templated_sql.replace("{{SECTION_LITERAL}}", f"secm.Name = '{section_letter}'")

    def __len__(self) -> int:
        return len(self._templates)


# ═══════════════════════════════════════════════════════════════════════════
#  TopNTemplateLookup — generalized TOP N substitution
# ═══════════════════════════════════════════════════════════════════════════

class TopNTemplateLookup:
    """
    Same idea as ClassTemplateLookup, applied to TOP N: a training
    example asking for "Top 10 fee defaulters" can also correctly answer
    "Top 15 fee defaulters" without the LLM, by substituting the number.

    CONFIRMED SCOPE, NOT ASSUMED: checked directly against the real dataset.
    277 examples use TOP N in their SQL, but most (N=1) are fixed questions
    like "highest"/"most"/"best" where the question text has no explicit
    number to vary -- those are already fully covered by exact matching and
    don't need this. The genuine template opportunity is N != 1 WITH the
    same number appearing explicitly in the question text: 62 examples.

    SAME CONTAMINATION RISK, SAME FIX AS ClassTemplateLookup: the
    target number could appear elsewhere in the SQL (a different literal, a
    column alias) -- confirmed via the same kind of check, any example where
    the number appears outside the one TOP N clause is excluded.
    """

    _QUESTION_PATTERN = re.compile(
        r'\b(top|bottom|last|first)\s+(\d+)\b', re.IGNORECASE
    )
    _SQL_TOP_N_PATTERN = re.compile(r'\bTOP\s+(\d+)\b', re.IGNORECASE)

    def __init__(self, dataset_path: str, enabled: bool = True):
        self._templates: Dict[str, str] = {}
        self.enabled = enabled
        self._load(dataset_path)

    @classmethod
    def _find_n_in_question(cls, text: str) -> Optional[Tuple[str, int]]:
        m = cls._QUESTION_PATTERN.search(text)
        if not m:
            return None
        return m.group(0), int(m.group(2))

    def _load(self, path: str) -> None:
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                record = json.loads(line)
                question = record.get("input", "")
                sql = record.get("output", "")
                if not question or not sql:
                    continue

                sql_match = self._SQL_TOP_N_PATTERN.search(sql)
                if not sql_match:
                    continue
                n = sql_match.group(1)
                if n == "1":
                    continue  # fixed question, no explicit number to vary -- out of scope

                q_match = self._find_n_in_question(question)
                if not q_match:
                    continue
                span_text, q_n = q_match
                if str(q_n) != n:
                    continue  # question's number and SQL's TOP N don't match -- not this pattern

                # Contamination check, same discipline as ClassTemplateLookup:
                # exclude if this number appears anywhere else in the SQL.
                sql_without_literal = sql[:sql_match.start()] + sql[sql_match.end():]
                if n in sql_without_literal:
                    continue

                templated_q = _normalize(question.replace(span_text, " {{TOPN}} ", 1))
                templated_sql = self._SQL_TOP_N_PATTERN.sub("TOP {{TOPN}}", sql, count=1)
                self._templates.setdefault(templated_q, templated_sql)

    def find(self, question: str) -> Optional[str]:
        if not self.enabled:
            return None
        q_match = self._find_n_in_question(question)
        if not q_match:
            return None
        span_text, n = q_match

        templated_q = _normalize(question.replace(span_text, " {{TOPN}} ", 1))
        templated_sql = self._templates.get(templated_q)
        if templated_sql is None:
            return None

        return templated_sql.replace("{{TOPN}}", str(n))

    def __len__(self) -> int:
        return len(self._templates)


# ═══════════════════════════════════════════════════════════════════════════
#  ClassSectionTemplateLookup — atomic "7A" → (Class 7, Section A) substitution
# ═══════════════════════════════════════════════════════════════════════════

class ClassSectionTemplateLookup:
    """
    Handles compressed class-section notation ("7A" = Class 7, Section A) as
    its own dedicated lookup -- NOT an extension of ClassTemplateLookup
    or SectionTemplateLookup, deliberately.

    WHY SEPARATE, NOT BOLTED ONTO THE EXISTING TWO: "7A" encodes BOTH
    variables in a single token. ClassTemplateLookup and
    SectionTemplateLookup each substitute exactly one variable and
    leave everything else in the matched template untouched -- confirmed
    directly (see orchestrator integration testing) that a genuine multi-
    variable question safely MISSES across both rather than risk a partial,
    wrong substitution. Adding "7A" detection to either one alone would
    either fail to compile (no single matching template with only one
    placeholder) or, worse, risk substituting only the class OR only the
    section while silently leaving the other at whatever value the specific
    training example happened to use -- exactly the kind of contamination
    bug already found and fixed in ClassTemplateLookup once. A
    dedicated lookup that substitutes BOTH literals atomically, from the
    same detected token, avoids that risk entirely.

    CONFIRMED SCOPE: built directly from the 4 real "7A"-style reinforcement
    examples added in this session (v18) -- these are the ONLY known real
    examples using this notation; before them, zero existed anywhere in the
    dataset.
    """

    # "7A", "9B", "12C" -- one or two digits immediately followed by a
    # single letter, no space (the compressed notation itself).
    _QUESTION_PATTERN = re.compile(r'\b(\d{1,2})([A-Za-z])\b')

    _ROMAN = {1: "I", 2: "II", 3: "III", 4: "IV", 5: "V", 6: "VI", 7: "VII",
              8: "VIII", 9: "IX", 10: "X", 11: "XI", 12: "XII"}

    _SQL_PATTERN = re.compile(
        r"cm\.Name IN \('Class \d{1,2}', '[IVX]+'\) AND secm\.Name = '[A-Za-z]'"
    )

    def __init__(self, dataset_path: str, enabled: bool = True):
        self._templates: Dict[str, str] = {}
        self._known_sections: Set[str] = set()
        self.enabled = enabled
        self._load(dataset_path)

    def _load(self, path: str) -> None:
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                record = json.loads(line)
                question = record.get("input", "")
                sql = record.get("output", "")
                if not question or not sql:
                    continue

                sql_match = self._SQL_PATTERN.search(sql)
                if not sql_match:
                    continue

                q_match = self._QUESTION_PATTERN.search(question)
                if not q_match:
                    continue
                grade = int(q_match.group(1))
                section = q_match.group(2).upper()
                if not (1 <= grade <= 12):
                    continue

                # Confirm the detected grade/section actually match what
                # the SQL literal says -- guards against a coincidental
                # digit+letter match elsewhere in unrelated question text.
                expected_roman = self._ROMAN.get(grade, "")
                if (f"Class {grade}" not in sql_match.group(0) or
                        f"'{section}'" not in sql_match.group(0)):
                    continue

                # Contamination check, same discipline as every other
                # template module here: exclude if the grade number,
                # roman form, or section letter appears anywhere else in
                # the SQL outside the one literal being substituted.
                sql_without_literal = sql[:sql_match.start()] + sql[sql_match.end():]
                if (str(grade) in sql_without_literal or
                        re.search(rf'\b{expected_roman}\b', sql_without_literal) or
                        re.search(rf"'{section}'", sql_without_literal)):
                    continue

                self._known_sections.add(section)
                templated_q = _normalize(question.replace(q_match.group(0), " {{CLASSSECTION}} ", 1))
                templated_sql = self._SQL_PATTERN.sub("{{CLASSSECTION_LITERAL}}", sql, count=1)
                self._templates.setdefault(templated_q, templated_sql)

    def find(self, question: str) -> Optional[str]:
        if not self.enabled:
            return None
        q_match = self._QUESTION_PATTERN.search(question)
        if not q_match:
            return None
        grade = int(q_match.group(1))
        section = q_match.group(2).upper()
        if not (1 <= grade <= 12):
            return None
        if section not in self._known_sections:
            return None  # only generalize to CONFIRMED real section letters

        templated_q = _normalize(question.replace(q_match.group(0), " {{CLASSSECTION}} ", 1))
        templated_sql = self._templates.get(templated_q)
        if templated_sql is None:
            return None

        roman = self._ROMAN.get(grade)
        literal = f"cm.Name IN ('Class {grade}', '{roman}') AND secm.Name = '{section}'"
        return templated_sql.replace("{{CLASSSECTION_LITERAL}}", literal)

    def __len__(self) -> int:
        return len(self._templates)


# ═══════════════════════════════════════════════════════════════════════════
#  ShorthandClassSectionLookup — "1 talented" / "class 1 talented" fast path
# ═══════════════════════════════════════════════════════════════════════════

class ShorthandClassSectionLookup:
    """
    Added 2026-09-06 (latency: the school's natural shorthand — "1 talented",
    "class 5 foundation 2" — matched NONE of the existing lookups, so every
    such question paid full LLM latency; measured live ~45-50s vs <1s).

    Recognizes ONLY tight, END-ANCHORED students/girls count questions with a
    trailing section name, and substitutes BOTH literals atomically into a
    verified skeleton.

    SKELETON PROVENANCE (confirmed scope, not assumed):
      - girls: verbatim SQL of the dataset example 'Girls in Class 9 Section
        A' (COUNT over StudentAcademicDetail, full branch scoping, Gender
        filter, IsActive/IsTCIssued guards) — only class/section literals
        change.
      - students: the dataset has NO plain students-count + section example
        (all such dataset questions are name-lists — checked), so this
        skeleton is the girls skeleton with ONLY the Gender clause removed.
        That shape is triple-confirmed: structurally identical to the girls
        skeleton, identical to the dataset's class-only student-count SQL,
        and identical to what the v28 model itself generated live for
        "how many students are there in 1 talented?" on 2026-09-06 (passed
        the full 54-rule chain, executed, returned 97).

    SAFETY (same discipline as every template module here):
      - The section name is validated against THE ASKING BRANCH's real
        Sections list (orchestrator passes branch_vocab.values("SECTION")).
        Unknown section -> miss -> LLM, exactly as before. The literal uses
        the branch's own canonical casing, so VALIDATE passes cleanly.
      - allowed_sections empty/None -> ALWAYS miss (fail-safe, never guess).
      - Skeleton candidates are rejected if the grade number, roman form, or
        section value appears anywhere else in the SQL (contamination checks,
        same as ClassSectionTemplateLookup).
      - The substituted SQL still flows through the FULL fail-closed chain
        (guardrail, alias_scope, branch_scoping, VALIDATE, SEMANTIC, BIND,
        EXECUTE). This lookup only decides what SQL text to try.
    """

    _ROMAN = {1: "I", 2: "II", 3: "III", 4: "IV", 5: "V", 6: "VI", 7: "VII",
              8: "VIII", 9: "IX", 10: "X", 11: "XI", 12: "XII"}

    _SQL_CLASSSEC = re.compile(
        r"cm\.Name IN \('Class (\d{1,2})', '([IVX]+)'\)\s+AND\s+secm\.Name\s*=\s*'([^']+)'")

    # Tight, END-ANCHORED skeleton on the normalized question.
    # G1 = subject word, G2 = class number, G3 = section phrase (1-3 tokens,
    # so "FOUNDATION 2" / "TALENTED 1" / "New Admission" all work).
    _Q = re.compile(
        r"^(?:how many|total|number of|count of|strength of)\s+"
        r"(students?|girls?)\s+"
        r"(?:are there |is there |are |do we have )?"
        r"(?:in|of) (?:class |std |grade )?"
        r"(\d{1,2}) "
        r"(?:section )?"
        r"([a-z][a-z0-9]*(?: [a-z0-9]+){0,2})$"
    )

    def __init__(self, dataset_path: str, enabled: bool = True):
        self.enabled = enabled
        self._skeletons: Dict[str, str] = {}
        self._load(dataset_path)

    def _load(self, path: str) -> None:
        try:
            with open(path, encoding="utf-8") as f:
                lines = f.readlines()
        except Exception:
            return
        for raw_line in lines:
            line = raw_line.strip()
            if not line:
                continue
            try:
                record = json.loads(line)
            except Exception:
                continue
            question = record.get("input", "")
            sql = record.get("output", "")
            if not question or not sql:
                continue
            sql_match = self._SQL_CLASSSEC.search(sql)
            if not sql_match:
                continue
            grade = int(sql_match.group(1))
            section = sql_match.group(3)
            if not (1 <= grade <= 12):
                continue

            # Contamination checks, same discipline as the other templates:
            # grade number / roman form / section value must not appear
            # anywhere else in the SQL outside the one literal substituted.
            sql_without_literal = sql[:sql_match.start()] + sql[sql_match.end():]
            roman = self._ROMAN.get(grade, "")
            if (str(grade) in sql_without_literal
                    or (roman and re.search(rf"\b{roman}\b", sql_without_literal))
                    or re.search(rf"'{re.escape(section)}'", sql_without_literal)):
                continue

            # Subject detection from the question, cross-checked against the
            # SQL: a girls skeleton must carry the Gender filter; a students
            # skeleton must be a COUNT(*) aggregate (NOT a name-list).
            q_lower = question.lower()
            has_gender = "sm.Gender" in sql
            if re.search(r"\bgirls?\b", q_lower) and has_gender:
                subject = "girls"
            elif (re.search(r"\bstudents?\b", q_lower) and not has_gender
                  and "COUNT(*)" in sql.upper()):
                subject = "students"
            else:
                continue  # teacher/list/attendance/fee shapes are out of scope

            templated_sql = (sql[:sql_match.start()]
                             + "{{CLASS_LITERAL}} AND secm.Name = '{{SECTION}}'"
                             + sql[sql_match.end():])
            self._skeletons.setdefault(subject, templated_sql)
            if "students" in self._skeletons and "girls" in self._skeletons:
                break

        # DERIVED students skeleton: dataset lacks a students-count+section
        # example (checked directly). Derive from the verified girls skeleton
        # by removing ONLY the Gender clause — provenance in the docstring.
        if "students" not in self._skeletons and "girls" in self._skeletons:
            derived = re.sub(r"\s*AND\s+sm\.Gender\s+IN\s*\([^)]*\)", "",
                             self._skeletons["girls"], count=1)
            if derived != self._skeletons["girls"]:
                self._skeletons["students"] = derived

    def find(self, question: str, allowed_sections=None) -> Optional[str]:
        """Returns substituted ready-to-use SQL, or None (caller falls through
        to the LLM exactly as before).

        allowed_sections: the ASKING BRANCH's real section names (orchestrator
        passes branch_vocab.values("SECTION")). None/empty -> ALWAYS miss.
        """
        if not self.enabled:
            return None
        if not allowed_sections:
            return None
        m = self._Q.match(_normalize(question))
        if not m:
            return None
        subject = "girls" if m.group(1).startswith("girl") else "students"
        skeleton = self._skeletons.get(subject)
        if skeleton is None:
            return None
        grade = int(m.group(2))
        if not (1 <= grade <= 12):
            return None
        wanted = m.group(3).strip().lower()
        canonical = next((s for s in allowed_sections
                          if str(s).strip().lower() == wanted), None)
        if canonical is None:
            return None  # not a real section at THIS branch -> LLM as before
        roman = self._ROMAN.get(grade)
        literal = f"cm.Name IN ('Class {grade}', '{roman}') AND secm.Name = '{canonical}'"
        return skeleton.replace(
            "{{CLASS_LITERAL}} AND secm.Name = '{{SECTION}}'", literal, 1)

    def __len__(self) -> int:
        return len(self._skeletons)

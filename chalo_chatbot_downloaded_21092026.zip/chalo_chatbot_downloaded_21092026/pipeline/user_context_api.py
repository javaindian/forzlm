"""
AI Secretary — Application Layer :: Live User Context API Client
==================================================================

Replaces the static context_branchX.json files with a real, live call to
the ChaloSchools GetUserContext API — the same shape context_vocab.py and
demo_runner.py already expect, just fetched fresh per request instead of
read from a file that can go stale.

CONFIGURABLE, NOT HARDCODED (Bible Rule 1): the endpoint URL and API key
come from config.yaml / .env, resolved the same way everything else in
this project resolves secrets — never hardcoded here.

Two real, confirmed implementation quirks this handles correctly:
  1. DOUBLE JSON-STRING ENCODING (classic ASMX/.NET pattern) — the request
     body's "request" field is itself a JSON string, not a raw object, and
     the response's "d" field is ALSO a JSON string requiring a second
     json.loads(). Confirmed intentional by the dev team, not a bug.
  2. INCONSISTENT ARRAY SHAPES — Classes comes back as a list of objects
     ({"Name", "DisplayOrder"}), while Subjects/EnquiryStatuses/FeeHeads/
     ExamTerms are plain string lists. Also confirmed intentional, and
     confirmed to originate from this project's own earlier proposal, not
     a dev-team decision.

KNOWN, DOCUMENTED GAPS:
  * Sections: not yet returned by the real API. If SECTIONS_FALLBACK_LOCAL
    is enabled (default: on), this queries Sections directly from the local
    database per branch and merges them into the live API response, so the
    app stays fully functional today. Once the dev team adds Sections to the
    real API, set SECTIONS_FALLBACK_LOCAL=false in .env and this stops
    querying locally, no code change needed.
  * FeeTerms: round-2 (D1.13) — the real API doesn't return FeeTerms yet.
    Same fallback pattern as Sections: when FEETERMS_FALLBACK_LOCAL is
    enabled (default: on), this queries `SELECT Name FROM TermMaster WHERE
    BranchID=? AND AcademicYearID=? AND IsDeleted=0` per branch and merges
    the result into the live API response. Once the dev team adds FeeTerms
    to the real API, set FEETERMS_FALLBACK_LOCAL=false and this stops.

UNVERIFIED, FLAGGED — multi-branch behavior: the dev team has only
verbally confirmed branch data is "strictly separated," with no concrete
multi-branch example ever provided. This module does not assume that
claim is correct — see verify_branch_isolation() below, which is a real,
runnable check against a real multi-branch user, not a trust exercise.

Reconstructed from the original app_layer/user_context_api.py + round-2
D1.13 (FeeTerms fallback). Diff against your real files before deploying.
"""

from __future__ import annotations

import json
import os
import sys
from typing import Any, Dict, List, Optional

# v97: erp_config.json (project root) is the PRIMARY source for the URL and
# the per-tenant API keys. This module's own constants below are last-resort
# fallbacks only. The sys.path dance keeps this module importable standalone.
_ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT_DIR not in sys.path:
    sys.path.insert(0, _ROOT_DIR)
try:
    import erp_config as _ERP
except ImportError:  # pragma: no cover — only if the root file was removed
    _ERP = None

# NOTE: the original imported `requests` (third-party). For the stdlib-only
# constraint of this reconstruction, we use urllib when `requests` is not
# available, but keep the `requests` fast path when it IS available (the live
# deployment already depends on it).
try:
    import requests  # type: ignore
    _HAS_REQUESTS = True
except ImportError:  # pragma: no cover — stdlib fallback for this reconstruction
    import urllib.request
    import urllib.error
    _HAS_REQUESTS = False


class UserContextAPIError(Exception):
    """Raised when the live API call fails outright (network, auth, bad response)."""
    pass


# Confirmed real endpoint, from dev-team documentation dated after this
# module was first built (the earlier version had no real URL to call at
# all). v97: used ONLY as a last-resort fallback — erp_config.json
# (get_user_context_url) is the live source; edit that file + restart to
# change it. Nothing else in this module needs touching.
DEFAULT_API_URL = "https://chaloschools.in/testv4service/DigitalSecretary/AISecretary.asmx/GetUserContext"

# TargetDatabase is confirmed to vary per user/school, not a single
# constant -- these two entries are real, confirmed values from actual
# API responses, not guessed. Add more only after confirming the same way.
USER_DATABASE_MAP = {
    116: "V3_TestDatabase",
    244: "V3_GG",
}

# CONFIRMED via direct testing (real error: "Invalid API key for the
# specified tenant" when calling for user 244 / V3_GG using the key that
# correctly works for V3_TestDatabase): the API key is PER-SCHOOL, not
# universal across tenants -- matching what the dev team's own
# documentation said from the start ("Use Key generated in select
# AISecretaryApiKey... from chalov3common.dbo.SchoolMaster") but which
# hadn't yet been treated as a real per-tenant requirement in code.
# Keyed by TargetDatabase, since the key belongs to the school/tenant,
# not to an individual user. v97: the REAL KEY VALUES moved out of code
# into erp_config.json (tenant_api_keys) — edit THAT file to add V3_GG's
# key (SELECT AISecretaryApiKey FROM chalov3common.dbo.SchoolMaster) or to
# rotate any key, then restart the backend. This map stays as an empty
# last-resort fallback so old deploys without erp_config.json still boot.
TENANT_API_KEY_MAP = {
    # "V3_TestDatabase": "<moved to erp_config.json>",
    # "V3_GG": "<add in erp_config.json once obtained>",
}


def _get_config_value(cfg: Optional[dict], *keys, env_var: str = None, default=None):
    """
    Reads a nested config value (e.g. cfg['api']['user_context_url']),
    falling back to an environment variable, then a default. Keeps this
    module usable standalone (env-only) or wired into config.yaml.
    """
    node = cfg or {}
    for k in keys:
        if not isinstance(node, dict):
            node = None
            break
        node = node.get(k)
    if node is not None:
        return node
    if env_var is not None:
        env_val = os.environ.get(env_var)
        if env_val is not None:
            return env_val
    return default


def _double_encode_request(user_id: int, target_database: str) -> str:
    """
    Builds the request BODY the real API expects: a JSON object whose
    "request" field is itself a JSON-encoded STRING (not a nested object) --
    the confirmed, intentional ASMX/.NET double-encoding pattern.

    CONFIRMED against real dev-team documentation and two real examples
    (user 116 / V3_TestDatabase, user 244 / V3_GG): the inner payload
    requires BOTH TargetDatabase and UserId -- TargetDatabase is NOT
    optional, and is NOT a single constant -- it varies per user/school.
    """
    inner = json.dumps({"TargetDatabase": target_database, "UserId": user_id})
    return json.dumps({"request": inner})


def _double_decode_response(raw_text: str) -> dict:
    """
    Undoes the same pattern on the way back: the real response wraps the
    actual payload as a JSON-encoded STRING inside a "d" field. This
    decodes both layers and returns the real payload dict.
    """
    outer = json.loads(raw_text)
    if "d" not in outer:
        raise UserContextAPIError(
            f"Response missing expected 'd' field. Got keys: {list(outer.keys())}"
        )
    inner_raw = outer["d"]
    if isinstance(inner_raw, str):
        return json.loads(inner_raw)
    # Defensive: if a future API version stops double-encoding, don't break.
    return inner_raw


def _http_post(url: str, body: str, headers: Dict[str, str],
               timeout_seconds: int) -> str:
    """Stdlib fallback for the requests.post used in the original."""
    data = body.encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST")
    for k, v in headers.items():
        req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=timeout_seconds) as resp:
            return resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        raise UserContextAPIError(f"GetUserContext API call failed: HTTP {e.code} {e.reason}") from e
    except urllib.error.URLError as e:
        raise UserContextAPIError(f"GetUserContext API call failed: {e}") from e


def fetch_user_context(user_id: int, target_database: Optional[str] = None,
                        cfg: Optional[dict] = None, timeout_seconds: int = 15) -> dict:
    """
    Calls the real, live GetUserContext API for a given user and returns
    the parsed payload in the EXACT shape context_vocab.py and
    demo_runner.py already expect (UserMasterDetails / UserBranchDetails /
    Classes / Sections / Subjects / EnquiryStatuses / FeeHeads / ExamTerms
    / FeeTerms).

    target_database: CONFIRMED to vary per user/school (real examples:
    user 116 -> "V3_TestDatabase", user 244 -> "V3_GG") -- NOT a single
    constant. If not given explicitly, resolved from USER_DATABASE_MAP
    below. There is currently no live lookup mechanism for this -- the
    dev team's own documentation notes the API key (and presumably this
    kind of per-school detail) will eventually come back in the login
    response, but that flow doesn't exist yet. This map is a deliberate,
    honest stand-in until it does -- add real confirmed users here the
    same careful way 116 and 244 were confirmed, don't guess at new ones.

    Raises UserContextAPIError on any failure -- callers decide whether to
    fall back to a cached/local context or surface the error, rather than
    this function silently returning something misleading.
    """
    if target_database is None:
        target_database = USER_DATABASE_MAP.get(user_id)
        if target_database is None:
            raise UserContextAPIError(
                f"No TargetDatabase known for user {user_id}. Pass it explicitly, "
                f"or add this user to USER_DATABASE_MAP once confirmed -- it is "
                f"required by the real API and is not a single constant."
            )

    # v97 resolution order: erp_config.json (file -> env -> builtin default)
    # first; the legacy cfg-dict / env / DEFAULT_API_URL chain stays behind it
    # as a fallback for deployments that somehow lack erp_config.json.
    if _ERP is not None:
        base_url = _ERP.get_user_context_url()
    else:
        base_url = None
    if not base_url:
        base_url = _get_config_value(cfg, "user_context_api", "url",
                                      env_var="USER_CONTEXT_API_URL", default=DEFAULT_API_URL)
    # Per-tenant key: erp_config.json's tenant_api_keys map first (confirmed
    # required -- see TENANT_API_KEY_MAP's docstring), then the old hardcoded
    # map (kept for old deploys), then the single config/.env value for
    # backward compatibility with today's single-tenant setup.
    api_key = None
    if _ERP is not None:
        api_key = _ERP.tenant_key(target_database)
    if not api_key:
        api_key = TENANT_API_KEY_MAP.get(target_database)
    if not api_key:
        api_key = _get_config_value(
            cfg, "user_context_api", "api_key", env_var="USER_CONTEXT_API_KEY"
        )
    sections_fallback = str(_get_config_value(
        cfg, "user_context_api", "sections_fallback_local",
        env_var="SECTIONS_FALLBACK_LOCAL", default="true"
    )).lower() in ("1", "true", "yes")
    # D1.13 — FeeTerms fallback, gated by its own env var (default on).
    feeterms_fallback = str(_get_config_value(
        cfg, "user_context_api", "feeterms_fallback_local",
        env_var="FEETERMS_FALLBACK_LOCAL", default="true"
    )).lower() in ("1", "true", "yes")

    if not base_url:
        raise UserContextAPIError(
            "No API URL configured. Set get_user_context_url in erp_config.json "
            "(project root) or USER_CONTEXT_API_URL in .env."
        )

    # CONFIRMED against real dev-team documentation: the required header
    # is "x-api-key", not "Authorization: Bearer ..." -- the earlier
    # version of this function had this wrong.
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["x-api-key"] = api_key

    body = _double_encode_request(user_id, target_database)

    try:
        if _HAS_REQUESTS:
            resp = requests.post(base_url, data=body, headers=headers, timeout=timeout_seconds)
            resp.raise_for_status()
            text = resp.text
        else:
            text = _http_post(base_url, body, headers, timeout_seconds)
    except UserContextAPIError:
        raise
    except Exception as e:
        raise UserContextAPIError(f"GetUserContext API call failed: {e}") from e

    try:
        payload = _double_decode_response(text)
    except (json.JSONDecodeError, UserContextAPIError) as e:
        raise UserContextAPIError(
            f"GetUserContext API returned an unparseable response: {e}"
        ) from e

    if not payload.get("Success", True):
        raise UserContextAPIError(
            f"GetUserContext API reported failure: "
            f"{payload.get('ErrorMessage')} (code {payload.get('ErrorCode')})"
        )

    if sections_fallback:
        _merge_local_sections(payload, cfg)
    if feeterms_fallback:
        _merge_local_fee_terms(payload, cfg)

    return payload


def _merge_local_sections(payload: dict, cfg: Optional[dict]) -> None:
    """
    KNOWN GAP WORKAROUND: the real API doesn't return Sections yet. If
    enabled, this queries Sections directly from the local database per
    branch the user has access to, and merges them into the payload so
    the rest of the app (context_vocab.py's Section handling, already
    wired in) keeps working exactly as it does with the static files
    today. Silently does nothing if a branch already has real Sections
    from the API (so this stops interfering the moment the dev team adds
    it -- no code change needed on that day, just flip the config flag).
    """
    branches = (payload.get("UserMasterDetails", {}) or {}).get("UserBranchDetails", [])
    if not branches:
        return

    try:
        import pyodbc
    except ImportError:
        # pyodbc not available in this environment -- skip the fallback
        # rather than crash the whole context fetch over a known, optional gap.
        return

    driver = _get_config_value(cfg, "database_base", "driver", default="ODBC Driver 17 for SQL Server")
    server = _get_config_value(cfg, "database_base", "server", env_var="DB_SERVER", default="localhost")
    db_name = (payload.get("UserMasterDetails", {}) or {}).get("DBPrefix", "")
    if not db_name:
        return

    db_username = _get_config_value(cfg, "database_base", "username", default="")
    db_password = _get_config_value(cfg, "database_base", "password", env_var="DB_PASSWORD", default="")
    # Matches the same SQL-login pattern config.yaml already uses for the
    # rest of the app (database_base.username/password) -- NOT Windows/
    # Trusted auth, which the real environment doesn't use.
    conn_str = (
        f"DRIVER={{{driver}}};SERVER={server};DATABASE={db_name};"
        f"UID={db_username};PWD={db_password};"
    )

    try:
        conn = pyodbc.connect(conn_str, timeout=5)
        cursor = conn.cursor()
        for branch in branches:
            if branch.get("Sections"):
                continue  # already present -- API has caught up, don't override
            branch_id = branch.get("ID")
            if branch_id is None:
                continue
            cursor.execute(
                "SELECT DISTINCT Name FROM SectionMaster WHERE BranchID = ? "
                "AND (IsDeleted IS NULL OR IsDeleted = 0)",
                (branch_id,)
            )
            branch["Sections"] = [row[0] for row in cursor.fetchall()]
        conn.close()
    except Exception:
        # Local DB not reachable from wherever this runs -- leave Sections
        # empty for this call rather than crash the whole context fetch.
        for branch in branches:
            branch.setdefault("Sections", [])


def _merge_local_fee_terms(payload: dict, cfg: Optional[dict]) -> None:
    """
    D1.13 — FeeTerms fallback. The real API doesn't return FeeTerms yet.
    When FEETERMS_FALLBACK_LOCAL is enabled (default on), this queries
    `SELECT Name FROM TermMaster WHERE BranchID=? AND AcademicYearID=? AND
    IsDeleted=0` per branch, using the branch's CURRENT AcademicYear ID
    (from the Context JSON's `IsCurrentYear` entry). The result is merged
    into the payload as the branch's FeeTerms list, so context_vocab.py's
    FEE_TERM vocab wiring and the orchestrator's @AcademicYearID resolution
    (D1.3) keep working today.

    Same idempotence / safety contract as _merge_local_sections: silently
    does nothing if a branch already has real FeeTerms from the API. On
    any DB error, leaves FeeTerms empty for that branch rather than
    crash the whole context fetch.
    """
    branches = (payload.get("UserMasterDetails", {}) or {}).get("UserBranchDetails", [])
    if not branches:
        return

    try:
        import pyodbc
    except ImportError:
        return

    driver = _get_config_value(cfg, "database_base", "driver", default="ODBC Driver 17 for SQL Server")
    server = _get_config_value(cfg, "database_base", "server", env_var="DB_SERVER", default="localhost")
    db_name = (payload.get("UserMasterDetails", {}) or {}).get("DBPrefix", "")
    if not db_name:
        return

    db_username = _get_config_value(cfg, "database_base", "username", default="")
    db_password = _get_config_value(cfg, "database_base", "password", env_var="DB_PASSWORD", default="")
    conn_str = (
        f"DRIVER={{{driver}}};SERVER={server};DATABASE={db_name};"
        f"UID={db_username};PWD={db_password};"
    )

    try:
        conn = pyodbc.connect(conn_str, timeout=5)
        cursor = conn.cursor()
        for branch in branches:
            if branch.get("FeeTerms"):
                continue  # already present -- API has caught up, don't override
            branch_id = branch.get("ID")
            if branch_id is None:
                continue
            # Resolve the current academic-year ID for this branch from
            # the Context JSON's AcademicYears list (matches D1.3 in
            # context.py's _resolve_current_academic_year_id). If the API
            # already populated AcademicYears, prefer the IsCurrentYear
            # entry; else fall back to NULL (we can't query without a
            # year filter — leave FeeTerms empty for this branch).
            academic_years = branch.get("AcademicYears", []) or []
            current_ay_id = None
            for ay in academic_years:
                if ay.get("IsCurrentYear"):
                    current_ay_id = ay.get("Id")
                    break
            if current_ay_id is None:
                # Without an academic-year filter the query would return
                # terms for ALL years — almost certainly wrong (TermMaster
                # IDs are reused across years). Skip rather than guess.
                branch.setdefault("FeeTerms", [])
                continue
            cursor.execute(
                "SELECT Name FROM TermMaster "
                "WHERE BranchID = ? AND AcademicYearID = ? "
                "AND (IsDeleted IS NULL OR IsDeleted = 0) "
                "ORDER BY DisplayOrder, Name",
                (branch_id, current_ay_id)
            )
            branch["FeeTerms"] = [row[0] for row in cursor.fetchall()]
        conn.close()
    except Exception:
        for branch in branches:
            branch.setdefault("FeeTerms", [])


def verify_branch_isolation(user_id_a: int, user_id_b: int,
                             target_database_a: Optional[str] = None,
                             target_database_b: Optional[str] = None,
                             cfg: Optional[dict] = None) -> dict:
    """
    A REAL, RUNNABLE check for the still-unverified multi-branch claim --
    not a trust exercise. Fetches context for two different users and
    reports whether their branch data is actually distinct, so this can
    be confirmed with evidence before relying on it, the same way every
    other claim in this project has been checked rather than assumed.

    Users may be on entirely different databases (confirmed real: user
    116 is on V3_TestDatabase, user 244 is on V3_GG) -- pass
    target_database explicitly for each if they're not both in
    USER_DATABASE_MAP already.

    Returns a dict with the two users' branch ID lists and whether they
    overlap in a way that looks suspicious (e.g. identical branch lists
    for users expected to have different access).
    """
    ctx_a = fetch_user_context(user_id_a, target_database_a, cfg)
    ctx_b = fetch_user_context(user_id_b, target_database_b, cfg)

    branches_a = {b.get("ID") for b in ctx_a.get("UserMasterDetails", {}).get("UserBranchDetails", [])}
    branches_b = {b.get("ID") for b in ctx_b.get("UserMasterDetails", {}).get("UserBranchDetails", [])}

    return {
        "user_a": user_id_a, "branches_a": sorted(branches_a),
        "user_b": user_id_b, "branches_b": sorted(branches_b),
        "identical": branches_a == branches_b,
        "note": (
            "Identical branch sets for two different users is not automatically "
            "wrong -- it depends on their real, intended access. Compare this "
            "against UserAccountRoleDetails for both users to confirm, the same "
            "way the Branch 2/3 mismatch was confirmed earlier -- don't trust "
            "this check alone."
        ),
    }

"""
AI Secretary — Application Layer :: Context-JSON Vocabulary Adapter
===================================================================

Parses the extended login Context JSON the ERP returns after authentication and
exposes each branch's REAL master-data vocabulary for the two mechanisms of the
corrected architecture (see AI_Secretary_App_Layer_Status.md — 2026-08-03
correction: post-generation substitution → prompt-time injection + validation):

    (a) PROMPT-TIME INJECTION — build a compact vocabulary string per branch to
        inject into the model's system prompt, so the model writes the correct
        real literal WHILE generating (e.g. branch3 "Class 10" → 'X', not
        LIKE '%10%').

    (b) POST-GENERATION VALIDATION — a fail-closed membership check: is a value
        the model emitted (or the user typed) an EXACT member of this branch's
        vocabulary for a concept type? If not → not resolved (ask/refuse). This
        is the Value Resolver's new role (validate, not substitute).

⚠️ ROUND-2 EXTENSION (D1.13): `FEE_TERM` is now part of CONCEPT_TO_JSON_KEY
    (maps to "FeeTerms" in the Context JSON). Also added
    `add_fee_terms_fallback(ctx, branch_id, fee_terms)` so a caller can fill in
    FeeTerms from a `SELECT Name FROM TermMaster WHERE BranchID=? AND
    AcademicYearID=? AND IsDeleted=0` query when the API doesn't return them
    (same pattern as _merge_local_sections / _merge_local_fee_terms in
    user_context_api.py).

NOTE ON THE VOCAB ENGINE: the synonym store + validate-and-substitute logic
(SynonymStore, validate_and_substitute, SubstitutionResult) lives in
/home/z/my-project/chalo_chatbot/vocab/inject.py — DO NOT duplicate it here.
This module is JUST the Context JSON parser + injection-prompt builder.

Context JSON shape (per the dev team's delivered sample)
--------------------------------------------------------
{
  "UserMasterDetails": {
    "Id", "UserName", "StaffName", "IsSuperUser", "IsMgmtAppEnabled",
    "DBPrefix" (target database, e.g. "V3_TestDatabase"), "ShortName",
    "UserBranchDetails": [
      {
        "ID", "Name", "IsPrimary",
        "AcademicYears": [ {"Id","Name","IsCurrentYear","PreviousAcademicYearID"} ],
        "Classes":       [ {"Name","DisplayOrder"} ],
        "Sections":      [ "A", "B", "C", ... ],                # list of strings — not yet in
                                                                  # the real dev-team API; sourced
                                                                  # locally via generate_branch_
                                                                  # contexts.py until it is
        "Subjects":      [ "MATHS", "ENGLISH", ... ],          # list of strings
        "EnquiryStatuses":[ "Initiated","Updated","Completed","Dropped" ],
        "FeeHeads":      [ "Admission Fee", "Bus Fee -I", ... ],
        "ExamTerms":     [ "Term I","TERM I","TERM-I", ... ],
        "FeeTerms":      [ "Term 1","Term 2","Term 3" ]          # NEW (D1.13) — sourced
                                                                  # via add_fee_terms_fallback
                                                                  # when API doesn't return it
      }, ...
    ]
  }
}

Design notes
------------
* Concept types map to Context-JSON keys:
      CLASS -> Classes (objects w/ Name+DisplayOrder), SECTION -> Sections,
      SUBJECT -> Subjects, ENQUIRY_STATUS -> EnquiryStatuses,
      FEE_HEAD -> FeeHeads, EXAM_TERM -> ExamTerms,
      FEE_TERM -> FeeTerms (D1.13 — populated via fallback when absent).
* Validation is EXACT (case-sensitive) by default because the stored value must
  match the DB literal exactly. A case-insensitive lookup is also provided for
  the Synonym/disambiguation layer to detect near-misses (e.g. model emitted
  'maths' but branch stores 'MATHS') and route them to disambiguation rather
  than silently "fixing" them.
* Fail closed: unknown branch / unknown concept type / value not present all
  return "not a member" — never a guess.
* No hardcoded paths or client names (Bible Rule 1). Pure stdlib.

Reconstructed from the original app_layer/ code + round-2 extensions.
Diff against your real files before deploying.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Union


# Concept type -> the Context-JSON branch key that holds its vocabulary.
# D1.13: added FEE_TERM -> "FeeTerms" (populated by add_fee_terms_fallback
# when the API doesn't return it).
CONCEPT_TO_JSON_KEY = {
    "CLASS": "Classes",
    "SECTION": "Sections",
    "SUBJECT": "Subjects",
    "ENQUIRY_STATUS": "EnquiryStatuses",
    "FEE_HEAD": "FeeHeads",
    "EXAM_TERM": "ExamTerms",
    "FEE_TERM": "FeeTerms",   # NEW (D1.13) — API doesn't return this yet
}

# Human labels for the injection prompt.
_CONCEPT_PROMPT_LABEL = {
    "CLASS": "Classes",
    "SECTION": "Sections",
    "SUBJECT": "Subjects",
    "ENQUIRY_STATUS": "Enquiry statuses",
    "FEE_HEAD": "Fee heads",
    "EXAM_TERM": "Exam terms",
    "FEE_TERM": "Fee terms",   # NEW (D1.13)
}


class ContextVocabError(Exception):
    """Base error for context-vocabulary parsing/lookup."""


@dataclass
class AcademicYear:
    id: int
    name: str
    is_current: bool = False
    previous_year_id: Optional[int] = None


@dataclass
class BranchVocab:
    """One branch's real master-data vocabulary, from the Context JSON."""
    branch_id: int
    name: Optional[str] = None
    is_primary: bool = False
    academic_years: List[AcademicYear] = field(default_factory=list)
    # concept_type -> ordered list of real values for this branch
    vocab: Dict[str, List[str]] = field(default_factory=dict)

    @property
    def current_academic_year(self) -> Optional[AcademicYear]:
        for ay in self.academic_years:
            if ay.is_current:
                return ay
        return None

    def values(self, concept_type: str) -> List[str]:
        return self.vocab.get(concept_type, [])

    # ── (b) validation ──
    def is_member(self, concept_type: str, value: str) -> bool:
        """EXACT (case-sensitive) membership — matches the DB literal exactly."""
        return value in self.vocab.get(concept_type, [])

    def match_ci(self, concept_type: str, value: str) -> List[str]:
        """
        Case-insensitive matches (0, 1, or 2+). Used to detect near-misses:
          - 1 CI match but not exact  -> route to disambiguation/normalize
          - 0 matches                 -> not recognized (fail closed)
          - 2+ matches                -> genuine ambiguity (e.g. 'TERM I' vs
                                         'TERM-I' if they folded — surface both)
        """
        if not value:
            return []
        needle = value.strip().lower()
        return [v for v in self.vocab.get(concept_type, []) if v.strip().lower() == needle]


@dataclass
class UserContextVocab:
    """Parsed Context JSON: user identity + per-branch vocabularies."""
    user_id: int
    username: str = ""
    staff_name: str = ""
    is_super_user: bool = False
    target_database: Optional[str] = None   # DBPrefix
    short_name: Optional[str] = None
    branches: Dict[int, BranchVocab] = field(default_factory=dict)

    def branch(self, branch_id: int) -> BranchVocab:
        b = self.branches.get(branch_id)
        if b is None:
            raise ContextVocabError(f"Branch {branch_id} not in this user's context.")
        return b

    @property
    def branch_ids(self) -> List[int]:
        return list(self.branches.keys())


def parse_context_json(payload: Union[str, Dict[str, Any]]) -> UserContextVocab:
    """
    Parse the ERP Context JSON (string or dict) into a UserContextVocab.

    Fail-closed on missing UserMasterDetails; tolerant of missing optional
    concept arrays (a branch simply has an empty vocab for that concept).
    Also tolerant of a missing "FeeTerms" key — see add_fee_terms_fallback().
    """
    if isinstance(payload, str):
        try:
            payload = json.loads(payload)
        except json.JSONDecodeError as e:
            raise ContextVocabError(f"Context JSON is not valid JSON: {e}")

    umd = (payload or {}).get("UserMasterDetails")
    if not isinstance(umd, dict):
        raise ContextVocabError("Context JSON missing 'UserMasterDetails'.")

    uid = umd.get("Id")
    if uid is None:
        raise ContextVocabError("Context JSON missing UserMasterDetails.Id.")

    ctx = UserContextVocab(
        user_id=int(uid),
        username=umd.get("UserName") or "",
        staff_name=umd.get("StaffName") or "",
        is_super_user=bool(umd.get("IsSuperUser", False)),
        target_database=umd.get("DBPrefix"),
        short_name=umd.get("ShortName"),
    )

    for b in umd.get("UserBranchDetails", []) or []:
        bid = b.get("ID")
        if bid is None:
            continue  # skip malformed branch entries rather than guess an ID
        bid = int(bid)

        ays = []
        for ay in b.get("AcademicYears", []) or []:
            if ay.get("Id") is None:
                continue
            ays.append(AcademicYear(
                id=int(ay["Id"]),
                name=ay.get("Name") or "",
                is_current=bool(ay.get("IsCurrentYear", False)),
                previous_year_id=ay.get("PreviousAcademicYearID"),
            ))

        vocab: Dict[str, List[str]] = {}
        for concept_type, json_key in CONCEPT_TO_JSON_KEY.items():
            raw = b.get(json_key, []) or []
            values: List[str] = []
            if concept_type == "CLASS":
                # Classes are objects {Name, DisplayOrder} — order by DisplayOrder.
                objs = [c for c in raw if isinstance(c, dict) and c.get("Name")]
                objs.sort(key=lambda c: c.get("DisplayOrder", 1_000_000))
                values = [c["Name"] for c in objs]
            else:
                # Others are plain string lists (preserve given order).
                values = [str(v) for v in raw if v is not None and str(v) != ""]
            vocab[concept_type] = values

        ctx.branches[bid] = BranchVocab(
            branch_id=bid,
            name=b.get("Name"),
            is_primary=bool(b.get("IsPrimary", False)),
            academic_years=ays,
            vocab=vocab,
        )

    return ctx


# ── (a) prompt-time injection ──
def build_injection_prompt(
    branch: BranchVocab,
    concept_types: Optional[List[str]] = None,
    max_values_per_concept: Optional[int] = None,
) -> str:
    """
    Build a compact vocabulary block to inject into the model's system prompt so
    it uses this branch's EXACT real literals while generating SQL.

    Args:
        branch: the resolved BranchVocab for the user's selected branch.
        concept_types: which concepts to include (default: all with values).
        max_values_per_concept: optional cap (e.g. if a Subjects list is huge);
            None = include all. When capped, appends an ellipsis marker.

    Returns a string like:

        This branch's real master-data values (use these EXACT names):
        - Classes: GATE-1, GATE-2, GATE-3, I, II, III, IV, V, VI, VII, VIII, IX, X
        - Subjects: Biology, Chemistry, ...
        - Enquiry statuses: Initiated, Updated, Completed, Dropped
        ...
    """
    types = concept_types or [t for t in CONCEPT_TO_JSON_KEY if branch.values(t)]
    lines = ["This branch's real master-data values (use these EXACT names, do not invent or approximate):"]
    for t in types:
        vals = branch.values(t)
        if not vals:
            continue
        shown = vals
        suffix = ""
        if max_values_per_concept and len(vals) > max_values_per_concept:
            shown = vals[:max_values_per_concept]
            suffix = ", …"
        label = _CONCEPT_PROMPT_LABEL.get(t, t)
        lines.append(f"- {label}: {', '.join(shown)}{suffix}")
    return "\n".join(lines)


# ── D1.13: FeeTerms fallback (when API doesn't return FeeTerms) ────────────

def add_fee_terms_fallback(ctx: UserContextVocab, branch_id: int,
                            fee_terms: List[str]) -> None:
    """
    When the real GetUserContext API doesn't return FeeTerms yet, call this with
    the result of `SELECT Name FROM TermMaster WHERE BranchID=? AND
    AcademicYearID=? AND IsDeleted=0` to populate the FEE_TERM vocab for the
    branch. Same pattern as the existing _merge_local_sections fallback in
    user_context_api.py and the _merge_local_fee_terms fallback added in the
    same round-2 pass.

    Idempotent: overwrites any prior FEE_TERM vocab for that branch (does NOT
    merge — the caller is responsible for de-duplication and ordering; the
    TermMaster query result is the canonical ordered list).
    """
    if not isinstance(ctx, UserContextVocab):
        raise TypeError("add_fee_terms_fallback expects a UserContextVocab.")
    branch = ctx.branch(branch_id)
    branch.vocab["FEE_TERM"] = [str(v) for v in (fee_terms or []) if v is not None]

"""
question_extractor.py — Option 1.5: Question-Level Entity Preprocessor
=======================================================================

PURPOSE
-------
Extracts entities from the user's NATURAL-LANGUAGE QUESTION (before the LLM
runs) and augments the system prompt with vocab-aware hints. This is the
"lightweight deterministic preprocessor" from the Option 1.5 design:

  Question: "how many students in 10 a?"
      |
      v
  +-------------------------------------------+
  |  QuestionExtractor.extract(question, ctx) |  ~5ms (no LLM)
  |  Output: {class: "10", section: "A"}      |
  +-------------------------------------------+
      |
      v
  +-------------------------------------------+
  |  Augment the system prompt:               |
  |  "The user mentioned class '10' AND        |
  |   section 'A'. Include BOTH filters."     |
  +-------------------------------------------+
      |
      v
     LLM (one call, 15-35s)  -- now with hints

WHY THIS EXISTS (the gap it fills)
----------------------------------
The existing pipeline/entity_extractor.py extracts values from the SQL
(AFTER the LLM runs) for validation. It can't help the LLM write better SQL
— by then the SQL is already generated. This module runs BEFORE the LLM,
so it can PREVENT errors instead of just catching them.

Real bug this fixes: "how many students in 10 a?" — the LLM ignored "a"
(section A) and counted all 32 students in class 10. With this preprocessor,
the prompt will explicitly say "the user mentioned section A", and the LLM
is far less likely to skip it.

WHAT IT EXTRACTS
----------------
1. CLASS — "class 10", "10 a", "grade 10", "X", "class x", etc.
   - Matches against the branch's actual Classes list (from Context JSON)
   - Handles Arabic numerals (10), Roman numerals (X), and word forms (ten)
   - Maps "10" → all matching class names: ["X", "GRADE X", "ClassX", ...]

2. SECTION — single letters after a class: "10 a", "10-A", "10A", "section A"
   - Matches against the branch's Sections list
   - Only extracted if the branch actually HAS sections (avoids false positives)

3. ACADEMIC YEAR — "this year", "last year", "2026-2027"
   - Maps to the branch's AcademicYears list

4. EXAM TERM — "term 1", "term 2", "annual exam"
   - Matches against the branch's ExamTerms list

5. FEE TERM — "term 1 fees", "term 2 outstanding"
   - Matches against the branch's FeeTerms list

WHAT IT DOES NOT DO
-------------------
- It does NOT write SQL (that's the LLM's job)
- It does NOT replace the LLM (it augments the prompt)
- It does NOT validate values (that's the VALIDATE stage's job)
- It does NOT call any external API
- It does NOT add latency (runs in ~5ms, vs. 15-35s for the LLM)

SAFETY
------
The extracted entities are HINTS, not constraints. The LLM can ignore them
if it disagrees (e.g., if "a" in "10 a" actually means something else in
context). The hints are phrased as observations ("the user mentioned X"),
not commands ("filter by X"). This keeps the LLM's flexibility intact
while reducing the chance it misses obvious entities.

VOCAB-AWARENESS
---------------
The key advantage over retraining: this module has access to the user's
ACTUAL branch vocab (from the Context JSON) at runtime. The LLM was
trained on generic data and doesn't know that YOUR school has classes
named "GRADE X" AND "X" AND "ClassX" AND "class x". This module does.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple


# ── Regex patterns for question-level extraction ───────────────────────────

# Class patterns: "class 10", "class 10 a", "grade 10", "10 a", "10a", "X", "class x"
# Strategy: look for explicit "class/grade" keywords OR a number+letter combo
_CLASS_KEYWORD = re.compile(
    r'\b(?:class|grade|std|standard)\s+([0-9]+|[ivxlcdm]+|[a-z]+)\b',
    re.IGNORECASE,
)
# "10 a", "10-a", "10a" — number immediately followed by a single letter
_CLASS_SECTION_COMPACT = re.compile(
    r'\b([0-9]{1,2})\s*[-]?\s*([a-z])\b',
    re.IGNORECASE,
)
# Standalone Roman numerals (could be a class): "X", "VIII", "XII"
_ROMAN_NUMERAL = re.compile(r'\b([ivxlcdm]+)\b', re.IGNORECASE)
# "section A", "sec A", "section a"
_SECTION_KEYWORD = re.compile(
    r'\b(?:section|sec)\s+([a-z])\b',
    re.IGNORECASE,
)

# Academic year patterns
_YEAR_RELATIVE = re.compile(
    r'\b(this\s+year|current\s+year|last\s+year|previous\s+year|next\s+year)\b',
    re.IGNORECASE,
)
_YEAR_ABSOLUTE = re.compile(r'\b(20[0-9]{2})\s*[-–]\s*(20[0-9]{2})\b')

# Exam/fee term patterns
_EXAM_TERM = re.compile(
    r'\b(exam\s+term|term\s+([0-9]+|one|two|three|four|i|ii|iii|iv))\b',
    re.IGNORECASE,
)


# ── Number-to-Roman and Roman-to-Number maps (for class matching) ──────────

_ROMAN_TO_NUM = {
    'i': 1, 'ii': 2, 'iii': 3, 'iv': 4, 'v': 5, 'vi': 6, 'vii': 7,
    'viii': 8, 'ix': 9, 'x': 10, 'xi': 11, 'xii': 12, 'xiii': 13,
}
_NUM_TO_ROMAN = {v: k for k, v in _ROMAN_TO_NUM.items()}

_WORD_TO_NUM = {
    'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5, 'six': 6,
    'seven': 7, 'eight': 8, 'nine': 9, 'ten': 10, 'eleven': 11, 'twelve': 12,
}


def _normalize_class_token(token: str) -> Optional[int]:
    """Convert a class token (from the question) to a number 1-12.
    Returns None if the token isn't a recognizable class number.
    """
    t = token.strip().lower()
    if t in _WORD_TO_NUM:
        return _WORD_TO_NUM[t]
    if t in _ROMAN_TO_NUM:
        return _ROMAN_TO_NUM[t]
    if t.isdigit():
        n = int(t)
        if 1 <= n <= 12:
            return n
    return None


def _extract_class_number_from_name(class_name: str) -> Optional[int]:
    """Extract a class number from a class name in the branch vocab.
    e.g. "Class 10" -> 10, "X" -> 10, "GRADE X" -> 10, "class x" -> 10,
         "CLASS TENN" -> 10, "KG" -> None, "PREKG" -> None
    """
    name = class_name.strip().lower()
    # Direct Roman numeral match
    if name in _ROMAN_TO_NUM:
        return _ROMAN_TO_NUM[name]
    # "class 10", "grade 10"
    m = re.match(r'^(?:class|grade|std|standard)\s+([0-9]+|[ivxlcdm]+)$', name)
    if m:
        return _normalize_class_token(m.group(1))
    # "classx", "class10" (no space)
    m = re.match(r'^(?:class|grade)([0-9]+|[ivxlcdm]+)$', name)
    if m:
        return _normalize_class_token(m.group(1))
    # "class ten", "class twelve"
    m = re.match(r'^(?:class|grade)\s+(one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)', name)
    if m:
        return _WORD_TO_NUM.get(m.group(1))
    # "class tenn", "class twelvee" (typos with extra letters)
    m = re.match(r'^(?:class|grade)\s+(ten|eleven|twelve|one|two|three|four|five|six|seven|eight|nine)', name)
    if m:
        return _WORD_TO_NUM.get(m.group(1))
    return None


# ── Main extractor ─────────────────────────────────────────────────────────

def extract_from_question(question: str, ctx: Any = None) -> Dict[str, Any]:
    """
    Extract entities from a natural-language question.

    Args:
        question: the user's question (e.g. "how many students in 10 a?")
        ctx: the UserContext (from build_context_from_json). Optional —
             if provided, extracted entities are matched against the branch's
             actual vocab (Classes, Sections, etc.) for vocab-awareness.

    Returns a dict with keys:
        - class_num: int or None (e.g. 10)
        - class_names: list of actual class names from the branch vocab
                       that match the extracted number (e.g. ["X", "GRADE X", "ClassX"])
        - section: str or None (e.g. "A")
        - academic_year: str or None (e.g. "current" or "2026-2027")
        - exam_term: str or None (e.g. "term 1")
        - hints: str — the prompt augmentation text (empty if nothing extracted)
        - raw: dict of raw extracted values (for the trace/audit log)
    """
    result: Dict[str, Any] = {
        "class_num": None,
        "class_names": [],
        "section": None,
        "academic_year": None,
        "exam_term": None,
        "hints": "",
        "raw": {},
    }

    if not question:
        return result

    q = question.strip()

    # ── 1. Extract CLASS ──────────────────────────────────────────────────
    class_num: Optional[int] = None

    # Try "class 10", "grade 10", "std 10"
    m = _CLASS_KEYWORD.search(q)
    if m:
        class_num = _normalize_class_token(m.group(1))

    # Try "10 a" compact notation (also extracts section)
    if class_num is None:
        m = _CLASS_SECTION_COMPACT.search(q)
        if m:
            class_num = _normalize_class_token(m.group(1))
            if class_num and not result["section"]:
                result["section"] = m.group(2).upper()

    # Try "1brainy" — number followed by a WORD (not just a single letter).
    # This catches cases like "1brainy", "2expert", "3foundation" where the
    # section is a named section (not A/B/C). The section name is extracted
    # as-is (lowercased) and passed through even if the branch's Sections
    # list is empty (some schools don't return Sections from their API).
    # Guard against false positives: skip common English words that might
    # follow a number (e.g. "10 students", "5 results", "3 people").
    _SECTION_BLOCKLIST = {
        'students', 'student', 'results', 'result', 'people', 'person',
        'teachers', 'teacher', 'staff', 'classes', 'class', 'sections',
        'section', 'subjects', 'subject', 'fees', 'fee', 'years', 'year',
        'days', 'day', 'months', 'month', 'rows', 'row', 'count', 'total',
        'marks', 'mark', 'grade', 'grades', 'exam', 'exams', 'term',
        'terms', 'boys', 'boy', 'girls', 'girl', 'male', 'female',
        'present', 'absent', 'active', 'inactive', 'new', 'old',
    }
    if class_num is None:
        m = re.search(r'\b([0-9]{1,2})\s*([a-zA-Z]{2,})\b', q)
        if m:
            potential_class = _normalize_class_token(m.group(1))
            potential_section = m.group(2).lower()
            # Only accept if the number is a valid class (1-12) AND the word
            # is NOT a common English word from the blocklist
            if potential_class and potential_section not in _SECTION_BLOCKLIST:
                class_num = potential_class
                if not result["section"]:
                    result["section"] = m.group(2)
                    result["raw"]["section_match_method"] = "number_plus_word"

    # Try standalone Roman numeral (but only if it looks like a class context)
    if class_num is None:
        # Look for "class X" or "in X" or "of X" where X is Roman
        for m in _ROMAN_NUMERAL.finditer(q):
            token = m.group(1).lower()
            if token in _ROMAN_TO_NUM:
                # Check if there's a class-related keyword nearby
                start = max(0, m.start() - 15)
                context = q[start:m.end() + 15].lower()
                if any(kw in context for kw in ['class', 'grade', 'std', 'in ', 'of ']):
                    class_num = _ROMAN_TO_NUM[token]
                    break

    if class_num is not None:
        result["class_num"] = class_num
        result["raw"]["class_num"] = class_num

        # Vocab-aware matching: find all class names in the branch that
        # correspond to this class number
        if ctx is not None:
            class_names = _match_class_to_vocab(class_num, ctx)
            if class_names:
                result["class_names"] = class_names
                result["raw"]["class_names"] = class_names

    # ── 2. Extract SECTION ────────────────────────────────────────────────
    if not result["section"]:
        m = _SECTION_KEYWORD.search(q)
        if m:
            result["section"] = m.group(1).upper()
            result["raw"]["section"] = result["section"]

    # ── 2b. Vocab-aware section name matching ────────────────────────────
    # If the branch uses NAMED sections (BRAINY, EXPERT, FOUNDATION) instead
    # of A/B/C, the user might type "1brainy" or "in brainy" or "expert class".
    # Scan the question for any branch section name (case-insensitive).
    # This catches cases the single-letter patterns miss.
    if not result["section"] and ctx is not None:
        sections = _get_branch_sections(ctx)
        if sections:
            q_lower = q.lower()
            for sec in sections:
                if not sec or sec.upper() == 'ALL':
                    continue  # skip "All" — it's not a real section filter
                # Match the section name as a whole word (case-insensitive).
                # Use lowercase section name against lowercase question.
                sec_lower = sec.lower()
                # First try word-boundary match (e.g. "in brainy" or "class 1 brainy")
                if re.search(r'\b' + re.escape(sec_lower) + r'\b', q_lower):
                    result["section"] = sec  # use the actual vocab name (preserves case)
                    result["raw"]["section"] = sec
                    result["raw"]["section_match_method"] = "vocab_name"
                    break
                # Also try without leading word boundary — catches "1brainy"
                # where the section name is glued to a number with no space
                if re.search(re.escape(sec_lower), q_lower):
                    result["section"] = sec
                    result["raw"]["section"] = sec
                    result["raw"]["section_match_method"] = "vocab_name_compact"
                    break

    # Also try to extract a class number from compact forms like "1brainy"
    # (number immediately followed by a section name, no space)
    if result["section"] and class_num is None and ctx is not None:
        # Look for a number prefix before the matched section name
        sec = result["section"]
        pattern = re.compile(r'\b([0-9]{1,2})\s*' + re.escape(sec) + r'\b', re.IGNORECASE)
        m = pattern.search(q)
        if m:
            class_num = _normalize_class_token(m.group(1))
            if class_num is not None:
                result["class_num"] = class_num
                result["raw"]["class_num"] = class_num
                result["raw"]["class_match_method"] = "compact_with_section_name"
                # Vocab-aware matching
                class_names = _match_class_to_vocab(class_num, ctx)
                if class_names:
                    result["class_names"] = class_names
                    result["raw"]["class_names"] = class_names

    # Validate section against the branch's Sections list (if available).
    # IMPORTANT: do NOT clear the section if it's not in the branch vocab —
    # the branch might use named sections (BRAINY, EXPERT) instead of A/B/C,
    # but the user clearly MENTIONED "A". Pass it through as a hint; the LLM
    # + VALIDATE stage will handle it. We just add a note if it's not in vocab.
    if result["section"] and ctx is not None:
        sections = _get_branch_sections(ctx)
        if sections:
            sec_upper = result["section"].upper()
            matched = [s for s in sections if s.upper() == sec_upper]
            if not matched:
                # Don't clear — just note it for the trace
                result["raw"]["section_note"] = (
                    f"Section '{sec_upper}' not in branch sections list "
                    f"({len(sections)} sections: {sections[:3]}...). "
                    f"Passing through as a hint — the LLM will decide."
                )

    # ── 3. Extract ACADEMIC YEAR ──────────────────────────────────────────
    m = _YEAR_RELATIVE.search(q)
    if m:
        phrase = m.group(1).lower()
        if 'this' in phrase or 'current' in phrase:
            result["academic_year"] = "current"
        elif 'last' in phrase or 'previous' in phrase:
            result["academic_year"] = "previous"
        elif 'next' in phrase:
            result["academic_year"] = "next"
        result["raw"]["academic_year"] = result["academic_year"]

    m = _YEAR_ABSOLUTE.search(q)
    if m:
        result["academic_year"] = f"{m.group(1)}-{m.group(2)}"
        result["raw"]["academic_year"] = result["academic_year"]

    # ── 4. Extract EXAM TERM ──────────────────────────────────────────────
    m = _EXAM_TERM.search(q)
    if m:
        result["exam_term"] = m.group(0).strip()
        result["raw"]["exam_term"] = result["exam_term"]

    # ── 5. Build the prompt hints ─────────────────────────────────────────
    result["hints"] = _build_hints(result)

    return result


def _match_class_to_vocab(class_num: int, ctx: Any) -> List[str]:
    """Find all class names in the branch vocab that correspond to class_num.
    e.g. class_num=10 → ["X", "GRADE X", "ClassX", "class x"] if those exist
    in the branch's Classes list.
    """
    classes = _get_branch_classes(ctx)
    if not classes:
        return []

    matched = []
    for class_name in classes:
        extracted = _extract_class_number_from_name(class_name)
        if extracted == class_num:
            matched.append(class_name)
    return matched


def _get_branch_classes(ctx: Any) -> List[str]:
    """Get the list of class names for the selected branch from the context."""
    try:
        if hasattr(ctx, 'vocab') and ctx.vocab is not None:
            branch_id = ctx.selected_branch_id
            if branch_id is not None:
                bv = ctx.vocab.branch(branch_id)
                # BranchVocab has a values(concept_type) method that returns
                # the list of values for that concept (CLASS, SECTION, etc.)
                if hasattr(bv, 'values'):
                    return list(bv.values("CLASS"))
                # Fallback: check the vocab dict directly
                if hasattr(bv, 'vocab') and isinstance(bv.vocab, dict):
                    return list(bv.vocab.get("CLASS", []))
    except Exception:
        pass
    return []


def _get_branch_sections(ctx: Any) -> List[str]:
    """Get the list of section names for the selected branch from the context."""
    try:
        if hasattr(ctx, 'vocab') and ctx.vocab is not None:
            branch_id = ctx.selected_branch_id
            if branch_id is not None:
                bv = ctx.vocab.branch(branch_id)
                if hasattr(bv, 'values'):
                    return list(bv.values("SECTION"))
                if hasattr(bv, 'vocab') and isinstance(bv.vocab, dict):
                    return list(bv.vocab.get("SECTION", []))
    except Exception:
        pass
    return []


def _build_hints(extracted: Dict[str, Any]) -> str:
    """Build the prompt augmentation text from extracted entities.
    Returns an empty string if nothing was extracted.
    The hints are phrased as OBSERVATIONS, not commands — the LLM can
    ignore them if it disagrees.
    """
    parts: List[str] = []

    if extracted["class_num"] is not None:
        if extracted["class_names"]:
            names_str = ", ".join(f"'{n}'" for n in extracted["class_names"])
            parts.append(
                f"The user mentioned class {extracted['class_num']}. "
                f"In this branch's vocabulary, the matching class names are: {names_str}. "
                f"Use one or more of these in the cm.Name IN (...) clause."
            )
        else:
            parts.append(
                f"The user mentioned class {extracted['class_num']}. "
                f"Include a class filter (e.g. cm.Name IN ('Class {extracted['class_num']}', "
                f"'{_NUM_TO_ROMAN.get(extracted['class_num'], 'X')}'))."
            )

    if extracted["section"]:
        parts.append(
            f"The user mentioned section '{extracted['section']}'. "
            f"Include a section filter (e.g. secm.Name = '{extracted['section']}' "
            f"OR JOIN SectionMaster). Do NOT skip the section filter."
        )

    if extracted["academic_year"]:
        ay = extracted["academic_year"]
        if ay == "current":
            parts.append(
                "The user asked about the CURRENT academic year. "
                "Use @AcademicYearID (the backend resolves it) or "
                "GETDATE() BETWEEN Start_Date AND End_Date."
            )
        elif ay == "previous":
            parts.append(
                "The user asked about the PREVIOUS academic year. "
                "Use the PreviousAcademicYearID from the Context JSON."
            )
        else:
            parts.append(f"The user asked about academic year {ay}.")

    if extracted["exam_term"]:
        parts.append(
            f"The user mentioned exam term '{extracted['exam_term']}'. "
            f"Include an exam-term filter if relevant."
        )

    if not parts:
        return ""

    return (
        "\n\n[ENTITY HINTS from question analysis — these are observations, "
        "not constraints. Use them to write more accurate SQL.]\n"
        + "\n".join(parts)
    )


# ── Self-test ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    # Test with a mock context (no real branch vocab)
    class MockCtx:
        selected_branch_id = 1
        vocab = None
        context_json = None

    test_questions = [
        "how many students in 10 a?",
        "how many students are there in class 10?",
        "who is the principal?",
        "students in class 8 section B",
        "fee outstanding for this year",
        "top 5 students by marks in term 1",
        "attendance for 2025-2026",
        "how many students in grade X?",
    ]

    print("=== Question Extractor Self-Test ===\n")
    ctx = MockCtx()
    for q in test_questions:
        result = extract_from_question(q, ctx)
        print(f"Q: {q}")
        print(f"  class_num={result['class_num']}, section={result['section']}, "
              f"year={result['academic_year']}, exam_term={result['exam_term']}")
        if result['class_names']:
            print(f"  class_names (vocab match): {result['class_names']}")
        if result['hints']:
            print(f"  hints: {result['hints'][:120]}...")
        print()

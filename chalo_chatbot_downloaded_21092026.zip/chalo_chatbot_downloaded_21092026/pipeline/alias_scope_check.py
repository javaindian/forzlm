"""
AI Secretary — Application Layer :: Alias-Scope Validation Pass (Component #4)
=============================================================================

Purpose
-------
A second, cheap, deterministic validation pass that runs ALONGSIDE the existing
schema guardrail (finetune/sql_guardrail.py) — it does NOT replace or modify it.

The existing guardrail validates that every referenced table/column EXISTS in
the schema, using a single flat alias scope. By its own documented design it
does NOT track per-subquery alias scope. That leaves one specific, confirmed
bug class uncaught:

    Msg 4104 — "The multi-part identifier could not be bound."

This happens when an alias is defined (joined) INSIDE one subquery, but then
referenced OUTSIDE that subquery — where the alias is not in scope. The column
genuinely exists on the table, so the existence guardrail passes it; the query
still fails at execution. This exact bug was found post-delivery in a
multi-subquery training example (the MinMark join present in only one of two
subqueries) and could not be caught by the existing tool.

What this pass does
-------------------
1. Walk the SQL tracking parenthesis depth to delimit subquery scopes.
2. Record, for every alias introduced by `FROM/JOIN <table> [AS] <alias>`,
   the scope (paren-depth path) in which it was defined.
3. For every `alias.column` reference, check the alias is VISIBLE from the
   reference's scope. SQL scoping is lexical + outward: a reference can see
   aliases defined in its own scope or any ENCLOSING (ancestor) scope, but
   NOT aliases defined in a sibling or inner (already-closed) subquery.
4. Flag any reference whose alias is not visible → likely Msg 4104.
5. 2026-09-07 (GAP FIX, real-world Msg 4104 on "top student in 7 in Term 1"):
   a qualifier that was NEVER DEFINED ANYWHERE in the statement (e.g. the
   model wrote `cm.Name = 'VII'` with no ClassMaster join at all) used to be
   SKIPPED here because "the existence guardrail owns that verdict" — but the
   existence guardrail also skips unknown qualifiers ("skip rather than
   false-flag"), so the bug fell through the gap and failed at SQL Server
   with Msg 4104. Both checkers now agree: THIS pass owns every
   unknown-qualifier verdict. A qualifier that is not a reserved word, not a
   parameter, not a schema prefix (sys/information_schema/dbo), not a
   multi-part name prefix, and never defined as a table/alias/CTE/derived
   alias is now flagged as `undefined_alias` → REFUSED (and with the v98
   orchestrator retry, auto-repaired once before the user ever sees it).

Deliberate limits (honest, per Bible Rule 6)
--------------------------------------------
- This is a heuristic paren-depth scope model, not a full T-SQL parser. It is
  intended to catch the specific "alias used outside its subquery" class, not
  to be a complete scope resolver.
- Bracketed qualifiers (`[cm].Name`) are invisible to the word-based regex
  and therefore never flagged (the model overwhelmingly emits unbracketed
  SQL; bracketed SQL is rare and self-repairing via the retry).
- It does not resolve correlated-subquery edge cases where an inner query
  legitimately references an outer alias (those are ALLOWED here — outward
  visibility is permitted, which is correct).
- Parameters (@x), CTE names, and reserved words are ignored as qualifiers.
- It assumes reasonably well-formed SQL from the model + existing guardrail.

No hardcoded paths or client names (Bible Rule 1). Pure-Python, no new deps.

Reconstructed from the original app_layer/ code (no round-2 changes — unchanged).
Diff against your real files before deploying.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple
from functools import lru_cache


@dataclass
class AliasScopeIssue:
    kind: str            # "alias_out_of_scope" | "undefined_alias"
    detail: str


@dataclass
class AliasScopeResult:
    is_valid: bool
    issues: List[AliasScopeIssue] = field(default_factory=list)
    # alias -> ALL scope paths where it was defined (a name can legitimately
    # be redefined in multiple sibling subqueries -- see fix note below)
    alias_scopes: Dict[str, List[Tuple[int, ...]]] = field(default_factory=dict)

    def summary(self) -> str:
        if self.is_valid:
            return "PASS — no out-of-scope alias references detected."
        lines = [f"FAIL — {len(self.issues)} alias-scope issue(s):"]
        for i in self.issues:
            lines.append(f"  [{i.kind}] {i.detail}")
        return "\n".join(lines)


_RESERVED = {
    "select", "from", "where", "group", "order", "having", "and", "or",
    "not", "in", "is", "null", "as", "on", "join", "inner", "left",
    "right", "outer", "cross", "apply", "case", "when", "then", "else",
    "end", "top", "distinct", "union", "all", "with", "cast", "sum",
    "count", "avg", "min", "max", "isnull", "getdate", "dateadd",
    "datediff", "datepart", "datename", "convert", "over", "partition",
    "by", "format", "month", "year", "day", "exists", "dbo", "asc", "desc",
    "like", "between", "coalesce", "row_number", "rank", "dense_rank",
}

# FROM/JOIN <table> [AS] <alias>
_FROM_JOIN = re.compile(
    r"\b(?:FROM|JOIN)\s+(?:\[?dbo\]?\.)?\[?(\w+)\]?\s*(?:AS\s+)?(\w+)?",
    re.IGNORECASE,
)
# CTE names — declared as valid pseudo-tables, always visible (like the
# existing guardrail, we don't scope-check CTE bodies).
_CTE = re.compile(r"(?:\bWITH\s+|,\s*)(\w+)\s+AS\s*\(", re.IGNORECASE)
# alias.column references (excluding function calls "x.y(")
_ALIAS_COL = re.compile(r"\b(\w+)\.(\w+)\b(?!\s*\()")
# alias.* references ("SELECT cm.*" fails Msg 4104 exactly like cm.Name)
_ALIAS_STAR = re.compile(r"\b(\w+)\.\*")
# qualified FROM/JOIN: FROM [db.][schema.]table [AS] alias — captures the
# TABLE NAME (last dotted component) and optional ALIAS. Needed so that
# 3-part names like "FROM V3_TestDatabase.dbo.Student_Master sm" still
# register "student_master" + "sm" as defined.
_FROM_JOIN_QUALIFIED = re.compile(
    r"\b(?:FROM|JOIN)\s+(?:\[?(\w+)\]?\.)+\[?(\w+)\]?\s*(?:AS\s+)?(\w+)?",
    re.IGNORECASE,
)
# Old-style comma joins: "FROM TotalCollected tc, TotalStructure ts". The
# second+ tables in a FROM list are separated by COMMAS, which no FROM/JOIN
# regex can see. Without this scan, "ts.TotalDemand" (defined as
# "TotalStructure ts" after a comma) is wrongly flagged as undefined — real
# false positives found in 8 training rows on the first regression run.
# Over-matching here is harmless: extra registrations only ever SUPPRESS a
# flag (and _RESERVED filters junk words like DESC/HAVING).
_COMMA_TABLE = re.compile(
    r"(?:\bFROM|,)\s+(?:\[?(\w+)\]?\.)?\[?(\w+)\]?\s+(?:AS\s+)?(\w+)",
    re.IGNORECASE,
)
# derived-table / derived-column aliases: `) x` or `) AS x`. Recording these
# is essential: "FROM (SELECT ...) x" defines x AFTER the closing paren, and
# x.col references would otherwise be flagged as undefined (false positive).
_DERIVED_ALIAS = re.compile(r"\)\s*(?:AS\s+)?(\w+)", re.IGNORECASE)
# Schema/catalog prefixes that legally appear as qualifier.word but are NOT
# aliases: "sys.tables", "INFORMATION_SCHEMA.COLUMNS", "dbo.X" (dbo is also
# in _RESERVED).
_NON_ALIAS_QUALIFIERS = {"sys", "information_schema", "dbo"}


def _strip_comments(sql: str) -> str:
    """Remove -- line comments and /* block */ comments, respecting string
    literals ('...' — a '--' inside a literal is data, not a comment).
    Newlines are preserved so downstream regexes stay line-anchored."""
    out: List[str] = []
    i, n = 0, len(sql)
    in_str = False
    while i < n:
        ch = sql[i]
        if ch == "'":
            in_str = not in_str
            out.append(ch)
            i += 1
        elif not in_str and ch == "-" and i + 1 < n and sql[i + 1] == "-":
            while i < n and sql[i] != "\n":
                i += 1
        elif not in_str and ch == "/" and i + 1 < n and sql[i + 1] == "*":
            i += 2
            while i + 1 < n and not (sql[i] == "*" and sql[i + 1] == "/"):
                i += 1
            i += 2
        else:
            out.append(ch)
            i += 1
    return "".join(out)


def _scope_at(pos: int, open_positions: List[Tuple[int, Tuple[int, ...]]]) -> Tuple[int, ...]:
    """Return the scope-path active at character position `pos`."""
    active: Tuple[int, ...] = ()
    for p, path in open_positions:
        if p <= pos:
            active = path
        else:
            break
    return active


def _is_ancestor_or_same(def_scope: Tuple[int, ...], ref_scope: Tuple[int, ...]) -> bool:
    """
    True if an alias defined in `def_scope` is visible from `ref_scope`.

    Visibility rule (lexical, outward): the reference can see the alias iff the
    alias's defining scope is the reference's scope OR an ANCESTOR of it, i.e.
    def_scope is a prefix of ref_scope.
    """
    if len(def_scope) > len(ref_scope):
        return False
    return ref_scope[: len(def_scope)] == def_scope


def _visible_from_any(def_scopes: List[Tuple[int, ...]], ref_scope: Tuple[int, ...]) -> bool:
    """
    True if the alias is visible from ref_scope via ANY of its definitions.

    FIX (found via real testing against the actual training dataset): the
    same alias name is legitimately redefined in multiple sibling
    subqueries throughout this project's real SQL -- e.g. two UNION ALL
    branches each independently joining "FeesCollection fc" and only
    referencing fc within their own branch. The original single-scope
    model kept only one definition and incorrectly flagged the second
    branch's valid, in-scope references as out-of-scope. Confirmed via a
    full run against all 2,417 real v16 examples: 20 false positives, all
    of this exact shape, zero genuine Msg 4104 risks among them.
    """
    return any(_is_ancestor_or_same(ds, ref_scope) for ds in def_scopes)


@lru_cache(maxsize=1024)
def check_alias_scope(sql: str) -> AliasScopeResult:
    issues: List[AliasScopeIssue] = []
    sql = _strip_comments(sql)  # comments may contain alias.col text -> false positives

    # ── Build a per-character scope path by walking parentheses ──
    # Each '(' opens a child scope; scope path is the sequence of child indices
    # from the root, e.g. () = root, (0,) = first subquery, (0,1) = ...
    scope_path: Tuple[int, ...] = ()
    child_counters: Dict[Tuple[int, ...], int] = {}
    # timeline of (char_position, active_scope_path) at each open/close boundary
    timeline: List[Tuple[int, Tuple[int, ...]]] = [(0, ())]
    stack: List[Tuple[int, ...]] = [()]

    i, n = 0, len(sql)
    # track string literals so parens inside '...' don't affect scoping
    in_str = False
    while i < n:
        ch = sql[i]
        if ch == "'":
            in_str = not in_str
        elif not in_str and ch == "(":
            parent = stack[-1]
            idx = child_counters.get(parent, 0)
            child_counters[parent] = idx + 1
            child = parent + (idx,)
            stack.append(child)
            timeline.append((i + 1, child))
        elif not in_str and ch == ")":
            if len(stack) > 1:
                stack.pop()
            timeline.append((i + 1, stack[-1]))
        i += 1

    timeline.sort(key=lambda t: t[0])

    cte_names = {m.group(1).lower() for m in _CTE.finditer(sql)}

    # ── Record where each alias is defined (ALL its scope paths -- an
    #    alias name can legitimately be redefined in multiple sibling
    #    subqueries, see _visible_from_any's docstring) ──
    alias_scopes: Dict[str, List[Tuple[int, ...]]] = {}
    for m in _FROM_JOIN.finditer(sql):
        table_name, alias = m.group(1), m.group(2)
        def_scope = _scope_at(m.start(), timeline)
        tl = table_name.lower()
        if tl not in _RESERVED and tl not in cte_names:
            alias_scopes.setdefault(tl, [])
            if def_scope not in alias_scopes[tl]:
                alias_scopes[tl].append(def_scope)
        if alias and alias.lower() not in _RESERVED:
            al = alias.lower()
            alias_scopes.setdefault(al, [])
            if def_scope not in alias_scopes[al]:
                alias_scopes[al].append(def_scope)

    # Qualified FROM/JOIN (2/3-part names): register table + alias. The
    # simple scan above cannot see "FROM db.dbo.Student_Master sm" because
    # its (\w+) grabs only the first dotted component.
    for m in _FROM_JOIN_QUALIFIED.finditer(sql):
        table_name, alias = m.group(2), m.group(3)
        def_scope = _scope_at(m.start(), timeline)
        tl = table_name.lower()
        if tl not in _RESERVED and tl not in cte_names:
            alias_scopes.setdefault(tl, [])
            if def_scope not in alias_scopes[tl]:
                alias_scopes[tl].append(def_scope)
        if alias and alias.lower() not in _RESERVED:
            al = alias.lower()
            alias_scopes.setdefault(al, [])
            if def_scope not in alias_scopes[al]:
                alias_scopes[al].append(def_scope)

    # Old-style comma-join tables: "FROM A x, B y" — register table + alias
    # for every comma-separated entry (see _COMMA_TABLE docstring).
    for m in _COMMA_TABLE.finditer(sql):
        table_name, alias = m.group(2), m.group(3)
        def_scope = _scope_at(m.start(), timeline)
        tl = table_name.lower()
        if tl not in _RESERVED and tl not in cte_names:
            alias_scopes.setdefault(tl, [])
            if def_scope not in alias_scopes[tl]:
                alias_scopes[tl].append(def_scope)
        if alias and alias.lower() not in _RESERVED:
            al = alias.lower()
            alias_scopes.setdefault(al, [])
            if def_scope not in alias_scopes[al]:
                alias_scopes[al].append(def_scope)

    # Derived-table aliases: `FROM (SELECT ...) x` / `) AS x`. Registered at
    # the scope OUTSIDE the closing paren (the alias belongs to the outer
    # FROM). Over-recording is harmless — extra names only ever suppress a
    # flag; they can never create one.
    for m in _DERIVED_ALIAS.finditer(sql):
        al = m.group(1).lower()
        if al in _RESERVED:
            continue
        def_scope = _scope_at(m.start(1), timeline)
        alias_scopes.setdefault(al, [])
        if def_scope not in alias_scopes[al]:
            alias_scopes[al].append(def_scope)

    # CTE names are globally visible pseudo-tables (root scope).
    for c in cte_names:
        alias_scopes.setdefault(c, [()])

    # ── Check every alias.column (and alias.*) reference is visible from
    #    its scope, and — GAP FIX — that the qualifier is defined AT ALL. ──
    for pattern in (_ALIAS_COL, _ALIAS_STAR):
        for m in pattern.finditer(sql):
            qualifier = m.group(1)
            column = m.group(2) if (pattern is _ALIAS_COL and m.lastindex and m.lastindex >= 2) else "*"
            ql = qualifier.lower()
            if ql in _RESERVED or qualifier.startswith("@") or qualifier.isdigit():
                continue
            if ql in _NON_ALIAS_QUALIFIERS:
                continue
            if sql[m.end():m.end() + 1] == ".":
                # multi-part name prefix (db.dbo.Table / dbo.Table) — the
                # FINAL component carries the real table/alias check.
                continue
            if ql in cte_names:
                continue  # CTE — globally visible, body not scope-checked

            if ql not in alias_scopes:
                # GAP FIX (2026-09-07): a qualifier defined NOWHERE in the
                # statement is a guaranteed Msg 4104 at execution. This pass
                # now owns the verdict (the existence guardrail also skips
                # unknown qualifiers, which is exactly how the real-world
                # 'cm.Name' production error slipped through both checks).
                issues.append(
                    AliasScopeIssue(
                        "undefined_alias",
                        f"Alias '{qualifier}' (in '{qualifier}.{column}') is never "
                        f"defined in the statement (no FROM/JOIN introduces it) — "
                        f"SQL Server will reject with Msg 4104 (multi-part "
                        f"identifier could not be bound).",
                    )
                )
                continue

            ref_scope = _scope_at(m.start(), timeline)
            def_scopes = alias_scopes[ql]
            if not _visible_from_any(def_scopes, ref_scope):
                issues.append(
                    AliasScopeIssue(
                        "alias_out_of_scope",
                        f"Alias '{qualifier}' (in '{qualifier}.{column}') is referenced "
                        f"outside the subquery where it is defined — likely Msg 4104 "
                        f"(multi-part identifier could not be bound).",
                    )
                )

    return AliasScopeResult(
        is_valid=(len(issues) == 0),
        issues=issues,
        alias_scopes=alias_scopes,
    )

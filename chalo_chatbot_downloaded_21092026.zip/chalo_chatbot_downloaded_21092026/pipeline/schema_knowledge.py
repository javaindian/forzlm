"""
schema_knowledge.py — ERP Codebase-Analysis Knowledge for the System Prompt
===========================================================================

WHAT THIS IS
------------
The single source of truth for the expanded system prompt, built from the
REAL extracts of the school ERP's own C# code (codebase_analysis/extracted/:
JOIN_PATTERNS_REFERENCE.md, MANDATORY_FILTERS_REFERENCE.md,
BUSINESS_FORMULAS_REFERENCE.md, QUERY_TEMPLATES_REFERENCE.md — 7,440 source
files, 11,148 WHERE clauses, 7,830 LINQ queries analyzed).

WHY IT EXISTS
-------------
The v27 model was trained with a one-paragraph instruction. It had no way to
know the ERP's tribal knowledge: which joins the real code uses, which
filters it ALWAYS applies, which columns are hallucination traps. That gap
was the root cause of the documented blindspots (fee-vs-exam term joins,
TC-issued students counted, bounced cheques counted as paid, ...).

DESIGN (read this before changing)
----------------------------------
The FROZEN_V27_PROMPT text ALWAYS leads the prompt, byte-for-byte. The model
was fine-tuned on exactly that text; leading with it minimises distribution
shift. The knowledge block is appended AFTER it as reference material — the
same append-after pattern the pipeline already uses for vocab injection.

Two profiles:
    "legacy"   -> FROZEN_V27_PROMPT only (the verified StudentCount=32 path)
    "expanded" -> FROZEN_V27_PROMPT + SCHEMA_KNOWLEDGE (the documented #1
                  accuracy lever; requires --ctx-size 4096, which
                  scripts/start_llm.bat now sets)

Selected via env var AI_SECRETARY_PROMPT_PROFILE (default: "expanded").
Rollback = set AI_SECRETARY_PROMPT_PROFILE=legacy in backend/.env. One line,
no code change. The choice is logged in the audit trail via /api/health.

The v28 retrain will bake this knowledge into the weights (improved
instruction + ~200 new training examples in training_dataset_v28_additions
.jsonl) — after v28 lands, this block becomes the safety net, not the crutch.
"""
from __future__ import annotations
import os

# ── The frozen base (EXACTLY what v27 was trained on — do not edit) ─────────
FROZEN_V27_PROMPT = (
    "You are a T-SQL expert for the ChaloSchools (V3_CHALO) school management "
    "database. Convert the following natural language question into a single, "
    "executable T-SQL query. Use @UserId (bound as a query parameter at runtime "
    "from the logged-in user's session) to scope results to the branches that "
    "user has access to via UserAccountRoleDetails."
)

# ── The knowledge block (from the ERP codebase analysis, 2026-09-04) ────────
# Evidence: codebase_analysis/extracted/*.md — the school ERP's own C# LINQ.
SCHEMA_KNOWLEDGE = """
SCHEMA KNOWLEDGE (from the ERP's own code — follow it exactly):

TWO TERM CONCEPTS (the #1 confusion):
- FEE terms live in TermMaster (StartingDate, EndingDate). Fee tables
  (FeesInformationStudentDetail, FeesCollection_Details, BusFeeStrucure,
  HostelFeeStructure, FeeStructureMonth) join Term_ID -> TermMaster.ID.
- EXAM terms live in ExamTermMaster (StartDate, EndDate, Deleted). Exam
  tables (ExamTypeMaster, StudentMarkMaster) join TermID -> ExamTermMaster.ID.
- Never join a fee table to ExamTermMaster; never join an exam table to TermMaster.

CORE STUDENT CHAIN (class/section/year live on StudentAcademicDetail,
NOT on Student_Master — Student_Master holds only the static profile):
FROM StudentAcademicDetail sad
JOIN Student_Master sm ON sad.StudentID = sm.ID
JOIN ClassMaster cm ON sad.ClassID = cm.ID
JOIN SectionMaster secm ON sad.SectionID = secm.ID
WHERE (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL)
  AND sad.AcademicYearID IN (SELECT Id FROM Branch_Academic_Details
      WHERE GETDATE() BETWEEN Start_Date AND End_Date AND Branch_Id IN (<scoping>))
Count students as COUNT(DISTINCT sad.StudentID). (Student_Master has NO
delete column — student activeness is the TC filter above. StudentAcademicDetail
has no BranchID — branch scope flows through the year subquery.)

FEE COLLECTION CHAIN (receipts):
FROM FeesCollection fc
JOIN FeesCollection_Details fcd ON fcd.Fees_Collection_ID = fc.Id
JOIN Fees_Master fm ON fcd.Fees_Head_ID = fm.ID
WHERE fc.ChequeStatus_ID IN (1, 2)
  AND (fc.IsDeleted = 0 OR fc.IsDeleted IS NULL)
The amount column is fc.Receipt_Amt ('Amt' does not exist). The receipt
date column is fc.Bill_Date. Show fee-head names via fm.Name — never return
the raw numeric Fees_Head_ID.

FEE OUTSTANDING (the student ledger, FeesInformationStudentDetail):
Outstanding = ISNULL(Amount,0) - ISNULL(Concession_Amt,0)
              - ISNULL(Paid_Amt,0) - ISNULL(Lien_Amount,0)
AND fisd.IsIncludedInLumpSum = 0 AND fisd.IsDonation = 0
(never compute outstanding as Amount - Paid without concession and lien)

WHO TEACHES WHAT / CLASS TEACHERS:
FROM SubjectAllocation_Master sam
JOIN Staff_Master sm ON sam.Staff_ID = sm.Staff_ID
JOIN Subject_Master sub ON sam.Subject_ID = sub.Id
JOIN ClassMaster cm ON sam.Class_ID = cm.ID
WHERE (sam.IsDeleted = 0 OR sam.IsDeleted IS NULL)
  AND sm.StaffStatus_ID = 1
[AND sam.IsClassTeacher = 1  -- only for class-teacher questions]

THE PRINCIPAL: BranchMaster.Principal (join the scoping branch).

MANDATORY FILTERS (the ERP applies these in its own code — apply them too):
- Active students: (sad.IsTCIssued = 0 OR sad.IsTCIssued IS NULL)
- Active staff: sm.StaffStatus_ID = 1 (2 = resigned/terminated)
- Valid receipts: fc.ChequeStatus_ID IN (1, 2)
- Soft deletes: (IsDeleted = 0 OR IsDeleted IS NULL) on most tables;
  ExamTermMaster uses (Deleted = 0 OR Deleted IS NULL)
- Approved leave (LeaveEntryMaster): lem.LeaveStatus_ID = 1 (active/approved)
- Approved concessions: ApprovalStatus = 1 (0 = pending, 2 = rejected)
- Visible evaluation items: swhl.Visibility = 1
- Root evaluation nodes: ehl.MasterRefID = 0
- Sub-subjects in progress-card totals: pcmd.ParentSubjectID = 0

ENUMS (magic numbers in this database):
- ChequeStatus_ID: 1 = Realized, 2 = Pending, 3 = Bounced, 4 = Cancelled, 5 = Stopped
- StaffStatus_ID: 1 = Active, 2 = Inactive/Resigned/Terminated
- ApprovalStatus: 0 = Pending, 1 = Approved, 2 = Rejected
- SubjectTypeID: 1 = Scholastic, 2 = Co-scholastic
- EvaluationTypeID: 1 = Formative (FA), 2 = Summative (SA)
- Marks 'Others' column: 'AB' = Absent, 'NT' = Not taken, 'NA' = Not
  applicable, 'OP' = Optional (exclude 'OP' from totals)

SUBJECT DISPLAY (v58, user rule 2026-09-08):
- Academic results always show the subject NAME — never a raw numeric
  Subject_ID (users would see '222' instead of 'MATHEMATICS').
- ProgressCardDataRetrieval already carries SubjectName — prefer it.
- Other paths: JOIN Subject_Master sub ON <t>.Subject_ID = sub.Id and
  select sub.Name AS SubjectName. StudentMarkDetails has NO Subject_ID —
  reach the subject via ExamConfigurationEvaluationDetails (EvalHierID).
- COUNT(DISTINCT cs.Subject_Id) style counts are fine (not a display ID).

PARENT SUBJECTS (v60, user rule 2026-09-09):
- ProgressCardDataRetrieval (and OtherExam_ProgressCardDataRetrieval) store
  parent subjects as their OWN rows with marks already filled in — the
  parent's marks are PRE-COMPUTED (sum/average of child subjects, done by
  the ERP; never re-aggregate child rows yourself).
- Parent-child link: ParentSubjectID / ParentSubjectName on child rows.
- Ask "marks in English" (parent) → read the parent row directly
  (SubjectName = 'English'). Ask "marks in English-I" (child) → read that
  child row directly. NEVER SUM child rows into a parent — that would
  double-count, because parent rows already exist with their own marks.
- Staff "on hold" = EmployeeMaster.IsHold = 1; hold history +
  reason: EmployeeSalaryHoldDetail (HoldFromDate / HoldToDate / Reason).
  StaffStatus_ID has NO 'on hold' value (user-confirmed 2026-09-09).

SCHEMA GOTCHAS (hallucination traps — these do NOT exist):
- Student_Master has NO ClassID / SectionID / AcademicYearID columns
- BusFeeStrucure is MISSPELLED in production (no second 't')
- ClassMaster's name column is Name (NOT ClassName)
- Subject_Master's PK is Id (lowercase d)
- Staff names are Staff_FirstName / Staff_LastName (NOT FirstName)
- No IsPreAdmissionFee on FeesCollection (pre-admission fees are in
  ProspectusFeesCollection, linked by ApplicationNo)
- Staff questions: Staff_Master (EmployeeMaster is the payroll/bank twin)
- Messages sent: SMSAuditTrail (GeneralCallRegister = admission enquiries)
- Feedback: FeedbackTicket. Enquiries: GeneralCallRegister (EnquiryMaster
  is deprecated). SL_ tables are a parallel schema — never mix them in.
- The academic year is PER-BRANCH: AcademicYearID values are
  Branch_Academic_Details.Id — resolve by dates, never YEAR(GETDATE())

FORMULAS:
- Attendance %: ROUND(CAST(SUM(CASE WHEN sa.Attendance_Status_ID = 1 THEN 1
  ELSE 0 END) AS FLOAT) / NULLIF(COUNT(*), 0) * 100, 1)
- Holiday days count (half-days count 0.5): SUM(CASE WHEN hm.IsHalfDay = 1
  THEN 0.5 ELSE DATEDIFF(DAY, hm.From_Date, hm.To_Date) + 1 END)
- 'Attendance not marked' means NO ROW EXISTS: use NOT EXISTS (or LEFT
  JOIN ... IS NULL) against StudentAttendance for that class-section-day —
  a status filter can never find rows that do not exist.
""".strip()

# ── Profile selection ────────────────────────────────────────────────────────

# ── v29 profile (Batch A, 2026-09-10) ────────────────────────────────────────
# Byte-identical to the instruction stamped on the v29 training rows.
# NOT active by default: env stays AI_SECRETARY_PROMPT_PROFILE=expanded;
# cutover to "v29" is an env-flip + restart (owner Decision 1, staged).
V29_PROMPT_SHA = "528692397793727d"
_V29_PROMPT_B64 = (
    "WW91IGFyZSBhIFQtU1FMIGV4cGVydCBmb3IgdGhlIENoYWxvU2Nob29scyAoVjNfQ0hBTE8pIHNjaG9vbCBtYW5hZ2VtZW50IGRhdGFiYXNlLiBDb252ZXJ0IHRoZSB1c2VyJ3MgbmF0dXJhbC1sYW5ndWFnZSBxdWVzdGlvbiBpbnRvIGEgc2luZ2xlLCBleGVjdXRhYmxlIFQtU1FMIFNFTEVDVCBxdWVyeS4KClNFQ1VSSVRZIChhbHdheXMpOgotIFNjb3BlIGV2ZXJ5IHF1ZXJ5IHRvIHRoZSB1c2VyJ3MgYnJhbmNoZXM6IEJyYW5jaElEIElOIChTRUxFQ1QgQnJhbmNoSUQgRlJPTSBVc2VyQWNjb3VudFJvbGVEZXRhaWxzIFdIRVJFIFVzZXJJRCA9IEBVc2VySWQgQU5EIChAU2VsZWN0ZWRCcmFuY2hJZCBJUyBOVUxMIE9SIEJyYW5jaElEID0gQFNlbGVjdGVkQnJhbmNoSWQpIFVOSU9OIFNFTEVDVCBJRCBGUk9NIEJyYW5jaE1hc3RlciBXSEVSRSBFWElTVFMgKFNFTEVDVCAxIEZST00gVXNlckFjY291bnRNYXN0ZXIgV0hFUkUgSUQgPSBAVXNlcklkIEFORCBJc1N1cGVyVXNlciA9IDEpIEFORCAoQFNlbGVjdGVkQnJhbmNoSWQgSVMgTlVMTCBPUiBJRCA9IEBTZWxlY3RlZEJyYW5jaElkKSBBTkQgKElzRGVsZXRlZCBJUyBOVUxMIE9SIElzRGVsZXRlZCA9IDApKS4KLSBDdXJyZW50IGFjYWRlbWljIHllYXI6IEFjYWRlbWljWWVhcklEIElOIChTRUxFQ1QgSWQgRlJPTSBCcmFuY2hfQWNhZGVtaWNfRGV0YWlscyBXSEVSRSBHRVREQVRFKCkgQkVUV0VFTiBTdGFydF9EYXRlIEFORCBFbmRfRGF0ZSBBTkQgQnJhbmNoX0lkIElOICg8dGhlIHNhbWUgYnJhbmNoIHNjb3Bpbmc+KSkuIE5ldmVyIGhhcmRjb2RlIGEgeWVhciBhbmQgbmV2ZXIgdXNlIFlFQVIoR0VUREFURSgpKS4KClRXTyBURVJNIENPTkNFUFRTOgotIEZFRSB0ZXJtczogVGVybU1hc3RlciAoU3RhcnRpbmdEYXRlLCBFbmRpbmdEYXRlKS4gRmVlIHRhYmxlcyBqb2luIFRlcm1fSUQgLT4gVGVybU1hc3Rlci5JRC4KLSBFWEFNIHRlcm1zOiBFeGFtVGVybU1hc3RlciAoU3RhcnREYXRlLCBFbmREYXRlLCBEZWxldGVkKS4gRXhhbSB0YWJsZXMgam9pbiBUZXJtSUQgLT4gRXhhbVRlcm1NYXN0ZXIuSUQuCi0gTmV2ZXIgbWl4IHRoZW0uCgpPVVRTVEFORElORyBGT1JNVUxBIChmZWUgbGVkZ2VyLCBGZWVzSW5mb3JtYXRpb25TdHVkZW50RGV0YWlsKToKSVNOVUxMKEFtb3VudCwwKSAtIElTTlVMTChDb25jZXNzaW9uX0FtdCwwKSAtIElTTlVMTChQYWlkX0FtdCwwKSAtIElTTlVMTChMaWVuX0Ftb3VudCwwKSwgd2l0aCBJc0luY2x1ZGVkSW5MdW1wU3VtID0gMCBBTkQgSXNEb25hdGlvbiA9IDAuCgpBTFdBWVMgRklMVEVSOgotIEFjdGl2ZSBzdHVkZW50czogKElzVENJc3N1ZWQgPSAwIE9SIElzVENJc3N1ZWQgSVMgTlVMTCkgb24gU3R1ZGVudEFjYWRlbWljRGV0YWlsIChjbGFzcy9zZWN0aW9uL3llYXIgbGl2ZSB0aGVyZSwgTk9UIG9uIFN0dWRlbnRfTWFzdGVyKS4KLSBWYWxpZCByZWNlaXB0czogQ2hlcXVlU3RhdHVzX0lEIElOICgxLDIpICgzPWJvdW5jZWQsIDQ9Y2FuY2VsbGVkLCA1PXN0b3BwZWQpLiBVc2UgRmVlc0NvbGxlY3Rpb24uUmVjZWlwdF9BbXQgZm9yIGFtb3VudHMuCi0gQWN0aXZlIHN0YWZmOiBTdGFmZlN0YXR1c19JRCA9IDEuIFN0YWZmIG5hbWVzIGFyZSBTdGFmZl9GaXJzdE5hbWUgLyBTdGFmZl9MYXN0TmFtZS4gQ2xhc3MgdGVhY2hlciA9IFN1YmplY3RBbGxvY2F0aW9uX01hc3Rlci5Jc0NsYXNzVGVhY2hlciA9IDEuCi0gU29mdCBkZWxldGVzOiAoSXNEZWxldGVkID0gMCBPUiBJc0RlbGV0ZWQgSVMgTlVMTCk7IEV4YW1UZXJtTWFzdGVyIHVzZXMgRGVsZXRlZCwgbm90IElzRGVsZXRlZC4KCktOT1dOIFRSQVBTOiBCdXNGZWVTdHJ1Y3VyZSBpcyBtaXNzcGVsbGVkIChubyBzZWNvbmQgJ3QnKS4gQ2xhc3NNYXN0ZXIncyBuYW1lIGNvbHVtbiBpcyBOYW1lLiBGZWUtaGVhZCBhbnN3ZXJzIG11c3QgSk9JTiBGZWVzX01hc3RlciBmb3IgdGhlIG5hbWUuIE1lc3NhZ2VzIHNlbnQgPSBTTVNBdWRpdFRyYWlsOyBmZWVkYmFjayA9IEZlZWRiYWNrVGlja2V0OyBlbnF1aXJpZXMgPSBHZW5lcmFsQ2FsbFJlZ2lzdGVyOyBzdGFmZiBsaXN0cyA9IFN0YWZmX01hc3RlciAoRW1wbG95ZWVNYXN0ZXIgaXMgcGF5cm9sbC9iYW5rIG9ubHkpLiAnQXR0ZW5kYW5jZSBub3QgbWFya2VkJyA9IE5PVCBFWElTVFMuIFByaW5jaXBhbCA9IEJyYW5jaE1hc3Rlci5QcmluY2lwYWwuCgpPVVRQVVQ6IG9ubHkgdGhlIFQtU1FMIHF1ZXJ5IOKAlCBubyBtYXJrZG93biBmZW5jZXMsIG5vIGV4cGxhbmF0aW9uLCBubyB0cmFpbGluZyBzZW1pY29sb24uIEEgc2luZ2xlIFNFTEVDVCAob3IgV0lUSCAuLi4gU0VMRUNUKS4gSWYgdGhlIHF1ZXN0aW9uIGlzIG5vdCBhYm91dCBzY2hvb2wgZGF0YSBvciBhc2tzIGZvciBhIHdyaXRlIG9wZXJhdGlvbiwgb3V0cHV0IGEgU0VMRUNUIHJldHVybmluZyBhIHNpbmdsZSBNZXNzYWdlIGNvbHVtbiB3aXRoIGEgc2hvcnQgcmVmdXNhbC4="
)

def _v29_prompt() -> str:
    import base64 as _b64
    return _b64.b64decode(_V29_PROMPT_B64).decode("utf-8")

VALID_PROFILES = ("legacy", "expanded", "v29")

def _env_profile() -> str:
    p = os.environ.get("AI_SECRETARY_PROMPT_PROFILE", "expanded").strip().lower()
    return p if p in VALID_PROFILES else "expanded"

def build_system_prompt(profile: str = "") -> str:
    """Build the system prompt for the requested profile.

    profile: "legacy" | "expanded" (default: env AI_SECRETARY_PROMPT_PROFILE,
    falling back to "expanded" — the documented #1 accuracy lever). The
    frozen v27 text ALWAYS leads, byte-for-byte; the knowledge block is
    appended after it (same append pattern as vocab injection).
    """
    p = profile if profile in VALID_PROFILES else _env_profile()
    if p == "v29":
        return _v29_prompt()
    if p == "legacy":
        return FROZEN_V27_PROMPT
    return (FROZEN_V27_PROMPT + "\n\n" + SCHEMA_KNOWLEDGE).strip()

def prompt_profile() -> str:
    """The profile that build_system_prompt() would use right now."""
    return _env_profile()

def knowledge_token_estimate() -> int:
    """Rough token estimate of the knowledge block (~4 chars/token)."""
    return len(SCHEMA_KNOWLEDGE) // 4

if __name__ == "__main__":
    print(f"profile           : {prompt_profile()}")
    print(f"frozen prompt     : {len(FROZEN_V27_PROMPT)} chars (~{len(FROZEN_V27_PROMPT)//4} tokens)")
    print(f"knowledge block   : {len(SCHEMA_KNOWLEDGE)} chars (~{knowledge_token_estimate()} tokens)")
    full = build_system_prompt()
    print(f"full prompt       : {len(full)} chars (~{len(full)//4} tokens)")
    print(f"legacy prompt     : {len(build_system_prompt('legacy'))} chars")
    assert build_system_prompt().startswith(FROZEN_V27_PROMPT), "frozen text must lead"
    assert build_system_prompt("legacy") == FROZEN_V27_PROMPT, "legacy must be exact"
    print("self-check        : OK (frozen text leads in every profile)")

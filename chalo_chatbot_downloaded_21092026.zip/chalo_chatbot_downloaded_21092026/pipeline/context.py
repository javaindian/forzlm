"""
AI Secretary — Application Layer :: Context Manager (Component #1)
==================================================================

⚠️ UPDATE (2026-08-03) — Context JSON is now the primary source
---------------------------------------------------------------
The ERP now returns an extended **Context JSON** at login (UserMasterDetails +
per-branch UserBranchDetails incl. each branch's real master-data vocabulary).
That JSON carries BOTH the authorized-branch set (replacing the DB branch
lookups below) AND the per-branch vocab used for prompt injection / validation.

PRIMARY path (use this): `build_context_from_json(payload)` — parses the
Context JSON via app_layer.context_vocab and returns a UserContext whose
authorized branches come from UserBranchDetails, with the parsed
UserContextVocab attached (ctx.vocab) for the Value Validator + prompt
injection. Super-user branch set is simply whatever branches the ERP included
for that user (it already scopes list_BranchData to the user's real access —
confirmed with dev team).

FALLBACK path (retained, unchanged): the DB-query `ContextManager` below still
works for any flow that lacks a Context JSON. Not used in the live pipeline.

⚠️ ROUND-2 EXTENSION (D1.3): `to_query_params()` now ALSO resolves and returns
`AcademicYearID` — the current academic year for the user's selected branch,
derived from the Context JSON's `IsCurrentYear` AcademicYear entry. The model
references it via `@AcademicYearID` so downstream queries are scoped to the
correct year without relying on `YEAR(GETDATE())` (STUD-004 / D1.3). When no
Context JSON is attached (DB-fallback path) or the selected branch has no
current AcademicYear, the key is omitted (the caller/parameter_binder will not
inject it).

Purpose
-------
Given an authenticated UserId, resolve the AUTHORITATIVE runtime context that
every downstream component (Value Resolver, Disambiguation, Parameter Binder)
depends on:

    - The user's identity (UserId, display name).
    - Whether the user is a super user.
    - The exact set of BranchIDs the user is authorized to see.
    - The currently selected branch (nullable = "all authorized branches").

Why this exists
---------------
The PRD's two-parameter security model scopes every query by:

    @UserId            -> identity; resolved to authorized branches from the DB.
    @SelectedBranchId  -> nullable; NULL = all authorized branches, a specific
                          value narrows to one branch, but ONLY within the
                          user's already-authorized set.

Branches are NEVER trusted from the token. They are derived from the database
on every session-context build, using the canonical branch-authorization query
(UserAccountRoleDetails UNION super-user BranchMaster) so that:

    * Normal users get exactly their assigned branches.
    * Super users (IsSuperUser = 1, who have ZERO rows in
      UserAccountRoleDetails by design) get every non-deleted branch.

Security properties
-------------------
    * `resolve_context()` returns the branch set from the DB, not the caller.
    * `resolve_selected_branch()` FAILS CLOSED: an @SelectedBranchId the user is
      not authorized for is rejected (raises UnauthorizedBranchError), never
      silently widened or narrowed to someone else's data.
    * All DB access is parameterized (no string interpolation of user input).

This module contains NO hardcoded paths or client names (Bible Rule 1) and is
DB-driver agnostic — it uses the existing SQLExecutor.execute_parameterized
helper, exactly as auth_userid.py does.

Reconstructed from the original app_layer/ code + round-2 extensions.
Diff against your real files before deploying.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Any, Dict


# ───────────────────────── Exceptions ──────────────────────────
class ContextError(Exception):
    """Base class for context-resolution errors."""


class UserNotFoundError(ContextError):
    """The UserId does not correspond to an active UserAccountMaster row."""


class NoAuthorizedBranchesError(ContextError):
    """The user is authenticated but authorized for zero branches."""


class UnauthorizedBranchError(ContextError):
    """A selected branch is outside the user's authorized set (fail closed)."""


# ───────────────────────── Data model ──────────────────────────
@dataclass(frozen=True)
class Branch:
    """A single branch the user is authorized to see."""
    branch_id: int
    name: Optional[str] = None


@dataclass
class UserContext:
    """
    The resolved, authoritative runtime context for a single user session.

    Attached to every query generated in the session. `selected_branch_id`
    is the only mutable field (the user may switch branches mid-session via
    the picker); everything else is derived once from the DB and frozen.
    """
    user_id: int
    username: str = ""
    display_name: str = ""
    is_super_user: bool = False
    authorized_branches: List[Branch] = field(default_factory=list)
    selected_branch_id: Optional[int] = None  # None = all authorized branches
    # Attached when built from the Context JSON: the parsed per-branch vocab
    # (app_layer.context_vocab.UserContextVocab). None when built from the DB.
    vocab: Optional[Any] = None

    # ── Convenience accessors ──
    @property
    def authorized_branch_ids(self) -> List[int]:
        return [b.branch_id for b in self.authorized_branches]

    @property
    def branch_count(self) -> int:
        return len(self.authorized_branches)

    @property
    def needs_branch_selection(self) -> bool:
        """
        True when the user has 2+ branches and has not yet chosen one.
        The app surfaces the branch picker in this case; a single-branch
        user never sees it.
        """
        return self.branch_count > 1 and self.selected_branch_id is None

    def is_authorized_for(self, branch_id: int) -> bool:
        return branch_id in self.authorized_branch_ids

    def to_query_params(self) -> Dict[str, Any]:
        """
        The security parameters bound into every generated query.
        @SelectedBranchId is None (SQL NULL) when the user wants all
        authorized branches — the canonical scoping subquery handles NULL.

        ⚠️ D1.3 (round-2): when the Context JSON is attached and the selected
        branch has an `IsCurrentYear` AcademicYear entry, we ALSO resolve
        `@AcademicYearID` to that year's Id. The model can reference
        `@AcademicYearID` in its SQL to scope to the current academic year
        without `YEAR(GETDATE())` (the canonical pattern per STUD-004 /
        Deep-Dive #1). When the value is unresolvable, the key is omitted —
        the parameter_binder enforces parity and would refuse SQL that
        references `@AcademicYearID` if no value is supplied.
        """
        params: Dict[str, Any] = {
            "UserId": self.user_id,
            "SelectedBranchId": self.selected_branch_id,
        }
        ay_id = self._resolve_current_academic_year_id()
        if ay_id is not None:
            params["AcademicYearID"] = ay_id
        return params

    def _resolve_current_academic_year_id(self) -> Optional[int]:
        """
        D1.3 helper: look up the current AcademicYear for the SELECTED branch
        in the Context JSON's AcademicYears list. Returns the Id (int) when the
        branch has an `IsCurrentYear=True` entry, else None.

        None is returned when:
          - vocab is None (DB-fallback path),
          - no branch is selected (None selected → multi-branch "all" mode),
          - the selected branch has no AcademicYears,
          - none of its AcademicYears has `IsCurrentYear=True`.
        In all those cases the orchestrator / parameter_binder must not inject
        @AcademicYearID — the model's SQL should not reference it either
        (training should avoid `@AcademicYearID` when a single-year resolution
        is ambiguous).
        """
        if self.vocab is None:
            return None
        bid = self.selected_branch_id
        if bid is None:
            return None
        try:
            branch_vocab = self.vocab.branch(bid)
        except Exception:
            return None
        ays = getattr(branch_vocab, "academic_years", None) or []
        for ay in ays:
            if getattr(ay, "is_current", False):
                return getattr(ay, "id", None)
        return None

    def branch_vocab(self, branch_id: Optional[int] = None):
        """
        The BranchVocab for the given branch (defaults to the selected branch)
        — for prompt injection + value validation. Requires this context to
        have been built from the Context JSON (self.vocab set), else None.
        Fails closed if no branch is resolvable.
        """
        if self.vocab is None:
            return None
        bid = branch_id if branch_id is not None else self.selected_branch_id
        if bid is None:
            return None
        return self.vocab.branch(bid)


# ───────────────────────── SQL (parameterized) ─────────────────
# Identity + super-user flag. TOP 1 defensive; ID is unique.
_SQL_USER = (
    "SELECT TOP 1 ID, Username, StaffName, "
    "       ISNULL(IsSuperUser, 0) AS IsSuperUser, IsDeleted "
    "FROM UserAccountMaster WHERE ID = ?"
)

# Authorized branches for a NORMAL user (explicit role assignment).
_SQL_BRANCHES_NORMAL = (
    "SELECT DISTINCT bm.ID, bm.Name "
    "FROM UserAccountRoleDetails urd "
    "JOIN BranchMaster bm ON urd.BranchID = bm.ID "
    "WHERE urd.UserID = ? AND (bm.IsDeleted = 0 OR bm.IsDeleted IS NULL) "
    "ORDER BY bm.Name"
)

# Authorized branches for a SUPER user (every non-deleted branch).
# Super users have zero UserAccountRoleDetails rows by design, so the normal
# query would return empty — this is the UNION branch of the PRD's canonical
# scoping subquery, expressed as a standalone lookup.
_SQL_BRANCHES_SUPER = (
    "SELECT bm.ID, bm.Name "
    "FROM BranchMaster bm "
    "WHERE (bm.IsDeleted = 0 OR bm.IsDeleted IS NULL) "
    "ORDER BY bm.Name"
)


# ───────────────────────── Context Manager ─────────────────────
class ContextManager:
    """
    Resolves and validates per-user session context against the live DB.

    Usage:
        cm = ContextManager(executor, driver)
        ctx = cm.resolve_context(user_id=123)
        ctx = cm.resolve_selected_branch(ctx, selected_branch_id=2)  # fail-closed
        params = ctx.to_query_params()   # {"UserId": 123, "SelectedBranchId": 2}
    """

    def __init__(self, executor: Any, driver: Any = None):
        """
        Args:
            executor: object exposing
                      execute_parameterized(sql, params, driver) -> {"rows": [...]}
                      (the existing app.sql_executor.SQLExecutor).
            driver:   DB driver identifier passed through to the executor
                      (e.g. config.database_base.driver). Optional.
        """
        self._executor = executor
        self._driver = driver

    # ── internal: run a parameterized query, return rows ──
    def _rows(self, sql: str, params: list) -> list:
        result = self._executor.execute_parameterized(sql, params, self._driver)
        # execute_parameterized returns {"rows": [...]} (see auth_userid.py);
        # code defensively in case a driver returns a bare list.
        if isinstance(result, dict):
            return result.get("rows", []) or []
        if isinstance(result, list):
            return result
        return []

    # ── public: build the full context for a user ──
    def resolve_context(self, user_id: int) -> UserContext:
        """
        Resolve identity + authorized branches for `user_id` from the DB.

        Raises:
            UserNotFoundError        — no active UserAccountMaster row.
            NoAuthorizedBranchesError — authenticated but zero branches.
        """
        user_rows = self._rows(_SQL_USER, [user_id])
        if not user_rows:
            raise UserNotFoundError(f"No user with ID {user_id}.")

        r = user_rows[0]
        uid, username, staff_name, is_super_raw, is_deleted = (
            r[0], r[1], r[2], r[3], r[4],
        )
        if is_deleted:
            raise UserNotFoundError(f"User {user_id} is inactive.")

        is_super = bool(is_super_raw)

        branch_sql = _SQL_BRANCHES_SUPER if is_super else _SQL_BRANCHES_NORMAL
        branch_params = [] if is_super else [user_id]
        branch_rows = self._rows(branch_sql, branch_params)

        branches = [Branch(branch_id=int(br[0]), name=br[1]) for br in branch_rows]

        if not branches:
            # Fail closed: a user with no authorized branch cannot query anything.
            raise NoAuthorizedBranchesError(
                f"User {user_id} is authorized for no branches."
            )

        return UserContext(
            user_id=int(uid),
            username=username or "",
            display_name=staff_name or username or "",
            is_super_user=is_super,
            authorized_branches=branches,
            selected_branch_id=None,  # defaults to "all authorized"
        )

    # ── public: apply a branch selection, fail closed ──
    def resolve_selected_branch(
        self, ctx: UserContext, selected_branch_id: Optional[int]
    ) -> UserContext:
        """
        Apply a user's branch pick to an existing context, enforcing that the
        branch is within the user's authorized set.

        selected_branch_id=None  -> "all authorized branches" (always allowed).
        selected_branch_id=<int> -> must be in ctx.authorized_branch_ids,
                                     else UnauthorizedBranchError (fail closed).

        Returns the same context object with selected_branch_id updated.
        """
        if selected_branch_id is None:
            ctx.selected_branch_id = None
            return ctx

        sid = int(selected_branch_id)
        if not ctx.is_authorized_for(sid):
            raise UnauthorizedBranchError(
                f"User {ctx.user_id} is not authorized for branch {sid}."
            )
        ctx.selected_branch_id = sid
        return ctx


# ═══════════════════════════════════════════════════════════════════════════
#  PRIMARY (2026-08-03): build context directly from the extended Context JSON
# ═══════════════════════════════════════════════════════════════════════════

def build_context_from_json(payload, auto_select_single: bool = True) -> "UserContext":
    """
    Build a UserContext from the ERP's extended Context JSON.

    The authorized-branch set comes from UserMasterDetails.UserBranchDetails
    (already scoped to the user's real access by the ERP — confirmed with the
    dev team that list_BranchData reflects actual per-user authorization, not an
    unfiltered list). The parsed per-branch vocabulary is attached as ctx.vocab
    for prompt injection + value validation.

    Args:
        payload: the Context JSON (str or dict).
        auto_select_single: if the user has exactly one branch, pre-select it
            (a single-branch user should never see a picker).

    Raises:
        NoAuthorizedBranchesError — the Context JSON lists zero branches.

    Note: imports context_vocab lazily so this module has no hard import-time
    dependency (keeps the DB-only fallback path importable on its own).
    """
    try:
        from .context_vocab import parse_context_json
    except ImportError:
        from context_vocab import parse_context_json

    uctx_vocab = parse_context_json(payload)  # UserContextVocab

    branches = [
        Branch(branch_id=bv.branch_id, name=bv.name)
        for bv in uctx_vocab.branches.values()
    ]
    if not branches:
        raise NoAuthorizedBranchesError(
            f"User {uctx_vocab.user_id} has no branches in the Context JSON."
        )

    ctx = UserContext(
        user_id=uctx_vocab.user_id,
        username=uctx_vocab.username,
        display_name=uctx_vocab.staff_name or uctx_vocab.username,
        is_super_user=uctx_vocab.is_super_user,
        authorized_branches=branches,
        selected_branch_id=None,
        vocab=uctx_vocab,
    )

    # Convenience: a lone branch is auto-selected (no picker for single-branch).
    if auto_select_single and len(branches) == 1:
        ctx.selected_branch_id = branches[0].branch_id

    return ctx

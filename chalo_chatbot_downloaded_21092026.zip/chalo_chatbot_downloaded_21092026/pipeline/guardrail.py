"""
AI Secretary — Application Layer :: Schema Guardrail (Component #3 — extended)
=============================================================================

Parses a generated T-SQL query, extracts every table/alias and every
alias.column reference, and checks each against the real schema catalog.
Catches hallucinated tables and columns deterministically — independent of
model quality — before the query ever reaches the database.

⚠️ ROUND-2 EXTENSIONS (D1.2 + D1.6):
  1. SENSITIVE TABLE / COLUMN BLOCKLIST enforcement (defense in depth).
     The original guardrail only checks EXISTENCE. The extended version also
     blocks:
       (a) any table in SENSITIVE_TABLES — secrets / configs / draft data that
           must NEVER be exposed through the AI Secretary:
             StorageConfiguration, SMS_ConfigurationSettings, WhatsAppConfiguration,
             Student_Master_Draft, PasswordRecovery, PaymentConfiguration,
             AirpayTXNDataTable.
       (b) any column in SENSITIVE_COLUMN_OWNERS when the OWNER table is in
           scope (Password, Token, SGC_Password, SGC_UserId, APIKey).
     NOTE: the semantic-rules engine (semantic_rules.py) already implements
     these as MEDIUM-severity rules at the semantic layer. The guardrail's
     blocklist is DEFENSE IN DEPTH — catch it even earlier, at the schema
     layer, before semantic_rules even runs. The two layers overlap
     intentionally; either one alone catches the issue.
  2. CONFIGURABLE SCHEMA CATALOG PATH. The original hard-coded the catalog
     load (`open('schema_catalog.json')` from CWD). This version reads
     SCHEMA_CATALOG_PATH from env (or constructor arg), falling back to a
     sibling-of-this-file location, then CWD. Robust when invoked from any
     working directory.

Known limitations (by design, not oversights — see README notes at bottom):
  - Does not validate columns inside CTEs' own SELECT lists against their
    source tables recursively; it treats a CTE name as a valid pseudo-table
    once declared, but doesn't verify the CTE's own body.
  - Does not resolve bare (unqualified) column references — those are
    skipped rather than guessed at, to avoid false positives in multi-table
    queries where a bare column could belong to any joined table.
  - Does not evaluate subquery-local aliases separately from the outer
    query's alias scope in deeply nested queries (single flat scope is
    used) — sufficient for the query patterns seen in this project so far,
    but not a full SQL scope resolver.
  - Handles multi-CTE WITH clauses (WITH a AS (...), b AS (...), c AS (...))
    and SQL Server system objects (master.dbo.spt_values, sys.*,
    INFORMATION_SCHEMA.*) as of the second validation round against the
    full v5 dataset — both were found as false-positive sources and fixed.
  - KNOWN BLIND SPOT: the bare-column check allows any column name that
    exists on UserAccountRoleDetails or Branch_Academic_Details (the
    near-universal branch/year-scoping subquery tables) even when the bare
    reference is actually in the OUTER table's scope, not the subquery's.
    Confirmed concretely: UserAccountRoleDetails has its own real StaffID
    column, so a query wrongly referencing bare "StaffID" against, say,
    StaffDepartmentMaster (which has no such column) will NOT be flagged,
    because StaffID is valid somewhere in the query overall. This is a
    narrow, specific gap (only affects names colliding with
    branchid/userid/roleid/isprimary/id/staffid), not a general failure —
    fixing it properly requires real paren-depth scope tracking, which is
    out of scope for a regex-based approach. Flagging honestly rather than
    claiming full coverage.

Reconstructed from the original app_layer/sql_guardrail.py + round-2
extensions. Diff against your real files before deploying.
"""

import os
import re
import json
from dataclasses import dataclass, field
from typing import List, Optional


# ── D1.6: Sensitive table / column blocklist (defense in depth) ────────────
# These tables contain secrets / configs / draft data that must NEVER be
# exposed through the AI Secretary. The semantic-rules engine
# (semantic_rules.py RBAC-006 / SENSITIVE_TABLES / SENSITIVE_COLUMN_OWNERS)
# already enforces these at the SEMANTIC layer; this guardrail blocklist
# enforces them at the SCHEMA layer too, catching them even earlier.
SENSITIVE_TABLES = {
    "StorageConfiguration",
    "SMS_ConfigurationSettings",
    "WhatsAppConfiguration",
    "Student_Master_Draft",
    "PasswordRecovery",
    "PaymentConfiguration",
    "AirpayTXNDataTable",
}

# Sensitive columns → their owner tables. We flag when the column is
# referenced via an alias whose resolved real table is one of the owners.
# The "owner set" model handles the common pattern where the same column
# name lives on multiple tables (e.g. Password on both UserAccountMaster
# and Student_Master_Draft — neither should ever be selected).
SENSITIVE_COLUMN_OWNERS = {
    "Password": {"UserAccountMaster", "Student_Master_Draft"},
    "Token": {"UserAccountMaster", "Student_Master_Draft"},
    "SGC_Password": {"BranchMaster"},
    "SGC_UserId": {"BranchMaster"},
    "APIKey": {"BranchMaster"},
}


# ── Catalog loading (D1.2: configurable path) ──────────────────────────────
def _default_catalog_path() -> str:
    """
    D1.2 — locate schema_catalog.json WITHOUT hardcoding CWD.
    Order:
      1. env var SCHEMA_CATALOG_PATH (caller-supplied absolute path).
      2. sibling of THIS file (pipeline/schema_catalog.json).
      3. /home/z/my-project/semantic_validation/reference_inputs/schema_catalog.json
         (the canonical copy shipped with the project).
      4. CWD ./schema_catalog.json (legacy fallback for existing scripts).
    Returns the first that exists; the caller raises a clean error if
    none of them is found.
    """
    candidates = []
    env_path = os.environ.get("SCHEMA_CATALOG_PATH")
    if env_path:
        candidates.append(env_path)
    here = os.path.dirname(os.path.abspath(__file__))
    candidates.append(os.path.join(here, "schema_catalog.json"))
    candidates.append(
        "/home/z/my-project/semantic_validation/reference_inputs/schema_catalog.json"
    )
    candidates.append(os.path.join(os.getcwd(), "schema_catalog.json"))
    for p in candidates:
        if p and os.path.isfile(p):
            return p
    # fall through to the first candidate so the caller's open() raises a
    # FileNotFoundError with a meaningful path
    return candidates[0] or candidates[1]


def _load_catalog(path: Optional[str] = None) -> dict:
    """
    Load the schema catalog from a configurable path (D1.2). When `path`
    is None, resolve via _default_catalog_path(). Raises FileNotFoundError
    if no usable catalog is found, with a clear message listing the search
    order so the caller can fix it.
    """
    if path is None:
        path = _default_catalog_path()
    if not os.path.isfile(path):
        raise FileNotFoundError(
            f"schema_catalog.json not found at '{path}'. "
            f"Set SCHEMA_CATALOG_PATH env var or pass an explicit path "
            f"to GuardrailValidator(schema_catalog_path=...)."
        )
    with open(path, encoding="utf-8") as f:
        return json.load(f)


@dataclass
class ValidationIssue:
    kind: str          # "unknown_table" | "unknown_column" | "sensitive_table" | "sensitive_column"
    detail: str         # human-readable description


@dataclass
class ValidationResult:
    is_valid: bool
    issues: list = field(default_factory=list)
    tables_found: dict = field(default_factory=dict)   # alias -> real table name

    def summary(self):
        if self.is_valid:
            return "PASS — no unknown tables or columns detected."
        lines = [f"FAIL — {len(self.issues)} issue(s) found:"]
        for i in self.issues:
            lines.append(f"  [{i.kind}] {i.detail}")
        return "\n".join(lines)


# CTE names get treated as valid pseudo-tables once declared (their own
# body isn't recursively checked — see module docstring).
_CTE_PATTERN = re.compile(r"(?:\bWITH\s+|,\s*)(\w+)\s+AS\s*\(", re.IGNORECASE)

# FROM/JOIN TableName [AS] alias — alias is optional; if omitted, the alias
# IS the table name (SQL allows referencing sm.Col even when FROM sm has no
# explicit AS, as long as "sm" was itself the table name... but T-SQL
# actually requires either using the real table name or the given alias,
# not both once an alias exists. We handle both cases: explicit alias, or
# no alias at all (bare table name usable as its own qualifier).
_FROM_JOIN_PATTERN = re.compile(
    r"\b(?:FROM|JOIN)\s+(?:\[?dbo\]?\.)?\[?(\w+)\]?\s*(?:AS\s+)?(\w+)?",
    re.IGNORECASE
)

# alias.Column or TableName.Column references anywhere in the query.
# Deliberately excludes anything immediately followed by "(" (function
# calls like dbo.SomeFunction(...) aren't column references).
_ALIAS_COLUMN_PATTERN = re.compile(r"\b(\w+)\.(\w+)\b(?!\s*\()")

# SQL keywords/functions that can precede a dot-like pattern but aren't
# real table aliases (e.g. "GETDATE()" isn't matched by the pattern above
# since it requires a dot, but guard against reserved words appearing as
# a false "alias" in edge cases)
_RESERVED_NOT_ALIASES = {
    "select", "from", "where", "group", "order", "having", "and", "or",
    "not", "in", "is", "null", "as", "on", "join", "inner", "left",
    "right", "outer", "cross", "apply", "case", "when", "then", "else",
    "end", "top", "distinct", "union", "all", "with", "cast", "sum",
    "count", "avg", "min", "max", "isnull", "getdate", "dateadd",
    "datediff", "datepart", "datename", "cast", "convert", "over",
    "partition", "by", "format", "month", "year", "day",
}


# ── Module-level catalog (lazy-loaded, configurable) ──────────────────────
# Loaded once at first use. Tests can call _reload_catalog(path) to swap.
_CATALOG: Optional[dict] = None
_CATALOG_CI: Optional[dict] = None
_CATALOG_LOAD_PATH: Optional[str] = None


def _reload_catalog(path: Optional[str] = None) -> None:
    """Force-reload the schema catalog from `path` (or the default)."""
    global _CATALOG, _CATALOG_CI, _CATALOG_LOAD_PATH
    _CATALOG = _load_catalog(path)
    _CATALOG_LOAD_PATH = path or _default_catalog_path()
    _CATALOG_CI = {
        name.lower(): (name, set(c.lower() for c in cols))
        for name, cols in _CATALOG.items()
    }


def _catalog_ci() -> dict:
    """Lazy-load + cache the case-insensitive catalog index."""
    if _CATALOG_CI is None:
        _reload_catalog()
    return _CATALOG_CI


def _strip_cte_headers(sql: str):
    """Returns the set of CTE names declared via WITH ... AS (...)."""
    return set(m.group(1).lower() for m in _CTE_PATTERN.finditer(sql))


# ── rev-10: comment/literal masking ────────────────────────────────────────
# Closes the auditor's rev-10 tooling finding: _FROM_JOIN_PATTERN matched
# "FROM <word>" inside -- comments (and inside '...' string literals), so a
# refusal row whose comment said "...retrieve data from the school database"
# was flagged as referencing a nonexistent table "the" and failed validation
# even though the row itself was a correct refusal. The fix masks BOTH hole
# classes (line comments and string literals, plus /* */ block comments for
# completeness) with position-preserving spaces BEFORE any FROM/JOIN,
# alias.column, bare-column, or scoping-subquery scanning. Positions are
# preserved so index-based helpers (_enclosing_select_span etc.) still align.
def _strip_comments_and_literals(sql: str) -> str:
    """Blank out -- line comments, /* */ block comments and '...' string
    literals with spaces, preserving string length and line structure."""
    out = list(sql)
    n = len(sql)
    i = 0
    while i < n:
        ch = sql[i]
        if ch == "-" and sql[i + 1:i + 2] == "-":
            # line comment: mask to end of line (keep the newline itself)
            while i < n and sql[i] != "\n":
                out[i] = " "
                i += 1
        elif ch == "/" and sql[i + 1:i + 2] == "*":
            out[i] = " "
            out[i + 1] = " "
            i += 2
            while i < n:
                if sql[i] == "*" and sql[i + 1:i + 2] == "/":
                    out[i] = " "
                    out[i + 1] = " "
                    i += 2
                    break
                if sql[i] != "\n":
                    out[i] = " "
                i += 1
        elif ch == "'":
            # string literal: mask opening quote, contents, closing quote;
            # '' inside is an escaped quote, still part of the literal
            out[i] = " "
            i += 1
            closed = False
            while i < n:
                if sql[i] == "'":
                    if sql[i + 1:i + 2] == "'":
                        out[i] = " "
                        out[i + 1] = " "
                        i += 2
                        continue
                    out[i] = " "
                    i += 1
                    closed = True
                    break
                if sql[i] != "\n":
                    out[i] = " "
                i += 1
            if not closed:
                # unterminated literal — restore nothing; the scan on the
                # masked text is still safer than scanning raw text
                pass
        else:
            i += 1
    return "".join(out)


# ── batch-b-2026-09-10: scoping-subquery select-list validation ─────────────
# Closes the #1 live failure class (19 production execute errors, 83% of live
# failures on 2026-09-09/10 — owner-verified against the real audit trail):
# the branch linkage is PRESENT and genuinely used as a filter, but the
# scoping subquery SELECTs a column that does not exist on ITS OWN table —
# canonically "SELECT Branch_Id FROM UserAccountRoleDetails" (the real UARD
# column is BranchID; Branch_Id exists only on Branch_Academic_Details).
# Why the existing checks miss it: the reference is UNQUALIFIED, so the
# alias.column check skips it; the bare-column check is skipped for
# multi-table queries and, when it runs, its allowed set is deliberately
# unioned with the boilerplate tables' columns (so Branch_Id is valid
# everywhere). This check walks each scoping subquery back to its own
# select-list and validates every selected BARE column against THAT table's
# real columns. Qualified references stay covered by the alias.column check.
_SCOPING_FROM_PATTERN = re.compile(
    r"\bFROM\s+(?:\[?dbo\]?\.)?\[?(UserAccountRoleDetails|Branch_Academic_Details)\]?(?=\s|\)|$)",
    re.IGNORECASE,
)
_SELECT_KEYWORD = re.compile(r"\bSELECT\b", re.IGNORECASE)


def _enclosing_select_span(sql: str, frm_start: int) -> Optional[tuple]:
    """
    Locate the select-list region for the FROM at frm_start:
    (start, end) such that sql[start:end] sits between the innermost
    enclosing '(' of the subquery and this FROM. For a top-level FROM
    (no enclosing paren), the text between the last paren-depth-0 SELECT
    and the FROM. Returns None when no select region can be identified.
    """
    depth = 0
    i = frm_start
    while i > 0:
        i -= 1
        c = sql[i]
        if c == ")":
            depth += 1
        elif c == "(":
            if depth == 0:
                return (i + 1, frm_start)  # subquery: region after '('
            depth -= 1
    # top level: last SELECT at paren-depth 0 in the prefix
    prefix = sql[:frm_start]
    d = 0
    last_sel = None
    for m in re.finditer(r"\(|\)|\bSELECT\b", prefix, re.IGNORECASE):
        tok = m.group(0)
        if tok == "(":
            d += 1
        elif tok == ")":
            d = max(0, d - 1)
        elif d == 0:
            last_sel = m
    if last_sel is None:
        return None
    # Region INCLUDES the SELECT keyword (uniform with the subquery case);
    # _scoping_subquery_issues finds the keyword and tokenizes after it.
    return (last_sel.start(), frm_start)


def _scoping_select_list_columns(select_list: str) -> List[str]:
    """
    Extract the BARE column identifiers from a select-list. Strings are
    blanked, balanced function-call groups are removed iteratively,
    DISTINCT/ALL/TOP-n prefixes and AS-aliases are stripped, and anything
    not a single plain identifier (qualified refs, expressions, leftovers)
    is skipped — those are owned by the existing alias.column check.
    """
    s = re.sub(r"'(?:[^']|'')*'", " ", select_list)
    prev = None
    while prev != s:
        prev = s
        s = re.sub(r"[A-Za-z_]\w*\s*\([^()]*\)", " ", s)
    s = re.sub(r"^\s*(?:DISTINCT|ALL)\b", " ", s, flags=re.IGNORECASE)
    s = re.sub(r"^\s*TOP\s+\d+\s*(?:PERCENT\s*)?(?:WITH\s+TIES\s*)?", " ",
               s, flags=re.IGNORECASE)
    s = re.sub(r"\bAS\s+\w+", " ", s, flags=re.IGNORECASE)
    out: List[str] = []
    for item in s.split(","):
        item = item.strip()
        if not item or item == "*":
            continue
        if re.fullmatch(r"[A-Za-z_]\w*", item):
            out.append(item)
    return out


def _scoping_subquery_issues(sql: str, catalog_ci: Optional[dict] = None) -> list:
    """
    Validate every bare column selected by a UserAccountRoleDetails /
    Branch_Academic_Details subquery against that table's REAL columns.
    Returns a list of ValidationIssue (empty = clean). Deliberately
    standalone so the regression suite can sweep the full training corpus
    with this check alone, cheaply.
    """
    if catalog_ci is None:
        catalog_ci = _catalog_ci()
    found = []
    for m in _SCOPING_FROM_PATTERN.finditer(sql):
        table = m.group(1)
        entry = catalog_ci.get(table.lower())
        if not entry:
            continue
        real_name, cols = entry
        span = _enclosing_select_span(sql, m.start())
        if span is None:
            continue
        region = sql[span[0]:span[1]]
        sm = _SELECT_KEYWORD.search(region)
        if not sm:
            continue
        for col in _scoping_select_list_columns(region[sm.end():]):
            if col.lower() in cols:
                continue
            norm = col.lower().replace("_", "")
            # hint in the catalog's ORIGINAL casing (e.g. 'BranchID')
            orig_cols = (_CATALOG or {}).get(real_name, [])
            hint = next(
                (c for c in orig_cols if c.lower().replace("_", "") == norm), None
            )
            extra = f" — did you mean '{hint}'?" if hint else ""
            found.append(ValidationIssue(
                "unknown_column",
                f"Column '{col}' does not exist on table '{real_name}' "
                f"(selected in the scoping subquery's select-list){extra}."
            ))
    return found


def validate_sql(sql: str, schema_catalog_path: Optional[str] = None) -> ValidationResult:
    """
    Validate the SQL against the schema catalog (existence check) AND the
    sensitive table/column blocklist (D1.6 defense-in-depth check).

    Args:
        sql: the T-SQL query to validate.
        schema_catalog_path: optional override for the catalog location
            (D1.2). When None, the module default catalog is used.
    """
    # Honor an explicit per-call path override (D1.2): if the caller asks
    # for a different catalog, swap it in for this call only.
    if schema_catalog_path is not None and (
        _CATALOG_LOAD_PATH is None
        or os.path.abspath(schema_catalog_path) != os.path.abspath(_CATALOG_LOAD_PATH)
    ):
        _reload_catalog(schema_catalog_path)

    # rev-10: scan a comment/literal-masked copy so "FROM <word>" inside
    # -- comments or '...' literals can never satisfy the table-extraction
    # regex (auditor finding; reproduced with the val#83 CBSE-refusal row).
    sql_scan = _strip_comments_and_literals(sql)

    catalog_ci = _catalog_ci()
    issues = []
    cte_names = _strip_cte_headers(sql_scan)

    # SQL Server system objects (master.dbo.spt_values, sys.*, etc.) are
    # legitimately outside the V3_CHALO schema catalog — they're built-in
    # engine objects, not application tables. Register any such reference
    # (and its alias, if given) as known/skip-validated before the main
    # FROM/JOIN parsing loop, so they're never flagged as unknown.
    system_object_pattern = re.compile(
        r"\b(?:FROM|JOIN)\s+(master\.dbo\.\w+|sys\.\w+|INFORMATION_SCHEMA\.\w+)\s*(?:AS\s+)?(\w+)?",
        re.IGNORECASE
    )
    system_aliases = {}
    for m in system_object_pattern.finditer(sql_scan):
        full_ref, alias = m.group(1), m.group(2)
        # register every segment (e.g. "master", "dbo", "spt_values" for
        # master.dbo.spt_values) since the generic FROM/JOIN pattern used
        # below may only capture the first segment (stops at the first dot)
        for segment in full_ref.lower().split('.'):
            system_aliases[segment] = None
        if alias and alias.lower() not in _RESERVED_NOT_ALIASES:
            system_aliases[alias.lower()] = None

    # Build alias -> real_table map from every FROM/JOIN in the query
    alias_map = dict(system_aliases)
    for m in _FROM_JOIN_PATTERN.finditer(sql_scan):
        table_name, alias = m.group(1), m.group(2)
        table_lower = table_name.lower()

        if table_lower in system_aliases or (alias and alias.lower() in system_aliases):
            continue  # already handled above as a system object

        if table_lower in cte_names:
            # It's a CTE reference, not a real schema table — register
            # the CTE name (and its alias, if any) as "known", but skip
            # column validation for it (see module docstring).
            alias_map[table_lower] = None
            if alias and alias.lower() not in _RESERVED_NOT_ALIASES:
                alias_map[alias.lower()] = None
            continue

        # ── D1.6: SENSITIVE TABLE check (defense in depth). Even if the
        # table genuinely exists in the catalog, refuse it — the AI
        # Secretary must never read from these tables.
        if table_name in SENSITIVE_TABLES:
            issues.append(ValidationIssue(
                "sensitive_table",
                f"Table '{table_name}' is on the sensitive-table blocklist — "
                f"the AI Secretary must not read from this table."
            ))
            # Register the alias so we don't ALSO cascade a false
            # unknown_column issue for its columns (we already refused
            # the table; no value in piling on).
            alias_map[table_lower] = table_name
            if alias and alias.lower() not in _RESERVED_NOT_ALIASES:
                alias_map[alias.lower()] = table_name
            continue

        if table_lower not in catalog_ci:
            issues.append(ValidationIssue(
                "unknown_table",
                f"Table '{table_name}' does not exist in the schema."
            ))
            continue

        real_name, _cols = catalog_ci[table_lower]
        # register both the alias (if given) and the table's own name as
        # valid qualifiers, matching how SQL Server actually resolves this
        alias_map[table_lower] = real_name
        if alias and alias.lower() not in _RESERVED_NOT_ALIASES:
            alias_map[alias.lower()] = real_name

    # Now check every alias.column reference against the resolved table
    for m in _ALIAS_COLUMN_PATTERN.finditer(sql_scan):
        qualifier, column = m.group(1), m.group(2)
        qualifier_lower = qualifier.lower()

        if qualifier_lower in _RESERVED_NOT_ALIASES:
            continue
        if qualifier.startswith('@'):
            continue  # parameter, not a table qualifier
        if qualifier_lower not in alias_map:
            # Not a table/alias we recognized from FROM/JOIN in this query
            # — could be a schema prefix like "dbo" used oddly, or a false
            # positive from the regex. Skip rather than false-flag.
            continue

        real_table = alias_map[qualifier_lower]
        if real_table is None:
            continue  # CTE — not validated (see module docstring)

        # ── D1.6: SENSITIVE COLUMN check. If the column is one of the
        # sensitive columns AND its resolved real table is one of its
        # owners, refuse it. BranchMaster.SGC_Password, UserAccountMaster.
        # Password, etc. must never be selected by the AI Secretary.
        if column in SENSITIVE_COLUMN_OWNERS and real_table in SENSITIVE_COLUMN_OWNERS[column]:
            issues.append(ValidationIssue(
                "sensitive_column",
                f"Column '{column}' on table '{real_table}' is on the "
                f"sensitive-column blocklist — the AI Secretary must not "
                f"read credentials or secrets."
            ))
            continue  # don't also emit a (redundant) unknown_column if it
            # happens to be missing from the catalog

        _real_name, cols = catalog_ci[real_table.lower()]
        if column.lower() not in cols:
            issues.append(ValidationIssue(
                "unknown_column",
                f"Column '{column}' does not exist on table '{real_table}' (referenced as '{qualifier}.{column}')."
            ))

    # Bare (unqualified) column check — only attempted when the query
    # references exactly ONE real schema table (excluding CTEs), since a
    # bare column in a multi-table query is genuinely ambiguous and
    # guessing which table it belongs to risks false positives. This
    # covers a real, common case from this project's findings (e.g.
    # "SELECT StaffID FROM StaffDepartmentMaster WHERE DepartmentName = ...").
    # UserAccountRoleDetails and Branch_Academic_Details appear as nested
    # branch/year-scoping subqueries in nearly every query in this project
    # — they're structural boilerplate, not part of what the user actually
    # asked about, so they're excluded when deciding if a query is
    # "single-table" for the purpose of safely checking bare columns.
    _SCOPING_BOILERPLATE = {"useraccountroledetails", "branch_academic_details"}
    real_tables_referenced = set(
        v for v in alias_map.values()
        if v is not None and v.lower() not in _SCOPING_BOILERPLATE
    )
    if len(real_tables_referenced) == 1 and not system_aliases:
        # system_aliases non-empty means a SQL Server system object
        # (master.dbo.spt_values etc.) is present — that's a signal this
        # query has a genuinely different, unresolvable inner scope (e.g. a
        # derived table), which the simple bare-column heuristic below
        # isn't equipped to reason about (see module docstring on subquery
        # scope). Skip rather than risk checking a bare column against the
        # wrong table's columns.
        only_table = next(iter(real_tables_referenced))
        _real_name, cols = catalog_ci[only_table.lower()]
        # Also allow columns belonging to the excluded boilerplate tables —
        # our simple regex isn't scope-aware, so a bare column appearing
        # inside e.g. "(SELECT BranchID FROM UserAccountRoleDetails WHERE
        # UserID = @UserId)" would otherwise be wrongly checked against the
        # OUTER table instead of the subquery's own table.
        for boilerplate_table in _SCOPING_BOILERPLATE:
            if boilerplate_table in catalog_ci:
                _bp_name, bp_cols = catalog_ci[boilerplate_table]
                cols = cols | bp_cols
        known_aliases = set(alias_map.keys())

        # Output aliases (from "... AS SomeAlias" anywhere in the SELECT
        # list) are valid to reference in ORDER BY / GROUP BY even though
        # they're not real table columns — collect them so they're not
        # wrongly flagged.
        output_aliases = set(
            a.lower() for a in re.findall(r"\bAS\s+(\w+)", sql_scan, re.IGNORECASE)
        )

        bare_col_pattern = re.compile(
            r"(?:SELECT|WHERE|AND|OR|,|\bBY\b)\s+(\w+)\s*(?:=|,|>|<|\bIS\b|\bIN\b|\bLIKE\b|\bASC\b|\bDESC\b|\bFROM\b|$)",
            re.IGNORECASE
        )
        for m in bare_col_pattern.finditer(sql_scan):
            candidate = m.group(1)
            candidate_lower = candidate.lower()
            if candidate_lower in _RESERVED_NOT_ALIASES or candidate_lower in known_aliases:
                continue
            if candidate_lower in output_aliases:
                continue
            if candidate.startswith('@'):
                continue
            if candidate.isdigit():
                continue  # numeric literal (e.g. inside DATEADD(HOUR, 4, ...)), not a column
            if candidate_lower not in cols:
                issues.append(ValidationIssue(
                    "unknown_column",
                    f"Column '{candidate}' does not exist on table '{only_table}' (unqualified reference, single-table query)."
                ))

    # ── batch-b-2026-09-10: scoping-subquery select-list check. Catches the
    # #1 live failure class (linkage present + used as filter, but the
    # subquery selects a column that doesn't exist on its own table —
    # canonically 'SELECT Branch_Id FROM UserAccountRoleDetails'). See the
    # block comment above _SCOPING_FROM_PATTERN for why the existing
    # alias.column and bare-column checks structurally miss this class.
    issues.extend(_scoping_subquery_issues(sql_scan, catalog_ci))

    return ValidationResult(is_valid=(len(issues) == 0), issues=issues, tables_found=alias_map)


# ── Convenience wrapper (matches the original API used by orchestrator) ────
def validate_sql_with_catalog(sql: str, catalog_path: Optional[str] = None) -> ValidationResult:
    """
    Thin wrapper around validate_sql. Provided so the orchestrator can pass
    an explicit catalog path per-call without touching the module-level
    cache (the cache is reused if the path matches).
    """
    return validate_sql(sql, schema_catalog_path=catalog_path)


# ── Self-test ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    # Smoke: load the catalog (using env var or default) and validate a
    # trivial SELECT. Should pass with no issues.
    r = validate_sql("SELECT TOP 1 ID FROM UserAccountMaster WHERE ID = @UserId")
    print(r.summary())
    # Defense-in-depth: a SENSITIVE table must be refused even though it
    # genuinely exists in the catalog.
    r2 = validate_sql("SELECT TOP 1 * FROM StorageConfiguration")
    print(r2.summary())
    # Defense-in-depth: a SENSITIVE column on a real owner table.
    r3 = validate_sql(
        "SELECT u.Password FROM UserAccountMaster u WHERE u.ID = @UserId"
    )
    print(r3.summary())

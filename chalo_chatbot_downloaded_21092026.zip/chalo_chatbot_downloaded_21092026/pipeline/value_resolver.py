"""
AI Secretary — Application Layer :: Value Resolver (Component #2) — round-2 corrected
======================================================================================

⚠️ ARCHITECTURE CORRECTION (round-2 §F6, §14b) — READ FIRST
-----------------------------------------------------------
The original ValueValidator (from the 2026-08-03 correction) VALIDATED the
model's literal against the branch vocab but did NOT SUBSTITUTE — i.e. when
the user typed "maths" and the branch stores "MATHS" (a CI near-miss), or
when the model emitted "Mathematics" and the synonym store maps that to
ConceptKey GRADE_SUBJECT_MATHS → branch vocab member "MATHS" (a synonym
match), the validator would route the case-insensitive one to DISAMBIGUATION
even when there was exactly one match — and the query would execute with the
WRONG literal in it (the user's "maths" rather than the DB's "MATHS"). The DB
returned zero rows (case-sensitive comparison), and the orchestrator
silently surfaced "0 students" as a confident ANSWER. Confirmed bug — see
round-2 §14b.

ROUND-2 FIX (D1.4 / §F6):
  When matched_via is "synonym_exact" or "ci_near_miss", the ValueValidator
  now returns the database_value AND sets `should_substitute=True` so the
  orchestrator can REWRITE the SQL literal (parameter_binder.substitute_validated_values)
  BEFORE the semantic-rules check (so semantic_rules sees the substituted
  SQL). Only the canonical VALIDATED + should_substitute=True path triggers a
  substitution; NEEDS_DISAMBIGUATION and NOT_RECOGNIZED still fail closed
  (ask / refuse) — substitution is for CONFIDENT single-match cases only.

⚠️ VOCAB ENGINE LIVES ELSEWHERE: the synonym store (SynonymStore) and the
validate-and-substitute logic (validate_and_substitute, SubstitutionResult)
live in /home/z/my-project/chalo_chatbot/vocab/inject.py — this module
imports them. Do NOT duplicate them here.

The original ValueResolver (table-substitution via ConceptStore) is
retained below for history and for any offline/table-backed use, but is
SUPERSEDED for the live pipeline.

Reconstructed from the original app_layer/value_resolver.py + round-2 F6
extension. Diff against your real files before deploying.
"""

from __future__ import annotations

import difflib
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Dict, Any

try:
    # The vocab engine lives in /home/z/my-project/chalo_chatbot/vocab/inject.py
    from vocab.inject import SynonymStore, validate_and_substitute, SubstitutionResult
except ImportError:  # pragma: no cover — runtime fallback for direct-module imports
    import os, sys
    _HERE = os.path.dirname(os.path.abspath(__file__))
    _VOCAB = os.path.normpath(os.path.join(_HERE, "..", "vocab"))
    if _VOCAB not in sys.path:
        sys.path.insert(0, _VOCAB)
    from inject import SynonymStore, validate_and_substitute, SubstitutionResult  # type: ignore

try:
    from .concept_store import ConceptStore
except ImportError:
    from concept_store import ConceptStore  # type: ignore


# Default fuzzy threshold. Deliberately high — we prefer to ASK (fail closed)
# rather than accept a weak fuzzy match. Tunable per call.
DEFAULT_FUZZY_THRESHOLD = 0.86


class ResolutionStatus(str, Enum):
    RESOLVED = "RESOLVED"
    NEEDS_DISAMBIGUATION = "NEEDS_DISAMBIGUATION"


@dataclass
class ResolutionResult:
    """Outcome of resolving a single user value for one branch (legacy path)."""
    status: ResolutionStatus
    concept_type: str
    user_value: str
    # populated when RESOLVED:
    concept_key: Optional[str] = None
    database_value: Optional[str] = None
    source_table: Optional[str] = None
    match_kind: Optional[str] = None            # "exact" | "fuzzy"
    match_score: Optional[float] = None
    # populated when NEEDS_DISAMBIGUATION:
    reason: Optional[str] = None                # "no_match" | "multiple_synonyms" | "multiple_mappings"
    candidates: List[Dict[str, Any]] = field(default_factory=list)

    @property
    def resolved(self) -> bool:
        return self.status == ResolutionStatus.RESOLVED


def _normalize(text: str) -> str:
    """
    Lightweight normalization for exact-match comparison:
    lowercase, collapse internal whitespace, strip surrounding punctuation/space.
    Intentionally conservative — real matching intelligence lives in the
    Synonym table rows, not in clever normalization.
    """
    t = (text or "").strip().lower()
    t = re.sub(r"\s+", " ", t)
    t = t.strip(" .,:;!?-_/")
    return t


class ValueResolver:
    """
    Legacy table-substitution resolver (ConceptStore-backed). Retained for
    history and offline use; the live pipeline uses ValueValidator below.

    Usage:
        resolver = ValueResolver(store)
        res = resolver.resolve("CLASS", "10th standard", branch_id=2)
        if res.resolved:
            bind_param(res.database_value)      # e.g. 'X'
        else:
            hand res.candidates to the Disambiguation Handler (Component #3)
    """

    def __init__(self, store: ConceptStore, fuzzy_threshold: float = DEFAULT_FUZZY_THRESHOLD):
        self._store = store
        self._threshold = fuzzy_threshold

    # ── Phase 1: user phrasing -> concept key (synonym table only) ──
    def _match_concept_key(self, concept_type: str, user_value: str):
        """
        Returns (status_ok, concept_key, match_kind, score, candidate_keys).

        status_ok=False means ambiguous/none — caller fails closed.
        Fuzzy matching is confined to this method and only touches UserTerm
        strings from the Synonym table.
        """
        synonyms = self._store.synonyms_for_type(concept_type)
        norm_input = _normalize(user_value)

        # 1a. Exact (normalized) match wins outright.
        exact_keys = {
            s["ConceptKey"] for s in synonyms
            if _normalize(s["UserTerm"]) == norm_input
        }
        if len(exact_keys) == 1:
            return True, next(iter(exact_keys)), "exact", 1.0, []
        if len(exact_keys) > 1:
            # Same phrasing maps to multiple concepts — genuinely ambiguous.
            return False, None, None, None, sorted(exact_keys)

        # 1b. Fuzzy fallback — only against known phrasings (never raw DB values).
        #
        # DIGIT-CONFLICT GUARD (added after confirmed real-world testing):
        # difflib's character-level similarity is blind to numeric meaning --
        # "Class 99" vs "Class 9" scores 0.933 (shared "Class " prefix
        # dominates the ratio), ABOVE the default 0.86 threshold, causing
        # "Class 99" to silently VALIDATE as "Class 9" (confirmed via direct
        # testing: status=VALIDATED, database_value="Class 9",
        # matched_via="synonym_exact" -- not a rejection, an actual wrong
        # answer). No threshold value cleanly separates this false positive
        # from legitimate matches, since several real phrasings ("grade-10"
        # at 0.875, "10 th" at 0.889, "std. 10" at 0.923) score LOWER than
        # this false positive (0.933). A blanket threshold change would
        # break those. This guard is narrower and precise: if BOTH the
        # input and a candidate phrasing contain digits, and those digits
        # differ, that candidate is skipped regardless of its similarity
        # score -- confirmed via direct testing to reject "Class 99" vs
        # "Class 9" while leaving every legitimate case (which always has
        # matching digits) unaffected.
        input_digits = re.findall(r"\d+", norm_input)
        scored: Dict[str, float] = {}
        for s in synonyms:
            term_norm = _normalize(s["UserTerm"])
            term_digits = re.findall(r"\d+", term_norm)
            if input_digits and term_digits and input_digits != term_digits:
                continue  # digit conflict -- never a valid match, regardless of text similarity
            score = difflib.SequenceMatcher(None, norm_input, term_norm).ratio()
            key = s["ConceptKey"]
            if score > scored.get(key, 0.0):
                scored[key] = score

        above = {k: v for k, v in scored.items() if v >= self._threshold}
        if not above:
            return False, None, None, None, []          # no confident match
        if len(above) == 1:
            k, v = next(iter(above.items()))
            return True, k, "fuzzy", round(v, 4), []

        # Multiple concepts tie above threshold. Accept only if there is a clear
        # single winner strictly ahead of the rest; otherwise ambiguous.
        ranked = sorted(above.items(), key=lambda kv: kv[1], reverse=True)
        top_key, top_score = ranked[0]
        second_score = ranked[1][1]
        if top_score - second_score >= 0.05:
            return True, top_key, "fuzzy", round(top_score, 4), []
        return False, None, None, None, [k for k, _ in ranked]

    # ── Public: full two-phase resolution ──
    def resolve(self, concept_type: str, user_value: str, branch_id: int) -> ResolutionResult:
        ok, concept_key, kind, score, cand_keys = self._match_concept_key(
            concept_type, user_value
        )

        if not ok:
            return ResolutionResult(
                status=ResolutionStatus.NEEDS_DISAMBIGUATION,
                concept_type=concept_type,
                user_value=user_value,
                reason="no_match" if not cand_keys else "multiple_synonyms",
                candidates=[{"concept_key": k} for k in cand_keys],
            )

        # Phase 2: concept key -> branch's real stored value.
        mappings = self._store.mappings_for_key(concept_type, concept_key, branch_id)

        if len(mappings) == 1:
            m = mappings[0]
            return ResolutionResult(
                status=ResolutionStatus.RESOLVED,
                concept_type=concept_type,
                user_value=user_value,
                concept_key=concept_key,
                database_value=m["DatabaseValue"],
                source_table=m["SourceTable"],
                match_kind=kind,
                match_score=score,
            )

        # 0 or 2+ real values for this branch -> ask, using the branch's own
        # vocabulary (the candidate DatabaseValues). Fail closed.
        return ResolutionResult(
            status=ResolutionStatus.NEEDS_DISAMBIGUATION,
            concept_type=concept_type,
            user_value=user_value,
            concept_key=concept_key,
            match_kind=kind,
            match_score=score,
            reason="no_match" if not mappings else "multiple_mappings",
            candidates=[
                {"database_value": m["DatabaseValue"], "source_table": m["SourceTable"]}
                for m in mappings
            ],
        )


# ═══════════════════════════════════════════════════════════════════════════
#  CORRECTED PIPELINE (2026-08-03): ValueValidator
#  Validates a value against the branch's live Context-JSON vocabulary instead
#  of substituting from a maintained table. Use this for the live pipeline.
#
#  ROUND-2 EXTENSION (D1.4 / §F6): ValueValidator now uses the vocab engine
#  (vocab/inject.py's validate_and_substitute) for the synonym + CI near-miss
#  paths, and returns `should_substitute=True` with the database_value when
#  matched_via ∈ {"synonym_exact", "ci_near_miss"} so the orchestrator can
#  REWRITE the SQL literal before the semantic-rules check.
# ═══════════════════════════════════════════════════════════════════════════

class ValidationStatus(str, Enum):
    VALIDATED = "VALIDATED"                     # exact member of branch vocab (or confident substitute)
    NEEDS_DISAMBIGUATION = "NEEDS_DISAMBIGUATION"  # CI near-miss(es) or 2+
    NOT_RECOGNIZED = "NOT_RECOGNIZED"           # nothing — fail closed


@dataclass
class ValidationResult:
    """Outcome of validating one value for one branch against Context-JSON vocab.

    ROUND-2 F6: `database_value` + `should_substitute` are populated whenever
    matched_via ∈ {"synonym_exact", "ci_near_miss"} so the orchestrator can
    REWRITE the SQL literal (the model emitted the user's phrasing or a
    near-miss; we splice in the branch's real literal before the
    semantic-rules check).
    """
    status: ValidationStatus
    concept_type: str
    user_value: str
    database_value: Optional[str] = None        # exact branch literal to bind (or substitute)
    concept_key: Optional[str] = None
    matched_via: Optional[str] = None           # "exact_member" | "synonym_exact" | "synonym_fuzzy" | "ci_near_miss"
    candidates: List[str] = field(default_factory=list)  # branch literals to offer on disambiguation
    reason: Optional[str] = None                # "not_recognized" | "near_miss" | "multiple" | "multiple_synonyms"
    # D1.4 / F6: when True, the orchestrator rewrites the SQL literal with
    # database_value before the semantic-rules check.
    should_substitute: bool = False

    @property
    def validated(self) -> bool:
        return self.status == ValidationStatus.VALIDATED


class ValueValidator:
    """
    Corrected-architecture value handler: VALIDATE, and SUBSTITUTE when there
    is a single confident match (D1.4 / F6).

    The per-branch vocabulary is supplied by app_layer.context_vocab.BranchVocab
    (parsed from the login Context JSON). The synonym store
    (vocab/inject.py SynonymStore) is OPTIONAL: when supplied, it provides the
    phrasing → ConceptKey bridge for synonym matches (handles "10th" → "X",
    "maths" → "MATHS"). Fuzzy matching, when used, is confined to the synonym
    phrasings (never raw DB values) — the same rule as the original design.

    Usage:
        store = SynonymStore()               # vocab/inject.py
        v = ValueValidator(branch_vocab, synonym_store=store)
        r = v.validate("CLASS", "10th standard")
        if r.validated:
            if r.should_substitute:
                sql = substitute_validated_values(sql, {f"{r.concept_type}:{r.user_value}": r.database_value})
            bind_param(r.database_value)          # e.g. 'X'
        elif r.status is ValidationStatus.NEEDS_DISAMBIGUATION:
            ask_user(r.candidates)                # Disambiguation Handler
        else:
            fail_closed(r)                        # not recognized
    """

    def __init__(self, branch_vocab: Any,
                 synonym_store: Optional[SynonymStore] = None,
                 fuzzy_threshold: float = DEFAULT_FUZZY_THRESHOLD,
                 concept_store: Any = None):
        """
        Args:
            branch_vocab: context_vocab.BranchVocab for the selected branch.
            synonym_store: vocab/inject.py SynonymStore (recommended) — the
                new vocab engine. When provided, validate-and-substitute runs
                with synonyms + fuzzy + CI near-miss.
            fuzzy_threshold: difflib ratio threshold for fuzzy synonym
                matches (only used by the synonym store, never against raw DB
                values).
            concept_store: optional legacy ConceptStore (synonyms) — used
                ONLY when synonym_store is None, to preserve backward
                compatibility with the original table-backed path.
        """
        self._vocab = branch_vocab            # context_vocab.BranchVocab
        self._synonym_store = synonym_store    # new vocab engine (vocab/inject.py)
        self._threshold = fuzzy_threshold
        self._store = concept_store            # legacy ConceptStore (synonyms)

    # ── Phase 1 helper: canonical terms via the legacy ConceptStore ──
    def _canonical_terms(self, concept_type: str, user_value: str) -> List[str]:
        """
        Phase 1 — map the user's phrasing to candidate canonical term(s) via
        the legacy ConceptStore (if provided). Returns the list of
        ConceptKeys' canonical terms to try against the branch vocab. If no
        store/synonyms, returns the raw user value so it is validated
        directly. Only used as a fallback when no vocab/inject.py SynonymStore
        is wired in.
        """
        if self._store is None:
            return [user_value]
        # Reuse the proven synonym matching from ValueResolver.
        helper = ValueResolver(self._store, self._threshold)
        ok, concept_key, kind, score, _cands = helper._match_concept_key(
            concept_type, user_value
        )
        if not ok or concept_key is None:
            # No confident synonym mapping — fall back to the raw value; the
            # branch-vocab check below still gets a chance (and fails closed).
            return [user_value]
        # Gather every synonym phrasing for this concept key as candidate terms
        # to test against the branch vocab (e.g. GRADE_10 -> "X","10","Class 10").
        terms = [
            s["UserTerm"] for s in self._store.synonyms_for_type(concept_type)
            if s["ConceptKey"] == concept_key
        ]
        # Include the raw user value too, in case the branch literal IS a phrasing.
        return terms + [user_value]

    def validate(self, concept_type: str, user_value: str) -> ValidationResult:
        """
        Validate `user_value` against the branch vocab. Returns a
        ValidationResult whose `should_substitute` flag is True whenever the
        validator has a confident database_value to splice back into the SQL
        (D1.4 / F6). The orchestrator calls
        parameter_binder.substitute_validated_values() to do the actual
        rewrite BEFORE the semantic-rules check.
        """
        # ── Batch A / owner Decision 2 (2026-09-10): empty-vocab section
        # fallback. When the school's Sections vocab is EMPTY (nothing
        # configured/returned by the API), accept a 1-3 char alnum literal
        # ('A', '7a', 'B') as-is instead of failing closed — the production
        # audit's 7/8 VALIDATE refusals were exactly this gap. When the
        # vocab is NON-empty, strict matching is unchanged: a school with
        # real sections (North/South/Blue/Red) must not get a wrong-guess
        # 'B' silently accepted.
        if (str(concept_type).lower() in ("sections", "section")
                and re.fullmatch(r"[A-Za-z0-9]{1,3}", str(user_value or ""))
                and not self._vocab.values(concept_type)):
            return ValidationResult(
                status=ValidationStatus.VALIDATED,
                concept_type=concept_type, user_value=user_value,
                database_value=user_value, matched_via="empty_vocab_fallback",
                should_substitute=False,
            )

        # ── Path A (preferred, round-2 vocab engine): use
        # vocab/inject.py.validate_and_substitute, which already implements
        # exact_member → synonym_exact → synonym_fuzzy → ci_near_miss →
        # fail-closed, with the database_value populated for every confident
        # match. Translate its SubstitutionResult into our ValidationResult.
        if self._synonym_store is not None:
            sub = validate_and_substitute(
                concept_type, user_value, self._vocab, self._synonym_store,
                fuzzy_threshold=self._threshold,
            )
            if sub.matched_via == "exact_member":
                # Already a real branch literal — no rewrite needed, just bind.
                return ValidationResult(
                    status=ValidationStatus.VALIDATED,
                    concept_type=concept_type, user_value=user_value,
                    database_value=sub.database_value, matched_via="exact_member",
                    should_substitute=False,
                )
            if sub.matched_via in ("synonym_exact", "ci_near_miss"):
                # D1.4 / F6: the model emitted a phrasing / near-miss; we
                # have a single confident branch literal — SUBSTITUTE it
                # back into the SQL before the semantic-rules check.
                return ValidationResult(
                    status=ValidationStatus.VALIDATED,
                    concept_type=concept_type, user_value=user_value,
                    database_value=sub.database_value, matched_via=sub.matched_via,
                    should_substitute=True,
                )
            # synonym_fuzzy isn't returned by validate_and_substitute as a
            # confident single match (it requires a clear winner above
            # threshold) — that path is folded into synonym_exact at the
            # engine level. If we ever see it, treat as a confident match.
            if sub.matched_via == "synonym_fuzzy":  # pragma: no cover - defensive
                return ValidationResult(
                    status=ValidationStatus.VALIDATED,
                    concept_type=concept_type, user_value=user_value,
                    database_value=sub.database_value, matched_via="synonym_fuzzy",
                    should_substitute=True,
                )
            # Needs disambiguation
            if sub.needs_disambiguation:
                return ValidationResult(
                    status=ValidationStatus.NEEDS_DISAMBIGUATION,
                    concept_type=concept_type, user_value=user_value,
                    candidates=sub.candidates,
                    reason=sub.reason or "multiple",
                )
            # Not recognized
            return ValidationResult(
                status=ValidationStatus.NOT_RECOGNIZED,
                concept_type=concept_type, user_value=user_value,
                candidates=sub.candidates,
                reason=sub.reason or "not_recognized",
            )

        # ── Path B (legacy fallback, no SynonymStore wired): replicate the
        # original ValueValidator behavior using the legacy ConceptStore (if
        # provided) for synonym resolution, but APPLY the D1.4 / F6 fix here
        # too: a single CI near-miss becomes VALIDATED + should_substitute=True
        # (substitute the branch's real literal) instead of routing to
        # disambiguation.
        # 0. Direct exact-member check on the raw value (fast path).
        if self._vocab.is_member(concept_type, user_value):
            return ValidationResult(
                status=ValidationStatus.VALIDATED,
                concept_type=concept_type, user_value=user_value,
                database_value=user_value, matched_via="exact_member",
                should_substitute=False,
            )

        # 1. Map phrasing -> candidate canonical terms (synonyms, optional).
        candidate_terms = self._canonical_terms(concept_type, user_value)

        # 2. Try each candidate term for an EXACT branch-vocab member.
        for term in candidate_terms:
            if self._vocab.is_member(concept_type, term):
                return ValidationResult(
                    status=ValidationStatus.VALIDATED,
                    concept_type=concept_type, user_value=user_value,
                    database_value=term,
                    matched_via="synonym_exact" if term != user_value else "exact_member",
                    # D1.4 / F6: substitute the synonym's real literal for
                    # the model's phrasing.
                    should_substitute=(term != user_value),
                )

        # 3. No exact member — look for case-insensitive near-misses on the
        #    raw value AND the candidate terms (D1.4 / F6: a single near-miss
        #    now SUBSTITUTES instead of routing to disambiguation).
        ci_hits: List[str] = []
        for term in [user_value] + candidate_terms:
            for hit in self._vocab.match_ci(concept_type, term):
                if hit not in ci_hits:
                    ci_hits.append(hit)

        if len(ci_hits) == 1:
            # Single CI near-miss (e.g. user "Maths" vs branch "MATHS"):
            # round-2 fix — SUBSTITUTE the branch's real literal rather than
            # asking the user to confirm casing/punctuation. Two+ matches
            # still go to disambiguation (real ambiguity remains).
            return ValidationResult(
                status=ValidationStatus.VALIDATED,
                concept_type=concept_type, user_value=user_value,
                database_value=ci_hits[0],
                matched_via="ci_near_miss",
                should_substitute=True,
            )
        if len(ci_hits) >= 2:
            return ValidationResult(
                status=ValidationStatus.NEEDS_DISAMBIGUATION,
                concept_type=concept_type, user_value=user_value,
                candidates=ci_hits, reason="multiple",
            )

        # 4. Nothing recognized — fail closed. Offer the branch's full vocab so
        #    the Disambiguation Handler can present real options.
        return ValidationResult(
            status=ValidationStatus.NOT_RECOGNIZED,
            concept_type=concept_type, user_value=user_value,
            candidates=list(self._vocab.values(concept_type)),
            reason="not_recognized",
        )
